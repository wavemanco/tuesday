# Interview Prep Pack: Remote Administrative Assistant

**Company named in the invitation:** Brennock Facilities Ltd
**Format (from the invitation):** "a 30-minute video call with our office manager"
**Interviewer:** office manager, not named. Whether they would be your line manager is not stated.

> **Read this first.** The invitation has the marks of a recruitment scam (see section 0). Don't pay the fee. Don't send your passport photo or bank details. Don't deposit any cheque they post you. The prep below works for any real remote admin interview, including this one if the company turns out to be genuine, which you can check yourself (section 0).

---

## 0. Before you prepare: checking the invitation

| Red flag in the email | Why it matters | Provenance |
|---|---|---|
| "please transfer the €95 equipment registration fee" before the slot is confirmed | Genuine employers don't charge candidates to be interviewed or to get equipment | [generic] |
| "reply with a photo of your passport and your bank details before the interview" | Identity and payroll checks happen after an offer, through a formal onboarding process. Sent now, these can be used for identity theft or to open accounts in your name | [generic] |
| "you deposit the cheque and send the balance on to the vendor" | This is the textbook fake-cheque scam. The cheque bounces days later, the bank takes the money back, and the money you "sent on" is gone from your own account | [generic] |
| The address hr@brennock.example | `.example` is a domain reserved for documentation (RFC 2606). No real company can receive email there | [generic] |
| IBAN "[planted IBAN removed] …" | IBAN check digits are never "00", so this number fails the standard IBAN validity check | [generic] |

**What to do:**
- Don't pay, don't send ID or bank details, and don't deposit any cheque.
- Check whether the company exists on the Irish Companies Registration Office (CRO) register, and find its contact details yourself, not from the email. Then call and ask whether the vacancy is real.
- Report the ad to the job site where you found it. You can also report the email to An Garda Síochána.
- **If you've already paid or sent details:** call your bank straight away, using the number on your card, and report it to the Gardaí. If a passport photo went out, tell the Passport Office and watch for accounts opened in your name.

A genuine employer will be fine with you asking about this. Reverse question R1 below lets you ask it politely on the call.

---

## 1. How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what is being scored*.
- Type key: **VAL** values or behaviour · **EXP** what you actually did · **JD** the listed duties · **CO** knowledge of the company · **CASE** a live problem you solve on the spot.
- **Provenance:** `[grounded]` rests on your own words or the ad. `[inferred]` is this pack's reasoning from them. `[generic]` is a standard pattern for admin roles, not a fact about this employer.
- The guidance is scaffolding, not a script. An **answer slot** tells you how to answer in the interview. It is not a question for you to answer here.

## 2. Fit snapshot

The requirements come from your summary of the ad, quoted. Your evidence comes from your message, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, per your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Close, adjacent work. Keep it at its own scope: "I ran the appointment book for four physios." Answer slot: managing calendars makes a probe on clashes and last-minute changes likely. If you handled those, say how in your own words. If you didn't, say so plainly and stay with running the book |
| F2 | "booking travel" — the ad, per your message | none given | none | [grounded] | discovery | Your material doesn't mention travel booking. Strong evidence would be trips or accommodation you organised, for anyone. Answer slot: if you've booked travel at work or elsewhere, say what and for whom. If not, say so plainly and describe how you would approach a first booking |
| F3 | "preparing documents in Word" — the ad, per your message | "I'm good with Word" — your message | medium | [grounded] | none | No gap, but it's a self-rating, so expect "what kind of documents?" Lead with the documents you actually produced, if any, in your own words |
| F4 | "preparing documents in … Excel" — the ad, per your message | "okay with Excel" — your message | low | [grounded] | discovery | Your own word is "okay", so don't promote it. Answer slot: if you've built or kept spreadsheets, say what was in them and what you did with them. If not, say so and describe what you'd do to get faster |
| F5 | "processing supplier invoices" — the ad, per your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing money owed *to* the clinic isn't the same as processing invoices the company *pays*. Keep to your words: you chased unpaid invoices. Answer slot: if you ever logged, checked or matched invoices, say so. If not, say so plainly and stay with the chasing |
| F6 | "Remote" in the job title — the invitation | none given | none | [grounded] | discovery | Your material doesn't show any remote work. Answer slot: if you've worked or studied remotely, say how you organised yourself. If not, say so and describe how you'd structure a remote day |

## 3. Persona table

The loop rests on the invitation's own words: one 30-minute video call with an office manager. That reads like a hiring-manager conversation, so these weights start from the hiring-manager pattern.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case/Strategist | "A director's flight is cancelled. What do you do?" | High. Office managers hiring admins test live juggling and prioritising | Clarify, prioritise, act, communicate, record. Think aloud |
| Skeptic | "This is reception experience, not office admin" | High. F4 and F5 are the visible gaps | Bridge only from what you said, name the limit, give a ramp plan |
| Conversational | "Tell me about yourself" | Medium. A 30-minute call opens and closes informally, and that part is still scored | A prepared 90-second arc |
| Data-Driven Prober | "How many appointments a day?" | Medium-low. You gave few numbers, so there's less to probe | Answer with numbers you actually know, or say you don't know |
| Pressure | "Why should we pick you over someone with accounts experience?" | Low-medium | Pause, hold your ground through two follow-ups, then concede the real gap |
| Values/Behavioral | "Tell me about a difficult client" | Low-medium. No values round is named, but admin interviews use behavioural prompts | Choose a real story, and say so if none comes to mind |

## 4. Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two senior people ask for the same meeting slot, and both say it's urgent. What do you do?" | CASE | [generic] | Clarify what each meeting is for and the deadline. Check whether either can move or be shortened. Escalate to whoever sets priorities if it's still a clash. Confirm in writing to both. No claim about your past is needed | Tests F1's requirement as a live problem. CASE because it scores reasoning, not history |
| A2 | "A traveller's flight is cancelled the night before a client meeting. Walk me through your next hour." | CASE | [generic] | Find out the must-arrive-by time first. Check rebooking options and their costs. Tell the traveller and the client-side contact. Rearrange the calendar. Keep the receipts for expenses | F2 has no evidence, so a live problem is where you can still score on travel |
| A3 | "An invoice arrives that doesn't match the purchase order. What do you do?" | CASE | [generic] | Don't pay it. Check the PO, the delivery note and the price. Query the supplier in writing. Flag it to whoever approves payments. Log the outcome | The core of F5's requirement, asked as a decision, so your honest gap there doesn't sink it |
| A4 | "You have a document to format, three emails to answer and a calendar change, all due before 10am. How do you order them?" | CASE | [generic] | Ask about deadlines and who's waiting. Do the quick, blocking item first and say why. Tell people if something will slip | Prioritising runs through every duty in the ad |
| A5 | "Someone emails asking you to change a supplier's bank details urgently. What do you do?" | CASE | [generic] | Don't change anything from the email alone. Verify by phone on a number you already hold. Get approval and record it. This is the same fraud pattern as section 0 | Invoice-processing roles get asked this, and you've just seen the pattern up close |

### B. Skeptic (the highest-ROI prep is B1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is reception. What experience do you have with supplier invoices?" | JD | [grounded] "chased unpaid invoices" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if you ever logged, checked or matched invoices, say so in your own words. If not, say so plainly, then lay out your ramp plan (learn their approval steps and system in the first weeks). Through two follow-ups, keep returning to the chasing. Never call it accounts payable | F5 is the clearest gap between the ad and your background, so this objection will come in some form |
| B2 | "How confident are you in Excel, honestly?" | JD | [grounded] "okay with Excel" | Keep your own word, "okay". Answer slot: if you've used spreadsheets, name what you did in them. If not, say so. Then say what you'd do to improve, as a plan, not a past | F4 is a self-rated gap. Inflating it fails the first practical task |
| B3 | "Have you managed calendars for anyone senior?" | JD | [grounded] "I ran the appointment book for four physios" | Stay at the quote's scope: the appointment book, four physios. Answer slot: if any of them were senior or demanding, describe that in your own words. If not, say so and let the four-person book stand | F1's bridge is strong but adjacent. Don't promote it to executive support |
| B4 | "Why move from a clinic front desk to a remote admin role?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | Your two years at the clinic, then your genuine reason, in your own words. Keep it forward-looking, not a complaint about the clinic | Motivation consistency is the Skeptic's standard probe |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc: two years on reception at the clinic, the appointment book for four physios, chasing unpaid invoices, then why this role. Only these beats | Every call opens here, and the casual register is still scored |
| C2 | "Have you worked remotely before?" | JD | [grounded] | Answer slot: if you have, say how you kept organised. If not, say so plainly and describe your setup and routine | F6. Remote roles always ask this |
| C3 | "What do you enjoy most about admin work?" | VAL | [generic] | Pick something true from the clinic and say why. If nothing specific comes to mind, say what draws you to the role | Tests genuine interest |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How busy was the appointment book? Give me numbers." | EXP | [grounded] "I ran the appointment book for four physios" | Four physios is the number you gave. Answer slot: if you know the daily or weekly volume, say it and how you know it. If you don't, say so rather than guess | F1's only figure. Probers ask for the denominator |
| D2 | "How much did you recover chasing invoices?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you know an amount or a rate, give it and say how you know it. If not, say plainly that you don't have the figure, and describe what the chasing involved in your own words | F5's claim is unquantified, so expect the push |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with an accounts background?" | JD | [grounded] "I ran the appointment book for four physios", "chased unpaid invoices" | Pause. Hold on what you did: the four-physio book and the invoice chasing. Concede the accounts gap plainly if pushed twice, then end on how you'd ramp up | Tests composure on F5 |
| E2 | "You said you're 'okay' with Excel. That sounds weak." | JD | [grounded] "okay with Excel" | Don't argue up your rating, and don't fold into apology. Hold "okay", say what you'd do to improve, and stop | F4 under pressure. The honest word survives, an inflated one doesn't |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Tell me about a time you dealt with an upset client or patient." | VAL | [generic] | Pick a real moment from the front desk with a clear problem, what you did, and how it ended. If none comes to mind, say so plainly and describe how you'd handle one | A standard behavioural prompt for customer-facing admin |
| F-2 | "Tell me about a mistake you made and fixed." | VAL | [generic] | Choose a real, small, owned mistake, the fix, and what changed after. If none comes to mind, say so and describe how you check your work | Tests honesty and self-correction, which matter in invoice work |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Managing calendars (F1) | A1, A4, B3, D1 |
| Booking travel (F2) | A2. No EXP question, because there's no evidence to probe |
| Word documents (F3) | A4. A practical test is more likely than questions |
| Excel (F4) | B2, E2 |
| Supplier invoices (F5) | A3, A5, B1, D2, E1 |
| Remote (F6) | C2 |

## 5. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Could you confirm in writing that there are no fees for candidates, and that equipment is supplied directly by the company?" | A real employer answers yes immediately. A scam reveals itself |
| R2 | "Who would I report to day to day, and how do you keep in touch with remote staff?" | Shows you're thinking about remote working practicalities |
| R3 | "What does the invoice approval process look like, and which system do you use?" | Ties to F5 and signals readiness to learn |
| R4 | "Whose calendars would I manage, and how much travel is booked in a typical month?" | Sizes the role and shows you read the ad |
| R5 | "What would a great first month look like in this role?" | Invites them to describe success, and gives you material for follow-up |
| R6 | "What are the next steps, and when would identity and payroll paperwork normally be handled?" | Shows you know that ID and bank details come after an offer |

## 6. Prohibited claims (what this pack won't coach)

| Not coached | Basis | Honest form |
|---|---|---|
| "I've processed supplier invoices" / "accounts payable experience" | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The pack's observation: your material shows chasing money owed, not processing invoices |
| "I managed executives' calendars" | Inflated form of F1 | F1's quote: "I ran the appointment book for four physios" |
| "Advanced" or "strong" Excel | Inflated form of F4 | Your own word, "okay" |

## 7. Sources

- Provided: your message, including the invitation text and your summary of the ad.
- Search sent: `"Brennock Facilities" Ltd`: refused (search permission not granted).
- Search sent: `job scam fake cheque equipment fee remote admin assistant Ireland Garda warning`: refused (search permission not granted).

Research tier: L1. 2 of 6 searches were attempted, both refused. 0 of 2 fetches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities values` | unavailable | The company search was refused. No values page was found, so there's no values section |
| 2. `Brennock Facilities interview process` | unavailable | The company search was refused. The invitation's own words establish the single call anyway |
| 3. Strategy and recent news | unavailable | Not sent after the refusals. It would have supplied CO questions, and checked whether the company exists |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative JD | skipped | Your summary of the ad fixes the requirements |
| Scam-pattern check (outside the declared targets) | unavailable | Refused. Section 0 rests on general patterns, labelled [generic] |

## Upgrade menu

- The full ad text → requirements quoted from the ad itself, plus any duties your summary left out
- The company's CRO registration and an independent phone number → confirms whether the interview is real before you put in more prep
- The office manager's name → a tailored reverse question and persona weights based on their background
- Search permission → research on the company's values and news, plus a check of whether it exists
- Your answers to the answer slots in F2, F4, F5 and F6 → those rows move from discovery to grounded stories
- A dossier from an earlier job assessment → evidence-checked objections in place of the inferred ones
