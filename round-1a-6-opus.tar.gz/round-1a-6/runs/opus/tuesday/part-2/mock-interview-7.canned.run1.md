Reading done — now running the default research pass on Saltmarsh Games and the interviewer before building your pack.
I've built your prep pack and saved it as `Saltmarsh-Games_live-operations-producer_interview_pack.md`. Today is Thursday, so it's set up for one evening of prep before Friday.

- **The format:** Saltmarsh's careers page says this interview is one 60-minute session with the hiring manager. The first half is a role-play on a simulated outage during a live event, and the second half is a conversation about the company's values. There's no take-home. The pack treats Tobias as that hiring manager.
- **The values:** the company has three published values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. The release checklist you wrote fits the third one closely.
- **Tobias:** he was a QA lead at a console studio before this job. He gave a talk at GDC 2026 arguing that a live team is judged by whether its patch notes describe what actually shipped. I only saw a summary of that talk, so if you mention it, cite only what you've actually watched or read yourself.
- **What's changing at the studio:** in September 2026 Saltmarsh announced it is moving two games, Tidepool Tactics and Lantern Row, to a season pass with one shared events calendar from February 2027. That probably means purchases are involved, which runs into your "never worked on a game with in-app purchases." The pack gives you a plain sentence to say and a learning plan, not a workaround.
- **The question to rehearse most:** you ran one title's calendar, and this role runs two, so what changes? It's question B1 in the pack, with exact wording for the follow-ups, including "I haven't led a team."

Say the word and I'll play the skeptical interviewer on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** Saltmarsh's "Outage Hour": a single 60-minute interview with the hiring manager. Their careers page says it is "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." This pack treats Tobias as that hiring manager. Your 60-minute slot with the Head of Live Operations matches that description.

---

## How to use this pack

Each question has two labels. The **persona** describes how it gets asked (who is asking, and in what tone). The **type** describes what is being scored. The answer guidance is a scaffold for you to speak from in your own words. It is not a script. Where a cell says **Answer slot**, the pack doesn't know the answer and won't invent one. Answer it from what you actually did, or say plainly that it wasn't yours.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values |
| EXP | Whether your stated experience holds up under scrutiny, including what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Saltmarsh's current strategy and can think at that level |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` means it traces to your message, the JD or a source listed under Sources. `[inferred]` means it is derived, and the derivation is named. `[generic]` means it is a role-family pattern with no claim about Saltmarsh or you.

---

## Prep triage: tonight

The interview is on Friday and today is Thursday, so this assumes you have one evening.

1. **B1 out loud, three times** (30 min). This is the highest-ROI prep in the pack. Rehearse the follow-ups too, especially the exact concession wording.
2. **A1 and A2, the outage tabletop** (30 min). It fills the first half of the hour. Say the structure aloud until it is automatic.
3. **C1 to C3, one story per value** (20 min). The values conversation fills the second half. C3 is your strongest one.
4. **D1, the retention numbers** (15 min). Before you walk in, know which measures you presented and what you can and can't say about how they were counted.
5. **G1, your 90-second journey** (10 min).
6. **Pick three reverse questions** (10 min). Make R1 or R2 one of them.

Everything else is insurance.

---

## Fit snapshot

All evidence quotes come from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar. It does not say live events across two titles, and your words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on what two titles would change likely. Answer it as a plan, not a past. If your calendar work ever touched a second title, or events alongside the drops, say what, in your own words. If it didn't, say so plainly and stay with the main title's calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a stated line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, the main title, the last two years |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message, "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | presentation | Reword only what you said: "Four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Keep "associate". Let the weekly drops make the live-service point rather than putting a label on the game. Answer slot: the JD says "mobile titles", so if asked about platform, say which platform your title was on |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Running a calendar touches this requirement, but your material doesn't show whether it reaches it. Answer slot: if running the calendar meant working with design, art, engineering or community on drops, say which teams and what you did with them, in your own words. If it didn't, or someone else did that, say so plainly and stay with the calendar |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting monthly numbers. It does not say owning a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared those numbers or wrote up what drove them, say which part, in your own words. If someone else built them, say so plainly and stay with presenting them |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in wording, but expect the probe to go one level down. Answer slot: name the retention measures you presented, in your own words. If you'd struggle to define one or to say how it was counted, say so plainly. That is better than a definition you can't defend |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote it. It does not say you ran it with QA release by release. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you worked through it with QA on releases, say how, in your own words. If QA ran it without you, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | One document other people still rely on touches this requirement but doesn't settle it. Answer slot: if you've written other things that teams or leadership relied on, name them in your own words. If the checklist is your strongest example, say so and let it stand |
| F9 | "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh news, September 2026 (company context, not a JD line) | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | This is a gap you stated, and wording can't close it. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan and never as a past. The link is the pack's derivation: season passes are typically sold in-game, so this row assumes the move touches purchases. The JD doesn't name monetization |

---

## Reading the interviewer

Public professional footprint only, from one search result. The talk page itself was not fetched.

| Signal | Provenance | What it means for Friday |
|---|---|---|
| Career pattern: "previously a QA lead at a console studio", now Head of Live Operations at Saltmarsh | [grounded] | Release discipline is his home ground. Expect A2, E2 and F2 to be pressed hard, and expect him to know what a good checklist looks like |
| GDC 2026 talk, "Patch Notes Are a Promise". The search summary describes its argument as "a live team is judged by how often its patch notes describe what actually shipped" | [grounded] | This is a published theme, so it will likely come back as a question (A5). It also matches the company value Ship the Patch Not the Promise. If you can find and watch the talk tonight, cite only what you actually saw |
| Shared vocabulary rather than a shared career jump | [grounded] | F7's quote, "Wrote the release checklist our QA team still uses", is in his language. Lead with it plainly and let him ask the follow-ups. Your material shows no career jump like his, so don't claim one |

---

## Persona table

The loop is established by Saltmarsh's careers page (see Sources), so these weights rest on this company's documented format, not on a guess.

| Persona | How it shows up on Friday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The outage tabletop, plus planning questions about the two-title calendar | Highest. The first half of the hour is a documented tabletop, and the hiring-manager prior puts Case on top | Clarify, set the objective, triage, act, communicate, then review. Think aloud and challenge one premise per case |
| B. Skeptic | Gentle, persistent probes on the step from one title to two, on associate-level scope and on the season pass | High. The hiring-manager prior puts Skeptic second, and F1, F4 and F9 are visible gaps | Rehearse B1 until it bores you. Bridge only from what you said, and state the limit before he does |
| C. Values / Behavioral | The second half of the hour: three named values | Mid. Values are documented in the loop, but they share the hour with the tabletop | One story or scaffold per value (see the cheat sheet). Use "we" for context and "I" for what was yours |
| D. Data-Driven Prober | Retention numbers, how drops were judged, a metric diagnosis | Mid. The JD names retention metrics and the post-event KPIs, and F5 and F6 are where a number gets tested | Know what you can and can't say about how the numbers were counted. "I don't know" is a legitimate answer |
| E. Pressure | Time-boxing inside the tabletop, and "how much was actually you" | Mid. A simulated outage is built for composure under time pressure | Pause, restate, anchor in what you said. Hold through two follow-ups, then concede specifically |
| F. Peer Evaluator | Seam questions between community, engineering and QA | Low. Tobias isn't a peer, but the JD's coordination line will arrive in this form | Propose principles for the seam. Don't pretend to know Saltmarsh's actual seams |
| G. Conversational | The opener and the close | Low, but the reverse-question slot is still scored | A 90-second arc, and never "I think you've covered everything" |

---

## Question banks

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event on one title. Some players report event rewards aren't granting. Walk me through your first 30 minutes." | CASE | [generic] | Clarify first: which players, which platforms, since when, and is it still happening. Set the objective: protect players, then fix. Triage: get engineering to confirm scope, and decide whether to pause, extend or leave the event running. Communicate: brief community on what is known now, with no fix time you can't stand behind. Record decisions and times as you go. Close by saying what the post-incident review will cover. The question needs no claim about your past, so the guidance makes none | Saltmarsh's careers page documents a tabletop on a simulated outage during a live event, so some version of this opens the hour. CASE because it scores live structure |
| A2 | "Engineering has a fix, but QA can't fully test it before the event ends. Do you ship it?" | CASE | [grounded] | Clarify the risk on both sides: what breaks if you ship untested, and what players lose if you don't. Offer options rather than a yes or no: ship the fix with a narrowed scope, extend the event, or compensate players afterwards. Name the call and who has to agree to it. Tie it to Players Before Plans ("when the calendar and the players disagree, the players win") and Leave the Build Greener. Challenge one premise, for example whether the event end date is actually fixed | The likely follow-up inside the tabletop, and it sits right on Tobias's QA background. Grounded on the values page cited in Sources |
| A3 | "From February both titles share one events calendar. How would you build it?" | CO | [grounded] | Clarify: each title's current cadence, the season boundaries, and what capacity the shared group has. Objective: one calendar with no clashes that strain the shared team. Approach: lay both titles' beats on one timeline, find collisions, sequence the art and engineering load, and set a review rhythm. Risks: two launches in one week, a shared bottleneck discipline, and community fatigue. Metrics: participation and retention by title. Answer it as a plan, not as something you've done before | Project Larkspur's shared calendar is Saltmarsh's biggest stated live-ops change, and few candidates will have read about it. CO content with CASE delivery |
| A4 | "What goes in a post-event review, and which KPIs would you report?" | JD | [generic] | A structure, not a past: what was planned versus what shipped, participation and completion, retention around the event window, incidents and how they were handled, community sentiment, and the one or two changes for next time. Name the season-pass angle as something you'd want to learn the Saltmarsh view on. Don't describe reviews you've owned, because F5 doesn't show one | The JD's post-event review line is a scored requirement, and F5 shows it only at a distance. JD content with CASE delivery |
| A5 | "How would you make sure our patch notes describe what actually shipped?" | CASE | [grounded] | A plan: draft the notes from the final build, not from the plan; flag last-minute cuts; give each line an owner; sign the notes off as a step in the release checklist; check them against the live build after release. Keep it short and concrete, because this is Ship the Patch Not the Promise in practice. Answer slot: if your own checklist covered release notes, say so in your own words. If it didn't, say so plainly and give the plan | The recurring theme of Tobias's published GDC talk, so likely to come up in some form. CASE because it asks how you'd do it here |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran the weekly content-drop calendar for your main title. This role runs live events across two titles. What changes, and where would you be weakest on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "Never led a team" | **The highest-ROI prep in this pack.** Open with the quote at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Then answer "what changes" as a plan: collisions between the two titles, a shared team's capacity, and one calendar instead of two. For "weakest", pick your real answer. The pack's read is that your material shows nothing yet on events across two titles or on cross-discipline coordination; if one of those is it, name it with your plan. **Follow-up 1**, "Have you worked with art, engineering and community directly?": the F4 answer slot. Which teams and what you did with them, or say plainly it wasn't yours. **Follow-up 2**, "Have you managed people?": "I haven't led a team." Stop there. Don't argue that coordinating is the same thing. **Follow-up 3**, "So why take the risk?": go back to the calendar quote and the checklist you wrote, and add nothing to them. Hold by returning to what you said. The limit is said before he asks for it, and it isn't a confession | F1, F4 and the stated "never led" line are where an associate stepping up gets pressed hardest, so this objection comes in some form. JD because it scores the two-title calendar requirement |
| B2 | "Both titles move to a season pass in February. What monetization work have you done?" | JD | [grounded] "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then a plan, not a past: who you'd sit with first, how you'd learn the titles' existing economy, and which questions you'd want answered about where season-pass content meets the events calendar. Don't pad the gap with nearby experience, and don't argue that the JD doesn't list it | F9 is a gap you stated, against the studio's biggest stated change. It may come up whether or not the JD names it. The question's premise is Saltmarsh's news, and the guidance adds nothing to your sentence |
| B3 | "Why live ops, why Saltmarsh, why now?" | EXP | [generic] | A selection scaffold: give your real reasons in your own words. Ideally there is one about the work (running a live calendar), one about Saltmarsh specifically (the shared calendar under Larkspur, or a value that matches how you work), and one about timing. If one of those isn't true for you, leave it out rather than borrowing it from this pack | The Skeptic's standard motivation probe. Generic because your message gives no reasons, so none are supplied here |
| B4 | "Your title's been associate producer. What changes stepping into a producer role?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Keep the title exactly as it is: "Four years as an associate producer." Then a plan: what you'd own outright on day one, and what you'd want to agree with Tobias in the first weeks. Answer slot: if any of your work was already producer-level by your studio's own definition, say what in your own words. If not, say so plainly and stay with the four years | F3's title is the seniority seam. EXP because it tests what your scope actually was |

### C. Values / Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our value is Players Before Plans. Tell me about a time the plan and the players disagreed." | VAL | [generic] | Selection scaffold: pick a time a plan you ran changed because of how players responded. It needs the plan, what the players did, the call, who made it, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is running the weekly content-drop calendar, or say how you would decide | The values page names this value, and the loop includes a values conversation. Your message has no story for it, so this is a scaffold |
| C2 | "Ship the Patch Not the Promise. When have you had to announce less than people hoped?" | VAL | [generic] | Selection scaffold: pick a time you said what was actually ready rather than what was hoped. It needs the pressure to promise more, what you said instead, and how it landed. If no such time comes to mind, say so plainly, then say how you would handle it here | The value's definition, "we announce what is built, not what is hoped", is also Tobias's talk theme, so it matters twice |
| C3 | "Leave the Build Greener. Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped: you wrote the release checklist, and QA still uses it. Those are the beats your sentence states, so tell them in your own words. Answer slot: the value says the checklist should be better after every release. If you revised it after releases, say how. If you didn't, or someone else maintains it, say so plainly and stay with having written it | Your strongest values match, and the value's own definition names "the checklist". VAL because it is scored against a published value |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The beats your sentence states: you presented them, monthly, to the studio head. Answer slot: the JD's retention-metrics line makes a probe on which measures and how they were counted likely. If you know, say in your own words. If someone else built them and you presented them, say so plainly. "I don't know exactly how that was counted" is an honest answer. If there's a part of the count you'd trust least, name it before he asks. Then stay with presenting them | F5 and F6 rest on this one line, so it is where the prober goes two levels deeper. EXP because it tests attribution |
| D2 | "How did you know whether a content drop worked?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: the JD's post-event KPIs line raises this. If you or anyone judged drops against a measure, say which and what your part was, in your own words. If drops weren't evaluated, or that wasn't yours, say so plainly and return to running the calendar, then say what you would measure first | F2's calendar meets the F5 requirement here. JD because it scores the KPI ownership line |
| D3 | "Day-7 retention on one title dropped after an event. Diagnose it." | CASE | [generic] | Clarify: how big the drop is, which cohort, and whether the measurement changed. Segment: new versus returning players, platform, and event participants versus non-participants. Hypotheses: event difficulty or rewards, a bug, a competing release, seasonality. Say which you'd check first and why, then what you'd do. The question needs no claim about your past | A standard metric-diagnosis case for the JD's retention requirement. Generic pattern |

### E. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live events across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" | Pause and restate. Hold on what you said: two years running the main title's weekly content-drop calendar, and a release checklist QA still uses. When he pushes, hold through two follow-ups by returning to those two lines. Concede by scope, specifically: "My calendar was one title's." Never fold the core claim, and never add to it | F1's scope gap delivered at speed. The hold is only what F2 and F7 carry |
| E2 | "That release checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote it, and QA still uses it." If others contributed, say who and what before he asks. Ambiguity goes downward. Answer slot: if he asks how you know QA still uses it, say how you know in your own words. If you're going on what you last saw, say that | A persona stem aimed at F7, from an ex-QA lead. EXP because it tests attribution |
| E3 | "Thirty seconds. The event's broken and community wants something posted now. What's the message?" | CASE | [grounded] | Say what's known, that the team is on it, and when the next update will come. Give no fix time you can't keep. That is Ship the Patch Not the Promise in one line. If he interrupts, finish the sentence calmly, then answer the interruption | Time pressure inside the tabletop. Grounded on the value cited in Sources |

### F. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Community wants to post a fix time. Engineering won't commit to one. You're between them. What do you do?" | CASE | [generic] | Propose principles for the seam rather than claiming to know Saltmarsh's: engineering owns the estimate, community owns the voice, and you own the decision on what gets said and when. Agree one honest line together and a time for the next update | The JD's coordination line in collegial packaging |
| F2 | "QA wants to block a release on a checklist item. Engineering says it's cosmetic. What happens?" | CASE | [generic] | Clarify what the item protects and what players would see. Bring the two leads together on the risk, not the rule. Make or escalate the call, record it, and fix the checklist item if it was miscalibrated (Leave the Build Greener). No claim about your past | The JD's checklist-with-QA line from Tobias's home ground |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | A 90-second arc in your words, using four beats: four years as an associate producer at a puzzle-game studio; two years running the main title's weekly content-drop calendar; the release checklist QA still uses; presenting monthly retention numbers to the studio head. Close with why this role, in your own reasons. Answer slot: if asked about platform, say which platform your title was on | The opener is scored on economy. F3's rewording lives here |
| G2 | "What live event in a mobile game has caught your eye lately?" | CO | [generic] | Selection scaffold: pick one you actually played, say what it did well and one thing you'd change, and tie it to the calendar or the review. If nothing comes to mind, say so and talk about one you know well | The JD's live-events and mobile lines asked casually. Still scored |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | B1, A3, E1 |
| Coordinate design, art, engineering and community | A1, F1, F2, B1 follow-up 1 |
| Own the post-event review and its KPIs | A4, D2, D3 |
| Manage the release checklist with QA | A2, C3, E2, F2 |
| 3+ years producing live-service games or apps | G1, B4 |
| Experience running a content calendar | B1, D2, E1 |
| Comfortable with player-retention metrics | D1, D3 |
| Clear written communication | A5, E3, plus the F8 answer slot if asked directly |

---

## Values cheat sheet

The loop documents a values conversation, and the values come from Saltmarsh's own page.

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries one. Use the selection scaffold in C1, and its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries one. Use the selection scaffold in C2, and its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better | F7: "Wrote the release checklist our QA team still uses". See C3 for its answer slot |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live ops from QA. What did that teach you about what makes a producer good to work with?" | Tied to his own career path, and it turns the hour into a peer conversation |
| R2 | "Your GDC talk argued a team is judged by how often patch notes match what shipped. How does the team track that today?" | It shows you researched him, not just the company. Only ask it if you're comfortable with what the talk says |
| R3 | "With the shared calendar starting in February, what does this role own before the switch, and what after?" | It shows you read about Larkspur, and it tells you what your first months actually look like |
| R4 | "Moving from per-title event teams to one live-ops group: what's been hardest so far?" | It reads as diligence about the change you'd be joining |
| R5 | "Where does season-pass content sit between this role and monetization or design?" | It shows you see your own F9 gap and want to know its boundaries. It's honest, not defensive |
| R6 | "What would a first post-event review from me need to show for you to call it good?" | It lets him define the bar for the JD's KPI line, and you learn it before day one |

---

## Prohibited claims

This pack does not coach the following claims. If you reach for one under pressure, use the honest form instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a calendar, across two or more titles | Inflated form of F1 | F1's quote at its own scope. Your material says one title's content-drop calendar |
| Led a team, or managed people | A negative you stated: "Never led a team" | "I haven't led a team." No slot |
| Worked on in-app purchases, monetization or a season pass | A negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." No slot |
| Owned post-event reviews or their KPIs | Inflated form of F5 | F5's quote at its own scope. Your material says presenting monthly retention numbers. D2's slot stays inside what was yours |
| Analysed or built the retention numbers | Inflated form of F5 and F6 (presented changing into analysed) | "Presented the monthly retention numbers to the studio head." D1's slot covers what part was yours |
| Managed the release process, or ran QA | Inflated form of F7 | "Wrote the release checklist our QA team still uses." F7's slot covers working through it with QA |
| Producer or senior producer as your past title | Inflated form of F3 | "4 years as an associate producer at a puzzle-game studio" |

---

## Sources

- **Provided:** the JD and your background, both from your message.
- Search: "Saltmarsh Games values" returned https://saltmarshgames.com/values
- Fetch: https://saltmarshgames.com/values returned the three values and their definitions
- Search: "Saltmarsh Games interview process producer" returned https://saltmarshgames.com/careers/interviewing
- Fetch: https://saltmarshgames.com/careers/interviewing returned the loop: a recruiter call, then the 60-minute Outage Hour with the hiring manager (tabletop, then values), with no take-home
- Search: "Saltmarsh Games mobile studio news 2026" returned https://saltmarshgames.com/news/project-larkspur (September 2026)
- Search: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only, not fetched)
- No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet, the C bank, A2, E3 and F2 |
| 2. Saltmarsh interview process | yes | Loop established: one session with the hiring manager, tabletop then values. Persona weights, and the A and C banks |
| 3. Saltmarsh strategy or recent news | yes | Project Larkspur: A3, B2, F9, R3, R4 and R5 |
| 4. Tobias Wrenfield, Saltmarsh | yes | Interviewer read, A5, R1 and R2. Search snippet only, because the fetch budget went on targets 1 and 2 |
| 5. Representative Live Ops Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Saltmarsh and the two titles, a full read of Tobias's talk rather than a snippet, and recent org context on the move to one live-ops group
- **Notes from your recruiter call** → any focus areas for the tabletop, and confirmation that Tobias is the hiring manager
- **Your answers to the F4, F5 and F7 slots** (which teams you worked with on drops, whether you built the retention numbers, whether you ran the checklist with QA) → B1, D1, D2, E2 and A4 move from slots to story-mapped guidance
- **Your title's platform** → F3 and G1 close the "mobile" question
- **An inspectable artifact**, such as a sanitised copy of the release checklist or a page of the content calendar → F2 and F7 rise from medium toward high confidence
- **A tuesday-dossier.md** → an evidence-derived highest-ROI objection and a confirmed prohibited-claims list, instead of ones built from your message alone
