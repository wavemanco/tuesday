Reading the module's reference rules (personas, question rubric, research and output template) before I build your three-round pack.
I've written one prep pack covering all three rounds. I built it from the role summary and the background in your message. Searches for Larkfield's values, interview process and recent news were all blocked in this session, so I couldn't look up any company-specific facts.

**The question to rehearse most is A1, the hardware roadmap.** You told me you've never owned a hardware-adjacent roadmap, and the job asks you to plan the roadmap with the hardware team. The Director will likely ask about it Tuesday, the product manager again Thursday (D3), and the VP Monday under time pressure (K1). The pack gives you one honest line to use in all three rounds: "I haven't owned a hardware-adjacent roadmap." You follow it with a plan for learning, and you never stretch it.

How the pack is organised:
- **Shared across all rounds:**
  - how each part of the job description matches your background, with the gaps marked;
  - a list of claims not to make, such as "hired 40 engineers" (it was 40 *interviews*) or "cut on-call by 60%" (your words were that it dropped 60% *after* the reliability quarter);
  - a table showing which questions cover each requirement.
- **Tuesday, Director (10 questions):** weighted toward probing your gaps and live problems, like your first 90 days or a slipped hardware release.
- **Thursday panel (11 questions):** the staff engineers will likely pick apart the 60% and the 40. The product manager will test your one story about roadmap pressure.
- **Monday, VP (8 questions):** weighted toward leadership philosophy, as the recruiter described. There's no cheat sheet of Larkfield's own values, because I couldn't look them up and wouldn't quote them from memory.
- **Questions to ask them:** each round has at least five. Ask the Director the first Tuesday one: whether the two squads already have their own leads. The answer tells you whether "I've never managed managers" comes up at all.

If you can, ask the recruiter whether the Thursday panel includes a design exercise or presentation. If it does, I'll add a section for it.

Files are in the working directory:
- Larkfield-Systems_engineering-manager_interview_pack.md

I can play the Director and run A1 with you live, with follow-up questions, then give feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the full job posting and your CV? Right now the pack works from a three-line summary and four sentences about you, and more of your own material would replace several answer outlines with your real stories.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf. **Mode:** loop, three scheduled rounds.

| Round | When | Length | Who | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | 45 min | Director of Engineering | Hiring manager, your would-be boss |
| 2 | The Thursday after | 60 min | Two staff engineers and a product manager | Panel: peers plus your roadmap partner |
| 3 | The following Monday | 30 min | VP Engineering | Skip-level; the recruiter called it "values and leadership philosophy" |

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it scores. Each round has its own persona weights, bank and reverse questions; the fit snapshot and the prohibited list are shared, because all three rounds will compare notes on the same story.
- Type key: **VAL** values and behaviour · **EXP** deep-dive on your own experience · **JD** the stated job · **CO** company and strategy knowledge · **CASE** a live problem from the role.
- Question IDs go by persona letter. F is skipped in the banks so it never clashes with the fit-snapshot rows F1–F8.
- **An answer slot** is an instruction for the interview. It names a probe you're likely to get and gives two honest branches. Fill it only from what you actually did.
- The guidance is scaffolding, not a script. Say it in your own words.
- **The rule across all three rounds is consistency.** Your answer on hardware (A1) and your "weakest area" answer (A4) will get compared after Thursday and again after Monday. Give the same honest answer every time.

## Fit snapshot (shared)

Requirements quote the role text you pasted. Evidence quotes your message word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material describes one team of six, not two squads, and the words stay there: "I've been a team lead for three years, of a team of six." Answer slot: the two-squad line makes a probe on running more than one team likely. If you have ever coordinated work across another team, say how, in your own words. If you haven't, say so plainly and stay with the team of six. Your material doesn't say whether these squads have their own leads (see reverse question R1-1). If they do, your words are: "I haven't managed managers." |
| F2 | "building device-management services" — role text | none given | none | [grounded] | discovery | Your material does not show device-management or IoT work. Strong evidence would be services you ran that track, configure or update hardware in the field. Answer slot: if any of your work touched device or fleet management, say what it was, in your own words. If none did, say so plainly and describe how you would ramp up |
| F3 | "own delivery" — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Keep the quote's own scope and its "after": "I pushed a reliability quarter through against roadmap pressure, and afterwards my team's on-call burden dropped 60%." It is a delivery decision, not a record of delivery ownership. Answer slot: "own delivery" makes a probe on what happened to roadmap commitments during that quarter likely. If they were moved or renegotiated, say what happened and which part was yours. If nothing was moved, or it wasn't yours, say so plainly and stay with the quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role text | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | You run the loop, and the 40 counts interviews, not hires. Keep that number attached to "interviews". Answer slot: "own hiring" makes a probe on hire decisions and headcount likely. If any hire decisions or headcount plans were yours, say which, in your own words. If not, say so plainly and stay with running the loop |
| F5 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Being a team lead touches growth but doesn't show it. Answer slot: "growth for 11 engineers" makes a probe on how you have grown engineers likely. If you have helped someone on your team grow, say what you did, in your own words. If you haven't, say so plainly and say what you would do first |
| F6 | "partner with hardware and product on roadmap" (a hardware-adjacent roadmap) — role text | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You have stated this gap, and wording can't close it. Your words: "I haven't owned a hardware-adjacent roadmap." Then say how you would learn it, as a plan and never as a past. Never claim roadmap work with hardware, and add nothing to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" (working with a hardware team at all) — role text | none given | none | [grounded] | discovery | Your stated negative is about owning a roadmap. Your material says nothing either way about working alongside a hardware team. Answer slot: if you have worked with a hardware team in any form, say how, in your own words. If you haven't, say so plainly and return to the plan in F6 |
| F8 | "partner with hardware and product on roadmap" (the product part) — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | "Against roadmap pressure" touches roadmap partnership without showing who you negotiated with. Answer slot: if product was on the other side of that quarter, say how the conversation went and which part was yours. If the pressure came from elsewhere, or there was no conversation with product, say so plainly and stay with the quarter |

No row is a gate. The role text sets no location, schedule, pay or credential terms.

## Prohibited claims (shared)

Built from the snapshot before any bank was written. No cell in this pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated, F1 | "I haven't managed managers." No slot |
| Has owned or led a hardware-adjacent roadmap | A negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot |
| Has led two teams, or more than six people | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material describes one team of six. A2's slot stays inside that |
| Hired about 40 engineers, or owned hiring decisions | Inflated form of F4 | F4's quote at its own scope: you run the loop, and about 40 was interviews. E2's slot asks only which decisions were yours |
| The reliability quarter cut on-call by 60% (a causal claim) | Inflated form of F3, on the logical-form axis | F3's quote: the burden "dropped 60% after" the quarter. E1 and K2 rehearse what you can and can't say about cause |
| Designed or built the reliability work yourself | Inflated form of F3, on the verb axis | F3's quote: you "pushed a reliability quarter through". E3's slot asks which parts of the engineering were yours |

Device-management experience isn't on this list. Your material is silent on it rather than stretched, so it is handled as the answer slot in F2.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "Lead two squads" (F1) | A2, B1, D1 |
| "building device-management services" (F2) | A3, H1, L1 |
| "own delivery" (F3) | B2, B3, D3, J2 |
| hiring for 11 engineers (F4) | B4, E2, J3 |
| growth for 11 engineers (F5) | D4, J1 |
| hardware-adjacent roadmap (F6) | A1, A4, K1 |
| working with hardware (F7) | A1, B2, D3 |
| product roadmap partnership (F8) | D2, D3 |
| Headline figure "60%" | E1, K2 |
| Figure "about 40 interviews" | E2 |

**The highest-ROI prep across the whole loop is A1, the hardware-adjacent roadmap.** The Director asks it Tuesday, the PM asks it again in D3, and the VP checks it in K1. It is aimed at F6, the one gap you have stated yourself. Rehearse it until it bores you.

---

# Round 1 — Tuesday, Director of Engineering (45 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why you, given the gaps?" Probes F1, F2 and F6 | High. The hiring-manager prior puts Case and Skeptic on top, and the gaps you named are exactly what a would-be boss has to de-risk | Rehearse A1 until it's boring. Use bridges only from your quotes, and give a ramp plan as a plan |
| Case / Strategist | Live problems from their actual roadmap: first 90 days, a slipped dependency | High. Same prior. 45 minutes leaves room for one or two live cases | Clarify, then objective, approach, metrics, risks. Think aloud and challenge one premise |
| Conversational | Opening "walk me through it", why leave, why here | Low. It's an opener, but it is still scored | A pre-scripted 90-second arc built from your quotes only |

No interviewer profile was supplied, so the weights come from the round type alone.

## Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't owned a hardware-adjacent roadmap, and ours is tied to hardware. How do you partner with a hardware team here?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI rehearsal in the pack.** State the limit before they push: "I haven't owned a hardware-adjacent roadmap." Then give a plan, said as a plan: what you'd want to learn first from the hardware leads about their constraints, and how you'd find out where software usually waits on hardware here. Answer slot from F7: if you have worked with a hardware team in any form, say how, in your own words. If you haven't, say so plainly and go back to the plan. Expected follow-ups: (1) "So what would you get wrong in your first quarter?" Name one thing you'd expect to learn slowly, and keep it as a guess about the future. (2) "Why not hire someone who has done it?" Hold. Don't add experience; say what you'd do to close the gap. Concede exactly what's true: "That's a real gap. I'm not going to talk around it." | F6 is the one gap you stated yourself, and it sits in the role's partnership line, so a would-be boss will ask it. It's JD-typed because it scores the stated requirement. Deepest rehearsal, as the rubric requires for the most predictable objection |
| A2 | "You've led six. This is eleven across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | Start from the quote's scope: three years leading a team of six. Answer slot from F1: if you have coordinated work across another team, say how, in your own words. If you haven't, say so plainly. Then say what you'd expect to change, as reasoning about the future: less hands-on time, and a structure for two squads. If they ask whether the squads have leads and they do, your words are: "I haven't managed managers." Then ask R1-1 | F1 is the scope gap between the role and your current team, so it will come up. JD because it tests the "two squads" line |
| A3 | "Your background is payments. What do you actually know about device management?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot from F2: if any of your work touched device or fleet management, say what, in your own words. If none did, say so plainly, and say how you'd ramp up (reading, sitting with the squads, shadowing on-call) as a plan. Don't borrow IoT vocabulary to describe your payments work | F2 is silent in your material, and the domain line is the job's first noun. JD-typed |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name F6 again, in the same words as A1: "I haven't owned a hardware-adjacent roadmap." Then one line of plan. Don't swap in a softer weakness. The panel and the VP will hear about this answer | It's the Skeptic's standard stem. A consistent honest answer here is worth more than a clever one. JD |

## Bank B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's your first 90 days with two squads. What do you need to know first?" | CASE | [generic] | Clarify first: the squads' current shape, their on-call load, the roadmap commitments in flight, and the hardware dependencies. Structure the 90 days as listen, then commit to a small number of changes, with how you'd measure them. Growth of each person belongs in the "listen" part. The question needs no claim about your past, so don't make one | It's a live problem on the "Lead two squads" and growth lines (F1, F5). Generic because it's a pattern, not a fact about Larkfield |
| B2 | "A hardware release slips three weeks. Your service was due to ship against it, and product wants the date held. What do you do?" | CASE | [generic] | Clarify what is actually blocked and what can ship independently. Lay out options with their cost to customers, decide with product rather than around them, and say what you'd communicate and to whom. Challenge one premise: whether "the date" is a customer date or an internal one. No claim about your past | It tests the delivery line and the hardware-and-product partnership line (F3, F7, F8) as a live decision. Generic because no research on Larkfield's roadmap could run |
| B3 | "On-call is climbing on one squad and the roadmap is full. How do you decide whether to stop for reliability?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision first: what you'd measure, what the threshold is, and who you'd bring along. Then offer your one real data point, at its own scope: you pushed a reliability quarter through against roadmap pressure, and afterwards your team's on-call burden dropped 60%. Keep "afterwards". Don't say "because" | It's a live case where F3 is your strongest material. CASE delivery with an EXP tail |
| B4 | "You get three open roles across the two squads. How do you run that hiring?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure it: what each squad is missing, the order to hire in, how the loop is designed, and who decides. Bring in F4 at its scope: you run the hiring loop for backend roles, about 40 interviews last year. Answer slot: if any hire decisions or headcount plans were yours, say which. If not, say so plainly and stay with the loop | It's the hiring line (F4) turned into a decision. CASE because it's live, and the quote anchors it |

## Bank C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with three beats, each at its quote's own scope: nine years in engineering and three as lead of a team of six, now at a payments company; running the backend hiring loop, about 40 interviews last year; the reliability quarter and what came after it. Close with why this role, in your own words. Your material doesn't give your reason, so don't borrow one | The opener is still scored. This keeps the arc to what F1, F3 and F4 carry |
| C2 | "Why leave payments for industrial IoT?" | EXP | [generic] | Your reason, in your own words. It is the one answer only you can give. Say it the same way on Thursday (H2) and Monday | Motivation consistency gets checked across rounds. Generic because your material gives no reason |

## Reverse questions — Tuesday

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Do the two squads have their own tech leads or managers today, and what would my relationship to them be?" | It settles F1 directly. If the answer is yes, you've already rehearsed the honest line |
| R1-2 | "Where does device-management delivery usually get squeezed by the hardware schedule?" | It shows you've thought about F7 seriously, and the answer feeds your Thursday prep |
| R1-3 | "What would you need to see at 90 days to know this hire was right?" | It turns the would-be boss's private scorecard into a shared one |
| R1-4 | "Is the hiring for the 11 backfill, growth, or both?" | It tells you whether F4's hiring work is the job or a side task |
| R1-5 | "How are roadmap decisions split between you, product and this role today?" | It locates the delivery authority that "own delivery" implies |
| R1-6 | "What's on-call like for these services right now?" | It invites your F3 story naturally, without you forcing it in |

---

# Round 2 — Thursday, panel: two staff engineers and a PM (60 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Staff engineers: "where's the line between your call and ours?" PM: "what do I get from you?" | High. The peer prior covers the staff engineers. The PM is the role's named roadmap partner, so I tilted the PM toward Peer Evaluator as well. That's a judgment call; adjust it if you know otherwise | Frame answers as reciprocity. Propose seam principles rather than claiming to know the seam |
| Data-Driven Prober | Staff engineers taking apart the 60% and the 40 | Medium-high. It's the second persona in the peer prior, and your two figures are magnets for it | Know how each figure was counted, or say you don't. Name your weakest assumption first |
| Values / Behavioral | PM: "tell me about a time…" | Medium. It's the cross-functional prior for the PM | Behavioural stories from your quotes, with an honest branch where none fits |
| Conversational | Panel warm-up, and "what are you playing with" | Low. A 60-minute panel usually has a warm-up | Same arc as C1. Treat a casual question on IoT as scored |

## Bank D — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "As staff engineers we set technical direction. Where's the line between your call and ours?" | JD | [generic] | Propose principles rather than a line: they own the technical decision, you own priority, staffing and delivery risk, and you say how disagreements get escalated. Ask what works today before proposing changes | Staff engineers are pricing how a new manager affects their own work (F1's two squads). JD because it tests "Lead two squads" |
| D2 | "Tell me about a time you disagreed with product on priorities." (PM) | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3, with only the quote's beats: a reliability quarter, pushed through, against roadmap pressure, and the drop in on-call afterwards. Answer slot from F8: the role's product-partnership line makes a probe on who you negotiated with likely. If product was on the other side, say how that went and what part was yours. If the pressure came from elsewhere or there was no conversation with product, say so plainly and tell the story as what it was | The PM will test F8's partnership through the one story that touches it. EXP, themed by the role's product line |
| D3 | "Hardware slips, and I've promised customers a date. What do you need from me, and what do I get from you?" (PM) | CASE | [generic] | Reciprocity first. What they get: early warning, options with their costs, and a straight answer on what can ship. What you need: the actual customer commitment and a decision partner. If they push on hardware experience, give A1's line word for word: "I haven't owned a hardware-adjacent roadmap" | It's the PM's version of A1 (F6, F7, F8). Answers on this get compared between rounds |
| D4 | "How do you grow an engineer toward staff level?" (staff engineers) | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot from F5: if you have helped someone on your team grow, say what you did, in your own words. If you haven't, say so plainly and say what you'd do first: ask them what staff means here, then find real scope for them. Asking the staff engineers what helped them is fair | F5's growth line, put by the people who embody it. JD |

## Bank E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer each slot in your own words. How the 60% was counted: if you don't know, say so. What it's sensitive to. The assumption behind it you'd defend least, which you should name before they do. Which part of the result was yours. Keep the quote's "after". Whether anything else changed during that period is a question you answer honestly, not one you avoid | It's the headline figure (F3), and staff engineers will go two levels deep on it. EXP |
| E2 | "Tell me about the hiring loop you run. About 40 interviews last year?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Use the quote's scope: you run the loop for backend roles, about 40 interviews last year. The figure's slots: how the 40 was counted, and which part of the loop is yours. Answer slot from F4: "own hiring" makes a probe on hire decisions likely. If any were yours, say how you made them. If not, say so plainly and stay with running the loop | The second figure (F4), and the panel will want to know how you'd hire onto their squads. EXP |
| E3 | "What was in the reliability quarter, technically?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: staff engineers will ask what the work was and who did it. Say what it contained and which parts of the engineering were yours, in your own words. If your part was getting the quarter through rather than building it, say exactly that. "I pushed it through" is the claim your quote makes | It's the verb-axis risk in F3. Engineers will separate the advocacy from the build |

## Bank G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | If this fits, tell F3 with only its beats: a reliability quarter, pushed through against roadmap pressure, and what came after. Your quote doesn't say the pressure came from leadership. If it didn't, say so plainly and tell it as what it was. If no story of yours fits, say so plainly and give the nearest thing your material does carry | It's a stem from the persona model. F3 is your only quoted story with a stake in it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold. Pick a time with a named customer impact, a metric you let slip on purpose, and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | No quote carries a customer story, so this is a scaffold rather than a story map |

## Bank H — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What are you actually playing with in IoT these days?" | JD | [generic] | Answer slot from F2: if you've been reading, building or experimenting with anything in device management, say what, in your own words. If not, say so plainly and say what you'd start with. Don't invent a side project | A casual question on the job's domain is still scored (F2) |
| H2 | "What made you want to move into a hardware company?" | EXP | [generic] | The same reason as C2, in the same words. Panels compare notes | Motivation consistency |

## Reverse questions — Thursday

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What could a new manager do in their first month that would actually help your squads?" (staff) | The reciprocity question, which shows you're pricing their load, not just yours |
| R2-2 | "Where do you two disagree with each other technically right now?" (staff) | It shows the real seams D1 is about, and staff engineers like being asked |
| R2-3 | "What's the hardest roadmap trade-off you've made with engineering in the last year?" (PM) | It's the PM's side of D2 and D3, and the answer is useful to you |
| R2-4 | "How early do you hear about hardware slips today?" (PM) | It goes at F7 and F8 directly. The answer tells you how much of the job is coordination |
| R2-5 | "What does on-call look like for you two?" (staff) | It sets up F3 honestly, and tells you about the job |

---

# Round 3 — Monday, VP Engineering (30 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" and behavioural stories | High. The recruiter's words, "values and leadership philosophy", make this a documented values-style round, which outranks the skip-level prior | Philosophy stated in a line, then proven with one quoted story |
| Pressure | Time-boxed "why you", and "how much was you" | Medium. Skip-level prior, and 30 minutes forces short answers | Pause, restate the question, hold through two follow-ups, then concede exactly what's true |
| Case / Strategist | Altitude: where device-management platforms go wrong | Low-medium. Skip-level prior, squeezed by the round's stated focus | Short structured answers. Labelled generic, because no Larkfield strategy research could run |

**Values cheat sheet: not included.** This round is values-style, but Larkfield's published values aren't in hand. The search was refused, so no value names appear here. Names quoted from memory would be worse than none. See the upgrade menu.

## Bank J — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | One sentence of philosophy, in your own words and not a slogan. Then prove it with one story at its quote's scope: either the reliability quarter (F3) or running the hiring loop (F4). How you grow people (F5) is an answer slot. If you have done it, say what you did; if not, say what you would do, as a plan | This is the round's stated subject, taken from the recruiter's words. VAL |
| J2 | "How do you decide when to push back on the roadmap?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give your principle first, then F3 with only its beats. Answer slot from F3: if roadmap commitments were moved during that quarter, say what happened and which part was yours. If not, say so plainly. Keep "afterwards", not "because" | Leadership philosophy applied to "own delivery" (F3) |
| J3 | "How do you think about hiring? What's your bar, and who sets it?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Your bar, in your own words. Then F4 at its scope: you run the loop for backend roles. Answer slot: if the bar or the hire decisions were yours to set, say how. If not, say who set them and what you did within that | It's hiring philosophy (F4), which a VP owns across teams |
| J4 | "Tell me about a time you got something wrong as a lead." | VAL | [generic] | A selection scaffold. Pick a real mistake with a named cost, what you changed afterwards, and evidence the change held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry. "I can't think of one" will cost you more than a small honest one | No quote carries a mistake, so this is a scaffold. Leadership-philosophy rounds commonly ask this |

## Bank K — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you over someone who's already run a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause first. Concede first, in A1's words: "I haven't owned a hardware-adjacent roadmap." Then hold on what your quotes carry: the reliability quarter and running the hiring loop, each at its scope. Hold through two follow-ups by returning to those, never by adding to them | It's A1 under time pressure (F6). The VP will have read Tuesday's and Thursday's notes |
| K2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold on the claim your quote makes: you pushed the quarter through, against pressure. Concede specifically: the drop is your team's, it came after the quarter, and say which parts of the engineering were or weren't yours (E3's slot). Don't claim cause you can't show | It's a persona stem aimed at F3's attribution |

## Bank L — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Where does a device-management platform go wrong as a company grows?" | CO | [generic] | Think aloud and keep it structured: reliability at fleet scale, coupling to hardware release cycles, and on-call load. Say plainly that you're reasoning from outside the domain. No claim about Larkfield, and no claim about your past | Strategy altitude on F2's domain. Generic because no Larkfield research could run |
| L2 | "You get two squads and a mandate to cut operational load. How do you measure progress over two quarters?" | CASE | [generic] | Clarify what "operational load" means here, choose two or three measures, set a baseline, and decide what you'd trade off. Answer it as a live problem | It links F3's territory to a live decision at a VP's altitude |

## Reverse questions — Monday

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "Is there a written set of values or engineering principles that managers here are held to?" | It shows you take the round's own theme seriously, and the answer gives you what this pack couldn't fetch |
| R3-2 | "What separates the engineering managers who thrive here from those who don't?" | It asks the VP to describe the bar directly |
| R3-3 | "How do you expect this role to grow? Would it lead managers eventually?" | It brings F1 into the open on your terms |
| R3-4 | "Where does engineering most need to get better at working with hardware over the next year?" | It's an altitude question on F7, and frames your gap as a shared priority |
| R3-5 | "What's one thing you'd want me to do differently from the last person in a role like this?" | It's direct and useful, and VPs remember it |

---

## Sources

- **Provided:** your message (the role text, the three rounds, your background, and the recruiter's description of round 3).
- **Searches sent:** `Larkfield Systems values` was refused. `Larkfield Systems interview process engineering manager` was refused. `Larkfield Systems industrial IoT news` was refused. No fetches.
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have provided the Monday values cheat sheet and value-themed J questions |
| 2. `Larkfield Systems interview process` | unavailable | The search was refused. Your own words already establish the three rounds, so the persona weights stand. It would have added documented round formats, such as whether the panel includes a design exercise |
| 3. `Larkfield Systems` strategy / recent news | unavailable | The search was refused. It would have made L1, B2 and D3 Larkfield-specific rather than generic |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. The interviewer read is omitted |
| 5. Representative EM JD | skipped | The role text you supplied fixes the fit snapshot and the JD-tagged rows |

## Upgrade menu

- **Allow web search in this session** → Larkfield's published values for a Monday cheat sheet mapped to your stories, current strategy so L1, B2 and D3 stop being generic, and any published loop detail
- **The full job posting** → requirements the summary leaves out get rows and questions, and the coverage table becomes complete
- **Your CV** → more quotes to work from. F2, F5, F7 and F8 may move out of `discovery`
- **Interviewer names** → personas assigned per panel member, persona weights read from their public profiles, and a reverse question tied to each person's career path
- **The recruiter's notes on the panel format** → if there's a design exercise or presentation, a build section for it
- **Your answers to the answer slots, said outside a drill** (how the 60% was counted, who applied the roadmap pressure, which hire decisions were yours, whether you've worked with hardware) → A1, A3, D2, D4, E1, E2, E3, J2, J3 and K2 become fully story-mapped
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes, once search is allowed) → a strategy brief and recent org context, for sharper CO and CASE questions on Monday
- **A `tuesday-dossier.md`** → verified evidence and an evidence-derived top objection. Useful, but not needed
