No dossier present. Reading the references.
I've built your prep pack for Ashgrove: `/var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-8-denied-775597d1/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`

It covers all three rounds on 5 December, using the recruiter's description of each. The four sentences you gave me about your background are the only material it uses about your past.

- **Most important to rehearse (B1):** the Head of Member Services is likely to point out that you've handled one branch's complaints log but have never worked in a contact centre, while this role covers every branch and the contact centre. The pack has you describe exactly what you did, say the contact-centre gap yourself before you're asked, and set out a plan for learning that side. It rehearses this through two follow-up questions.
- **Panel round:** there's a four-value cheat sheet, plus a plan for the 20-minute case with three positions, each with a concession you should make. The 20-minute plan suggests how to split the time and what to avoid: escalating straight to head office, or offering compensation before you know the facts. It also includes a practice question on how branch closures sit alongside "Neighbours, Not Numbers".
- **Things only you can fill in:** what your monthly spreadsheet tracks and whether it's in Excel, whether your branch's formal complaints counted as regulated, and whether you've presented at regional level. The pack doesn't guess at any of these; it gives you an honest way to answer either way. A list at the end of the pack, the upgrade menu, shows which sections improve if you tell me.
- **Research:** I didn't run any searches. Your pasted values, the recruiter's email, the job description and your summary of the July 2026 strategy brief already covered what searching would have found.

If you'd like a mock run, I can play the sceptical hiring manager on B1, the question the pack names as most worth rehearsing. I can also save a `tuesday-dossier.md` file recording the gaps this prep found, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 5 December 2026, as the recruiter's email describes them
- Round 1: 30 minutes with the recruiter
- Round 2: 45 minutes with the Head of Member Services, your future manager, mostly behavioural
- Round 3: 60 minutes with a panel of two branch managers. It includes a 20-minute complaint-escalation case, and it is the values round, scored against the four values

**Interviewers:** not assigned yet, so this pack works from roles only.
**Highest-ROI prep:** B1, the scope objection (one branch's log against an organisation-wide process that includes the contact centre).

---

## How to use this pack

- **Personas** describe how a question is asked: the interviewer's style and register. **Types** describe what the answer is scored on. You need to rehearse both.
- Guidance is scaffolding, not a script. Say every answer in your own words.
- An **answer slot** is an instruction for the interview itself, not a question for you to answer here. It always has an honest branch, such as "if not, say so plainly". Taking that branch is a limit, not a failure.
- The question IDs run A (Round 1), B (Round 2) and C (Round 3).

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you've said about your work holds up when probed, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on Ashgrove's strategy and context |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` means traceable to your message, the JD, the values, the recruiter's email or the strategy brief. `[inferred]` means the pack derived it and names the derivation. `[generic]` means a role-family pattern that makes no claim about Ashgrove or about you.

---

## Fit snapshot (shared across all rounds)

Every statement in this pack about your past draws on the sentences quoted below, all from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages likely, from a complaint arriving to it being closed. If any stage of that log was yours to decide, say which one and how you decided, in your own words. If none was, say so plainly and stay with the log you handled. Then describe how you would approach a multi-site process, framed as a plan and never as a past |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I've never worked in a contact centre." Then say how you would learn that side, framed as a plan for your first months and never as a past. Never claim contact-centre work, and add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Monthly complaints reporting is in your material. What the sheet tracks is not. Lead with the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes and resolution times, say so and say how each is counted. If it tracks other things, say what they are. If you don't know how a figure is counted, say that. Never describe a column the sheet doesn't have |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material says you trained new tellers on a script. It doesn't say you coached supervisors. Words: "I trained new tellers on our escalation script," and "for the last three years I've been a branch supervisor." Let the panel draw its own inference about you knowing the supervisor's seat, and don't state it for them. Answer slot: expect a probe on coaching peers. If you have coached other supervisors, or supervisors brought their escalations to you, say how, in your own words. If not, say so plainly and stay with training tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if you have worked with a digital team or on any self-service change, say what it was and what your part was. If you haven't, say so plainly, then say how you would approach it, framed as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. Say it in your own terms: six years in retail banking, the last three as a branch supervisor. Don't relabel your history in the JD's words ("customer operations"). Let the interviewer make that mapping |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material says "formal", not "regulated". The step from one to the other is the pack's inference, so don't make it for yourself. Answer slot: if those complaints fell under a regulator's rules, such as response deadlines or required content in the final reply, name the rules and say what you did to meet them, in your own words. If they didn't, or you don't know which rules applied, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD, above regional level | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated this gap yourself. Words: "I've never presented to anyone above regional level." Then describe how you would prepare to present the monthly report, framed as a plan. Never claim senior-level presenting |
| F9 | "confident presenting to senior leaders" — JD, at regional level | "I've never presented to anyone above regional level" — your message | low | [grounded] | discovery | Your sentence doesn't say whether you have presented at regional level. Answer slot: if you have, say what you presented and to whom. If you haven't, say so plainly and use F8's words |
| F10 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says spreadsheet, not Excel. Answer slot: if it is in Excel, say so and say which parts you built yourself. If it is in another tool, name the tool. Never list functions you haven't used |

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

**What is grounded:** the recruiter's email says the Round 3 panel is "60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation", and that "they score against the four values". The scenario itself hasn't been shared, and the email names no required close.

**What you can bring from your own material** (use it only if the case invites it):
- F1: "I handled the branch's formal complaints log"
- F4: "trained new tellers on our escalation script"
- F3: "I built the monthly complaints spreadsheet our regional manager uses"

**How to spend the 20 minutes** `[generic]`: about 2 minutes clarifying (what the member wants, what has happened so far, who has touched the complaint, any deadline). About 3 minutes laying out your structure aloud. About 10 minutes working through it. About 3 minutes on the wrap-up: the member outcome, what changes so it doesn't recur, and how it shows up in the monthly report. Leave room for the panel's questions.

| Thesis | Value it carries | Mandatory concession |
|---|---|---|
| T1. One named person owns the complaint from first contact to final response, and the member always knows who that is | Own the Fix | Owning it doesn't mean doing every step. The contact centre or a specialist team may hold parts of it, and the owner's job is to keep hold until it's solved |
| T2. Explain the outcome once, in plain words, and check it landed | Plain Words | A regulated final response may need set content. Say you'd check what Ashgrove's process requires rather than promising to strip it out |
| T3. Fix the member's case first, then fix the pattern: log it, put it in the monthly report, and brief the supervisor (and the digital team if a self-service journey caused it) | Members First, Always; Own the Fix | Root-cause work never delays the member's fix, and one case isn't yet a pattern |

**Differentiation:** the consensus answer is "apologise, escalate, resolve, follow up", and any prepared candidate will give it. Your edge is the role's own job: leave the branch supervisor more capable instead of taking the case away from them, and connect the single case to the monthly reporting line in the JD. Branch managers scoring "Neighbours, Not Numbers" will notice whether the branch keeps the relationship.

**Anti-pick:** don't escalate reflexively to head office, and don't offer compensation before you have the facts. Both are easy ways to look decisive, but they take ownership away from the branch and commit to a fix before the problem is understood.

**Close:** none was requested. End on the member outcome, then the one change that stops it recurring.

---

## Grounding brief

From the July 2026 strategy brief, as you summarised it to me, and the JD. I haven't seen the brief's full text.

| Item | What it says | Provenance | Why it matters in these rounds |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | The JD's self-service line sits inside this. Use the figure in B10 and in reverse questions |
| Branch consolidation | Eight branches into five hubs over 2027 | [grounded] | Branch managers are on your panel, and this collides with "Neighbours, Not Numbers". See C5 and B11 |
| New product | Small-business lending product launches in Q1 2027 | [grounded] | A reverse-question opener on new complaint types (R3) |
| Competition | The main competitive pressure is app-only banks | [grounded] | Members unhappy with how a complaint is handled have an easy alternative. Use it as a case framing in C6 |
| Size and model | Member-owned, about 900 staff | [grounded] | Say "members", never "customers". The values use "member" throughout |
| Implication | During a channel shift or a branch closure, complaints may move between channels or rise. This is a pattern, not a fact about Ashgrove | [generic] | Offer it as a hypothesis to check against their data, never as a prediction |

---

## Round 1: recruiter screen (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | A friendly walk through your background, motivation and logistics | High. It's the recruiter-screen prior, and 30 minutes leaves little time for depth | A pre-scripted 90-second arc (A1). Treat every casual question as scored |
| Skeptic, light | Knockout-style checks against JD lines, asked gently | Medium. Recruiters screen against the stated requirements before passing you on | Short, honest answers that stay at the scope of your own sentences. The deep rehearsal is in Round 2 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | 90 seconds, in this order: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on your escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close on why this role, in your own words (A2) | F6, F1, F4 and F3 together map most closely onto the JD. EXP because the recruiter will check that this arc matches what reaches the manager |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Give your own reason, in your own words. If it's true for you, connect it to one value by its exact name, such as "Own the Fix" ("whoever finds the problem keeps hold of it until it is solved"), and to the JD's end-to-end complaints ownership. Mention member-owned, and say "members" | Motivation consistency is scored in every round. CO because naming a value exactly shows you read the page |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | A standard recruiter-screen logistics check. JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | A standard logistics check. JD for the same reason as A3 |
| A5 | "The role spans branches and the contact centre. How are you with travelling between sites?" | JD | [inferred] | Logistics slot: say plainly which locations and how much travel you can do, in your own words | The JD's "across branches and the contact centre" makes multi-site work likely. That's an inference, because the JD doesn't state travel |
| A6 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your own reason, in your own words, and keep it about what you're moving toward | The reason for leaving is asked in nearly every screen. EXP because it's about your history |
| A7 | "The JD mentions regulated complaints. What's your experience there?" | JD | [inferred] "I handled the branch's formal complaints log" | Open with your quote: "I handled the branch's formal complaints log." Answer slot (F7): if those complaints fell under a regulator's rules, name the rules and say what you did to meet them. If they didn't, or you don't know, say so plainly and stay with the log | F7 is a likely knockout check. `[inferred]` because the link from formal to regulated is the pack's inference |
| A8 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Lead with the quote. Answer slot (F10): if it's in Excel, say so and say which parts you built. If it's another tool, name it | A direct JD line. F10 has evidence close by, so the honest answer is short and strong |
| A9 | "The role covers the contact centre. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre" | Plainly: "I've never worked in a contact centre." Then one sentence of plan: how you would learn it in your first months. Don't over-explain here. B1 is where you rehearse this in depth | F2 is a stated gap. A recruiter may check it to brief the manager, and a calm two-sentence answer here sets up Round 2 |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does the Head of Member Services most need this role to fix in the first six months?" | It tells you what Round 2 will probe, so you can aim your B answers |
| "Today, is complaint handling run as one process across branches and the contact centre, or separately?" | It scopes F1 and F2 before you meet the manager |
| "For the 20-minute case, will I get the scenario on the day, and should I prepare or bring anything?" | It's a prep question about a graded part of the loop |
| "How is the move from eight branches to five hubs expected to shape this role in its first year?" | It shows you've read the July brief and links the role to a live change |
| "What happens after 5 December, and when should I expect to hear?" | Logistics you need |

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scope gap, the contact-centre gap and the presenting gap | High. Your future manager is buying capability and pricing the risk, and F1, F2 and F8 are the visible gaps | B1 rehearsed until it's boring. Name the limit before it's asked for, follow it with a concrete plan, and never bluff |
| Values / Behavioural | "Tell me about a time…" questions, STAR-shaped | High. The recruiter said this round is "mostly behavioural", which lifts this persona above the hiring-manager prior | A short list of real stories, with "we" for context and "I" for your contribution. Where no story comes to mind, use the honest branch |
| Data-Driven Prober | Asks what's in the monthly spreadsheet and how it's counted | Medium. Monthly reporting is a JD line this manager will own | Know exactly what the sheet holds, and say when you don't know how a field is counted |
| Case / Strategist | Strategy-shaped questions on the digital shift and the hubs | Lower. The hiring-manager prior puts it high, but "mostly behavioural" pulls it down | Clarify, set the objective, structure, then give metrics and risks. Use the brief's own figures |
| Pressure | Follow-ups inside B1 | Folded into B1 rather than asked separately | Hold through two follow-ups, then concede the specific limit |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns complaints across every branch and the contact centre. You've handled one branch's log, and you've never worked in a contact centre. Why should I trust you with the whole process?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor"; "I built the monthly complaints spreadsheet our regional manager uses" | **Highest-ROI rehearsal in the pack.** Your hold is only what your quotes carry: "For the last three years I've been a branch supervisor. I handled the branch's formal complaints log, and I built the monthly complaints spreadsheet our regional manager uses." Name the limit before they press: "I've never worked in a contact centre." Then a plan, framed as future: how you'd learn the contact-centre side and compare how complaints arrive there and in branches. **Follow-up 1** ("So you've never run a process this size?"): your material doesn't say you have. Answer slot: if any stage of the log's process was yours to set, say which one. If none was, say so plainly and return to the log and the spreadsheet. **Follow-up 2** ("Wouldn't someone from our contact centre be a safer hire?"): don't run down the alternative and don't fold. Return to what your quotes carry and to your plan. Concede only the specific limit, never the core | F1 and F2 are the biggest gaps between your material and the role, and the person asking will own the whole process, so this objection will arrive in some form. JD because it scores the headline requirement |
| B2 | "Tell me about a time a complaint needed escalating. What did you do?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Selection scaffold: pick one real complaint from the log you handled. It needs to cover what the member wanted, what you did at the branch, what you passed on and why, and how it ended, all in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the escalation script you trained tellers on) or how you would handle it | Escalation is a JD theme, and F1 and F4 are where it lives. JD content, behavioural delivery |
| B3 | "Tell me about a time you coached someone through handling an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: training new tellers on your escalation script, told in your own words. Answer slot: the JD says "coach branch supervisors", so expect a probe on coaching peers. If you have coached other supervisors, say how. If not, say so plainly and stay with training tellers | F4 is the bridge for the coaching line. The tellers-to-supervisors step is where it will be probed |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" | Calibrated candour: "I've never presented to anyone above regional level." Then your plan for presenting the monthly report: how you'd prepare and who you'd ask for feedback, framed as future. Answer slot (F9): if you have presented at regional level, say what and to whom. If not, say so plainly | F8 is a stated gap, and choosing it yourself beats having it found. The contact-centre gap is already covered in B1 |
| B5 | "Tell me about a time a complaint showed you a problem bigger than the one member's case." | JD | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint from that log that pointed to something recurring, covering what you noticed, what you did about it, and what changed. If no such time comes to mind, say so plainly, then say how you would use a complaints log to spot a pattern | It tests the JD's reporting purpose through your F1 material |
| B6 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you said it, how it landed, and the relationship afterwards. Your regional manager is one possible audience, if a real time comes to mind. If none does, say so plainly, then say how you would raise it | A persona stem the HM will likely use. Your senior-audience gap (F8) makes candour with seniors worth rehearsing |
| B7 | "When did you put a member ahead of an internal target?" | VAL | [grounded] | Selection scaffold: pick a real decision where the member's outcome and a target pulled apart, covering what you chose, what it cost, and how you'd explain it. If no such time comes to mind, say so plainly and say how you would decide | It mirrors "Members First, Always — we decide from the member's side of the counter." `[grounded]` on the values page |
| B8 | "Walk me through the monthly complaints spreadsheet you built. What's in it, and how is each number counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot (F3): say what the sheet tracks and how each figure is counted, in your own words. Name the field you'd trust least before they ask. If you don't know how a field is counted, say so plainly. Never describe a column it doesn't have | F3 is your strongest evidence for the reporting line, so it's the most likely to be probed. EXP, defend-the-numbers |
| B9 | "Your regional manager uses that spreadsheet. What does it feed into?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if you know of a decision or conversation it fed, say what it was. If you don't know, say so plainly and stay with what the sheet holds | A natural follow-up to B8. It tests whether the sheet is read, which is what the JD's monthly report is for |
| B10 | "We're aiming to move 40% of member service to digital by 2028. What should complaints data tell our digital team?" | CO | [grounded] | CASE delivery: clarify what "member service" covers, then structure it: which complaint types trace back to a self-service step, where members leave digital for a branch or a call, and what you'd measure before and after a change. Answer slot (F5): if you have worked with a digital team, say how. If not, say so plainly, and say what you'd bring to the first meeting | The brief's headline target plus the JD's self-service line. The only strategy-grounded question in this round |
| B11 | "Eight branches become five hubs in 2027. What happens to complaints, and what would you do before it starts?" | CO | [grounded] | Structure: take a baseline now, have a plan per branch during the change, brief the branch supervisors, use plain-words member communication, and watch the monthly figures. Offer "complaints may rise around a closure" as a hypothesis to check, not a prediction. Name the "Neighbours, Not Numbers" tension honestly | A live change from the brief that lands directly on this role. CASE delivery, CO content |

### Reverse questions

| Question | Why it lands |
|---|---|
| "How do you measure complaints today, and what does good look like on resolution times?" | It gives you the baseline the JD's monthly report starts from |
| "Where does complaint handling differ most between branches and the contact centre today?" | It turns F2 into curiosity rather than a weakness |
| "Who would I present the monthly report to, and how often?" | It scopes F8 honestly and shows you're thinking about the audience |
| "How do you see complaints insight feeding the 40% digital target?" | It ties the role to the manager's strategy |
| "A year in, what would tell you this hire worked?" | Your future manager names the scorecard |
| "How will branch supervisors be supported through the move to hubs?" | They're the people you'd coach, and it signals you're thinking about them |

---

## Round 3: panel of two branch managers (60 minutes, values round plus case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One or more questions per value, scored against all four | High. The recruiter says the panel "score against the four values" | Use the cheat sheet below. Quote each value by its exact name. "We" for context, "I" for your part |
| Case / Strategist | The 20-minute escalation case and its follow-ups | High. It's declared, and it takes a third of the round | The case build section above: clarify, structure aloud, close on member outcome and recurrence |
| Peer Evaluator | "What happens when we disagree?" and what you'd need from their branches | Medium. Their supervisors are the people the JD says you'd coach, so they're pricing your effect on their branches | Reciprocity framing and seam principles, never pretending to know their branch |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: one real decision, covering what the member needed, what the easier option was, what you chose and why, and the outcome. It might come from the log you handled, if a real case fits. If no such time comes to mind, say so plainly and say how you would decide | It mirrors "Members First, Always" in its own words |
| C2 | "When has something needed explaining twice, and what did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Answer slot: if you changed how you explained the escalation script, or its wording, after something didn't land with new tellers, say what you changed and why. If not, say so plainly and describe how you trained them on it, in your own words | It mirrors "Plain Words — if a member needs it explained twice, we wrote it wrong." F4 is the nearest material |
| C3 | "How is your branch part of its town, and when did that shape a decision?" | VAL | [grounded] | Selection scaffold: a real local connection and a decision it changed. If no such time comes to mind, say so plainly and say what you would protect for a branch's town | It mirrors "Neighbours, Not Numbers". Branch managers will feel this value most |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if you built the spreadsheet because you saw a need yourself, say what you saw and what you did until it was in use. If you were asked to build it, say so plainly and tell what you built. If another story fits "Own the Fix" better, use that one | It mirrors "Own the Fix". F3 is the nearest material, and the slot keeps who started it honest |
| C5 | "Some of our branches will close into hubs. How do you square that with 'Neighbours, Not Numbers' when a member complains about it?" | VAL | [grounded] | Don't criticise the strategy or the people who set it. Acknowledge the tension plainly. Decide from the member's side (what they'll lose and what they still need), explain it once in plain words, and keep hold of the complaint until it's resolved | It sets the brief's consolidation against the values. This panel lives with it, so honesty here scores |
| C6 | The case. Practice scenario: "A long-standing member complained at the branch about a fee, then rang the contact centre and was told something different. Now they want the branch manager and say they'll move to an app-only bank. Take us through it." | CASE | [generic] | Use the case build above. Clarify (what was each told, what do they want, any deadline), name one owner, fix the member's case, explain once in plain words, then deal with the branch and contact-centre mismatch and log it for the monthly report. Name one value per step, out loud | A practice scenario, not Ashgrove's. It's built from the declared case format and the brief's app-only-bank pressure |
| C7 | "The supervisor who first handled it got it wrong. How do you coach them?" | CASE | [generic] | Structure: talk privately, start from what the member experienced, agree what to do differently, keep the supervisor as the member's contact if possible, and follow up. The question needs no claim about your past, so give none | The JD's coaching line in case form. Panel managers will judge how you'd treat their staff |
| C8 | "How would this case show up in your monthly report, and what would you do with it?" | CASE | [generic] | Structure: categorise it, link it to similar cases, flag the mismatch between channels as a possible pattern, and say who you'd take it to. Keep it a hypothesis until the numbers show a pattern | It connects the case to the JD's reporting line |
| C9 | "You'd be coaching my supervisors. What happens when you and I disagree about one of my branch's complaints?" | JD | [generic] | Seam principles: the member's outcome decides, one owner is named, the disagreement is raised with the facts and between the two of you, and you never undercut the manager in front of staff | Peer Evaluator's core probe. JD because it tests the coaching mandate |
| C10 | "What would you need from branch managers, and what would we get from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I built the monthly complaints spreadsheet our regional manager uses" | Reciprocity: what you'd need (honest early warning on complaints, access to supervisors) and what they'd get (a monthly report they can use and consistent coaching for supervisors), framed as plans. You can say you've been a branch supervisor for the last three years and that you built a monthly complaints spreadsheet your regional manager uses. Let them infer what that means for them | It prices your effect on their branches. F6 and F3 are the relevant material |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from where the member stands | Selection scaffold (C1, B7). Nearest material, F1: "I handled the branch's formal complaints log". Use a real case from it only if one fits. If no such time comes to mind, say so plainly and say how you would decide |
| Plain Words | Needing to explain something twice means it was badly explained the first time | F4: "trained new tellers on our escalation script", with C2's answer slot on whether you changed how it was explained. If you didn't, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town, not just to a network | Selection scaffold (C3, C5). No quoted sentence carries this. If no such time comes to mind, say so plainly and say what you'd protect |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses", with C4's answer slot on whether you started it yourself. If you didn't, say so plainly |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Which of the four values is hardest to live day to day in a branch?" | It's the values round, and inviting their honesty shows you take the values as real |
| "When a complaint moves from your branch to the contact centre, where does it go wrong most often?" | It's the seam you'd own, and it draws on their experience |
| "What would you want from someone coaching your supervisors, and what would you not want?" | The reciprocity question for a panel whose staff you'd coach |
| "How are members in your towns reacting to the hub plans?" | It's "Neighbours, Not Numbers" turned into a question |
| "With small-business lending launching in Q1 2027, are branches expecting new kinds of complaints?" | It shows you've read the brief and gets you ahead on what the role will face |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches | B1, B2, B5, C6 |
| Across the contact centre | A9, B1, C6 |
| Report monthly on volumes and resolution times | B8, B9, C8 |
| Coach branch supervisors on escalations | B3, C7, C9 |
| Work with digital teams on self-service journeys | B10 |
| 4+ years in financial-services customer operations | A1, C10 |
| Experience handling regulated complaints | A7 |
| Confident presenting to senior leaders | B4, B6 |
| Comfortable with Excel reporting | A8, B8 |
| The four values | C1 to C5, B7 |

---

## Prohibited claims

This pack won't coach any of the following claims. Don't say them in your own words either.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, or ran it end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack observes that your material describes one branch's log, not a process. B1's slot stays inside the log |
| Has contact-centre experience | You stated the negative (F2) | "I've never worked in a contact centre." No slot |
| Has presented to senior leaders or executives | You stated the negative (F8) | "I've never presented to anyone above regional level." F9's slot covers only regional level |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". B3's slot asks only whether you have coached peers |
| Reported complaint volumes and resolution times to the region, or built the region's reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". B8's slot asks only what it holds |
| Six years in customer operations | Inflated form of F6: the JD's vocabulary borrowed for your history | "Six years in retail banking, the last three as a branch supervisor" |

---

## Sources

**Provided documents:**
- The JD, pasted
- Ashgrove's values, pasted. You copied them on 26 November 2026 from ashgrovecu.org/about/values. That page was not fetched
- The recruiter's email about the process, pasted
- Your summary of Ashgrove's July 2026 strategy brief, which the recruiter sent you
- Your background, from your message

**Searches and fetches:** none sent. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The pasted values, copied today, already fix the values cheat sheet and C1 to C5 |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes all three rounds, the case and the values round. Persona weights follow it |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief (about four months old) already supplies the priorities behind B10, B11 and C5 |
| 4. Interviewer names | n/a | No interviewers have been assigned, so no query could be formed. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The supplied JD fixes the fit snapshot and every JD-tagged question |

---

## Upgrade menu

- **Interviewer names, once assigned:** an interviewer read, personas assigned to each panel member, and at least one reverse question per round tied to that person's own career path
- **Your CV:** fit-snapshot rows that quote CV lines alongside your message, and possibly evidence for F5 (digital) and F9 (regional presenting) that your message doesn't carry
- **What the monthly spreadsheet tracks, and in what tool:** F3 and F10 move from discovery to direct evidence, and B8, B9 and A8 become story-mapped
- **Whether your formal complaints fell under a regulator's rules, and which ones:** F7, A7 and the case concession on T2 become grounded
- **Any presenting you've done at regional level:** F9 and B4 upgrade
- **Any work with a digital team or a self-service change:** F5 and B10 upgrade
- **How much prep time you have before 5 December:** a prioritised prep schedule tied to question IDs
- **The full text of the strategy brief:** exact wording and any further figures for the grounding brief and CO questions
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes):** recent news on the hub consolidation and leadership, plus candidate reports on Ashgrove's interviews, feeding B11, C5 and the reverse questions
- **A `tuesday-dossier.md`:** a verified evidence map and named objections to anchor B1. Useful later, never needed for this pack
