Now the references it names.
I'll make those edits with the Edit tool instead.
Dara, I've saved your prep pack as `AshgroveCreditUnion_member-experience-lead_interview_pack.md`. It covers all three rounds on 5 December. I built it from what you sent: the JD, the values, the recruiter's email and the July brief. I didn't run any web searches, because your documents already covered everything a search would have found.

- **Most important thing to rehearse:** question C1 in round 2, with the Head of Member Services. They will almost certainly ask why someone whose complaints work is one branch is ready for every branch, the contact centre and the senior team. The pack has you say the gaps yourself before they do: "I haven't worked in a contact centre" and "I've never presented to anyone above regional level". It then helps you stand by what you have actually done and handle two harder follow-ups.
- **Round 1 (recruiter):** pay, notice period, location and why you're leaving, each to be answered from your own situation. It also has short, honest answers to the yes/no checks on the JD's requirements.
- **Round 3 (panel):**
  - **Values:** one question for each of the four values, with prompts to help you pick a real example.
  - **The 20-minute case:** a structure and three positions you can take, each with the limit you should admit.
  - **Your main point there:** as escalation lead, you would help the branch supervisor keep hold of the complaint and fix it, rather than taking it over. That fits the "Own the Fix" value.
- **Places to fill in yourself:** the pack doesn't know some things, such as which complaint rules your log came under, what your spreadsheet measures and whether it's in Excel. Where it would be guessing, it gives you an "answer slot" to fill from what really happened. If you tell me those answers, I'll turn those sections into full suggested answers.
- **Claims to avoid:** a list of statements to stay away from even under pressure, such as "ran complaints across the region" or "coached supervisors". Each goes further than what you told me.

If you'd like to practise, I can play the Head of Member Services and ask you C1 live, with follow-ups that react to your answers.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, so you can bring it to later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AshgroveCreditUnion_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 5 December 2026, as the recruiter's email sets them out
- Round 1: 30 minutes with the recruiter
- Round 2: 45 minutes with the Head of Member Services, who would be your manager. Mostly behavioural
- Round 3: 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case. This is the values round, scored against the four values

Interviewer names have not been assigned yet, so the pack is built on each round's role alone.

---

## How to use this pack

- **Personas** describe how a question gets asked: a friendly opener, a quiet probe on a gap, a scored values question.
- **Types** describe what is being scored:
  - **VAL**: whether past behaviour shows Ashgrove's four published values
  - **EXP**: whether what you say about your experience holds up when probed, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: whether you know Ashgrove's strategy and can think at its level
  - **CASE**: how you structure and reason through a live problem
- **Provenance labels:** `[grounded]` traces to something you gave me (the JD, the values, the brief, the recruiter's email, your own sentences). `[inferred]` is this pack's own derivation. `[generic]` is a general pattern for this kind of role, with no claim about Ashgrove or you.
- **Answer slots** mark the places where only you know the answer. Each has two honest branches. Fill them from what actually happened.
- The guidance is scaffolding, not a script. Say it in your own words.

**Highest-ROI prep in this pack: C1** (Round 2). It is the scope-jump objection: one branch's complaints log against a role that covers every branch, the contact centre and the senior team. It will come up in some form, and probably first in Round 1 (B2, B4).

---

## Shared: Fit snapshot

Everything the pack says about your past comes from the sentences quoted in this table.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's formal complaints log. It does not describe a process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe on what handling the log involved likely. If some steps were yours to decide (how a complaint was logged, who it went to, when it was closed), say which ones and how, in your own words. If none were, or there was no such step, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | No wording closes this gap, and you have said so. Words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as something you've done. Never claim contact-centre work, and don't add anything to make the gap sound smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | You state this specifically, but nothing has been inspected behind it, so expect a probe. Your material doesn't say what the spreadsheet measures. Answer slot: if it counts volumes or tracks how long complaints take to resolve, say what it counts, in your own words. If it tracks something else, say what, and say what you would add for volumes and resolution times. Keep "our regional manager uses" at its own scope: your material says who uses it, not which branches' data it holds |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words at their own scope: "I trained new tellers on our escalation script." The pack's own observation: that covers tellers, not supervisors, and training on a script, not coaching people's judgement. Answer slot: the JD's coaching line makes a probe on how you trained them likely. If you ran the training sessions or checked their handling afterwards, say which and how. If the training was walking them through the script, say so plainly. "Our" script: the material doesn't say you wrote it |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show any work with digital teams. Answer slot: if you have worked with a digital or app team (testing a journey, or passing on member complaints about online banking), say what you did and which part was yours. If you haven't, say so plainly and explain how you would bring complaint data to a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already meets this requirement in other words. Words: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map branch work onto "customer operations". Don't relabel your history in the JD's term |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" isn't the same as "regulated", and the material doesn't say which rules applied. Answer slot: if the complaints in that log came under a regulator's rules (deadlines, or responses you were required to send), say which rules and what you did to meet them. If you don't know, or they didn't, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated this gap. Words: "I've never presented to anyone above regional level." Then give a plan for your first senior report. Your sentence doesn't say whether you have presented at regional level. Answer slot: if you have, say to whom and what about. If not, keep to the sentence as it stands |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The material says "spreadsheet", not "Excel". Answer slot: name the tool you built it in and what the spreadsheet does (formulas, pivot tables, charts, whatever is true). If the tool isn't Excel, name it, and say what you would need to learn in Excel |

**Requirement coverage**

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end (F1) | C1, D1, G1, H1 |
| Across branches and the contact centre (F2) | B4, C1, C4 |
| Report monthly on volumes and resolution times (F3) | E1, P1, I2 |
| Coach branch supervisors on escalations (F4) | D3, G5, I1, H1 |
| Work with digital teams on self-service journeys (F5) | E2, E3 |
| 4+ years in financial-services customer operations (F6) | A1 |
| Regulated complaints (F7) | B1, C3 |
| Presenting to senior leaders (F8) | B2, C1, C2 |
| Excel reporting (F9) | B3, P1 |

---

## Shared: Grounding brief

Source: the July 2026 strategy brief the recruiter sent, the JD, and the values text you copied on 26 November 2026. By 5 December the brief will be about five months old. If an interviewer describes a plan differently from the brief, go with their version and don't correct them.

| Item | What your documents say | Provenance | Where it can come up in the loop |
|---|---|---|---|
| Who Ashgrove is | "member-owned, about 900 staff" — JD | [grounded] | Use "members" throughout, never "customers" |
| Digital shift | "move 40% of member service to digital channels by 2028" — brief | [grounded] | E2, E3. The JD's digital line (F5) |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" — brief | [grounded] | H3, and the panel in general: both panellists are branch managers. Talk about members and staff in the towns affected, and don't call any of it "efficiency" |
| New product | "launch a small-business lending product in Q1 2027" — brief | [grounded] | Reverse questions R2.5. A new product brings new kinds of complaint |
| Competition | "the main competitive pressure is app-only banks" — brief | [grounded] | E2. Why a fast, plain-words complaints process matters when switching is easy |
| Values | Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix — ashgrovecu.org/about/values, as you pasted it | [grounded] | Round 3 scoring, plus D1 to D4. Learn them by name |

---

## Shared: Prohibited claims

These are the claims this pack won't coach, because each one goes beyond what you told me. Expect pressure to make them in C1, B2 and G1.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across several branches or the region | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation: the material says one branch's log. Slots stay inside the log |
| Any contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." |
| Built the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The material says who uses it, not what it covers |
| Coached supervisors, or wrote the escalation script | Inflated form of F4 | "I trained new tellers on our escalation script." |
| Managed or ran the branch | Inflated form of F6 | "the last 3 as a branch supervisor" |

---

## Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through, motivation, logistics | High. A recruiter screen's default register, and 30 minutes leaves room for little else | A prepared 90-second arc (A1). Treat every casual question as scored |
| Skeptic (light) | Checks against the JD's requirements | Medium. Four JD lines (F2, F7, F8, F9) are easy yes/no checks, and the answers go to the Head of Member Services | Short, honest answers. A plain negative plus a one-line plan beats a long hedge |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, using only these beats: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on our escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close by linking to this role's complaints remit. No titles, team sizes or numbers beyond these | Almost certain to open the call. It sets how F1, F3, F4 and F6 come across in every later round. EXP because it's a summary of what you did |
| A2 | "Why this role, and why a credit union?" | CO | [grounded] "I handled the branch's formal complaints log" | Answer slot: give your actual reason, in your own words. One factual anchor: you handled the branch's formal complaints log, and this role owns complaints across branches and the contact centre. For "why a credit union", Ashgrove is member-owned and its first value is "Members First, Always". If that matters to you, say why in your own words. If you have no specific reason for credit unions, say what draws you to the role instead, and don't invent one | Motivation checks are standard in a screen, and the recruiter passes the answer on. CO because it tests whether you know what Ashgrove is |
| A3 | "What do you know about Ashgrove at the moment?" | CO | [grounded] | Two facts from the brief and one link to the role: the move to 40% digital service by 2028, and eight branches becoming five hubs over 2027. Both will change where and how members complain. Don't recite all four priorities | A cheap homework check. Picking two items and linking them to the role shows judgement. Reciting the brief only shows you read it |
| A4 | "What are you looking for in terms of pay?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a standard screen item. JD because it's about the job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, and the earliest start you could commit to | Standard logistics question |
| A6 | "The role covers several branches and the contact centre. Where are you based, and how do you feel about moving between sites?" | JD | [generic] | Logistics slot: say plainly where you can work and how often you can travel between sites, based on your actual situation | "Across branches" in the JD makes this likely, and the hub changes may sharpen it |
| A7 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, and keep it short. Say nothing about your current employer you wouldn't say to them | Standard screen question. EXP because the answer is about your history |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Do you have experience handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Lead with the quote: "I handled the branch's formal complaints log." Then the answer slot: if those complaints came under a regulator's rules, name the rules and what you did to meet them. If you don't know, or they didn't, say so plainly and stay with the log | F7 is a listed requirement and an easy screening check |
| B2 | "Have you presented to senior leaders before?" | JD | [grounded] "I've never presented to anyone above regional level." | Don't dodge this: "I've never presented to anyone above regional level." Then one line of plan (for example, getting your first monthly report reviewed by your manager before it goes up). Answer slot: if you have presented at regional level, say to whom. If not, stop at the sentence | F8 is a gap you have stated. A clean answer here sets up C1 well. A hedge here gets repeated to the hiring manager |
| B3 | "How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: name the tool and what the spreadsheet does. If it isn't Excel, name the tool and say so | F9 is a listed requirement. The recruiter will probably note a one-word answer |
| B4 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then one line of plan: in your first weeks, sit with contact-centre colleagues and listen to escalated calls. Say it as a plan | F2 is a gap you have stated. A short, calm answer here means the gap reaches the HM as handled, not as a surprise |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would the Head of Member Services most want fixed in the first six months?" | It shapes your Round 2 answers, and recruiters often know |
| R1.2 | "For the 20-minute case, will I get the scenario in advance or on the day, and is it spoken or written?" | A process question that is fair to ask. The answer changes how you prepare H1 |
| R1.3 | "Does the role manage a team, or work through the branch supervisors?" | The JD doesn't say, and it changes how you answer the coaching questions (D3, I1) |
| R1.4 | "Do branch and contact-centre complaints sit with one team today?" | It tells you whether "end to end" means joining things up or running something that already exists |
| R1.5 | "What's the timeline after 5 December?" | Practical, and it shows you're planning ahead |

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope jump and of F2 and F8 | High. A manager buying capability prices the gaps first, and F2 and F8 are the obvious ones | Rehearse C1 until it's boring. Name the limit before you're asked about it |
| Values / Behavioural | "Tell me about a time…" questions | High. The recruiter says this round is "mostly behavioural" | Story selection from real instances, with "I" for what you did. Where no story comes to mind, use the honest branch |
| Case / Strategist | Live problems on reporting and the digital shift | Medium. The usual manager-round prior, toned down by the behavioural focus | Clarify, then structure, then answer. Use Ashgrove's own words: members, hubs, Plain Words |
| Data-Driven Prober | Questions about the spreadsheet | Low. F3 and F9 are the only places to probe | Know what it counts and what you don't know about it |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role runs complaints across every branch and the contact centre, and reports to the senior team. Your experience is one branch. Why are you ready for that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre" "I've never presented to anyone above regional level." | **Highest-ROI prep.** Name the limit first, before they do: "My complaints work has been one branch's formal log. I haven't worked in a contact centre, and I've never presented to anyone above regional level." Then hold only what the quotes carry: you handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet your regional manager uses. Then a plan, said as a plan: learn the contact centre from the people in it, find out how complaints reach the log from each channel, and have your first senior report reviewed before it goes up. **Follow-up 1** ("contact-centre complaints work differently"): agree, and say what you would learn first. Don't claim to know how they work. **Follow-up 2** ("why not hire someone who's done this?"): concede it exactly ("someone who has run contact-centre complaints would start faster there"), then go back to the three quotes. Never fold into "I'd pick it up quickly" with nothing behind it, and never stretch the log into a multi-branch process | F1, F2 and F8 combined are the most predictable objection to this candidate for this role. Your future manager will test it because they carry the hiring risk. JD because it scores the role's scope directly |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level." | Choose a real gap, not a disguised strength: "I've never presented to anyone above regional level." Then the plan and what you'd ask of your manager. Don't add a second weakness to look modest | A standard Skeptic stem. F8 is the honest answer, and having it rehearsed stops a scramble |
| C3 | "Tell me about the regulated side of your complaints work. What rules were you working to?" | JD | [grounded] "I handled the branch's formal complaints log" | Start from the log. Answer slot (F7): name the rules and what you did to meet them, such as deadlines or required responses. If you don't know which rules applied, say so plainly. Never name a regulation you didn't work to | F7 matters in a regulated-complaints role, and this question is where vague answers get caught. JD primary, EXP delivery |
| C4 | "How would you get up to speed on the contact centre?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then a 30-day plan in three steps: listen (sit with agents and hear escalated calls), map (how a contact-centre complaint is logged compared with a branch one), and agree (one shared way of logging so the monthly report counts both the same way). All said as a plan | F2 is a stated gap. A concrete ramp plan is the Skeptic's counter-strategy. JD because it's the role's scope |

### Bank D: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint where hearing the member's side changed how you saw it." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Pick a real complaint from the log you handled. It needs what the member said, the decision you made and what changed for the member. "I" for what you did. If no such complaint comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle one | The theme comes from "Members First, Always", which your manager will look for even though the panel scores it formally |
| D2 | "Tell me about a time you had to tell your regional manager something they didn't want to hear." | VAL | [generic] | Selection scaffold: a real instance with a named stake, a moment you didn't back down, and a working relationship still intact afterwards. If none comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | A Values persona stem. It matters because this role reports bad news upwards every month (F8's requirement) |
| D3 | "Tell me about a time a new teller handled an escalation badly. What did you do?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold, grounded in your training of new tellers on our escalation script. Pick a real instance: what happened, what you said to the teller, and what happened next. If none comes to mind, say so plainly and describe how you trained them | The theme comes from the JD's coaching line (F4's requirement). This is the closest your material gets to it |
| D4 | "Tell me about a problem you found that wasn't strictly yours to fix. What did you do?" | VAL | [grounded] | Selection scaffold: a real problem, the point where you could have passed it on, and what you did to keep hold of it until it was solved. If none comes to mind, say so plainly, then give the nearest thing you have | The theme comes from "Own the Fix". Your manager will want to know whether you hold onto problems |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "It's your first monthly complaints report for the senior team. What's in it?" | CASE | [grounded] | Structure it: volumes by channel (branches, contact centre, digital); resolution times against the deadline that applies; the top causes; what changed since last month; and one decision you're asking them for. One page, in plain words ("if a member needs it explained twice, we wrote it wrong" applies to leaders too). The question needs no claim about your past, so the guidance makes none. If asked whether you've built something like it, P1 covers that | Tests the JD's reporting line (F3's requirement) and the senior-audience gap (F8's) as a live problem. CASE because it asks for a design, not a history |
| E2 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and what would you do about it?" | CO | [grounded] | Clarify first: which services move first? Then: complaints move channel, and journeys that fail become complaints. Tag digital complaints separately so the digital teams see them. Protect members who won't go digital (Members First, Neighbours). Mention app-only banks: when switching is easy, a slow complaint costs a member. Then F5's answer slot on your own experience with digital teams | Uses the brief's headline priority. CO content, CASE delivery. This is the question most candidates can't answer specifically |
| E3 | "How would you work with our digital teams on self-service journeys?" | JD | [grounded] | Answer slot (F5): if you've worked with a digital or app team, say what you did and which part was yours. If you haven't, say so plainly. Then the approach: bring them the complaints that show where a journey fails, in their terms (the step, how many members, what they said), and agree how to check whether a fix worked | A listed requirement with nothing in your material behind it. The honest branch has to be ready before it's needed |

### Bank P: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Cover the beats the quote states: you built it, it's monthly, your regional manager uses it. Answer slot: say what it counts and which tool it's in. If it counts volumes or resolution times, say how, in your own words. If you don't know how your regional manager uses it, say so rather than guessing. Never widen it to "the region's reporting" | F3 and F9 both rest on this sentence, so it's the one place a Prober will dig. EXP because it tests what was actually yours |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What's the complaints issue you'd most want this person to fix first?" | Puts you in their problem, and tells you what the first 90 days would be judged on |
| R2.2 | "How would you know at 12 months that this hire had worked?" | Shows you think in outcomes, and asks them to state the bar |
| R2.3 | "Who reads the monthly report, and what do they do with it?" | Ties to F8 without dwelling on it. You're preparing for the audience |
| R2.4 | "How are complaints from branch members being planned for as the eight branches become five hubs?" | Shows you've read the brief and thought about members in the affected towns |
| R2.5 | "Will the small-business lending product's complaints come through the same process?" | A Q1 2027 launch would land in your first months. Shows you're looking ahead |
| R2.6 | "What support is there for someone stepping up to report to the senior team for the first time?" | Turns the F8 gap into a conversation about development, raised on your terms |

---

## Round 3: Panel of two branch managers (60 minutes, values round, with a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scored questions against the four values | High. The recruiter says the panel "score against the four values" | One prepared story per value (cheat sheet below). Use the value's name in your answer |
| Case / Strategist | The 20-minute escalation case | High. Announced by the recruiter | The case build section below |
| Peer Evaluator | "How would you work with my branch?" | Medium. Their supervisors are the people this role coaches | Frame it as what you'd bring their branch, and offer principles for the working relationship. Don't pretend to know it |
| Skeptic | Same objection as C1, asked collegially | Low. This round's scoring is values-led | C1's answer, shortened |

### Values cheat sheet

| Value (official name) | Working meaning | Your story | Question |
|---|---|---|---|
| Members First, Always | Decide as the member would see it | Draw on F1: "I handled the branch's formal complaints log." Selection scaffold: one complaint from that log where your decision followed the member's view. If none comes to mind, say so plainly, then give the nearest thing you have | G1 |
| Plain Words | Write and speak so nothing needs explaining twice | Draw on F4: "trained new tellers on our escalation script." Selection scaffold: one moment from that training where you changed how you explained something until it landed. If none comes to mind, say so plainly | G2 |
| Neighbours, Not Numbers | Each branch belongs to its town, and each member is a person, not a case number | Selection scaffold: a real member or local situation where you treated it as more than a transaction. If none comes to mind, say so plainly, then say how you would approach it. Be careful here: the panel's branches may be the ones being consolidated | G3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Draw on F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you spotted a problem, say what the problem was and how you saw it through. If not, pick another real instance. If none comes to mind, say so plainly | G4, G5 |

### Bank G: Values / Behavioural (scored)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold from the log you handled: the member's situation, the harder option, why you chose it, and what happened. Use "member's side of the counter" if it fits naturally. If no instance comes to mind, say so plainly, then give the nearest thing you have | Members First, worded the way Ashgrove words it. The panel scores this one by name |
| G2 | "Tell me about a time you had to explain something so a member or colleague understood it first time." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold from training new tellers on our escalation script: what wasn't landing, what you changed, how you could tell it worked. If none comes to mind, say so plainly | Plain Words. Your training work is the closest material you have |
| G3 | "Tell me about a time you treated a member as part of the community, not just a case." | VAL | [grounded] | Selection scaffold: a named situation (no member names), what made it local, and what you did. If none comes to mind, say so plainly, then say how you would approach it. Don't use the hub consolidation as your example | Neighbours, Not Numbers. Branch managers will feel this value most strongly |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet started with a problem you found, tell that: the problem, why you kept it, what you built, and who uses it now (your regional manager, as the quote says). If it didn't, pick another real instance. If none comes to mind, say so plainly | Own the Fix. A spreadsheet story only works if it started with a problem, hence the slot |
| G5 | "Our values say whoever finds the problem keeps hold of it. As escalation lead, when would you take a complaint off one of our supervisors?" | VAL | [grounded] | Hold the value: by default the supervisor keeps hold and you coach and back them. Name the exceptions: a deadline at risk, a complaint about the supervisor's own conduct, or the member asking for someone else. Say what "taking it" means: you own it, and you tell the supervisor and the member. VAL content, CASE delivery | A natural tension between the role and the value. Branch managers will want to know you won't undercut their people |

### Graded deliverable: the 20-minute complaint-escalation case

**What you can build on**
- JD: "Own the member complaints process end to end", "report monthly on complaint volumes and resolution times", "coach branch supervisors on escalations".
- The four values, by name.
- The brief: eight branches into five hubs over 2027, 40% digital by 2028, app-only banks.
- Your material: F1, "I handled the branch's formal complaints log". F4, "trained new tellers on our escalation script". If they ask whether you've handled something similar, answer from F1's quote and pick a real instance. Don't build one from the case.

**Suggested time split, 20 minutes**
1. Clarify (2 min): what the member says happened and what they want; how long ago they raised it and which deadline applies; whether they may be vulnerable; whether anyone has contacted them yet; which channel it came through; whether a staff member's conduct is involved; whether there have been similar complaints.
2. The member now (3 min): who contacts them, by when, and what they're told in plain words, including what happens next and when.
3. Own and investigate (5 min): who keeps hold of it (thesis 1), the facts to gather, and the deadline.
4. Resolve and respond (3 min): the decision, the reply in plain words, and any redress, decided on the facts.
5. Root cause and reporting (4 min): one case or a pattern? Log it so the monthly volumes and resolution times show it.
6. Coach and close (3 min): the debrief with the supervisor, and what changes in the escalation process.

**Theses, each with a concession you have to state**

| Thesis | Concession |
|---|---|
| T1. Keep the fix with whoever found it, and back them. The escalation lead coaches the branch supervisor to keep hold of the complaint, rather than taking it to head office by default. That is Own the Fix | Some escalations should be taken over: a deadline at risk, a complaint about the supervisor's own conduct, or the member asking for someone else (G5) |
| T2. The member first, then the process. Contact the member early, in plain words, with what happens next and when | Don't promise an outcome or compensation before you have the facts. Being quick to reassure is not the same as being quick to agree |
| T3. Every escalation is data. Tag it so the monthly report shows whether it's one case or part of a pattern across branches, the contact centre and digital | One case isn't a trend. Say so, and say what would make it one |

**Differentiation:** the expected answer is apologise, investigate, resolve. Do that, then add the two moves most candidates leave out: the coaching conversation with the supervisor (T1) and the reporting step (T3).
**Anti-pick:** don't offer compensation just to close it, and don't move it to head office because it's uncomfortable. Say why: that teaches the supervisor to pass problems up instead of owning them.
**Close:** end on what the member hears from Ashgrove, and when.

### Bank H: Case / Strategist (inside the case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Here's an escalated complaint. Walk us through what you'd do." | CASE | [grounded] | Run the six-step structure above. Ask two or three clarifying questions out loud before you structure anything. Name T1 to T3 as you reach them, and state each concession | The announced case. Clarifying before structuring is what this persona scores |
| H2 | "The member wants compensation now, and the supervisor thinks the member is wrong. What do you do?" | CASE | [generic] | Separate the facts from the positions. Contact the member with a timeline rather than a decision (T2's concession). Ask the supervisor for the facts behind their view. Decide on the evidence and explain the decision plainly to both. Hold T1: the supervisor stays involved | A likely follow-up that tests composure in the middle of the case. `[generic]` because it's a pattern for this kind of case, not a fact about Ashgrove |
| H3 | "The member's branch is closing in the consolidation, and that's part of why they're upset. Does that change anything?" | CO | [grounded] | It changes the member's context, not the fairness of the process. Acknowledge the change plainly. Make sure they know where to go next, in person and online. Log it as consolidation-related so the monthly report shows the pattern (T3). Neighbours, Not Numbers. Don't defend or criticise the consolidation itself | The brief's hub plan, put in front of branch managers. CO content, CASE delivery |

### Bank I: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd be coaching my supervisors on escalations. How do you do that without cutting across me?" | JD | [grounded] "trained new tellers on our escalation script" | Answer with principles for the working relationship, not knowledge of it: agree with the branch manager what you coach on; debrief the supervisor and copy the manager; you never overrule them in front of their team. Your experience: you trained new tellers on our escalation script. Don't present that as coaching supervisors. Ask what they'd want from you (that's the reciprocity move) | F4's requirement from the panel's side. Branch managers are judging whether you lighten their load or add to it |
| I2 | "What would you need from branch managers to make the monthly report useful to us?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built the monthly complaints spreadsheet your regional manager uses, so you know a report has users. Ask them what they would use: their own branch's figures, the reasons behind them, comparisons with other branches. Offer to send them their branch's section before it goes up | F3's requirement from the branch side. Reciprocity: what they get from your report, not only what you need from them |
| I3 | "What would your first month with our branches look like?" | JD | [generic] | Visit each branch; sit with each supervisor on one real escalation; ask each manager what one change would help most; then share back what you heard. Keep it modest. You're learning their branches, not auditing them | Tests whether you understand turf. `[generic]` because it's a common onboarding pattern, not a fact about Ashgrove |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could someone in this role do in their first month that would genuinely help your branches?" | The reciprocity question. It tells peer-level interviewers you're there to help |
| R3.2 | "What's one thing about complaints you wish head office understood better?" | It gives them the floor and shows you'll listen |
| R3.3 | "What does a good escalation from your branch look like today?" | Tells you their current standard before you try to coach it |
| R3.4 | "How do your supervisors learn to handle escalations at the moment?" | Ties to F4's requirement and shows you'd build on what's there |
| R3.5 | "As the branches move into hubs, what do you think members will complain about most?" | Uses their local knowledge, and shows you've read the brief without lecturing them about it |

---

## Sources

**Provided documents**
- The JD, pasted.
- The values text, pasted, which you copied from ashgrovecu.org/about/values on 26 November 2026.
- The recruiter's email describing the three rounds.
- The July 2026 strategy brief, as you summarised it.
- Your background, in your own message.

**Searches and fetches:** none sent. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted, copied on 26 November 2026, already fixes the cheat sheet and Bank G. The values page URL was named as the source of pasted text, so it was not fetched |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email already fixes the loop: three rounds, who runs each, the case and the values scoring |
| 3. `Ashgrove Credit Union strategy` and recent news | skipped | The July 2026 brief, under six months old, already supplies the priorities and competition that E2, H3, R2.4 and R2.5 use |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form. There is no interviewer read |
| 5. A representative JD | skipped | You supplied the JD |

---

## Upgrade menu

- **Interviewer names, once assigned** → a section on reading each interviewer from their public professional profile, persona weights per person, and at least one reverse question tied to each one's career path.
- **How much prep time you have before 5 December** → a prioritised schedule (C1 first, then the case, then the four values stories), with everything else marked as insurance.
- **Your answers to the slots in F1, F3, F5, F7 and F9** → those rows, and the questions that draw on them (B1, B3, C3, E3, P1, G4), move from slots to story-mapped guidance.
- **Whether the case scenario comes in advance or on the day (R1.2)** → a case build tuned to the real format, and a full rehearsal if you get the prompt.
- **A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes** → any Ashgrove news since the July brief, and any public candidate reports on its interviews, labelled `[inferred]`.
- **A `tuesday-dossier.md`** → a cross-checked evidence map that would turn the inferred highest-ROI objection into an evidence-derived one, and bind each weak area to a set interview strategy.
