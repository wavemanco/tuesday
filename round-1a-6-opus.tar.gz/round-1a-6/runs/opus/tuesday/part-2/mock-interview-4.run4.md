Quick update: I've read your dossier and the prep playbook, and now I'm doing a few quick searches on Quartzline (values, interview process, recent news) before I build the pack.
I've saved your prep pack as `/var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-4-denied-e89416ad/Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the single 45-minute hiring-manager conversation you described, and it works from your dossier alone. I tried three searches on Quartzline (values, interview process, recent news) but didn't have permission to run them, so the case questions (bank B) are generic and there's no question on Quartzline's current strategy.

Today is Thursday 26 November. If the interview is today, rehearse these two things first:

- **A1, the objection your dossier named:** "You have never held the PM title or owned a roadmap — why should we hire you instead of an experienced PM?"
  - **Admit the gap first:** "I haven't held the PM title, and I haven't owned a product roadmap."
  - **Then describe the adjacent work:** your 30+ integrations through go-live, and the quarterly roadmap-input sessions. Describe the work and let them decide whether it counts as product experience.
  - **Before they ask,** say the sessions are the part you have little to show for.
  - **Close with a ramp plan,** said as a plan for the future.
  - **Two follow-ups are scripted:** where to hold your ground and where to concede.
- **Reverse questions RQ1 and RQ2:** what the PM decides versus the squad leads, and how API adoption is measured today. Your dossier's go decision depends on the first answer.

What else is in the pack:

- An 8-row fit snapshot covering R1–R5 and the role's responsibilities.
- 22 questions across seven interviewer styles. They're weighted toward Skeptic and Case/Strategist, which is what a hiring-manager round leans to.
- Six reverse questions. One checks whether the role's scope has changed, since your dossier dates from August.
- A list of eight claims the pack won't coach. Three come from your dossier; the other five are stretched versions of your own evidence. Examples: "shipped an API product", "drove the roadmap through the input sessions", "PM in all but title".

Where your material says nothing, the pack gives you an "answer slot" with two honest branches instead of words. This covers API docs and schemas, engineering and sales stakeholders, agile, and adoption metrics. Each slot reads "if you did it, say how; if not, say so plainly."

If you want, I'll play the hiring manager as a Skeptic on A1 and push with follow-ups based on what you actually say.
I can also add a `pack_feedback` section to your `tuesday-dossier.md`, recording the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs, Quartzline

Hiring-manager conversation, 45 minutes. Interviewer name not given. Built from your `tuesday-dossier.md` (generated 2026-08-14).

## How to use this pack

- **Personas** describe how a question is asked (who is asking, in what style). **Types** describe what is being scored.
- Type tags: **VAL** values and behaviour · **EXP** a deep-dive on your experience: what you actually did · **JD** whether you can do the listed job, gaps included · **CO** company and strategy knowledge · **CASE** a live problem from the role.
- Provenance labels: `[grounded]` traces to your dossier · `[inferred]` is this pack's own reading, with how it got there named · `[generic]` is a role-family pattern with nothing specific to Quartzline in it.
- **Answer slots** are instructions for your answer in the room, not questions for me. Each has two honest branches. If you did the thing, say how in your own words. If you didn't, or it never happened, say so plainly. Either branch is a good answer.
- Guidance is scaffolding, not a script. Every sentence about your past in this pack is one of the three verified-evidence entries in your dossier, quoted. Nothing else.
- Question bank letters skip F, so question IDs never clash with the fit-snapshot rows F1–F8.

## Fit snapshot

Requirement sources are your dossier's `role_profile` requirements (R1–R5) and responsibilities, which stand in for the JD. Evidence is the dossier's `verified_candidate_evidence` entries, numbered 1–3 in the order the dossier lists them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [grounded] | transferability | A bridge, always positioned as adjacent work and never as PM experience. That is the dossier's condition. The limit, in the pack's own words: your material shows integration leadership and input to product, not the PM role. Your words, kept to the quotes' scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." The second has limited proof you can show, so say that before you're asked. Answer slot: the R1 line makes a probe on the sessions likely. If you chose which client evidence went into them, say how you chose, in your own words. If you didn't, say so plainly and stay with what you ran |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier says acknowledge this gap and don't bridge it (acknowledge_gap). Your words, from the dossier's prohibited_claims entry "Having owned a product roadmap": "I haven't owned a product roadmap." Follow with a ramp plan, said as a plan and never as something you've done: how you would learn this team's roadmap calls in your first months. Don't offer the roadmap-input sessions (F1) as roadmap ownership, and add nothing to make the gap feel smaller |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [grounded] | transferability | The limit, in the pack's own words: your material says you integrated the vendor's APIs for clients. It doesn't say you shipped the API product. Your words stay at that scope: the integrations, through go-live. Answer slot: R2 makes a probe on what reached production likely. If any change to the vendor's APIs came out of your integrations, say what it was and which part was yours, in your own words. If none did, say so plainly and stay with the go-lives you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | discovery | The quotes touch technical work (architecture, a playbook) but don't show whether it involved API docs or schemas. Answer slot: R3 makes a probe on reading or writing API docs and schemas likely. If you worked with them in those integrations or in the playbook, say how, in your own words. If you didn't, say so plainly and say how you would get fluent in Quartzline's |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [grounded] | transferability | Clients and product appear in the quotes. Engineering and sales don't. The sessions have limited proof you can show, so expect a probe on them. Your words stay at the quotes' scope. Answer slot: R4's engineering-and-sales wording makes a probe likely. If engineering or sales people were part of those integrations, say who they were and what you worked through with them, in your own words. If they weren't, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier says to clarify this one, and none of the verified entries mentions agile. Answer slot: R5 makes "agile delivery experience" a likely probe. If your integrations ran in sprints or another agile cadence, say how, in your own words. If you never worked that way, say so plainly. Then the honest clarifier: "Here's what I'd want to confirm about how your squads define it — the cadence, who writes the tickets, and how scope changes mid-sprint" |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [grounded] | transferability | Scoping and gathering requirements with clients sits next to partner discovery. The pack's own limit: your material calls it scoping for integrations, not product discovery. Your words stay at the quotes' scope: scoping, requirements, and the client evidence you fed to product. Answer slot: if a need came out of scoping that went beyond the client's own integration and you took it into the sessions, say what it was, in your own words. If none did, say so plainly and stay with the scoping |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material doesn't mention this at all. That leaves it open, not a known gap. Answer slot: if anything about your integrations was tracked after go-live, say what was tracked and whether you did the tracking, in your own words. If nothing was, say so plainly and say what you would measure first |

## Persona table

Weights follow your own description of the round: one 45-minute conversation with the hiring manager. That sets the hiring-manager starting weights (Case/Strategist and Skeptic). No interviewer profile was available to adjust them.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the PM-title gap and roadmap ownership | High. A hiring manager is reducing the risk of a hire, your dossier names a Skeptic objection, and R1 is a must-have resting on your thinnest rows (F1, F2) | Rehearse A1 until it bores you. Bridge only from the quoted entries, say the limit plainly, then give a concrete ramp plan |
| Case / Strategist (bank B) | Live problems from the role: partner onboarding, adoption metrics, two squads, specs | High. This is the hiring-manager prior, and the responsibilities hand them ready-made cases | Clarify, then set the objective, segment, give the approach, name the metrics, then the risks. Think aloud, and challenge one premise politely per case |
| Data-Driven Prober (bank C) | Pushes on "30+", and asks what you can show for the sessions | Mid. "30+" is the one figure in your material, and the sessions are medium-confidence (limited proof) | Know what you can and can't say about how "30+" was counted. Raise the sessions' limit before they find it |
| Conversational (bank D) | The walk-me-through opener and casual questions about the playbook | Mid. The biography question is where your move from integrations into product gets scored, even though it sounds informal | A rehearsed 90-second arc built only from the three entries, plus your own reason for the move |
| Peer Evaluator (bank E) | Asks for the squads' point of view: what they'd need from you | Low. The hiring manager speaks for the two squads, and authority versus the squad leads is an open unknown | Frame it as reciprocity. Propose working principles, not a guess at how the teams actually split work |
| Pressure (bank G) | Time-boxed "why you" and "how much was you" | Low. Nothing in your material signals a stress style. Included so the style isn't new to you live | Pause, restate the question, anchor in the quotes, hold through two follow-ups |
| Values / Behavioral (bank H) | Behavioural "tell me about a time" questions | Low. No values-style round is detected, and Quartzline's published values aren't in hand | Use the selection scaffolds, each with its honest branch |

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier prohibited_claims: "Having held a product manager title or role", "Having owned a product roadmap" | **The highest-ROI rehearsal in this pack. Your dossier named this objection.** 1) Concede first, plainly: "You're right — I haven't held the PM title, and I haven't owned a product roadmap." 2) Then the adjacent work at its own scope: "What I have done: I've led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. And I ran quarterly roadmap-input sessions feeding client evidence to product." 3) Raise the limit yourself: the sessions are the part with little you can show, so say that before they ask. 4) A ramp plan, said as a plan: what you would learn first about how this team makes roadmap calls, and whom you'd sit with. Describe what you did and let them draw the conclusion. Never "that's basically PM work". Follow-up 1, "So the real calls were someone else's?": hold. "I haven't owned a product roadmap", then back to what you led, with nothing added. Follow-up 2, "Then why not the experienced PM?": concede specifically. They've done the roadmap part and you haven't. Then return to the two quotes and the plan, and never argue against the other candidate | Your dossier's named objection, aimed straight at F1 and F2. It will come in some form, so it gets the deepest rehearsal. Tagged JD because it scores R1 |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier uncertain_or_weak_areas acknowledge_gap and prohibited_claims: "Having owned a product roadmap" | Name F2 and don't fake a weakness: "Owning the roadmap. I haven't owned a product roadmap." Then the ramp plan, said as a plan: the first decisions you'd want to watch the team make, and how you'd learn the partners' priorities. Stop there. Don't add a second weakness to soften the first | F2 is the one capability gap in your file. Naming it before they do is the credibility move. JD because it scores the stated responsibility |
| A3 | "I don't see API docs or schemas in your background — how would you handle the technical side of this role?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Start with what the quotes carry: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, through architecture and UAT, and I wrote the internal integration playbook my team uses." Answer slot: if those integrations or the playbook involved API docs or schemas, say how, in your own words. If they didn't, say so plainly and say how you'd get fluent in Quartzline's docs in your first weeks | F4 is a discovery row. The honest answer depends on a fact the dossier doesn't hold, so rehearse both branches. JD because it scores R3 |
| A4 | "Leading integrations of the vendor's REST APIs isn't the same as shipping an API product. How do you see the difference?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Agree it's different. Don't blur it. Your side, at the quote's scope: you led client integrations of the vendor's APIs through go-live. Answer slot: if any change to the APIs came out of your integrations, say what it was and which part was yours. If none did, say so plainly. Then give your view of the difference as analysis, not as a claim about your past: an API product also has to cover versioning, docs, adoption and a roadmap across many partners | F3 is a transferability row, and its inflated form is on the prohibited list. Tagged JD because it scores R2 |
| A5 | "Why move into product now — and why this role?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give your real reason, in your own words. Nothing in the material states it. If the sessions are part of why, you can anchor there: "I ran quarterly roadmap-input sessions feeding client evidence to product." If they aren't, give your actual reason. Keep it to about 60 seconds and end on this role, not on leaving your current one | The motivation part of the Skeptic's "why now". It rests on F1's second quote. EXP because it tests whether your story holds together |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Three months in, partners tell you onboarding to our API is slow. How do you work out what to fix first?" | CASE | [generic] | Clarify first: which partners, slow compared with what, and who is saying it. Objective: time to first production call, or time to go-live. Segment partners by size and use case. Approach: map the stages a partner goes through, find where they stall, and talk to a handful in each segment. Metrics: time per stage, drop-off. Risks: fixing the loudest partner instead of the common stall. Makes no claim about your past | Built from the "Run discovery with integration partners" responsibility (F7). Labelled `[generic]` because the structure is a pattern, not knowledge of Quartzline |
| B2 | "How would you define adoption for a partner-facing API, and what would you track first?" | CASE | [generic] | A funnel: signed up, first successful call, production traffic, sustained or growing usage. Separate leading signals (time to first call, error rates during onboarding) from lagging ones (active partners, call volume). Segment by partner tier. Ask what they measure today, which ties to reverse question RQ2. If they turn it to what you've tracked, use F8's answer slot | The "Define and track adoption metrics" responsibility (F8), with no baseline stated anywhere. The CASE format lets you show structure without claiming a past |
| B3 | "The two squad leads disagree about what goes into next quarter. How do you handle it?" | CASE | [generic] | Clarify decision rights first: who makes the call. That's the dossier's open question, so it's fair to say you'd want it settled early. Then: shared criteria (partner impact, effort, risk), evidence from partners, a written trade-off, and a clear escalation path if the leads still disagree. Speak in the future tense. Your file has no past instance of this (prohibited list) | Built from the "drive delivery with two engineering squads" responsibility and the authority-versus-squad-leads unknown. A hypothetical, so it presupposes nothing about you |
| B4 | "A large partner wants a custom endpoint only they would use, and sales is pushing hard. What do you do?" | CASE | [generic] | Clarify the need underneath the request, the deal at stake, and whether other partners share it. Options: generalise it into the platform, offer a workaround, or say no with reasons. Give the anti-pick plainly: a one-off endpoint adds maintenance cost for every future version. Close with how you would tell sales and the partner | R4's engineering, sales and customer triangle as a live problem. Built so you can show judgement, including saying no |
| B5 | "Here's a draft spec for a new webhook. What do you ask before engineering starts?" | CASE | [generic] | Who consumes it, and which problem it solves. Payload and schema. Versioning. Authentication. Retries and ordering. Rate limits. Docs and examples. What "success" means after launch. Ask at least one question that challenges the spec's premise | The "Write specs" responsibility, and a live test of R3 fluency without needing your past |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ integrations — walk me through how that's counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep the number attached to what it counts: client integrations that you led, end to end. Answer slots, each in your own words: how they were counted (what made one integration "one"), what the figure is sensitive to, the assumption behind it you'd defend least, and which part of each was yours. If you don't know how a part was counted, say so plainly | The only figure in your material, so a prober will go for it. EXP because it tests attribution |
| C2 | "Pick one of those integrations and take me through it end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Choose one real integration. Its beats are the stages the quote states: scoping, requirements, architecture, UAT, go-live. Tell each in your own words, and keep "led" as your verb. Answer slot: R4 makes a probe on stakeholders likely. If engineering or sales people were involved, say who they were and what part of the work was yours. If they weren't, say so plainly and stay with the client | Tests whether "led" holds up when examined (F1, F5). The stages come straight from the quote, so the story's middle is yours to tell, not the pack's |
| C3 | "Those roadmap-input sessions — what came out of them? Is there anything I could look at?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what you did, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Raise the limit before they find it: say plainly what you can and can't show. Answer slot: if you know of a change that followed evidence you fed in, say what it was and which part was yours. If you don't know of one, say so plainly and describe what the sessions fed in. Never "shaped" or "drove" the roadmap | The dossier marks this entry medium: confirmed, little you can show. A prober finds that weak spot, and volunteering it turns a gotcha into credibility |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each one an entry: the integrations you led, the playbook you wrote that your team uses, and the sessions feeding client evidence to product. Then your own reason for this move, in your own words, and land on this role. Give dates and years only in your own words | Casual, but scored. This is where your move into product gets judged. It draws on F1, F4 and F5 |
| D2 | "Tell me about the playbook you wrote — what's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states: you wrote it, and your team uses it. Describe what's in it in your own words. Answer slot: R3 makes a probe likely. If it covers API docs or schemas, say how. If it doesn't, say so plainly and say what it does cover. If you can show part of it without breaking confidentiality, offer to. If you can't, say so | Your one entry backed by something they could inspect (F4). A relaxed question here often turns into a technical one |
| D3 | "How have you usually worked with engineering teams day to day?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if engineers were part of those integrations, say how you worked with them, in your own words. If they weren't, say so plainly. Answer slot: if the work ran in sprints or another agile cadence, say how. If not, say so plainly, then add the clarifier: "I'd want to understand how your squads run — cadence, tickets, mid-sprint changes" | Covers R4's engineering wording and R5 (F5, F6) in a casual register, which is where unrehearsed answers drift |

### E — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The squad leads will expect clear priorities from you. What would you need from them, and what would they get from you?" | CASE | [generic] | Reciprocity first: what they get. Partner evidence brought to them early, written trade-offs, and protection from one-off requests. Then what you need from them: effort estimates, technical risks raised early, and agreement on who decides what. Propose principles, not a claim about how Quartzline splits decisions. Future tense only | The two-squads responsibility and the open decision-rights question, seen from the squads' side |
| E2 | "How do you handle credit when an integration's success depends on several teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Use "we" for the context and "I" for what you led. Answer slot: pick one integration. If other teams did parts of it, say who did what, in your own words. If none did, say so plainly and stay with what you led | A test of credit-sharing on F5's evidence |

### G — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who's already been a PM?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier prohibited_claims: "Having held a product manager title or role" | Pause, then give A1 compressed: "I haven't held the PM title." One quote: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." One line of ramp plan. Stop before the 60 seconds are up | A1's objection, time-boxed. Composure is what's scored, so rehearse the short version separately |
| G2 | "That's 30+ integrations — how much of each one was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led" through two follow-ups, because the quote carries it. Answer slot: say which parts of the stages were yours and which were others', in your own words, and concede specifically where others did the work. Never inflate the share and never fold it to zero | The attribution test on the one figure (C1). The hold-then-concede structure decides how this answer is judged |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where there was a named stake, you said the hard thing, it landed, and the relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. With no published values in hand, it stays generic |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a real decision where a customer's need cost something internally, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-first framing suits a partner-facing role. Labelled `[generic]` because it isn't tied to any stated value |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management | A1, A2, A5, G1 |
| R2 Shipped API or platform products | A4 |
| R3 Technical fluency: API docs, schemas | A3, B5, D2 |
| R4 Stakeholder management across engineering, sales, customers | B4, C2, D3, E2 |
| R5 Agile delivery | D3, plus reverse question RQ3 |
| Own the roadmap | A1, A2, B3 |
| Run discovery with integration partners | B1 |
| Write specs and drive delivery with two squads | B3, B5, E1 |
| Define and track adoption metrics | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Carried from your dossier. The job ad claims this authority but nothing shows it yet, and the dossier's go decision depends on this answer. It reads as diligence and tells you whether the role is what it's called |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | Carried from your dossier. Adoption is listed as a responsibility with no baseline stated. The answer tells you whether you'd inherit a metric or have to build one |
| RQ3 | "How do the two squads plan and ship work today — cadence, rituals, who writes the tickets?" | Settles F6 on their terms instead of yours, and shows you what "drive delivery" means day to day |
| RQ4 | "What would you want this person to have changed for partners by the end of the first six months?" | Defines success in their words, and shows whether ownership comes with real scope |
| RQ5 | "Where do partner integrations stall most today, and who hears about it first — sales, support or engineering?" | Asks about the integration path that your F1 and F3 evidence sits on, so their answer gives you something concrete to respond to |
| RQ6 | "Has anything about the scope of this role changed since it was posted?" | Your dossier dates from 2026-08-14, so the requirements in this pack may have moved since. The answer re-checks them live |

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Dossier prohibited_claims: "Having held a product manager title or role" | "I haven't held the product manager title." No answer slot |
| Owned a product roadmap | Dossier prohibited_claims: "Having owned a product roadmap", plus the acknowledge_gap area in uncertain_or_weak_areas | "I haven't owned a product roadmap." Then a ramp plan, as a plan. No answer slot |
| Set prioritization for an engineering squad | Dossier prohibited_claims: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." B3 and E1 stay hypothetical, in the future tense |
| "PM in all but title" or "effectively did product work" | Implies the dossier's prohibited claim "Having held a product manager title or role" | F1's quotes at their own scope, framed as adjacent work. Let the interviewer draw the conclusion |
| Shaped, influenced or drove the roadmap through the input sessions | Inflated form of F1's second quote | "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit, in the pack's own words: the quote says feeding evidence, not deciding. C3's slot stays inside the sessions |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit, in the pack's own words: the material says integrations of the vendor's APIs. F3's and A4's slots stay inside the integrations |
| Managed engineering and sales stakeholders | Inflated form of F5 | F5's quotes at their own scope: clients and product. The slots ask only who was part of the integrations |
| Ran product discovery with partners | Inflated form of F7 | F7's quotes at their own scope: scoping and requirements for client integrations |

## Sources

- **Provided:** `tuesday-dossier.md`, version 1.1, generated 2026-08-14. Sections used: `role_profile` (requirements R1–R5 and responsibilities, standing in for the JD), `handoff_to_mock_interview` (all seven fields), and `decision` (context only). This dossier has no `evidence_map`, `evidence_state` or `risk_register`, so confidence comes from the handoff's own notes and its weak-area entries. The dossier is about three and a half months old, so check the role's details with RQ6.
- **Your own words:** "a 45-minute conversation with the hiring manager". This establishes the session, so persona weights use the hiring-manager starting weights, not a guessed loop pattern.
- **Searches:** `Quartzline company values` — refused. `Quartzline interview process product manager` — refused. `Quartzline partner API platform news 2026` — refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have themed bank H from Quartzline's published values, so H stays `[generic]` |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have shown later rounds beyond this one. This session's weights rest on your own description, so they don't change |
| 3. `Quartzline` strategy / recent news | unavailable | The search was refused. It would have grounded bank B and added a CO question on current strategy. As it stands, B is `[generic]` and the pack has no CO question |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to run. The interviewer read is left out |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements that fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow the three searches, or paste Quartzline's values or about page and any recent news → bank B grounded in current strategy, a CO question added, bank H themed on their published values
- A deeper research pass — up to 6 more searches and 2 more fetches, several more minutes → a strategy brief, the hiring manager's public talks and writing if you give a name, and recent org context for the differentiator questions
- The hiring manager's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own career path
- Any recruiter prep note (focus areas, a pre-declared exercise or presentation) → a build section for that deliverable and confirmed coverage
- Something inspectable from the roadmap-input sessions, such as an agenda or a summary sent to product → the third evidence entry can move from medium toward high, and the caveat in A1 and C3 shrinks
- Your answers to the answer slots in F4, F5, F6 and F8 → those rows move from discovery or transferability to quoted evidence, and A3, C2, D2 and D3 become story-mapped
- How much prep time you have → a prioritised prep schedule at the top of the pack
