# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations, running the hiring-manager hour
**Format:** Friday, 60 minutes. Saltmarsh's careers page calls this the "Outage Hour": "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

- **Personas** describe *how* a question is asked (who is asking, and in what style). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: values. Does your past behaviour show Saltmarsh's *published* values?
  - **EXP**: experience deep-dive. Do the lines in your background hold up, and what exactly was yours?
  - **JD**: the job description. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Do you know what Saltmarsh is doing now?
  - **CASE**: a live problem. How do you structure and reason under time pressure?
- **Provenance labels:** `[grounded]` = traceable to your message, the JD or a cited source. `[inferred]` = derived from a source, with the derivation named. `[generic]` = a role-family pattern with no claim about Saltmarsh or you.
- **Answer slots** are instructions for the interview, not questions for me. They give you two honest branches: if you did the thing, say how in your own words. If you didn't, or it wasn't yours, say so plainly.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage: one evening before Friday

This is sized to tonight, since the interview is tomorrow. Do these in order:

1. **Rehearse C1 out loud three times** (two titles, then one shared calendar). This is the highest-ROI prep in the pack. Hold the line, then use the answer slot.
2. **Run the tabletop structure on A1 and A2 once, out loud, with a timer.** The first half of the hour is this format.
3. **Rehearse C2 (no in-app purchases) until the plain acknowledgment sounds calm.** Then the forward plan.
4. **Pick your three values stories** using the values cheat sheet. B3 is already mapped. B1 and B2 need you to choose one.
5. **Install Tidepool Tactics and Lantern Row and play each for 15 minutes.** These are the two titles named in Saltmarsh's Project Larkspur announcement. F2 and reverse question 2 get much stronger once you have.
6. **Choose three reverse questions** and read them aloud once.

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one title's weekly content-drop calendar, and your words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" makes a probe about other titles likely. If you worked on another title's calendar, say how, in your own words. If you didn't, say so plainly and stay with the main title's calendar. Your material also doesn't say what platform the title was on. If asked, say what it was |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Your material doesn't show which teams a content drop involved. Answer slot: if getting a drop out meant working with design, art, engineering or community, say who and what you needed from each, in your own words. If it didn't, say so plainly and stay with running the calendar. The JD asks for coordination, not line management, so the two are separate questions (see C3) |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your words: "I presented the monthly retention numbers to the studio head." That is a monthly report, not a review of a single event, and the bridge shouldn't stretch past it. Answer slot: if you reviewed how a particular drop performed, say what you looked at and who saw it. If reviews weren't yours, or didn't happen, say so plainly and stay with the monthly numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: you wrote it, and your QA team still uses it. It is a CV-style line with nothing inspected behind it, and your interviewer has a QA background (see Reading the interviewer), so expect a detailed probe (D2) |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer and two years of weekly content drops. It doesn't say whether the title was live-service for all four years. Answer slot: if your work was on a live game for longer than the two calendar years, say for how long and on what, in your own words. If not, say so plainly and stay with the two years of weekly drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. This is the strongest match in the pack: say it in your own words, cadence and duration included. Expect a probe on how the calendar actually worked (C1, B1) |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap at the JD's bar. Expect a probe on which measures they were and who produced them (D1). Presenting is not the same as computing, and the D1 slot keeps the two apart |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your quote already shows a written document in daily use. Reword only that: "The release checklist our QA team still uses is one I wrote." Let the interviewer draw the conclusion about your writing. Don't call the checklist proof of anything |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Live-events calendar for two mobile titles (F1) | C1, A5 |
| Coordinate design, art, engineering, community (F2) | C3, A1 |
| Own the post-event review and its KPIs (F3) | A4, D3 |
| Release checklist with QA (F4) | D2, B3 |
| 3+ years producing live-service (F5) | C5, F1 |
| Running a content calendar (F6) | C1, B1 |
| Player-retention metrics (F7) | D1, D3 |
| Clear written communication (F8) | B4, A3 |

---

## Reading the interviewer

Public professional footprint only. Source: one search result (see Sources). The talk itself wasn't fetched.

- **Career pattern:** Head of Live Operations at Saltmarsh Games. Previously a QA lead at a console studio.
- **Public theme:** a GDC 2026 talk, *Patch Notes Are a Promise*. Its stated argument: "a live team is judged by how often its patch notes describe what actually shipped."
- **What this suggests:**
  1. Release discipline is his native language. Your checklist line will land, and it will be probed for detail (D2).
  2. Expect a question about patch notes matching what shipped (B4). It echoes the published value *Ship the Patch Not the Promise*.
  3. In the outage tabletop, never promise a fix time you don't have (A3, E2). Promising one cuts against both his public theme and the value.
  4. Only quote his talk in a reverse question if you've watched it tonight. A question built on a one-line summary falls apart if he asks what you thought of it.
- **Mirror opportunity, shared vocabulary:** F4, "Wrote the release checklist our QA team still uses." You and he both work in QA-facing release vocabulary. This is shared work, not a shared career jump, so don't present it as one.

---

## Persona table

The loop source is Saltmarsh's careers page: one 60-minute hiring-manager interview, a live-incident tabletop and then a values conversation.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop: a simulated outage during a live event, with new facts dropped in as you go | **Highest.** The careers page names a tabletop as half the hour, and hiring managers tilt toward live problems anyway | Clarify, set the objective, triage, communicate, decide, record. Think aloud and name who you'd pull in |
| Values / Behavioral | The second half: the values conversation | **High.** The careers page names it. Saltmarsh publishes three values by name | One story or scaffold per value (see the cheat sheet). Use "we" for context and "I" for your part |
| Skeptic | Probes on scope: one title versus two, no in-app purchases, coordination | **Mid.** Hiring managers de-risk gaps. F1 and F2, plus the two negatives you stated, are the obvious ones | Rehearse C1 until it's boring. Give stated negatives plainly, then a concrete ramp plan |
| Data-Driven Prober | Digs into the retention numbers and the checklist | **Mid-low.** F7 invites it, and his QA background points to detail probes on F4 | Know exactly which parts were yours. Say plainly when someone else produced a number |
| Pressure | Interruptions inside the tabletop, such as an executive demanding a fix time | **Low-mid.** A simulated live incident can escalate by design. That's an inference from the format, not a documented feature | Pause, restate, hold the position the facts support. Concede uncertainty specifically |
| Conversational | Opening minutes, the "walk me through" question | **Low.** It's a short hour, but the opener is still scored | A 90-second arc built only from your four quoted lines |
| Peer Evaluator | — | **Not included.** The careers page describes a single hiring-manager hour, with no peer | — |

---

## Question banks

### A. Case / Strategist: the outage tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Ten minutes into a weekend live event, players start reporting they can't log in. Talk me through your first fifteen minutes." | CASE | [inferred] | Clarify first: which title, how many players, which platforms, whether it's the event or everything, and when it started. Set the objective: players first, and the event's fairness protected. Triage: who's on call in engineering, who owns the status page, and who in community is watching the channels. Communicate: the first player-facing message says only what you know ("we're aware, investigating, next update at a set time"). Decide nothing about compensation yet. Start a timeline log now, because the review will need it. Think aloud the whole way | The careers page names a simulated outage during a live event. This exact scenario is my construction, so it's `[inferred]`. CASE because it scores structure live and makes no claim about your past |
| A2 | "Engineering says the fix is two hours out, and the event ends tonight. Do you extend it?" | CASE | [inferred] | Don't answer yes or no first. Name the trade-off: players who lost time versus what's next on the calendar, reward pacing, and team capacity to support an extension. Name who decides with you (design for rewards, engineering for confidence in the fix, community for player sentiment). Give a recommendation and its condition: extend by the outage length, announced only once the fix is confirmed. This mirrors *Players Before Plans* without reciting it | The standard follow-on in a live-event outage. It tests whether you weigh the calendar against players, which one value names directly |
| A3 | "Community is asking for compensation and you don't know the cause yet. What do you post?" | CASE | [inferred] | Write it aloud in two sentences: what's affected, that you're investigating, and when the next update comes. No promised fix time and no promised compensation until it's decided. Then say what the next update will hold once you know more. This is *Ship the Patch Not the Promise* in practice, so let him notice that rather than announcing it | It tests written communication (F8) under pressure. His public theme and a published value both point here |
| A4 | "The outage is over. Walk me through the post-event review you'd run." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Give it as a plan: timeline from the log, player impact (who was affected and for how long), how the event performed against a comparable past event, root cause with engineering, actions with owners and dates, and the checklist change that would have caught it. You can say you presented the monthly retention numbers to the studio head, in those words, if he asks who you've reported to. Answer slot: the JD's "own the post-event review" makes a probe likely. If you reviewed a drop's performance before, say what it covered. If you didn't, say so plainly and present this as how you would run one | F3 is the requirement where your material is adjacent, not direct. The JD names ownership of the review, so it's JD-typed with CASE delivery |
| A5 | "Both titles want the same weekend for a major event. How do you sequence the calendar?" | CASE | [grounded] | Clarify: what each event is meant to achieve, how much the two player bases overlap, and what each event needs from art, engineering and QA. Then lay out options: stagger them, split the weekend, or run one major and one minor. Name the risk you'd protect against: two launches competing for the same QA and on-call capacity. Mention that Saltmarsh's Project Larkspur moves both titles to one shared events calendar from February 2027, so this becomes the everyday job | The JD's two-title line and the Larkspur announcement make this the real problem of the role. `[grounded]` because it rests on the JD and a cited company page, with no claim about your past |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar said one thing and the players said another." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Look inside the weekly content-drop calendar you ran for a drop where player response changed what happened. A good story needs: what players signalled, what you changed or argued for, and how it ended. Answer slot: if you made or pushed that call, say how, in your own words. If the call wasn't yours, say who made it and what your part was. If no such time comes to mind, say so plainly, then say how you'd handle it here | Maps *Players Before Plans* ("when the calendar and the players disagree, the players win"). F6 is the arena. The story's middle has to come from you |
| B2 | "When have you held something back from an announcement because it wasn't built yet?" | VAL | [grounded] | Selection scaffold. Pick a time an announcement, patch note or player message was changed or held because the work wasn't done. It needs a named thing, a reason, and what happened next. If no such time comes to mind, say so plainly, then say how you'd keep announcements tied to what has shipped (A3 is the live version) | Maps *Ship the Patch Not the Promise* ("we announce what is built, not what is hoped"). `[grounded]` on the fetched values page. It makes no claim about your past |
| B3 | "Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats your sentence states: you wrote the release checklist, and your QA team still uses it. Tell them in your own words. Answer slot: the value says every release leaves "the checklist better than it found" it, so expect a probe on how the checklist changed over time. If you updated it after a release taught you something, say what changed and why. If updates weren't yours, or it hasn't changed, say so plainly and stay with having written it | Maps *Leave the Build Greener* almost word for word. It's your best values story, so give it room |
| B4 | "How would you make sure our patch notes describe what actually shipped?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Give it as a process: notes drafted from what QA signed off, not from the plan; a final check against the build before posting; and one named owner for the notes. You can say you wrote the release checklist your QA team still uses, in those words. Don't claim it covered patch notes unless it did. Answer slot: if your checklist had a step for notes or announcements, say what it was. If it didn't, say so plainly and present this as how you'd add one | Scores the JD's "clear written communication" (F8) through the value *Ship the Patch Not the Promise* and his public theme. JD-typed because the requirement is what's scored |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the calendar for your main title. This job runs two, and from February they share one calendar. Why are you ready for that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Hold to what your quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Don't add titles, team sizes or scope. Answer slot: if you worked on another title's calendar, say how. If not, say so plainly and stay with the main title. Then give a forward plan, said as a plan and never as a past: how you'd learn both titles' rhythms in month one, what you'd ask design, engineering and QA for, and how you'd set up one shared view of both calendars ahead of February. **Follow-up 1:** "What breaks at two?" Name capacity collisions and shared QA, as analysis. **Follow-up 2:** "So you haven't done it?" Return to your quote and the slot. Don't fold into a self-criticism you didn't state, and don't inflate. The limit, named before he names it: your material covers one title's calendar | F1 is where the JD presses hardest on your background, and Larkspur raises the stakes. Some version of this will be asked. JD-typed because it scores the stated requirement |
| C2 | "Our events move to a season pass next year. Have you worked on a game with in-app purchases?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly first, in your own words: "I haven't worked on a game with in-app purchases." No softening, and no "but basically". Then a forward plan: what you'd learn first (how Saltmarsh's events feed the season pass, and how rewards pace across it) and how you'd learn it (playing both titles, sitting with whoever owns the pass). Hold that through one follow-up. Don't reach for adjacent monetization experience your material doesn't carry | Project Larkspur moves both titles to a season-pass model from February 2027. CO because it scores current strategy. A calm, rehearsed plain acknowledgment beats a defensive one |
| C3 | "This role coordinates design, art, engineering and community on every update. Who did you work with to get a weekly drop out?" | JD | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if a drop meant working with design, art, engineering or community, name who and what you needed from each, in your own words. If it didn't, say so plainly and stay with running the calendar. If he asks whether you've led a team, your own words cover it: "I haven't led a team." The role asks for coordination, not management, and it's fine to say that the JD's line is about coordination | F2 is the thinnest row against a headline requirement. `[inferred]` because the link from calendar to coordination is this pack's derivation |
| C4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Choose a real one. This pack reads your material as thinnest on F1 (two titles) and F3 (owning a post-event review). Answer slot: name the one you'd honestly pick and say why, in your own words. Then give a specific ramp plan. If you pick F3, you can say you presented the monthly retention numbers to the studio head, in those words, as the starting point. Don't pick a fake weakness | A classic Skeptic stem. A rehearsed, specific, non-defensive answer turns it into a credibility gain |
| C5 | "How much of your four years was on a live game?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if the game was live for more than the two calendar years, say for how long and what you did then, in your own words. If not, say so plainly: four years as an associate producer, the last two running the weekly content-drop calendar. Don't round up | F5 is the JD's years line. Your material doesn't say how much of the four years was live-service, and a vague answer here reads as evasion |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented monthly retention numbers. Which measures, and who produced them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which retention measures they were, in your own words. If you produced them, say how. If an analyst or a tool did, say so plainly and stay with presenting them. If you don't know how a figure was counted, saying "I don't know how it was counted" is an honest answer. If he asks what moved them, answer only what you actually know | F7. The JD's bar is "comfortable with", and this tests whether that holds up two levels deep. JD-typed because it scores the stated requirement through your line |
| D2 | "Walk me through the release checklist you wrote. What's on it, and how does QA use it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Premised on F4. Describe what's actually on it and how your QA team uses it, from memory and in your own words. Answer slot: the JD says "manage", so expect a probe on upkeep. If you kept it updated release to release, say how. If someone else maintains it now, say so plainly and stay with having written it. Practise this one aloud tonight: you need to be able to list its real sections | His QA background makes this a near-certain deep probe. JD because "manage the release checklist with QA" is listed |
| D3 | "How would you know whether an event actually helped retention, versus just spiking logins?" | CASE | [generic] | Structure: compare players who joined the event with a similar group who didn't, or with the same period around a comparable past event. Look past the event window to later retention, not just same-day activity. Then name the weakest assumption yourself: players who join events may already be your most engaged, so the comparison flatters the event. Naming that before he does is the move | Tests F3 and F7 as reasoning, not record. `[generic]` because it's an analysis pattern, not a claim about Saltmarsh or you |

### E. Pressure (inside the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Stop. The CEO's on the thread asking when it's fixed. What do you tell them, right now?" | CASE | [inferred] | Pause and restate it. Give what you know, what you don't, and when the next update comes. Don't give a fix time you don't have. If he pushes, say again that you'd commit to the next update time rather than a fix time. Concede only something specific: "If engineering gives me a confidence level, I'll pass it on with that label." | A plausible escalation inside a simulated outage. It's composure plus *Ship the Patch Not the Promise* |
| E2 | "Sixty seconds: why you over someone who's already run live ops on a monetized title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Use only your quoted facts: two years running the weekly content-drop calendar for your main title, and the release checklist your QA team still uses. Say plainly, "I haven't worked on a game with in-app purchases," then your learning plan from C2. Hold through one push by repeating the two facts. Don't add any third claim to compete | A time-boxed version of C1 and C2. Hold-then-concede is the scored behaviour |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through how you got here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these beats, in your own words: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; you wrote the release checklist your QA team still uses; you presented the monthly retention numbers to the studio head. Close on why this role, in your own words (Larkspur's shared calendar is a fair hook if it's genuinely why) | The opener is still scored. Every beat is one of your sentences, so nothing in it can be probed into collapse |
| F2 | "What mobile live-service games are you playing right now, and which event did you think was well run?" | CO | [grounded] | Answer slot: name a game you actually play and one event in it, and say what made it work. If you play Tidepool Tactics or Lantern Row tonight, you can say you played them and give one honest observation. If you don't play much mobile right now, say so plainly and talk about one you've looked at | The JD names "mobile titles", and this is the casual way that gets scored. A real, current answer is hard to fake and easy to prepare tonight |

---

## Values cheat sheet

Value names are from Saltmarsh's values page (fetched).

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | If the schedule and the player experience conflict, the players win | Scaffold, F6: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a drop where player response changed the plan, and say what your part was. If none comes to mind, say so plainly and give how you'd handle it (B1, A2) |
| Ship the Patch Not the Promise | Only announce what's actually built | Scaffold: pick a time an announcement or note was held or corrected because the work wasn't done. If none comes to mind, say so plainly, then walk through how you'd keep notes tied to what shipped (B2, A3, B4) |
| Leave the Build Greener | Each release improves the code and the checklist | Mapped, F4: "Wrote the release checklist our QA team still uses." Use the B3 answer slot for how it changed over time |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live ops from QA. What from your QA years shaped how this team runs releases?" | Tied to his own path. It turns the hour toward his expertise, and it's an opening for your checklist work |
| R2 | "When both titles move to one shared calendar in February, what will this role own in its first month?" | Shows you read the Larkspur announcement, and tells you whether the JD's two-title scope is about to change |
| R3 | "What does a good post-event review look like here? Which KPIs does it report, and who reads it?" | The JD makes you the owner of this. It tells you the bar, and it's the area where your material is thinnest |
| R4 | "How does the team track whether patch notes match what shipped?" | Echoes his GDC theme and a published value. Mention the talk by name only if you've watched it |
| R5 | "What does the release checklist with QA look like today, and what would you change in it first?" | *Leave the Build Greener* in question form, and it plays to your strongest row (F4) |
| R6 | "What would make the first live event I run here a success, from where you sit?" | Gets his success criteria directly, which you can use in your follow-up note |

---

## Prohibited claims

This pack won't coach these claims, whatever the pressure in the room.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-events calendars across multiple titles | Inflated form of F1 | F1's quote at its own scope. This pack's observation: your material says the main title. C1's slot stays inside that |
| Owned post-event reviews and their KPIs | Inflated form of F3 | F3's quote at its own scope. A4's slot asks only whether you reviewed a drop's performance |
| Built or analysed the retention metrics | Inflated form of F7 | "Presented the monthly retention numbers to the studio head." D1's slot asks who produced them |
| Managed QA's release process | Inflated form of F4 | "Wrote the release checklist our QA team still uses." D2's slot asks about upkeep |
| Four years producing a live-service game | Inflated form of F5 | F5's two quotes at their own scope. C5's slot asks how long the game was live |
| Led or managed the design, art, engineering or community teams | Negative you stated: "Never led a team" | "I haven't led a team." No slot |
| Has worked on monetized, in-app-purchase or season-pass events | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

**Provided:** the JD text and your background, both in your message.

**Searches:**
1. `Saltmarsh Games values` → https://saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` → https://saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` → https://saltmarshgames.com/news/project-larkspur (September 2026)
4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` → https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; not fetched)

**Fetches:**
1. https://saltmarshgames.com/values
2. https://saltmarshgames.com/careers/interviewing

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet: three values by official name. Themes for B1 to B4 |
| 2. `Saltmarsh Games interview process` | yes | Loop established: one 60-minute hiring-manager interview, an outage tabletop then a values conversation. Sets the persona weights, the A and E banks, and the values-round detection |
| 3. `Saltmarsh Games` strategy and recent news | yes | Project Larkspur: season pass and one shared calendar from February 2027. Feeds C1, C2, A5 and R2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, B4, R1 and R4. Taken from a search snippet; the talk wasn't fetched |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Recruiter call notes** (anything said about the tabletop or the values chat) → the A and E banks and the persona weights retuned to what was actually flagged.
- **Answers to the answer slots, told to me outside a drill** (what platform the puzzle title was on and how long it was live, which teams a drop involved, whether drop reviews were yours) → F1, F2, F3 and F5, plus C1, C3, C5 and A4, move from slots to story-mapped guidance.
- **A redacted copy of the release checklist** → F4 and F8 go from medium to high, and D2 is mapped to its real sections.
- **A redacted retention deck you presented** → F7 goes to high, and D1 is mapped to the measures you actually showed.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → the GDC talk's actual content, the two titles' recent event history and more Larkspur detail, for a grounding brief. With the interview tomorrow, it's worth it only if you have the evening.
- **A `tuesday-dossier.md`** → an evidence-derived highest-ROI objection and claim guardrails carried between sessions. This pack doesn't need one.
