# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Round: final round, sessions and interviewers not known. Built with no job description, no CV and no company research (web search was not available), so this is a role-family pack: every row is `[generic]`, and the upgrade menu at the end says what turns each part specific.

---

## How to use this pack

- **Personas** describe *how* a question arrives (who is asking, in what style). **Types** describe *what* is being scored. Rehearse both: the same question feels different from a friendly opener and from a time-boxed challenge.
- Type key:
  - **VAL**: behavioral or values: does your past behavior show the qualities the company says it values
  - **EXP**: experience deep-dive: do the claims on your CV survive scrutiny, and what was actually you
  - **JD**: role-driven: can you do the listed job, gaps included
  - **CO**: company and strategy: homework depth on the company itself
  - **CASE**: live problem: structure and reasoning on a problem from the role, done out loud
- Provenance labels: `[grounded]` traces to something you gave me or to cited research, `[inferred]` is derived from a representative source, `[generic]` is a role-family pattern with no claim about Stripe or about you. In this version every row is `[generic]`.
- Question IDs run A to H by persona. The letter F is skipped so that F1 to F7 always mean fit-snapshot rows.
- **Guidance is scaffolding, not a script.** Because I have none of your background yet, the guidance tells you *how to choose* a story, not *which* story. Fill it with what you actually did.

---

## Fit snapshot (worksheet version)

No JD and no CV were provided, so the requirements below are typical of product operations roles, written as plain prose rather than quotes, and every evidence cell is empty for you to fill. Use it as a worksheet: for each row, write one true sentence about your own work before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating product launches across functions: readiness, enablement, go-live checklists (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like a named launch, your specific part in it, and what readiness meant in practice. Pick a launch or rollout where you held part of the coordination; it needs a named product, a date or deadline, and something you yourself tracked or unblocked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Turning customer and support feedback into product inputs (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like a signal you collected or noticed, how it reached a product owner, and what happened to it. Pick a time feedback you handled reached someone who could act on it; it needs a source, a route and an outcome you can state honestly, including no outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Designing processes and tooling that keep working as volume grows (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like a before and after: how the work ran, what you changed, and how you knew it held. Pick a process you changed or set up; it needs the problem it solved and your part in the change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Defining and tracking operational metrics, with hands-on data work such as queries or dashboards (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like a number you reported, how it was counted, and what decision it informed. Pick one metric you tracked or analyzed yourself; be ready to say how it was counted and which assumption behind it is weakest. If you do not know how a figure was counted, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Working across product, engineering, support, sales and risk or compliance partners (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like a named partner team, a point where your goals differed, and how it was resolved. Pick a piece of work that needed another team; it needs a real disagreement or dependency and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritizing and driving work without formal authority, in ambiguous situations (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like competing requests, the call you made between them, and why. Pick a time you had to choose what not to do; it needs the options, your reasoning and who you told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Clear written communication: launch briefs, process docs, updates to leadership (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like a document you wrote that others used to decide or act. Pick one written piece of your own; know who read it and what it changed. If no such piece comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch coordination | A1, B3 |
| F2 Feedback into product | A2, A4, B4 |
| F3 Process design and scale | A4, A5 |
| F4 Metrics and data | A2, C3, D1, D2, D3 |
| F5 Cross-functional work | E1, E2, E3 |
| F6 Prioritization without authority | A3, E3 |
| F7 Written communication | none, and why: written work is usually judged from what you hand in or describe, not from one question. If your recruiter names a written exercise, it gets its own build section |

---

## Persona table

No loop source says how this final round is split, so the weights below rest on a pattern, not on Stripe's documented process. I've used the **big-tech structured** archetype as a fallback (recruiter, hiring manager, skills or case, behavioral or values, committee), which tilts toward Values/Behavioral and Case. A final round is often several sessions, so the weights are blended across the likely interviewers rather than tuned to one.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ops problems: plan a launch, diagnose a spike, design a process | High. Hiring managers lead with case work, and the fallback archetype tilts toward Case | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Values / Behavioral | "Tell me about a time" stories, often from someone outside the team | High. The fallback archetype usually has a values-style session somewhere in the loop | Pick stories where you can say what *you* did. Use "we" for context and "I" for your contribution. If a story has no clean ending, say so rather than supplying one |
| Skeptic | Quiet probing of gaps and motivation: why this, why now, what's weakest | Medium. Present in most final rounds, and the most predictable objection lands here | Rehearse the weakest-on-day-one answer until it's boring. Name the limit plainly, then give a concrete ramp plan |
| Data-Driven Prober | Asks how a number was counted and which assumption is weakest | Medium. Metrics are core to product ops, and ops interviewers often probe them | For any number you plan to mention, know how it was counted. If you don't know, say so. Name the weakest assumption before they do |
| Peer Evaluator | Seams between teams, credit, disagreement with equals | Medium. Final rounds often include a cross-functional partner such as a PM or engineer | Frame what you'd bring their team, propose principles for the seam, and pick a disagreement story that shows both spine and tact |
| Pressure | Time-boxed or devil's-advocate challenges | Low. Possible in any session; rarely a whole round | Pause and restate the question. Hold your position through two follow-ups, then concede specifically, never wholesale |
| Conversational | Friendly openers, "walk me through your journey" | Low as a style, but always present. Casual questions are still scored | A rehearsed 90-second arc. Never say "I think you've covered everything" at the reverse-question slot |

---

## Question banks

**Highest-ROI prep in this pack: C1**, "Which part of this role would you be weakest at on day one?" Without your background I can't name the specific objection you'll face, so C1 is the general form of it. Rehearse it deepest. Once you share a CV, this pick gets replaced with the real one.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new feature to business customers in several countries next quarter, and you own launch readiness. What do you need to know first, and what's your plan?" | CASE | [generic] | Clarify first: who the customers are, which countries, what "ready" means to the product owner, and the hard date. State the objective in one line. Segment by country, customer type and internal team (support, sales, risk or compliance). Approach: a readiness checklist per segment, named owners, and a go or no-go review. Metrics: readiness items closed, support contacts in the first weeks, adoption. Risks: country-specific requirements and a support team that hasn't been briefed. The question needs no claim about your past, so the guidance makes none | F1 is the core of most product ops roles and the most natural live case. CASE because it scores structure on a live problem, not a record |
| A2 | "Support tickets about one product doubled last month. Diagnose it." | CASE | [generic] | Clarify: doubled from what base, which ticket categories, and whether anything changed (a launch, a pricing or policy change, an outage, a new market). Split real-problem causes (a bug, confusing UX, a policy change) from measurement causes (new tagging, a new channel, volume growth). Say which data you'd pull first and why. Close with a short-term fix and a long-term fix, and the metric that tells you it worked. No claim about your past | Tests F2 and F4 together. Diagnosis cases are a common hiring-manager format for ops roles |
| A3 | "Product, sales and support each send you a top-priority request this week, and you can only do one. How do you decide?" | CASE | [generic] | Clarify each request's impact and deadline, and whether any is reversible or blocking. State your criteria out loud: customer impact, risk, how many people it unblocks, cost of delay. Choose one and say what you'll tell the other two and when. Challenge one premise, e.g. whether one could be cut in half or handed off. No claim about your past | F6 in a live form. The interviewer scores the criteria you state and how you tell the two you didn't pick, more than the pick itself |
| A4 | "Design a process for routing user feedback to product teams so it actually changes the roadmap." | CASE | [generic] | Clarify sources (support, sales, research, direct feedback) and who decides the roadmap. Structure it as intake, tagging, aggregation, a regular review with product owners, and closing the loop with whoever raised it. Metrics: share of top themes that get a decision, time to decision. Name one risk, such as volume drowning signal, and how you'd guard against it. No claim about your past | Covers F2 and F3. A design question checks whether you think about the loop closing, not just the intake |
| A5 | "A manual process that worked at 100 cases a week now has to handle ten times that. What do you do?" | CASE | [generic] | Clarify what the cases are, where the time goes and what errors cost. Map the steps, find the bottleneck, then choose between removing a step, standardizing, automating or adding people, with the trade-off for each. Pilot before rolling out, and measure throughput, error rate and time per case. No claim about your past | F3 at scale. Tests whether you diagnose before automating |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you actually said, and what happened next, including if nothing changed. Say "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values-round theme. Without Stripe's published values in hand, it's themed from the persona, not from the company |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer's need and a number you were measured on pointed different ways. It needs the metric, the customer situation and the call you made, with its cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common values theme that maps directly onto product ops trade-offs |
| B3 | "Leadership has fixed a launch date. Two weeks out, you find a readiness gap that would hurt customers. What do you do?" | CASE | [generic] | Size the gap first: who it hits, how badly, whether it can be fixed in time. Lay out options (delay, phased rollout, ship with a mitigation, ship as planned), recommend one, and say how and when you'd raise it and with whom. Hold the recommendation if pushed, and say what would change your mind. No claim about your past | Values content (candor, customer focus) delivered as a live case. It ties to F1. Tagged CASE because it asks for a decision, not a record |
| B4 | "Your team's process is beating its target, but you find users quietly working around it. What do you do?" | CASE | [generic] | Name the tension: the metric says it's working and the behavior says otherwise. Find out why the workarounds exist, decide whether the metric is measuring the wrong thing, and say who you'd bring it to. No claim about your past | Values-style judgment on a metric-versus-customer tension, tied to F2. CASE because it's hypothetical |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal.** Choose one real weakness against F1 to F7, the one you would rate lowest if you're honest, not a disguised strength. Say it plainly in one sentence, say what you'd do in the first 30 to 60 days to close it, and stop. On follow-up ("so you've never done X?"), hold the same plain wording and go back to the ramp plan, without adding experience to soften it and without falling into apology. If nothing in F1 to F7 feels weak, pick the one you have the least evidence for, because that's the one they'll probe | The objection that arrives in some form in nearly every final round. JD because it scores self-assessment against the role's requirements |
| C2 | "Why Stripe, and why product operations rather than product management?" | CO | [generic] | Two parts, about 60 seconds. Why the company: name something specific you've read in Stripe's own material and why it matters to you. I couldn't research it, so the specifics have to be yours. Why product ops: what you like about the operational side of product work, in your own words. Avoid putting PM down as the lesser option | The motivation probe. CO because company-specific homework is what separates answers here, and this pack couldn't supply it |
| C3 | "How would you handle the data side of this role: the metrics and the analysis?" | JD | [generic] | Pick the data work you've actually done and name its level plainly (spreadsheets, dashboards, queries, or none). Then say how you'd close whatever gap remains. If you haven't done hands-on analysis, say so plainly and describe how you'd work with an analyst or learn it. No claim about your past | F4 is a frequent screening point for ops roles. Asked without a premise, so either answer is honest |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you've reported in your work. Walk me through how it was counted." | EXP | [generic] | Choose a figure you'll mention anyway (from your CV or a story) and know: what was counted, from what source, over what period, and which part of the result was yours. If you don't know how it was counted, say so plainly. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4. Probers test whether headline numbers survive. Any figure on your CV is a target, so choose yours before they do |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it yourself, in your own words, before they find it. That turns a gotcha into credibility. If you don't know the assumptions behind the figure, say that, and say who would | The weakest-assumption move. The follow-up to D1 |
| D3 | "How would you measure whether a launch went well?" | CASE | [generic] | Clarify the launch's goal first. Split leading signals (readiness completed, support contacts, early adoption) from lagging ones (retention, revenue, satisfaction). Pick one primary metric and say what it misses. No claim about your past | F4 meets F1. Tests whether your metrics follow the goal |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Don't pretend to know their seam. Propose principles: who decides what, how you escalate, how often you sync. Then pick a disagreement with a peer from your own work. It needs the disagreement, how you handled it, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5. The peer is weighing whether you add to or take from their load |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a piece of shared work and say plainly what was yours and what was others'. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing probe tied to F5. VAL because it scores behavior, not skill |
| E3 | "A PM on my team wants to skip a readiness step you think matters. How do you handle it?" | CASE | [generic] | Ask why first: maybe the step doesn't fit this launch. Name the risk the step guards against, offer a lighter version, and agree on who owns the call. Escalate only if the risk is real and you can't agree. No claim about your past | F5 and F6 in a live, collegial form |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give two or three points in under a minute: what you'd bring from outside, and how you'd learn the internal context fast. Don't knock internal candidates. Hold the points if challenged. If pushed, concede something specific ("they'd know the systems faster") without folding | Composure under a time box. JD because it tests fit to the role |
| G2 | "That result: how much of it was actually you?" | EXP | [generic] | It can follow any story you tell. For each story, know in advance exactly which part was yours. Answer with that, plainly. If the honest answer is "less than it sounded," say so. That's the rehearsal, and it reads as credible | Attribution probe. Pressure interviewers use it to check honesty, so the answer they reward is the precise one |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc you've rehearsed out loud: where you started, the one or two moves that led toward operations work, and why this role is the next step. Every clause should be something you'd stand behind under a follow-up | Nearly every session opens here. Casual, but it sets the frame for everything after |
| H2 | "What tools or automation are you playing with in your ops work these days?" | JD | [generic] | Name only what you actually use, at the level you use it. If it's nothing new, say what you'd like to learn and why. No claim about your past | Casual register, but it's scoring F3 and F4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a great first 90 days look like in this role, and how would you know the hire worked?" | Shows you're thinking about delivery, and tells you what you'd actually be measured on |
| R2 | "Where's the line between product ops and product management here today, and where does it get blurry?" | Shows you understand seams exist, and tells you which half of the job you'd actually be doing |
| R3 | "What's an operational problem the team has been meaning to fix but hasn't had capacity for?" | Invites them to describe the real work, and gives you a concrete thing to react to in later sessions |
| R4 | "How does user feedback reach product decisions today, and where does it get lost?" | Ties directly to a core product ops responsibility and shows you've thought about the loop closing |
| R5 | "What's the hardest trade-off this team made in the last six months?" | Gets you current context that research couldn't, and signals judgment over process |
| R6 | "How are the different sessions in this final round weighed against each other?" | A fair process question, and the answer tells you where to put your energy |

---

## Prohibited claims

There are no entries yet. This list holds the stretched versions of things you've said, and since I don't have any of your sentences, there's nothing to stretch. That doesn't mean everything is safe to say. It means the pack had nothing to check against. Once you share a CV or a few lines about your background, this section lists the wordings this pack won't coach you toward, each paired with its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| none yet | No candidate material provided | Not applicable until your background is in hand |

---

## Sources

Provided documents: your message ("Final-round interview at Stripe for a Product Operations Manager role").

Searches sent, all refused because web search permission wasn't granted:

- "Stripe operating principles": refused
- "Stripe interview process product operations final round": refused
- "Stripe Product Operations Manager job posting": refused
- "Stripe news 2026 strategy": refused

No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values or operating principles | unavailable | The one search was refused. It would have produced a values cheat sheet with the official principle names, and VAL questions themed on them |
| 2. Stripe interview process, product operations | unavailable | The one search was refused. It would have named the actual sessions and replaced the fallback archetype in the persona table |
| 3. Stripe strategy and recent news | unavailable | The one search was refused. It would have produced at least one CO or CASE question on current strategy, and specifics for C2 |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. The interviewer section is absent |
| 5. Representative Product Operations Manager JD | unavailable | The one search was refused. It would have turned F1 to F7 from role-family prose into quoted requirements labeled `[inferred]` |

---

## Upgrade menu

- The job description text → F1 to F7 become quoted, `[grounded]` requirements, and missing requirements get their own JD questions
- Your CV, or a few lines about your background → the worksheet becomes a real fit snapshot, guidance becomes story-mapped to your own sentences, C1 is replaced by the specific objection you're most likely to face, and the prohibited list fills in
- Allowing web search → the default research pass: Stripe's published values (a values cheat sheet), the documented interview loop, and current strategy for CO questions
- A deeper research pass, on request → up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief, interviewer talks or writing, role-specific loop reports and recent org context
- If your final is several sessions, the schedule and who runs each one → a mini-pack per session with its own persona weights and bank
- Interviewer names → a section on reading each interviewer from their public professional footprint, plus a reverse question tied to their career path
- Your recruiter's prep email → coverage of any stated focus areas, and a build section for any declared case, presentation or written exercise
- How much prep time you have → a prioritized prep schedule sized to that time
- For any story you plan to tell, an artifact that shows it (a launch plan, runbook, dashboard or process doc you wrote) → the confidence on that row can rise from medium to high
- A tuesday-dossier.md from an earlier underwriting session → verified evidence, binding limits on weak areas, and a named highest-ROI objection. Useful, not required
