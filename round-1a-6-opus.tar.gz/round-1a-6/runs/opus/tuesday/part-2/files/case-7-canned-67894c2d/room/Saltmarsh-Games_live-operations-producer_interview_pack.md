# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations, the hiring manager for this round
**Round:** The "Outage Hour". Saltmarsh's interviewing page describes it as "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."
**When:** Friday, which is tomorrow

## How to use this pack

Two separate things shape each question. **Personas** describe how a question gets asked: the tone and the pressure. **Types** describe what the interviewer is scoring:

- **VAL**: values alignment, checked against Saltmarsh's three published values
- **EXP**: a deep dive on your experience, testing what was actually yours
- **JD**: a requirement from the job description, gaps included
- **CO**: company and strategy knowledge
- **CASE**: a live problem set inside the role (this round's tabletop is all CASE)

The answer guidance is scaffolding, not a script. Wherever it describes your past, it uses only your own sentences, quoted. Wherever your material is silent, you'll see an **answer slot**. An answer slot is not a gap for you to fill with something impressive. It gives you two honest branches, and both are good answers.

## Prep triage: one evening

| Order | What | Where | Time |
|---|---|---|---|
| 1 | Say B1 out loud three times, including both follow-ups. It is the highest-ROI prep in this pack | B1, F1, F2 | 30 min |
| 2 | Talk through the outage tabletop out loud with a timer: first 15 minutes, the extend-or-compensate call, the first player post | A1, A2, A3 | 30 min |
| 3 | For each of the three values, choose a story or decide on your honest branch | C1, C2, C3, values sheet | 20 min |
| 4 | Practise the plain answer on in-app purchases, and be ready to say how your retention numbers were counted | B2, D1 | 15 min |
| 5 | Pick three reverse questions, including the one about Tobias's own path | Reverse questions 1, 2, 3 | 10 min |

Everything else in the pack is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one title's weekly content drops, not a live-events calendar for two titles, and your words should stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: because the JD names two titles and live events, expect a probe on what the calendar held. If it included timed events or anything beyond content drops, say what, in your own words. If it didn't, say so plainly and stay with the weekly drops |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message and "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Running a calendar doesn't show which teams you worked across, so the pack doesn't assume any. The JD asks you to coordinate, not to lead. "I haven't led a team" is a true answer to a different question. Answer slot: if any of those four teams fed into your content drops, say which ones and what part of coordinating them was yours, in your own words. If none did, or the coordinating wasn't yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting a monthly report is next to running a post-event review, but it isn't the same thing. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review line makes a probe likely. If you ran any review after a content drop, say what it covered. If you didn't, say so plainly and stay with the monthly numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist sits next to managing it release by release. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you kept it updated or ran through it with QA on each release, say how. If you didn't, say so plainly and stay with writing it. A redacted copy would be the strongest proof you could bring |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The four years meet the length requirement. Your material doesn't say in those words that the main title was a live-service game. Answer slot: if it was, say so in your own words. If it wasn't, say so plainly and describe the weekly content drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: weekly, main title, two years. It's a single sentence with nothing behind it yet, so expect a probe |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in what the JD asks for. Expect to be asked which metrics they were and how they were counted (D1). If the counting wasn't yours, saying so is a strong answer |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [inferred] | presentation | The checklist is a piece of writing, and the team it was written for still uses it. You can say exactly that: "I wrote the release checklist, and our QA team still uses it." |
| F9 | Not in the JD. A Saltmarsh news result says Project Larkspur moves both titles to a season-pass model with one shared events calendar from February 2027 | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | This is a gap you stated yourself, and wording can't close it. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, framed as a plan and never as something in your past |

## Reading the interviewer

These points come from public professional footprint only. The source is one search result for a GDC 2026 talk listing, which I saw as a snippet and did not fetch.

- **Career pattern:** Head of Live Operations at Saltmarsh, and previously a QA lead at a console studio.
- **Public theme:** his talk is "Patch Notes Are a Promise". Its stated argument is that "a live team is judged by how often its patch notes describe what actually shipped."
- **Implications:**
  1. Release discipline is his home ground, so expect real depth on the checklist (D3, E2).
  2. In the outage tabletop, he will likely score honest player communication: what you say, and what you refuse to promise (A3). This matches the "Ship the Patch Not the Promise" value.
  3. He has worked with QA from the inside, so overstating your role with QA is the claim most likely to be caught.
- **Mirror opportunity (shared vocabulary, not a shared career jump):** the release checklist. Your side of it is F4: "Wrote the release checklist our QA team still uses." Say it in those words and let him ask more.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop: a simulated incident during a live event | Highest. The interviewing page says the first part of the hour is this tabletop, and a hiring manager is buying capability | Clarify, then stabilise, then communicate, then decide, then review. Say your structure out loud before you use it. Challenge one premise respectfully |
| Values / Behavioral | The second half of the hour: the values conversation | High. The loop source names it, and Saltmarsh publishes three values by name | One story or one honest branch per value. Use "we" for context and "I" for your contribution. Where your material has no story, say so plainly rather than inventing an ending |
| Skeptic | Probes on scope (one title to two, four disciplines) and on monetization | High. Hiring managers de-risk gaps, and F1, F2 and F9 are the gaps | Rehearse B1 until it bores you. Bridge only from your quoted sentences, name the limit, and give a concrete ramp plan |
| Data-Driven Prober | How the retention numbers were counted, and what's on the checklist | Medium. His QA background and the JD's KPI line both point here | Know what you can and can't say about how each number was counted, and say plainly where you don't know |
| Pressure | The clock inside the tabletop, and "how much was actually you" | Medium-low. The incident format brings time pressure even from a friendly interviewer | Pause, restate the question, hold through two follow-ups, then concede the specific thing that's true |
| Conversational | The opening few minutes | Low but scored. A 60-minute single round still opens with "walk me through" | A 90-second arc built only from your four sentences |
| Peer Evaluator | Seams between engineering, community, design and art | Low. Tobias isn't a peer, but the JD's coordination line brings seam questions | Talk about seam principles rather than claiming to know Saltmarsh's actual seams |

## Question banks

### A. Case / Strategist: the outage tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's hour two of a weekend event on one of our titles and players can't log in. Walk me through your first fifteen minutes." | CASE | [grounded] | Say the structure out loud first. **Clarify:** which title, which regions, the event only or the whole game, and when it started. **Stabilise:** reach engineering on-call and confirm who owns the fix. **Communicate:** get the community team to post what's known, plus when the next update will come. **Decide:** whether to pause the event clock. **Record:** a timeline from minute one, which will feed the review. This question needs no claim about your past, so the guidance makes none | The interviewing page names this exact format. CASE because it scores structure under a live problem, not a record |
| A2 | "Engineering says the fix is four hours away and the event ends in two. Extend it, rerun it, or compensate players?" | CASE, VAL | [grounded] | Lay out all three options and their costs: extending moves the next calendar slot, rerunning costs art and design time, compensating costs economy balance. Name the data you'd want first: how many players lost progress and how far they got. Make a call, then concede what you'd revisit. The "Players Before Plans" value says "when the calendar and the players disagree, the players win". Use it as reasoning, not as a slogan | The most likely follow-up inside the tabletop. VAL as a second tag because the published value applies directly |
| A3 | "What does the first player-facing post say in the first thirty minutes, and what does it not say?" | CASE, JD | [grounded] | **It says:** we know, what's affected, what we're doing, and when the next update is. **It doesn't say:** an ETA you don't have, or compensation that hasn't been decided. That follows "we announce what is built, not what is hoped." Offer to draft the first line out loud. This is the JD's "clear written communication" tested live | It covers the written-communication requirement and the value at once. Tobias's talk theme makes honest comms a likely scoring point |
| A4 | "The outage is over. Walk me through the post-event review you'd run." | JD, CASE | [grounded] "Presented the monthly retention numbers to the studio head." | **Structure:** the timeline, then player impact (event participation, retention of affected players against unaffected ones, support tickets, sentiment), then the root cause and its owner, then what changes on the release checklist, then who reads the review. If you bring up your own past, keep it at "I presented the monthly retention numbers to the studio head." Answer slot: if you have run a review after a content drop, say what it covered. If you haven't, say so plainly and describe how you'd run this one | Covers the JD's post-event review requirement (F3). The case shape lets you show the skill without claiming a record you don't have |
| A5 | "Both titles want the same week for their biggest event next quarter. How do you plan the calendar?" | CASE, JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify each event's goal and its fixed dates. Look at capacity across art, engineering and QA, and at the player overlap between the two titles. Then sequence the events, or deliberately run them together, and say which metric decides. If you draw on your own calendar, keep it at its scope: one title, weekly content drops, two years. Answer slot: the JD names two titles, so expect a probe. If your calendar ever had to fit around another title or a competing priority, say how. If it didn't, say so plainly and stay with the one title's calendar | This is the scope jump in F1, asked as a live problem. Larkspur's shared events calendar makes it timely |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This job is live-events calendars for two titles, with design, art, engineering and community on every update. What in your background says you can run that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." | **The highest-ROI rehearsal in this pack.** **Hold:** "For the last two years I ran the weekly content-drop calendar for our main title." **Name the limit before he does:** it was one title. Answer slot: the JD's coordination line makes a probe likely. If any of those teams fed into your drops, say which ones and what part of coordinating them was yours. If none did, or that part wasn't yours, say so plainly and stay with the calendar. **Follow-up 1, "But one title?":** go back to the same sentence. Don't add to it. **Follow-up 2, "Have you led a team?":** "I haven't led a team." Then point out that the JD asks for coordination, and give your ramp plan as a plan: for example, meet each discipline's lead in week one and map how an update moves through them. Concede the scope. Don't concede the calendar | F1 and F2 are where this role presses hardest, so the objection will come in some form. JD because it scores the stated requirement |
| B2 | "We're moving to a season pass. What's your experience with in-app purchases?" | JD, CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | "I haven't worked on a game with in-app purchases." Say it plainly and early. Then give a learning plan, framed as a plan: for example, pairing with whoever owns monetization, and studying how season-pass progression lines up with the event calendar. Don't claim monetization knowledge and don't make the gap sound smaller | F9's stated gap, which becomes urgent because of Larkspur. A rehearsed plain answer beats a defensive one |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name one real weakness. The honest candidate is in-app purchases: "I haven't worked on a game with in-app purchases." Add one concrete step you'd take to close it. Don't pick a fake weakness | A classic Skeptic stem. It rewards calibrated candour, which is exactly what F9 needs |
| B4 | "Why this role, and why now?" | EXP | [generic] | Give your actual reason for leaving and what draws you to this role, in your own words. Nothing in the pack supplies a reason for you. Something specific to this role, such as owning a calendar across two titles, lands better than a general wish to grow | Motivation-consistency is the Skeptic's core probe. `[generic]` because your material gives no reason yet |

### C. Values / Behavioral: the values conversation

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: choose a time from your two years on the weekly content-drop calendar when a player signal changed or held a drop. The story needs the signal, what was decided, and which part was yours. If no such time comes to mind, say so plainly, then give the nearest example you do have, or explain how you'd handle it here | "Players Before Plans" is a published value. Your calendar is where a story could come from, but your material doesn't say one exists |
| C2 | "When have you pushed back on announcing something before it was built?" | VAL | [grounded] | Selection scaffold: choose a time you held back, or argued to hold back, an announcement or a patch-note line until the thing had shipped. It needs the stake and what you said. If no such time comes to mind, say so plainly, then explain how you'd handle it, for example by using A3's "what the post does not say" | "Ship the Patch Not the Promise", and the theme of Tobias's talk. Expect this one |
| C3 | "Leave the Build Greener: what have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are the ones your sentence states: you wrote the release checklist, and your QA team still uses it. Tell it in your own words. Answer slot: the value says "the checklist better", so expect a probe on what came before. If there was an earlier checklist or process, say what you changed and why. If there wasn't one, say so plainly and describe what you wrote | Your strongest values match. The published value names the checklist itself |
| C4 | "Tell me about a time you had to give leadership numbers they didn't want to hear." | VAL, EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if any month's retention numbers you presented to the studio head were bad news, say how you presented them and what happened next. If none were, say so plainly and describe how you presented the numbers. Don't invent a bad month | A persona stem (an unpopular truth for leadership). F7 is the only material where such a story could live |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. Which metrics were they, and how were they counted?" | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name the metrics you presented, in your own words. Answer slot: if you calculated them, say how they were counted and which assumption you'd defend least. If someone else produced them, say so plainly and describe what you presented and how. "I don't know exactly how they were counted" is an honest branch | F7 and the JD's retention requirement. A presenter who is clear about where the numbers came from beats one who claims the maths |
| D2 | "Which KPIs go in a post-event review, and which one would you trust least?" | JD, CASE | [grounded] "Presented the monthly retention numbers to the studio head." | **Candidate KPIs:** event participation rate; retention of participants compared with non-participants; session counts; support contacts; once the season pass lands, pass progression and revenue too. **Trusted least:** the retention lift, because players who join events were likely to stay anyway, so the comparison flatters the event. If you mention your past, keep it at your sentence | The JD's "own the post-event review and the KPIs it reports". Naming the weakest KPI is the move a prober rewards |
| D3 | "Walk me through the release checklist you wrote. What's on it, and why is it still in use?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it. Describe what's on it, in your own words. Answer slot: if you updated it with QA across releases, say how. If you didn't, say so plainly. Explain why you think it's still in use in your own words, and say it as your view, not as a fact | An ex-QA lead will go two levels deep here. The JD's checklist line raises the maintenance probe |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who's already run live ops on a monetized game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." and "Wrote the release checklist our QA team still uses." | Pause and restate the question. **Concede first:** "I haven't worked on a game with in-app purchases." **Then hold:** two years running the weekly content-drop calendar for your main title, and the release checklist your QA team still uses. Stop at 60 seconds. If pushed, hold once more on those two facts, then concede the specific thing that's true | Stress on F9. The hold-then-concede structure is what's scored here |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | **Hold:** "I wrote the release checklist our QA team still uses." Answer slot: if others contributed sections or edits, say who and what, plainly. If it was all yours, say so without hedging | An attribution probe on your strongest claim. An interviewer from QA will test it |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "So, walk me through your journey." | EXP, JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc: four years as an associate producer at a puzzle-game studio; for the last two, you ran the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. Close with why this role (B4's answer). Answer slot: if the main title was a live-service game, say so here | Covers the JD's 3+ years requirement (F5). The opener is scored even when it feels casual |
| F2q | "What are you playing at the moment? Any live event you thought was really well run?" | CO | [generic] | Your honest answer. Choose one event and say one specific thing that made it work and one thing you'd change. Don't name a game you haven't played | Rapport questions about the JD's core topic are still scored |

### G. Peer seams

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Engineering wants to cut a feature from Thursday's update, and community has already teased it. What do you do?" | CASE, VAL | [grounded] | Confirm the facts with engineering: what's cut, and whether that's final. Agree a correction with community that says only what will ship. Update the calendar and the checklist. Afterwards, raise how teasers get approved. "We announce what is built, not what is hoped." | The JD's coordination line combined with a published value. A seam problem asked as a decision |
| G2 | "Design and art disagree about what goes into the next update. How do you settle it?" | CASE, JD | [generic] | Bring it back to the update's goal and the player. Get each side's constraint stated plainly. Decide, or escalate with options and a deadline. Record the decision. Talk about principles rather than claiming you know Saltmarsh's process | The JD's "coordinate design, art, engineering and community teams" (F2) as a live problem |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A5, B1 |
| Coordinate design, art, engineering and community | B1, G1, G2 |
| Own the post-event review and its KPIs | A4, D2 |
| Manage the release checklist with QA | D3, C3, E2 |
| 3+ years producing live-service games or apps | F1q, B1 |
| Experience running a content calendar | A5, B1, C1 |
| Comfortable with player-retention metrics | D1, D2, C4 |
| Clear written communication | A3, G1 |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and player needs conflict, side with the players | Scaffold (C1). F1's evidence is the place to look: "I ran the weekly content-drop calendar for our main title for the last two years." Choose a moment where a player signal changed a drop. If there was none, say so plainly and describe how you'd decide |
| Ship the Patch Not the Promise | Announce only what has actually been built | Scaffold (C2). Choose a time you held back an announcement until the thing shipped. If there was none, say so plainly and walk through how you'd handle it (A3, G1) |
| Leave the Build Greener | Each release should leave the code and the checklist in better shape | F4: "Wrote the release checklist our QA team still uses." (C3) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You moved from QA lead to heading live ops. What from QA still shapes how your team ships?" | It's tied to his own path, and it connects naturally to your checklist (F4) |
| 2 | "Larkspur moves both titles onto one shared events calendar from February. What does this role own during that transition?" | It shows you've done current homework, and it pins down the scope of the job |
| 3 | "Who reads the post-event review today, and what has changed because of one?" | It asks about the JD's KPI ownership, and it tells you whether the reviews actually get used |
| 4 | "What would you want the release checklist to do that it doesn't do today?" | It echoes "Leave the Build Greener" and speaks to his QA background |
| 5 | "With the season pass coming, how will this role work with whoever owns monetization?" | It faces F9 directly and shows you're thinking about the seam |
| 6 | "What would a strong first 90 days look like for this producer?" | It lets you check your ramp plan against what he actually expects |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that your material describes one title's weekly content drops |
| Led a team, or led cross-functional teams | A negative you stated (F2, F9) | "I haven't led a team." |
| Owned post-event reviews or KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. A4's slot stays inside what you did |
| Built or calculated the retention analysis | Inflated form of F7 | "I presented the monthly retention numbers to the studio head." D1's slot lets you say who counted them |
| Managed QA's release process | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Has worked on in-app purchases, monetization or a season pass | A negative you stated (F9) | "I haven't worked on a game with in-app purchases." No slot |

## Sources

**Provided:** your message, which included the JD text and your background.

**Searches**
- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games mobile studio news 2026` returned https://saltmarshgames.com/news/project-larkspur (snippet only, not fetched)
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only, not fetched)

**Fetches**
- https://saltmarshgames.com/values: the three values and their definitions
- https://saltmarshgames.com/careers/interviewing: the Outage Hour format

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, the C bank, and A2, A3 and G1. Three values by name |
| 2. `Saltmarsh Games interview process` | yes | Established the loop as a single 60-minute hiring-manager round: an outage tabletop, then values. Set Case and Values as the top persona weights |
| 3. Saltmarsh strategy and recent news | yes | Project Larkspur. Moved B2, A5, F9 and reverse questions 2 and 5 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, D3 and E2 depth, reverse question 1. From a snippet only |
| 5. Representative JD | skipped | You supplied the JD |

## Upgrade menu

- Deeper research (L2): up to 6 more searches and 2 more fetches, taking several more minutes. It would fetch the Larkspur announcement and Tobias's talk page, so B2, A5 and the interviewer read rest on full pages rather than snippets
- Notes from your recruiter call: any stated focus areas for the Outage Hour would retune the A bank
- Your CV text: more F rows become specific, and F1q's arc gains detail you've actually written down
- Your answers to the answer slots, especially which teams fed your drops, how the retention numbers were counted, and whether the main title was live-service: these upgrade F2, F5 and F7, and with them B1, D1 and F1q
- A redacted copy of your release checklist: the domain artifact that would raise F4 and F8 from medium to high
- A `tuesday-dossier.md`, if you have one: verified evidence and a named objection would replace the pack's inferred ones
