# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel. **Deepa**, VP Partnerships (your future manager), and **Ross**, Commercial Director.
**Format (the recruiter's words):** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."
**Built on:** your message and the recruiter's email. There's no JD, no CV and no web research behind it, because every search was refused (see Sources). The market report you read isn't in here either, since I haven't seen its contents.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: who's asking and in what register. **Types** describe *what* is being scored.
- Type tags:
  - **VAL**: behaviour against values
  - **EXP**: whether your own claims hold up
  - **JD**: the job as listed
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem, solved out loud
- Provenance labels:
  - `[grounded]`: comes from your message or the recruiter's email
  - `[inferred]`: a derivation, with its basis named
  - `[generic]`: a role-family pattern that makes no claim about Kelverton
- Guidance is scaffolding, not a script. Wherever a cell says **answer slot**, the material you gave me doesn't settle the point. Answer it from what actually happened, in your own words, and either branch is an honest answer.

---

## Prep triage: 4 hours

| Order | Block | Time | What "done" looks like |
|---|---|---|---|
| 1 | The POV (Graded deliverable, below) | 90 min | One thesis chosen, its concession written, the operator close drafted, and the whole 13–14 minutes rehearsed aloud twice against a timer |
| 2 | B1, the quota objection (highest-ROI prep) | 40 min | The plain acknowledgment said without apologising, plus the hold through two follow-ups. Rehearse it out loud until it's boring |
| 3 | The £4M and 6→40 numbers: C1, C2, C3, D1 | 30 min | You can say how each figure was counted, what it's sensitive to, the assumption you'd defend least and which part was yours, or say plainly where you don't know |
| 4 | Ross's commercial cases: C4, D2, D3 | 40 min | A spoken structure for partner economics, and a way to answer "what number would you sign up to" without inventing one |
| 5 | Deepa's follow-ups A1–A5, plus the E1 arc | 30 min | A skim of A1–A5, and E1 told aloud in 90 seconds |
| 6 | Reverse questions | 10 min | Three picked, in order |

Everything else in this pack is insurance.

---

## Fit snapshot

There's no JD, so the requirements come from two places. Some are the recruiter's own words, quoted, which makes them `[grounded]`. The rest are partnership-role patterns written as plain prose, which makes them `[generic]`. Every quote about you comes from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | You ran a channel at a payments company. That's adjacent to rail operator partnerships, not the same thing. Keep the quote at its own scope: "For the last four years I ran the ISV channel at a payments company." Answer slot: the brief asks where you'd *take* the partnerships, so expect "what from that channel would you reuse here?" If a specific practice of yours transfers, name it and say what was yours. If it doesn't transfer, say so plainly and say what you'd do differently |
| F2 | "land on what it means for the operators themselves" — recruiter | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | It's bus and light rail network planning, not heavy rail. "From the other side" is your phrase, so keep it and don't widen it. Answer slot: the operator close invites "who were your clients?" If you worked with or for operators, say so in your own words. If your clients were authorities or others, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Influenced revenue is commercial evidence, but it isn't revenue you owned. Use your own word, *influenced*, every time. Answer slot: Ross's push makes "how was the £4M counted?" near-certain. Say how it was counted and which part was yours. If you don't know how it was counted, say so |
| F4 | Partner roles at this level often carry a revenue target | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You stated this gap and wording can't close it. Words: "I've never carried a direct quota. My numbers have been influenced revenue." Then how you'd take one on, said as a plan and never as a past |
| F5 | Selling into the client's own industry, here rail | "Never sold into rail specifically" — your message | none | [grounded] | capability | You stated this one too. Words: "I haven't sold into rail." Don't add anything that makes the gap sound smaller |
| F6 | Understanding the operators' world (planning, constraints, priorities) | "bus and light rail network planning, so I know the operator world from the other side" — your message | medium | [grounded] | transferability | This is real adjacent knowledge at its own scope: bus and light rail planning. Don't let it become "rail operations" or "TOC experience". This is a `[generic]` requirement, so there's no answer slot. Let F2's slot carry the probe |
| F7 | Building and scaling a partner programme | "took it from 6 partners to 40" — your message | medium | [grounded] | none | Your quote already says this in partnership terms. Expect a probe because nothing has been inspected behind it. Lead with the count exactly as you gave it, 6 partners to 40, and never widen it to "built from scratch" |
| F8 | Senior stakeholder management with clients and partners | none given | none | [generic] | discovery | Strong evidence here is a named senior counterpart, a moment where interests conflicted, and a relationship still intact afterwards. Selection scaffold: pick a time from the ISV channel or your consulting years that has those three things. If none comes to mind, say so plainly and give the nearest thing your material does carry, or how you'd handle it |
| F9 | Seniority for a "Senior" title | "9 years in partnerships" — your message | medium | [grounded] | none | Your quote already covers this. Say the tenure as you gave it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 POV on operator partnerships | Graded deliverable, A1, A2, A3, A5 |
| F2 Operator close | Graded deliverable, A4, B3 |
| F3 Commercials | C1, C3, C4, D1, D3 |
| F4 Direct quota | B1, D2 |
| F5 Selling into rail | B2 |
| F6 Operator world | B3, A4 |
| F7 Programme building | C2, E1 |
| F8 Senior stakeholders | V1, V2 |
| F9 Seniority | E1, B4 |

---

## Graded deliverable: the 15-minute POV

**Brief (the recruiter's words):** "where you'd take our operator partnerships over the next 18 months … land on what it means for the operators themselves."

### What you can build on about yourself

- **F1:** "last 4 at a payments company running the ISV channel"
- **F7:** "took it from 6 partners to 40"
- **F3:** "roughly £4M of influenced revenue"
- **F2:** "bus and light rail network planning, so I know the operator world from the other side"

Use these at their own scope. Describe what you did and let Deepa and Ross draw the conclusion. "That channel proves I can do this" is a claim they'll test, so don't say it.

### The market report: differentiate, don't recite

The panel's own strategy team wrote it. Reading it back to them scores as homework at best, and you'd be teaching them their own document. Use this move: name **one** point from the report you agree with, to show you've read it. Then name **one** place you'd go further or differently, and say why. Take any figures you use from the report exactly as it states them.

### Thesis options: pick one to lead, keep one in reserve

| Thesis | Each one's concession (mandatory) | Provenance |
|---|---|---|
| T1. Build an integration ecosystem around the operator: bring in the software partners operators already run beside scheduling, so the operator gets joined-up data rather than another vendor to manage | Every integration costs the operator's own IT time, and in a narrow market a partner can also be a competitor. Say how you'd choose which partners first | [generic] |
| T2. Treat a small number of operators as design partners, giving them early access and influence on the roadmap in exchange for references and co-developed use cases | Design partners can drift into bespoke work, and other operators may read it as favouritism. Name the guardrail, such as a published programme with written criteria | [generic] |
| T3. Go through the advisers operators already trust, such as consultancies and integrators, so Kelverton is in the room earlier | You give up margin and some customer intimacy, and those advisers serve several vendors. Say what you'd keep direct | [generic] |

**Differentiation against the consensus answer** `[generic]`: the obvious answer from someone with your background is "recruit lots of partners". Your F7 story is breadth, so the panel will expect breadth from you. Saying where breadth *doesn't* fit scores as judgment.

**The anti-pick** `[generic]`: name one thing you would *not* do in the first 18 months, with a reason. One candidate is a broad partner-recruitment drive before two or three partnerships are showing operator value. If the report says the operator base is concentrated, tie the anti-pick to that. If the report doesn't say so, use your own reasoning and don't attribute it to the report.

### A 15-minute shape

| Minutes | Beat |
|---|---|
| 0–1 | The frame: what operator partnerships are *for*, in one sentence |
| 1–3 | One point from the report you agree with, then where you'd go further |
| 3–10 | Your lead thesis across three phases: 0–6, 6–12 and 12–18 months. Give each phase one move, one measure and the concession |
| 10–12 | The commercials, before Ross asks: how partners earn, how Kelverton earns, and what you'd track |
| 12–14 | **The close: what it means for the operators** |
| 14–15 | The one thing you'd want to test with them first, which turns into Q&A |

### The close the recruiter asked for

Land on two or three operator outcomes, each said in the operator's terms rather than Kelverton's. Use the operator outcomes the report names, in its own words. If you bring in your F2 lens, keep it to "I've worked in bus and light rail network planning". It says what your angle is without claiming heavy-rail knowledge. Finish on something the operator would notice in an ordinary week, not on revenue.

---

## Reading the panel

What's below comes only from the recruiter's email. I don't have Deepa's or Ross's career histories because the research was refused, so I've offered no shared-path openings.

| Interviewer | Relationship | What the email says | Practical implication |
|---|---|---|---|
| Deepa | VP Partnerships, your future manager | Named as your future manager | Expect her to score your thinking and how easy you'd be to manage. She'll likely probe how you'd work her partner book |
| Ross | Commercial Director | "Ross will push on commercials" | The pressure and number-probing will come from him. Influenced revenue and the quota gap will likely land in his part of the Q&A |

---

## Persona table

The weights rest on the recruiter's description of the round, which counts as a loop source: one session, a POV followed by Q&A. They don't rest on any documented Kelverton process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa extending the POV into plans and trade-offs | High. The round opens with a strategy deliverable and a hiring manager is on the panel | Clarify, set the objective, segment, give the approach, the metrics and the risks. Challenge one premise politely |
| Skeptic | Either panellist on the rail and quota gaps | High. F4 and F5 are gaps you stated, and they're the obvious objections | Rehearse B1 until it's boring. Use bridges only from the quotes. Give a concrete ramp plan, said as a plan |
| Data-Driven Prober | Ross asking for denominators on £4M and 6→40 | Medium-high. "Ross will push on commercials" | Know how each figure was counted, or say plainly that you don't. Name your weakest assumption before he does |
| Pressure | Ross interrupting and asking for a number | Medium. A push on commercials often arrives as pressure | Pause and restate the question. Hold through two follow-ups, then concede specifically |
| Conversational | The openers and the closing chat | Low. It's a 60-minute panel with a set agenda | Have a 90-second arc ready. Treat casual questions as scored |
| Values / Behavioral | Stakeholder stories during the Q&A | Low. No values round was named | Use the selection scaffolds in V1 and V2 |

There's no peer on the panel, so there's no Peer Evaluator bank.

---

## Question banks

### A. Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If your budget for this were halved, which part of your 18-month plan goes first?" | CASE | [generic] | Name what you'd cut and what you'd protect, and tie the protected part to the operator close. Say the trade-off aloud | It tests whether the POV has priorities or just a list. It's CASE because it's a live re-plan of the POV |
| A2 | "What would you do in your first 90 days?" | CASE | [generic] | Listen first: operators, the top partners, internal teams. Then pick one thing to prove early and say how you'd know it worked. Make no claim about your past | It's a standard hiring-manager follow-on to a POV and it scores sequencing. CASE |
| A3 | "Integration partners, advisers, or operators as design partners: which comes first, and why?" | CASE | [generic] | Pick one, give the reason, and give the concession from the thesis table. If you led with T1, defend T1 here | It checks whether the thesis survives being compared with the alternatives. CASE |
| A4 | "An operator tells you partner integrations are your problem, not theirs. How do you get them to commit?" | CASE | [generic] | Start from the operator's cost: their IT time and their risk. Offer the smallest commitment that shows value. You may add that you've worked in bus and light rail network planning, but say nothing about operators beyond that | This tests the operator close under resistance (F2, F6). CASE |
| A5 | "How would we know at 18 months whether this worked?" | CASE | [generic] | Give two or three measures: one operator-side, one partner-side and one commercial. Say which one you'd trust least | It turns the POV into accountability. CASE because it's prospective |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. This role will be measured on revenue. Why should we trust you with a number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | **The highest-ROI rehearsal in this pack.** Name the limit before they push: "I've never carried a direct quota. My numbers have been influenced revenue." Then hold on what the quotes do carry: "For the last four years I ran the ISV channel, and it went from 6 partners to 40." Then say how you'd take on a number, as a plan: what you'd want to understand before signing up, and how you'd report against it. First follow-up, "So it's not really your number": hold. Restate *influenced*, don't argue, and don't upgrade it. Second follow-up, "Then how do we know you can close?": concede specifically that you haven't closed direct deals against a quota. Then return to the plan. Never fold into apology, and never claim ownership | F4 is a gap you stated and it sits exactly where "push on commercials" points. It will arrive in some form. JD because it scores a likely revenue requirement |
| B2 | "You haven't sold into rail. What makes you think a payments channel playbook works here?" | JD | [grounded] "Never sold into rail specifically" "last 4 at a payments company running the ISV channel" | Acknowledge it plainly: "I haven't sold into rail." Then don't claim the playbook transfers. Say what you'd test first to find out whether it does. Answer slot: if a specific method from the channel work was yours and you'd reuse it, name it in your own words. If not, say so plainly and stay with the channel you ran | It's the second stated gap (F5). JD because the domain is part of the role |
| B3 | "Bus and light rail planning isn't heavy rail. What actually carries over?" | EXP | [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Agree with the premise and keep the scope exactly as it is: bus and light rail network planning. Answer slot: if a particular part of that work bears on train operators, name it and say what was yours. If nothing carries over directly, say so plainly and describe the work as it was | F6's scope is where the flattering stretch to "rail experience" happens. EXP |
| B4 | "Why leave payments for rail-tech now?" | EXP | [grounded] "9 years in partnerships" "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your material gives no reason for moving, so this is a slot: give your actual reason, in your own words. The quotes only let you say that this role sits where your transport years and your partnership years meet. Don't attribute a motive you haven't stated | It's a motivation-consistency check and the Skeptic's standard question. EXP |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Keep your own words, *roughly* and *influenced*. Answer slot: say how the figure was counted, what it's sensitive to, and which part was yours. If you don't know how it was counted, say so plainly. "I don't know the exact method" is an honest answer | It's the headline number and it sits right where Ross is pushing (F3). EXP: defend the number |
| C2 | "Of the 40 partners, how many actually produced revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know how many produced revenue, say so and give the count as you know it. If you don't, say so plainly. Either way, the count you gave stays partners, 6 to 40 | A prober always asks for the denominator behind a growth count (F7). EXP |
| C3 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name it before he does, in your own words. Answer slot: if you know the assumption behind the figure you'd defend least, say it. If you don't know how it was built, say so plainly | Naming your own weak spot turns a gotcha into credibility (F3). EXP |
| C4 | "What commercial model would you put to a partner: referral fee, revenue share, or resell margin, and why?" | CASE | [generic] | Structure it: what each model asks of the partner, what it gives Kelverton, and what it means for the operator's contract. Pick one for your lead thesis and say what would make you change your mind | Commercials as a live problem. CASE |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Influenced revenue is a soft number. Sixty seconds: convince me it's real." | EXP | [grounded] "roughly £4M of influenced revenue" | Pause, then restate: "You're asking whether it's real or just attributed." Hold on your own words, roughly £4M of influenced revenue. Don't harden it to "generated" or "drove". Answer slot: say how it was counted if you know, and concede plainly what you don't know. Through two follow-ups, return to the same words | F3 under time pressure. The test is composure without inflation. EXP content, Pressure delivery |
| D2 | "If I gave you a revenue target tomorrow, what number would you sign up to for year one?" | CASE | [generic] | Don't invent a figure. Say what you'd need before committing: the pipeline, the partner mix and the baseline. Say how you'd build the number with Deepa and Ross. Hold that line through the push, then offer to come back with a figure built on their data | It tests the F4 gap live. CASE because no past is asked about |
| D3 | "Your POV sounds like a cost centre. Where's the money?" | CASE | [generic] | Point to the commercials beat in your POV: how partners earn, how Kelverton earns, and the one measure you'd report. Concede what the first six months cost | This challenges the POV's commercial spine. CASE |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "9 years in partnerships" | A 90-second arc that uses only these beats: transport consulting in bus and light rail network planning, then the ISV channel at a payments company, 6 partners to 40, roughly £4M influenced. End on why this role, in your own words | It's the scored opener, and it covers F7 and F9. EXP |
| E2 | "What drew you to Kelverton?" | CO | [generic] | Give your own reason. One link to the report is fine if it's in your own words. Make no claim about Kelverton beyond what you've read in its material | It's a light homework check. CO |

### V. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a partner wanted something that would have hurt the end customer." | VAL | [generic] | Selection scaffold: pick a time with a named partner interest, a customer cost and a decision you made, where the relationship survived. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | It mirrors the operator-first close and it's a persona stem (F8). VAL |
| V2 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a named stake, a moment you didn't fold, and an intact relationship afterwards. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | It's senior stakeholder evidence and a persona stem (F8). VAL |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To Deepa) "What would make you say, twelve months in, that this hire worked?" | It gets you her scorecard, and you can mirror it in your follow-up |
| R2 | (To Ross) "How do you want partner-influenced revenue counted and reported here?" | It meets the influenced-versus-owned question head-on, on his terms |
| R3 | "Which operators get the most out of Kelverton today, and what do they do differently?" | It anchors your operator close in their reality rather than your assumptions |
| R4 | "Where in the market report would you push back on your own strategy team?" | It shows you read the report critically, and it invites them to think aloud |
| R5 | "What's the one partnership you'd most want in place 18 months from now?" | It tests your POV against what they actually want |
| R6 | "What has stopped operator partnerships from moving faster so far?" | It surfaces the constraints you'll inherit |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried or hit a revenue quota | A negative you stated (F4) | "I've never carried a direct quota. My numbers have been influenced revenue." No slot |
| Has sold into rail | A negative you stated (F5) | "I haven't sold into rail." No slot |
| Generated or drove £4M of revenue | An inflated form of F3 | F3's quote at its own scope: roughly £4M of *influenced* revenue. C1's slot stays inside how that figure was counted |
| Built the partner channel from scratch | An inflated form of F7 | F7's quote at its own scope: "took it from 6 partners to 40". The pack's observation: the quote starts at 6 partners, not at zero |
| Rail or train-operator industry experience | An inflated form of F6 | F6's quote at its own scope: bus and light rail network planning. B3's slot stays inside that work |
| Knows how operators buy from the inside | An inflated form of F2 | "From the other side" stays your phrase and isn't widened. F2's slot asks who your clients were |

---

## Sources

**Provided:**
- your message
- the recruiter's email, as you quoted it

**Not seen:** the market report the recruiter attached. You've read it, but its contents aren't in this pack.

**Searches sent:** every call was refused, because search permission wasn't granted.
1. "Kelverton Rail values": refused
2. "Kelverton Rail interview process partnerships": refused
3. "Kelverton Rail scheduling software train operating companies news 2026": refused
4. "Deepa VP Partnerships Kelverton Rail": refused
5. "Senior Partnerships Manager rail software job description train operating companies": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Its call was refused. It would have named the published values, themed V1 and V2, and enabled a values cheat sheet if one applied |
| 2. Kelverton Rail interview process | unavailable | Its call was refused. The recruiter's email already sets this round's structure, so it would only have added loop context |
| 3. Kelverton Rail strategy and recent news | unavailable | Its call was refused. It would have grounded the theses and E2 in current company facts. The report you read would cover this if you paste its key points |
| 4. Deepa and Ross at Kelverton Rail | unavailable | The Deepa call was refused, and no Ross call was sent once search proved unavailable. It would have added career patterns, persona tilts and a reverse question tied to each person's path |
| 5. A representative Senior Partnerships Manager JD | unavailable | Its call was refused. It would have turned the `[generic]` rows F4–F9 into `[inferred]` rows built on a quoted posting |

---

## Upgrade menu

- **The JD text** → F4–F9 become quoted `[grounded]` requirements, and any requirement missing from the coverage table gets a JD question
- **Your CV** → more story-mapped answers, and V1, V2 and F8 move from selection scaffolds to story maps
- **Key points from the market report, only what you're comfortable sharing** → the theses, the anti-pick and the operator close get grounded in its own words, and a CO bank is built on it
- **Search permission (L1)** → targets 1–5 run: values, process, recent news, Deepa's and Ross's public professional footprint, and a representative JD
- **A deeper research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, the interviewers' talks and writing, loop reports and recent org context
- **Answers to the slots in F1, F2, F3, C1, C2 and C3** → those rows move from slots to story-mapped guidance
- **A tuesday-dossier.md** → would carry verified evidence and a checked list of prohibited claims into this pack
