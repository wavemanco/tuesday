# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date:** 5 December 2026, three rounds · **Mode:** loop (one shared fit snapshot, one mini-pack per round)

| Round | Length | Who | What the recruiter said it holds |
|---|---|---|---|
| 1 | 30 min | The recruiter | A conversation |
| 2 | 45 min | Head of Member Services, your would-be manager | "mostly behavioural" |
| 3 | 60 min | Two branch managers | "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

Interviewers beyond their roles haven't been assigned, so there is no interviewer read yet.

---

## How to use this pack

- **Personas** describe *how* a question arrives: friendly, sceptical, time-boxed, collegial. **Types** describe *what is scored*.
- Type key: **VAL** = behaviour against Ashgrove's published values · **EXP** = whether what you say about your past holds up under follow-up · **JD** = can you do the listed job, gaps included · **CO** = Ashgrove strategy and context · **CASE** = a live problem from the role.
- **Provenance** shows what each row rests on: `[grounded]` = your own words or a document you supplied; `[inferred]` = the pack's derivation, named; `[generic]` = a role-family pattern, with no claim about you or Ashgrove.
- **Answer slot** = a place where the pack can't know the answer. It names the likely probe and gives you two honest branches. Answer from your own experience. Never fill a slot with what sounds good.
- Guidance is scaffolding, not a script. Every scripted line here is proposed, pending your approval. Change any word that isn't how you'd say it.
- Question IDs run by persona: A–B (round 1), C, D, E, G, P (round 2), H, J, K, L (round 3). F-numbers are fit-snapshot rows.

---

## Prep triage: nine days to 5 December

1. **First, the answer slots on paper** (fit rows F1, F3, F4, F7, F9; questions G1, G3, C4, D1). Write down what the spreadsheet tracks and in which tool, which rules governed the formal log, and whether you've ever advised another supervisor. These answers decide what you can say in all three rounds.
2. **C1, out loud, until it's boring.** It is the highest-ROI prep in this pack. Then do C3.
3. **Four real stories for H1–H4**, one per value. This is the biggest gap in your material: nothing you've shared yet tells a member story, and the panel scores all four values.
4. **Run the 20-minute case (section 5) twice against a clock.**
5. **Decide your logistics answers (A3–A6) before the recruiter call.**
6. **Strategy fluency:** E2, K2, L1.
7. **Pick reverse questions for each round.**

Everything else is insurance.

---

## 4. Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes the branch's formal complaints log, not a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If you took complaints from logging through to resolution yourself, say which steps were yours and how, in your own words. If some steps sat with someone else, or there was no such step, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you've stated, and wording can't close it. Words: "I haven't worked in a contact centre." After that, how you'd learn it, said as a plan and never as a past. Don't add anything to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material doesn't show what the spreadsheet tracks. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes-and-resolution-times line makes a probe on its contents likely. If it tracks volumes or resolution times, say which and how each is counted, in your own words. If it doesn't, or you don't know how a figure is counted, say so plainly and describe what it holds |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says you trained new tellers, not that you coached supervisors. Words: "I trained new tellers on our escalation script," and "the last three years as a branch supervisor." Answer slot: the JD's coaching line makes a probe likely. If you have coached or advised another supervisor on an escalation, say when and how, in your own words. If you haven't, say so plainly and stay with training new tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work either way. Answer slot: the JD's line makes a probe likely. If you have fed into an app, an online process or a self-service journey, say what it was and which part was yours, in your own words. If you haven't, say so plainly and give how you would work with a digital team, said as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Say it as you wrote it: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer map it. Don't relabel your years in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says "formal". It doesn't say whether these were regulated complaints or which rules applied. Answer slot: if those complaints were handled under regulatory complaint rules, name the rules as you know them and which part of following them was yours, in your own words. If they weren't, or you're not sure which rules applied, say so plainly and describe how the formal log worked. Don't guess a rule's name or a deadline on the spot |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you've stated. Words: "I haven't presented to anyone above regional level." Answer slot: if you have presented to anyone at regional level or below, say to whom and about what, in your own words. If you haven't, say so plainly. Then give the plan, said as a plan. Never call yourself confident at a level you haven't presented to |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet", not which tool. Answer slot: if it's built in Excel, say so and describe in your own words what you set up in it. If it's another tool, name it plainly |

**Reading the snapshot:** F2 and F8 are the two gaps you have stated yourself, and both sit inside headline lines of the JD. F1, F3, F4, F7 and F9 hold real material at a smaller scope than the JD asks for, and your answers to their slots decide how far each one reaches. F5 is silence, not a gap you've confirmed. F6 is closed.

---

## 5. Graded deliverable: the 20-minute complaint-escalation case (round 3)

The recruiter's words: "a 20-minute case on a complaint escalation". The panel is "also the values round — they score against the four values". You don't yet know whether the case is handed over on the day or sent ahead, or whether you present it or discuss it. Ask in round 1 (reverse question R1-1).

**What you can build on**
- The JD's lines: "Own the member complaints process end to end", "coach branch supervisors on escalations", "report monthly on complaint volumes and resolution times".
- The four values by name: "Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix".
- The strategy brief: "move 40% of member service to digital channels by 2028", "consolidate eight branches into five hubs over 2027", and app-only banks as "the main competitive pressure".
- Your own side. F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." F4: "6 years in retail banking, the last 3 as a branch supervisor." Mention these only as they stand. The case is about what you would do, so it needs no claim about your past.

**A 20-minute shape** `[generic]` (pending your approval)
1. **Clarify, about 3 minutes.** What was the complaint? What has been said and done so far, and by whom? What does the member want? Is it a formal complaint, and which regulatory clock and Ashgrove policy apply? Ask about the clock rather than stating one. Are there any signs the member is vulnerable?
2. **Member first, about 4 minutes.** Same-day contact from one named person who keeps the complaint until it is closed. Acknowledge the member before explaining anything. Explain in plain words and check they understood. Promise no remedy before you have the facts.
3. **Facts and decision, about 4 minutes.** What was the member actually told, and what do the branch notes say? Was "resolved" really a resolution, or only a closure? If Ashgrove got it wrong, put it right. If not, explain plainly and give the member their options.
4. **Fix the cause, about 3 minutes.** Is this one member or a pattern? Check the complaint records across branches and the contact centre. If a notice or a journey caused it, take it to the team that owns it, the digital team included.
5. **Coach and report, about 3 minutes.** Debrief the supervisor privately (J2). Show where the case lands in the monthly figures (J3).
6. **Close, about 3 minutes.** Name the value behind each decision.

**Three theses, each with its concession**

| Thesis | Concession you say out loud |
|---|---|
| Resolve the member first and fix the process second: the member gets contact today, and the root cause gets its own track | Moving fast can close a complaint before you understand it, so the root-cause track has to be booked, not hoped for |
| An escalation tells you about the process, not a verdict on the supervisor | Sometimes the supervisor got it right and the member is still unhappy. Then the job is a plain explanation, not a reversal |
| One owner across branch and contact centre, so the member never tells the story twice | During the 2027 hub moves, who owns what will be messier. Say how you'd hold it in the meantime |

**Differentiation.** The consensus answer is apologise, investigate, resolve, learn. Any prepared candidate gives it. Go past it in three ways: tie each step to a value by name, show the loop back to coaching and the monthly report, and give the anti-pick. Don't overrule the supervisor in front of the member, and don't offer money to make the anger stop before you know the facts.

**The close the panel scores.** The recruiter named no specific close. Since the panel scores against the four values, end with one sentence per value saying where it drove a decision in your plan.

---

## 6. Grounding brief: what Ashgrove has said about itself

| Item | Source, as you supplied it | What it likely means for this role | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — strategy brief, July 2026 | Complaints will increasingly be about digital journeys, and the JD's "self-service journeys" line is where this role meets that | [inferred] from the brief and JD |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" — strategy brief | Likely a live topic for a panel of branch managers. It touches "Neighbours, Not Numbers" directly | [inferred] from the brief and the recruiter's email |
| New product | "launch a small-business lending product in Q1 2027" — strategy brief | New product, new complaint types, early in your first year | [inferred] from the brief |
| Competition | "the main competitive pressure is app-only banks" — strategy brief | How complaints are handled is part of why members stay. Talk about it as a reasoned view, without statistics | [inferred] from the brief |
| Shape | "member-owned, about 900 staff" — JD | Use "members", never "customers" | [grounded] |

The brief is four months old, which is current enough. Use its exact phrases. You only have these lines from it, so don't describe anything else as being in it.

---

# Round 1: Recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through, motivation, logistics | High. It is the recruiter-screen prior, in a 30-minute slot | A rehearsed 90-second arc. Treat every casual question as scored |
| Skeptic, light | Knockout checks against the JD's requirements | Medium. Recruiters screen F2, F6 and F8 before passing you on | Short plain acknowledgments now, with the full versions saved for round 2 |
| Others | Not expected here | Low. Rounds 2 and 3 carry them | — |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Ninety seconds, three beats, in your own sentences. First, six years in retail banking, the last three as a branch supervisor. Second, you handled the branch's formal complaints log and trained new tellers on your escalation script. Third, you built the monthly complaints spreadsheet your regional manager uses. Then say why this role, in your own words. Don't join the beats with claims the sentences don't make: "six years in complaints" is on the prohibited list | F6, F1 and F3 are your strongest quoted material, and the opener sets the frame for the rest of the call. EXP because it is your record, said aloud |
| A2 | "What's drawing you to Ashgrove, and to a credit union?" | CO | [grounded] | Your reason has to be yours, and the pack can't supply it. Anchor it in something you actually read. Name one value by its exact name ("Members First, Always", "Plain Words", "Neighbours, Not Numbers" or "Own the Fix") and one line of the strategy brief, then say in your own words why it matters to you. Under a minute | Recruiters check that your motivation is consistent. CO because it tests whether you did the homework. It rests on the pasted values and brief |
| A3 | "What salary range are you looking for?" | JD | [generic] | Logistics slot. Give your own number, or ask for the role's band first. It's your choice, and nothing here supplies a figure. If asked what you earn now: "I'd rather focus on the range for this role." | A standard recruiter logistics check. JD because pay is one of the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, and the earliest start date that follows from it | Standard logistics. JD because it is one of the job's terms |
| A5 | "The role covers branches and the contact centre, and branches move into hubs over 2027. Where can you be based, and how much moving between sites works for you?" | JD | [grounded] | Logistics slot. Say where you can be based and how much travel between sites works for you, in your own terms. Your brief says eight branches into five hubs but not where. If you don't know where the hubs or the contact centre are, ask | The JD's "across branches and the contact centre" line and the hub plan make location a live term. JD because it is one of the job's terms |
| A6 | "Why are you looking to move now?" | EXP | [generic] | Logistics slot. Give your own reason, in your own words, in two or three sentences. Nothing here supplies one | Standard reason-for-leaving check. EXP because it concerns your own history |

### Bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers the contact centre as well as branches. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Keep it plain and short at this stage: "I haven't worked in a contact centre." Then one sentence on what you do bring, in its own words: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Stop there. The full version is C1 | F2 is a stated gap inside the JD's first line, so expect a knockout-style check. JD because it scores a listed requirement |
| B2 | "The role asks for 4+ years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it as you wrote it: "Six years in retail banking, the last three as a branch supervisor." Let the recruiter do the mapping | F6 closes this requirement. The rehearsal is not over-dressing it. JD |
| B3 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Words: "I haven't presented to anyone above regional level." Then one line of plan, said as a plan: how you would prepare for it here. Don't call yourself confident at a level you haven't presented to. The full version is C3 | F8 is a stated gap against a named requirement. JD |

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Is the 20-minute case given on the day or sent ahead, and is it discussed or presented?" | It changes how you prepare section 5 and shows you're taking the case seriously |
| R1-2 | "Do you know yet who'll be on each round, and which branches the panel manage?" | Names unlock an interviewer read. Branch context sharpens K2 |
| R1-3 | "How does the panel score the four values: separately, or as one overall mark?" | It shows you read the process. It tells you whether every value needs its own story (H1–H4) |
| R1-4 | "What happens after 5 December, and when would I hear?" | Plain logistics, and it is expected |
| R1-5 | "What would make you confident putting a candidate forward to the Head of Member Services?" | It invites the recruiter to tell you what round 2 is looking for |

---

# Round 2: Head of Member Services, your would-be manager, 45 minutes, "mostly behavioural"

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F2 and F8, "why you, why now" | High. The hiring-manager prior is derisking gaps, and two of yours are stated | The plain acknowledgment first, then a ramp plan. Rehearse C1 until it's boring |
| Values / Behavioral | "Tell me about a time…" | High. The recruiter called this round "mostly behavioural", which lifts this persona above the hiring-manager prior | Real stories with "we" for context and "I" for your part. Use scaffolds where your material has no story yet |
| Case / Strategist | Short live problems on the role | Medium. It is the hiring-manager prior, tilted down by "mostly behavioural" | Clarify, then structure, then answer, using Ashgrove's own words |
| Data-Driven Prober | "What's in the spreadsheet? How was that counted?" | Medium-low. The JD's reporting and Excel lines meet F3 and F9 | Say what you know, say plainly what you don't, never estimate on the spot |
| Pressure | A time-boxed challenge | Low. Nothing signals it, but you shouldn't meet it first live | Pause, hold, concede exactly |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked in a contact centre, and this role owns complaints across branches and the contact centre. Why should I trust you with that side of it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI prep in this pack.** Name the limit before they finish. Beat 1, the words: "I haven't worked in a contact centre." No apology, no padding. Beat 2, what you do bring, in the quote's own terms: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Don't say it transfers or proves anything; let them draw that. Beat 3, a ramp plan, said as a plan: your first weeks would be spent with the contact centre, listening to complaint calls, reading how complaints are logged there, and asking the team lead where escalations stall. Follow-up 1, "contact centres run on volume and targets". Hold: "They do, and I haven't worked in one. That's why my first weeks would be spent there." Follow-up 2, "so you'd be learning on the job?" Concede exactly: "On the contact centre, yes." Then go back to the formal complaints log. Never reach for a contact-centre-like claim your material doesn't carry | F2 is a gap you've stated, and it sits in the JD's opening line next to F1, so it will be asked in some form. JD because it scores the listed requirement directly |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two gaps you've named and say it plainly: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level." Then say what you'd do about it in the first 90 days, as a plan. Don't offer a strength in disguise; it reads as dodging the question | A persona stem aimed at F2 and F8. JD |
| C3 | "This role reports monthly to senior leaders. Tell me about presenting at that level." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Words: "I haven't presented to anyone above regional level." Answer slot: if you have presented to anyone at regional level or below, say to whom and about what, in your own words. If you haven't, say so plainly and go straight to the plan. The plan, said as one: you'd lead a monthly pack with the headline number and its trend, one or two causes, and the decision you need from them, and you'd ask your manager to review the first one. Hold the line: don't call yourself confident at that level | F8 is the second stated gap. It is the second-highest-ROI rehearsal. JD |
| C4 | "Coaching branch supervisors is different from training tellers. What have you done that's closest?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Say both facts in their own words: "I trained new tellers on our escalation script," and the last three years as a branch supervisor. Don't say you wrote the script, and don't call teller training coaching. Answer slot: the JD's coaching line makes this probe likely. If you have coached or advised another supervisor on an escalation, say when and how, in your own words. If you haven't, say so plainly and stay with training new tellers. Then the plan for coaching supervisors here, said as a plan | F4 is adjacent work at a smaller scope than the JD asks. JD |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint you took from first contact to resolution." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick one real complaint from the formal log you handled. It needs what the member raised, each step that was yours, how it ended, and what changed afterwards, if anything did. "We" for the branch, "I" for your part. If no complaint comes to mind that you followed through yourself, say so plainly. Then give the nearest thing your material does carry, how you handled the branch's formal complaints log, or how you would handle one | The theme comes from the JD's end-to-end line, and F1 is where it lands. EXP because it tests what was actually yours |
| D2 | "Tell me about a time an escalation didn't go the way it should have. What did you do?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick a real escalation where something went wrong. It needs what went wrong, which part was yours, and what you changed or would change. If none comes to mind, say so plainly. Then give the nearest thing your material does carry, training new tellers on your escalation script, or how you would handle it | The theme comes from the JD's escalations line, with F1 and F4 as the nearest material. EXP |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Complaint resolution times have crept up across branches for three months. Diagnose it." | CASE | [generic] | Clarify first: how resolution time is measured, which channels, which complaint types. Then segment by branch, channel and type. Then hypotheses: volume, staffing, escalations stuck between branch and contact centre, a product or process change. Say what data you'd pull first, what you'd do this week, and how it would read in the monthly report. The question needs no claim about your past, so make none | A live problem from the JD's reporting line. `[generic]` because it is a pattern, not an Ashgrove fact |
| E2 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and how would you work with the digital team?" | CO | [grounded] | Structure: complaints about the digital journeys themselves; whether members can raise a complaint easily in-app; feeding complaint data into journey design; "Plain Words" applied to screens; members who still want a branch ("Members First, Always"). End on what you'd bring to the digital team each month. No claim about past digital work. That is F5's slot, if asked | The strategy brief and the JD's self-service line. It is the only route to F5's requirement. CO |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built: what's in it, and how does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote states: you built it, it's monthly, your regional manager uses it. Answer slot: the JD's "report monthly on complaint volumes and resolution times" and "Excel reporting" lines make probes on its contents and tool likely. If it tracks volumes or resolution times, say which and how each is counted. If it's in Excel, say so and what you set up in it. If not, or you don't know how a figure is counted, say so plainly and describe what it holds. If there's a figure in it whose count you'd defend least, name it yourself first. Say only what you know about how your regional manager uses it | F3 and F9 rest on this one sentence. EXP because it tests what is behind it |
| G2 | "How many complaints went through your branch's log in a typical month, and how long did they take to resolve?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if you know the figures, give them as you know them and say how they were counted. If you don't, or resolution time wasn't tracked, say so plainly. Never estimate on the spot. If you give a figure, name the assumption behind it you'd defend least before they do | The JD's reporting line pressed on F1. EXP |
| G3 | "Which complaints went into the formal log, and what rules governed how you handled them?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats the quote states: it was the branch's formal complaints log, and you handled it. Answer slot: the JD's "experience handling regulated complaints" line makes this probe likely. If those complaints were handled under regulatory complaint rules, name the rules as you know them and which part of following them was yours. If they weren't, or you're not sure which applied, say so plainly and describe how the log worked. Don't guess a rule's name or a deadline | It covers F7's requirement, the one JD line with no other question. JD |

### Bank P: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Pause, then three facts in your own words: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Then one line on what you would do in the role, in your own words. If interrupted with "an internal person already knows our contact centre": hold, then concede exactly, "They'd know it better than I do on day one." Don't run down the other candidate | A persona stem. It is rehearsal for composure under a time box before the case round. JD |

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "Where do complaints most often stall today: in branches, at the contact centre, or between them?" | It shows end-to-end thinking and tells you what the job really is |
| R2-2 | "What do senior leaders do with the monthly complaints report now? Which decisions does it drive?" | It treats reporting as decisions, the JD's reporting and presenting lines together |
| R2-3 | "As service moves digital toward 2028, who owns the fix when a complaint is about an app journey?" | It uses their strategy and their "Own the Fix" value in one question |
| R2-4 | "What would you want to see from this role after six months?" | It defines success with the person who will judge it |
| R2-5 | "How do you support someone stepping up to presenting at senior level?" | It turns F8 into a development conversation, honestly |
| R2-6 | "Will complaints about the small-business lending product come through the same process?" | A Q1 2027 launch lands early in your first year, and the question shows you read the brief |

---

# Round 3: Panel of two branch managers, 60 minutes (values round plus 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One probe per value, scored | High. The recruiter says the panel "score against the four values" | One real story per value (cheat sheet below) |
| Case / Strategist | The 20-minute escalation case and its follow-ups | High. Pre-declared by the recruiter | Section 5's shape, timed |
| Peer Evaluator | "What would you need from us?", and the hubs | Medium. The JD puts their supervisors and branches inside this role's remit | Reciprocity and seam principles, not promises |
| Conversational | Openers and strategy chat | Low | Treat casual questions as scored |

Interviewers' names aren't known, so personas can't be assigned per panel member yet.

### Bank H: Values / Behavioral (one per value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell us about a time you decided from the member's side of the counter, even when it was harder for the branch." | VAL | [grounded] | Selection scaffold. A real decision where the member's interest and the branch's convenience pulled apart and you went with the member. It needs the member's situation, what made it harder for the branch, what you decided, and what happened. "We" for the branch, "I" for your decision. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | "Members First, Always", in the value's own wording. VAL. None of your sentences carries a story here yet |
| H2 | "Tell us about a time someone needed something explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. A time an explanation didn't land, with a member or a new teller, and what you changed so it would. It needs what was misunderstood, what you changed, and how you knew it worked. Answer slot: the nearest material is training new tellers on our escalation script. If you changed how something in it was explained, say what, in your own words. If not, pick another time. If none comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | "Plain Words": "if a member needs it explained twice, we wrote it wrong". F4 is the nearest material. VAL |
| H3 | "Every branch is part of its town. Tell us about a time you treated a member as a neighbour, not a number." | VAL | [grounded] | Selection scaffold. A real member whose local situation changed what you did. It needs who they were to the branch (no identifying details), what the standard route was, what you did instead, and what happened. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | "Neighbours, Not Numbers". A panel of branch managers may weigh it most heavily during the hub plans. VAL |
| H4 | "Tell us about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold. It needs the problem, the moment you could have handed it off, and the fix. Answer slot: if the spreadsheet you built began with a problem you found, that is this story; tell it in your own words. If it didn't, pick another. If none comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | "Own the Fix", in the value's own words. F3 is possible material, but only if it started that way. VAL |

### Bank J: Case (the declared 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | Practice version: "A long-standing member has complained twice at their branch about a fee they say they were never told about. The supervisor closed it as 'explained'. Now they've called the contact centre, angry, saying they'll move to an app-only bank. Walk us through it." | CASE | [generic] | Use the section 5 shape, timed: clarify, member first, facts and decision, fix the cause, coach and report, close on the values. Say the anti-pick: no public overruling of the supervisor, and no money before the facts. Ask which regulatory clock and Ashgrove policy apply; don't state one | A practice case in the recruiter's announced format. It touches the JD's end-to-end, escalation and reporting lines and all four values. `[generic]` because the scenario is invented |
| J2 | "Same case: the branch supervisor feels you went over their head. How do you handle them?" | CASE | [generic] | Privately, the same day. Start with what they saw. Agree what "resolved" should mean from now on, and what you'll both do next time. Leave them owning their branch's relationship with the member. Make no claim about having coached supervisors before; describe what you would do | The JD's coaching line, rehearsed as a decision rather than a record. CASE |
| J3 | "What from this case goes into your monthly report, and what would you ask leaders for?" | CASE | [generic] | One case is an anecdote. The report counts things: repeat complaints, escalations from branch to contact centre, time to resolve. If the fee wording turns out to be a pattern across branches, ask for the wording to be fixed ("Plain Words"). One decision asked for, not five | The JD's reporting line, from inside the case. CASE |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our supervisors handle escalations their own way. What would you need from us, and what would you bring us?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Reciprocity first. You'd bring a shared escalation approach across branches and the contact centre, a monthly view of their branch's complaints, and coaching time. You'd need supervisors' time, their honest read of where escalations stall, and managers backing a common standard. Seam principle: the branch keeps the member relationship, and this role owns the process and the data. On your past, say only that the last three years were as a branch supervisor | The JD's coaching line, seen from the managers' side. JD |
| K2 | "Eight branches are becoming five hubs over 2027. What happens to complaints, and to members, through that move?" | CO | [grounded] | Say it as a hypothesis: you'd expect complaints about access, travel and changed faces. Before the move, tell members in plain words. During it, watch complaints from the affected towns more often than monthly. Afterwards, keep the local relationships ("Neighbours, Not Numbers"). Concede what you don't know: the hub plan's details. Ask what they're seeing | The strategy brief, put to the people whose branches it touches. CO |
| K3 | "Tell us about a time you disagreed with another supervisor or manager about how to handle a complaint." | EXP | [generic] | Selection scaffold. A real disagreement with an equal or a senior. It needs the two positions, how you raised it, what was decided, and the working relationship afterwards. If none comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you would handle it | A peer stem about how you disagree with colleagues. EXP |

### Bank L: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Members can open an app-only account in minutes. Why would they stay with us?" | CO | [grounded] | A reasoned view, not statistics. What app-only banks do well: speed and self-service. Where a member-owned credit union can compete: ownership, local branches, plain words. Where complaints fit: a well-handled complaint is a reason to stay, and with the 2028 digital target a complaint has to be easy to raise in the app too | The brief names app-only banks as the main pressure. A casual strategy question is still scored. CO |
| L2 | "What would your first 90 days look like?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Said as a plan. Month 1: listen in branches and the contact centre, the contact centre first because you haven't worked in one, and read the complaints data. Month 2: a baseline monthly report and an escalation standard agreed with supervisors. Month 3: the first coaching cycle, the first senior-leader report with your manager's review, and the first joint item with the digital team | It gathers the JD's lines into one plan and builds F2 and F8 into it honestly. JD |

### 10. Values cheat sheet (round 3)

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No quoted sentence carries one yet. Selection scaffold: a decision where the member's interest and the branch's convenience pulled apart and you chose the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (H1) |
| Plain Words | If it needs explaining twice, the wording is the problem | Nearest material, F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It is a story only if you changed how something was explained. If you did, say what; if not, choose another. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (H2) |
| Neighbours, Not Numbers | Each branch belongs to its town | No quoted sentence carries one yet. Selection scaffold: a member whose local situation changed what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (H3, K2) |
| Own the Fix | Whoever finds a problem keeps it until it's solved | Nearest material, F3: "I built the monthly complaints spreadsheet our regional manager uses." It is this story only if it began with a problem you found. If not, choose another. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (H4) |

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What could someone in this role do in their first month that would genuinely help your branches?" | Reciprocity. It makes you their resource, not their auditor |
| R3-2 | "What do your supervisors find hardest about escalations today?" | It goes straight to the JD's coaching line and tells you where to start |
| R3-3 | "When a complaint moves from your branch to the contact centre, how do you hear how it ended?" | It shows you see the seam this role sits on |
| R3-4 | "How are members in your towns responding to the hub plans so far?" | "Neighbours, Not Numbers" applied to their live concern. Ask it gently |
| R3-5 | "Which of the four values is hardest to live up to on a busy day?" | It invites honesty and shows you take the values as practice, not slogans |

---

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| Own the member complaints process end to end across branches | F1 | C1, D1, J1, L2 |
| …and the contact centre | F2 | B1, C1, L2 |
| Report monthly on complaint volumes and resolution times | F3 | G1, G2, E1, J3, C3 |
| Coach branch supervisors on escalations | F4 | C4, J2, K1 |
| Work with digital teams on self-service journeys | F5 | E2, L1 |
| 4+ years in financial-services customer operations | F6 | B2, A1 |
| Experience handling regulated complaints | F7 | G3 |
| Confident presenting to senior leaders | F8 | B3, C3, C2 |
| Comfortable with Excel reporting | F9 | G1 |
| The four published values | — | H1–H4, section 5 close |
| The 2026 strategy brief | — | A2, E2, K2, L1 |

---

## 13. Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log, not a process across branches |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. Your material says you trained new tellers |
| Wrote or designed the escalation script | Inflated form of F4 | F4's quote: you trained new tellers on "our escalation script". Your material doesn't say who wrote it |
| Owned the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: a spreadsheet your regional manager uses |
| Six years of complaints experience | Inflated form of F6 and F1 | Both quotes at their own scope: six years in retail banking. Your material doesn't say how long you handled the log |
| Contact-centre experience | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." No slot for presenting at senior level |

---

## 14. Sources

**Provided documents:** the JD (pasted); Ashgrove's values (pasted, which you copied on 26 November 2026 from ashgrovecu.org/about/values; not fetched); the recruiter's email describing the three rounds (pasted); the 2026 strategy brief, published July 2026, as the lines you summarised; your background (your message). No dossier was consumed.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | Your pasted values, copied this morning, give the official names and wording behind the cheat sheet and bank H |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes all three rounds, who runs each and what each holds. Persona weights follow it, and it names round 3 as the values round |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief is under six months old and supplies the CO questions and the grounding brief |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form. There is no interviewer read |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD |

---

## 15. Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each person, persona weights per panel member, and one reverse question tied to each person's own path
- **Your answers to the answer slots** (what the spreadsheet tracks and in which tool; which rules governed the formal log; whether you've advised another supervisor; any digital work; anything you've presented at regional level or below) → F3, F4, F5, F7, F8 and F9, plus C3, C4, G1, G2 and G3, go from slots to story-mapped answers
- **One real story per value, in your own words** → the four cheat-sheet rows and H1–H4 go from scaffolds to mapped stories. This is the single biggest lift for round 3
- **Your CV** → more of your own sentences to quote. It may also show material for F5 (digital) or for presenting below senior level
- **The full strategy brief text** → exact vocabulary for E2, K2 and L1, and a fuller grounding brief
- **The case format from the recruiter** (on the day or sent ahead, discussed or presented) → section 5 retuned to the real format
- **A layout of your monthly complaints spreadsheet with no member data, only if your employer's rules allow** → the artifact that would raise F3 and F9 from medium to high, and something concrete to talk through in G1
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes, covering recent Ashgrove news and organisational context) → fresher CO questions and reverse questions. Say the word and it runs
- **A tuesday-dossier.md from an underwriting pass** → verified evidence and a named top objection to rehearse against. This pack doesn't need one
