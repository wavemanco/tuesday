# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager (4 terminal sites, 12 supervisors). Company: Atlas Freight. Interviewer and round: not known. This pack covers the full loop with flat persona weights, which makes it noticeably less targeted than a pack built for a known round.

## How to use this pack

Personas describe **how** a question gets asked: the style, the pressure, who is asking. Types describe **what** gets scored. Each question has both.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's values (generic here, because research did not run) |
| EXP | Whether what you say about your past holds up when probed, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Your homework on the company: strategy, competition, recent moves |
| CASE | How you structure a live problem from the actual role |

The guidance is scaffolding, not a script. Say it in your own words. **Answer slot** means the pack does not know the answer. If you did the thing, say how. If you didn't, say so plainly. Both branches are honest answers.

Fit-snapshot rows are F1 to F8. Questions are lettered by persona: A Skeptic, B Case/Strategist, C Prober, D Pressure, E Conversational, V Values/Behavioral, P Peer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution operations under a shift-manager title. It does not mention terminal operations or four sites, so keep your words at that scope: "I've spent seven years in warehouse and distribution operations, and I'm currently a senior shift manager over three supervisors." Answer slot: the JD's four-site line makes a probe on multi-site work likely. If any of your work has covered more than one site, say what and how in your own words. If none has, say so plainly and stay with the operation you run |
| F2 | "drive on-time performance" (from "drive on-time performance and cost-per-shipment down") — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Running a surge plan is not the same as driving on-time performance, so don't stretch this bridge. Answer slot: if you tracked on-time or service-level results, during peak or at any other time, say what was measured and what moved. If you tracked none, say so plainly and say how you would measure on-time performance first |
| F3 | "drive ... cost-per-shipment down" (from "drive on-time performance and cost-per-shipment down") — JD | none given | none | [grounded] | discovery | Strong evidence here is a cost measure you tracked per unit, plus something you did that moved it. Answer slot: if you have owned or tracked any cost measure, say which one and what you did with it. If you haven't, say so plainly and say what you would look at first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is your stated span, and the words stay there: "I currently lead three supervisors as senior shift manager." Answer slot: the JD's twelve-supervisor line makes a probe on leading at scale likely. If you have led a larger group at any point, say when and how many, in your own words. If you haven't, say so plainly and stay with the three |
| F5 | "build reporting in Excel" (from "build reporting in Excel/Power BI") — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill level. It does not show reporting you built. Answer slot: if you have built reports or trackers that other people used, say what they were and who used them. If you haven't, say so plainly and say what you would build first |
| F6 | "build reporting in ... Power BI" (from "build reporting in Excel/Power BI") — JD | "never used Power BI" — your message | none | [grounded] | capability | No wording closes this gap, and you have already said so. Words: "I haven't used Power BI." Follow with how you would learn it, said as a plan and never as something you have done. Never claim Power BI work, and add nothing to make the gap sound smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material shows seven years in operations and a current leadership role. It does not show how many of those years were spent leading people. This is a length-of-experience requirement, not a gate, but expect it to be read literally. Answer slot: give the actual number of years you have led people, and in which roles. If the number is under five, say it plainly |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | No gap, but nobody has inspected the certificate, so expect a probe. Lead with "I'm green belt certified." The pick-path redesign is a result you can describe, but whether you used Lean or Six Sigma tools on it is an answer slot. If you did, name what you used, in your own words. If you didn't, keep the two separate |

## Persona table

No loop source was available (the company search was blocked), so the pack falls back to the **Generic** archetype: screen, then hiring manager, then panel. That means **flat weights**, and they rest on a pattern, not on Atlas Freight's documented process. Each persona gets about three questions. The banks are ordered by how directly the JD's content tests each persona's focus, not by likelihood.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scale jump and the gaps | Flat. The JD's scale (4 sites, 12 supervisors) against F1 and F4 is the most predictable objection in any round | Rehearse A1 until it bores you. Use only your stated span, name the limit before they do, then give a ramp plan |
| Case / Strategist | Live problems on OTP, cost and multi-site running | Flat. The JD names two metrics to drive, so expect them to be tested live | Clarify, set the objective, segment, give your approach, the metrics and the risks. Think aloud |
| Data-Driven Prober | Digs into the 40% figure | Flat. Your one headline number will draw it | Know what you can and cannot say about how the 40% was counted, and say plainly where you don't know |
| Pressure | Time-boxed, devil's advocate | Flat. Common in operations interviews, where composure is part of the job | Pause, restate the question, anchor on what you stated, and hold through two follow-ups before conceding |
| Conversational | Friendly openers | Flat. Present in almost every loop | Have a 90-second arc ready, built only from your stated facts. Treat casual Lean or Power BI chat as scored |
| Values / Behavioral | Tell-me-about-a-time | Flat. Atlas's values are unknown (research didn't run), so these are generic stems | Pick real stories. "We" for context, "I" for your contribution |
| Peer | Collaboration and seam questions | Flat. A panel may include other site or functional leads | Offer what you bring them, and propose principles for the seam rather than claiming to know it |

## Question banks

**Highest-ROI prep in this pack: A1.** The jump from 3 supervisors to 12 across 4 sites will come up in some form, in any round.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today. This role is twelve across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | The deepest rehearsal here. Hold only what the quotes carry: "I'm currently a senior shift manager over three supervisors, after seven years in warehouse and distribution operations." Name the limit yourself, before they do: three is your current span. Answer slot: if you have led more people or more than one site at any point, say when and how many. If you haven't, say so plainly. Then give the ramp plan, said as a plan: how you would learn four sites and twelve supervisors in your first 90 days. Through two follow-ups, keep returning to the quotes and the plan. Never add to the quotes | F1 and F4 are where the JD presses hardest on this background, which makes this the most predictable objection. JD because it tests the stated scope |
| A2 | "This is terminal operations. Your background is warehouse and distribution. What doesn't transfer?" | JD | [grounded] "7 years in warehouse and distribution ops" | Agree that the difference is real. Don't argue it away. Answer slot: the JD names terminal operations. If any of your work has involved terminal operations, say what. If none has, say so plainly and name what you would want to learn first about how a terminal day runs. Asking good questions about the difference scores better than claiming there isn't one | F1's kind gap, warehouse against terminal, invites a direct challenge. JD because it scores the first line of the posting |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "solid Excel" | Pick the true answer: "I haven't used Power BI." Add your Excel in your own words ("solid Excel") and how you would learn Power BI, as a plan with a timeframe you can commit to. Don't pick a fake weakness. A real one, owned, is the strongest answer | F6 is a gap you stated yourself, so own it before it gets extracted. JD because it maps to the reporting requirement |
| A4 | "How many of your seven years have been in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the actual number of years you have led people, and in which roles, in your own words. If it is under five, say the number plainly and stay with what the quotes carry. Never round seven years of operations up into seven years of leadership | F7 is a "required" line that will likely be screened literally. JD because it is a stated qualification |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose on-time performance at one of the four terminals has slipped for a month while the other three held. How do you diagnose it?" | CASE | [generic] | Clarify first: how on-time is defined and measured, and since when. Segment: by shift, lane, customer, carrier and dock. Ask what changed at that site. Then data before theory, the root cause, a countermeasure, and how you would know it worked. Since nothing here claims anything about your past, the guidance makes no such claim | The JD's on-time line (F2's requirement), asked as a live problem. Generic because it is a pattern, not knowledge of Atlas |
| B2 | "Cost per shipment is up across all four sites. Where do you look first?" | CASE | [generic] | Split the number: has cost risen, or has shipment volume (the denominator) fallen? Then break it down by cost bucket, by site and over time. Pick the biggest mover, find its driver, and name the risk to on-time performance if you cut it. Say the structure aloud before filling it in | F3 has no evidence, so a strong live structure is the best available answer. CASE because it is a role problem |
| B3 | "Walk me through your first 90 days across four sites." | CASE | [generic] | Frame it as a plan: listen and visit every site, learn the current numbers and reports, meet each supervisor, pick one or two priorities, then set a cadence. Keep everything future-tense. Nothing in it should sound like you have done multi-site work before | Tests F1 and F4 as a plan rather than a record, which is the honest ground for this background |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Four answer slots, each in your own words. How the rate was counted, and over what period before and after. What it is sensitive to. The assumption behind it you would defend least, named before they ask. Which part was yours. If you don't know how it was counted, say so plainly, which beats a method you can't defend on the second question | The rubric requires every headline figure to get a defend-the-number question, and this is your only one. EXP because it tests the figure |
| C2 | "What did redesigning the pick path actually change, and which part was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you changed in the pick path, in your own words. Answer slot: if others worked on it, say who did what, using "we" for context and "I" for your part. If it was yours alone, say so plainly | Probers go two levels down on a headline result. EXP because it is about attribution |
| C3 | "What would you put on a weekly report for four terminals, and how would you build it?" | JD | [grounded] "solid Excel"; "never used Power BI" | Name the measures you would want as a plan: on-time, cost per shipment, and whatever else drives them. Say how you would build it in Excel ("solid Excel" is your own word for your level) and that you haven't used Power BI, plus how you'd learn it. Answer slot: if you have built a report like this before, describe it. If you haven't, say so plainly | Covers F5 and F6 together. JD because it is the reporting requirement, CASE in delivery |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then three beats, each in its quote's own terms: seven years in warehouse and distribution operations, running the site's peak-season surge plan two years running, and green belt certified. Concede what's true: an internal candidate knows the terminals better. Hold on what you bring, and don't argue their knowledge away | Time-boxed comparison questions test composure. JD because it maps you to the role |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede. Restate what the quote says. Answer slot: say exactly which part was yours and which was others'. If others were involved, concede it specifically and without shrinking your part. Don't fold on what was yours just to ease the tension | The pressure version of C1 and C2. EXP because it scores attribution honesty |
| D3 | "You've never used Power BI. We need those reports in month one. Isn't that a problem?" | JD | [grounded] "never used Power BI"; "solid Excel" | Hold calmly: "I haven't used Power BI." Then the plan: what you'll do in weeks one to four, plus Excel at the level you stated ("solid Excel"). Concede that it is a ramp, and don't promise fluency by a date you can't defend | F6 is a gap you stated, so this negative is fair to rehearse. JD because it scores the requirement |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc made only of these: seven years in warehouse and distribution ops, now a senior shift manager over three supervisors, cut the mis-pick rate 40% by redesigning the pick path, ran the site's peak-season surge plan two years running, green belt certified. Close on why this role, in your own words | It opens almost every loop and sets the frame. Use only F1, F4, F7 and F8's quotes |
| E2 | "What do you know about Atlas Freight, and why us?" | CO | [generic] | The pack has no researched facts about Atlas, so do this homework yourself: their website, recent news, their sites. Use only what you have actually read. If you can't find much, say what you did find and what you'd want to learn | The CO question goes generic because research didn't run. Generic because it holds no facts about Atlas |
| E3 | "Are you doing anything with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you have applied it to a project, say which one and what you did. If you haven't, say so plainly | The JD lists Lean/Six Sigma as a plus, and casual mentions of a plus are still scored (F8). JD because it is a stated plus |

### V. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they didn't want to hear. It needs a named stake, a moment you didn't fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | A generic values stem, since Atlas's values are unknown |
| V2 | "Tell me about a time you held a supervisor to a standard they pushed back on." | VAL | [generic] | Pick a time with a clear standard, real pushback, what you said, and how it ended. "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | Themed on the JD's line about leading 12 supervisors (F4's requirement). VAL because it scores how you lead |
| V3 | "Walk me through how you ran the site's peak-season surge plan." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it in your own words, with the beats the quote states: you ran it, for the site, two years running. Answer slot: the JD's on-time line makes a probe on results likely. If on-time or service results were tracked during peak, say what was measured and what moved. If they weren't, say so plainly and stay with how you ran it. "Ran" is your word, so don't make it "designed" unless that is true and you say how | F2's thin bridge, rehearsed so the honest answer is ready before the probe. EXP because it is premised on your own sentence |

### P. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "When terminal ops and customer service disagree about a delivery commitment, how do you handle it?" | CASE | [generic] | Propose principles: a shared definition of on-time, early warning when a commitment is at risk, and one escalation path. Ask how it works here today. Don't pretend to know the seam | Peer rounds price how you'd work alongside others. CASE because it is a live problem |
| P2 | "How do you handle credit when an improvement involves other people?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | "We" for context, "I" for your contribution. Answer slot: if others worked on the pick-path redesign, name their part and yours. If it was yours alone, say so plainly | Peers test credit-sharing. EXP because it is about attribution |
| P3 | "What would you need from the people already running these terminals in your first month?" | CASE | [generic] | Reciprocity first: what you would bring them, then what you'd ask for (their numbers, their problems, time on the floor). Future tense throughout | Shows you'd reduce their load, not add to it |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites (F1) | A1, A2, B3, P3 |
| Drive on-time performance down (F2) | B1, V3, P1 |
| Drive cost-per-shipment down (F3) | B2 |
| Lead a team of 12 supervisors (F4) | A1, V2, B3 |
| Build reporting in Excel (F5) | C3 |
| Build reporting in Power BI (F6) | A3, C3, D3 |
| 5+ years operations leadership required (F7) | A4 |
| Lean/Six Sigma a plus (F8) | E3, C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured here, and where does it stand at each of the four sites?" | It shows you think in definitions before targets, and it tells you your starting line |
| R2 | "How are the twelve supervisors spread across the sites, and is there a site-lead layer between them and this role?" | It sizes the span-of-control jump at the heart of A1, which is diligence you genuinely need |
| R3 | "What reporting exists today in Excel or Power BI, and who maintains it?" | It sizes your Power BI ramp honestly and shows you're already thinking about the reporting part of the job |
| R4 | "What do you see as the biggest driver of cost-per-shipment right now?" | It brings out their own diagnosis and shows you'll go after the stated metric |
| R5 | "What would success look like at six and twelve months?" | It gets their scorecard in their own words, which you'll be judged against |
| R6 | "Is this a new role or a backfill, and what would you want done differently?" | It shows what the role is really for |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has run multi-site or four-site operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's own observation: your material describes your current operation, not four sites. A1's slot stays inside what you've led |
| Has terminal operations experience | Inflated form of F1 (warehouse and distribution relabelled as terminal) | "7 years in warehouse and distribution ops" at its own scope. A2's slot asks only what your work involved |
| Has led a team of twelve supervisors, or a team that size | Inflated form of F4 | "currently a senior shift manager over 3 supervisors" at its own scope. A1's and F4's slots stay with when and how many |
| Has seven years of operations leadership | Inflated form of F7 (seven years in ops relabelled as leadership) | F7's quotes at their own scope. A4's slot asks for the actual number |
| Has built Power BI reports or dashboards | A negative you stated, F6 | "I haven't used Power BI." No slot |
| Designed or built the peak-season surge plan | Inflated form of "ran the site's peak-season surge plan two years running" | The quote, with "ran" kept. V3's slot holds anything further |
| Led Lean or Six Sigma projects, or holds a higher belt | Inflated form of F8 | "green belt certified" at its own scope. E3's slot asks only what you've applied it to |
| The pick-path redesign was a Lean or Six Sigma project | Inflated pairing of F8's two quotes | Keep the two quotes separate unless you say otherwise. F8's slot covers it |

## Sources

- Provided: your message (the JD text and your background).
- Search "\"Atlas Freight\" values": refused.
- Search "\"Atlas Freight\" interview process operations manager": refused.
- Search "\"Atlas Freight\" regional logistics news 2026": refused.
- No dossier consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Refused. It would have supplied value names for the V bank and, if a values-style round exists, a values cheat sheet |
| 2. `Atlas Freight interview process operations manager` | unavailable | Refused. It would have named the rounds and replaced the flat persona weights |
| 3. `Atlas Freight strategy` / recent news | unavailable | Refused. It would have grounded E2 and at least one CO or CASE question in current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who you're meeting (manager, peer, panel, recruiter) → real persona weights, with the banks trimmed and deepened for that person
- The interviewer's name → an interviewer read, plus a reverse question tied to their own career path
- Web search allowed → targets 1 to 3 rerun: Atlas's values in the V bank, its loop structure in the persona table, and a CO question grounded in current news
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a strategy and context brief that sharpens B1, B2 and E2
- Any recruiter guidance (focus areas, a presentation or exercise) → a build section for any graded deliverable
- Your answers to the slots on F2, F3, F5 and F7 (whether you tracked on-time results, a cost measure, reports you built, years leading people) → those rows, and V3, B2, C3 and A4, rewritten as story-mapped guidance
- Your green belt certificate and any project write-up, or before-and-after mis-pick figures → F8 and C1 raised from medium toward high
- Your resume → titles and dates that settle F7 and may add evidence for F2 and F3
- How much prep time you have → a prioritized prep schedule
- A `tuesday-dossier.md`, if you have one → an objection drawn from confirmed evidence, and a prohibited-claims list built from what you verified
