# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight. Interviewer: not known. Round type: not known, so this pack covers a full loop with flat persona weights. That makes it noticeably weaker than a pack built for a known round (see the upgrade menu).

## How to use this pack

Two axes run through everything:

- **Personas** describe how a question is asked: who is asking and in what style.
- **Types** describe what is being scored:
  - **VAL**: behavioral or values alignment. Does your past behavior show the values they care about?
  - **EXP**: work-experience deep-dive. Do your claims hold up, and what was actually you?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on them?
  - **CASE**: a live problem from the role. Is your reasoning structured?

Provenance labels: `[grounded]` traces to what you or the JD said. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern that makes no claim about you or Atlas Freight.

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview itself. It means: if you did the thing, say how in your own words; if you didn't, say so plainly. Both branches are honest answers.

Question IDs use a letter per persona. F is skipped because F1 to F7 are the fit-snapshot rows.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution ops and one site's peak plan. The JD describes terminal operations across four sites. Keep the words at your scope: "Seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the four-site line makes a probe on multi-site or terminal work likely. If any of your work spanned more than one site or ran through a freight terminal, say which and what part was yours, in your own words. If none did, say so plainly and stay with the site you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate measures accuracy. It is not on-time performance or cost per shipment, so keep the bridge at the quote's scope: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: expect a probe on on-time and cost. If the pick-path change, or any other work of yours, moved an on-time or cost figure that you tracked, say which figure and how it was counted. If none was tracked, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Going from three supervisors to twelve is the first gap an interviewer will see, so don't stretch the bridge. Words: "I'm currently a senior shift manager over three supervisors." Answer slot: if you have led a larger group of supervisors or leads at any point, say when and how many, in your own words. If you haven't, say so plainly, describe how you lead the three, and present the structure for twelve as a plan |
| F4 | "build reporting in Excel/Power BI" (the Excel half) — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-rating, while building reporting is a specific output. Your material does not show whether you have built reports. Answer slot: the JD asks you to build reporting, so expect "what have you built?" If you have built a report or tracker that others used, say what it tracked and who used it, in your own words. If you haven't, say so plainly and say what you use Excel for day to day |
| F5 | "build reporting in Excel/Power BI" (the Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | No wording can close this gap, and you have said so yourself. Words: "I've never used Power BI." Then explain how you would learn it, as a plan for the future and never as something you've already done. Never claim any Power BI work, and add nothing to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [grounded] | discovery | The seven years in ops are clear. Your material does not show how many of those years were in leadership roles. This is a length-of-experience line, not a gate, but expect it to be checked. Answer slot: give the actual number of years you have led people, and in which roles, in your own words. If the number is under five, say it plainly and stay with the seven years in ops and your current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap: "I'm green belt certified." Confidence is medium only because nothing has been inspected, so a prober may ask where you used it. Answer slot: if any project of yours used Lean or Six Sigma methods, name it and your part. If the pick-path redesign wasn't run that way, don't present it as if it were |

## Persona table

No loop source establishes Atlas Freight's interview process. The company research needed web search, and the searches were refused (see Sources). The weights below therefore use the generic archetype fallback (screen, then hiring manager, then panel): flat weights, said plainly. They rest on a pattern, not on this company's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scale jump and the tool gap | Flat weight, but this is where the gaps in F1, F3, F5 and F6 sit, so the deepest rehearsal (A1) is here whichever round you face | Rehearse A1 until it's boring. Bridge only from what you actually said, name the limit plainly, then give a concrete ramp plan |
| Case/Strategist | Live problems from the role: diagnosing on-time performance, cost per shipment, a 90-day plan | Flat. Hiring managers lean this way, and the JD's two named metrics make it likely | Clarify, objective, segment, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Data-Driven Prober | Goes two levels deep on the 40% | Flat. A single headline number like the 40% attracts probers | Know what you can and can't say about how the 40% was counted. Say plainly what you don't know |
| Pressure | Interrupts, time-boxes, asks "how much was actually you" | Flat. Common in panels and with senior interviewers | Pause, restate the question, anchor in what you actually did, and hold your position through two follow-ups before conceding anything real |
| Conversational | Friendly openers about your journey and your Lean interest | Flat. Most rounds open this way, and the casual questions are still scored | Have a prepared 90-second arc built only from your own lines |
| Peer Evaluator | A fellow site lead or ops peer asking about seams, credit and what you'd bring | Flat. Possible if a panel includes peers | Use reciprocity framing and propose seam principles. Don't pretend to know their seams |
| Values/Behavioral | STAR-shaped stories on leading people and handling pressure | Flat. No values-style round is detected: the fallback archetype has none, and no values page was read | Pick stories you can tell in full. "We" for context, "I" for your contribution |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors today. This role is twelve, across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **Highest-ROI rehearsal in this pack.** Name the limit before they do: "Today I'm a senior shift manager over three supervisors, and this role is twelve across four sites. That's a real step up." Then add what you have: "I ran the site's peak-season surge plan two years running." Answer slot (F3's): if you have led a larger group of supervisors or leads, say when and how many; if you haven't, say so plainly. Then give the plan for twelve: how you'd learn each site, set a daily rhythm with the supervisors, and decide where your time goes. Present it as a plan. Follow-up 1, "what breaks first?": answer from the plan. Follow-up 2, "how do you know you can?": go back to the three supervisors and the surge plan, and add nothing to them | F3 and F1 are where the JD presses hardest. The scale gap will be raised in some form in any round. JD because it scores the stated team-size and multi-site requirements |
| A2 | "I don't see Power BI in your background. How would you handle the reporting this role needs?" | JD | [grounded] "solid Excel, never used Power BI" | Plain acknowledgment first: "I've never used Power BI. My Excel is solid." Answer slot (F4's): if you have built a report or tracker others used, say what it tracked; if you haven't, say so plainly. Then the plan: what you would learn first and how you would confirm which reports the business needs before building any. Don't make the gap sound smaller than it is | F5 is a stated capability gap and F4 is unshown, so honesty plus a plan is the whole answer. JD because reporting is a listed responsibility |
| A3 | "Your background is warehouse and distribution. This role owns terminal operations. What transfers, and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start with your own line: seven years in warehouse and distribution ops. Then give your honest read of the difference, as your understanding of the role and not as experience. Answer slot (F1's): if any of your work ran through a freight terminal or across sites, say which and what part was yours; if none did, say so plainly. Close by asking how their terminals run day to day. It's a fair question, and it shows you're not pretending | F1 is transferability, not a direct match, and an interviewer from terminal ops will test it. JD because it scores the headline responsibility |
| A4 | "How many of your seven years have been in leadership roles?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot (F6's): give the actual number of years you've led people, and the roles, in your own words. If it is under five, say the number plainly, then stay with the seven years in ops and your current role. Don't round up | F6 checks the JD's one stated minimum. JD because it's a listed qualification |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals dropped ten points last month. Diagnose it." | CASE | [generic] | Clarify first: how is on-time defined (pickup, delivery or appointment), when did it start, and is it all lanes or some? Segment by shift, lane, carrier, inbound versus outbound, and dock. Form hypotheses: volume mix, staffing, late inbound arrivals, dock congestion, or a data or definition change. Check the data before acting, fix the biggest driver, and say how you would know the fix worked. The question needs no claim about your past, so the guidance makes none | Built from the JD's on-time line. CASE because it's a live problem; `[generic]` because it's a pattern, not Atlas Freight's actual data |
| B2 | "Cost per shipment is up across the network. Where do you look first?" | CASE | [generic] | Clarify the numerator (labor, overtime, equipment, claims, rehandling) and the denominator (what counts as a shipment). Separate a volume effect from a cost effect. Compare the four sites. Split quick wins from structural fixes. Name your weakest assumption aloud, for example that the shipment count is consistent across sites | Built from the JD's cost-per-shipment line, so the role's second named metric gets its own case |
| B3 | "Your first 90 days with twelve supervisors across four sites. What do you do?" | CASE | [generic] | Present it as a plan: visit each site and meet each supervisor one to one; take a baseline of on-time performance and cost per shipment per site; set one daily reporting rhythm; pick one improvement to pilot at one site before spreading it. Say what you'd hold off on changing until you've seen the sites | Built from the team-size and multi-site lines (F3, F1). CASE because it's scored on structure |
| B4 | "Peak is coming across all four sites. How would you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Start from your own line: you ran the site's peak-season surge plan two years running. Answer slot: if parts of that plan were yours to set, say which and how you decided; if it was set for you and you ran it, say so plainly. Then scale it to four sites as a plan: what you would standardize, what each site keeps, and how you would track it | F1's strongest evidence, applied to the JD's multi-site scope. CASE delivery with EXP grounding |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 40% mis-pick reduction. How was the rate counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number in your own words. Answer slots: how the mis-pick rate was counted and over what period; what it is sensitive to, such as volume swings or a change in how errors were logged; the assumption behind it you'd defend least, which you should name before they do; and which part was yours. If you don't know how it was counted, say so plainly. That is an honest answer | The CV-style headline figure (F2) is the prober's first target. EXP because it tests the claim itself |
| C2 | "What did the pick-path redesign actually change?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats are in your line: the pick path, redesigned, and the rate cut. Describe what changed in your own words. Answer slot: if others worked on it, say who did what and what was yours; if it was yours alone, say so | F2's story, asked as a method question. EXP because it checks attribution |
| C3 | "What numbers do you look at every day, and how do you report them?" | JD | [inferred] "solid Excel" | Answer slot (F4's): name the measures you actually track and how you report them. If you build the report, say what's in it; if someone else owns reporting, say so plainly and say what you see. Don't name measures you don't track | The JD's reporting line raises it, and F4 is unshown. JD content with EXP delivery |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then give three of your own lines: the seven years, the 40% mis-pick cut, and the surge plan two years running. Add green belt certified as the fourth if time allows. Concede the real point: an internal candidate knows the terminals. Hold on what you bring, and don't claim terminal knowledge | Pressure tests composure on F1's gap. JD because it's a fit judgment |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede. Restate your line. Answer slot: say which part was yours and who else contributed. Hold that position through two follow-ups. If part of the credit belongs to others, say so specifically rather than vaguely, and don't fold on what was yours | F2 under attribution pressure. Rehearsing candor here beats improvising it |
| D3 | "You've never used Power BI, and this job builds reporting in it. Why should we wait for you to learn?" | JD | [grounded] "solid Excel, never used Power BI" | Don't argue the fact: "I've never used Power BI. My Excel is solid." Hold on the plan, and give a time frame you would actually commit to. Concede that there's a learning curve. Don't promise a skill level by a date you can't back | F5 under pressure. JD because reporting is a listed duty |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from these lines: seven years in warehouse and distribution ops, now a senior shift manager over three supervisors, the 40% mis-pick cut, the surge plan two years running, and green belt certified. End with why this role, in your own words | The opener in most rounds. The arc keeps you inside F1 to F7 when the tone is casual |
| E2 | "Are you doing much with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot (F7's): if you've used it on a project, name the project and your part; if not, say so plainly and say where you would apply it here | F7 is the JD's plus-skill, asked casually but still scored |
| E3 | "What drew you to Atlas Freight?" | CO | [generic] | Give your actual reason in your own words. Use only what you know from the posting (a regional logistics company with 800 employees, and this role's four sites) plus anything you've verified yourself. Don't claim knowledge of their strategy | Company research didn't run, so this stays generic (see the upgrade menu) |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites compete for the same people and trucks. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than claiming to know their setup: shared data on volume, an agreed rule for who gets priority, and escalation only after you've talked directly. Ask how it works today | A peer is pricing whether you add to their load or reduce it. Built from the JD's multi-site line |
| G2 | "How do you handle credit when an improvement spans shifts or teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use "we" for the context and "I" for your contribution. Answer slot: if others worked on the pick-path redesign, name their part alongside yours; if it was yours alone, say so | F2 in collegial packaging. EXP because it checks attribution |
| G3 | "What would you need from me, and what would you bring my team in the first month?" | CASE | [generic] | Reciprocity first: what you would offer, such as an open daily handoff and shared numbers. Then one concrete ask | The standard peer probe on partnership fit |

### H. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you held a supervisor accountable for performance." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a time with one of your supervisors. It needs a clear expectation, a conversation you had, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Built from the JD's team-size line (F3). VAL in STAR form. Not mapped to published values, because none were read |
| H2 | "Tell me about a time your plan had to change under pressure." | VAL | [generic] | Selection scaffold: pick a time with a real deadline, a decision you made, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Operations interviewers commonly ask a version of this. `[generic]` because it's a pattern |
| H3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you didn't fold, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem that tests spine and tact |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B3, B4, D1, G1 |
| "drive on-time performance" | B1 |
| "cost-per-shipment down" | B2 |
| "lead a team of 12 supervisors" | A1, B3, H1 |
| "build reporting in Excel/Power BI" | A2, C3, D3 |
| "5+ years operations leadership required" | A4 |
| "Lean/Six Sigma a plus" | E2 |
| Your 40% figure (defend the number) | C1, C2, D2, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you measure on-time performance here: pickup, delivery, or appointment? And where does each site stand today?" | Shows you know the definition matters, and it gives you the baseline you'd be judged against |
| R2 | "What goes into cost per shipment in your numbers, and what has driven it lately?" | Shows you think in numerators and denominators, and it tells you what you'd inherit |
| R3 | "How are the twelve supervisors spread across the four sites, and how much time would you expect me to spend at each?" | Takes on the scale question directly and tells you what the job is like day to day |
| R4 | "What reporting exists today, and what would you want built first in Excel or Power BI?" | Scopes your Power BI ramp honestly and shows you'd ask before building |
| R5 | "What would make the first 90 days a success in your eyes?" | Gets their scoring sheet and anchors your plan (B3) to it |
| R6 | "Is this a new role or a backfill, and what did the previous approach get right?" | Tells you what the role is really for, without criticizing anyone |

## Prohibited claims

What this pack will not coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran operations across multiple sites or terminals | Inflated form of F1 | F1's quotes at their own scope. The pack's observation: your material describes warehouse and distribution ops and one site's peak plan. The A3 and B4 slots stay inside what you ran |
| Designed or built the peak-season surge plan | Inflated form of F1's second quote (the verb "ran" becoming "designed") | "ran the site's peak-season surge plan two years running." The B4 slot asks only which parts were yours to set |
| Led a team of twelve, or a large team of supervisors | Inflated form of F3 | "currently a senior shift manager over 3 supervisors." The A1 slot asks only about groups you actually led |
| Improved on-time performance or cost per shipment | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path." The pack's observation: that is accuracy, not on-time performance or cost |
| Built Excel reports or dashboards for the operation | Inflated form of F4 | "solid Excel." The C3 slot asks only what you actually build or see |
| Has used Power BI | A negative you stated (F5) | "I've never used Power BI." No slot |

## Sources

- Provided: the JD text you pasted; your background as written in your message.
- No dossier was present.
- Searches sent, all refused because web search permission was not granted in this session:
  - "Atlas Freight values mission regional logistics": refused
  - "Atlas Freight interview process operations manager": refused
  - "Atlas Freight news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The search was refused. It could have themed the H bank on published values, and a values cheat sheet would have followed if a values round were detected |
| 2. Atlas Freight interview process, operations | unavailable | The search was refused. It would have named the actual rounds and replaced the flat fallback weights |
| 3. Atlas Freight strategy or recent news | unavailable | The search was refused. It would have grounded E3 and one CASE question in their current priorities |
| 4. Interviewer name at Atlas Freight | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you're meeting (hiring manager, peer, panel, or the recruiter) → reweights every bank. For example, a hiring-manager round moves Case and Skeptic up and cuts Peer.
- The interviewer's name → an interviewer read, persona weights based on their public footprint, and a reverse question tied to their path.
- Web search permission for company research → Atlas Freight's published values, interview process and recent news. That would give a CO question and a CASE question grounded in their strategy, and persona weights based on their documented process. "Atlas" is a common company name, so results that can't be tied to this employer would be set aside.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy and org-context brief for sharper CO and CASE questions.
- Your answers to the slots in F2, F3, F4 and F6 (on-time or cost figures you tracked, larger groups you've led, reports you've built, years in leadership) → those rows move from slots to story-mapped guidance in A1, A4, B4, C1 and C3.
- Your resume → exact titles and dates, which settle F6, plus more lines to map stories from.
- The before-and-after mis-pick data, or the report you used to track it → raises F2's confidence and gives C1 a firmer footing.
- Your green belt certificate → raises F7 from medium to high.
- The recruiter's prep email, if there is one → coverage of any pre-declared deliverable, such as a case presentation or a site walk.
- How much prep time you have → a prioritized prep schedule.
- A tuesday-dossier.md from an earlier session → evidence graded against confirmed claims, and a prohibited list built from what you've already verified.
