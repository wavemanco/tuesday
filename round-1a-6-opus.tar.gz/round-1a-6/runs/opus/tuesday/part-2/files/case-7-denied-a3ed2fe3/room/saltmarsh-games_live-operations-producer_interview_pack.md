# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Format:** one 60-minute interview, Friday
**Assumed relationship:** hiring manager. A Head of Live Operations interviewing for a Live Operations Producer is most likely the role's manager, but nobody has confirmed it. If that's wrong, the persona weights change.

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking, and in what style. **Types** describe *what is being scored*.
- Type key:
  - **JD**: can you do the listed job, gaps included
  - **EXP**: does what you've done hold up under close questioning; what was actually yours
  - **CASE**: a live problem from the role, solved out loud
  - **CO**: homework on the company and its games
  - **VAL**: behaviour against values (generic here, because no published Saltmarsh values were found)
- **Provenance labels:** `[grounded]` = traceable to your message or the JD. `[inferred]` = this pack's derivation, with the derivation named. `[generic]` = a role-family pattern with no claim about Saltmarsh or you.
- **Answer slot:** the pack says what is likely to be asked and gives you two honest branches. Only you know which branch is true, so the pack never answers it for you.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage

The interview is Friday, so this assumes you have about one evening.

1. **B2, out loud, three times.** This is the highest-ROI prep in the pack. Practise holding on your own sentences through two follow-ups.
2. **Choose your honest branch for each answer slot in F1, F3, F5 and F7** (snapshot below). Write one line each in your own words. These are the four places Tobias is most likely to dig.
3. **A1 and A2 (the cases).** Talk through the structure out loud once each: clarify, objective, options, metrics, risks.
4. **D1, the 90-second "walk me through your journey".** Time it.
5. **Pick three reverse questions** from the list near the end.
6. **If you know which two titles the role covers, play both tonight** (D2).

Everything else is insurance.

---

## Fit snapshot

Your evidence is quoted from your message. Requirements are quoted from the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one main title's weekly content-drop calendar. The JD describes live events across two mobile titles. Keep the words at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." **Answer slot:** the JD's "live-events" makes a probe on events likely. If any drops were timed events, say which ones and what part was yours, in your own words. If they weren't, say so plainly and stay with the drops. If you planned for any title besides the main one, say so. If you didn't, say that plainly too |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a calendar touches coordination, but your material doesn't show it. **Answer slot:** if work from design, art, engineering or community fed the drops, say which teams and what part of lining them up was yours. If that coordination sat with someone else, say so plainly and describe how you ran the calendar. The JD asks you to coordinate, not to lead, so your "never led a team" doesn't answer this row either way |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | transferability | Presenting numbers is not owning a review, so don't stretch the bridge. Words: "I presented the monthly retention numbers to the studio head." **Answer slot:** if you built those numbers or looked back at how drops performed, say how, in your own words. If you presented numbers someone else produced, or there was no look-back, say so plainly. Then describe what you would want a post-event review to answer, as a plan and not as a past |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in kind, but it's a single line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you wrote it, and QA still uses it. **Answer slot:** the JD says "manage", so expect "who ran it release to release?" If you did, say so. If QA ran it after you wrote it, say so plainly |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material gives four years at the studio and two on the calendar. It doesn't show how many of the four were on a live title, or which platform. **Answer slot:** if all four years were on a live game, say so. If only part were, say which part plainly. The JD names mobile titles, so if the puzzle game was on mobile, say so. If it wasn't, name the platform plainly. Not a gate: years of experience are graded like any other requirement |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your strongest row. Lead with it as written: weekly, main title, the last two years. A named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Lead with the quote. A Head of Live Ops will likely ask what was in those numbers. **Answer slot:** if asked which retention measures the monthly report used, name them and say how they were counted, in your own words. If you don't know how a figure was counted, say that plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [inferred] | transferability | A checklist another team still uses is one kind of writing, not the whole requirement. Words: "I wrote the release checklist our QA team still uses." **Answer slot:** if you wrote other things people relied on, such as calendar notes or update summaries, name one. If not, say so and say how you would keep teams informed. The interview itself is also evidence here: answer in short, structured sentences |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Live-events calendar for two mobile titles (F1) | A1, B2, E1 |
| Coordinate design, art, engineering, community (F2) | A3, B4, G1, G2 |
| Post-event review and its KPIs (F3) | A2, B2, C2, C3 |
| Release checklist with QA (F4) | A4, E2 |
| 3+ years producing live-service (F5) | B3, B5 |
| Content calendar experience (F6) | A1, B2, D1 |
| Player-retention metrics (F7) | A2, C1, C2 |
| Clear written communication (F8) | A5, D3 |

---

## Persona table

The loop wasn't established: no recruiter note was given, and the searches for Saltmarsh's process were refused. These weights therefore rest on the **generic archetype** (screen, then hiring manager, then panel) plus the assumed hiring-manager relationship. They are not based on Saltmarsh's documented process.

| Persona | How it shows up with Tobias | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Two titles want the same week. What do you do?" | High. A hiring manager is buying the ability to do the job, and live ops is scheduling, trade-offs and reviews, all of which make natural live cases | Clarify, then objective, options, metrics, risks. Think aloud. Challenge one premise politely |
| Skeptic | Quiet probing of the jump: from one title's calendar to two titles plus owning the review | High. F1 and F3 are the widest seams between your material and the JD. A manager derisking a hire goes there | Rehearse B2 until it's boring. Hold on your own sentences, and say the limits plainly |
| Data-Driven Prober | "What was in the retention numbers? How was retention counted?" | Medium. The JD says the role owns KPIs, and a live-ops head will know retention definitions well | Know what you can and can't say about how each figure was counted. Say "I don't know" where that's true |
| Conversational | "So, walk me through your journey" / "What have you played of ours?" | Medium. Almost every 60-minute manager interview opens and closes this way, and it's still scored | Use the 90-second arc (D1). Treat casual questions as scored |
| Pressure | "Sixty seconds: why you?" / "How much of that checklist was actually you?" | Low. Nothing points to a stress style, but a short time-boxed probe is common | Pause, restate the question, anchor on what you said, and hold through two follow-ups |
| Peer Evaluator | "Engineering says the date won't work. What happens next?" | Low. A peer round, if there is one, would come later. Still, the JD is all coordination, so expect it in collegial packaging | Frame it as what you bring each team. Propose principles rather than pretend to know their process |
| Values / Behavioral | "Tell me about a time you delivered an unpopular truth" | Low. No values round was detected and no published values were found | Pick real stories. Where none fits, say so |

Question IDs skip the letter F so they don't collide with the fit-snapshot rows (F1 to F8).

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Both titles want the same week for a big event. How do you decide, and how do you build the calendar around it?" | CASE | [generic] | Clarify first: what each event is for, which KPI it is meant to move, and what each one depends on from art and engineering. Then lay out the options: stagger them, scale one down, or swap one with a later slot. Say how you'd choose (player impact, team capacity, risk), who signs off, and how you'd tell design, art, engineering and community. Close with the risk you'd watch. The question needs no claim about your past, so the guidance makes none | This is the core of the JD's two-title calendar line (F1). CASE because it tests structure live, and it's the problem this role meets first |
| A2 | "An event has just ended and retention for players who joined during it looks worse than usual. Walk me through your post-event review." | CASE | [generic] | Clarify the cohort and the baseline: worse than what? Segment new against returning players, participants against non-participants, and by platform. Check for confounds: a buggy release, overlap with another drop, a change in store featuring. Form a hypothesis, say what you'd report and to whom, and say what you'd change on the next calendar. Name the measure you'd trust least and why, in your own reasoning | The JD gives the post-event review and its KPIs to this role (F3, F7). CASE because Tobias can watch you reason with retention, which is the thinnest part of your material |
| A3 | "Three weeks out, art tells you the event's assets will be a week late. What do you do?" | CASE | [generic] | Confirm the scope and the cause. Then options: cut scope, reuse assets, slip the event, or swap it with a later calendar slot. Say who decides, what you tell engineering and community and when, and how the release checklist changes. A pattern, not a story about you | Tests the JD's coordination line (F2) as a decision rather than a record |
| A4 | "How would you run the release checklist with QA when both titles ship updates in the same month?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Open with what is yours, in the quote's terms: you wrote the release checklist, and QA still uses it. **Answer slot:** the JD says "manage", so if you ran it release to release, say how in your own words; if QA ran it after you wrote it, say so plainly. Then the two-title plan as a plan: shared items against title-specific ones, who calls go or no-go, and when sign-off happens | F4 is your cleanest match, and this turns it toward the two-title scope. JD content with CASE delivery |
| A5 | "Talk me through the note you'd send the community team the day an event has to slip." | JD | [generic] | Keep it short and structured: what changed, why (one sentence), what players will see, what you need from community and by when, and when the next update comes. Say it in the order you'd write it | Tests "clear written communication" (F8) directly, and community is one of the four teams the JD names |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one JD item where your material is thinnest. The pack's own reading is that F2 (coordination) and F3 (owning the review) are the seams, and only you know which is truer. Say it plainly, then give a concrete plan for the first weeks. If the conversation goes to monetized events or managing people, your own words are available: "I haven't worked on a game with in-app purchases" and "I haven't led a team." Follow each with how you'd learn it, as a plan. Don't invent a weakness or dress up a strength as one. The JD asks you to coordinate, not to lead, so don't offer "I haven't led a team" as if it answered F2 | A predictable manager question. It's the safe place to say your two stated gaps on your own terms before they're found |
| B2 | "You've run a weekly content-drop calendar for one title. This role is live events across two titles, plus owning the review and the KPIs. Why are you ready for that step?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | **The highest-ROI rehearsal in this pack.** Hold only on what the quotes carry: "For the last two years I ran the weekly content-drop calendar for our main title, and I presented the monthly retention numbers to the studio head." **Answer slot, events:** if any drops were timed events, say which ones and what part was yours; if not, say so plainly. **Answer slot, review:** if you built the numbers or looked back at how drops did, say how; if you presented numbers someone else produced, say so plainly. Then give the step up as a plan: what you'd learn first about two calendars and a review. Hold through two follow-ups by returning to the calendar, never by adding to it. The honest branch is a limit, not a confession | F1 and F3 are where your material and the JD are furthest apart, so this objection arrives in some form. Deepest rehearsal, because a calm, unpadded answer here changes the hour |
| B3 | "The JD asks for 3+ years producing live-service games. How much of your four years was on a live game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Give the four years and the two on the calendar exactly as stated. **Answer slot:** if all four years were on a live title, say so; if only part were, say which part plainly. The JD names mobile titles, so if the game was on mobile, say so; if it wasn't, name the platform plainly and move on | F5's open question. A literal reading of "3+ years" is likely, so the plain answer should be ready before the question arrives |
| B4 | "Tell me about getting design, art, engineering and community lined up for one of your content drops." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6: the weekly calendar, the main title, the last two years, told in your own words. **Answer slot:** the JD's coordination line makes this probe likely. If those teams' work fed the drops, name one drop, say which teams were involved and what part of lining them up was yours. If that sat with someone else, say so plainly and describe how you ran the calendar | F2 is a discovery row. This is where Tobias finds out what's behind it, so choose your branch tonight |
| B5 | "You've been an associate producer. What makes you ready for a producer role?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Use the title as it was: associate producer, four years. Then give the two things you did in their own words: the weekly content-drop calendar and the release checklist QA still uses. **Answer slot:** if your scope grew over the four years, say how in your own words. If not, stay with what you did. Let Tobias draw the "ready" conclusion. Don't assert it on your own behalf | The title step is visible on paper. EXP because it tests whether you describe your role at its true size |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. What was in them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote: you presented them monthly to the studio head. **Answer slot:** name the measures the report used and how each was counted, in your own words. Say which part was yours: building them, or presenting them. If you don't know how a figure was counted, say so plainly; that's an honest answer. Don't learn a definition tonight and present it as your past practice | F7 rests on this one line, and a live-ops head is the person most likely to ask for definitions |
| C2 | "Tell me about a time a retention number changed what you put on the calendar." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." "I ran the weekly content-drop calendar for our main title for the last two years." | **Answer slot:** the JD joins KPIs to the calendar, so expect this. If a retention result ever changed a drop, say what changed and what part was yours. If the two never connected in your role, say so plainly, then say how you'd connect them here | This tests whether F3 and F7 link up in your experience. The honest branch is fine if you say it cleanly |
| C3 | "What KPIs would you put in a post-event review, and which would you trust least?" | CASE | [generic] | Structure the answer: participation, the retention of event cohorts against a baseline, engagement during the event, and player sentiment from community. If the event has paid offers, include revenue and say who owns it. Then the weakest-assumption move: name the measure you'd trust least and why, in your own reasoning | F3 asks the role to own these KPIs. CASE because it's a design problem, not a record |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of these four sentences, in your own words: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist QA still uses; the monthly retention numbers you presented to the studio head. **Answer slot:** close on why this role, in your own words | The near-certain opener, and it sets the frame for the hour |
| D2 | "Have you played our games?" | CO | [generic] | The JD doesn't name the two titles. If you know them or can find them, play both tonight, notice one live event or update in each, and have one specific observation ready. If you haven't played them, say so plainly. Faked familiarity fails in one follow-up | The cheapest homework signal there is. CO, kept generic because no research on Saltmarsh ran |
| D3 | "How do you like to keep people informed during an update?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Mention the checklist as a written thing a team still relies on, in the quote's terms. **Answer slot:** if you wrote other things teams used during updates, name one. If you didn't, say so and describe how you'd do it here: what goes out, to whom, and when | A casual route into F8, and still scored |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause, then use two sentences from your own material: the weekly content-drop calendar for two years, and the release checklist QA still uses. Then one line on what you'd bring fresh, in your own words. Don't knock the internal candidate. If interrupted, finish the sentence you're on and stop | A time-boxed test of composure on F1 and F6. JD, because it's really "can you do this job" |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it, and QA still uses it. **Answer slot:** if others added items, say so plainly; if you kept it up to date, say so. Hold through two follow-ups by repeating what you did, and concede only what's true. Don't add new achievements under pressure | F4 is your cleanest claim, which makes it the natural target for an attribution probe |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Engineering says the update is too big for the date you've put on the calendar. What happens next?" | CASE | [generic] | Ask what's driving their estimate. Separate what must ship from what could follow. Offer options (split, slip, cut), agree who decides, and confirm it in writing. Show spine and tact together: you protect the calendar without overruling the people who build it | The JD's coordination line (F2) as a disagreement between equals |
| G2 | "What would you need from the art and engineering leads to run their calendar well, and what would they get from you?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The reciprocal side: as an example of something you gave a team, the checklist QA still uses, in the quote's terms. What you'd need: early scope, honest estimates, a named contact. What they'd get: a calendar they can plan around and early warning of changes | Pricing what you add to other teams' work. F2 seen from their side |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, the moment you said it, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem. Generic, because no Saltmarsh values were found |
| H2 | "Tell me about a time a release didn't go to plan." | VAL | [generic] | Selection scaffold: pick a release where something went wrong. It needs what went wrong, what you did, and what changed afterwards. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The JD's release-checklist line makes release trouble a natural theme, and live ops lives with it |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here: who's in the room, and what decision does it feed?" | Goes straight at the JD line you're thinnest on (F3) and shows you're thinking about owning it |
| R2 | "Are the two titles planned on one calendar or two, and how far ahead?" | Shows you're already picturing the job, and the answer tells you the real scope of F1 |
| R3 | "Which KPIs does the review report today, and is there one you'd like this role to change?" | Invites Tobias to talk about his own priorities, and prepares you for the metrics work |
| R4 | "When two teams disagree on a date, who makes the call?" | Shows you know coordination is where live ops goes wrong, and tells you how much authority the role has |
| R5 | "How do live events work with monetization on these titles, and who owns that side?" | A real question you need answered, given that you haven't worked with in-app purchases. Asked as curiosity, it tells you what you'd need to learn |
| R6 | "What would you want this person to have taken off your plate by month three?" | Turns the hour toward his needs and gives you a concrete picture of success |
| R7 | "What are the next steps after today?" | Clears up the process, and tells you whether a further round is coming |

---

## Prohibited claims

These are the claims this pack will not coach. They are the ones a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar, or ran live ops across multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says a weekly content-drop calendar for the main title, not live events or more than one title. B2's slots stay inside that |
| Owned the post-event review or the KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says you presented the numbers, not that you owned them. C1's slot asks only what was in them and which part was yours |
| Managed the release process or QA | Inflated form of F4 | F4's quote: "Wrote the release checklist our QA team still uses." A4's slot asks only who ran it release to release |
| Held the producer title | Inflated form of F5's first quote | "4 years as an associate producer at a puzzle-game studio." Say the title as it was |
| Has led a team | A negative you stated | "Never led a team, and never worked on a game with in-app purchases." Plain words: "I haven't led a team." |
| Has worked on in-app purchases or monetized events | A negative you stated | Same sentence. Plain words: "I haven't worked on a game with in-app purchases." Then how you'd learn it, as a plan |

---

## Sources

- **Provided:** the JD text and your background, both from your message.
- **Searches sent:** 4, all refused (web search permission was not granted in this session):
  - `Saltmarsh Games values mobile game studio`: refused
  - `Saltmarsh Games interview process producer`: refused
  - `Saltmarsh Games mobile news 2026`: refused
  - `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused
- **Fetches:** none.
- **Dossier:** none present. The pack was built from raw inputs.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Refused. It would have supplied published values for a values cheat sheet and given the VAL questions real themes |
| 2. `Saltmarsh Games interview process producer` | unavailable | Refused. It would have shown whether this 60 minutes is one round of several, and replaced the generic-archetype persona weights |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Refused. It would have grounded a CO or CASE question in their current titles and recent moves. D2 and the cases stay generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Refused. It would have supplied an interviewer read and a reverse question tied to his own path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search allowed in this session** → targets 1 to 4 run: published values (a values cheat sheet if Saltmarsh has them), loop structure (weights based on their real process), recent news (a grounded CO question), and Tobias's public professional background (an interviewer read plus a tailored reverse question).
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on Saltmarsh and its titles, and case questions set in their actual games.
- **The names of the two titles** → D2, A1 and A2 can be set in their real games.
- **Your honest branch on the answer slots** (were the drops timed events, did you build the retention numbers, how many of the four years were on a live title, was it mobile) → F1, F3, F5 and F7 get your own words, and B2, B3, C1 and C2 become story-mapped instead of slotted.
- **A recruiter email or agenda for the 60 minutes** → coverage of any case or presentation they've announced, and confirmation that Tobias is the hiring manager.
- **A redacted copy of the release checklist or a monthly retention report** → evidence that can be inspected, which raises F4 and F7 from medium.
- **Your CV** → more of your own sentences to map stories to, especially for H1 and H2.
- **A `tuesday-dossier.md`** → verified evidence and a prohibited-claims list from an earlier fit review, so the highest-ROI objection comes from checked evidence rather than this pack's inference.
