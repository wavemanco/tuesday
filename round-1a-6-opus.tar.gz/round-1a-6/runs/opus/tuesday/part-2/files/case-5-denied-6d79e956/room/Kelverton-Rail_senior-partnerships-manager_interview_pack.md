# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round. A 60-minute panel with Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your POV, with no slides. The other 45 are Q&A, and Ross will push on commercials.
**Built from:** the recruiter's email as you quoted it, and the background in your message. The searches I tried were refused, so nothing in this pack comes from research. I haven't seen the market report. Anything tagged `[generic]` is a role-family pattern, not a fact about Kelverton.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what's being scored.
- **Type key:**
  - VAL: past behaviour against values
  - EXP: whether your stated experience survives scrutiny
  - JD: whether you can do this job, gaps included
  - CO: company and market altitude
  - CASE: a live problem, reasoned out loud
- **Provenance:**
  - `[grounded]`: rests on your own words or the recruiter's.
  - `[inferred]`: a derivation, which the row names.
  - `[generic]`: a pattern, with no claim about Kelverton or about you.
- **The guidance is scaffolding, not a script.** Every claim about your past is limited to the three sentences you wrote. Where a strong answer needs more than those sentences hold, the pack gives you an **answer slot**: you answer from what actually happened, and if nothing happened, you say so plainly.

---

## Prep triage: your four hours

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build the POV. Pick 2 of the 3 theses, choose your one agreement with the report and your one divergence from it, and write the operator close. Then say the whole thing aloud twice with a timer, aiming for 13–14 minutes. | POV build |
| 2 | 45 min | Rehearse the highest-ROI objection, C1, until it bores you. Then work through B1 and B2: write down what you actually know about how the £4M was counted and how many of the 40 partners produced revenue. | C1, B1, B2 |
| 3 | 30 min | Do Ross's commercial set. Sketch a year-one number on one sheet of paper and say out loud the assumption you'd defend least. | B3, B4, C4 |
| 4 | 30 min | Do the rail-gap set, and settle how you'll say your years of experience. | D1, D2, E1 |
| 5 | 20 min | Pick three reverse questions, one for each panellist and one spare. | Reverse questions |
| 6 | 15 min | Read the prohibited list once. Then do a last run of the POV's first 90 seconds and its close. | Prohibited claims, POV build |

Everything else in this pack is insurance.

---

## Fit snapshot

Your three sentences, quoted exactly from your message:

- **Q1:** "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- **Q2:** "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- **Q3:** "Never sold into rail specifically and never carried a direct quota, only influenced revenue."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material describes a payments ISV channel, not rail operator partnerships, so the words stay at that scope: "For four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the brief asks where you'd take partnerships, so expect "what did you change to get from 6 to 40". If specific moves were yours, name them in your own words. If the growth didn't come from a plan you set, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Bus and light rail network planning sits next to train operators but isn't their world, and your own phrase carries its own limit: "from the other side." Words: "I spent five years in transport consulting on bus and light rail network planning, so I know the operator world from the other side." Answer slot: expect a question on what that work showed you about operators. If particular engagements showed you something, say what, in your own words. If it doesn't carry over to train operators, say so plainly and close on what you would go and learn first |
| F3 | "Ross will push on commercials" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Influenced revenue is commercial evidence one step removed, and the figure keeps its "roughly": "roughly £4M of influenced revenue." The answer slots are the four a figure raises: how the £4M was counted and over what period, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. Answer each in your own words. "I don't know exactly how it was counted" is an honest branch |
| F4 | A direct revenue or sourced-pipeline target, which senior partnerships roles in software firms often carry. A role-family pattern with no posting text in hand | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | You stated the absence yourself, so the words are yours: "I've never carried a direct quota. My numbers were influenced revenue." Then describe how you would work to a direct number here, said as a plan and never as a past. Add nothing to make the gap sound smaller |
| F5 | Selling to or partnering with train operating companies. A role-family requirement implied by the company's market, with no posting text in hand | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap you have named yourself. Words: "I haven't sold into rail." Then say how you would learn the operator buying cycle, as a plan. Never imply rail selling through the consulting years: F2 is bus and light rail planning, not selling |
| F6 | Building and scaling a partner programme. A role-family requirement | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap, but the claim rests on your statement alone, so expect a probe. Lead with the channel in Q1's own terms: you ran it, and it went from 6 partners to 40. One open point: Q1's "9 years in partnerships" and Q2's "5 years in transport consulting" can be read as overlapping, 4 + 5 = 9, or as separate. The pack takes the reading that claims less, so never say "9 years of partnerships plus 5 of consulting" unless the years are separate. E1 rehearses this |

---

## POV build: "where you'd take our operator partnerships over the next 18 months"

**What you're graded on:**

- The recruiter's brief: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it."
- The required close: "Please land on what it means for the operators themselves."
- The commercial test that follows: "Ross will push on commercials."

**What you can build on:**

- **About you (F1):** "took it from 6 partners to 40, roughly £4M of influenced revenue". Use it as one sentence of credibility, not as the spine of the POV.
- **About you (F2):** "so I know the operator world from the other side". This is your licence to close on operators, at its own scope: bus and light rail planning.
- **About Kelverton:** the internal market report, which the panel circulated and you've read. I haven't seen it, so every specific fact about the market or about Kelverton comes from you and the report. None comes from this pack.

**Opening, about 90 seconds:**

1. Say your reading of "operator partnerships" in one sentence: partnerships *with* the operators themselves, or partnerships *around* them, meaning technology and channel partners who serve operators. The phrase can be read either way, and saying your reading up front stops the panel scoring you against the other one.
2. Name one point from the report you agree with. It proves you're grounded, and Deepa and Ross already know the report, so one point is enough.
3. Then signal the divergence: "Here's where I'd push further than the report does."

**Thesis options.** Pick two. Each one carries a concession you say out loud. All three are `[generic]` patterns. Make them specific with the report's own facts and vocabulary.

| # | Thesis | The concession you volunteer | What it means for operators (the close) |
|---|---|---|---|
| T1 | **Partnerships as integration.** Pick a small set of technology partners whose systems operators already run next to scheduling, and make the joins work, so the product is easier to adopt and harder to rip out | Integration partnerships are slow to show revenue and they cost engineering time. In 18 months you'd show a few working integrations, not an ecosystem | Fewer one-off integration projects for the operator to run, and fewer hand-offs between systems for their planning team to manage |
| T2 | **A few operators as design partners.** Invite two or three operators into a structured feedback and early-access arrangement, so the roadmap is shaped with operators and not just sold to them | The risk is building one operator's custom roadmap. Procurement and contract rules may also limit how close the arrangement can get, so check what the report says about how operators buy | Operators get a say in what ships and see it earlier. The product they buy fits how their planners actually work |
| T3 | **Fewer, deeper partners, measured on operator outcomes rather than partner count.** Tier the existing partners, invest in the few that move operator results, and let the rest be self-serve | Pruning gives up some revenue and some relationships. Your own headline is a count, 6 to 40, so Ross may say so; get there first. Answer slot: if your ISV years showed you a limit of measuring by count, say what, in your own words. If they didn't, present T3 as a choice for this market rather than a lesson | Each operator deals with partners who actually serve them well, instead of a long list of logos |

**Differentiation strategy.** The report is the consensus answer: the panel has it, and any prepared candidate who was sent it has too. Reciting it scores as homework. Departing from it with reasons scores as judgement. Your structure is one agreement, then one divergence with its reason, then **one anti-pick**: a thing you would *not* do in the first 18 months, and why. A broad, open partner programme or marketplace is a natural anti-pick for T1 and T3, but choose the one the report makes most tempting. A Partnerships VP hiring someone senior wants to hear them say no.

**Commercial frame (2 minutes, said before Ross asks):**

- For each thesis, say how it makes money. Options to choose from: partner-sourced pipeline, influenced pipeline, retention and expansion of operators who use the integrations, and partner fees or margin, if the report shows Kelverton runs any. These are `[generic]` options; pick the ones the report supports.
- Say which number you'd sign up to own. Ross is likely to ask whether that number is sourced or influenced, and C1 rehearses that exchange. Getting ahead of it here makes it your framing rather than his challenge.
- Name one leading indicator for the first six months and one lagging result for month 18.

**Close (about 2 minutes): land on operators.** Take the operator-meaning cells of your two theses and say them in an operator planner's terms, using the report's own description of what operators struggle with. End on one sentence that starts "For an operator, this means…". Then stop and hand over to questions.

**Timing:** opening 1:30, thesis one 4:00, thesis two 4:00, commercial frame 2:00, operator close 2:00. That totals 13:30 and leaves room to breathe.

---

## Reading the interviewer

From the recruiter's email only. There was no public-profile research.

| Panellist | What the recruiter said | Practical implications |
|---|---|---|
| Deepa | "VP Partnerships, your future manager" | She owns the partnerships agenda you're presenting on. Expect her to probe whether the POV is something she'd sign off: the 90-day test (A1) and the partner portfolio (A2). The Skeptic bank's rail gap (D1, D2) is hers to raise |
| Ross | "Commercial Director" who "will push on commercials" | The pressure and prober banks (B, C) are aimed at him. Every figure in Q1 will be tested. Hold-then-concede matters most with him |

There are no mirror opportunities: no profiles are in hand, so no shared career jumps can be established.

---

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Deepa's follow-ups on the POV: 90-day plan, portfolio choices, measures | Highest. A hiring manager's prior is Case + Skeptic, and a declared POV makes case follow-ups certain | Clarify, state the objective, structure out loud, give metrics and risks. Challenge one premise politely |
| Data-Driven Prober (B) | Ross testing the £4M and the 6-to-40 | High. The recruiter said "Ross will push on commercials", and Q1 has two headline numbers | Know what you can and can't say about how each figure was counted. Name your weakest assumption before he does |
| Pressure (C) | Ross challenging influenced versus carried revenue, and the 18-month realism | High. A commercial director's prior is Case + Pressure, and C1 is the obvious pressure line | Pause, restate the question, hold through two follow-ups, then concede only what's real |
| Skeptic (D) | Deepa on the rail gap and your motivation | Medium. It's the other half of the hiring-manager prior, and Q3 hands her the objection | Rehearse the plain acknowledgment until it's boring, then give a concrete ramp plan |
| Conversational (E) | The opening "walk me through your background" | Low to medium. Panels often open warm, but the POV takes the first slot | Have a 90-second arc built only from Q1 and Q2 |
| Peer Evaluator (P) | Channel conflict with sales, and what you need from Ross's team | Low to medium. Ross runs the function you'll sit beside | Frame it as reciprocity: propose principles for the seam |
| Values (V) | One or two behavioural questions | Low. The recruiter's description of the round names no values element, and the company's values weren't found | Use the selection scaffolds below |

The weights rest on the recruiter's description of the round, not on any research into Kelverton's process.

---

## Question banks

### A. Case / Strategist (mostly Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've told us where you'd go. What would you do in your first 90 days to test it?" | CASE | [generic] | Cover four things: what you'd learn first (the current partners, two or three operators' views, pipeline data), which one thesis you'd test first, what result would make you change course, and what you'd bring back to Deepa at day 90. The question needs no claim about your past, so the guidance makes none | It's the natural bridge from POV to plan, and a hiring manager is buying execution. CASE because it's a live plan |
| A2 | "Of the partnerships we already have, how would you decide which to invest in and which to let go?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Give your criteria first: effect on operators, revenue, cost to support, strategic fit. Then the anti-pick. Answer slot: if at the payments company you tiered or dropped partners in that channel, say how, in your own words. If you didn't, say so plainly and stay with the criteria | The brief asks where you'd take the partnerships, which implies choices about the ones they already have. F1 is the nearest evidence, so the slot sits on it |
| A3 | "Pick one operator. What concretely changes for them a year from now?" | CASE | [generic] | Rehearse the required close at ground level: one operator, one team, one before-and-after. Use your theses' operator-meaning cells. Name no operator problem the report doesn't describe | It tests the "land on operators" brief under follow-up, and the brief makes it a likely question |
| A4 | "You've read our market report. Where do you disagree with it?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | One agreement in a sentence, then one divergence with your reason, said as a view and not a correction. The panel may have written or endorsed the report | Your POV's differentiation is built on exactly this, so be ready for it asked directly. CO because it tests altitude on their own material |
| A5 | "How would you know operator partnerships are working, beyond revenue?" | CASE | [generic] | Give one leading and one lagging measure for each thesis. One should be an operator outcome and one a commercial result. Say which you'd report to Deepa monthly | It's a measures question and a natural prompt for the operator close. It also sets up Ross |

### B. Data-Driven Prober (mostly Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Keep "roughly" and "influenced". Answer slots, each in your own words: how it was counted and over what period; what it is sensitive to; the assumption behind it you'd defend least, said before he asks; which part was yours. If you don't know how it was counted, say so plainly. Never give a method you can't back on the second follow-up | F3's headline figure will be tested by the person the recruiter named as the commercial challenger. EXP because it's about attribution |
| B2 | "Of the 40 partners, how many actually produced revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if you know the split, give it in your own words. If you don't, say so plainly and stay with what Q1 states. Don't defend the count as an outcome in itself; T3 already makes that argument for you | This is the denominator behind F6's headline count, and a prober asks it. It's also the bridge to T3 |
| B3 | "If we gave you a number for year one, how would you build it?" | CASE | [generic] | Build it bottom-up and out loud: partners, then deals each, then deal size, then win rate, then timing. Name the assumption you'd defend least. Say whether it's a sourced or influenced number and why. It's a method, so it makes no claim about your past | It's Ross's native question, and it links straight to F4 |
| B4 | "How would you structure the commercials with a partner: referral, resell, co-sell?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Give a trade-off for each model: margin, control, how much of the operator relationship you keep. Choose one per thesis. Answer slot: if you set partner terms in the ISV channel, say which and how, in your own words. If that wasn't yours, say so plainly and give how you'd decide | "Push on commercials" raises partner economics. F3 is adjacent evidence, so the slot sits on it |

### C. Pressure (mostly Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Influenced revenue isn't revenue. Have you ever actually carried a number?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | **The highest-ROI rehearsal in this pack.** Pause. Then the plain answer first: "No. I've never carried a direct quota. My number was influenced revenue, roughly £4M." **Hold**: answer slot. If you can say what "influenced" meant in your channel and how it was counted, say it in your own words. If you can't, say so. **Follow-up 1**, "So who carried it?": answer slot. If you know who closed those deals, say so. If not, say plainly that you don't know. **Follow-up 2**, "Why would I trust you with a number here?": give the plan, said as a plan. Say which number you'd own (B3) and how you'd report it. **Concede** what's real: "It's a fair gap, and I'd rather name it than blur it." Don't fold into apology, and don't upgrade influenced to sourced | F4 is the most predictable objection to you: the recruiter named Ross as the commercial challenger, and Q3 states the gap. Rehearsed calmly, it turns into a credibility point. JD because it tests the stated job's commercial bar |
| C2 | "Sixty seconds: why you over someone who's sold to train operators for ten years?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Concede first: "I haven't sold into rail." Then two facts, each at its own scope: the ISV channel, 6 to 40, and transport consulting in bus and light rail planning, "from the other side". Close on what you'd bring that the POV showed. Stop at 60 seconds | F5 combined with a time box is the classic pressure line. JD because it tests fit against the role |
| C3 | "That 6 to 40: how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | "We" for the team, "I" only for what was yours. Answer slot: say what you personally did to grow the channel, in your own words. If others signed or sourced most partners, say so plainly. Q1 says you ran it, and you can hold that | It's an attribution probe on F6's headline, and the Pressure stem asks it word for word |
| C4 | "Operators buy slowly and procurement rules everything. Isn't 18 months a fantasy?" | CASE | [generic] | Hold, then scope: separate what you'd *show* in 18 months (working integrations or design partners, leading indicators) from what you'd *book*. Concede that timelines depend on how operators buy, using the report's own account of it. Don't claim to know rail procurement | It's devil's advocate on the brief's own time frame. CASE because it's reasoning live, and `[generic]` because the procurement premise is the interviewer's |

### D. Skeptic (mostly Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't sold into rail. What will you get wrong in your first six months?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Agree with the premise in your own words: "I haven't sold into rail." Then name one or two real risks, such as misreading how long operators take to buy, or who inside an operator decides. Give the ramp plan: who you'd learn from, which operators you'd visit, and what you'd have read by week four. Calibrated candour beats bluffing in front of the VP who owns this area | F5 is the gap Deepa owns. A Skeptic stem, sourced on Q3's own negative |
| D2 | "Bus and light rail planning is a long way from a train operator's scheduling team. What actually carries over?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Say it at Q2's scope: consulting, bus and light rail, network planning, "from the other side". Answer slot: if specific work showed you how operators plan or decide, say what, in your own words. If it doesn't carry to train operators, say so plainly. Never claim you worked inside an operator or on heavy rail | F2's bridge is the one most likely to be stretched in the room. Getting the relationship wrong, consultant versus operator, collapses within one sentence |
| D3 | "Why leave payments, and why rail now?" | EXP | [generic] | Your material doesn't give a reason, so give your actual reason in your own words: one sentence on leaving and one on why rail. Keep it consistent with E2 | It's the Skeptic's motivation check. You've given no reason, so the guidance is a slot, not a story |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc in time order: transport consulting in bus and light rail network planning, then the payments ISV channel, 6 to 40 partners and roughly £4M influenced. Answer slot: the two sentences can be read as 4 + 5 = 9 or as separate years. Count your years the way they actually fell, and if the consulting years are part of the nine, don't call all nine "partnerships" | It's a likely warm opener. The arithmetic in F6 is the one place a total could be overstated by accident |
| E2 | "What's drawing you to rail tech?" | EXP | [generic] | Selection scaffold: one real pull, in your own words. If the consulting years are part of it, say so at Q2's scope. If no single reason comes to mind, say what you're curious about in the POV | It's a casual-register motivation question, and still scored |

### P. Peer evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "A partner and our direct sales team both claim the same operator deal. What do you do?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Propose principles for the seam: agreed rules on who registered the deal and when, one owner for the operator, and credit that doesn't punish co-selling. Answer slot: if you handled such conflicts in the ISV channel, say how, in your own words. If not, say so plainly and stay with the principles | Channel conflict sits between Deepa's team and Ross's. It's a seam question, and F1 is the adjacent evidence |
| P2 | "What would you need from the commercial team in your first month?" | CASE | [generic] | Answer with reciprocity: what you'd *give* Ross's team (pipeline visibility, partner intelligence on operators) before what you'd ask for (deal data, a named contact) | Reciprocity framing scores with the function you'll sit beside |

### V. Values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you told leadership a partnership wasn't worth it." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you held your view, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It's an unpopular-truth stem from the Values persona, and it pairs with T3's anti-pick |
| V2 | "When did you put a partner's or a customer's interest ahead of your own number?" | VAL | [generic] | Selection scaffold: a specific decision, what it cost you, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It's a customer-over-metric stem, and it echoes the "operators themselves" close |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: the 18-month POV | POV build, A1, A2, A4 |
| F2: land on operators | POV close, A3, A5, D2 |
| F3: commercials | B1, B3, B4, C1, C4 |
| F4: direct number | C1, B3 |
| F5: rail selling | C2, D1 |
| F6: scaling a partner programme | B2, C3, E1, P1 |

---

## Reverse questions

| # | Ask | To | Why it lands |
|---|---|---|---|
| R1 | "Which part of my POV is furthest from how you're thinking about the next 18 months?" | Deepa | Invites the correction in the room, where you can respond to it, and shows you can hear "no" |
| R2 | "How is partnerships' contribution counted commercially today: sourced, influenced, or something else?" | Ross | It's the measure your number will live under, and it shows you're thinking about C1's distinction |
| R3 | "What would make this hire clearly a success at twelve months, in your view?" | Deepa | Your future manager defines the bar, and her answer tells you what to emphasise in any follow-up |
| R4 | "Where do partnerships and the commercial team tread on each other today?" | Ross | It names the P1 seam before he does, and it's a reciprocity signal |
| R5 | "What did the strategy team's report get right that the business hasn't acted on yet?" | Either | It treats their own document as a working tool rather than homework |
| R6 | "Which operator relationship would you most like to see become a real partnership?" | Deepa | It grounds the conversation in a named operator and shows interest beyond the deck |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried, hit or owned a quota | A negative you stated, F4 | "I've never carried a direct quota. My number was influenced revenue" |
| Generated, closed or sourced £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, not closed or sourced |
| Sold into rail, or has rail sales experience | A negative you stated, F5 | "I haven't sold into rail" |
| Worked with train operating companies, or inside an operator | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, as a consultant, "from the other side" |
| Built the ISV channel from scratch | Inflated form of F1 | Q1's own words: you ran it and took it from 6 partners to 40. The pack's observation: it started at 6, not zero |
| Fourteen years of partnerships, or nine years of partnerships plus five of consulting | Inflated form of F6 (ambiguity resolves downward) | Count your years the way they actually fell. E1's slot covers it |
| £4M a year, or a specific period | Inflated form of F3 | The figure as you stated it, "roughly £4M", with its period given only if you know it (B1's slot) |

---

## Sources

**Provided inputs:**

- The recruiter's email, as you quoted it in your message
- The background you gave in your message

**Not used:** the internal market report. You've read it; I haven't, because it wasn't pasted into the conversation.

**Searches attempted:**

1. `Kelverton Rail values`: refused
2. `Kelverton Rail scheduling software train operating companies news`: refused
3. `Senior Partnerships Manager rail software job description UK`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have supplied value names to theme the V bank. No values-style round is detected, so the values cheat sheet would not have been included either way |
| 2. `Kelverton Rail interview process` partnerships | skipped | The recruiter's email already fixes this session: one 60-minute panel, a 15-minute POV, then Q&A |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused. It would have grounded the POV theses, A4 and C4 in Kelverton's current moves. The market report you've read is the substitute, and its contents aren't in hand |
| 4. `Deepa Kelverton Rail`, `Ross Kelverton Rail` | unavailable | Not sent, because search on this host was refused. It would have supplied each panellist's career pattern, persona weights read from their profiles, and a reverse question tied to their path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The search was refused. It would have turned F4, F5 and F6 from `[generic]` into `[inferred]` rows quoting a real posting |

---

## Upgrade menu

- **The market report's key points, pasted or summarised:** the POV theses become `[grounded]` in Kelverton's own framing. I can then pick your agreement, divergence and anti-pick with you, and make A4 and C4 specific.
- **The job description text:** F4, F5 and F6 become `[grounded]` rows, and any requirement the pack has missed gets a question.
- **Permission to search:** official values, recent news, and Deepa's and Ross's public profiles. That unlocks a panellist read, profile-based persona weights, and a reverse question tied to each of their paths.
- **A deeper research pass, at most 6 further searches and 2 further fetches, several more minutes:** a strategy brief on Kelverton and the operator market, to make the differentiator and commercial questions specific.
- **Your answers to the slots in B1, B2, C1 and C3:** how the £4M was counted, how many of the 40 produced revenue, and what was yours. Said to me outside a drill, they move B1, B2, C1, C3 and F3 from slots to story-mapped guidance.
- **A `tuesday-dossier.md`:** it would carry verified evidence and a checked prohibited-claims list into this pack, replacing the locally built one.
- **One email to the recruiter, asking whether "operator partnerships" means partnerships with operators or partners serving operators:** it settles the POV's opening framing before Tuesday.
