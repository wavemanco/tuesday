# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager (your words). Interviewer not named.
**Built from:** your `tuesday-dossier.md` (v1.1, 2026-08-14), with no web research: all three searches were refused by this session's permissions (see Sources).

---

## How to use this pack

Two axes. **Personas** describe *how* a question will be asked (who's asking, in what style). **Types** describe *what* is being scored:

- **JD**: can you do the job as listed, gaps included
- **EXP**: does your stated experience hold up under scrutiny, and what was actually you
- **CASE**: structure and reasoning on a live problem from the role
- **CO**: knowledge of the company and its strategy
- **VAL**: whether your past behaviour shows the values they publish

Provenance labels: `[grounded]` traces to your dossier, `[inferred]` is this pack's own derivation (named), and `[generic]` is a role-family pattern with no claim about you or Quartzline.

Treat the guidance as scaffolding, not a script. Say it in your own words, and say only what you actually did.

**The one rule your dossier sets for this interview:** present your integration work as *adjacent* to product management and never as PM experience. Section 13 lists the lines this pack won't coach.

---

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [grounded] | transferability | Bridge, with the limit your dossier set: adjacent, never PM experience. Concede first. Your dossier's prohibited_claims item "Having held a product manager title or role" sources the words "I haven't held a product manager title." Then the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Say the limit yourself: integration work, not the PM job. Answer slot: the JD's 3+ years line makes a probe on tenure likely. Give your actual years doing this work, in your own words. Your dossier's verified entries don't state a figure, so this pack gives none |
| F2 | Owning a roadmap and prioritization authority (dossier, R1 sub-claim) | none given | none | [grounded] | capability | Acknowledge, never bridge. Your dossier records this as acknowledge_gap, and its prohibited_claims items "Having owned a product roadmap" and "Having set prioritization for an engineering squad" source the words "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as something you've done. No answer slot, and nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | medium | [grounded] | transferability | Your material shows integrations taken to go-live, not an API product shipped, and the words stay there. Answer slot: this requirement makes a probe on the API itself likely. If any of those integrations led to a change in the API that you specified, say which and how, in your own words. If none did, or the spec wasn't yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1, and "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | medium | [inferred] | discovery | The quotes touch REST APIs but don't say whether you worked from or wrote API docs or schemas. Answer slot: if you did, in those integrations or the playbook, say which and how, in your own words. If not, say so plainly and stay with the integrations |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important): the customer and product side | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1, and "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | none | Clients and product are both in your own quotes, so lead with them in those terms. Your dossier marks the sessions as confirmed with limited inspectable proof, so expect a probe on them. Volunteer that limit before it's pulled out of you: you ran the sessions and they fed product, and the decisions after that were product's |
| F6 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important): the engineering and sales side | none given | none | [grounded] | discovery | Your material doesn't show engineering or sales stakeholders by name. Answer slot: if you managed engineering or sales stakeholders in those integrations, say who and how, in your own words. If not, say so plainly and return to the clients and product side in F5 |
| F7 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Clarify, as your dossier allows. Answer slot: "agile delivery" is the interviewer's likely probe. If you worked that way, say how, in your own words. If you never did, say so plainly and add: "Here's what I'd want to confirm about how you define it on these squads" |
| F8 | "Define and track adoption metrics" (dossier role_profile responsibility) | none given | none | [grounded] | discovery | Your material doesn't show adoption metrics. Answer slot: if you tracked any adoption or usage measure for those integrations, say what was counted and how. If none was, say so plainly and say what you would measure first (B1) |

---

## 8. Persona table

Your own words set the loop: one 45-minute conversation with the hiring manager. So these weights start from the hiring-manager prior (Case/Strategist plus Skeptic) and not from a guessed company pattern. The dossier's named objection pushes the Skeptic to the top.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title gap and "why now" | Highest. A hiring manager is de-risking a hire, and your dossier names the objection outright (A1) | Rehearse A1 until it's boring. Concede first, bridge only from quoted evidence with its limit, then give a ramp plan |
| B. Case / Strategist | Live problems from the real job: adoption, partner requests, the first 90 days | High. The hiring-manager prior, and the JD's responsibilities are all live-problem material | Clarify, then objective, approach, metrics and risks. Think aloud, and challenge one premise per case |
| C. Data-Driven Prober | Pulls on "30+", the playbook and the sessions | Medium. Your strongest evidence is countable and inspectable, which draws exactly this | Know what you can and can't say about how each figure was counted, and say plainly when you don't know |
| D. Conversational | "Walk me through the journey" openers | Medium. Most 45-minute hiring-manager conversations open warm, and that part is still scored | A 90-second arc built only from your quoted lines |
| E. Pressure | Time-boxed or "how much was you" jabs | Low. Nothing points to a stress format, but a hiring manager may test composure on the title gap | Pause, restate, anchor in what you stated, then hold through two follow-ups |
| F. Values / Behavioral | "Tell me about a time…" | Low. No values round is indicated, and Quartzline's values couldn't be researched | Selection scaffolds with honest branches |
| G. Peer Evaluator | Seams with the squad leads and partner team | Low. Not a peer round, but the squad-authority question is live (R1 in the reverse questions) | Propose principles for the seam instead of pretending to know it |

---

## 9. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | **This is the highest-ROI prep in the pack, and your dossier named it.** Three moves. (1) Concede first, in words your dossier's prohibited_claims items "Having held a product manager title or role" and "Having owned a product roadmap" source: "That's right. I haven't held a product manager title, and I haven't owned a product roadmap." (2) The adjacent case, then its limit, both said by you: "What I have done is this: I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Then name the limit before they do: that's integration work, not the PM job. Don't call it PM experience. Let them draw the inference. (3) A ramp plan, said as a plan: how you'd learn which roadmap calls are yours and which are the squad leads', and how you'd get in front of partners early. Then hand the floor back with reverse question R1. On follow-up 1 ("integrations aren't product"), agree and return to what the integrations were, adding nothing. On follow-up 2 ("a PM with three years would ramp faster"), concede specifically that on roadmap ownership they'd start ahead of you, and hold on the integration work exactly as stated. Don't use the roadmap-input sessions as your answer to the roadmap half. Used there, they become the bridge your dossier ruled out | Your dossier named this objection, and it lands on F1 and F2 together, the two biggest gaps. JD, because it scores the must-have directly. It's asked as the dossier wrote it because both of its negatives are prohibited_claims items |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Name it before they do. Your dossier's prohibited_claims item "Having set prioritization for an engineering squad" sources the words "I haven't set prioritization for an engineering squad." Then the ramp plan: how you'd learn the squads' current priorities and who sets them, and what you'd do in the first month. Say it as a plan. Don't follow it with a "but I have…" bridge. The underwriter found nothing to bridge, and inventing one live is how candidates get caught | F2 is the capability gap, and naming it yourself scores as calibrated candour. JD because it asks about the listed job |
| A3 | "I don't see shipped API products in your background — how would you handle that part of this role?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Agree with the observation and give the quote at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: if any integration led to an API change you specified, say which and how, in your own words. If none did, or the spec wasn't yours, say so plainly and stay with the integrations. Then say how you'd approach shipping here, as a plan | F3's must-have, and the second-most predictable Skeptic line. JD because it's the requirement's own wording |
| A4 | "Tell me how you've worked in agile delivery." | JD | [grounded] | Clarify strategy (F7). Answer slot: if you worked in agile delivery, say how, in your own words. If you never worked that way, say so plainly, then: "Here's what I'd want to confirm about how you run it with these two squads." Don't describe a ceremony or cadence you didn't take part in | F7 is preferred-tier, but it's the kind of mid-list item that gets asked and goes unrehearsed. JD for R5 |
| A5 | "Why move from integrations into product management now?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reason, in your own words. The pack doesn't supply a motive. If the sessions are part of the reason, keep them at their scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." You fed product, and product decided. Use them for motivation only, never as roadmap experience. If your reason is something else, use that instead. Avoid framing that criticises your current employer | The Skeptic's "why now" probe for a career switch. EXP because it tests whether your story holds together. F5 carries the sessions |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption is one of this role's metrics. How would you define and track it?" | CASE | [generic] | Clarify first: adoption by whom (partners, apps, end users) and towards what goal. Then a short ladder of candidate measures, e.g. partners with credentials issued, partners with a successful production call, time to first successful call, and active partners per month. Then data sources, a baseline, and the one you'd defend least, said aloud. End by asking what's measured today (reverse question R2). This answer needs no claim about your past, so it makes none | The JD names adoption metrics, and your dossier flags that no baseline is stated. CASE because it's a live problem. The examples are generic patterns, not Quartzline facts |
| B2 | "A large partner asks for an endpoint only they would use. How do you decide?" | CASE | [generic] | Structure: what problem they're actually trying to solve, whether other partners share it, cost to build and maintain, the precedent it sets, and the options (generalise it, a workaround, decline with a path). Say who you'd involve: squad leads, and sales if a commitment is in play. State a default you'd lean towards and what would change it | Partner-facing roadmap trade-offs are the core of the job. A pure decision question with no claim about your past |
| B3 | "Sketch your first 90 days on this roadmap — what do you need to know first?" | CASE | [generic] | Lead with what you need to know: decision rights against the two squad leads, current adoption baseline, top partner pain points, and what's already committed. Then 30/60/90 in brief: listen and map, a first prioritised view validated with the squads, then the first spec you'd drive. Keep it as a plan. This is also where the F2 ramp plan lives, so rehearse them together | It tests the ramp plan F2 demands, delivered as structure. The JD's "drive delivery with two engineering squads" makes it likely |
| B4 | "Adoption of a new API version stalls at 20% a quarter in — diagnose it." | CASE | [generic] | Clarify the denominator (which partners, eligible to migrate how?), then segment by partner size, integration age and the friction point (docs, breaking changes, auth, incentives). Form a hypothesis, name the data that would test it, and only then propose fixes. Name one premise to challenge (is 20% actually low for this timeline?) | A classic stem fitted to adoption metrics. It scores whether you clarify before you structure |
| B5 | "How would you run discovery with integration partners?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Mostly a plan: who you'd talk to, how often, what you'd ask, and how findings reach the squads. The one past line you can use is the quote at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Say its limit yourself: your dossier marks it as confirmed with limited inspectable proof, and the sessions fed product rather than deciding anything. Don't relabel the sessions as discovery you ran. That's the JD's word, not yours. Answer slot: if any session's findings changed what product did, say what, in your own words. If you don't know, or none did, say so | JD responsibility "Run discovery with integration partners", where F5's medium-confidence line is closest. JD content with CASE delivery |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30-plus integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words. How you counted it: what made something one integration. What it's sensitive to. The assumption behind it you'd defend least, said before they ask. Which part was yours: what "led" meant across them. If you don't know exactly how it was counted, say that plainly. The pack supplies no method or breakdown | Every headline figure gets a defend-the-number question, and "30+" is F1's and F3's anchor. EXP |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Two beats the quote states: you wrote it, and your team uses it ("I wrote the internal integration playbook my team uses"). What's in it is yours to describe in your own words, because the pack doesn't know its contents. Your dossier says it was provided as an inspectable artifact. If you can show an excerpt without breaching confidentiality, offer to | The strongest inspectable item you have. Leading with it gives a skeptical listener something concrete. EXP, drawing on F4 |
| C3 | "Those quarterly roadmap-input sessions — what changed on the roadmap because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Volunteer the limit first: confirmed, but there's little you can show. Then the quote's beats: you ran them, quarterly, and they fed client evidence to product. Answer slot: if you know of a roadmap change that came from them, say what it was and what part was yours. If you don't know, or none did, say so plainly. Either way, the roadmap decision was product's. Don't let the follow-up turn "fed" into "decided" | F5's medium-confidence seam, the one your dossier says to expect a probe on. EXP |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", "Wrote the internal integration playbook her team uses", "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc using the three quoted lines in your own words: the integrations, the playbook, and the sessions feeding product. Close on why this role. Answer slot: give your actual years and employers in your own words. The pack holds no dates. Don't use "product" for anything except the sessions feeding it | Nearly every hiring-manager conversation opens this way, and it frames everything after it. EXP draws on F1 and F5 |
| D2 | "What drew you to Quartzline's API platform specifically?" | CO | [generic] | Your genuine reason. Research couldn't run, so this pack has no Quartzline facts to give you. Say only what you've read or heard yourself, and name where. If you can't speak to specifics, ask about the partner base instead of guessing | A CO question will come in some form. It's generic here because all three searches were refused |
| D3 | "What are you working with on the API tooling side these days?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt for R3. Pick what you actually use with API docs or schemas. If nothing comes to mind, say so plainly, give the nearest thing your material carries (the REST API integrations, in the quote's words), and say what you'd learn first | F4's discovery gap, asked casually, which is still scored. JD for R3 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with the title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", "Wrote the internal integration playbook her team uses" | Pause, then A1 compressed: one sentence of concession ("I haven't held the title", sourced by prohibited_claims "Having held a product manager title or role"), then the two quotes in your own words, then one line of ramp plan. Don't argue that the title doesn't matter | A1 under a time box. JD |
| E2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on "led", the quote's own verb. Answer slot: say which parts you did hands-on and which you led others through, in your own words. If others owned some stages (architecture, say), say so plainly. Concede specifics, not the core claim | The attribution probe on F1's evidence. EXP |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you didn't fold, and a relationship still intact at the end. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem. Generic because no Quartzline values could be fetched |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real case with a customer, a metric you knowingly set aside, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Partner-facing roles invite this. Generic |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd sit between two squad leads, sales and partners. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose principles instead of claiming to know the seam: written decision rights, disagreements raised early with the evidence, and partner commitments routed through the roadmap rather than around it. Then ask how it works today (reverse question R1). No claim about your past | R4's engineering and sales side (F6) plus the squad-authority unknown. JD content, CASE delivery |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: name who else worked on those integrations and what was theirs, in your own words. If you can't, say how you'd credit it in principle | A collegial attribution probe, a softer cousin of E2. EXP |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management experience | A1, E1, D1 |
| R1 sub-claim: roadmap ownership and prioritization authority | A1, A2, B3 |
| R2 Shipped API or platform products | A3 |
| R3 Technical fluency: API docs, schemas | D3 |
| R4 Stakeholder management across engineering, sales, customers | G1, B5, C3 |
| R5 Agile delivery experience | A4 |
| Responsibility: own the roadmap | A1, A2, B3 |
| Responsibility: run discovery with integration partners | B5 |
| Responsibility: write specs and drive delivery with two squads | B3, G1 |
| Responsibility: define and track adoption metrics | B1, B4 |

---

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. The JD asserts authority it doesn't evidence. This reads as diligence, and the answer tells you whether the role is the one advertised |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. Adoption is a stated responsibility with no stated baseline, so this tells you whether you'd inherit a metric or build one |
| R3 | "What would make you say, six months in, that this hire was the right call?" | It gets the real success criteria out, and lets you tune your answers in the remaining minutes |
| R4 | "Which partners shape the roadmap most today, and how does their input reach the squads?" | It shows you're thinking about discovery the way the role needs, and tells you where the pressure on the roadmap comes from |
| R5 | "How do commitments sales makes to partners get onto the roadmap?" | It tests the engineering and sales seam (F6) and surfaces whether roadmap promises are made around the PM |
| R6 | "What's the biggest thing the squads need from a PM that they aren't getting now?" | It frames you as reducing their load, and gives you a concrete first-90-days target |

---

## 13. Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims item | The plain acknowledgment it sources: "I haven't held a product manager title." Then F1's quote at its own scope, adjacent and never PM experience |
| Having owned a product roadmap | Dossier prohibited_claims item, and an acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan as a plan. No bridge and no slot. The roadmap-input sessions are not offered against this |
| Having set prioritization for an engineering squad | Dossier prohibited_claims item | "I haven't set prioritization for an engineering squad." Then a ramp plan. No slot |
| Shipped an API product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's own observation: your material says integrations taken to go-live, not an API product shipped. A3's slot stays inside the integrations |
| Ran partner discovery | Inflated form of F5 | F5's quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the material says input sessions feeding product, not a discovery programme |
| Integration leadership "is" product experience | Inflated form of F1 | F1's quote, with the limit you say yourself. Let the interviewer draw the inference |

---

## 14. Sources

**Provided documents:** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14. Sections consumed:
- `role_profile`: requirements R1 to R5, responsibilities and unknowns, standing in for the JD.
- `handoff_to_mock_interview`: verified evidence (the fit snapshot's quotes), weak areas with their allowed strategies, the A1 objection, reverse questions R1 and R2, and the prohibited claims.
- `decision`: context only.

The dossier carried no `evidence_map`, `risk_register` or `evidence_state`, so the grading for F3 to F8 is this pack's own, from the verified entries.

**Searches sent:**
- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline API platform news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Refused. It would have supplied value names to theme the VAL questions (F1, F2 stay generic). No values round is indicated, so there's no cheat sheet either way |
| 2. `Quartzline interview process product manager` | unavailable | Refused. Your own description already sets this session, so it would have added only context on the wider loop |
| 3. `Quartzline strategy` / recent news | unavailable | Refused. It would have grounded D2 and given B-bank cases Quartzline's current priorities. All CO and CASE items are generic as a result |
| 4. `{interviewer name} Quartzline` | n/a | No name given. No interviewer read, and the reverse questions stay role-generic |
| 5. representative `Product Manager, Platform APIs` JD | skipped | Your dossier's role_profile supplies the requirements and responsibilities |

---

## 15. Upgrade menu

- **Allow web search** → Quartzline's published values for F1 and F2, its current strategy for D2 and the B bank, and a CO question grounded in real news (targets 1 to 3)
- **Deeper research pass**, up to 6 more searches and 2 more fetches, several more minutes (needs search allowed) → a strategy brief, competitive framing and recent org context for a differentiator question
- **The hiring manager's name** → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- **The raw CV behind your verified entries** → a quotable tenure line for F1 and D1, and possibly evidence for F6
- **Your answers to the slots in F4, F6, F7 and F8** (API docs and schemas, engineering and sales stakeholders, agile, adoption measures), said as input outside a drill → those rows regrade, and A4, D3, B1 and G1 can be story-mapped
- **Anything inspectable behind the roadmap-input sessions** (an agenda, or a summary sent to product) → F5's medium caveat could lift, which de-risks C3 and B5
- **How much prep time you have before Thursday** → a prioritised prep schedule tied to question IDs
- **Any recruiter note on focus areas or a deliverable** → a build section for anything you're asked to prepare
