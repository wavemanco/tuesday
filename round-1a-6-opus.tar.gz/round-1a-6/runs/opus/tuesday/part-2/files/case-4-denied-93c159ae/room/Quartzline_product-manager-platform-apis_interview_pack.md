# Interview prep pack — Product Manager, Platform APIs, Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday (your words). Interviewer name not given.
**Built from:** your message and `tuesday-dossier.md` (v1.1). Web searches were refused permission this session, so everything company-specific beyond the dossier is labeled `[generic]`. Details are under Sources.

---

## How to use this pack

Two axes. **Personas** describe *how* a question gets asked: the style, the pressure, the register. **Types** describe *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values they care about |
| EXP | Whether your stated experience holds up under scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your dossier or your message. `[inferred]` is a derivation the pack names. `[generic]` is a role-family pattern that makes no claim about Quartzline or about you.

The guidance is scaffolding, not a script. Where a cell says **answer slot**, the pack does not know the answer. Give the true one in your own words, including "that wasn't how it worked" when that is the truth.

---

## Fit snapshot

Requirements come from the dossier's `role_profile` (the JD's lines). Evidence quotes come only from the dossier's `verified_candidate_evidence`, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's condition: position this as adjacent, never as PM experience. Start with the plain acknowledgment its prohibited_claims item "Having held a product manager title or role" supports: "I haven't held a product manager title." Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." The pack's observation on the limit: feeding evidence to product is input to a roadmap, not ownership of one. The sessions are graded as confirmed with limited inspectable proof, so expect a probe and describe them plainly rather than reaching for outcomes |
| F2 | "Own the roadmap for the partner-facing API platform" — JD responsibility (dossier weak area: roadmap ownership and prioritization authority) | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, so there is no bridge here, and none should be built live. Words sourced from prohibited_claims "Having owned a product roadmap" and prohibited_claims "Having set prioritization for an engineering squad": "I haven't owned a product roadmap or set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past: what you would learn first about how roadmap calls get made here, who decides what, and how partner needs reach the roadmap |
| F3 | "Shipped API or platform products" — JD (R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The material shows integrations of the vendor's APIs taken to go-live. It does not show shipping the API product itself, and the words stay inside the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Answer slot: the JD's "shipped API or platform products" line makes a probe on the API side likely. If any change to the API itself came out of an integration you led and you had a part in it, say what it was and what your part was, in your own words. If none did, or it wasn't yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — JD (R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | Leading REST API integrations through architecture touches this requirement but does not show work with docs or schemas. That is the pack's derivation, not something you said. Answer slot: if you worked from or wrote API documentation or schemas during those integrations, say which and how you used them. If you didn't, say so plainly and describe the architecture and requirements work you did |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes show clients and product. They don't show engineering or sales. Answer slot: the JD names engineering and sales. If you worked with either during integrations or the input sessions, say who and what the working relationship was, in your own words. If not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD (R5, preferred) | none given | low | [grounded] | discovery | The dossier's strategy for this row is clarify. Answer slot: the interviewer may ask about "agile delivery". If your integration work ran in sprints or another agile cadence, say how it worked and what your part was. If it never ran that way, say so plainly. Either way, add: "I'd want to understand how your squads define it: cadence, ceremonies, and where the PM sits in them" |
| F7 | "Run discovery with integration partners" — JD responsibility | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | This is the closest adjacent work, at its own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Keep your word, "client", rather than the JD's "partner" when talking about your past. Limit: running input sessions for product is not running discovery as the product owner. Expect a probe, since the sessions have limited inspectable proof |
| F8 | "Write specs and drive delivery with two engineering squads" — JD responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes show requirements work and a written playbook, not product specs or delivery with engineering squads. Answer slot: if your integration requirements went to engineers as written specs, say what they covered and who built from them. If not, say so plainly and describe the requirements work as it was. Never coach squad prioritization; it is on the prohibited list |
| F9 | "Define and track adoption metrics" — JD responsibility | none given | none | [grounded] | discovery | Your material says nothing about metrics. Answer slot: if you tracked any measure for your integrations, such as go-lives or usage after go-live, say what it was and how you tracked it. If you didn't, say so plainly and say what you would measure first in this role |

---

## Persona table

The loop for this session comes from your own words: one 45-minute conversation with the hiring manager. No research established the rest of Quartzline's process.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the no-PM-title gap | **High (5 questions).** Hiring-manager prior. The dossier names a gap objection, and F1 and F2 are must-have and core rows | Rehearse A1 until it's boring. Concede the title fast, hold on the adjacent work, and give a ramp plan. Never bluff ownership |
| Case / Strategist | "Sketch the plan", "diagnose this" on the roadmap, adoption and partner work | **High (5).** A hiring-manager prior: they are buying capability, and the role's responsibilities are live-problem shaped | Clarify, then objective, segments, approach, metrics, risks. Think aloud and challenge one premise per case |
| Data-Driven Prober | "How are you counting 30+?", "which decisions were yours?" | **Mid (3).** "30+" is a headline figure in your evidence, and figures attract probes | Know what you can and can't say about the count. Say plainly what was yours |
| Conversational | Friendly opener ("walk me through the journey"), casual technical asides | **Mid (3).** A 45-minute conversation usually opens in this register, and it is still scored | A rehearsed 90-second arc built only from your quotes |
| Pressure | Time-boxed or "how much was actually you" | **Low (2).** No signal for it, but the persona should not be met for the first time live | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Values / Behavioral | "Tell me about a time…" stakeholder stories | **Low (2).** No values round detected and no published values in hand | Use a story your quotes carry, or say plainly that none comes to mind |
| Peer Evaluator | Seam with the two squad leads, credit-sharing | **Low (2).** A hiring manager may raise it on the squads' behalf | Propose seam principles. Don't pretend to know the seam |

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | **The highest-ROI rehearsal in this pack. The underwriter named this objection in the dossier.** (1) Concede first, cleanly. These words are sourced from prohibited_claims "Having held a product manager title or role" and prohibited_claims "Having owned a product roadmap": "That's fair — I haven't held a product manager title, and I haven't owned a product roadmap." (2) The adjacent work, in the quotes' terms and no wider: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live, and run quarterly roadmap-input sessions feeding client evidence to product." (3) Name the limit before they do: that is input to a roadmap, not ownership of one. (4) Answer slot: give your own reason for wanting to move into product management now, in your own words. (5) The ramp, as a plan: what you would learn first about how roadmap decisions get made here. **Follow-up 1:** "So you've basically been doing PM?" Hold the line: no, it's adjacent, and repeat the limit. **Follow-up 2:** "Then why not the three-year PM?" Don't compare yourself to them or say what PMs lack. Return to the two quotes and the plan, and concede that owning the roadmap would be new to you. **Follow-up 3:** "What happens when you get a priority call wrong in month one?" Answer as a plan for how you'd find out and correct course, with no claim to past prioritization | F1 and F2 are the must-have gaps, and the dossier derived this objection from evidence you confirmed. It will come up in some form. JD because it scores R1 directly |
| A2 | "The role asks for shipped API or platform products. Where does your background reach that, and where does it stop?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say where it reaches, in the quote's terms: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Where it stops is the honest half. Answer slot: if any change to the API itself came out of an integration you led and you had a part in it, say what and what your part was. If none did, or it wasn't yours, say so plainly: you took integrations live, and the API product was the vendor's. Let the interviewer draw the inference about transfer; don't assert it | F3 is the second must-have, and its limit is easy to blur under pressure. JD because it scores R2 |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Choose roadmap ownership. Don't choose something safe, because a dodge here costs more than the gap. Words sourced from prohibited_claims "Having owned a product roadmap" and prohibited_claims "Having set prioritization for an engineering squad": "Owning the roadmap. I haven't owned a product roadmap or set prioritization for an engineering squad." Then the ramp plan for the first 60–90 days, said as a plan: learn the decision rights, learn how partner needs arrive, learn the adoption baseline. No bridge on this one: the dossier found nothing to bridge with | F2 is an acknowledge_gap area, and choosing it yourself shows calibrated candor. JD because it scores the roadmap responsibility |
| A4 | "Those roadmap-input sessions — what actually changed in the product because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Describe the sessions in the quote's terms first: quarterly, feeding client evidence to product. Volunteer the limit early: they're hard to evidence from the outside, so you'll describe them as they ran. Answer slot: if you know of a product change that came from evidence you fed in, say what it was and how you know. If you don't know of one, say so plainly and stay with what the sessions were | F1 and F7 both rest on this medium-confidence entry, and a prober will find the seam. Coaching you to name the limit first turns it into a credibility point. EXP because it tests the claim itself |
| A5 | "Why move from integrations into product management, and why now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: give your actual reason, in your own words. This is the one place the pack cannot help with content. Anchor it in the work at its own scope (the integrations you led), and keep "why Quartzline" to what you know of this role from the JD | A Skeptic's "why leave, why now" probe follows the F1 gap. EXP because it tests whether your story holds together |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch your first 90 days owning the partner API roadmap. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what decisions this PM makes alone versus with the squad leads, what the current roadmap commits to, and how adoption is measured. Then a three-phase plan: listen (partners, squads, sales), baseline (adoption, top partner pain), and first bets (a small, visible improvement plus one roadmap proposal). Say what would change the plan. The question needs no claim about your past, so the guidance makes none | Tests the F2 responsibility as a plan, which is the honest form for an acknowledge_gap area. `[generic]` because no Quartzline strategy was researched |
| B2 | "Partner API adoption has flattened over two quarters. Diagnose it." | CASE | [generic] | Clarify what "adoption" means here (sign-ups, first call, production traffic, retained use), since the JD names adoption metrics without a stated baseline. Segment by partner type and funnel stage. Hypotheses: onboarding friction, docs and schema gaps, missing endpoints, commercial factors. Say what data you'd pull first and the one assumption you'd want checked | The F9 responsibility, asked live. CASE because it scores diagnosis structure |
| B3 | "What adoption metrics would you put on a dashboard for a partner-facing API platform?" | JD | [generic] | A funnel: time to first successful call, partners reaching production, active partners by week, calls per partner, error rate, and support tickets per partner. Add one leading and one lagging measure, and say which you would defend least and why. Close with: "I'd want to know what you measure today before changing anything" | Covers the F9 responsibility directly. JD content with CASE delivery |
| B4 | "A large partner wants a new endpoint this quarter. The squad lead says it's not on the plan. What do you do?" | CASE | [generic] | Clarify: who holds the prioritization call here (the open authority question), what the partner's need actually is, and what the cost and alternatives are. Approach: understand the need behind the ask, size it with the squad lead, look for an interim option, decide or escalate per the decision rights, and close the loop with the partner and sales. No claim about your past | Probes the decision-authority unknown and the F8 responsibility. CASE because there is no right answer, only structure |
| B5 | "How would you run discovery with our integration partners?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: which partners to talk to (by segment, active and churned), the questions (jobs, friction, workarounds), synthesis, and how findings reach the roadmap. If you anchor in your past, use only this, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Then say how running discovery as the owner would differ, as a plan | F7 is the adjacent row here. CASE delivery with a grounded anchor |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ integrations — how are you counting that?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts end-to-end client integrations you led. Keep it attached to "integrations", not clients, partners or APIs. Answer slots, each in your own words: how the 30+ was counted; what would change the count; the assumption behind it you would defend least; and which part of each integration was yours. "I don't know exactly how it was tallied" is an honest branch | The headline figure in your evidence, so expect a defend-the-number probe. EXP because it tests attribution |
| C2 | "Walk me through one integration end to end, scoping to go-live. Which decisions were yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration and walk the five stages the quote names: scoping, requirements, architecture, UAT, go-live. Answer slot: at each stage, if a decision was yours, say what it was and how you made it. If it wasn't yours, or there was no such decision, say so plainly and describe what you did at that stage | F1 and F3 both lean on this quote, so the stage-by-stage attribution needs to be solid. EXP because it tests what was actually you |
| C3 | "Tell me about that integration playbook — what's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | In your words: "I wrote the internal integration playbook my team uses." Answer slot: say what it covers and why you wrote it, in your own words. If asked who else uses it, stay with your team unless you know otherwise. The dossier says it's inspectable, so offer to share a redacted version if that's allowed | The strongest inspectable item in your evidence, so worth showing off precisely. EXP because it tests the claim |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from these three: the integrations you led, the playbook you wrote, and the input sessions with product. Then one sentence on why product management, which is your own reason (A5's slot). Don't add tenure or titles here that aren't in this pack. Land on "which is why this role" | The likely opener. A rehearsed arc stops the biography from sprawling into claims the pack hasn't checked |
| D2 | "How do you get on with API docs and schemas these days?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Treat it as scored. Answer slot: if you read or wrote API docs or schemas in those integrations, say which and how. If not, say so plainly and describe the integration architecture work instead. Never claim a schema or spec format you haven't used | F4 is a discovery row. Asked casually, it is still the R3 check. JD tag |
| D3 | "How did your teams work — agile, sprints, something else?" | JD | [grounded] | Clarify strategy, per the dossier. Answer slot: if your integration work ran in sprints or another agile cadence, say how and what your part was. If it never ran that way, say so plainly. Then: "I'd want to understand how your squads run it and where the PM sits in that." No borrowed agile vocabulary for your own past | F6 is a clarify area. JD because R5 is a stated requirement |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, then hold: "I led them, end to end." Answer slot: say who else was on them and what was theirs, in your own words. Hold through two follow-ups by returning to "led". Concede specifics that weren't yours, and never fold on what you stated | Attribution pressure on the F1 and F3 quote. EXP |
| E2 | "Sixty seconds: one thing you'd cut from a partner API roadmap, and why." | CASE | [generic] | Clarify in one breath ("assuming I don't know your roadmap yet"), then give a principle: cut what has the least partner demand evidence and the highest maintenance cost. Give one example type, such as a bespoke endpoint for a single partner, and say what evidence would reverse the call. Stop at sixty seconds | A time-box tests composure. It needs no claim about your past, which keeps you clear of F2 |

### F — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Tell me about a time a customer, sales and engineering wanted different things. How did you handle it?" | VAL | [generic] | Selection scaffold: pick a time from your integration work with a real conflict among those parties, a named stake, what you did, and how it ended. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (client integrations or the input sessions with product), or how you would handle it | The R4 stakeholder requirement as a behavioural probe. F5 is a discovery row, so this is a scaffold, not a mapped story |
| F-2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, the truth itself, and that it actually landed. If no such time comes to mind, say so plainly and give the nearest thing your material carries, or how you would approach it | A common behavioural stem. With no published values in hand, it stays role-generic |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd work with two squad leads. Where's the seam, and what happens when you disagree?" | CASE | [generic] | Propose principles rather than claiming to know the seam: the PM owns the why and what (problem, partner evidence, success metric), the squad leads own the how and when, disputes go to evidence first and then to an agreed escalation path. Ask how it works today, which is reverse question R1. Don't claim past squad prioritization; it's on the prohibited list | The F8 responsibility, plus the decision-authority unknown. CASE because it is a live working-model question |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: a time on a cross-team integration where you named others' contributions. If none comes to mind, say how you would handle it. Use "we" for the work and "I" for your part | A collaboration probe a hiring manager may run on the squads' behalf |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 — 3+ years product management experience | A1, A3, A5, D1 |
| R2 — Shipped API or platform products | A2, C2, E1 |
| R3 — Technical fluency: API docs, schemas | D2 |
| R4 — Stakeholder management across engineering, sales, customers | F-1, G1, G2 |
| R5 — Agile delivery experience | D3 |
| Own the roadmap | A1, A3, B1, E2 |
| Run discovery with integration partners | B5, A4 |
| Write specs and drive delivery with two squads | B4, G1, C2 |
| Define and track adoption metrics | B2, B3 |
| Company and strategy knowledge (CO) | none: no Quartzline research ran, so a CO question could only be invented. See the upgrade menu |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier: decision authority is asserted in the JD but not evidenced. You need the answer before accepting, and it reads as someone already thinking about how to do the job |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier: adoption is a stated responsibility with no stated baseline. It tells you whether you'd inherit a metric or have to build one |
| R3 | "What would make you nervous about hiring someone into this role from the integration side, and what would put that to rest in the first 90 days?" | Brings the A1 objection into the open on your terms and gets you their real criteria |
| R4 | "How do partner requests reach the roadmap today, and where does that break down?" | Tests the discovery responsibility and shows you've thought about how partner input flows |
| R5 | "What does a great first six months in this role look like to you?" | Gives you their success definition in their own words, which you can play back later in the loop |
| R6 | "How do sales commitments to partners interact with the API roadmap?" | R4 names sales, and this seam is where platform PMs often get squeezed. You learn whether it is managed |

---

## Prohibited claims

What this pack will not coach, and why. The dossier's three items are absolute.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | The plain acknowledgment this item supports: "I haven't held a product manager title." Then F1's quotes at their own scope, positioned as adjacent |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan, said as a plan. No bridge |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." In B4 and G1, answer as principles and plans, never as a past |
| "I've effectively been doing product management without the title" | Inflated form of F1's quotes | F1's quotes at their own scope. The pack's observation: input sessions feed a roadmap and don't own it |
| Shipped an API product | Inflated form of F3 | "I led 30+ end-to-end client integrations of the vendor's REST APIs." The pack's observation: the API was the vendor's. A2's slot stays inside the integrations |
| Decided what product built from the input sessions | Inflated form of the roadmap-input quote (F1 and F7) | "I ran quarterly roadmap-input sessions feeding client evidence to product." A4's slot asks only what you know changed |
| 30+ partners, clients or APIs | Inflated form of F1 and F3: the number counts integrations | "30+ end-to-end client integrations", with the number kept on "integrations" |

---

## Sources

**Provided documents**
- Your message: role, company, round type ("45-minute conversation with the hiring manager"), timing.
- `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14. Sections consumed: `role_profile` (requirements R1–R5, responsibilities and unknowns, used as the JD), `handoff_to_mock_interview` (verified evidence, weak areas and their strategies, the A1 objection, risks and employer questions for R1 and R2, prohibited claims), and `decision` (context only). The dossier carried no `evidence_map`, `evidence_state` or `risk_register`. The fit snapshot's grading comes from the handoff's confidence bands and the pack's own reading.

**Searches sent**
- `Quartzline company values`: refused (search permission not granted)
- `Quartzline interview process product manager`: refused (search permission not granted)
- `Quartzline API platform news 2026`: refused (search permission not granted)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The call was refused. It would have themed the VAL questions on published values, and fed a values cheat sheet if a values round were detected |
| 2. `Quartzline interview process product management` | unavailable | The call was refused. It would have shown the rounds beyond Thursday and whether a values or case round follows. Your own words establish Thursday's session, so this session's persona weights stand |
| 3. `Quartzline strategy` / recent news | unavailable | The call was refused. It would have supported a CO question and grounded B1–B4 in Quartzline's current platform priorities. They stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements and fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Search permission for this session** → targets 1–3 rerun: a CO question on Quartzline's current platform strategy, B1–B4 grounded in their actual priorities, and VAL questions themed on their published values
- **Deep research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission)** → a strategy brief and recent org context for a "why Quartzline, why now" answer and sharper reverse questions
- **The hiring manager's name** → an interviewer read from their public footprint, adjusted persona weights, and a reverse question tied to their own path
- **Any recruiter guidance (focus areas, a case or exercise)** → coverage of what they actually said they'd test, and a build section for any deliverable
- **How much prep time you have before Thursday** → a prioritized prep schedule in place of the full pack
- **Your raw CV** → more of your own sentences to quote, including tenure, which today can't go in any answer because no verified entry states it
- **An artifact from the roadmap-input sessions (a session summary, or a product ticket that cites one)** → that evidence moves from medium toward high, and A4 and F7 get firmer holds
- **Your answers to the slots, told to me outside a drill** → A2, A4, C1, C2, D2, D3 and F4–F9 move from slots to story-mapped guidance
