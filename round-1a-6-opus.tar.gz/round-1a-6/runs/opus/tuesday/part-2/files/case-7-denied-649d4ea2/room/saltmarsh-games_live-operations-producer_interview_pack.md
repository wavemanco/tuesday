# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Format:** one 60-minute interview, Friday
**Built as:** a hiring-manager round. You didn't say whether Tobias would be your manager, but the role sits in his function. If that's wrong, the persona weights below change.

---

## How to use this pack

Two things organize every question here:

- **Personas** describe *how* a question gets asked: who is asking and in what style.
- **Types** describe *what* is being scored.

| Type | What it scores |
|---|---|
| VAL | Behaviour and values: whether your past behaviour shows how you work |
| EXP | Work-experience deep-dive: whether your background holds up when probed, and what was actually yours |
| JD | The listed job: can you do what the posting asks, including where you have gaps |
| CO | Company knowledge: homework on Saltmarsh, its titles and its market |
| CASE | Live problem: structure and reasoning on a problem from the role, worked out loud |

The guidance is scaffolding, not a script. Say it in your own words. Every claim about your past in this pack comes from one of the five sentences you wrote about yourself, quoted exactly. Where the role asks about something those sentences don't cover, the pack gives an **answer slot**. That is an instruction for the interview with two honest branches, and it never invents the answer for you.

Labels: `[grounded]` means it traces to your message or the JD. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a common pattern for this kind of role, with no claim about Saltmarsh or about you. Web research was blocked this session, so everything about Saltmarsh beyond the JD is `[generic]` (see Sources).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material covers one title and weekly content drops. The role covers two titles and live events. Keep your words at their own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" makes a question about juggling more than one product likely. If your calendar ever had to work around another title or a shared team, say how, in your own words. If it didn't, say so plainly and stay with the one calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. This is your strongest match, and your own sentence already uses the JD's terms. It's a line with nothing behind it to inspect, so expect a probe. Lead with it as you wrote it: weekly, main title, two years |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show who you worked with to land each drop. Answer slot: if running the calendar meant lining up work with design, art, engineering or community, say which and how, in your own words. If it didn't, say so plainly, then say how you would run that coordination here, as a plan |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning an event review, but it is not the same thing. Words at their own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you ever reviewed a single drop or event after it ran, say what you looked at and what changed because of it. If you didn't, say so plainly and say what your first post-event review here would contain |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap. Your sentence speaks straight to it, and "still uses" is the part that carries weight. Say it that way: "I wrote the release checklist our QA team still uses." Answer slot: "manage" invites a question about upkeep. If you updated it with QA over time, say how. If not, say so and stay with having written it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Four years clears the number. Your material doesn't say in so many words that the title was run as a live service, and weekly drops is the pack's reason to think it was. Answer slot: if the main title was run as a live-service game, say so in your own words and what that meant day to day. If it wasn't, say so plainly and stay with the weekly drops |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | Your sentence reaches the requirement: you presented retention numbers to the studio head every month. Expect the probe to go one level down, into which metrics were in them, where they came from, and what part was yours. The answer slots for that are in C1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is written work that a team still relies on. Describe it and let the interviewer draw the conclusion: "I wrote the release checklist our QA team still uses." Don't call it proof of anything |

Not in the JD, but stated by you, and likely to come up: "Never led a team, and never worked on a game with in-app purchases" — your message. These two negatives are the source for the plain acknowledgments in A1, A2 and E2.

---

## Persona table

| Persona | How it shows up with Tobias | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probes on the gaps: one title versus two, no team leadership, no in-app purchases | High. The default for a hiring manager is Case plus Skeptic, and your own stated negatives give him obvious places to press | Rehearse A1 until it's boring. Give the plain acknowledgment first, then the calendar you ran, then a plan. Never stretch a bridge |
| Case / Strategist | Live problems: plan a quarter, diagnose a retention drop, handle a slipped feature | High. A Head of Live Operations hiring a producer will want to watch you run his actual problems | Clarify, objective, structure, approach, metrics, risks. Think out loud and challenge one premise politely |
| Data-Driven Prober | Goes one level below "presented the monthly retention numbers" | Medium. The JD names KPIs and retention, and F7 is the obvious place to dig | Know exactly what was in those numbers and what part was yours. Say "I don't know how it was counted" if that's true |
| Conversational | Opens with your story and why you want this role | Medium. Most 60-minute rounds open and close this way, and the register is casual but still scored | Have a 90-second arc built from your four sentences, plus a real reason for wanting the job |
| Pressure | "How much of that was you?" and "Why you over someone with in-app purchase experience?" | Low to medium. Not the default for a hiring manager, but the attribution question is common | Pause, restate, anchor in what you wrote, and hold through two follow-ups before conceding the real gap |
| Values / Behavioral | Story prompts about writing, influencing and hard conversations | Low. No values-style round was established, and research was blocked, so the pack doesn't know Saltmarsh's values | Have two stories selected. Use "we" for context and "I" for your part |
| Peer Evaluator | Seams between live ops and engineering or community | Low. He's not a peer, but live ops sits between teams, so seam questions are natural | Propose principles for the seam rather than pretending to know Saltmarsh's |

Depth follows weight: 5 questions for each high persona, 3 for medium, 2 for low. Banks are lettered A–H. There is no bank F, so question IDs can't be confused with fit rows.

---

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role coordinates design, art, engineering and community on every update, and you haven't led a team. How would you get four disciplines to land an update on the date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | **Highest-ROI prep in this pack.** Start with the plain acknowledgment: "I haven't led a team." Then say the calendar as you wrote it: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if running that calendar meant lining up work with design, art, engineering or community, say which and how, in your own words. If it didn't, say so plainly and stay with the calendar. Then give the plan, said as a plan: one shared calendar for both titles, dependencies and lock dates agreed with each discipline up front, and a standing check-in before each update. Concede that coordinating without line authority is what you'd be proving in this job. Hold through two follow-ups by returning to the calendar, never by adding to it | F3 is the snapshot's thinnest row against the JD's busiest line. Your stated negative gives the interviewer a ready-made way in, so some form of this question is close to certain. JD because it scores the coordination requirement directly |
| A2 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Give a plain, short answer: "No, I haven't worked on a game with in-app purchases." Don't soften it and don't hint at side exposure. Then, as a plan: how offers are planned against events here is the first thing you'd ask about, and you'd learn it from whoever owns them. Stop there. A short honest answer reads better than a long defence | The JD doesn't mention monetisation. Mobile live events often carry in-game offers, but that is a general pattern, not something this posting states. Your stated negative makes this the second most predictable objection. EXP because it's about your background |
| A3 | "You've run your main title's calendar. This is two titles. What breaks first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Keep the scope honest: "I ran the weekly content-drop calendar for our main title." Then reason forward, as expectations rather than past experience: shared art and engineering capacity, events landing on the same weekend, QA windows overlapping, and community messaging for two audiences. Say what you'd set up first, such as one combined view, agreed priority rules, and earlier lock dates | F1 is the transferability row, and this is its natural question. JD content with CASE delivery |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | Name one real gap, not a disguised strength. The ones you stated are no team leadership and no in-app purchases. If you'd rather name the post-event review, your words go no further than "I presented the monthly retention numbers to the studio head." Answer slot: if you've reviewed a single drop after it ran, say so. If not, say so plainly. Then give a concrete ramp: read the last few post-event reviews, and agree the KPI set with Tobias before the first event | A standard Skeptic stem. F4 and your stated negatives are where an honest answer comes from. JD because it scores self-assessment against the listed job |
| A5 | "Is a weekly content drop really live ops, or just a content schedule?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "4 years as an associate producer at a puzzle-game studio" | Don't argue the label. Say what you ran: the weekly content-drop calendar for the main title, for two years. Answer slot (F6): if the title was run as a live-service game, say so in your own words and what that meant day to day. If it wasn't, say so plainly and stay with the weekly cadence. Then name what you'd expect to be new in a live-events calendar, such as time-limited events, rewards, and the review afterwards | F6 is the discovery row behind the "3+ years producing live-service games" requirement. A skeptic tests whether the years count |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan the next quarter's live-events calendar across both titles. What do you need to know first?" | CASE | [generic] | Clarify before planning: what each title's goal is this quarter (retention, re-engagement, a launch), the fixed dates (store features, holidays, updates), team capacity by discipline, and what last quarter's events taught. Then structure: an anchor event per title per month, filler beats between them, no clashes on shared teams, lock dates working backwards, and the review after each one. Close on the metric each event is meant to move | The JD's first line as a live problem. Generic because Saltmarsh's titles and goals weren't researched |
| B2 | "An event's day-7 retention came in well below the last one. Diagnose it." | CASE | [generic] | Structure it before guessing. Is the drop real (same cohort definition, same window, tracking intact)? Who dropped: new or returning players, which platform, which segment? What changed: event design, difficulty, rewards, timing, a bug, a competing release? What was happening outside the game? Then pick the two likeliest causes, say how you'd check each, and say what you'd change in the next event. Name the assumption you're least sure of | Retention plus the KPI line, asked as a problem. The structure carries the score here, not knowing the answer |
| B3 | "Three days before an event goes live, engineering says a feature won't make it. What do you do?" | CASE | [generic] | Get the facts: what exactly won't make it, and is there a smaller version that will? Run through the options: ship without it, swap in fallback content, move the date, or cut the event. Weigh each against player impact, community messaging and the other title's calendar. Decide with the right people quickly, then tell everyone: community, QA, art. Afterwards, add a lock date or checkpoint so it surfaces earlier next time | The coordination line (F3's requirement) under time pressure. It needs no claim about your past, so the guidance makes none |
| B4 | "What goes in a post-event review, and who reads it?" | JD | [generic] | Cover the purpose, then the contents: the goal set before the event, results on the agreed KPIs against that goal and against comparable past events, what players said (via community), what went wrong in production, and two or three decisions for next time. Say who reads it: design, art, engineering, community, and Tobias. Keep it short, written, and on a fixed schedule. This is a design question, so answer it as one. Your own past experience goes in only through F4's answer slot | F4's requirement asked as a deliverable. It also tests the JD's "clear written communication" |
| B5 | "Saturday, mid-event, community flags a bug that's breaking rewards. Walk me through the next two hours." | CASE | [generic] | Confirm and size it: how many players, which title, is it still happening? Get engineering on it and decide whether to pause, hotfix, or let it run and compensate. Give community a holding message quickly and an update when you know more. Log what players lost so compensation is fair. Record it all for the post-event review | Live ops at its most live. It tests coordination and calm. No past claimed |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. What was in them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from your sentence: you presented them, monthly, to the studio head. Answer slots, in your own words: which metrics were in them; where they came from and how they were counted (if you don't know, say "I don't know how it was counted"); what part was yours beyond presenting, if any (if none, say so plainly); and what the studio head did with them. Don't supply a metric name or method you can't stand behind | F7 is the likeliest thing to be probed one level down. EXP because it tests attribution |
| C2 | "How did you know whether a content drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if you measured drops after they shipped, say what you looked at and what it changed. If you didn't, or that sat with someone else, say so plainly, then say what you would measure for an event here and why | This bridges F2 to F4. The JD's "KPIs it reports" makes this probe likely |
| C3 | "After an event, which metric would you look at first, and what could fool you?" | CASE | [generic] | Pick one metric and justify it against the event's goal (for example, return rate in the week after for a re-engagement event). Then name the traps: comparing to the wrong baseline, a seasonal effect, a store feature inflating installs, or a small segment pulling the average. Close with the one assumption you'd check first | Tests comfort with retention metrics as reasoning, which needs no claim about your past |

### D. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only these four sentences, in your own words: four years as an associate producer at a puzzle-game studio; for the last two, you ran the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. End with why live ops is the next step, in your words | Almost certain to open the hour. The arc stays inside what you wrote, so nothing in it needs defending later |
| D2 | "Why this role, and why Saltmarsh?" | CO | [generic] | Selection scaffold: one reason about the work (running an events calendar across two titles), one about Saltmarsh specifically from what you find before Friday (its games, how it talks about itself on its site), and the reason you're moving on, which only you can give. If you're asked why you're leaving, give your actual reason, briefly and without criticising your current studio | A casual-register question that is still scored. Generic because the company research couldn't run |
| D3 | "What mobile games are you playing at the moment?" | CO | [generic] | Name what you're actually playing, and one live event or update in it you noticed and why. Play both Saltmarsh titles before Friday and have one specific observation about an event or update in each. If you haven't played something, don't claim to have | A Head of Live Operations will hear quickly whether you play. A concrete observation beats a list |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Pause, then hold: "I wrote it, and our QA team still uses it." Answer slot: if others contributed items or reviewed it, say so plainly and say what was yours. If it was yours alone, say that once without padding. Hold through two follow-ups. The fact that QA still uses it is the part to come back to | F5 is your strongest artifact, so it's the one an attribution probe goes after |
| E2 | "Sixty seconds: why you over a producer who's already run events with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Concede first and briefly: "I haven't worked on a game with in-app purchases." Then hold on what you did: two years running the weekly content-drop calendar for the main title, and a release checklist QA still uses. Close with how quickly you'd learn the offer side. Don't argue the gap is small | A pressure version of A2. Hold-then-concede: give up the real gap and keep the real strengths |

### G. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time something you wrote changed how a team worked." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F8: you wrote the release checklist, and QA still uses it. Those are the beats your sentence states, so tell them in your own words. Answer slot: the JD's "manage the release checklist with QA" makes a question about upkeep likely. If you kept it current with QA, say how. If not, say so plainly and stay with having written it | Theme comes from the JD's "clear written communication". G1 rehearses F5 and F8 as a story |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a clear stake, the moment you said it, and what happened next. Answer slot: if one of the monthly retention presentations to the studio head carried bad news, that may be your story; if none did, pick another. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. Owning the KPI report (F4) means sometimes reporting a bad event |

### H. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Community wants a fix shipped this week; engineering says next sprint. You're in the middle. What do you do?" | CASE | [generic] | Get both sides' reasons first: player harm and how visible it is, against engineering risk and cost. Look for a middle path, such as a workaround, a communication plan, or a smaller fix. Agree a rule for this kind of trade-off so it isn't renegotiated every time. Escalate only with a clear recommendation | Live ops sits on the seam between teams, and F3's requirement names both of these teams |
| H2 | "What would you need from the other teams in your first month?" | JD | [generic] | Frame it both ways: what you'd bring each team (one calendar they can plan around, earlier warnings, a checklist they can rely on) and what you'd need from them (capacity views, lock-date commitments, and a community read on each event) | Tests whether you reduce other teams' load or add to it |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A3, B1, A5 |
| Coordinate design, art, engineering and community on each update | A1, B3, B5, H1, H2 |
| Own the post-event review and the KPIs it reports | B4, B2, C2, A4 |
| Manage the release checklist with QA | E1, G1 |
| 3+ years producing live-service games or apps | A5, D1 |
| Experience running a content calendar | A3, B1, D1 |
| Comfortable with player-retention metrics | C1, C3, B2 |
| Clear written communication | G1, B4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do the two titles' calendars work today: one shared calendar or two, and where do they collide?" | This tells you what the job actually is, and it shows you've already thought about the two-title part (A3) |
| R2 | "What does a good post-event review look like here: which KPIs, and who acts on it?" | It turns F4's gap into a question about what the role owns, and it tells you what your first review needs to hit |
| R3 | "How are in-game offers planned against events, and does that sit with live ops or another team?" | It addresses the in-app purchase gap head-on, as a learning question, and the answer tells you how much of it you'd own |
| R4 | "What's working and not working in the release checklist with QA today?" | It plays to F5, your strongest match, and shows you'll engage with the process rather than inherit it passively |
| R5 | "For you as Head of Live Operations, what would make this hire a success at the 90-day mark?" | It gets his actual scoring criteria, which you can use in your follow-up note |
| R6 | "What's the most useful thing the team learned from a recent event?" | It invites a real story, and shows you think in terms of review and iteration |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led or managed a team | Negative you stated | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or on monetised events | Negative you stated | "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across multiple titles | Inflated form of F1 | F1's quote at its own scope: the weekly content-drop calendar for the main title, for two years. The limit is the pack's own observation: your material says one title and content drops. A3's slot stays inside that calendar |
| Owned post-event reviews and their KPIs | Inflated form of F4 | F4's quote at its own scope: you presented the monthly retention numbers to the studio head. The limit is the pack's own observation: your material says presenting, not owning a review. A4's and C2's slots ask only whether you reviewed a drop |

---

## Sources

**Provided:** your message, which included the JD text and your background.

**Searches sent (all refused, because web search permission wasn't granted this session):**

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process producer`: refused
- `Saltmarsh Games mobile studio news 2026`: refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused

No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have themed the values questions (G1, G2) with Saltmarsh's own published values |
| 2. `Saltmarsh Games interview process producer` | unavailable | Every call was refused. It would have shown whether this hour is one round of several, and the persona weights would follow the named rounds |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have grounded D2, D3, B1 and the reverse questions in Saltmarsh's titles and recent moves, so those rows are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have added a section reading the interviewer, adjusted the persona weights from his public career, and given one reverse question tied to his path |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** → Saltmarsh's published values, any documented interview process, recent news, and Tobias's public professional footprint. That adds a section reading the interviewer, recalibrates the persona weights, gives a reverse question on his career path, and turns D2, D3 and B1 from `[generic]` into rows grounded in Saltmarsh's actual titles.
- **A deeper research pass** → up to 6 more searches and 2 more fetches, several more minutes: a company strategy brief, Tobias's talks or writing, and loop reports for this role family. It only runs if you say yes, and it needs search allowed.
- **Whether Tobias would be your manager, and whether other rounds follow** → reweights every bank. A peer or panel round brings the Peer and Values banks up.
- **How many hours you have before Friday** → a prioritised prep schedule sized to that time.
- **The names of the two titles** → CO and CASE questions about the real games instead of generic ones.
- **Your answers to the answer slots in A1, A4, C1, C2 and F6** → rows F3, F4, F6 and F7 become story-mapped, with your own words in place of slots.
- **Your CV text** → more of your own sentences to quote, and a likely upgrade to several `medium` rows.
- **Any prep email from the recruiter** → coverage of stated focus areas, and a build section if they've asked for a presentation or take-home.
- **A tuesday-dossier.md** → an objection derived from your confirmed evidence rather than inferred, plus a fixed list of claims to avoid. It's useful, never required.
