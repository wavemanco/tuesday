# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager (your words). Interviewer's name not given.
**Built from:** your `tuesday-dossier.md` (v1.1, generated 2026-08-14). Web research was attempted and refused in this session, so nothing here comes from Quartzline's own pages.

---

## How to use this pack

Two axes. **Personas** describe how a question is asked: who's asking and in what style. **Types** describe what's being scored:

| Tag | Scores |
|---|---|
| **VAL** | Whether past behaviour shows the company's published values |
| **EXP** | Whether your claims hold up under scrutiny, and what was actually yours |
| **JD** | Whether you can do the listed job, gaps included |
| **CO** | Company and strategy homework |
| **CASE** | Structure and reasoning on a live problem from the role |

Every question row has a **Provenance** cell. `[grounded]` means it rests on your dossier's confirmed evidence or the role profile, and the exact sentences it stands on are quoted. `[inferred]` means it's derived, with the derivation named. `[generic]` means it's a role-family pattern with no claim about you or Quartzline.

The guidance is scaffolding, not a script. Where a cell says **answer slot**, the pack doesn't know the answer and won't make one up. Answer it from what you actually did, or say plainly that you didn't do it.

Question IDs go by persona: A to E, then G and H. F is skipped so the questions don't clash with the fit-snapshot rows F1 to F6.

---

## Fit snapshot

V1, V2 and V3 are the three `verified_candidate_evidence` entries in your dossier, in order. Each quote stops where the dossier's confidence note starts.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [inferred] | transferability | This is a bridge. Following the dossier's condition, position it as adjacent work and never as PM experience. Start with the plain acknowledgment, sourced from prohibited_claims "Having held a product manager title or role": "I haven't held the PM title." Then give the adjacent work in its own words: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live. I also ran quarterly roadmap-input sessions feeding client evidence to product." The pack's observation on the limit: your material shows integration-side work on a vendor's APIs and input to product, not product-side decisions. V3 is medium confidence, so be ready to say plainly what you can and can't show from those sessions before you're asked |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile | none given | none | [grounded] | capability | Your dossier marks this acknowledge_gap in uncertain_or_weak_areas, and its prohibited_claims list "Having owned a product roadmap" and "Having set prioritization for an engineering squad". The words to use: "I haven't owned a roadmap, and I haven't set priorities for an engineering squad." Follow with a ramp plan, stated as a plan and never as something you've done. The underwriter looked for a bridge and found none, so this pack doesn't build one |
| F3 | "Shipped API or platform products" — dossier R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Use the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through to go-live." The pack's observation: the material shows client integrations of a vendor's APIs, not shipping the API product. Keep your words on the integration side. An API PM will hear the difference in one sentence. Answer slot: R2's wording makes a probe on what shipped likely. Say what went live and which stages were yours, in your own words. If a stage wasn't yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | Both quotes touch this requirement without showing they meet it. A playbook isn't API documentation, and leading integrations doesn't say what you did with docs or schemas. Answer slot: the JD names API docs and schemas, so expect a probe. If you worked from the vendor's API docs or schemas in those integrations, say how, in your own words. If you didn't, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | discovery | The quotes cover clients and product in their own terms: client integrations through to go-live, and client evidence fed to product. Engineering and sales aren't in the material. Answer slot: R4 names engineering and sales, so expect a probe on each. If you worked with either during those integrations, say who, how and what part was yours. If you didn't, say so plainly and stay with clients and product. V3 is medium confidence, so expect a probe on the sessions |
| F6 | "Agile delivery experience" — dossier R5 | none given | low | [grounded] | discovery | Your dossier's strategy here is clarify, and none of the verified entries speaks to this. Answer slot: "agile delivery experience" is the interviewer's probe. If you've delivered in agile cadences, say how it ran and what your part was, in your own words. If you never worked that way, say so plainly. Then ask the honest question back: "What I'd want to confirm is how you define agile delivery here: the squads' cadence, and where the PM sits in it" |

---

## Persona table

Your own words establish the session: one 45-minute conversation with the hiring manager. So the weights start from the hiring-manager prior, not an assumed loop. No source names a values round, so values questions stay light.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the title gap and the roadmap gap | **High, 5 questions.** The hiring-manager prior puts Skeptic on top, and your dossier names the exact objection, aimed at F1 and F2 | Rehearse A1 until it's boring. Concede first, bridge only from the quotes, name the limit before they do, and finish with a ramp plan |
| Case / Strategist | Live problems from the JD: adoption, discovery, specs, two squads | **High, 5 questions.** The hiring-manager prior. Every responsibility in the role profile can be asked as a live problem | Clarify, set the objective, segment, give the approach, the metrics and the risks, all out loud. Ask who decides before you decide |
| Data-Driven Prober | "How was the 30+ counted?" and requests for detail on the integrations and the playbook | **Mid, 3 questions.** V1's figure is the only number in your evidence, and R3 invites technical follow-ups | Know how the figure was counted, name its weakest assumption yourself, and keep the number attached to its noun |
| Conversational | "Walk me through the journey", "why Quartzline" | **Mid, 3 questions.** A 45-minute conversation will open casually, and casual questions are still scored | A 90-second arc built only from V1 to V3, plus your own reason for moving to product |
| Pressure | "How much was actually you?" and "60 seconds: why you?" | **Low, 2 questions.** Not the hiring-manager norm, but the title gap invites a sharp version of A1 | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Values / Behavioral | A customer story, a hard-truth story | **Low, 2 questions.** No values round detected, and Quartzline's values couldn't be fetched | Selection scaffolds with an honest way out if no story fits |
| Peer Evaluator | The seam with the two squad leads, and credit | **Low, 2 questions.** The hiring manager may ask on the squads' behalf, since the role "drives delivery with two engineering squads" | Propose principles for the seam rather than claiming to know it, and check the decision split (Q1) |

---

## Question banks

### A. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role", "Having owned a product roadmap", "Having set prioritization for an engineering squad" | **This is the highest-ROI rehearsal in the pack. The objection comes from your dossier's likely_interviewer_objections.** Four beats, about 90 seconds. **1. Concede cleanly:** "That's right. I haven't held the PM title, and I haven't owned a roadmap." **2. The adjacent work, in the quotes' words:** "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live. And I ran quarterly roadmap-input sessions feeding client evidence to product." **3. Name the limit before they do:** this is adjacent work, not PM experience, and you won't call it PM experience. Describe it and let them draw the connection. **4. Ramp plan, as a plan:** what you'd learn first, such as how decisions split between this role and the squad leads and how adoption is measured, and how you'd learn it. **Follow-up 1, "How do I know you can prioritize?":** hold the acknowledgment: "I haven't set priorities for an engineering squad." Then explain how you'd approach it here, as a plan. **Follow-up 2, "What did product do with your session input?":** stay with the quote's beats (quarterly, client evidence, to product) and say only what you actually saw happen. Be ready to say plainly what you can and can't show from those sessions. **Follow-up 3, "So it's PM work without the title?":** no. It's adjacent work, and say that. Never blur the acknowledgment into "basically PM work" | F1 and F2 are the role's two must-have pressure points, and the underwriter named this objection from the confirmed evidence. JD because it scores R1 directly |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Pick F2. It's the real gap and the one they've likely already spotted: "Owning the roadmap. I haven't owned one." Then give the ramp plan in two or three concrete steps, as a plan. Don't offer a fake weakness. Don't pick F6 unless your honest answer to its slot is that you haven't worked that way | A standard Skeptic stem. Answering with F2 turns the gap into candour on your own terms. JD because it scores self-assessment against the listed job |
| A3 | "Tell me about your agile delivery experience." | JD | [grounded] | Clarify, following the dossier's strategy for F6. Answer slot: if you've delivered in agile cadences, say how it ran and what your part was, in your own words. If you never worked that way, say so plainly. Either way, close with the question back: "What I'd want to confirm is how you define agile delivery here: the squads' cadence, and where the PM sits in it." Never describe ceremonies you didn't run | R5 is preferred, not required, but a requirement with no rehearsed answer is a free miss. F6 has no quote, so the guidance is all slot |
| A4 | "Shipping API or platform products is a must-have here. What have you shipped?" | JD, EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer in the quote's words: the client integrations you led end to end, through to go-live. Keep the relationship straight, as plainly as the quote does: these were integrations of the vendor's REST APIs, not the API product itself. Answer slot: if one go-live is worth walking through, say what went live and what part was yours, in your own words. If a stage wasn't yours, say so and stay with the integrations you led | R2 is a must-have and F3 is a transferability gap. The likeliest slip is relabelling integrations as a shipped platform. JD content, probed EXP-style |
| A5 | "How have you managed stakeholders across engineering, sales and customers?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Cover clients and product in the quotes' words: client integrations from scoping to go-live, and quarterly sessions feeding client evidence to product. Answer slot: the JD names engineering and sales, so expect a probe on each. If you worked with either during those integrations, say who, how and what your part was. If you didn't, say so plainly and stay with clients and product. The sessions are medium confidence, so be ready to say what you can and can't show | R4 is marked important and F5 only partly covers it. JD because it's the listed requirement asked straight |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of a partner API you own has gone flat for a quarter. Diagnose it." | CASE | [generic] | Think out loud: clarify, objective, segmentation, approach, metrics, risks. Clarify first what counts as adoption (sign-ups, first successful call, active partners, call volume) and against what baseline. Segment partners by new or existing, size and use case, and find the stage where they stall: onboarding, first call, go-live or expansion. Give two or three hypotheses and what you'd check first. Close with one metric you'd add. The question needs no claim about your past | A live problem from the "Define and track adoption metrics" responsibility. [generic] because it's a pattern for the problem, not a fact about Quartzline |
| B2 | "If there were no adoption baseline when you started, what would you measure in your first 60 days?" | CASE, JD | [generic] | Separate leading from lagging indicators. Walk the funnel: time to first successful call, integrations reaching go-live, active partners, onboarding error rates. Get a baseline before setting targets, and agree definitions with the squads and with sales. This sets up reverse question Q2 | Same responsibility, asked as a cold start. JD content, CASE delivery |
| B3 | "An integration partner wants a new endpoint, and one squad lead wants the quarter for reliability work. How do you decide?" | CASE | [generic] | Ask who decides before you decide. That's the open question behind F2, so ask it: "Is this call mine, the squad lead's, or shared?" Then weigh the evidence on each side (partner impact, how many partners want it, reliability risk), lay out options (sequence it, split it, cut scope), explain how you'd bring both sides into the decision, and how you'd tell the partner. Answer it as a plan for this role. The pack's observation: nothing here claims you've set a squad's priorities | The "two engineering squads" line combined with the open question of decision authority makes this the likeliest live case. CASE because it scores structure, not a record |
| B4 | "A partner says they need a bulk export endpoint. How would you run discovery on that?" | CASE, JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure: find the problem behind the request, who else has it, what they do today, what success looks like for them, and what it costs to build and support. If you draw on your own work, use only the quote's words, "scoping, requirements" on client integrations. Don't call that partner discovery. Let the interviewer make the link | A live test of the "Run discovery with integration partners" responsibility. [grounded] only because the guidance lets you cite V1 |
| B5 | "Outline the spec you'd write for that endpoint." | JD, CASE | [generic] | Cover the problem and the partners, scope and non-goals, and the API surface: resource, request and response schema, errors, auth, rate limits, versioning. Then docs and examples, rollout, and how you'd measure adoption. This is R3's live test, so use schema terms only as far as you're actually fluent. Where you're not, say what you'd confirm with the squad | Covers R3 and the "Write specs" responsibility. JD content, CASE delivery |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slots, each in your own words: how the figure was counted (what counted as one integration), what it's sensitive to, the assumption behind it you'd defend least (name it before they ask), and which part was yours. If you don't know exactly how part of it was counted, say so plainly. Keep the number attached to its noun: 30+ client integrations, not 30+ launches or 30+ partners | V1's figure is the only number in your evidence, so it's the one a prober will target. EXP because it tests attribution |
| C2 | "Walk me through one of those integrations end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Use the quote's stages as the beats: scoping, requirements, architecture, UAT, go-live. Tell them for one integration you actually led, in your own words. Answer slot: the JD names API docs and schemas, so expect a probe. If you worked from the vendor's API docs or schemas in that integration, say how. If you didn't, say so plainly and stay with the stages you led. Don't add an incident to make the story land | This is F3's and F4's evidence under a microscope. EXP |
| C3 | "Tell me about the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats from the quote: you wrote it, it's internal, and your team uses it. Describe what's in it in your own words. It's your one inspectable artifact, so if you're allowed to share a redacted page, offer it. Answer slot: if the JD's API docs line draws a probe, say which part of the playbook deals with the APIs, if any. If none does, say so plainly. Don't call the playbook API documentation | V2 is high confidence and inspectable, and it sits next to R3, so it'll be probed for kind. EXP |

### D. Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. Why product, and why now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from the three quotes: the integrations you led, the playbook you wrote, the roadmap-input sessions. Then the turn toward product. Answer slot: give your actual reason for moving to product now, in your own words. The material doesn't carry one, so the pack doesn't supply it. Don't open with the title gap. A1 handles it if they raise it | Almost every hiring-manager conversation opens here, and it's scored even though it feels casual. EXP because the arc is your history |
| D2 | "Why Quartzline?" | CO | [generic] | Research couldn't run, so the pack holds no facts about Quartzline. Structure: one specific thing about its partner API platform that you read on its own site or developer docs, why platform APIs, and one thing you want to learn there. Before the interview, read their developer docs and partner pages yourself. Don't mention anything you haven't read | The only CO question, and it's generic. That's the honest cost of research being unavailable |
| D3 | "What makes a partner API good to integrate with?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Casual register, but still scored. Give a view in a few points: clear docs and examples, predictable errors, a sandbox, versioning, support through go-live. If you draw on your own work, keep to the quote's words. Answer slot: if a specific integration taught you one of these points, name it in your own words. If not, keep it as a view | A casual way into R2 and R3. JD because it tests your view of the product you'd own |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty-plus integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, then restate the question. Hold: "I led them, end to end." That's what the quote says. Then concede specifically, in your own words: who else worked on them and what they did, and whether any in the count weren't yours to lead. Hold through two follow-ups by going back to the quote, never by adding to it | V1 carries the "led" verb, so the attribution probe will land there. EXP |
| E2 | "Sixty seconds: why you over someone who's already been a PM?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role" | A1 compressed. About 10 seconds conceding ("They have the title; I don't"), 30 seconds on the two quotes in their own words, and 20 seconds on what you'd do first, as a plan. Hold the concession, and don't attack the hypothetical PM | The time-boxed version of the A1 objection. JD |

### G. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need cut against an internal target. It needs a named stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A Values stem that fits a partner-facing role. [generic] because Quartzline's values weren't available |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Scaffold: the story needs a named stake, the truth itself, who heard it, and whether it landed. If one of the quarterly sessions is the instance, tell it inside the quote's words (client evidence, to product) and add only what you can stand behind. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it. Don't supply a happy ending if the truth didn't land | V3 is the nearest quote, but it's medium confidence and says nothing about reception, so this stays a scaffold |

### H. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "This role drives delivery with two squad leads. Where's the seam between you, and what happens when you disagree?" | JD, CASE | [generic] | Propose principles for the seam rather than claiming to know it. For example, the PM owns the partner problem and the why, and the squads own the how. Then say you'd confirm that split, because it's the open question behind F2. On disagreement: evidence first, disagree and commit, escalate rarely. The pack's observation: nothing here claims you've set a squad's priorities. Answer slot: if a disagreement with an engineering lead during one of your integrations fits, tell it in your own words. If there wasn't one, say so and stay with the principles | The open question about decision authority is the role's biggest structural risk. JD content, CASE delivery |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of cross-team work where credit mattered. Use "we" for context and "I" for your part. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A Peer stem. The integration work implies other teams, but no quote names them |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, E2, D1 |
| R1 sub-claim: owning the roadmap, prioritization authority | A1, A2, B3, H1 |
| R2: Shipped API or platform products | A4, D3 |
| R3: Technical fluency with API docs and schemas | B5, C2, C3, D3 |
| R4: Stakeholder management across engineering, sales, customers | A5 |
| R5: Agile delivery experience | A3 |
| Responsibility: run discovery with integration partners | B4 |
| Responsibility: write specs and drive delivery with two squads | B5, B3, H1 |
| Responsibility: define and track adoption metrics | B1, B2 |

22 questions in total.

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| Q1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. The JD asserts this authority but nothing shows it. The answer tells you whether the job is the one advertised, and asking it shows you understand how platform PM works |
| Q2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. Adoption is a stated responsibility with no stated baseline. The answer tells you whether you'd inherit a metric or have to build one, and it connects to B2 |
| Q3 | "What would make you hesitate about someone coming from the integration side rather than a PM seat?" | It brings out the A1 objection while you can still answer it. With A1 rehearsed, you get to answer it calmly instead of leaving it unspoken |
| Q4 | "Where do integration partners get stuck most often today?" | Ties to the discovery responsibility, and it tells you the real problem you'd be hired to solve |
| Q5 | "How does partner feedback reach the roadmap today?" | Shows you where work like V3's sits in their process, and whether this role creates that channel or inherits it |
| Q6 | "What would a strong first 90 days look like in this role?" | Lets you check your ramp plan from A1 and A2 against what they actually expect |

---

## Prohibited claims

What this pack won't coach, and why. The first three come from your dossier's `prohibited_claims` and are absolute.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held the PM title." Then F1's quotes at their own scope |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap area (F2) | "I haven't owned a roadmap," plus a ramp plan stated as a plan. No answer slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims (F2) | "I haven't set priorities for an engineering squad." B3 and H1 are answered as plans for this role |
| Shipped an API or platform product | Inflated form of F3 | V1's quote at its own scope. The pack's observation: client integrations of the vendor's APIs, not the API product. A4's slot stays inside the integrations |
| Shaped or decided what product built from the session input | Inflated form of V3 (F1, F5) | V3's quote at its own scope. The material says you fed client evidence to product. What product did with it isn't in the material, and no cell supplies it |
| Ran partner discovery or wrote product specs | Inflated form of V1 (F3) | V1's own words, "scoping, requirements", on client integrations. Use the JD's terms for analysis only, never for your own history |
| Wrote API documentation or schemas | Inflated form of V2 (F4) | V2's quote at its own scope: the internal integration playbook. The slots in C2 and C3 stay inside the integrations and the playbook |

---

## Sources

- **Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14, decision conditional_go. Sections consumed: `role_profile` (in place of the JD), `handoff_to_mock_interview` (the verified evidence V1 to V3, the weak areas and their strategies, the A1 objection, the reverse questions Q1 and Q2, and prohibited claims), and `decision` (context only). The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so the grading in the fit snapshot comes from the handoff's confidence notes and weak-area entries.
- **Searches sent:** `Quartzline company values` was refused. `Quartzline interview process product manager` was refused. `Quartzline partner API platform news 2026` was refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Refused. It would have themed the G questions with Quartzline's own value names and decided whether a values section belongs |
| 2. `Quartzline interview process product manager` | unavailable | Refused. It would have shown whether other rounds follow this one. Your own words already establish this session |
| 3. `Quartzline strategy` / recent news | unavailable | Refused. It would have grounded D2 and given B1 to B5 Quartzline's real API context |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is left out |
| 5. Representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirements and responsibilities |

---

## Upgrade menu

- **Allow web search, or paste Quartzline's careers, values and developer-docs pages** → targets 1 to 3 run. D2 becomes grounded, B1 to B5 get Quartzline's real API context, and G1 and G2 get its value names.
- **Deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, and it needs search allowed** → a strategy brief and recent org context for a company-specific case bank.
- **The hiring manager's name** → a read of their public professional footprint, persona weights tuned to them, and a reverse question tied to their own path.
- **Your own sentence on how long you've done integration work** → F1's bridge can carry a duration. The dossier's summary mentions one, but none of the verified entries states it, so no cell here uses it.
- **Your answers to the slots on agile (F6), API docs and schemas (F4), and engineering and sales stakeholders (F5)** → A3, A5, C2 and B5 become story-mapped instead of slotted.
- **Something you can show from the roadmap-input sessions, such as an agenda or a summary you shared with product, if you're allowed to** → V3 moves from medium towards high, and the caveat in A1, A5 and G2 gets lighter.
- **Your CV** → more quoted sentences, so the scaffolds in G1, G2, H1 and H2 can become mapped stories.
- **Any recruiter note about the format, such as a case or a spec exercise** → a build section for that deliverable.
