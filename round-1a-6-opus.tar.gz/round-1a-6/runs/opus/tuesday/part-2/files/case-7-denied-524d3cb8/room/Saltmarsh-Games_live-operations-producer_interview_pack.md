# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. I've assumed he is the hiring manager. Your note gives his title but doesn't say he's your future manager.
- **Format:** one 60-minute conversation, Friday 27 November 2026
- **Research:** none ran. All four web searches were refused permission, so nothing here about Saltmarsh's values, titles, strategy or Tobias comes from the web. Those rows are labelled `[generic]`.

## How to use this pack

Two axes. **Personas** describe how a question will be asked (who's asking, in what style). **Types** describe what's being scored:

| Tag | What it scores |
|---|---|
| VAL | Behaviour against the company's stated values |
| EXP | Whether your own claims hold up under questioning, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Reasoning on a live problem from the role |

Provenance labels: `[grounded]` means it comes from your own words or the JD. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a role-family pattern with no claim about Saltmarsh. The guidance gives you a structure to work from, not a script. Where it says **answer slot**, you fill that part from your own experience. If there's nothing to fill it with, say so plainly.

Question IDs go by persona: A, B, C, D, E, G, H. There's no F, so a question ID can't be confused with a fit-snapshot row (F1 to F9).

## Prep triage: tonight, before Friday

1. **A2 out loud, three times.** This is the most likely objection (coordinating four teams when you haven't led one), and it's the best use of your prep time. About 20 minutes.
2. **A3.** Practise the in-app-purchase acknowledgment until it sounds calm. Then the plan. About 10 minutes.
3. **B1 and B4.** Practise the case structure for calendar planning and for a post-event review. About 20 minutes.
4. **C2.** Know what you can and can't say about how the retention numbers were counted. About 10 minutes.
5. **Pick three reverse questions.** About 5 minutes.

Everything else is backup.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes the weekly content-drop calendar for your main title. It doesn't describe live events across two titles, so the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you decided what went into each weekly drop, or when, say which decisions were yours and how you made them, in your own words. If they weren't yours, or there was no such step, say so plainly and describe how you ran the calendar. Talk about a second title only as a plan, never as something you've done |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Coordinating isn't the same as leading. Your material says nothing either way about coordination, so keep the negative you stated to its own scope. If you're asked whether you've managed people, use your own words: "I haven't led a team." Answer slot: the JD names four disciplines on every update, so expect a question on how you've worked with them. If design, art, engineering or community fed into your content drops and you kept them on schedule, say which teams and how, in your own words. If someone else did that, or there was no such step, say so plainly and come back to the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting monthly numbers isn't the same as owning a post-event review or its KPIs, and the bridge stays at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared any of those numbers yourself, or looked at how a content drop moved them, say which part and how, in your own words. If the numbers reached you ready-made, or no drop was reviewed that way, say so plainly. Then say what you'd put in a post-event review first, as a plan |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already meets the requirement, in different words. Lead with it as it stands: "I wrote the release checklist our QA team still uses." Nobody has seen the checklist itself, so expect follow-up questions on it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are there. Your material doesn't say whether the puzzle title was run as a live service. Words: "Four years as an associate producer at a puzzle-game studio." Answer slot: if your main title was run as a live service, say so and what that meant day to day, in your own words. If it wasn't, say so plainly and describe the weekly content-drop calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the line as you wrote it. Expect questions on it, since nobody has seen the calendar itself |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting the numbers is relevant, but it doesn't show how well you know the metrics. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you can say which retention measures those numbers covered and what moved them, say so in your own words. If you don't know how they were counted, say that plainly. It's an honest answer |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The checklist is a piece of writing your QA team still uses. Say it in the quote's terms: "I wrote the release checklist our QA team still uses." Let the interviewer draw the conclusion about your writing |
| F9 | Experience with in-app purchases or monetised events. This isn't in the JD; it's a common pattern in mobile live-ops roles, `[generic]` | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | This is a gap that wording can't close, and you've already said so. Words: "I haven't worked on a game with in-app purchases." Then explain how you'd learn it, as a plan and never as something you've done. Don't add anything to make the gap feel smaller |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F1, F2, F5 and F9: one title versus two, coordination without leading, in-app purchases | Highest, 5 questions. `[inferred]` from Tobias's title: the Head of Live Ops hiring for a Live Ops Producer is likely buying capability and checking gaps, and your two stated negatives give him obvious places to look | Rehearse A2 until it bores you. Build bridges only from your own quotes, and say the limit plainly |
| Case / Strategist | Live problems from the JD: plan a calendar, handle a slip, diagnose an event, outline a review | Highest, 5 questions. Hiring-manager prior: he'll want to see how you'd run his calendar | Clarify, then objective, segments, approach, metrics, risks. Think aloud. Challenge one premise per case |
| Data-Driven Prober | Your retention numbers and checklist, followed two levels deeper | Mid, 3 questions. The JD names KPIs and retention metrics, and F3 and F7 are your evidence there | Know what you can and can't say about how each number was counted. If you don't know, say so |
| Conversational | The opener, why live ops, what you play | Mid, 3 questions. A 60-minute single conversation almost always opens this way | A 90-second arc built only from your quotes. Treat casual questions as scored |
| Pressure | Time-boxed "why you" and "how much was you" | Low, 2 questions. No signal that this is a stress interview, but A2's follow-ups can arrive this way | Pause, restate, hold through two follow-ups, then concede exactly |
| Peer Evaluator | Seams between community, engineering and art | Low, 2 questions. Tobias isn't a peer, but the JD's coordination line invites seam questions | Offer working principles for the seams; don't pretend to know them already. Say what you'd give back as well as what you'd need |
| Values / Behavioral | Classic "tell me about a time" prompts | Low, 2 questions. Your note establishes one 60-minute session and names no values round, so no values-style round is detected. Saltmarsh's published values weren't retrieved | STAR shape. "We" for context, "I" for your contribution. Use the honest branch where your material has no story |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You ran the weekly content-drop calendar for your main title. This role runs live events across two titles. What changes for you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with what the quote states: the weekly calendar, your main title, the last two years. Tell it in your own words. Answer slot: if you decided what went into each drop, or when, say which decisions and how you made them. If you didn't, or there was no such step, say so plainly and describe how you ran the calendar. Then talk about the second title as a plan: what you'd want to learn first about each title's rhythm, which teams the two share, and where their dates could collide | F1 is the nearest evidence for the headline requirement, and the jump from one calendar to two titles is the obvious first question. JD because it scores the stated responsibility |
| A2 | "Every update here needs design, art, engineering and community moving together. Your title was associate producer. What tells me you can make that happen?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years."; "4 years as an associate producer at a puzzle-game studio." | **The highest-ROI rehearsal in this pack.** 1) Lead with what the quotes carry: "For the last two years I ran the weekly content-drop calendar for our main title." 2) Answer slot: if any of those four teams fed into the drops and you kept them on schedule, say which teams and how, in your own words. If someone else did that, or there was no such step, say so plainly and stay with the calendar. 3) If he asks whether you've managed people, say it once, without apology: "I haven't led a team." Then go back to step 1. 4) First 30 days, as a plan: meet each discipline lead, learn their lead times, and build those lead times into the calendar. Expected follow-ups: "But who actually got them to hit the date?" Hold by going back to the calendar and to whichever branch of the slot is true. Never add a team you didn't name. "So you've never led anyone?" Concede exactly: "I haven't led a team." Then stop. The limit is stated before he has to pull it out of you | F2 is where the role's core activity meets your stated negative. Some form of this question will come up. JD because it scores the coordination requirement directly |
| A3 | "Have you worked on a game with in-app purchases? How would you get up to speed on the monetised side of events?" | JD | [grounded] "never worked on a game with in-app purchases" | Say it plainly first: "I haven't worked on a game with in-app purchases." Then the plan: ask how events and offers connect on each title, spend time with whoever owns that side, and read past event reviews before you plan the first one. Don't hint at familiarity you don't have, and don't apologise twice | F9. It isn't in the JD, but it's a common mobile live-ops expectation, `[generic]`. JD because it tests the job's likely scope |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" | Choose one gap and own it. In-app purchases is the one you have your own words for: "I haven't worked on a game with in-app purchases." If you'd rather name the post-event review, use F3's answer slot, and its honest branch if that's the true one. Either way, follow with a plan, not a reassurance | A persona-stem question. Answering with a real gap scores as self-awareness, and dodging it scores as a red flag. F9 and F3 |
| A5 | "Was your puzzle game a live-service game?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if the main title was run as a live service, say so and what that meant day to day, in your own words. If it wasn't, say so plainly and describe the weekly content-drop calendar you ran. Don't stretch "weekly content drops" into a live-service claim you can't back | F5. The JD's "3+ years producing live-service games" makes this a likely check. EXP because it tests what your four years actually were |

### B. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan a quarter of live events across two titles that share one art team. What do you need to know first?" | CASE | [generic] | Clarify first: each title's audience and goals, existing fixed dates, art's capacity and lead times. Objective: what the quarter has to achieve. Segment by title. Approach: lay out the fixed dates, stagger the art-heavy events, and build in buffer before each release. Metrics you'd review afterwards. Risks: collisions, slips, team burnout. Think aloud. The question makes no claim about your past, so the guidance doesn't either | The headline JD line, asked as a live problem. `[generic]` because Saltmarsh's titles and cadence weren't researched |
| B2 | "An engineering fix slips a week and now lands on top of an event launch. Walk me through the next 24 hours." | CASE | [generic] | Clarify the impact: which title, and whether the fix is needed for the event or separate from it. Options: move the event, cut scope, or ship the event without the fix. Who you'd tell, in what order: engineering, design, QA, community. What goes in writing, and the decision deadline. Finish with what you'd change in the calendar so it doesn't happen again | Covers coordination and the release checklist through a realistic problem. CASE delivery, JD content |
| B3 | "Event participation on one title fell 20% compared with the last similar event. Diagnose it." | CASE | [generic] | Check the data first: same measurement, same comparison period. Then split it: is it fewer players reaching the event, or fewer joining once they're there? Look at segments: new versus returning players, platform, region. Then the event itself: timing, difficulty, rewards, a competing release, a bug. State a hypothesis early and say what data would confirm it | Retention and KPI comfort (F7's requirement), tested live rather than from your record |
| B4 | "Outline the post-event review you'd send me on Monday." | CASE | [generic] | Short and written: goal of the event, the three or four KPIs against target, what worked, what didn't, one cause for each, and decisions or actions with owners. Mention that you'd keep the format the same every time so events can be compared | Covers "own the post-event review" and "clear written communication" in one question. F3 is thin here, so a strong live structure matters |
| B5 | "Players report a bug in a live event on Saturday night through community channels. What happens?" | CASE | [generic] | Triage: severity, how many players are affected, whether it's exploitable. Who's on call. Community posts an acknowledgment. Decide between hotfix, disabling the event, or compensation, and who decides. Then the check you'd add to the release process so it's caught next time | Tests community, QA and release judgement together under time pressure |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the release checklist you wrote. What's on it, and why?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Start with what the quote states: you wrote it, and QA still uses it. Describe what's on it in your own words. Answer slot: if asked whether it has changed since you wrote it, and who changed it, say what happened. If you don't know, say so plainly | F4 and F8. Your most concrete artifact, so a prober will go straight to it. EXP because it tests what's really behind the line |
| C2 | "Those monthly retention numbers: walk me through how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slots, each in your own words: how the numbers were counted, what they're sensitive to, the assumption behind them you'd defend least (say it before he asks), and which part was yours, whether collecting, preparing, or presenting. "I don't know how they were counted" is an honest answer if it's the true one | F3 and F7. Every numeric claim in an interview gets this question, and retention is named in the JD |
| C3 | "How did you know whether a weekly content drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you looked at results after a drop, say what you looked at and what you did with it, in your own words. If you didn't, or there was no such step, say so plainly. Then say what you'd look at after an event here, as a plan | F3. The JD's post-event review line makes this follow-up likely. Its second branch allows that no such review existed |

### D. Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc using only those four lines, in your own words, in this order: four years as associate producer, the weekly calendar, the checklist, the retention numbers. Answer slot: why this role, and why now. Give your actual reason, in your own words | A 60-minute conversation usually opens here, and the opener is scored too. F5, F6, F4, F7 |
| D2 | "What do you enjoy most about running a content calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say what you actually enjoy about it, in your own words, tied to the calendar you ran. Keep it short and specific | F6. A casual question about the job's core, which is still scored |
| D3 | "What mobile games are you playing, and what do you think of their live events?" | CO | [generic] | Pick one or two you really play and give one specific view on an event's timing, rewards or pacing. If you haven't played both Saltmarsh titles, do that tonight. Don't talk about a game you haven't played | A rapport question that tests whether you play like someone in live ops. CO is thin because no research ran |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops on a monetised game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "never worked on a game with in-app purchases" | Pause. Hold on what the quotes carry: two years running the weekly calendar, and a release checklist your QA team still uses. If pushed twice, concede exactly: "I haven't worked on a game with in-app purchases." Then give your plan from A3. Don't fold on the calendar or the checklist to keep things friendly | F1, F4 and F9 in a time-boxed form. Tests composure more than content |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if others contributed items or reviewed it, say who and what, in your own words. Concede precisely, without shrinking the parts that were yours | F4. The classic attribution question, rehearsed so honesty comes out calm |

### G. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community wants to announce an event date before engineering has committed to it. What do you do?" | CASE | [generic] | A principle first: nothing public until the date has a named owner on each side. Then the practical steps: get engineering's earliest firm date, give community a holding message, set a decision deadline, and write it down. Show you take both sides' pressure seriously | Seam between two of the JD's four teams |
| G2 | "What would you need from the art lead to make a two-title calendar work, and what would you give back?" | CASE | [generic] | What you need: lead times, capacity, and early warning on slips. What you give back: a stable calendar with warning before any change, protected time between events, and clear briefs. That's the reciprocity point | Tests whether you'd make other teams' jobs easier or harder |

### H. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a clear stake, a moment you held your position, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the closest thing your material does carry, or how you'd handle it | A persona-stem question. None of your quotes says a hard message landed, so this is a scaffold, not a story |
| H2 | "Tell me about a time a release didn't go to plan." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: a release that went wrong, what you did, and what changed afterwards. If no such time comes to mind, say so plainly, then give the closest thing your material carries: "I wrote the release checklist our QA team still uses." Don't link the checklist to an incident unless that's how it really happened | Themed by the JD's release-checklist line. A scaffold, because your quotes don't describe a failed release |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1 |
| Coordinate design, art, engineering and community on each update | A2, B2, G1, G2 |
| Own the post-event review and its KPIs | B4, C3, B3 |
| Manage the release checklist with QA | C1, E2, B5, H2 |
| 3+ years producing live-service games or apps | A5, D1 |
| Experience running a content calendar | A1, D2 |
| Comfortable with player-retention metrics | C2, B3 |
| Clear written communication | B4, C1 |
| In-app purchases (not in the JD, `[generic]` role-family) | A3, A4, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do the two titles' calendars interact today: shared teams, shared dates, or fully separate?" | Shows you're already thinking about the two-title load, and tells you what the job really involves |
| R2 | "What does a good post-event review look like here, and who reads it?" | Shows you care about the part of the role you have least evidence for, and tells you the standard you'll be measured against |
| R3 | "Which KPIs does this role report, and which ones is Live Ops judged on?" | A sign you know the difference between metrics you report and metrics you're held to |
| R4 | "How much of the event calendar is tied to in-app purchases or offers, and who owns that side?" | An honest way to raise your F9 gap and find out how big it is in this role |
| R5 | "What would you want this person to have taken off your plate by the end of the first three months?" | Turns the interview toward his priorities, and gives you a 90-day target if you get the job |
| R6 | "Where does the release checklist live today, and how do producers and QA work on it together?" | A natural link to your F4 evidence without repeating it |
| R7 | "What's the hardest coordination moment in a typical update here?" | Brings the real pain point to the surface, and lets you respond with a plan rather than a claim |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated, F2 | "I haven't led a team." No answer slot |
| Worked on in-app purchases, offers or monetised events | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No answer slot |
| Ran a live-events calendar, or a calendar across more than one title | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material describes the weekly content-drop calendar for your main title. A1's slot stays inside that calendar |
| Owned the retention KPIs, or the analysis behind them | Inflated form of F3 and F7 | Their quote at its own scope. C2's slot asks only which part of those numbers was yours |
| Managed QA, or ran the release process | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist. C1 and E2's slots ask only about the checklist |
| A producer title above associate producer | Inflated form of F5 | F5's quote: "4 years as an associate producer at a puzzle-game studio." |

## Sources

- **Your inputs:** the job description and your background, both pasted in your message.
- **Searches sent:** "Saltmarsh Games values" (refused); "Saltmarsh Games interview process live operations producer" (refused); "Saltmarsh Games mobile studio news 2026" (refused); "Tobias Wrenfield Saltmarsh Games" (refused). No fetches.
- No `tuesday-dossier.md` was read.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Refused. It would have given value names to theme the two VAL questions. There would still be no values cheat sheet, since no values round was detected |
| 2. `Saltmarsh Games interview process` | unavailable | Refused. Your note already establishes one 60-minute session with Tobias. A loop source could have added the case format or a pre-set exercise |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Refused. It would have given the CASE bank and D3 Saltmarsh's actual titles, recent events and priorities, instead of `[generic]` problems |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Refused. It would have added an interviewer read, adjusted the persona weights, and tied a reverse question to his career path |
| 5. representative `Live Operations Producer` JD | skipped | Not needed: the JD you supplied defines the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Allow web search, then rerun research targets 1 to 4:** Saltmarsh's values by name, its titles and recent events in B1 to B5 and D3, and an interviewer read with a reverse question tied to Tobias's own path.
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes):** a strategy brief on Saltmarsh's two titles for CO questions, Tobias's talks or posts, and reports on this role's interview loop.
- **Whether Tobias is your future manager:** confirms or resets the persona weights. If he's a peer or a skip-level, the Case and Skeptic banks shift.
- **Any recruiter guidance (focus areas, or a pre-set exercise such as a calendar plan):** a dedicated build section for any graded exercise, which this pack doesn't have.
- **Your answers to the answer slots in A2, A5, C2 and C3:** these move F2, F3, F5 and F7 from slots to stories built on your own words.
- **A redacted copy of the release checklist or a past monthly retention deck:** the inspectable artifact a producer keeps. It would raise F4, F7 and F8 from medium to high confidence.
- **A `tuesday-dossier.md`:** would add evidence-checked gap strategies and a fixed list of claims not to make. This pack is complete without one.
