# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewers:** not known, and neither is their relationship to the role.
**Built from:** your message alone. No JD and no CV were supplied, and every web search this pack sent was refused by this session's permissions, so it uses nothing about Stripe from the web. Everything in it is labeled `[generic]` and the fit snapshot is a self-assessment worksheet. It's a usable rehearsal pack now, and the upgrade menu at the end lists exactly what each missing input would sharpen.

---

## How to use this pack

Two axes organize every question:

- **Personas** describe how a question arrives: who is asking and in what style. Rehearse the delivery as well as the content.
- **Types** describe what's being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior shows the values the company publishes. No published values are in hand here, so treat these as generic behavioral questions |
| EXP | Whether your own experience survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy homework |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to something you gave me or to cited research; `[inferred]` is derived from a representative source; `[generic]` is a role-family pattern that makes no claim about Stripe or about you. Every row here is `[generic]`.

Guidance is scaffolding, not a script. Where it says "pick a time…", you choose a real story from your own work, and every scaffold ends with what to do if no such story exists. Question IDs go by persona (A, B, C, D, E, G, H). F is reserved for fit-snapshot rows.

---

## Fit snapshot (self-assessment worksheet)

With no JD, the requirements below are typical of product operations roles in general. They are plain prose, not quotes from Stripe. With no CV, every evidence cell is empty. To use it, fill the evidence column yourself, in your own sentences, before you rehearse any bank. The bridge column says what strong evidence looks like.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Getting operations ready for product launches: processes, enablement, support handoff (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a launch you can name where you can say which readiness work was yours. Pick a launch or rollout where you prepared the people or processes around it. It needs a named product or change, a specific piece of preparation you did, and what happened at go-live. If no such launch comes to mind, say so plainly, then give the nearest thing your work does carry, or how you would approach it |
| F2 | Working across product, engineering, support, sales and risk teams (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a piece of work that needed another team to move, and how you got it moving. Pick a time you needed something from a team you didn't manage. It needs the ask, what made it hard, and where things ended up. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would handle it |
| F3 | Using data to find operational problems and measure impact (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a figure you can account for: how it was counted, and which part of it was yours. Pick a number from your own work you could defend for two follow-ups. If you don't know how a figure was counted, that is an honest answer. If no such figure comes to mind, say so plainly, then give how you would measure a problem in this role |
| F4 | Designing or improving processes and tooling so they scale (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a before and after you can describe in your own terms. Pick a process you changed or set up. It needs what it was like before, the change you made, and how you knew whether it helped. If none comes to mind, say so plainly, then describe how you would approach one |
| F5 | Turning customer or user feedback into product input (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a piece of feedback you carried to the people who could act on it, and what happened next. Pick a time you passed customer signal to a product or decision-maker. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would do it |
| F6 | Program management: priorities, timelines, stakeholder updates (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a piece of work you kept on track, with a moment where priorities collided. Pick one. It needs the collision and the call you made, or the call you escalated. If none comes to mind, say so plainly, then describe how you would run it |
| F7 | Working where operational mistakes carry financial or compliance cost (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is work where an error had a real cost, and how you guarded against it. Pick one if you have it. If not, say so plainly and describe how you would get up to speed safely |

---

## Persona table

No loop source here says how your final round is structured: your note doesn't say how many sessions there are, who runs them, or what each covers. The weights therefore fall back to the **generic archetype, with flat weights**, because this pack has no documented Stripe process to rest them on. Every persona gets three questions so you won't meet any style for the first time in the room. Send the schedule and these get reweighted.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of gaps: "why here, why now", the weakest part of your fit | Equal weight. It appears in some form whenever interviewers assess fit, and it carries this pack's highest-ROI question (A1) | Rehearse A1 until it's boring. Bridge only from evidence you actually have, name the limit plainly, and add a concrete ramp plan |
| B. Case / Strategist | Live problems from the role: plan this, diagnose that | Equal weight. Ops roles are commonly tested on live problems, but nothing here confirms that this loop includes a case | Clarify, then objective, then segment, then approach, then metrics, then risks. Think aloud and challenge one premise respectfully |
| C. Data-Driven Prober | Asks how numbers were counted and goes two levels deeper | Equal weight. F3 makes figures a likely target | Know what you can and can't say about how each of your numbers was counted, and name your weakest assumption first |
| D. Pressure | Interrupts, time-boxes answers, plays devil's advocate | Equal weight. No signal either way | Pause, restate the question, anchor in what you actually did, and hold through two follow-ups before conceding anything real |
| E. Values / Behavioral | STAR-shaped stories about judgment and candor | Equal weight. No Stripe values were fetched, so these score generic behavior, not Stripe's published values | "We" for context, "I" for your contribution. Choose stories where the hard truth actually landed |
| G. Peer Evaluator | Seams between teams, disagreement, credit-sharing | Equal weight. Product ops sits between teams by design (F2) | Frame what you bring to the peer's team, propose seam principles, and tell disagreement stories that show both spine and tact |
| H. Conversational | Friendly openers that are still scored | Equal weight. It opens most sessions | Have a 90-second arc ready, and treat casual questions as scored |

---

## Question banks

**Highest-ROI prep in this pack: A1.** Some version of "where are you weakest for this role" arrives in nearly every final, and a rehearsed, non-defensive answer changes how the rest of the conversation goes.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick the F1–F7 row where your own evidence is thinnest, and name it in one plain sentence. Don't pick a disguised strength. Then give your ramp as a plan, said in the future tense: what you'd learn first, from whom, and by when. Hold through two follow-ups: if pushed, repeat the limit and the plan, and add nothing to make the gap feel smaller. If every row feels covered, say so plainly, then name the one you'd most want to learn from the team | The highest-ROI rehearsal because it arrives in some form and candidates fold or bluff on it. JD because it scores the role's requirements directly. It returns as a deeper rehearsal once a CV shows where your real gap is |
| A2 | "Why this role, and why now?" | EXP | [generic] | Three beats in your own words: what in your own work points you toward product operations; what draws you to this team, using only things you've used, read or heard from people there yourself; and why the timing is right. Don't recite facts about the company that you can't say where you learned | A Skeptic tests motivation for consistency across sessions, so give the same answer in every one. EXP because it's scored against your own history |
| A3 | "An operational mistake here can cost a customer money. How would you get up to speed in a domain like that?" | CASE | [generic] | Structure it: what you'd read and who you'd shadow in the first weeks; which processes you'd leave untouched until you understood them; how you'd find where errors have happened before; and the first check you'd add. It needs no claim about your past, so make none unless you can give a real one | F7 as a live problem. CASE because it scores how you'd approach the domain, not a record |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the plan for getting operations ready for a new product launch. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, which teams touch it, the launch date, and what "ready" means. Then the plan: map every team the launch touches; for each, what they need (docs, training, tooling, escalation paths); a readiness checklist with owners; a go/no-go review; and a post-launch watch window with two or three metrics. Close on the risk you'd watch hardest | F1 and F6 as a live problem. CASE because it scores structure, and the clarify-first move is what's being watched |
| B2 | "Support tickets for one feature jumped 20% last month. Diagnose it." | CASE | [generic] | Clarify: is it absolute count or a rate per user, and did usage grow? Segment by ticket reason, customer segment and channel, and check what changed in that window: a release, a pricing or policy change, a docs change, a seasonal pattern. Form a hypothesis, say what data would kill it, then give the fix path and who owns it | F3 and F4 as a live problem. CASE because asking whether it's a count or a rate before diagnosing is the scored move |
| B3 | "Product wants to launch in two weeks; support says they won't be ready. What do you do?" | CASE | [generic] | Get the specifics from each side first: what exactly support lacks, and what drives product's date. Look for the smallest launch that's safe: a staged rollout, a limited audience, or a temporary escalation path. If there's no safe version, take the trade-off to whoever owns the decision with both costs stated. Don't decide it for them | F1, F2 and F6 colliding. CASE because it scores how you handle a trade-off, not who you side with |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a figure from your recent work you'd stand behind. Walk me through how it was counted." | EXP | [generic] | Choose a figure you can account for, and say in your own words how it was counted, what it's sensitive to, and which part of it was yours. If you don't know how it was counted, say so. That's an honest answer, and a better one than an explanation you can't repeat. If no figure comes to mind, say so plainly, then describe how you would measure the work instead | F3. EXP because Probers test whether your numbers survive two follow-ups |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they find it, in your own words, and say what would change if it were wrong. If you don't know the assumptions, say so plainly | The follow-up that turns a gotcha into a credibility gain. EXP because it scores whether you know your own evidence |
| C3 | "Say you change how escalations are routed. How would you know, three months later, whether it worked?" | CASE | [generic] | Define success before the change: one primary metric, such as time to resolution, plus a guardrail, such as reopen rate or customer satisfaction. Take a baseline, decide the comparison, watch for confounders like volume shifts, and set a review date with a rollback trigger | F3 and F4 as a live problem. CASE because it scores whether you'd set up measurement before you change anything |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause. One framing sentence, then two reasons from your own experience, then a close. Make no claims about internal candidates, because you don't know them. Rehearse against a timer | Pressure tests composure under a time box. JD because the reasons should land on the role's needs |
| D2 | "That result — how much of it was actually you?" | EXP | [generic] | Asked about whichever story you just told. Use "we" for the team's work and "I" for exactly yours. Hold your share through two follow-ups, and concede specifically where others did the work; don't shrink your part to restore harmony | Attribution is probed precisely because inflation is common. EXP because what's scored is honesty about your share |
| D3 | "Your launch plan from earlier just slipped a week and leadership is asking whose fault it is. Thirty seconds." | CASE | [generic] | Don't assign blame. Say what slipped, the new date, what you're doing to protect it, and what you need from them. Then stop talking | F6 under a time box. CASE content with Pressure delivery |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time it needed a named stake, what you actually said, and how it landed, including whether it changed anything. If no such time comes to mind, say so plainly, then give the nearest thing your work carries, or how you would handle it | Candor is a common behavioral theme. VAL because it scores behavior, though not against Stripe's published values, which this pack doesn't have |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a real tension between the metric and the customer, what you chose, and what it cost. If none comes to mind, say so plainly, then give the nearest thing your work carries, or how you would weigh it | F5 territory. VAL because it scores judgment under trade-off |
| E3 | "A process you own is hitting its target, but customers keep complaining. What do you do this week?" | CASE | [generic] | Treat the complaints as evidence the target is measuring the wrong thing. Read a sample of complaints, find the gap between the metric and the experience, propose a second measure, and say who you'd tell and when | F4 and F5 as a live problem. CASE delivery with VAL content |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles: who owns what, how a handoff is defined, and a disagreement path (talk directly first, then a shared decision-maker, with timelines). Ask what works today | F2. CASE because you're designing a working relationship live |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time credit had to be shared, and say how you named others' parts. If none comes to mind, say so plainly, then say how you would handle it | F2. VAL because peers score partnership behavior |
| G3 | "What would you need from me in your first month, and what would you take off my plate?" | CASE | [generic] | Reciprocity first: ask what currently costs them the most time, and offer to own something specific once you've learned it. Then keep your own ask small: context, introductions, and their read on the biggest gaps | F2. CASE because it scores whether you'd reduce a peer's load or add to it |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three turns that each led to the next, and why they lead here. Only real roles and moves, in your own words. Rehearse it out loud with a timer | The opener in most sessions. EXP because the arc gets checked against your CV |
| H2 | "What are you actually playing with these days, in work or out of it?" | EXP | [generic] | Something real and specific that you can talk about for two follow-ups. A casual register is still scored | Casual questions carry signal. EXP because it scores genuine interest |
| H3 | "So, what questions do you have for me?" | CO | [generic] | Use two from the reverse-questions section, adapted to who's asking. Never say "I think you've covered everything" | Rapport-style interviewers weight this slot as a preparation signal. CO because it shows your homework |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 launch readiness | B1, B3, D3 |
| F2 cross-functional work | G1, G2, G3, B3 |
| F3 data and measurement | C1, C2, C3, B2 |
| F4 processes and tooling | B2, C3, E3 |
| F5 customer feedback into product | E2, E3 |
| F6 program management | B1, B3, D3 |
| F7 risk-sensitive domain | A3 |

No CO or CASE question is grounded in Stripe's current strategy, because research didn't run. That's the honest cost of the refused searches, and the upgrade menu says how to recover it.

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great first six months look like in this role, and what would make you say the hire was a mistake?" | It shows you're thinking about outcomes, and the answer tells you what you'll really be judged on |
| "Where do product launches tend to go wrong operationally here today?" | It invites the interviewer to describe real pain, which is the work you'd be hired to fix |
| "How does product operations decide what to work on: who brings the requests, and who prioritizes them?" | It surfaces the team's power dynamics and how much ownership the role actually has |
| "Which team does this role work with most closely, and what does that relationship need that it isn't getting?" | It shows reciprocity thinking and hands you the seam to address in later sessions |
| "What's something the team changed its mind about in the past year?" | It reveals how decisions get revisited, and it's hard to answer generically |
| "Is there anything in my background you'd like me to say more about before we finish?" | It gives you a last chance to answer a hidden objection while you're still in the room |

---

## Prohibited claims

No entries yet. This list holds the stretched versions of sentences you've given me, the claims a candidate reaches for under pressure. You haven't shared any sentences about your experience yet, so there's nothing to stretch. The standing rule still applies to every scaffold above: tell only what you actually did, at the size you actually did it. Once a CV arrives, this list gets built from it before any bank is rewritten.

---

## Sources

- **Provided documents:** your message only ("Final-round interview at Stripe for a Product Operations Manager role").
- **Searches sent**, all refused by this session's permissions, so nothing came back:
  - `Stripe operating principles` → refused
  - `Stripe interview process operations final round` → refused
  - `Stripe "Product Operations" job posting responsibilities` → refused
  - `Stripe strategy news 2026` → refused
- **Fetches:** none sent.
- **Dossier:** none present; this pack was built standalone.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Refused. It would have given Stripe's published principles by name, VAL questions themed on them, and possibly a values cheat sheet |
| 2. `Stripe interview process` | unavailable | Refused. It would have given the final round's documented structure and persona weights based on named sessions instead of flat ones |
| 3. `Stripe strategy` / recent news | unavailable | Refused. It would have given CO and CASE questions grounded in current priorities |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative Product Operations Manager JD | unavailable | Refused. It would have turned F1–F7 from role-family prose into quoted `[inferred]` requirements |

---

## Upgrade menu

- **The JD text** → F1–F7 become quoted `[grounded]` requirements, every JD-tagged question gets rewritten against Stripe's own list, and any gate (location, office pattern, work authorization) becomes a visible row.
- **Your CV, or a few sentences about your recent roles** → the worksheet becomes a real fit snapshot, scaffolds become story-mapped guidance on your own sentences, A1 gets aimed at your actual gap, C1 and C2 target your real figures, and the prohibited list gets built.
- **Allowing web search in this session** → targets 1, 2, 3 and 5 run: Stripe's principles by name, the documented loop, and current-strategy CO and CASE questions.
- **A deeper research pass**, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief on Stripe's current strategy and vocabulary, plus recent org context for the role.
- **If your final is several sessions, send the schedule** → a mini-pack per session, each with its own persona weights and question bank.
- **Interviewer names** → a read on each interviewer's public professional footprint, reweighted personas, and a reverse question tied to their own path.
- **The recruiter's prep email** → coverage of any focus areas they named, and a build section for any pre-declared presentation or exercise.
- **A `tuesday-dossier.md`** → evidence-graded weak areas, a named highest-ROI objection, and a prohibited-claims guardrail drawn from your confirmed evidence.
