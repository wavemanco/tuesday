# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, Tuesday. 60-minute panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). It opens with a 15-minute spoken POV, no slides, followed by Q&A, with Ross pushing on commercials.
**Built from:** your message and the recruiter's email you quoted. No JD and no CV. The market report you read is not in this conversation, so nothing here rests on what it says. Web search was refused, so nothing here comes from research either (see Sources).

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what style. **Types** describe what the answer is scored on.
- Type key:
  - **VAL**: values and behaviour, shown through past decisions
  - **EXP**: deep-dive on your experience, and what was actually yours
  - **JD**: can you do the role as stated, gaps included
  - **CO**: company and strategy homework, and whether you can think at their level
  - **CASE**: a live problem from the role, scored on structure and reasoning
- Provenance labels: `[grounded]` means traceable to your message or the recruiter's email. `[inferred]` means a derivation, and the row names what it is derived from. `[generic]` means a pattern for the role family that makes no claim about Kelverton.
- The guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- Fit-snapshot rows are F1 to F5. Question IDs are A to E, then G and H. F is skipped so a question ID never collides with a snapshot row.

---

## Prep triage (4 hours)

| Order | Time | Do this | Section |
|---|---|---|---|
| 1 | 60 min | Build the POV outline from the graded-deliverable section. Pick your theses, write down each one's concession, and write the operator close | Graded deliverable |
| 2 | 30 min | Go back to the market report. Pull 3 or 4 figures or claims you can cite exactly. Choose one consensus point to agree with and one to push against | Graded deliverable, A4 |
| 3 | 45 min | Rehearse B1 aloud until it bores you. This is the highest-ROI prep in the pack. Then do C2 and C3 | B1, C2, C3 |
| 4 | 30 min | Ross's commercial questions. Work out what you can and cannot say about the £4M and the 6-to-40 figure | C1, C4, D1, D2 |
| 5 | 45 min | Two timed run-throughs of the POV, out loud, aiming for 12 to 13 minutes. Record one and listen back | Graded deliverable |
| 6 | 15 min | Choose three reverse questions: two for Deepa, one for Ross | Reverse questions |
| 7 | 15 min | A live drill of B1 with me, if you want one | B1 |

Everything else in this pack is insurance.

---

## Fit snapshot

No JD was supplied. F1 to F3 quote the recruiter's email. F4 and F5 are role-family requirements: a JD may confirm them or remove them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships" — your message, "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company. It does not describe operator partnerships in rail, and your words should stay at that scope: "For the last four years I ran the ISV channel at a payments company, and it went from 6 partners to 40." Answer slot: the recruiter's "operator partnerships" makes a probe on how that work maps across likely. If some of it was with the businesses your partners served, not only with the partners, say which part and how, in your own words. If none of it was, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material describes bus and light rail network planning, done as a consultant. It does not describe train operating companies, and it does not describe selling. Your words: "I spent five years in transport consulting, on bus and light rail network planning." The panel will hear "from the other side" and choose a meaning for it, so say what you meant, in your own words. Answer slot: if that consulting put you in front of operator teams, say whose and on what. If your clients were other bodies, or the work never did, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | Your material gives a revenue figure, and it is influenced revenue. It says nothing about deal terms. Answer slot: the recruiter's line makes a probe on the commercial terms of your partnerships likely. If any partner terms were yours to set or negotiate, say which and how you decided, in your own words. If none were, say so plainly and stay with the influenced figure and how it was counted |
| F4 | Owning direct revenue or a quota, which partnerships roles selling to customers often carry. This is a role-family requirement, not stated by Kelverton | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you have stated yourself. Words: "I haven't carried a direct quota. My number has been influenced revenue." Then, as a plan and never as a past, say how you would want to be measured in this role and what you would need in order to own a number. Add nothing to make the gap feel smaller |
| F5 | Experience selling into rail operators. This is a role-family requirement | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you have stated yourself. Words: "I haven't sold into rail." Then, as a plan, say how you would learn the operator buying cycle in your first months. Never claim rail selling or knowledge of how train operators buy |

---

## Graded deliverable: the 15-minute POV

The recruiter's brief is "where you'd take our operator partnerships over the next 18 months". It is spoken, with no slides, and it has to "land on what it means for the operators themselves".

**Grounded facts to build on**

- About Kelverton, from your message: UK rail-tech, about 600 staff, selling scheduling software to train operating companies. Add the figures you pull from the report in prep step 2, quoted exactly and attributed to "your strategy team's report".
- About you, from F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"
- About you, from F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."

**Say your one assumption in the first minute.** The brief does not say what "operator partnerships" covers. It could mean the commercial relationship with operators who use the product, third parties working around those operators, or both. Name the reading you built on, and invite them to correct it. That turns an ambiguity into a sign that you listened.

**Suggested shape (about 13 minutes, leaving 2 minutes of slack)**

| Time | Block |
|---|---|
| 0:00 to 1:00 | What you heard in the brief, your assumption, and the one-sentence answer |
| 1:00 to 3:00 | Where things stand, using only what the report says. One consensus point you agree with, then where you diverge |
| 3:00 to 9:00 | Your theses, sequenced across the 18 months |
| 9:00 to 11:30 | What it means for operators. This is the requested close |
| 11:30 to 13:00 | What you'd need, how you'd want to be measured, and the risks. This gets ahead of Ross |

**Thesis options (choose 2 or 3)**

| # | Thesis | Provenance | Mandatory concession | Where your material fits |
|---|---|---|---|---|
| T1 | Go deep before going broad. Run a small number of operator partnerships against a joint 18-month plan, with outcomes measured on the operator's own measures | [generic] | It shows fewer new names early. Ross will want the revenue logic, meaning renewal, expansion or references, stated in the same breath | None of your quotes speaks to this, so it is a plan, not a story |
| T2 | Build an ecosystem around the operator: partners whose systems sit next to scheduling, so operators deal with fewer handoffs | [generic] | You haven't seen Kelverton's integration roadmap. Whether the product can support partners is something you would confirm, not assume. Payments and rail ecosystems differ | F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — keep it at that scope |
| T3 | Sequence it: diagnose in months 0 to 3, prove the model with one or two operators in months 3 to 9, then codify and scale in months 9 to 18 | [generic] | A diagnosis phase can sound passive to a commercial director. Name what visibly ships in the first 90 days | None, so it is a plan |

**Differentiation strategy**

- **The consensus answer:** recite the report's growth areas back to the panel, then add "and sign more partners." Their own strategy team wrote the report, so reciting it scores as homework at best.
- **Do this instead:** cite one consensus item from the report, exactly, to show you read it. Then take one position the report does not take, with your reason. Then ask the panel where they think the report is wrong.
- **The anti-pick:** someone with your background would be expected to propose adding partners. Name that move yourself, and say why you would not make partner count the goal in the first 18 months. Present this as your plan, not as a lesson you learned in a past role.

**The requested close: what it means for operators**

For each thesis you use, say one line on what the operator gets. Take it from what the report says operators care about, not from general rail lore. Suggested frames, all `[generic]`:

- **T1:** the operator gets a plan measured on its own outcomes.
- **T2:** the operator gets fewer gaps between scheduling and the systems around it.
- **T3:** the operator gets a partner that learned their situation before proposing anything.

End on the operator, not on Kelverton.

**If the report covers industry structure:** check whether it says anything about changes to operator ownership or contracting over your 18-month window. If it does, your POV needs to say who the "operator" will be at month 18.

---

## Reading the interviewers

Source: the recruiter's email only. Public profiles were not researched because search was refused.

| Interviewer | What the email says | Practical implications |
|---|---|---|
| Deepa | VP Partnerships, your future manager | She is buying capability and wants your gaps de-risked. Expect "what would you do first" and questions on how you'd work. Ask her at least one reverse question about how she defines success |
| Ross | Commercial Director. "Ross will push on commercials" | Expect numbers, revenue timing, pricing pressure, and attribution of the £4M. Hold-then-concede matters most with him. Give him a way to model the plan, not a figure you can't back |

There are no mirror opportunities: without their public career paths, there is nothing to pair with your F rows.

---

## Persona table

The loop for this session is set by the recruiter's own words: one panel, two named members, a POV, then Q&A. These weights follow from that.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The POV itself, then "what first" and "which operator" follow-ups | Highest (5 questions). The panel format and the POV brief are both strategy-led, and the hiring-manager prior points the same way | Clarify, state the objective, segment, give the approach, then the metrics, then the risks. Challenge one premise respectfully |
| Skeptic | Your path from payments and bus/light rail into rail-tech; influenced revenue versus owned revenue | High (4). The F4 and F5 gaps are stated and obvious | Give the plain acknowledgment in your own words, then what you did at its own scope, then a ramp plan |
| Pressure | Ross pushing on commercials | High (4). The recruiter named it | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Data-Driven Prober | The £4M and the 6-to-40 figure | Medium (3). Commercials plus headline numbers | Know how each figure was counted, or say plainly that you don't |
| Conversational | The opening "walk me through" and "why us" | Low (2). It is the second round, but the opener still happens | A 90-second arc built only from what you've stated |
| Peer Evaluator | Deepa testing the seam with sales and account teams | Low (2). She owns partnerships, so seam questions come from her | Propose seam principles, and offer reciprocity |
| Values / Behavioural | Generic behavioural probes | Low (2). No loop source names a values round, and no published values were read | Selection scaffolds with honest branches |

---

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before committing to an 18-month plan, what would you need to know?" | CASE | [grounded] | Clarify before you plan. Ask what "operator partnership" covers today, how many operators are customers, where revenue comes from (new business, renewal or expansion), what has already been tried, and what Deepa would call a win at 12 months. Then say which answer would change your plan most | This follows straight on from the POV brief. CASE because it scores whether you clarify before structuring |
| A2 | "Which operator would you start with, and why?" | CASE | [generic] | Answer with criteria, not a name: an existing relationship, a live pain your work could address, and a willingness to co-design. Name an operator only if the report gives you grounds you can quote. Otherwise say which criteria you would test first | A natural follow-up to T1 and T3. `[generic]` because no Kelverton customer data is in hand |
| A3 | "What does a successful operator partnership look like at month 18, for us and for them?" | CASE | [grounded] | Use a two-sided scorecard. Kelverton's side: renewal, expansion, a referenceable operator. The operator's side: the measures they themselves track, taken from the report or from asking them, never assumed. Then name the leading indicator you'd check at month 6 | The recruiter asked for the operator close, so expect it to be tested. CASE with a CO flavour |
| A4 | "You've read our strategy team's report. What did you take from it, and where do you disagree?" | CO | [grounded] | One point you agree with, quoted exactly. One point you'd push on, with your reason. Then a question back. Use only what the report actually says. If you have no disagreement, say what you would want to test instead | They circulated the report to you, so they will check what you did with it. CO because it scores homework depth |
| A5 | "If we could fund only one partnership motion next year, what is it, and what do you drop?" | CASE | [generic] | Pick one thesis, name what you would stop or defer, and give the cost of dropping it. Saying no, with a reason, is the point of the question | It tests prioritisation. The anti-pick in the POV sets it up |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota and you've never sold into rail. Why should we believe you can move revenue with operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Open with the limit before they press it: "I haven't sold into rail, and I haven't carried a direct quota. My number has been influenced revenue." Then hold on what the quote carries: "For the last four years I ran the ISV channel at a payments company. It went from 6 partners to 40, with roughly £4M of influenced revenue." Then a plan, not a past: how you would want to be measured here, and what you would learn first. Follow-up 1, "So someone else closed those deals?": answer slot. Say which part of that revenue was yours and how it was counted, in your own words. If you don't know how it was counted, say so plainly. Follow-up 2, "Influenced is soft": hold. Restate the quote, concede that it isn't owned revenue, and do not fold into apologising. Never upgrade "influenced" | F4 and F5 are stated gaps, and Ross's commercial focus aims straight at them. JD because it scores the role's revenue expectation against your record |
| B2 | "Partnerships at a payments company and operator partnerships in rail are different jobs. What carries over?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Say what you ran, at the quote's scope. Answer slot: if particular ways of working in that channel would carry into operator partnerships, name them and say how you did them, in your own words. If you can't point to one, say so and describe how you would work instead. Let the panel draw the inference: don't tell them your channel "proves" anything | F1 is a transferability row, so expect this probe. EXP because it tests what was actually yours |
| B3 | "Your consulting was bus and light rail. How much do you actually know about how a train operator runs day to day?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | "I spent five years in transport consulting, on bus and light rail network planning." Say what "from the other side" means to you. Answer slot: if that work involved operator teams, say whose and on what. If it didn't, say so plainly. Then give the plan: how you would learn a train operator's realities in your first months, said as a plan | F2's limit, and the place an overreach would be easiest to catch. EXP because it tests the claim behind "the other side" |
| B4 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Give your actual reason, in your own words. If the transport consulting is genuinely part of it, you can say so in the quote's terms. If it isn't, don't use it as decoration | The Skeptic's motivation probe. EXP because it tests whether your story is consistent |

### C — Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Give me a number. What revenue does your plan add in 18 months?" | CASE | [generic] | Hold first: "I'd rather show you how I'd build the number than give you one I made up in the room." Then name the inputs you'd use: current operator customers, contract values, renewal and expansion rates. Use figures from the report if it has them, quoted exactly. Under a second push, concede: offer a directional range only from numbers they give you live, and name the assumption you'd defend least. Never invent a baseline | Ross was named as the commercials pusher. CASE because it scores reasoning under pressure, not the figure |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Restate it exactly: "roughly £4M of influenced revenue." Then four answer slots, each in your own words. How it was counted. What it is sensitive to. The assumption behind it you'd defend least. Which part was yours. "I don't know how it was counted" is an honest answer. Name your weakest assumption before Ross does. Never let it drift to "generated" or "closed" | Your headline metric is the defend-the-number target. EXP because it tests attribution |
| C3 | "Sixty seconds: why you over someone who's sold to operators for ten years?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause. Concede plainly: "I haven't sold into rail." Then put your two quotes side by side, each at its own scope: five years of transport consulting on bus and light rail network planning, and the last four years running an ISV channel that went from 6 to 40 partners. Then the POV's plan. Hold through the follow-up without claiming rail experience | Pressure stem aimed at F5. Rehearsing it time-boxed keeps it from sprawling |
| C4 | "An operator wants a big discount in return for being a 'strategic partner'. What do you do?" | CASE | [generic] | Structure it. What do they give in return: a reference, co-development input, a longer term, data? What is the walk-away? Who approves? How do you stop it becoming the precedent for every operator? Make no claim about past negotiations | Pricing is Ross's native language. `[generic]` because it is a pattern, not a fact about Kelverton |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you went from 6 partners to 40." | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | The beats the quote states: the ISV channel, four years, 6 to 40. Tell them in your own words. Answer slot: if the decisions on which partners to add were yours, say how you made them. If they weren't, or there was no such decision, say so plainly and describe how you ran the channel | A headline number, so it will be probed. EXP because it tests attribution |
| D2 | "Of the 40, how many actually produced revenue?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you know how the £4M was spread across partners, say so in your own words. If you don't, say so plainly. Don't estimate on the spot | The denominator question. It ties the two numbers together |
| D3 | "How would you know an operator partnership is working at six months?" | CASE | [generic] | Pair leading indicators (engagement, a joint plan agreed, a pilot live) with lagging ones (renewal, expansion, a reference). Then name which assumption in that model you trust least | Measurement thinking. It also sets up how you would want to be measured (F4) |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc using only these beats: five years of transport consulting on bus and light rail network planning, then nine years in partnerships, the last four running an ISV channel that went from 6 to 40 partners with roughly £4M of influenced revenue. The five partnership years before the payments company aren't described in your message, so tell them in your own words. End on why this role | The opener. A tight arc sets the frame for everything after it |
| E2 | "What drew you to Kelverton?" | EXP | [generic] | Give your real reason, in your own words. If it is the operator-facing side of the brief, say so specifically. Avoid generic praise | Scored even though it's casual |

### G — Peer Evaluator (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where's the seam between partnerships and whoever owns the operator account, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a turf claim: one owner of the operator relationship, agreed rules on who leads which conversations, shared measures, and a fast escalation route. Say what you'd bring to the account team, not just what you'd need from them | Deepa will test how you fit beside sales. CASE because you don't yet know the real seam |
| G2 | "How do you handle credit when a partner-influenced deal closes through sales?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Answer slot: your number has been influenced revenue, so expect this. If there were attribution rules in your channel, say how they worked and how you dealt with disputes, in your own words. If there weren't, say so plainly and describe how you'd want it to work here | Influenced revenue makes the credit question live (F4) |

### H — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told a partner or a leader something they didn't want to hear." | VAL | [generic] | Choose a story with a named stake, a moment where you held your position, and a relationship that stayed intact. Use "we" for the context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | A common behavioural probe. `[generic]` because no published values were read |
| H2 | "When did you put a customer's interest ahead of an internal number?" | VAL | [generic] | Choose a time with a real trade-off you made. If none comes to mind, say so plainly, then give the nearest thing you have, or how you'd handle it. It echoes the "what it means for operators" close | It mirrors the recruiter's operator emphasis |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: the 18-month operator partnerships POV | POV section, A1, A2, A3, A4, A5, B2, D1 |
| F2: what it means for operators | POV close, A3, B3, H2 |
| F3: commercials | C1, C2, C4, D2, D3 |
| F4: direct revenue ownership | B1, C2, G2, D3 |
| F5: selling into rail | B1, B3, C3 |

---

## Reverse questions

| # | For | Question | Why it lands |
|---|---|---|---|
| R1 | Deepa | "When you say operator partnerships, what does that cover today: the commercial relationship with operators, third parties around them, or both?" | It settles the assumption your POV was built on, and shows you noticed the ambiguity |
| R2 | Deepa | "At 12 months, what would make you say this hire worked?" | You get her real scorecard and can answer against it in the rest of the session |
| R3 | Ross | "How are partnerships measured commercially here: sourced revenue, influenced revenue, or a target of their own?" | It meets F4 head-on and tells you what you'd actually be carrying |
| R4 | Ross | "Where's the commercial tension between what operators want from a partnership and what Kelverton needs?" | It speaks his language and links back to the operator close |
| R5 | Both | "Which part of the strategy team's report do you think is most likely to be wrong?" | It invites them into your differentiation move and shows you treat the report as a starting point |
| R6 | Both | "What would most change for operators over the next 18 months that this plan has to survive?" | It tests the plan's horizon and shows you're thinking from the operator's side |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or owned revenue directly | A negative you stated, F4 | "I haven't carried a direct quota. My number has been influenced revenue." No answer slot |
| Has sold into rail | A negative you stated, F5 | "I haven't sold into rail." No answer slot |
| £4M generated, closed or delivered | Contradicted by your quote: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | That quote, and the F1 quote's "roughly £4M of influenced revenue." |
| Built the ISV channel from scratch | Inflated form of F1 | The F1 quote at its own scope. Your material says 6 to 40, not from zero |
| Has worked with train operating companies or in heavy rail | Inflated form of F2 | The F2 quote at its own scope: bus and light rail network planning. B3's answer slot stays inside that work |
| Knows operators from the inside | Inflated form of F2 | The F2 quote. Your sentence says "from the other side", and the pack does not widen it |

---

## Sources

**Provided documents**

- Your message, including the recruiter's email quoted verbatim.
- The internal market report: you read it, but it was not shared here. Nothing in this pack rests on its contents.
- No dossier was present.

**Searches sent (all refused, so none returned results)**

1. "Kelverton Rail values" (refused)
2. "Kelverton Rail interview process partnerships" (refused)
3. "Kelverton Rail scheduling software train operating companies news" (refused)
4. "Deepa VP Partnerships Kelverton Rail" (refused)
5. "Ross Commercial Director Kelverton Rail" (refused)
6. "Senior Partnerships Manager rail software job description UK" (refused)

No pages were fetched.

**Target accounting**

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused. It would have themed the H bank on published values. No values round is detected either way |
| 2. `Kelverton Rail interview process` | unavailable | Refused. The recruiter's words already set this session, but it would have shown whether later rounds exist |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Refused. It would have grounded A2, A4 and the POV's "where things stand" block, and made CO questions company-specific |
| 4. `Deepa` / `Ross` at Kelverton Rail | unavailable | Refused. It would have added career patterns, mirror opportunities and a reverse question tied to their own paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | Refused. It would have turned F4 and F5 from role-family prose into quoted `[inferred]` rows, and added JD-tagged coverage |

---

## Upgrade menu

- **The JD text:** F4 and F5 become quoted requirements, or drop out. Every JD requirement gets a covering question.
- **Key passages from the market report, pasted:** the POV's facts, A2, A4 and C1 become `[grounded]` on Kelverton's own numbers, and the consensus-and-divergence move gets specific.
- **Web search permission:** an L1 re-run covering values, recent news, Deepa's and Ross's public footprint, and a representative JD. That fills the five `unavailable` rows above.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It covers a strategy brief, the interviewers' talks or writing, and recent organisational context, for a sharper POV and CO bank.
- **Your CV:** the five partnership years before the payments company can be mapped into E1, H1 and H2 instead of left as scaffolds.
- **Your own answers to the answer slots:** whether your consulting put you in front of operator teams (F2, B3), whether partner terms were yours (F3, C2), and how the partner decisions were made (D1). Each answer moves those rows from a slot to a mapped story.
- **A `tuesday-dossier.md`:** it would record verified evidence and the objections to rehearse first, carried between sessions.
