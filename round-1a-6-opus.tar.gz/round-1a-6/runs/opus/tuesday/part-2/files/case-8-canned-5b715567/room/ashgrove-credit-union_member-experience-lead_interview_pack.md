# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 5 December 2026 (three rounds, one day) · **Pack built:** 26 November 2026

| Round | Who | Length | What it holds (recruiter's words) |
|---|---|---|---|
| R1 | The recruiter | 30 min | "30 minutes with me" |
| R2 | Head of Member Services, your would-be manager | 45 min | "mostly behavioural" |
| R3 | Panel of two branch managers | 60 min | "a 20-minute case on a complaint escalation"; "The panel is also the values round — they score against the four values" |

No interviewer names have been assigned yet, so there is no section on reading the interviewers, and the persona weights come from each round's role and the recruiter's description.

---

## 1. How to use this pack

- **Personas** describe *how* a question gets asked: who is asking and in what style. **Types** describe *what* is being scored. Rehearse both.
- **Type key:** `VAL` tests values and behaviour against Ashgrove's four published values. `EXP` is a deep-dive on what you actually did. `JD` checks whether you can do the listed job, gaps included. `CO` tests what you know of Ashgrove's strategy. `CASE` is a live problem worked through out loud.
- **Provenance labels:** `[grounded]` traces to something you, the recruiter or Ashgrove's own material said. `[inferred]` is this pack's own derivation, with the reasoning named. `[generic]` is a common pattern for roles like this and says nothing specific about Ashgrove.
- **Answer slots.** Some guidance says "Answer slot: if you did X, say how; if not, say so plainly". That is an instruction for the interview, not a question for you to answer here. Both branches are honest answers, and the second is never a confession.
- Guidance is scaffolding, not a script. Say it in your own words.

## 2. Prep triage: nine days to 5 December

1. **Days 1–2: C1, out loud, until it bores you.** This is the highest-ROI prep in the pack (R2, Skeptic bank).
2. **Days 3–4: the 20-minute case (section 4).** Run the structure twice against a timer, once with someone playing an angry member.
3. **Day 5: find your real answers to the answer slots on F1, F3, F7 and F9.** Look at the actual spreadsheet and the actual complaints log, if you still can, so you know what was in them before anyone asks.
4. **Day 6: the four values stories (section 9, H1–H4).** One story per value, each 90 seconds.
5. **Day 7: your 90-second background (A1) and the logistics answers (A3–A6).**
6. **Day 8: pick two reverse questions per round and drop the rest.**
7. **Day 9: rest.** Everything else in this pack is insurance.

---

## 3. Fit snapshot (shared across all rounds)

Your four sentences, which everything below draws on:

- "6 years in retail banking, the last 3 as a branch supervisor."
- "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- "I built the monthly complaints spreadsheet our regional manager uses."
- "Never worked in a contact centre, and I've never presented to anyone above regional level."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows one branch's formal complaints log. It does not show a process across branches, so your words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If you investigated, decided or replied to complaints on it, say which and how, in your own words. If handling it meant keeping the record while others decided, say so plainly and describe what keeping it involved |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you have said so yourself. Words: "I haven't worked in a contact centre." Follow them with how you would learn it, said as a plan and never as something you have done. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The spreadsheet is monthly and covers complaints. Your material does not show whether it counts volumes or resolution times. Answer slot: if it tracks either, say what it counts and how, in your own words. If it tracks something else, say what, and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers. That is tellers, not supervisors, and "our" script, which doesn't show you wrote it. Words: "I trained new tellers on our escalation script." Answer slot: if you shaped or changed the script, say how. If it was handed to you, say so plainly and describe how you trained people on it |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence would be a time you fed branch or complaint information into an online or app journey, or worked alongside a digital team. Answer slot: if you ever did, say what and with whom, in your own words. If not, say so plainly and say what you would bring from the branch side and how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but expect a probe, because this is one sentence with nothing behind it to inspect. Lead in your own terms (six years in retail banking, the last three as a branch supervisor) and let the interviewer map that to "customer operations". Don't relabel your history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | "Formal complaints log" touches regulated complaints but doesn't show which rules governed those complaints or what part of them was yours. Answer slot: the JD's regulated-complaints line makes a probe on the rules likely. If those complaints carried regulatory rules such as deadlines or required responses, say which applied and what they asked of you, in your own words. If you don't know, or that part sat with someone else, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you have said so yourself. Words: "I haven't presented above regional level." Follow them with how you would get ready, said as a plan. Your sentence doesn't say you have presented *at* regional level either, so don't claim that |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says "spreadsheet". It doesn't name Excel or say what is inside. Answer slot: expect a probe on the tool and how the sheet works. Name the tool you built it in and the features you actually used. If it wasn't Excel, say what it was |

**Requirement coverage**

| JD requirement | Fit row | Question IDs |
|---|---|---|
| Own complaints end to end across branches | F1 | C1, C3, J3, K1 |
| Own complaints in the contact centre | F2 | B2, C1, C3 |
| Report monthly on volumes and resolution times | F3 | C4, E2 |
| Coach branch supervisors on escalations | F4 | C2, J1, K1 |
| Work with digital teams on self-service journeys | F5 | E1, J2 |
| 4+ years financial-services customer operations | F6 | A1 |
| Experience handling regulated complaints | F7 | B1 |
| Confident presenting to senior leaders | F8 | C1, C5 |
| Comfortable with Excel reporting | F9 | B3, C4 |

---

## 4. Graded deliverable: the 20-minute complaint escalation case (R3)

The recruiter announced it, and the two branch managers score it against the four values. You don't know the scenario yet, so this section gives you a structure, positions you can defend, and what you can and can't claim about yourself.

**What you can build on**

| Fact | Source | Provenance |
|---|---|---|
| The case is "a 20-minute case on a complaint escalation", inside a 60-minute panel of "two branch managers" | Recruiter's email | [grounded] |
| "they score against the four values" | Recruiter's email | [grounded] |
| Values: "Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix" | Values text you copied from ashgrovecu.org/about/values, 26 Nov 2026 | [grounded] |
| Strategy: 40% of member service to digital by 2028; eight branches consolidated into five hubs over 2027; small-business lending launching Q1 2027; app-only banks named as the main competitive pressure | Your summary of the July 2026 strategy brief | [grounded] |
| Through 2027, branch consolidation is a plausible source of the complaints the panel will bring | Derived from the hubs plan; nothing published says so | [inferred] |
| What you bring: F1 "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Fit snapshot F1 | [grounded] |

**A structure for 20 minutes (a rehearsal method, not a fact about Ashgrove)** `[generic]`

| Minutes | Move | The value it lets the panel score |
|---|---|---|
| 0–3 | Clarify: who is the member, what happened, what they want, what has already been tried, any deadline or vulnerability | Members First, Always |
| 3–7 | Contain: what happens for the member today, who calls them, and what they're told in plain words | Members First, Always; Plain Words |
| 7–12 | Decide: facts needed, the rules that apply, who decides, and what you would and wouldn't promise before the facts are in | Own the Fix |
| 12–16 | Fix the cause: was this one bad moment, or a process, script or journey problem? Who keeps hold of it until it's solved? | Own the Fix |
| 16–19 | Close the loop locally: what the branch, its supervisor and the town hear; how it enters the monthly complaints report | Neighbours, Not Numbers |
| 19–20 | Summarise in three plain sentences | Plain Words |

**Positions you can defend, each with its concession**

| Thesis | Concession you say out loud | Provenance |
|---|---|---|
| Sort out the member's situation first, then fix the process, and never the other way round | You can't promise the outcome before the facts are in, so you promise the next contact and its date | [generic] |
| An escalation is a coaching moment for the branch supervisor, not just a handoff upward | Some cases have to be taken over: a regulatory deadline at risk, or a member who needs extra care | [generic] |
| One complaint is a data point for the monthly report and a possible root cause | One complaint isn't a trend. You flag it, check it against the log, and don't redesign anything on the strength of a single case | [generic] |

**Standing out from the stock answer.** The stock answer is "apologise, investigate, resolve", and every prepared candidate will give it. Give it in the first five minutes to show you know it. Then go further on the points most candidates skip: the root cause, the named person who keeps hold of the fix, and the plain-words reply.

**Don'ts:** don't offer compensation or promise an outcome before the facts are in. Don't blame the branch in front of branch managers. Don't send the member to the app as the fix if the complaint is that they can't or won't use it. That last one is where the digital target and "Neighbours, Not Numbers" collide, so name the tension if it comes up.

**About yourself in the case:** if you reach for your own experience, say only F1's words, at their scope. Don't describe running a cross-branch or contact-centre process (see section 12).

---

## 5. Grounding brief: Ashgrove in its own words

| Item | What it says | Source | Provenance | How to use it |
|---|---|---|---|---|
| Ownership and size | "member-owned, about 900 staff" | JD | [grounded] | Say "members", never "customers" |
| Members First, Always | "we decide from the member's side of the counter" | Values text you copied | [grounded] | Section 9, H1 |
| Plain Words | "if a member needs it explained twice, we wrote it wrong" | Values text you copied | [grounded] | Section 9, H2; minutes 3–7 and 19–20 of the case |
| Neighbours, Not Numbers | "every branch is part of its town" | Values text you copied | [grounded] | Section 9, H3; J2 |
| Own the Fix | "whoever finds the problem keeps hold of it until it is solved" | Values text you copied | [grounded] | Section 9, H4; minutes 12–16 of the case |
| Digital shift | 40% of member service to digital channels by 2028 | July 2026 brief, as you summarised it | [grounded] | E1; J2 |
| Hubs | eight branches into five hubs over 2027 | July 2026 brief, as you summarised it | [grounded] | J2; K2; reverse questions |
| New product | small-business lending, Q1 2027 | July 2026 brief, as you summarised it | [grounded] | Reverse question R2-5 |
| Competition | app-only banks named as the main pressure | July 2026 brief, as you summarised it | [grounded] | E1 |

Your copy is a summary of the brief, not its text, so quote no figures beyond those above.

---

## 6. Round 1: recruiter screen (30 min)

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation and logistics | High. This is the standard pattern for a recruiter round, and it is the first of the three | Have a 90-second background ready; treat every casual question as scored |
| Skeptic (light) | Quick knockout checks against the JD's requirements | Medium. Recruiters usually screen the listed requirements before passing you to the manager | Short honest answers: say the gap, then the plan, and stop |

**Bank A: Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, in order: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on your escalation script. You built the monthly complaints spreadsheet your regional manager uses. End with why this role, in your own words. Say what you did and let the recruiter draw the conclusions | Almost certain opener. F6, F1 and F3 are the rows that carry it. EXP because the recruiter is checking that your account hangs together |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Name one value by its exact name and one strategy point (the hubs or the digital shift), then say in your own words why they matter to you. Your motivation is yours to state; the pack supplies none | Standard recruiter question. CO because naming a value or a strategy point shows you've done the homework |
| A3 | "What salary are you looking for?" | JD | [generic] | Give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Logistics the recruiter has to clear. The JD states no pay |
| A4 | "What's your notice period?" | JD | [generic] | Give your actual notice period | Logistics; it decides start dates |
| A5 | "The role spans branches and the contact centre. How are you on location and travel?" | JD | [inferred] | Say where you can work and how much travel you can take on, in your own words | The JD names branches and the contact centre, and the hubs plan changes where branches are, so travel is likely to come up. The JD states no location |
| A6 | "Why are you looking to move?" | EXP | [generic] | Give your actual reason, in your own words, and keep it about what you're moving towards | Asked in nearly every screen |

**Bank B: Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with what you did: you handled the branch's formal complaints log. Answer slot: if those complaints carried regulatory rules such as deadlines or required responses, say which applied and what they asked of you. If you don't know, or that part sat with someone else, say so plainly and stay with the log | F7. A listed requirement the recruiter can check in a sentence |
| B2 | "Any contact-centre experience?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then one sentence of plan: what you'd want to learn first and from whom. Stop there; R2 is where you go deeper | F2. JD because the role names the contact centre. A short honest answer here protects you in R2 |
| B3 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built the monthly complaints spreadsheet your regional manager uses. Answer slot: name the tool you built it in and the features you actually used. If it wasn't Excel, say what it was | F9. A requirement a recruiter can tick off in one answer |

**R1 reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Will the escalation case be shared beforehand, or run live, and will someone play the member?" | It's a fair question about the process, and the answer tunes your case prep |
| R1-2 | "What does the Head of Member Services most want this hire to change in the first six months?" | It tells you what R2 will press on |
| R1-3 | "How does the panel's values scoring weigh against the other rounds?" | It tells you how much weight to give section 9 |
| R1-4 | "Where would the role be based through the move to five hubs?" | It's practical, and shows you've read the strategy |
| R1-5 | "What's the timeline after 5 December?" | Plain logistics; recruiters expect it |

---

## 7. Round 2: Head of Member Services (45 min, mostly behavioural)

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gap between one branch and an organisation-wide remit | High. A hiring manager is paying to reduce risk, and F2 and F8 are both gaps you've stated yourself | C1 rehearsed until it's boring: hold what you did, name the limit before it's asked for, give a plan |
| Values / Behavioral | "Tell me about a time…" questions | High. The recruiter said this round is "mostly behavioural" | 90-second stories; "we" for context, "I" for your own part |
| Case / Strategist | Questions on their plans: digital, hubs | Medium. Hiring managers test on their real roadmap | Clarify, structure, think aloud |
| Data-Driven Prober | Asks what's inside the spreadsheet | Medium. F3 and F9 are the only reporting evidence you have | Know exactly what the sheet counts; say plainly what you don't know |

**Bank C: Skeptic and Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've worked in a branch. This role owns complaints across branches and the contact centre, and reports to senior leaders. Why are you ready for that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** *Hold:* six years in retail banking, three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script. *Name the limit before it's asked for:* "I haven't worked in a contact centre, and I haven't presented above regional level." *Plan, said as a plan:* in your first weeks you'd want to sit with the people handling contact-centre complaints and learn how their log works before changing anything. Before your first senior-leader session you'd ask for a dry run with your manager. *Follow-up 1, "So how do you own something you've never seen?":* return to the plan, and stay with what you know about a branch log without stretching it. *Follow-up 2, "Your first senior presentation is in month two":* hold the plan and concede the gap specifically ("it would be my first at that level"). Don't fold, and don't upgrade what you've done | F1, F2 and F8 meet here, so the objection will arrive in some form. JD because it scores the role's stated scope. Deepest rehearsal because the gaps are real and stated, which makes them the easiest place to overclaim under pressure |
| C2 | "Tell me about coaching someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with what the quote says: you trained new tellers on your escalation script. Answer slot: the JD's coaching line makes a probe on how you trained likely. Say how you did it, in your own words. If you also coached anyone more senior, such as fellow supervisors, say who and how. If you didn't, say so plainly and stay with the tellers | F4. The JD asks for supervisors and the quote says tellers, so rehearse saying exactly that |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of your two stated gaps and say it plainly ("I haven't worked in a contact centre"), then a plan for closing it. Don't make up a softer weakness | F2 and F8. A standard Skeptic question, and the honest answer is already in your own words |
| C4 | "Talk me through the monthly complaints spreadsheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote states: you built it, it's monthly, and your regional manager uses it. Answer slots: what it counts (if volumes or resolution times, say how; if something else, say what); which tool and features you used; and whether you chose what went in it or were given a brief. Say plainly where you don't know | F3 and F9. Your only reporting evidence, so expect a prober two levels deep |
| C5 | "How would you present our monthly complaints figures to the executive team?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Structure it: the three numbers that matter, the trend, the one cause, the one decision you need from them, all in plain words. If asked whether you've done this: "I haven't presented above regional level." Answer slot: if you've presented at regional level or below, say to whom and what. If not, say so plainly | F8. Live-problem form of the presenting requirement. CASE delivery, JD content |

**Bank D: Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time the member was right and the process was wrong." | VAL | [grounded] | Pick a time you saw a process fail a member and did something about it. It needs the member's problem, your decision and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Themed from "Members First, Always" and "Own the Fix". The manager will want to hear the values before the panel scores them |
| D2 | "Tell me about a time you delivered unwelcome news to your regional manager." | VAL | [grounded] | Pick a time you told someone senior something they didn't want to hear. It needs the stake, what you said, and how the working relationship came out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, and it tests the composure senior presenting needs (F8) |
| D3 | "Tell me about a hard call you made as a branch supervisor." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Pick a real decision from your three years as supervisor: the situation, the options, what you chose and why, and the result. If none stands out, say so plainly and give the nearest example | F6. EXP because it tests the supervisor title in your own sentence |

**Bank E: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We want 40% of member service on digital channels by 2028, and app-only banks are the pressure. What does that mean for complaints?" | CO | [grounded] | Structure it: complaints data tells digital teams where journeys fail; the risk is members who can't or won't go digital; and the measure is complaints per journey. Answer slot: if you've ever worked with a digital team, say what and how. If not, say so plainly and say how you'd start | Grounded in the strategy brief. F5. CO because it tests whether you can think at the strategy's level |
| E2 | "Suppose resolution times rose sharply last quarter. Diagnose it." | CASE | [generic] | Clarify (which channel, which complaint types, how resolution time is counted), split the problem (volume up, capacity down, or more complex cases), then say what data you'd pull and who you'd talk to | A hypothetical, not a claim about Ashgrove. It tests the reporting requirement as reasoning (F3) |
| E3 | "What would you do in your first 90 days?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Listen, then map, then a first fix: sit in branches and the contact centre, learn the current complaints log and report, then make one visible improvement. Build the contact-centre learning in openly, as part of the plan | Common manager question. It's the natural place to show the F2 plan as a strength |

**R2 reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would make you say, a year from now, that this hire worked?" | It tells you the real scorecard |
| R2-2 | "How do branch and contact-centre complaints join up today, and where do they fall between the two?" | It shows you're thinking end to end, and it's the part you'd need to learn first |
| R2-3 | "Who presents complaints reporting to senior leaders now, and how would you want this role to take that on?" | It addresses F8 directly, without apologising for it |
| R2-4 | "How will the move to five hubs change who owns a complaint?" | It ties the strategy to the job |
| R2-5 | "Will small-business lending complaints come under this role from launch?" | It shows you've read the Q1 2027 plan |

---

## 8. Round 3: panel of two branch managers (60 min, including the 20-minute case)

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value, scored | High. The recruiter said the panel "score against the four values" | One 90-second story per value (section 9) |
| Peer Evaluator | "You'd be coaching my supervisors, so what do you need from me?" | High. Branch managers are the people whose teams this role coaches | Offer something to them before asking; propose principles for how you'd split responsibilities, without claiming to know the current split |
| Case / Strategist | The 20-minute escalation case | Certain, because the recruiter announced it | Section 4 |
| Skeptic | "Why should managers take coaching from a supervisor?" | Medium. It's the natural objection from people more senior than your current role | Hold, then concede (K1) |

**Bank H: Values / Behavioral** (stories in section 9)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Section 9, Members First. A selection scaffold that ends in its honest branch | The value's own words; it will be scored |
| H2 | "When have you made something simpler so a member understood it first time?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Section 9, Plain Words. Answer slot: if training new tellers on your escalation script meant putting it in plainer words, say how. If not, say so plainly and pick another time from the scaffold | "Plain Words", scored. F4 is the nearest quote |
| H3 | "Tell me about a time you treated a branch as part of its town." | VAL | [grounded] | Section 9, Neighbours, Not Numbers. A selection scaffold that ends in its honest branch | "Neighbours, Not Numbers", scored; it sharpens as the hubs arrive |
| H4 | "Tell me about a problem you found and kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Section 9, Own the Fix: built, monthly, used by your regional manager. Answer slot: if you built it because you found a problem, say what the problem was and how you kept hold of it. If it was asked of you, say so plainly and describe what it does and who relies on it | "Own the Fix", scored. F3 is the only quote that shows you building something that's still in use |

**Bank J: Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching my supervisors on escalations. What would you need from me, and what happens when we disagree on a case?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | First what you'd bring them: fewer escalations reaching them and a clear route for the ones that do. Then what you'd need: time with their supervisors, and a say on what counts as an escalation. On disagreement: the member's outcome decides, and you'd talk it through with the manager directly before going round them. If asked about your experience, say only the quote's words: you trained new tellers on your escalation script | F4. Peers price what the hire costs and adds to their own work |
| J2 | "Two of our branches become one hub next year. How do you keep complaint handling local?" | CO | [grounded] | Clarify what changes for members (distance, opening hours, the staff they know), then the risks (more complaints, members who won't go digital), then the moves: local escalation contacts, and tracking complaints by town so the hub change is visible in the monthly report | The hubs plan plus "Neighbours, Not Numbers". These managers will be living through it |
| J3 | "How would you get busy branch staff to log every complaint properly?" | CASE | [generic] | Keep it simple: a form short enough to fill in at the counter, a clear rule on what counts as a complaint, and branches shown their own figures back each month so logging feels useful. Ask how they log today before proposing anything | Owning the process end to end (F1) only works if branches log complaints, so it's a live problem |

**Bank K: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You're a branch supervisor. Why would branch managers take coaching on escalations from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold: your three years as a supervisor are spent where escalations start, and you trained new tellers on your escalation script. Concede: managing a branch is a level you haven't held, so you'd coach supervisors, not managers, and you'd earn their trust branch by branch. Don't fold, and don't upgrade the title | F4 and F6. The panel sits a level above your current role |
| K2 | "We're consolidating branches and members are angry. Are you the person who defends that?" | VAL | [grounded] | Hold: your job is to make the member's experience of the change as good as it can be, not to defend the decision. Concede: some members will still be unhappy, and saying so plainly is part of the job. Bring in Plain Words and Neighbours, Not Numbers by name | Pressure form of the hubs plan, tested against the values |

**R3 reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What could I do in my first month that would genuinely help your branches?" | Reciprocity: peers weight what you bring them |
| R3-2 | "Which complaints reach you as managers that shouldn't have to?" | It shows you'd lighten their load |
| R3-3 | "How have the hub plans landed with your teams and your towns?" | It's "Neighbours, Not Numbers" turned into a question |
| R3-4 | "What does a good escalation look like from your side?" | It gives you their definition before you coach to it |
| R3-5 | "When a fix needs both a branch and this role, who keeps hold of it?" | "Own the Fix", asked rather than recited |

---

## 9. Values cheat sheet (R3; scored)

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions get made from the member's point of view, not the organisation's | Selection scaffold: pick a time a member's problem reached you and you chose what they needed over the easier path. It needs the member's problem, your decision and the result for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script."), or how you would handle it |
| Plain Words | If something needs explaining twice, the wording is the problem, not the member | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if that training meant turning the script into plainer words, say how. If not, say so plainly and pick a time you made something simpler for a member or colleague. If none comes to mind, say how you would handle it |
| Neighbours, Not Numbers | Each branch belongs to its town, and members aren't a statistic | Selection scaffold: pick a time you dealt with a member or a branch issue as part of the local community rather than as a case number. It needs the local context, what you did and what it meant for them. If no such time comes to mind, say so plainly, then say how you would handle it, through the hubs change (J2) |
| Own the Fix | Whoever spots a problem stays responsible for it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Beats: you built it, it's monthly, your regional manager uses it. Answer slot: if you built it because you found a problem, say what and how you kept hold of it. If it was asked of you, say so plainly and describe what it does and who relies on it |

---

## 10. Prohibited claims

What this pack won't coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, end to end or across branches | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material shows one branch's log, not a process. Answer slots stay inside that log |
| Has worked in, or handled complaints for, a contact centre | A negative you stated (F2) | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated (F8) | "I haven't presented above regional level." No slot |
| Presented or reported complaints figures to the region | Inflated form of F3 | F3's quote: you built the spreadsheet your regional manager uses. The pack's observation: someone using it isn't the same as you presenting it |
| Coached supervisors, or wrote the escalation script | Inflated form of F4 | F4's quote: you trained new tellers on your escalation script. The slot asks only how you trained people on it, and whether you shaped it |
| Has handled regulated complaints, stated as regulatory expertise | Inflated form of F7 | F7's quote: the branch's formal complaints log. The slot asks only which rules applied to it |

---

## 11. Sources

**Provided documents:** the JD text; the values text you copied from ashgrovecu.org/about/values on 26 November 2026; the recruiter's email; your summary of Ashgrove's July 2026 strategy brief; your background note. No dossier was present.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted already supplies all four values by name and wording for section 9 and bank H |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email sets out all three rounds, who runs each one, the case and the values scoring. That fixes the loop structure and persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your summary of the July 2026 brief, under six months old, supplies the priorities and competition behind E1, J2 and K2 |
| 4. Interviewer names | n/a | No names have been assigned, so there was nothing to search for. The interviewer read is absent; see the upgrade menu |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD, so it sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Interviewer names, once assigned → a section on reading each interviewer, persona weights per panel member, and one reverse question per round tied to that person's own career
- The case format from the recruiter (whether it's shared beforehand, what materials you'll get, whether someone plays the member) → section 4 tuned to the real format
- The strategy brief's full text rather than your summary → exact figures and Ashgrove's own wording in section 5; sharper E1, J2 and K2
- Your real answers to the answer slots on F1, F3, F5, F7 and F9 → those rows rebuilt from your words. For example, if the spreadsheet tracks resolution times, F3 closes and C4 becomes a mapped story
- Your CV text → evidence beyond your four sentences, quoted line by line, which could turn scaffolds in D1–D3 and section 9 into mapped stories
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → Ashgrove's public complaints reporting and any coverage of the hub plans, feeding the CO questions
- Hours of prep available per day → a day-by-day schedule sized to them
- A tuesday-dossier.md from an earlier evaluation of this role → an evidence-graded main objection and a prohibited-claims list carried in, rather than built here
