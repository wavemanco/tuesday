# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** Friday 27 November 2026 (tomorrow), 60 minutes
**Interviewer:** Tobias Wrenfield, Head of Live Operations. This pack treats him as the hiring manager, because Saltmarsh's interviewing page says the 60-minute interview is "with the hiring manager". That is an inference: confirm it if you can.
**Format, from Saltmarsh's interviewing page:** "the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

Two axes. **Personas** describe how a question arrives (who is asking, in what style). **Types** describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values, not generic virtue |
| EXP | Whether your experience holds up under scrutiny, and how precisely you say what was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current direction and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your message, the JD, or research listed in Sources. `[inferred]` is this pack's derivation, with the derivation named. `[generic]` is a role-family pattern that makes no claim about you or Saltmarsh.

**Answer slots** mark places where a strong answer needs a fact your material doesn't give. They are instructions for the interview, not blanks for me to fill. Each slot has two honest branches, and "that wasn't mine" or "we didn't do that" is a full answer.

Guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage: tonight

The interview is tomorrow, so this assumes one evening of about two and a half hours. In order:

1. **Run the tabletop out loud (45 min).** A1, A2 and A3 back to back, with a timer. The format page puts the tabletop first, and it is a live performance, so reading about it doesn't count. Then E2, once.
2. **Rehearse the highest-ROI objection (25 min).** C1, through both follow-ups, until the hold and the concession come out plainly.
3. **Write your answer-slot answers (25 min).** For fit rows F1, F2, F3 and F5, write two lines each in your own words: what was yours, and what wasn't. These are the facts the interview will dig for.
4. **Values conversation (30 min).** Learn the three value names from section 10 word for word, then do B1, B2 and B3 aloud.
5. **Pick three reverse questions (10 min).** From section 11, with R1 first.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows a weekly content-drop calendar for your main title. It doesn't show a live-events calendar, or more than one title. Keep the words at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on what a drop involved likely. If any drops were time-limited events, say which and what running them involved, in your own words. If they weren't events, say so plainly and stay with the calendar you ran. Present a second title as a plan, never as a past |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The JD says coordinate, not manage. Your material doesn't show which teams the calendar involved. If you're asked about line management, the words are yours: "I haven't led a team." Answer slot: if running the calendar meant working with design, art, engineering or community on a drop, say which teams and what you did with them, in your own words. If it didn't, say so plainly and describe how you would set up that coordination here |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning an event review, and isn't the same thing. Keep the words at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared those numbers or decided what they meant, say which part was yours. If someone else built them, say so plainly and stay with the presenting. The review itself is a plan, said as a plan |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. It's a single line with nothing behind it that anyone has inspected, so expect a close probe on it (see section 7). Lead with it in its own terms: you wrote it, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material shows four years producing. It doesn't show whether the game counted as live-service. Answer slot: if the title ran ongoing updates and live content, say what made it live, in your own words. If it wasn't a live-service game, say so plainly and stay with the weekly content-drop calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote as it stands: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect a prober to ask which numbers they were and how they were counted (D1). Lead with the quote. What sits behind it is an answer slot, not something this pack supplies |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already shows written work that others rely on. Say it in those terms and add nothing: "I wrote the release checklist our QA team still uses — it's a document other people work from." |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A4, C1, B1 |
| Coordinate design, art, engineering and community teams (F2) | C3, H1, A1 |
| Own the post-event review and its KPIs (F3) | A3, A5, C1 |
| Manage the release checklist with QA (F4) | A2, D2, D3, H2 |
| 3+ years producing live-service games or apps (F5) | C4, G1 |
| Experience running a content calendar (F6) | C1, G1 |
| Comfortable with player-retention metrics (F7) | A5, D1 |
| Clear written communication (F8) | E2, A3 |

---

## Reading the interviewer

Public professional footprint only. It comes from one search result, a GDC 2026 talk listing (Sources).

- **Career pattern:** the listing describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, "previously a QA lead at a console studio."
- **Published theme:** the talk is titled "Patch Notes Are a Promise". The listing sums up its argument as "a live team is judged by how often its patch notes describe what actually shipped."
- **Practical implications:**
  1. Expect release-quality questions to go deep. Someone with a QA background will probe what is actually on a checklist (D2) and how notes get checked against a build (D3).
  2. In the tabletop, player communication will probably be scored on accuracy. Say what is known and what is being done. Don't give an ETA you can't stand behind (A1, E2). This matches Saltmarsh's published value "Ship the Patch Not the Promise".
  3. The talk is an easy reverse question (R1), and it shows you prepared for him as well as for the company.
- **Shared vocabulary:** his QA background pairs with F4, "Wrote the release checklist our QA team still uses." It's the most direct overlap between your material and his path, so lead the checklist discussion with it.

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop, plus planning questions on Larkspur's shared calendar | Highest. The hiring-manager prior puts it first, and the interviewing page says the hour opens with "a live-incident tabletop on a simulated outage during a live event" | Clarify, stabilise, communicate, decide, record. Think out loud, and challenge one premise respectfully |
| Values / Behavioral | The second half of the hour, on Saltmarsh's three published values | High. The same page names "a values conversation", and Saltmarsh's values page lists three values by name | Use each value's official name. Map a story where one of your quoted sentences carries it, and give the honest branch where none does |
| Skeptic | Gaps against the JD: scope of ownership, coordination, live-service, monetisation | Medium. The hiring-manager prior includes it, and F1, F2, F3 and F5 are where your material is thinnest | Rehearse C1 until it's boring. Stay inside your quotes, say limits plainly, and offer a ramp plan |
| Data-Driven Prober | Close questions on the checklist, the retention numbers and patch-note accuracy | Medium. His published theme and his QA background point here (section 7) | Know what you can and can't say about how your retention numbers were counted. Say "I don't know" where that's true |
| Pressure / Stress | Time pressure and interruptions inside the tabletop | Low to medium. A simulated outage is time pressure by design. The page gives no further sign of it | Pause, restate the question, hold through two follow-ups, and concede specifically |
| Conversational / Rapport | Opener and "why here" | Low. Probably the first few minutes before the tabletop | Use a 90-second arc built only from your quotes. Treat casual questions as scored |
| Peer Evaluator | Cross-team seams the JD names: design, art, engineering, community, QA | Low. There is no peer round, but the JD's coordination line brings this style into the manager's questions | Propose principles for the seam, and frame what you bring other teams |

---

## Question banks

Question IDs go by persona: A to E, then G and H. F is kept for fit-snapshot rows.

### A. Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's hour 30 of a 72-hour event and players can't log in. Talk me through your first 30 minutes." | CASE | [generic] | Clarify first: which title, all players or a segment, which platforms, since when. Stabilise: who is on call in engineering, whether a rollback exists, who owns the decision. Communicate: get community a holding message that says what is known, what is being done and when the next update comes, with no fix time unless engineering has one. Decide on the event: pause or extend the timer, and when to decide. Record: start a timeline for the post-event review. Say these steps out loud before you go into them | The tabletop format comes from the interviewing page (Sources). The scenario here is a pattern for rehearsal and makes no claim about Saltmarsh's systems. It's CASE because it scores structure under a live problem |
| A2 | "Engineering has a hotfix in two hours, but QA hasn't run the full release checklist. Do you ship it?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Name the trade-off: players locked out against the risk of a second break. Propose agreeing with QA on which checks are essential for this fix, and saying who signs off. Say what players will be told, and when. You can anchor in F4 at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: if that checklist separated must-run checks from the rest, say how in your own words. If it didn't, say so plainly and describe how you'd make the cut here | This is where the JD's checklist line meets the tabletop, and the interviewer's QA background makes it likely. CASE first, JD second |
| A3 | "It's fixed. Players lost most of a day of a limited-time event. What do you do for them, and what goes in the patch notes?" | CASE | [generic] | Separate the two decisions: making it right for players (extending the event, restoring progress, compensation), and the notes. Notes say what happened at the level players need, what was fixed and what players get, and nothing that hasn't shipped. Then name what the post-event review will record: timeline, impact, cause, actions. Use the value names where they fit: "Players Before Plans" for the event decision, "Ship the Patch Not the Promise" for the notes | Covers the JD's post-event review line and his published patch-notes theme. CASE, delivered as a judgment call with written output |
| A4 | "From February, Larkspur moves Tidepool Tactics and Lantern Row to a season pass with one shared events calendar. How would you plan the first month?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Clarify: season length, how much the two audiences overlap, the shared team's capacity. Principles: avoid collisions between the titles, stagger the big beats, build in buffer for incidents, and tie each beat to a measure the review will report. Risks: a single team stretched across two titles, and launch-week load. If it moves into pass pricing or monetisation, say it plainly: "I haven't worked on a game with in-app purchases." Then say what you would want to learn first, as a plan | Larkspur is Saltmarsh's own September 2026 announcement (Sources), so this is the question most grounded in current strategy. CASE with CO content. Provenance carries the one sentence the guidance gives you to say |
| A5 | "An event's retention came in below the previous one. Diagnose it." | CASE | [generic] | Clarify: which measure, which cohort, compared with what, and whether the gap is bigger than normal noise. Segment: new or returning players, platform, region. Look for what changed: event design, timing, a competing release, an outage, the store. Say which check you'd run first and why, then what you would do with each likely answer | Covers the JD's retention and KPI lines as a live problem. CASE |

### B. Values / Behavioral

Saltmarsh's values page lists three values. Their names are in section 10.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | This is "Players Before Plans". Pick a time from the calendar you ran when what was planned and what players needed pulled apart. It needs a planned item, a player signal, and a choice about which one won. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own wording, "when the calendar and the players disagree, the players win", makes this question very likely. F1 is where such a story would come from, so it's a selection scaffold and not a story this pack supplies |
| B2 | "When have you held back an announcement because the work wasn't built yet?" | VAL | [generic] | This is "Ship the Patch Not the Promise". Pick a time something was ready to announce before it was ready to ship. It needs the pull to announce, what you did, and what players were told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is "we announce what is built, not what is hoped", and it matches the interviewer's published theme. Your material carries no such story, so the guidance is a scaffold |
| B3 | "Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | This is "Leave the Build Greener". Map it to F4: you wrote the release checklist, and your QA team still uses it. Those are the beats. Answer slot: the value names "the checklist", so expect a probe on what came before yours. If you replaced an earlier one, say what changed, in your own words. If there wasn't one, say so plainly and stay with writing it and its continued use | The value's text says every release leaves "the codebase and the checklist better than it found them". This is the strongest value match your material has |
| B4 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if any of those monthly presentations carried bad news, say what it was and how you delivered it, in your own words. If none did, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values question. F3 is the place in your material where you spoke to leadership, so it's the natural place to look |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the content-drop calendar for your studio's main title as an associate producer. This role runs live events across two titles and owns the post-event review. What have you owned yourself?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** Hold only what the quotes carry: "For the last two years I ran the weekly content-drop calendar for our main title. I wrote the release checklist our QA team still uses, and I presented the monthly retention numbers to the studio head." Answer slot: if decisions on that calendar were yours to make, such as what went in, when, or what moved, say which, in your own words. If they weren't, say so plainly and describe how you ran it. On two titles and the review, your material shows neither. If asked, answer the slot: if you have worked across more than one title or run a review, say how; if not, say so plainly and give your plan for the first month. Follow-up 1, "So who decided?": return to the calendar you ran and the slot answer, and add nothing. Follow-up 2, "How is a content drop different from a live event?": F1's slot. Concede the specific limit, and don't fold on the two years | F1 and F3 are where the JD presses hardest on your material, so this objection will come in some form. JD because it scores the stated responsibilities |
| C2 | "Larkspur puts both titles on a season pass. Have you worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it first and plainly: "I haven't worked on a game with in-app purchases." Then give a plan for learning it, said as a plan: what you'd read, who you'd sit with, what you'd want to understand about the pass before planning around it. Then say what you do bring, at its scope: "I presented the monthly retention numbers to the studio head." Don't say retention work is the same as monetisation | You stated this negative yourself, and Larkspur makes it visible. Saying it before you're pushed is the credibility move. The JD doesn't list it, so the tag reflects the role's terms as Larkspur sets them |
| C3 | "Have you managed people? This role coordinates design, art, engineering and community." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | "I haven't led a team." Then F2's answer slot: if the calendar meant working with design, art, engineering or community on a drop, say which teams and what you did with them, in your own words. If it didn't, say so plainly and describe how you'd run coordination here: one owner per update, a shared calendar view, and a fixed point where each team signs off | Tests the JD's coordination line, which is F2. The JD says "coordinate", so a plain answer on leading costs little if the coordination answer is ready |
| C4 | "Was your puzzle game a live-service game? What made it one?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if the title ran ongoing updates and live content, say what made it live, in your own words. If it wasn't a live-service game, say so plainly and stay with the weekly content-drop calendar you ran | F5's requirement is literal ("live-service games or apps"), and your material doesn't settle it. `[inferred]` because the gap is this pack's reading |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Which numbers were they, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the measures in your own words, and say how they were counted if you know. If you built them, say how. If someone else did, say who and what your part was. "I don't know exactly how that was counted" is an honest answer. Then name the assumption behind them you'd defend least, before he asks | F7 and F3 rest on this sentence, and a prober will test it. EXP because it scores what was yours |
| D2 | "Walk me through your release checklist. What's on it, and why?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: give its sections and the reason for each, in your own words. Pick the one item you'd defend hardest and the one you'd change today. Then return to the fact the quote carries: your QA team still uses it | F4 is your strongest row, and his QA background makes a close look at it likely (section 7). It's EXP and premised only on the quote |
| D3 | "How would you know whether the patch notes matched what actually shipped?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure: a step where the notes are checked against the build before release, someone named who signs off, and a check after release against player reports. Answer slot: if your checklist had a step like that, say how it worked, in your own words. If it didn't, say so plainly and propose where it would go | This is his published theme, asked as a live problem. CASE, and it covers the JD's checklist line |

### E. Pressure / Stress (inside the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause, then hold on what you did: "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." Concede the specific gap: "I haven't worked on a game with in-app purchases." Close with what you'd do first in the role. Don't argue that monetisation doesn't matter | A predictable stress version of C2. Hold, then concede |
| E2 | "Community needs a message right now. Give me the exact words." | CASE | [generic] | Say it as you'd post it, in two or three sentences: what players are seeing, that the team is working on it, and when the next update will come. No cause guessed, no fix time promised. Then one line on who approves it | Tests the JD's written-communication line under time pressure, and "Ship the Patch Not the Promise" in a single message |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of these four sentences, in this order: the four years, the calendar, the checklist, the retention numbers. End on why live ops (G2). Add no titles, team sizes or results | Casual register, but it's scored. It sets up F5 and F6 before the tabletop |
| G2 | "Why live ops, and why Saltmarsh now?" | CO | [generic] | Answer slot: give your real reason for moving into this role, in your own words. For "why now", you can refer to Larkspur as public news: one shared events calendar across two titles from February 2027. Say what draws you to it without claiming you know how it will run | Motivation is scored casually. CO because Larkspur is the current context (Sources) |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Engineering says an event feature won't make its calendar date. Art is finished, and community has already teased it. What do you do?" | CASE | [generic] | Clarify: how late, and whether a reduced version can ship on the date. Options: move the date, ship the smaller version, or swap the slot. Tell community first, in words that describe what will actually ship. Keep art's work for the new date. Say who makes the final call | The JD's four-team coordination line, set as a seam problem. Ties to "Ship the Patch Not the Promise" |
| H2 | "Tell me about a time you disagreed with QA about whether a build was ready." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Pick a time from your work with QA when you and they read readiness differently. It needs the disagreement, how it was settled, and the working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's "with QA" line raises it. F4 shows you worked with QA, so that's where to look for the story |

---

## Values cheat sheet

The names and wording come from Saltmarsh's values page (Sources). Learn the names exactly.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | If the schedule and what players need conflict, players come first | F1, "I ran the weekly content-drop calendar for our main title for the last two years.", is where to look. Selection scaffold: a planned item, a player signal, and a choice about which won. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B1) |
| Ship the Patch Not the Promise | Announce only what is already built | No quoted sentence carries this. Selection scaffold: the pull to announce early, what you did, and what players were told. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B2) |
| Leave the Build Greener | Each release should leave the code and the checklist better than before | F4, "Wrote the release checklist our QA team still uses." Answer slot on what came before it (B3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How does the team track that today?" | It's tied to his published work and shows you prepared for him specifically. The answer also tells you how your releases will be judged |
| R2 | "You moved into live ops from QA. What did that teach you about where releases go wrong?" | It's tied to his career path, invites a conversation between equals, and connects to your checklist (F4) |
| R3 | "With Larkspur bringing the per-title event teams into one live-ops group, what changes for this role in February?" | It shows you know the current strategy, and it tells you what the job will become |
| R4 | "What does the post-event review look like now, and which KPIs does it report?" | You'd own this. The answer shows how much you'd be inheriting and how much you'd be building |
| R5 | "What would a strong first 90 days look like for the person in this role?" | It gets you his success criteria in his own words |
| R6 | "Where does the Outage Hour tabletop come from? Is it modelled on what the team actually faces?" | It's a process question with a prep payoff: his answer shows you which incidents matter most to the team |

---

## Prohibited claims

This pack won't coach these claims. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led or managed a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | "I haven't led a team." C3's coordination slot stays about coordinating |
| Has worked on a game with in-app purchases, a season pass or monetisation | Negative you stated, same sentence | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material says a weekly content-drop calendar, not live events. F1's slot asks only whether any drops were events |
| Ran the calendar across several titles | Inflated form of F1 | F1's quote at its own scope: "our main title". The limit is this pack's observation, and C1's slot handles it |
| Owned the post-event review or its KPIs | Inflated form of F3 | F3's quote at its own scope: presented the monthly retention numbers to the studio head. The limit is this pack's observation. D1's slot asks only which part of those numbers was yours |
| Produced a live-service game | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer at a puzzle-game studio. C4's slot asks only what made the title live, if it was |

---

## Sources

**Provided:** your message (the JD text and your background).

**Searches sent:**
1. `Saltmarsh Games values`: returned https://saltmarshgames.com/values
2. `Saltmarsh Games interview process producer`: returned https://saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news`: returned https://saltmarshgames.com/news/project-larkspur (September 2026: "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group.")
4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (the talk listing; the talk itself was not read)

**Fetches:**
1. https://saltmarshgames.com/values: the three values and their definitions
2. https://saltmarshgames.com/careers/interviewing: the Outage Hour format

No dossier was present. Everything here was built from your message and the research above.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet (section 10) and bank B: three values by official name |
| 2. `Saltmarsh Games interview process producer` | yes | Format confirmed as the Outage Hour: tabletop then values conversation with the hiring manager. Sets the persona weights and bank A |
| 3. `Saltmarsh Games` recent news | yes | Larkspur: A4, C2, G2, R3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read (section 7), D2 and D3, R1 and R2 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your two-line answers to the answer slots on F1, F2, F3 and F5** (calendar decisions that were yours, which teams you worked with, whether drops were events, whether the title was live-service) → those rows' bridges become stories built on your own words, and C1, C3, C4 and B1 get firmer guidance
- **Your CV text** → evidence quoted from your actual lines, which may raise the confidence on F2 and F5 and give D1 and G1 more to stand on
- **A copy of the release checklist you're free to share** → the one artifact that can be inspected in this field. It would raise F4 and F8 from `medium` to `high`
- **Any note from the recruiter about Friday** → confirms Tobias is the hiring manager and that the Outage Hour format applies, or reweights the personas if not
- **A tuesday-dossier.md** → would carry verified evidence and a named top objection into this pack, instead of the ones inferred here
