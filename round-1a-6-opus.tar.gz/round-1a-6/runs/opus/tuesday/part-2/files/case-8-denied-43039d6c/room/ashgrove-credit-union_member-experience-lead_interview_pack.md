# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date:** 5 December 2026, three rounds on the same day (loop mode)

| Round | Length | Who | What the recruiter said it holds |
|---|---|---|---|
| R1 | 30 min | Recruiter | Screen |
| R2 | 45 min | Head of Member Services, your future manager | "mostly behavioural" |
| R3 | 60 min | Panel of two branch managers | A 20-minute complaint escalation case; "the values round", scored against the four values |

Interviewers' names haven't been assigned yet, so the pack has no section on reading individual interviewers.

---

## How to use this pack

**Personas** describe *how* a question gets asked. **Types** describe *what is being scored*:

- **VAL**: whether your past behaviour shows Ashgrove's four published values
- **EXP**: whether what you say about your past holds up under follow-ups, and what was actually yours
- **JD**: whether you can do the job as listed, gaps included
- **CO**: whether you know Ashgrove's strategy and can think at that level
- **CASE**: a live problem from the role, worked through in the room

Provenance labels: **[grounded]** traces to something you or the recruiter gave me. **[inferred]** is my own reading of that material. **[generic]** is a pattern for roles like this, with no claim about Ashgrove.

The guidance gives you a structure to work from, not lines to memorise. Where a cell says **Answer slot**, the material doesn't show the answer. Give the true answer in your own words, and use the second branch if that's the true one.

---

## Shared: Fit snapshot

Your four sentences, from your message, are the only evidence used anywhere in this pack:

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material covers one branch's formal complaints log. It doesn't cover a process across branches, so keep the words at that scope: "I handled the branch's formal complaints log." Answer slot: "end to end" makes it likely you'll be asked what happened to a complaint after it went on the log. If you dealt with complaints through to an outcome yourself, say how in your own words. If your part was keeping the log, say so plainly and describe what the log recorded |
| F2 | "…and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap and wording can't close it. Words: "I haven't worked in a contact centre." Then give a learning plan, said as a plan and never as past experience. Add nothing that makes the gap sound smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material shows a monthly complaints spreadsheet. It doesn't show whether it tracks volumes or resolution times. Answer slot: if it tracks either, say which and how they're counted, in your own words. If it doesn't, say what it does track and stay with "I built it, and our regional manager uses it" |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material covers training new tellers on the branch's escalation script, not coaching supervisors. It also shows you've been a branch supervisor for three years. Say both at their own scope: "For the last three years I've been a branch supervisor, and I trained new tellers on our escalation script." Answer slot: if any part of the script was yours to write or change, say which. If not, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if you've worked with a digital or online-banking team on anything, say what and what your part was. If you haven't, say so plainly and say how you'd start working with that team (see B9) |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Expect a probe because there's no CV line behind it. Say it in your own terms ("six years in retail banking, the last three as a branch supervisor") and let the interviewer match it to the requirement |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" doesn't show "regulated", and handling the log doesn't show handling the complaints. Answer slot: if the complaints on that log came under a regulator's complaint-handling rules, name the rules and say what they meant for your part. If they didn't, or you're not sure, say so plainly and describe what the log recorded |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap. Words: "I haven't presented above regional level." Answer slot: if you have presented at regional level, say what you presented and to whom, in your own words. If you haven't, say so plainly. Then give a plan for building this up, said as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material doesn't say which tool the spreadsheet is in. Answer slot: if it's Excel, say so and describe what you built in it, in your own words. If it isn't, or you're not sure, name the tool you used |

**Requirement coverage:**

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches (F1) | A1, B1, B2, C6, Case build |
| …and the contact centre (F2) | A8, B1 |
| Monthly reporting on volumes and resolution times (F3) | B3, B4 |
| Coach branch supervisors on escalations (F4) | B5, B6, C6, C9 |
| Digital teams and self-service journeys (F5) | B9, C7 |
| 4+ years in FS customer operations (F6) | A1 |
| Regulated complaints (F7) | A7, Case build |
| Presenting to senior leaders (F8) | A10, B7 |
| Excel reporting (F9) | A9, B3 |

---

## Shared: Grounding brief, from the July 2026 strategy brief the recruiter sent

| Fact | Provenance | Where it shows up |
|---|---|---|
| Ashgrove plans to move 40% of member service to digital channels by 2028 | [grounded] | B9, C7. Complaints will start and travel through the app and website as well as branches |
| It will consolidate eight branches into five hubs over 2027 | [grounded] | C3, C7. The panel are branch managers living through this, so it bears directly on "Neighbours, Not Numbers" |
| It plans to launch a small-business lending product in Q1 2027 | [grounded] | Reverse questions. A new product brings a new type of complaint |
| The main competitive pressure is app-only banks | [grounded] | A2, B9. Being member-owned and having branches in towns is what an app-only bank can't copy |

Use these as vocabulary, not a speech. One accurate reference per round is enough.

---

## Shared: Graded deliverable: the 20-minute complaint escalation case (R3)

The recruiter announced it, so treat it as graded. The content of the case isn't known yet. What follows is a structure, not an answer.

**Facts you can build on:** F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." F4, "6 years in retail banking, the last 3 as a branch supervisor." Use them to say where you're coming from, not as proof.

**Structure (about 3 minutes clarifying, 12 working through, 5 closing):**

1. **Clarify first.** Who is the member, what happened, what have they already been told, who holds the complaint now, and what deadline applies? Ask which complaint-handling rules and timeframes Ashgrove works to. Don't assume them. (Panels like this usually reward clarifying before solving.) [generic]
2. **Start from the member's side of the counter.** What does the member need today, separate from what the process needs?
3. **Contain it.** What you'd do in the next 24 hours, and who you'd tell.
4. **Name one owner.** Say who keeps hold of the complaint until it's solved, and that a handover doesn't end the ownership.
5. **Tell the member in plain words.** Script one sentence you'd actually say to them.
6. **Fix the cause, not just the case.** Ask whether this is a one-off or a pattern, and how it would show up in the monthly volumes and resolution times.
7. **Coach the supervisor.** What you'd talk through with the branch supervisor who escalated it, so the next one goes better.

**Three theses you can defend, each with its concession:**

| Thesis | Concession you say out loud |
|---|---|
| One named person should own an escalated complaint to resolution, across branch and contact centre | Ownership can slow things down if that person is off or overloaded, so it needs a named cover |
| The first fix is for the member. The process fix comes after, but it comes | Some fixes cost money or set precedent, which is a senior call and not mine alone |
| Every escalation should teach the branch something, through coaching and through the monthly report | Not every escalation is a failure. Some members escalate however well the branch did, and the coaching shouldn't punish the supervisor for that |

**How to stand out:** a typical answer is "apologise, escalate, resolve". Go further: say who keeps hold of the complaint, what the member is told in one plain sentence, and how this case feeds the monthly figures and the supervisor's coaching. **Saying no well:** if the facts don't support the member's complaint, say how you'd tell them so in plain words, and what you'd still do for them.

**Close:** no specific close was named. End on what the member experiences and on one thing the branch learns. Let the values show in your decisions rather than naming them.

---

## Round 1: Recruiter screen (30 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through…" | High. This is the usual recruiter-screen register | Have a 90-second background arc ready. Treat casual questions as scored |
| Skeptic (light) | Quick checks against the JD's requirements | Medium. Recruiters screen against the requirements list, and F2, F7 and F8 are visible gaps | Give short, plain answers. Name the gap before they do |
| Values / Behavioural | One "why us" or values check | Low. The values round is R3 | One genuine sentence linking Ashgrove's values to why you're applying |

### Question bank R1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, in this order: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. End on why member experience is the next step, in your own words | F6, F1 and F3 give the arc. EXP because the recruiter is checking that it holds together |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Give one reason from the values ("Members First, Always" or "Own the Fix") and one from the strategy brief (the move to digital, or the pressure from app-only banks). Answer slot: give your real reason for wanting this. If it's mainly the step up, say so plainly | Motivation checks are standard in a screen. CO because quoting the published values and strategy accurately shows you've done the homework |
| A3 | "Why are you looking to move on?" | EXP | [grounded] | Logistics slot: give your actual reason in your own words. Keep it forward-looking and add nothing you wouldn't stand behind | Reason for leaving is one of the four recruiter logistics questions. EXP because it asks about your own history |
| A4 | "What salary are you looking for?" | JD | [grounded] | Logistics slot: either give your own number or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a standard screen item. JD because it's about the terms of the job |
| A5 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period | Screens check start dates |
| A6 | "Where are you based, and does the role's location and travel between branches work for you?" | JD | [grounded] | Logistics slot: give your actual location and what travel you can do, in your own words | The JD spans branches and the contact centre, so a recruiter will check location and travel |
| A7 | "The role needs experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I handled the branch's formal complaints log." Answer slot: if those complaints came under a regulator's complaint-handling rules, name them. If not, or you're not sure, say so plainly and say what the log recorded. Don't upgrade "the log" to "the complaints" unless you dealt with them yourself | F7 is a requirement the recruiter can tick or not. JD because it scores a stated requirement |
| A8 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "No, I haven't worked in a contact centre." Then one sentence on how you'd learn it, said as a plan, and move on. Don't pad it | F2 is the most visible gap against the JD, so expect a direct question. A short honest answer here protects R2 |
| A9 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it's in Excel, say so and describe what you did in it. If not, name the tool | F9 is a listed requirement that's easy to check. JD |
| A10 | "This is a step up. What's the biggest stretch for you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one honest stretch: "I haven't presented above regional level." Follow it with a plan, said as a plan. Choosing your own gap shows self-awareness and costs you nothing, because they'd find it anyway | A light Skeptic check that previews B1. JD because it's measured against the role's requirements |

### Reverse questions for R1

| Question | Why it lands |
|---|---|
| "What will the Head of Member Services most want to hear about in my round?" | It's a fair question for a recruiter and helps you prepare for R2 |
| "Can you tell me anything about the format of the 20-minute case: written brief, role-play, or discussion?" | Shows you're preparing for it properly, and the answer shapes how you use the case build |
| "Is this a new role or a backfill?" | Tells you whether you'd be building the complaints process or inheriting one |
| "How is the role split between branches and the contact centre?" | Tells you how much F2 will matter in day-to-day work |
| "What's the timeline after 5 December?" | Practical, and it marks you as serious |

---

## Round 2: Head of Member Services, your future manager (45 min, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps between one branch and the whole process | High. A hiring manager is reducing risk, and F1, F2 and F8 are where the risk is | Rehearse B1 until it's boring. Name each limit before you're asked |
| Values / Behavioural | "Tell me about a time…" | High. The recruiter said "mostly behavioural" | Use real stories, "we" for context and "I" for your part. Use the honest branch where no story exists |
| Data-Driven Prober | Questions about the spreadsheet | Medium. F3 is your clearest artifact, so a manager who'll own the monthly report will dig into it | Know what it tracks and how it's counted, and say plainly where you don't know |
| Case / Strategist | "How would you…" on supervisors and digital | Medium. Hiring managers test roadmap thinking, even in a behavioural round | Clarify, then structure, then answer |
| Pressure | One time-boxed challenge | Low | Pause, restate the question, hold, then concede only what's real |

### Question bank R2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your complaints experience is one branch's log. This role owns the process across every branch and the contact centre, and you haven't worked in a contact centre. Why are you ready?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." "6 years in retail banking, the last 3 as a branch supervisor." | **The most valuable thing to rehearse in this pack.** Concede first: "That's fair. I've handled one branch's formal complaints log, and I haven't worked in a contact centre." Then hold to what's true: six years in retail banking, the last three as a branch supervisor, and you trained new tellers on the escalation script. Then give a ramp plan, said as a plan: sit with contact-centre colleagues on live complaints, and read how branch and contact-centre complaints are logged today. **Follow-up 1** ("So you've never run a process this size?"): agree, briefly, and repeat what you did at its real size. **Follow-up 2** ("Why not hire someone who has?"): don't argue. Say what you'd want them to check about you in the first 90 days. Never stretch "the branch's log" into "the process" | F1 and F2 are the gaps a hiring manager sees first, so some version of this question will come. JD because it scores the role's core mandate against your evidence |
| B2 | "Tell me about a complaint that escalated, and what you did." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a real complaint from your time with the branch's formal complaints log where you did something yourself. It needs the member's situation, what you did, and what happened next. Answer slot: if you saw one through to its outcome, tell it. If you passed it on, say so plainly and say what you did before and after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | This is the opener a behavioural manager is most likely to use for this role. It tests "Own the Fix" and F1. VAL in delivery, EXP in what it checks |
| B3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slots: what it tracks, and if that includes volumes or resolution times, how each is counted. Which figure in it you'd defend least, and why. Which tool it's in. If you don't know how something is counted, say so plainly. Never describe a feature it doesn't have | F3 is the closest thing you have to the monthly reporting duty, so a manager will dig into it. EXP because it checks a specific claim |
| B4 | "What does your regional manager actually do with it?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you know what decisions or conversations it feeds, say so in your own words. If you don't, say so plainly and stay with "our regional manager uses it". Don't turn "uses" into "reports to the board" | A natural follow-up to B3. It tests whether you know your reporting's audience, which F8 makes important |
| B5 | "Tell me how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The quote gives two beats: new tellers, and the branch's escalation script. Answer slot: if any of the script was yours to write or change, say which. If not, say so plainly and describe how you ran the training. Keep "our script", not "my script" | F4 is the bridge to coaching supervisors, so this gets checked. EXP because it tests what was actually yours |
| B6 | "A branch supervisor escalates almost everything to you. How do you coach them?" | CASE | [generic] | Structure it: look at their last few escalations together, agree which were right to escalate, and agree what they can handle themselves. Then set a check-in date and say what you'd watch in the monthly figures. The question doesn't need a claim about your past, so don't make one. If you mention being a supervisor yourself, keep it to "I've been a branch supervisor for three years" | Coaching branch supervisors (F4) is a headline duty, and a manager tests it as a live problem. CASE because it's a scenario |
| B7 | "You'd be presenting monthly figures to senior leaders. How do you get ready for that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Concede once: "I haven't presented above regional level." Answer slot: if you've presented at regional level, say what and to whom. If not, say so plainly. Then give a plan: rehearse with your manager before the first session, open with one message per page, and give the number first and the reason second. Say it as a plan | F8 is a requirement you've said you don't yet meet. Rehearsing the concession keeps it from sounding like a confession |
| B8 | "Tell me about a time you found a problem that wasn't strictly yours and kept hold of it until it was fixed." | VAL | [grounded] | Selection scaffold for "Own the Fix": a problem you noticed, a moment you could have passed it on, and what you did to see it through. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Ashgrove's published values include "Own the Fix", and a manager can test values too. VAL |
| B9 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and how would you work with the digital teams?" | CO | [grounded] | Use the brief: 40% by 2028, and app-only banks as the main competition. Structure: complaints will start in the app as well as the branch, a self-service journey can fail in ways a teller would have caught, and complaint data can show the digital team where a journey breaks. Answer slot for F5: if you've worked with a digital team, say how. If not, say so plainly and say what you'd ask them for first | This question draws on the strategy brief and covers F5. CO because it tests whether you can think at strategy level |
| B10 | "Sixty seconds: why you, over a contact-centre team leader who's handled complaints?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause. Give the branch side in your own words: six years in retail banking, three as a branch supervisor. Concede the contact centre plainly. Then say what you'd want to be judged on. Don't attack the other candidate | A Pressure version of B1. Rehearsing it keeps you calm if the time box arrives |
| B11 | "What would you do in your first 90 days?" | CASE | [generic] | Listen, map, then act. Weeks 1 to 4: visit branches, sit with the contact centre, read the complaints data. Weeks 5 to 8: agree one measure for resolution time and one for volume. By day 90: make one visible fix. Keep it to a plan, with no claims about your past | A standard hiring-manager question that shows you'll ramp up on F2 and F3. CASE |

### Reverse questions for R2

| Question | Why it lands |
|---|---|
| "What does a great first year in this role look like to you?" | Your manager defines success, so let them say what it is |
| "How do branch and contact-centre complaints come together today: one log or several?" | Shows you're thinking end to end, and tells you how big F1's gap is in practice |
| "Which complaint-handling rules and timeframes does Ashgrove work to, and where does it find them hardest to meet?" | Makes F7 a diligence question instead of a weak spot |
| "How will the branch consolidation into hubs change where complaints are handled?" | Draws on the strategy brief and shows you've read it |
| "Who sees the monthly complaints report, and what do they do with it?" | Tells you exactly who the "senior leaders" in F8 are |
| "How would you like me to bring you problems: early and rough, or later with options?" | Shows you're thinking about working with them |

---

## Round 3: Panel of two branch managers (60 min: values round plus the 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One or more questions per value, scored | Very high. The recruiter said they "score against the four values" | Have a story or scaffold ready for each value (cheat sheet below) |
| Case / Strategist | The 20-minute escalation case | Certain. The recruiter announced it | Use the case build |
| Peer Evaluator | "You'd be coaching my supervisors…" | High. Branch managers will judge whether this role helps or adds to their load | Frame it as what you'd bring them. Propose principles, not turf |
| Conversational | Warm openers between scored questions | Medium | Treat the warm questions as scored too |

### Values cheat sheet

The values are quoted exactly from the page you copied. None of your four sentences carries a story that shows a value on its own, so each row is a scaffold for choosing a story, not a story the pack wrote for you.

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Members First, Always | Make decisions from the member's point of view, not the institution's | Scaffold: a time you changed what you did because of how it looked from the member's side. It needs the member's need, the easier option you didn't take, and the result. The F1 log is a natural place to look. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it |
| Plain Words | If a member needs something explained twice, the writing is at fault, not the member | Scaffold: a time you rewrote or re-explained something so a member or a new colleague got it the first time. Training tellers (F4) or the spreadsheet (F3) are places to look, but only if that's truly what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it |
| Neighbours, Not Numbers | Each branch belongs to its town, not just to a network | Scaffold: a time you treated a member or your branch's community as people rather than a target. It needs the local detail, the choice, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | Scaffold: a problem you noticed and stayed with until it was resolved, including after you handed part of it on. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it |

### Question bank R3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Use the "Members First, Always" scaffold. Be specific about what the member needed and what you chose to do. "We" for context, "I" for your decision | The panel scores "Members First, Always", using the value's own wording. VAL |
| C2 | "Tell me about a time you had to explain something so it landed the first time." | VAL | [grounded] | Use the "Plain Words" scaffold. Say the plain sentence you actually used, if you remember it | The panel scores "Plain Words". VAL |
| C3 | "Eight branches are becoming five hubs. How do you keep each town's members feeling it's their credit union?" | CO | [grounded] | The question needs no claim about your past. Structure: complaints in the towns losing a branch will need special attention, someone local should be named for each, and you'd watch the monthly volumes from those towns. Then link it to "Neighbours, Not Numbers" in one sentence | Combines the consolidation plan from the strategy brief with a value the panel scores. Branch managers are living through the change. CO first, VAL second |
| C4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Use the "Own the Fix" scaffold. If you used this story for B8, use a different one here or tell it more briefly. Answer slot as in B2: if you saw it through yourself, say how. If you passed it on, say so plainly | The panel scores "Own the Fix". VAL |
| C5 | The 20-minute complaint escalation case | CASE | [grounded] | Follow the case build: clarify, the member's side, contain, one owner, plain words, the cause, coaching. Give the three theses with their concessions | The recruiter announced it. CASE |
| C6 | "You'd be coaching my supervisors on escalations. What does that look like from my side of the branch?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with what you'd bring the branch manager: fewer escalations reaching them, a clear route for the ones that do, and monthly figures they can read. Where it fits: "I've been a branch supervisor for three years, and I trained new tellers on our escalation script." Propose principles: coach alongside the manager, not over them, and agree with the manager before changing anything in their branch | Peer Evaluator: the panel is judging whether you'll make their job easier. F4 and F1. JD because coaching supervisors is a headline duty |
| C7 | "More members are going to the app. What happens to the branch's role in complaints?" | CO | [grounded] | Use the 40% by 2028 target and the pressure from app-only banks. The branch is where a complaint made in the app can still be resolved face to face, so complaint data should flow both ways. Answer slot for F5 as in B9 | Draws on the strategy brief from the branch's point of view. CO |
| C8 | "Tell me about a disagreement with a colleague over how to handle a member's issue." | VAL | [grounded] | Selection scaffold: a real disagreement where you held your view and the relationship survived. It needs what you disagreed about, why, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Peer panels test how you disagree with equals. Linked to "Members First, Always". VAL |
| C9 | "From your time as a supervisor, what would you change about how escalations work?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Keep it to what you saw: three years as a branch supervisor, handling the branch's formal complaints log, and training tellers on the script. Answer slot: if you saw something in the script or the escalation route that didn't work, say what, in your own words. If you didn't, say what you'd look at first. Don't criticise your current employer | Branch managers will want to know what you'd change from your own experience. F4 and F1. EXP |
| C10 | "What would you need from us as branch managers?" | JD | [grounded] | Give something in return: what you'd give them (early warning from the monthly figures, coaching for their supervisors) and what you'd ask for (a named contact for complaints in each branch, an honest view of what's working) | Standard peer reciprocity. JD because it's about the working relationship the role needs |

### Reverse questions for R3

| Question | Why it lands |
|---|---|
| "What's one escalation your branch handled recently that you were proud of, and one you'd do differently?" | Gets them talking, and gives you real examples of what "good" means to them |
| "What would a new Member Experience Lead do in month one that would genuinely help your branches?" | The reciprocity question for a peer panel |
| "How are your teams feeling about the move to hubs?" | Shows "Neighbours, Not Numbers" in action, and the answer matters to the job |
| "Where do complaints get stuck between the branch and the contact centre today?" | Shows you're thinking about F2 from their side |
| "How do you know a member has been well looked after, beyond the complaint closing?" | Invites them to talk about their own values in their own words |

---

## Prohibited claims

These are the claims you might reach for under pressure. The pack won't coach them, and neither should you:

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." Your material covers the branch's log, not a process |
| Handled or resolved regulated complaints | Inflated form of F7 (the log becomes the complaints, and formal becomes regulated) | "I handled the branch's formal complaints log." Anything beyond that only through F7's answer slot |
| Coached supervisors, or wrote the escalation script | Inflated form of F4 | "I trained new tellers on our escalation script." Your material says tellers and "our" script |
| Reported monthly to the regional manager or to leadership | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Your material says built and uses, not presented |
| Has contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." |
| Has presented to senior leaders | Negative you stated, F8 | "I haven't presented above regional level." |

---

## Sources

**Provided documents:** the JD, pasted. The values page, pasted, copied this morning from ashgrovecu.org/about/values; I didn't fetch the page. The recruiter's email describing the process, pasted. Your summary of the July 2026 strategy brief, pasted. Your background, in your message. No dossier was present.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | Your pasted values page, copied today, fixes the values cheat sheet and the VAL questions |
| 2. Ashgrove Credit Union interview process, member experience | skipped | The recruiter's email sets out all three rounds, the case and the values scoring, which fixes the loop and the persona weights |
| 3. Ashgrove Credit Union strategy / recent news | skipped | The July 2026 strategy brief is under six months old and fixes the grounding brief and the CO questions |
| 4. Interviewer name + Ashgrove Credit Union | n/a | No names have been assigned, so there was nothing to search for |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewers' names**, once assigned → a section on reading each interviewer, persona weights based on their public professional profiles, and a reverse question tied to each one's career path
- **Your CV** → more of your own sentences to work from, which could turn some selection scaffolds in the values cheat sheet and B2/B8 into story-mapped answers
- **Your answers to the answer slots** in F3, F7, F9 and F5 (what the spreadsheet tracks and in which tool, whether the log was regulated, any digital work) → those rows, and A7, A9, B3, B4 and B9, rebuilt on what you tell me
- **Hours you have for prep before 5 December** → a prioritised prep schedule
- **The format of the 20-minute case** (written brief, role-play or discussion), usually one email to the recruiter → a case build tuned to that format
- **A deeper research pass**: up to 6 more searches and 2 more fetches, several more minutes → a check of the pasted values page and strategy brief against Ashgrove's live site, plus any recent Ashgrove news
- **A `tuesday-dossier.md`** → verified evidence and a named top objection to build the pack on, instead of the pack's own inference
