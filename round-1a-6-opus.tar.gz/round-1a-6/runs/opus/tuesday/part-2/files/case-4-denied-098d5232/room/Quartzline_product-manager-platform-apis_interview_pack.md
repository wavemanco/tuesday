# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. You didn't give the interviewer's name.
**Built on:** your `tuesday-dossier.md` (job-underwriter, dossier_version 1.1, generated 2026-08-14). Its decision is `conditional_go`, with two conditions this pack keeps: position the bridge as adjacent and never as PM experience, and check the squad-authority question in the interview (reverse question 1).

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it, and in what style. **Types** describe what gets scored. Rehearse both. The same objection lands differently as a quiet probe and as a 60-second challenge.
- **Type key:**
  - **VAL**: values and behaviour, shown through past decisions.
  - **EXP**: deep-dive on your experience. Does the claim hold up, and what part was actually yours?
  - **JD**: whether you can do the listed job, gaps included.
  - **CO**: company and strategy knowledge.
  - **CASE**: a live problem from the role, reasoned through aloud.
- **Provenance labels:**
  - `[grounded]` means the row traces to your dossier or to the role profile.
  - `[inferred]` means the pack derived it, and says how.
  - `[generic]` means a common pattern for this kind of role, with no claim about you or Quartzline.
- **Answer slots** are instructions for the interview, not questions for you to answer now. Each one names something the interviewer is likely to probe, and gives you two honest branches. Either branch is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.
- **F-rows** are the fit-snapshot rows below. **VE1 to VE3** are your dossier's three `verified_candidate_evidence` entries, in order.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — role profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | low | [grounded] | transferability | This is adjacent work. The dossier's condition is that you position it as adjacent and never as PM experience. Start with the plain acknowledgment (prohibited_claims: "Having held a product manager title or role"): "I haven't held a product manager title." Then give the quote at its own scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live." Don't call it PM work or say it equals PM work. Let the interviewer draw that conclusion. VE3 is medium confidence: confirmed, but with little you can show for it, so expect a probe. Keep it at "feeding client evidence to product" |
| F2 | "Own the roadmap for the partner-facing API platform" — role profile responsibility | none given | none | [grounded] | capability | This is the dossier's `acknowledge_gap` area, so there is no bridge. The plain acknowledgment (prohibited_claims: "Having owned a product roadmap"; "Having set prioritization for an engineering squad"): "I haven't owned a product roadmap or set prioritization for an engineering squad." Follow it with a ramp plan, said as a plan and never as something you've done: how you would learn the current roadmap, the partners and the two squads' constraints in your first weeks. Feeding evidence to product (F7) is input to a roadmap, not ownership of one. It doesn't bridge this gap |
| F3 | "Shipped API or platform products" — role profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | Your material says you integrated the vendor's REST APIs for clients. It doesn't say you shipped the API product, so the words stay at integrations. Answer slot: because the role profile says "Shipped API or platform products", expect a probe on the product itself. If any of your integration work changed the API or platform itself, say what changed and which part was yours, in your own words. If none did, say so plainly and stay with the integrations you led to go-live |
| F4 | "Technical fluency: API docs, schemas" — role profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Wrote the internal integration playbook her team uses" — dossier VE2 | low | [inferred] | discovery | Leading REST API integrations through architecture comes close to this requirement. Your material doesn't show API docs or schemas themselves, though, so this row is the pack's inference. Answer slot: if you worked from or wrote API docs or schemas in those integrations or in the playbook, say which and how, in your own words. If you didn't, say so plainly and stay with the integration stages you led |
| F5 | "Stakeholder management across engineering, sales, customers": the customer part — role profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | presentation | The quote already covers the customer side, just in different words: client integrations, end to end. Reword only that: "I led 30+ client integrations end to end, from scoping to go-live." Add nothing about how the clients were handled |
| F6 | "Stakeholder management across engineering, sales, customers": the engineering and sales part — role profile R4 | none given | none | [grounded] | discovery | Your material doesn't show engineering or sales stakeholders. Answer slot: the role profile names both, so expect a probe. If engineers or salespeople were part of your integrations or the roadmap-input sessions, say who they were and what you did with them, in your own words. If they weren't, say so plainly and stay with clients and product |
| F7 | "Run discovery with integration partners" — role profile responsibility | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [grounded] | transferability | Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." The limit: feeding evidence to product is input, not the roadmap decision. The dossier also marks this claim confirmed but with little you can show for it, so say up front what you can and can't show, before anyone asks. Answer slot: the discovery line in the role profile makes a probe on how the sessions ran likely. Say how they ran and which part was yours, in your own words. If any part wasn't yours, say so plainly and keep to what the quote says |
| F8 | "Write specs and drive delivery with two engineering squads" — role profile responsibility | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Wrote the internal integration playbook her team uses" — dossier VE2 | high | [grounded] | transferability | Use the quotes at their own scope: requirements and UAT were stages of integrations you led, and you wrote the integration playbook your team uses. Integrations and a playbook aren't product specs for squads, and the dossier prohibits any claim to have set squad prioritization. Answer slot: "drive delivery with two engineering squads" makes a probe on who built what likely. Say who did the build work on your integrations and which part of directing it was yours, in your own words. If directing engineers wasn't part of it, say so plainly and stay with the stages you led |
| F9 | "Define and track adoption metrics" — role profile responsibility | none given | none | [grounded] | discovery | Answer slot: if you defined or tracked any measure of integration or API use, say what was counted and how, in your own words. If you didn't, say so plainly, then say what you would measure first. How Quartzline measures adoption today is an open question in the dossier, so it is reverse question 2 |
| F10 | "Agile delivery experience" — role profile R5 | none given | low | [grounded] | discovery | The dossier's strategy here is `clarify`: none of the verified entries mentions agile. Answer slot: if they ask about agile delivery experience, describe how your integration work was actually run, in your own words. If it was agile, say which practices you used. If it never worked that way, say so plainly. Then: "What I'd want to confirm is how your squads define it day to day" |

---

## Persona table

No loop source describes Quartzline's wider process. Your own words fix this session as one 45-minute conversation with the hiring manager, so the weights start from the hiring-manager prior. They are adjusted by the objection the dossier named. There is no interviewer profile to adjust them further.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the missing PM title and roadmap ownership | **Very high.** This is a hiring-manager prior, and the dossier named this exact objection. A manager hiring for a role you have never held will check the gap | Rehearse A1 until it bores you. Concede first, then the quote, then a plan, then hand it back with a question |
| Case / Strategist | Live problems from the role: adoption, roadmap trade-offs, partner requests | **High.** This is a hiring-manager prior, and the responsibilities are all live-problem material. In 45 minutes, expect one or two cases | Clarify, then the objective, then segments, then the approach, then metrics, then risks. Think aloud. Ask who owns the decision before you decide |
| Conversational | Openers such as "walk me through your journey" | **Medium.** Most 45-minute conversations open this way, and it is still scored | A pre-scripted 90-second arc (C1) built only from VE1 to VE3 |
| Data-Driven Prober | "30+ — how counted?", "what's in the playbook?" | **Medium.** VE1 carries the one figure in your material, and a manager hiring away from a PM background will test it | Know how the 30+ was counted, which parts were yours, and what you can show |
| Pressure | Time-boxed versions of the objection | **Low to medium.** It isn't the usual hiring-manager register, but the objection often comes back compressed | Pause, then concede, quote and plan, and stop inside the time limit |
| Values / Behavioral | "A time you told product something unwelcome" | **Low.** No source names a values round, and the values search didn't run | Selection scaffolds with honest branches |
| Peer Evaluator | Seam questions about the squad leads | **Low.** This isn't a peer round, but the seam with the squad leads is the dossier's open authority question | Offer principles for where the seam sits rather than claiming authority. Ask where it sits |

---

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Wrote the internal integration playbook her team uses" | **This is the highest-ROI rehearsal in the pack. The underwriter named this objection.** Four beats: **1. Concede first**, plainly (prohibited_claims: "Having held a product manager title or role"; "Having owned a product roadmap"): "That's right: I haven't held a PM title and I haven't owned a roadmap." **2. Say what you did**, at its own scope: "I've led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping, requirements and architecture through UAT and go-live, and I wrote the integration playbook my team uses." Stop there. Don't call it product work. **3. Give the plan**, said as a plan: what you would learn first about the roadmap, the partners and the two squads. **4. Hand it back**: "Which roadmap decisions would this PM make alone?" **Follow-up 1** ("Isn't that just project delivery?"): hold by naming the stages again, and concede that delivering integrations isn't owning a roadmap. **Follow-up 2** ("So you'd learn the core of the job on the job?"): concede yes for roadmap ownership specifically, and go back to the plan. Never add something to your past to make the gap look smaller | F1 and F2 are where this role presses hardest, and the dossier names this as the likeliest objection. JD, because it scores the R1 requirement directly. Every negative in the question has a source in `prohibited_claims`, so it is asked as the underwriter wrote it |
| A2 | "The role asks for shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot (F3): if any of your integrations changed the API or platform itself, say what changed and which part was yours, in your own words. If none did, say so plainly and hold at the quote: "What I led were 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." Don't let "integrated" drift into "shipped" | R2 is a must-have, and F3 is adjacent rather than direct. JD, because it scores the stated requirement. The question's premise is the role profile's, not your history's |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] | Pick the real gap, not a safe-sounding one (prohibited_claims: "Having owned a product roadmap"): "Owning the roadmap. I haven't owned a product roadmap." Then 30 seconds of plan: how you would learn this roadmap's history, its partners and the squads' constraints. A real weakness named calmly scores better than an invented one | F2 is the obvious answer, and an interviewer who already sees it will judge whether you name it. JD, because it scores self-assessment against the listed job |
| A4 | "Why move from integration work into product management, and why now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Your material has no sentence about your motivation, so this one is yours. Answer slot: give your actual reason in your own words, in about 60 seconds. Anchor it in the integrations you led, not in a claim that you already do the job. If part of the honest answer is something you want to learn, say it | A move into a new title invites the "why now" probe. EXP, because it tests whether your story holds together. The rationale refers only to F1 |
| A5 | "I don't see agile delivery in your background. How have you actually worked?" | JD | [grounded] | The dossier's `clarify` strategy (F10). Answer slot: describe how your integration work was actually run, in your own words. If it was agile, name the practices. If it never worked that way, say so plainly. Close with: "What I'd want to confirm is how your squads define agile day to day." Don't borrow agile vocabulary for work that wasn't run that way | R5 is a preferred requirement the dossier marks low confidence. JD, because it scores a listed requirement. A question-shaped answer is the strategy the dossier allows |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has been flat this quarter. Diagnose it." | CASE | [generic] | Clarify first: what counts as adoption here, and against what baseline? The dossier says no baseline is stated, so asking is honest. Then segment: new versus existing partners, endpoint by endpoint, by integration stage. Then hypotheses: onboarding friction, docs gaps, a missing capability, commercial terms. Then what data would separate them, and what you would do in week one. Name the hypothesis you'd test first and why | It comes from the "Define and track adoption metrics" and roadmap responsibilities. CASE, because it scores structure live. `[generic]`, because it is a pattern for the problem, not a fact about Quartzline. It makes no claim about your past |
| B2 | "It's your first 90 days owning this roadmap. What do you need to know first, and what do you do?" | CASE | [generic] | Structure it in three parts. First, learn: the current roadmap and why it's shaped that way, the top partners and their open asks, each squad's capacity and constraints, and who decides what. Second, align: a shared view of problems with the two squad leads. Third, act: one small, visible improvement, with a metric attached. Say it all as a plan, never as something you have done before | This is the case version of F2's gap. A good plan is the honest counterweight to not having owned a roadmap. CASE and JD |
| B3 | "One squad wants a breaking v2 change; your biggest partners want stability. How do you decide?" | CASE | [generic] | Clarify: what does v2 unlock, who breaks, and is there a deprecation window? Lay out the options: versioning, a migration path, a phased rollout. Name the criteria: partner impact, engineering cost, strategic value. Then say how you'd decide **and with whom**. Ask whether the call is the PM's or the squad lead's, because the dossier lists that as unknown. Don't presume you'd hold the authority alone | It comes from "drive delivery with two engineering squads" and the open authority question. CASE, because it scores trade-off reasoning |
| B4 | "How would you define adoption metrics for a partner-facing API?" | JD | [generic] | Layer it. Activation: a partner's first successful production call. Breadth: active integrations. Depth: endpoints used and call volume. Retention: integrations still active after N months. Outcome: what partners actually get from it. Separate leading from lagging measures. Name the assumption you'd trust least, for example that call volume reflects value, before they do | F9 has no evidence behind it, so a strong live answer matters. JD content, delivered as CASE. It makes no claim about your past |
| B5 | "Sales has promised a large partner a custom endpoint, and engineering says no. What do you do?" | CASE | [generic] | Clarify what was promised and what the partner actually needs. Separate the need from the stated solution. Look for a general capability that serves the need. Bring sales and engineering to one view of the cost. Decide or escalate, and say who owns the call. Close the loop with the partner. Keep it in the future tense: F6 shows no engineering or sales history to draw on | This tests R4 across engineering, sales and customers. CASE delivery, JD content |

### C. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Wrote the internal integration playbook her team uses" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each at the scope of its own quote: the 30+ client integrations you led end to end; the integration playbook your team uses; the quarterly roadmap-input sessions that fed client evidence to product. Then why this role (an answer slot, in your own words). Don't add a PM title or a roadmap anywhere in the arc | The usual opener, and the first place a gap gets papered over. EXP, because it sets up what they will probe next. It draws on F1, F7 and F8 |
| C2 | "What drew you to Quartzline?" | CO | [generic] | Answer slot: give your actual reasons, in your own words. Research didn't run for this pack, so it supplies no facts about Quartzline. Mention only what you have read yourself, and say where you read it if they ask | Casual, but scored for homework. `[generic]`, because the strategy search was refused (see Sources) |
| C3 | "What API docs or specs do you find yourself working with these days?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot (F4): if you work from or write API docs or schemas, say which and how, in your own words. If you don't, say so plainly and stay with the integrations you led. A casual register is still a technical-fluency check | R3, asked conversationally. JD content. `[inferred]`, because F4's link to docs and schemas is the pack's inference |

### D. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Thirty-plus integrations. How are you counting those, and what was yours across all of them?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Prepare four things in your own words: how the 30+ was counted, what the count is sensitive to, the assumption behind it you'd defend least, and which parts were yours. "Led" is the quote's verb, so keep it. If others led some stages, say so plainly. "I'm not sure exactly how it was counted" is an honest answer | It is the one figure in your material, which makes it a natural target. EXP, because it scores attribution. The figure belongs to F1 and F3 |
| D2 | "Walk me through the integration playbook. What's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The dossier says it was provided and can be inspected, which is your strongest kind of proof. If you can show it, offer to. Answer slot: say what it covers and why you wrote it, in your own words. The material doesn't list its contents, so the pack names none | VE2 is high confidence, so lead with it under probing. EXP, because it scores what you actually wrote. It draws on F4 and F8 |
| D3 | "Those roadmap-input sessions: what changed in the product because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed, but with little you can show for it. Volunteer that limit before they find it. Answer slot: if you know of something product changed because of evidence you fed in, say what changed and how you know. If you don't know, or nothing traceable changed, say so plainly and describe how the sessions ran. Never claim the product decision | This is where the dossier expects a probe. EXP, because it scores the gap between input and influence. It draws on F7 |

### E. Pressure (low to medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause first. This is A1 compressed (prohibited_claims: "Having held a product manager title or role"): "I haven't held a PM title. I've led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live. Here's how I'd ramp on the roadmap…" Then one sentence of plan, and stop. Finishing inside 60 seconds is part of the score | The objection the dossier named, under time pressure. JD. Holding the concession under pressure is the test |
| E2 | "Thirty integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led", because it is your verb. Answer slot: say which stages you did yourself and which others did, in your own words. If some integrations were led differently, say so. Concede specifics, not the core claim | Pressure on F1's evidence. EXP, because it scores attribution under stress |

### F. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Tell me about a time you told a product team something they didn't want to hear." | VAL | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold. If one of the roadmap-input sessions carried a moment like this, tell it in your own words: what the evidence said, how you raised it, what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common hiring-manager probe of candour. VAL. The session line in F7 is the nearest candidate, but the pack supplies no event |
| F2q | "When did you put a client ahead of an internal deadline or metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a choice you made, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A partner-facing role tests this instinct. VAL. `[generic]`, because no quote carries this story |

### G. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The squad leads own a lot of the how. Where's the seam between you and them, and what happens when you disagree?" | CASE | [generic] | Offer principles for the seam rather than claiming you know where it sits. A common split: the PM owns the problem and the priority case, and the squad owns the solution and estimates. Disagreements go to shared evidence first, then an agreed decider. Then ask where the seam actually sits here. Say nothing about having set squad priorities | The dossier's unverified authority question, asked from the manager's side. CASE, because it scores working style. It makes no claim about your past |
| G2 | "How do you handle credit when an integration lands because of a lot of people?" | EXP | [generic] | Use "we" for the context and "I" for your part. Answer slot: name what was yours and what others did, in your own words. If no particular example comes to mind, describe how you would handle it | Integration work spans teams, so attribution habits get tested. EXP |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A3, A4, E1 |
| R2: Shipped API or platform products | A2 |
| R3: Technical fluency: API docs, schemas | C3, D2 |
| R4: Stakeholder management across engineering, sales, customers | B5, G1, F2q |
| R5: Agile delivery experience | A5 |
| Own the roadmap | A1, A3, B2 |
| Run discovery with integration partners | D3, F1q, B1 |
| Write specs and drive delivery with two squads | B3, G1, D2 |
| Define and track adoption metrics | B4, B1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier. The role profile claims decision authority but shows none, and the dossier's go depends on checking it. The answer tells you whether this role is the job described |
| 2 | "How is partner API adoption measured today, and what's the current baseline?" | From the dossier. Adoption metrics are listed as a responsibility with no baseline stated. It reads as diligence and tells you whether you'd be inheriting a metric or building one |
| 3 | "What would make this hire clearly successful at six months?" | It turns the role profile into concrete expectations, and lets you check them against your ramp plan |
| 4 | "How do partner requests from sales reach the roadmap today?" | It probes the R4 seam (sales, partners and product) that B5 rehearses |
| 5 | "Where do partners get stuck most often when they integrate?" | It goes straight to the discovery responsibility, and shows you thinking about the partner's problem |
| 6 | "Is there anything about my background that gives you pause for this role?" | It brings the A1 objection out while you still have time to answer it, rather than after you've left the room |

---

## Prohibited claims

Every guidance cell above was written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier `prohibited_claims` | "I haven't held a product manager title." Then VE1 at its own scope |
| Having owned a product roadmap | dossier `prohibited_claims`; `acknowledge_gap` area | "I haven't owned a product roadmap." Then a ramp plan, said as a plan |
| Having set prioritization for an engineering squad | dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." B3 and G1 are answered as a future way of working |
| That the integration work was product management, or PM in all but title | Inflated form of F1 | VE1 at its own scope. The pack's observation: the material says client integrations, not a product role. Let the interviewer draw the inference |
| Shipped an API or platform product | Inflated form of F3 | VE1 at its own scope: integrations of the vendor's REST APIs. A2's slot stays inside the integrations |
| Ran product discovery, or shaped the roadmap through the sessions | Inflated form of F7 | VE3 at its own scope: sessions feeding client evidence to product. D3's slot asks only what you know changed |

---

## Sources

- **Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14. The pack used these sections:
  - `role_profile`: requirements R1 to R5 and the responsibilities, used as the job description's lines.
  - `handoff_to_mock_interview`: the verified evidence (VE1 to VE3), the weak areas and their allowed strategies, the objection used for A1, the risks and employer questions behind reverse questions 1 and 2, and `prohibited_claims`.
  - `decision`: context only.
- The dossier has no `evidence_map`, `evidence_state` or `risk_register` section, so the fit snapshot's evidence cells quote `verified_candidate_evidence` exactly. The role profile reflects the posting as of the dossier's date.
- **Searches sent:**
  - "Quartzline company values": refused.
  - "Quartzline partner API platform news": refused.
- **Fetches:** none.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | The search was refused. It would have supplied value names to theme the VAL questions (F1q, F2q). No values cheat sheet either way, since no source names a values round |
| 2. Quartzline interview process, product management | skipped | Your own words fix this session as one 45-minute conversation with the hiring manager, and that sets the persona weights |
| 3. Quartzline strategy and recent news | unavailable | The search was refused. It would have grounded C2 and the B-bank cases in Quartzline's current priorities. They stay `[generic]` |
| 4. Interviewer name at Quartzline | n/a | No name was given, so there was nothing to search. The pack has no interviewer read |
| 5. A representative JD for the title | skipped | The dossier's `role_profile` supplies the requirements and responsibilities |

---

## Upgrade menu

- **Search permission for this session:** values (target 1) and strategy (target 3) would run, and C2 and the B-bank cases could become `[grounded]` in Quartzline's current priorities.
- **A deeper research pass:** a company strategy brief, an interviewer deep dive if you give a name, loop reports and recent org context. It costs up to 6 more searches and 2 more fetches, and several more minutes.
- **The hiring manager's name:** a read of their public professional profile, adjusted persona weights, and a reverse question tied to their own career path.
- **How much prep time you have before Thursday:** a triage schedule. Until then, A1 comes first, then reverse questions 1 and 2, then B1 and B4.
- **Your answers to the answer slots in F4, F6, F9 and F10:** told to me outside a drill, they would become quoted evidence, and rows A5, B4, B5 and C3 would gain story-mapped guidance.
- **Any recruiter guidance (focus areas, or a case or presentation announced in advance):** a build section for each announced deliverable.
- **Something you can show for the roadmap-input sessions (VE3):** F7 and D3 would move from medium toward high confidence.
