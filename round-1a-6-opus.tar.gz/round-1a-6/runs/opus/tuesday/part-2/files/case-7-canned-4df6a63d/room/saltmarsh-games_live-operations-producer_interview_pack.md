# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** Friday, 60 minutes. Saltmarsh's careers page says every loop is a recruiter call followed by "the Outage Hour": one 60-minute interview with the hiring manager, made up of "a live-incident tabletop on a simulated outage during a live event, then a values conversation", with no take-home. This pack assumes Tobias is that hiring manager and that Friday is the Outage Hour.

---

## How to use this pack

- **Personas** describe *how* a question gets asked. **Types** describe *what* it scores. Most questions here have both.
- Type key:
  - **VAL**: values alignment, scored against Saltmarsh's three published values
  - **EXP**: deep-dive on your experience; checks what was actually yours
  - **JD**: tests a requirement listed in the job description
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem you work through out loud
- Provenance labels: `[grounded]` = from your message, the JD or a cited Saltmarsh page; `[inferred]` = derived from one of those, with the derivation named; `[generic]` = a common pattern for this kind of role, with no claim about Saltmarsh.
- **Guidance is scaffolding, not a script.** Wherever guidance gives you an "answer slot", answer it from what really happened, in your own words. Each slot includes an honest "that wasn't me / that didn't happen" option, and that option is a complete answer.

---

## Prep triage (assumes you have tonight and Friday morning)

1. **C1**, the highest-ROI rehearsal in this pack. Say the answer out loud twice, including both follow-ups.
2. **A1 to A3**, the tabletop. Practise the six-step structure under A1 until you can say it without notes. This is half the interview.
3. **The values cheat sheet** (section below), then B1 to B3. That's the other half.
4. **C2**, the in-app purchases question. Make sure the plain acknowledgment and the learning plan come out calmly.
5. Read the Project Larkspur announcement on Saltmarsh's news page before A5 and the reverse questions.
6. Choose three reverse questions.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | You have adjacent work: a weekly content-drop calendar for one title. The role is a live-events calendar for two. Keep the quote at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: "two titles" makes a probe on juggling competing priorities likely. If that calendar ever had to balance competing demands, say what they were and how you decided, in your own words. If it didn't, say so plainly and describe how you'd approach two titles, framed as a plan |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't say who you worked with on each drop. Coordinating is a different thing from leading, and the JD asks for coordinating. Answer slot: if your calendar work involved design, art, engineering or community people, say who and what you agreed with them, in your own words. If it didn't, say so plainly and give how you would set up that coordination |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is next to the post-event review, not the same as owning it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you also wrote up what happened after a content drop, or chose what to report, say how. If you didn't, say so plainly and describe the review you would run |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | The quote shows you wrote it and that QA still uses it. It doesn't show whether you ran it release by release. Lead with exactly that: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA on each release or revised it over time, say how. If someone else ran it, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Four years clears the bar in years. Your material doesn't say whether the puzzle game counts as live-service. Answer slot: if the main title ran as a live-service game, say what made it one, in your own words. If it didn't, say so plainly and point to the weekly content-drop calendar as the closest thing |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. This quote meets the requirement directly. It's still a claim nobody has inspected, so expect a probe. Lead with it as stated: weekly, the main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote shows you presented the numbers. It doesn't show whether you calculated or interpreted them. Answer slot: if you calculated or analysed them, say which metrics and how. If a data team produced them, say so plainly, and say which ones you could explain and which you couldn't |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist that QA still uses is a written document that has lasted. It's one kind of writing, not proof of all of them. Words: "I wrote the release checklist our QA team still uses." Let the interviewer draw the conclusion about your writing |

---

## Reading the interviewer

From Tobias Wrenfield's public professional footprint (one search result, cited in Sources):

- **Career pattern:** he was a QA lead at a console studio before becoming Head of Live Operations at Saltmarsh.
- **Self-described stance:** in his GDC 2026 talk *Patch Notes Are a Promise*, he argues that "a live team is judged by how often its patch notes describe what actually shipped."

Practical implications:

1. **In the tabletop, don't promise players a fix time you don't have.** Both his talk and the value "Ship the Patch Not the Promise" point the same way: tell players what's known, not what's hoped.
2. **Expect a QA-literate probe on the checklist.** F4 is the place a former QA lead will dig into. Know what you can say about it, and what you can't.
3. **Precision will land better than polish.** Describe what you did at its real scope and let him draw the conclusions.

Mirror opportunities: there is no shared career jump to offer. None of the fit-snapshot rows puts you in QA. The shared vocabulary is the release checklist (F4: "Wrote the release checklist our QA team still uses."). Reverse question R2 asks about his path from QA to live ops directly.

---

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The whole first half: a simulated outage during a live event | **Highest.** The careers page names a live-incident tabletop as half of the Outage Hour, and hiring managers lean towards case questions anyway | Clarify, then objective, then structure, then decide, then communicate, then review. Think out loud. Challenge one premise politely |
| Values / Behavioral | The second half: a values conversation | **High.** The careers page names it. Saltmarsh publishes three values, so expect each one by name | One prepared story or scaffold per value (cheat sheet). Use "we" for context and "I" for your part |
| Skeptic | Probing the gaps: one title versus two, no team leadership, no in-app purchases | **High.** Hiring managers price in the risk of a gap, and F1, F2 and C2's stated negative are the obvious ones | Rehearse C1 until it's boring. Bridge only from your own quotes, and give a concrete learning plan |
| Data-Driven Prober | "Which retention metrics? What did the checklist catch?" | **Medium.** The JD names retention metrics and KPIs, and his QA background makes checklist detail a natural probe | Know what you can and can't say about how each number was counted. Saying you don't know is allowed |
| Pressure | Time limits inside the tabletop ("the event ends in four hours, decide") | **Medium-low.** Outage scenarios build in time pressure, but nothing published says he plays it adversarially | Pause, restate, decide. Hold through two follow-ups, then concede the specific uncertainty |
| Conversational | The opener, "walk me through your background" | **Low but certain.** Nearly every 60-minute interview opens this way, and the opener still counts | A rehearsed 90-second arc (E1) |
| Peer Evaluator | Where producer meets community or engineering | **Low.** This is a single interview with the hiring manager, but the JD's coordination line brings the seams in | Propose principles for handling the seam. Don't pretend to know Saltmarsh's teams |

---

## Question banks

### A. Case / Strategist: the tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event on one of our titles and the rewards service is down: players can't claim. Talk me through your first 30 minutes." | CASE | [inferred] | The structure to rehearse: (1) Clarify: which title, how many players are affected, since when, and is anything still working? (2) Get the right people: on-call engineering, QA to reproduce, community so players hear something early. (3) First player message: what's known and when the next update comes, with no fix time. (4) Decide the event question: pause, extend or carry on. (5) Keep a timeline as you go. (6) Name who owns the post-event review. Say the structure before you fill it in. This question needs no claim about your past, so the guidance makes none | The careers page names a simulated outage during a live event as half the interview. The scenario details are this pack's invention, which is why it's `[inferred]`. CASE because the delivery is what's being scored |
| A2 | "Engineering says the fix is six hours away. The event ends in four. Extend, compensate, or let it end?" | CASE | [inferred] | Name the trade-off first: the players who lost claim time versus the calendar slot the next event needs. Use the value by name, "Players Before Plans: when the calendar and the players disagree, the players win", then give an actual decision with its cost. For example: extend by enough to cover the lost window, and tell players only once the extension is confirmed. Say what you'd check before committing (does the extension push into the next event?). Choose one and defend it | The likeliest follow-up inside the tabletop, and a direct test of the first value. CASE content, VAL lens |
| A3 | "Community wants to post an ETA right now. What do you let them say?" | CASE | [inferred] | Hold the line on the second value: "Ship the Patch Not the Promise: we announce what is built, not what is hoped." Give community something true to post straight away: acknowledge the problem, say claims are affected, say rewards will be honoured, and give the time of the next update. Commit to a fix time only when engineering has one. Then agree how often updates go out, so community isn't waiting on you | Tests the second value and Tobias's talk at once. It's where candidates most often promise too much under pressure |
| A4 | "The outage is over. Walk me through the post-event review you'd run, and the KPIs it reports." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A shape for the review: what happened, the timeline, the impact on players, what we decided and why, what we'll change, who owns each change. For KPIs, choose a few that fit an event: participation, claim or completion rate, retention around the event, support contacts, crash or error rate. Name them as what you would report. You can say: "I presented the monthly retention numbers to the studio head." Answer slot: if you've written a review after a content drop, say how it was structured. If you haven't, say so plainly and present this as how you'd run one. To fit the third value, finish with what gets added to the checklist | F3 and F7 meet here, and the JD's "own the post-event review" line makes this near-certain. JD because it scores a listed responsibility |
| A5 | "From next year both our titles move to a season pass on one shared events calendar. What breaks first?" | CO | [grounded] | The question's premise comes from Saltmarsh's September 2026 Project Larkspur announcement (read it in full first). Structure: the clashes from a shared calendar (both titles wanting the same weekend), season-pass pacing against event pacing, combined load on QA and art, and player communications across two communities. Pick one as the first thing that breaks and say why. Ask one clarifying question, such as when the per-title teams merge. This makes no claim about your past | Larkspur is Saltmarsh's biggest public live-ops change, and it lands on this role directly. CO because it tests whether you've done your homework on the company |
| A6 | "How would you make sure our patch notes describe what actually shipped?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Propose a mechanism: draft the notes from the final build's verified change list, have QA sign off on the notes as a checklist step, add a hold step for anything cut late, and run a quick comparison after release. You can say: "I wrote the release checklist our QA team still uses." Answer slot: if your checklist included a patch-notes step, say what it was. If it didn't, say so plainly and present this as what you'd add | This is the argument of Tobias's own talk, so expect some version of it. CASE because it's a design problem, with JD content from the checklist line |

### B. Values / Behavioral: the values conversation

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Your calendar is the obvious place to look: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a moment it needs a named plan, a player signal that cut against it, what you did, and how it turned out. If no such moment comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, taken word for word from the values page. Its theme comes from that page, and the calendar quote is the only material near it |
| B2 | "Ship the Patch Not the Promise. When have you held back from announcing something that wasn't ready?" | VAL | [generic] | Selection scaffold: a time something was planned or hoped for, there was pressure to announce it, and you (or your team, said honestly) waited until it was built. Name your part with "I". If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second value. None of your sentences carries an announcement story, so this is a selection scaffold rather than a story map |
| B3 | "Leave the Build Greener. What have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are only the ones your sentence states: you wrote it, and QA still uses it. Tell those in your own words. Answer slot: the value says releases leave "the checklist better than it found them," so expect a probe on what changed. If you revised it or know what it improved, say what, in your own words. If you don't, say so plainly and stay with the fact that it's still in use | The third value names the checklist directly, and F4 is the best match in the whole pack |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've run a calendar for one title. This role runs two and coordinates design, art, engineering and community, and you've never led a team. Why are you ready?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team" | **The highest-ROI rehearsal in this pack.** Hold what your quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Give the plain acknowledgment before he presses: "I haven't led a team." The JD asks you to coordinate, not to manage people, and you can say you see it that way. Answer slot: if you worked with design, art, engineering or community on those drops, say who and what you agreed. If you didn't, say so plainly and stay with the calendar. Close with a learning plan for two titles, framed as a plan. **Follow-up 1:** "But two titles?" Return to the weekly rhythm you ran and say how you'd learn the second title's needs; add nothing to your past. **Follow-up 2:** "Coordinating four disciplines is leadership." Concede the specific point ("I haven't done that at this scale") without folding on the calendar | F1, F2 and your stated negative collide here, so this objection arrives in some form. JD because it scores the core requirement. The deepest rehearsal goes here because this is where the pull to inflate is strongest |
| C2 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment, said calmly and first: "I haven't worked on a game with in-app purchases." Then a learning plan as a plan: how you'd get up to speed on season-pass design and its metrics before Larkspur's start date. Don't reach for something that sounds nearby to soften it | The JD doesn't list monetization, but the Larkspur announcement's season-pass move makes it a likely probe. JD delivery, CO context |
| C3 | "Associate producer to producer: what's the step up you haven't taken yet?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "Never led a team" | Own it in one sentence: "Four years as an associate producer at a puzzle-game studio, and I haven't led a team." Then name what this role asks of you that's new, such as two titles and owning the review, and how you'd ramp. Answer slot: if you've stood in for a producer or taken on producer-level work, say what. If you haven't, say so plainly | The jump in title is visible from F5's quote, so a Skeptic will name it. EXP because it tests your account of yourself |
| C4 | "Why leave, why Saltmarsh, and why now?" | EXP | [generic] | Give your actual reason for leaving, in your own words, and keep it short. For "why Saltmarsh", use something true you've read: the values page or Larkspur. For "why now", say what's actually true. Keep the three parts consistent with each other | Standard Skeptic stem testing whether your motivation hangs together. You haven't shared your reasons, so this is an instruction, not a script |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Those monthly retention numbers you presented: which metrics, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start from the quote: "I presented the monthly retention numbers to the studio head." Answer slot: say which metrics they were and how they were counted, in your own words; which assumption behind them you'd defend least; and which part of the work was yours. If a data team produced them, or you don't know how they were counted, say so plainly. "I didn't calculate them" is an honest answer | The JD's "comfortable with player-retention metrics" makes this near-certain. F7 is thin on depth, so get your honest answer ready before the probe |
| D2 | "The release checklist QA still uses: what's on it, and what has it caught?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | You wrote it and QA still uses it; that's the hold. Answer slot: describe what's on it from memory, in your own words. If it has caught specific problems, name one. If you don't know of one, say so plainly and stay with the fact that it's still used | A former QA lead is likely to dig into F4. EXP because it tests the claim itself |
| D3 | "How did the weekly content-drop calendar actually run, week to week?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1 and F6: weekly, the main title, two years. Describe the rhythm in your own words. Answer slot: the JD's coordination line makes "who else was involved" a likely follow-up. If design, art, engineering or community fed into it, say who and how. If not, say so plainly | Checks the strongest line in your background. A detailed answer here turns "medium" evidence into something he believes |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your background." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these four sentences: four years as an associate producer at a puzzle studio; the weekly content-drop calendar for the main title for the last two years; the checklist QA still uses; presenting monthly retention numbers to the studio head. Then one line on why live ops at Saltmarsh. Stop there and let him choose what to ask next | The opener is nearly certain, and it sets the frame for the hour. It's still scored |
| E2 | "What are you playing at the moment, and what would you change about its live events?" | CASE | [generic] | Pick a game you actually play. Name one event, one thing that worked, one change, and the metric you'd watch. Be specific | A casual question that tests live-ops thinking. Interest you can't back up shows within one follow-up |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who's already run monetized live events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "never worked on a game with in-app purchases" | Pause, then: the calendar at its own scope; "I haven't worked on a game with in-app purchases"; one concrete thing you'd bring, framed as what you'd do; your learning plan. Keep it under 60 seconds. Don't attack the hypothetical rival | Tests composure on C2's gap under time pressure. JD because it scores fit to the role |
| F2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if others contributed sections or reviewed it, say who and what, in your own words. If it was yours alone, say so plainly. Don't make it bigger and don't shrink it | The standard attribution check, aimed at the claim he's most likely to care about |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community wants to announce the next event date before engineering has committed. What do you do?" | CASE | [generic] | Propose a principle rather than pretending to know Saltmarsh's teams: no public date before engineering commits, and community gets a date they can tease without naming it. Explain how you'd get both sides to agree in advance, so it isn't a fight every time | The JD's coordination line, as a conflict at the seam. It also tests the second value |
| G2 | "How do you handle credit when an update spans design, art and engineering?" | VAL | [generic] | Selection scaffold: a time shared work went well and you made sure each discipline's part was named. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A credit-sharing check between peers. Your material is silent on cross-team credit (F2) |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A5, C1, D3 |
| Coordinate design, art, engineering and community (F2) | A1, C1, D3, G1, G2 |
| Own the post-event review and its KPIs (F3) | A4 |
| Manage the release checklist with QA (F4) | A6, B3, D2, F2 |
| 3+ years producing live-service games or apps (F5) | C3, E1 |
| Experience running a content calendar (F6) | D3, B1 |
| Comfortable with player-retention metrics (F7) | A4, D1 |
| Clear written communication (F8) | A3, A6, B3. The interview is spoken, so the questions about your own writing are A3 (writing player comms) and B3 (the checklist) |

---

## Values cheat sheet

Value names and definitions are taken word for word from saltmarshgames.com/values.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | "When the calendar and the players disagree, the players win": the schedule gives way to the player experience | F1: "I ran the weekly content-drop calendar for our main title for the last two years." This gives the setting, not the disagreement. Choose a moment where a player signal pushed against the plan. If no such moment comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B1; tabletop A2) |
| Ship the Patch Not the Promise | "We announce what is built, not what is hoped": only promise what's done | No fit-snapshot row carries this story. Selection scaffold: a time you held back an announcement until the thing was built. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (B2; tabletop A3, A6) |
| Leave the Build Greener | "Every release leaves the codebase and the checklist better than it found them": leave things better than you found them | F4: "Wrote the release checklist our QA team still uses." (B3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How do you track that here?" | It shows you looked into *him*, and it invites him to talk about his own idea, which turns the interview into a conversation |
| R2 | "You moved into live ops from QA. What did that change about how you think release checklists should work?" | It's tied to his career path and to the one artifact you share (F4), so it becomes a conversation between two people who care about checklists |
| R3 | "With Larkspur merging both titles onto one calendar from February, what does this producer own before the merge, and what after?" | It shows you've read the announcement, and the answer tells you what the job actually is |
| R4 | "What does a good post-event review look like here: who reads it, and what decision does it feed?" | The JD says you'd own it. Asking what it's for shows you'd write it for the person who reads it |
| R5 | "When Players Before Plans runs into a date that's already been committed, who makes the call?" | It tests how the value works in practice and shows you took it seriously |
| R6 | "What would make you say, at 90 days, that this hire was the right one?" | It gets you the success criteria directly, and gives you a last chance to address any gap he names |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a live-events calendar | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The material says content drops, not live events |
| Ran calendars for multiple titles | Inflated form of F1 | The same quote. The material says "our main title" |
| Led or managed a team, including a cross-discipline team | A negative you stated | "I haven't led a team." |
| Experience with in-app purchases, monetization or season passes | A negative you stated | "I haven't worked on a game with in-app purchases." |
| Owned the post-event review, or owned the retention KPIs | Inflated form of F3 and F7 | "I presented the monthly retention numbers to the studio head." The material says you presented them, not that you owned or calculated them. D1's answer slot stays inside that |
| Managed or owned the release process with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." The material says you wrote it, not that you ran each release |
| Producer-level experience | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |

---

## Sources

**Provided:** your message (the JD text and your background).
**Dossier:** none present. This pack was built from your message and research.

Searches sent:
1. `Saltmarsh Games values` returned https://saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` returned https://saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` returned https://saltmarshgames.com/news/project-larkspur (search snippet only; the page was not fetched)
4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; the page was not fetched)

Pages fetched:
1. https://saltmarshgames.com/values: the three values and their definitions
2. https://saltmarshgames.com/careers/interviewing: the format of the Outage Hour

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; B1 to B3; the value wording used in A2, A3 and A6 |
| 2. `Saltmarsh Games interview process` | yes | Round structure (tabletop plus values conversation), so the Case and Values personas are weighted top, and the cheat sheet is included |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur (from the snippet), which feeds A5, C2's context and R3. Read the full page before Friday |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer; A6; R1 and R2 (from the snippet) |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied already sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your CV** → the fit-snapshot evidence would come from your CV wording, and any responsibilities your message didn't mention could become new rows
- **Your answers to the answer slots on F2, F4, F5 and F7** (who you coordinated with, whether you ran the checklist each release, whether the title was live-service, how the retention numbers were produced) → those four rows get rebuilt with your words, and C1, D1, D2 and D3 get firmer holds
- **An inspectable artifact: the release checklist itself, a calendar export, or a retention deck you presented** (with anything confidential removed) → F4, F6 or F7 could move from `medium` to `high`
- **The recruiter's prep notes for the Outage Hour** → confirms Tobias is the hiring manager and shows whether the tabletop has a set scenario
- **Deeper research: up to 6 more searches and 2 more fetches, several more minutes** → the full Larkspur announcement, the contents of Tobias's GDC talk, and candidate reports of the Outage Hour, which would sharpen A5, A6 and R1
- **A `tuesday-dossier.md`** → evidence you've confirmed and a named top objection would replace this pack's inferred ones
