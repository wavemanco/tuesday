# Interview prep: Engineering Manager, Larkfield Systems (three-round loop)

**Candidate:** Yusuf
**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
1. **Tuesday:** 45 min with the hiring manager, a Director of Engineering (your would-be manager)
2. **The Thursday after:** 60-min panel with two staff engineers and a product manager
3. **The following Monday:** 30 min with the VP Engineering, described by the recruiter as "values and leadership philosophy"

This is a loop pack. It has one shared fit snapshot and prohibited list, then a mini-pack for each round with its own persona weights, question bank and reverse questions. The round structure comes from what you told me, so the persona weights rest on your schedule and not on an archetype.

---

## How to use this pack, and the type key

**Personas** describe how a question is asked: who is asking and in what style. **Types** describe what is being scored. Tuesday's Skeptic and Thursday's Pressure interviewer may ask the same thing, but the delivery differs, so rehearse both.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values or leadership approach this company is looking for |
| EXP | Whether what you say about your work survives close questioning, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth: company, market, strategy |
| CASE | Structure and reasoning on a live problem from the role |

**Answer slots.** Many guidance cells contain an *answer slot*. A slot means the job description makes a follow-up likely, but nothing you have told me says what the honest answer is. Each slot has two branches. If you did the thing, say how in your own words. If you didn't, or it wasn't yours, say so plainly and go back to what you did do. Both branches are good answers. The second one is a limit, not a confession.

The guidance is scaffolding, not a script. Everything this pack says about your past comes from four sentences in your message, quoted in the fit snapshot below.

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description | "3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says one team of six, and the role says two squads and 11 engineers. Keep the words at that scope: "I've been a team lead of six for three years." If you're asked about managing managers, your own words already answer it: "I've never managed managers." Say it plainly and don't soften it. Answer slot: the two-squads line makes a probe on leading more than one team likely. If you have led more than one team or group at once, say when and how, in your own words. If you haven't, say so plainly and stay with the team of six |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | This is a prioritisation decision you pushed through. It is adjacent to owning delivery but doesn't reach it. Words at the quote's scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Answer slot: the own-delivery line makes a probe on how your team's commitments were planned and tracked likely. If that was yours to own, say how, in your own words. If it wasn't, or there was no such process, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running the loop is close to owning hiring but isn't the same thing. Keep your own words: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: the own-hiring line makes a probe on hire or no-hire decisions likely. If those calls were yours, say how you made them. If they weren't, say so plainly and stay with running the loop. The 40 also raises a defend-the-number probe (see D3) |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role description | "3 as a team lead of 6" — your message | low | [inferred] | discovery | Being a team lead doesn't show what you did for your people's growth, and the bridge shouldn't be stretched. Answer slot: if growing the people on your team was part of your job, say what you did, in your own words. If it wasn't, say so plainly and say how you would approach it here |
| F5 | "partner with hardware and product on roadmap" (hardware) — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | No rewording can close this gap, and you have already said so. Words: "I haven't owned a hardware-adjacent roadmap." Then describe how you would learn it, as a plan and never as a past. Never claim hardware roadmap work, and add nothing to make the gap feel smaller. Your sentence covers *owning* such a roadmap. Your material is silent on working alongside hardware teams in any other way, which is the slot in A1 |
| F6 | "partner with hardware and product on roadmap" (product) — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote shows you held a position against roadmap pressure. It doesn't show who you partnered with or how. Answer slot: the product-partnership line makes a probe on working with product likely. If a product partner was part of that trade-off, say what the conversation was and what part was yours. If not, or the pressure came from elsewhere, say so plainly and stay with what you pushed through |
| F7 | "building device-management services" in "industrial IoT" — role description | none given | none | [grounded] | discovery | Your material says nothing about device or IoT work either way, and "currently at a payments company" is all it says about your domain. Answer slot: if any of your work has touched devices, fleets or field hardware, say what, in your own words. If none has, say so plainly and say what from your current work you would carry over |

**Requirement coverage:** which questions rehearse each requirement.

| Requirement | Question IDs |
|---|---|
| Lead two squads (F1) | A2, A4, G2, K3, L1 |
| Own delivery (F2) | B1, B2, H2 |
| Own hiring (F3) | B4, D3 |
| Own growth for 11 engineers (F4) | B3, J4 |
| Partner with hardware on roadmap (F5) | A1, A4, B1, B2 |
| Partner with product on roadmap (F6) | E1, E3, H2 |
| Device-management services, industrial IoT (F7) | D4, D5, K1 |

---

## Prohibited claims (shared)

The pack doesn't coach these claims. Each one is a stretch you might reach for under pressure, and every bank below is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers or team leads | Negative you stated, F1 | "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." No slot |
| "I cut on-call by 60%" (sole or proven cause) | Inflated form of the F2 quote: your sentence says the burden dropped *after* the quarter, not *because of you alone* | The quote as you said it. Which part was yours, and how the figure was counted, are D1's and G1's slots, answered in your own words |
| Led two teams, or a dozen engineers | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says a team of six |
| Owned hiring, or made the hiring decisions | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says you run the loop. F3's slot asks only whether hire calls were yours |
| Personally conducted 40 interviews | Inflated form of F3: "about 40 interviews last year" could mean the loop or you, and the smaller reading wins | Your exact words: "I run our hiring loop for backend roles — about 40 interviews last year." D3's slot asks which part was yours |
| Owned the team's roadmap or delivery | Inflated form of the F2 quote: pushing one quarter through is not owning the roadmap | F2's quote at its own scope. F2's slot stays inside that |

---

# Round 1: Tuesday, hiring manager (Director of Engineering), 45 min

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the jump: one team of six to two squads of 11, and payments to a hardware-adjacent roadmap | High. A hiring manager is buying capability and reducing risk on gaps, and F1 and F5 are the two visible gaps against headline requirements | Rehearse A1 until it's boring. Give the plain acknowledgment first, then a concrete ramp plan, never a bluff |
| Case / Strategist | "How would you run…" problems on their actual squads | High. This is the hiring-manager prior, and the role description names delivery, hiring and growth as things to own | Clarify, then state the objective, then structure, then name the risks. Think aloud and challenge one premise respectfully |
| Conversational | Opener on your journey; questions on what you're proud of | Low to mid. It opens most hiring-manager rounds, and it is still scored | A 90-second arc built only from your quoted sentences |

## Question bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role partners with hardware on the roadmap. You've never owned a hardware-adjacent roadmap — how would you handle that part of the job?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment, unsoftened: "I haven't owned a hardware-adjacent roadmap." Then switch to a plan, said in the future tense: what you would learn first (how hardware milestones are set, which service work depends on them, who decides when dates collide), who you would learn it from, and how you would know in the first few months that you had it. Answer slot: if you have worked alongside hardware or firmware teams in any form, say how and what part was yours. If you haven't, say so plainly and stay with the plan. **Follow-up 1**, "How would you spot a hardware slip early?": answer in plan terms with the questions you would ask, not with experience you don't have. **Follow-up 2**, "Why take the risk over someone who has done it?": hold. Don't claim equivalence. Concede the specific cost, that this part will take you time to learn, and don't fold on whether you can learn it. Point only to what your quotes carry, such as the reliability quarter, at its own scope | F5 is a gap you stated against a headline requirement, and the Director owns the roadmap you would partner on, so this question arrives in some form. Tagged JD because it scores the stated requirement; the delivery is Skeptic. The same objection comes back Thursday through the PM (E1) |
| A2 | "You've been a team lead of six. This is two squads and eleven engineers. What changes?" | JD | [grounded] "3 as a team lead of 6"; "I've never managed managers" | Hold to the quote's scope: "I've been a team lead of six for three years." Then answer forward. Say what you expect to change: you can't be in every conversation, two squads need their own working rhythm, and your time moves from doing to setting context. Say these as expectations, not experience. If asked whether you've managed leads, use your own words: "I've never managed managers." Answer slot: if you have led more than one team at once, say when. If not, say so plainly and stay with the team of six | This is F1's scale gap, and the likeliest second objection. JD because the two-squads line is what's being scored |
| A3 | "Why leave payments for industrial IoT, and why now?" | EXP | [grounded] "currently at a payments company" | Your reason, in your own words. The pack has none from you and supplies none. Selection scaffold: one honest reason you are moving toward something, tied to something in this role description that draws you, and nothing negative about your current employer. If the honest answer is mostly about leaving, say it briefly and turn to what you want next | This is the classic Skeptic motivation probe, made sharper by the domain switch in F7. EXP because it tests whether your story is consistent |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Choose a real gap, not a disguised strength. The one you already named is the obvious choice: "I haven't owned a hardware-adjacent roadmap." Keep it consistent with A1 and give the plan in one line. Don't name a second weakness to seem modest | This tests self-assessment directly, and F5 and F1 are the gaps in your material. JD because it is scored against the listed job |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your squads have a reliability backlog and a hardware launch date product won't move. How do you plan the quarter?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Work it through: clarify first (how bad is the backlog, what breaks if the date slips, what can be cut), then the objective, then the options, including splitting the capacity rather than choosing all or nothing, then how you would make the case and to whom. You can mention your one data point at its own scope: "I pushed a reliability quarter through against roadmap pressure, and on-call dropped 60% after." Offer it as context, not as proof that the same move fits here. Don't describe how you made the case at your current company unless you say it in your own words | This scenario sits on F2 and F5 together, and it is the trade-off this role lives in. CASE because it's a live problem; the reliability quote is optional context |
| B2 | "How would you run delivery across two squads whose work depends on hardware milestones?" | JD | [generic] | Structure it: map the dependencies first, agree how milestone changes get communicated, keep buffers where hardware dates are least certain, set a reporting rhythm with the Director, and decide what you would escalate and when. This question needs no claim about your past, so the guidance makes none | The own-delivery requirement (F2) meets the hardware partnership (F5). JD content with CASE delivery. Labelled [generic] because it is a pattern, not Larkfield's actual process |
| B3 | "You inherit eleven engineers. How do you approach their growth in your first ninety days?" | JD | [grounded] "3 as a team lead of 6" | Forward plan: meet everyone one-to-one, learn what each person wants and what the squads need, find who is ready for more scope, and agree a feedback rhythm. Answer slot: the growth line makes a probe on your track record likely. If developing people on your team of six was yours, say what you did, in your own words. If not, say so plainly and stay with the plan | This is F4's discovery gap, rehearsed so the honest answer is ready. JD because growth is a named responsibility |
| B4 | "You'll be hiring for these squads. How would you set the process up?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with what the quote states: you run the hiring loop for backend roles, about 40 interviews last year. Then say what you would set up here as a plan. Answer slot: if hire or no-hire decisions were yours, say how you made them. If not, say so plainly and stay with running the loop. Keep "about 40" exactly as you said it | F3 is your strongest adjacent evidence against a named requirement. JD primary, EXP secondary |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your journey so far." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with only these beats: nine years in engineering, three as team lead of six, currently at a payments company, running the backend hiring loop, and the reliability quarter. Then one line on why this role, in your own words. Add anything else only as something you say yourself, not something the pack wrote | This opens most hiring-manager rounds and sets how they read everything after it. EXP because every beat can be probed |
| C2 | "What's something you've done as a lead you're proud of?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The reliability quarter, with the beats your sentence states: you pushed it through, against roadmap pressure, and your team's on-call burden dropped 60% after. Answer slot: if you made the case to someone senior, say how, in your own words. If it went differently, say so plainly and tell what you did | A casual question that is still scored. F2 is your headline story, and this is where it first lands |

## Reverse questions, Tuesday

| Question | Why it lands |
|---|---|
| "What would make the first six months a clear success in your eyes?" | It tells you what the person you'd report to will actually measure, and shows you think in outcomes |
| "How are the two squads organised today? Does either have a lead below the manager?" | It tells you whether F1's managing-managers question is live, without raising it defensively |
| "When a hardware date and a services date conflict, how does that get decided today, and who's in the room?" | It turns your biggest gap (F5) into curiosity about how the work runs |
| "What's the biggest delivery risk on these squads right now?" | It shows you're already thinking about the job, and the answer feeds your Thursday prep |
| "How do you like the managers who report to you to bring you bad news?" | It's a working-relationship question your future manager can answer in a way no one else in the loop can |
| "Why is this role open?" | Whether it's a backfill, growth or a reorg changes what the job really is |

---

# Round 2: The Thursday after, panel (two staff engineers and a product manager), 60 min

## Persona table

The panel blends the top two personas for each member's relationship to you.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | The staff engineers take your numbers, the 60% and the 40, down to how they were counted; then technical judgment on device-management problems | High. Two of the three panellists are technical specialists, and your two figures attract probers | Know what you can and can't say about how each figure was counted. Name your weakest assumption before they do, and say plainly when you don't know |
| Peer Evaluator | The PM and staff engineers ask where the seams are, what you would need from them and what they'd get from you | Mid. These are the people you would work beside, so they are pricing what you add to their load | Frame it as reciprocity. Propose principles for the seams rather than pretending to know them |
| Pressure | Interruptions on attribution ("how much was you?") and on the managing-managers gap | Mid to low. Technical panels push follow-ups deliberately | Pause, restate the question, anchor in what you actually said, and hold through two follow-ups |
| Values / Behavioral | The PM asks for stories about trade-offs and disagreement | Low to mid. It's the cross-functional prior, and it's the PM's slot in the panel | Say "we" for context and "I" for your part. Use only story endings you actually have |

## Question bank

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your team's on-call burden dropped 60% — walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Rehearse four things, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. The pack supplies no metric, baseline or method. If you don't know how it was counted, saying so is an honest answer. Name the weakest assumption before they ask | Every headline metric gets a defend-the-number question, and staff engineers will press this one (F2) |
| D2 | "How much of that drop came from the reliability work, versus other things changing at the same time?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your sentence says "after", and that's the claim to hold. Don't upgrade it to "because of". Answer slot: if you know what else changed in that period, say so. If you don't, say so plainly. Either way, say what part of the drop you would attribute to the quarter and why, in your own words | This is the attribution probe on F2, and the prohibited list's "I cut on-call by 60%" is the trap. EXP because it tests precise honesty |
| D3 | "About 40 interviews last year — what does your loop test, and how do you know it predicts how people do on the job?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Keep "about 40" and "run our hiring loop" exactly as you said them. Answer slots: which part of the 40 was yours. If the loop's outcomes are checked against later performance, say how. If they aren't, say so plainly and say what you would want to check here. Describe what the loop tests in your own words | This is the defend-the-number question for F3's figure, and engineers care how candidates get filtered |
| D4 | "A device-management service has to push a config change to a large fleet of devices in the field. How would you want the team to roll it out?" | CASE | [generic] | Clarify first: how many devices, how often they're connected, what a bad change costs, whether it can be rolled back. Then structure the answer: staged rollout, a small canary group, health signals, automatic halt and rollback, and handling for devices that are offline during the rollout. Think aloud, and ask what their current tooling does. No claim about your past is needed | Staff engineers will test your technical judgment in their domain (F7). CASE, labelled [generic] because it's a role-family problem, not Larkfield's system |
| D5 | "You've been building in payments. What carries over to device management, and what doesn't?" | JD | [grounded] "currently at a payments company" | Answer slot: if any of your work has touched devices or field hardware, say what. If none has, say so plainly. Then give your own view of what carries over and what doesn't, as a view rather than experience. Don't describe payments work you haven't told me about as if the pack knew it | F7's domain gap, asked collegially. JD because the device-management line is a stated part of the job |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | (PM) "When product and engineering disagree about the roadmap, how do you handle it?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote: you pushed a reliability quarter through against roadmap pressure, and on-call dropped 60% after. Answer slot: the product-partnership line makes a probe on who you disagreed with likely. If a product partner was on the other side, say how the disagreement went and what part was yours. If not, say so plainly and stay with what you pushed through. Close with how you would want disagreement to work with this PM | This is F6, and the PM is the partner you would have, so A1's hardware gap may come back here in collegial form. JD because product partnership is a named requirement |
| E2 | (Staff engineer) "Where's the line between your call and ours on technical decisions?" | JD | [generic] | Propose principles for the seam rather than claiming to know it: what you'd want them to own, where you'd want a say (cost, people, delivery risk), and how you'd settle disagreements. Ask how it works today | They're pricing whether you'll add to or reduce their load. JD content with CASE delivery |
| E3 | (PM) "What would you need from me in your first month, and what would I get from you?" | JD | [generic] | Give both halves. What you'd need: context on customers and the roadmap, and how decisions get made. What they'd get: say it in your own words, and don't promise anything your material doesn't carry | A reciprocity question, which is common from peers. JD because it touches the product-partnership requirement (F6) |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: how much of that on-call result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause and restate the question. Hold to the quote: you pushed the quarter through, and your team's burden dropped after. Answer slot: say which part of the work was yours and which was the team's, in your own words. Concede specifically where the credit is shared, and don't fold on the part your sentence says was yours, which is pushing the quarter through | This is the time-boxed version of D2 on F2. EXP because it tests attribution under pressure |
| G2 | "You've never managed managers. If this team grows, why not hire someone who has?" | JD | [grounded] "I've never managed managers" | Don't argue the premise, because it's your own sentence: "I've never managed managers." Hold that the role as described is two squads of 11, and what you bring to that is your quotes at their own scope. Concede that you haven't done that layer of management, and don't claim you have. If the follow-up asks how you'd grow into it, give a forward plan | This is F1's stated negative, pushed hard. JD because the two-squads line is scored |

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | (PM) "Tell me about a time you held a position under pressure from someone senior." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped: you pushed the reliability quarter through against roadmap pressure, and on-call dropped 60% after. Answer slot: if the pressure came from someone senior, say who in role terms and how you held your position. If it came from somewhere else, say so plainly and tell the story as it happened. If no other story comes to mind, this is enough | A Values persona question from the PM's seat. F2 is your one held-position story, so rehearse it from a second angle |
| H2 | (PM) "An engineering priority is about to move a date I've promised a customer. What do you do?" | CASE | [generic] | Tell the PM early. Bring options rather than only the news: what slips, what can be cut, and what the risk of not doing the engineering work is. Agree together what goes to the customer. No past claim is needed | This rehearses delivery (F2) meeting product partnership (F6) as a live problem |

## Reverse questions, Thursday

| Question | Why it lands |
|---|---|
| (To the staff engineers) "What could a new manager do in their first month that would genuinely help your work?" | A reciprocity question for peers. It shows you're pricing their load, not only your own |
| (To the staff engineers) "What's the hardest part of the device-management services to change safely today?" | It turns F7's domain gap into informed curiosity and gives you real material for Monday |
| (To the PM) "How does the roadmap get negotiated between product, hardware and these squads today?" | It goes straight at F5 and F6. You learn how the seam works rather than guessing at it |
| (To the PM) "What's one thing the previous setup made hard for you that you'd want a new manager to fix?" | It shows you want to reduce their friction, and the answer is useful context |
| (To any of them) "How does on-call work for these squads today?" | It links to your strongest story without retelling it, and the answer tells you whether reliability is a live issue |

---

# Round 3: The following Monday, VP Engineering, 30 min ("values and leadership philosophy")

The recruiter's description makes this a values-style round. The values cheat sheet is **left out** because Larkfield's published values weren't available: the searches for them were refused, and none were pasted in. The J questions below are themed on the recruiter's words and on the persona's standard questions, not on Larkfield's named values. See the upgrade menu.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" and stories about hard calls | High. The recruiter described the round as "values and leadership philosophy" | Two or three principles you actually hold, each tied to something you did. Say "we" for context and "I" for your part |
| Case / Strategist | Questions at the VP's altitude: what good looks like over the long run, and how you'd grow | Mid. This is the skip-level prior, though tempered by the recruiter's framing | Answer at the level of the org, not individual tickets. Clarify and then structure |
| Pressure | A short, time-boxed "why you" with a challenge on readiness | Low to mid. A 30-minute executive slot leaves little time, which is pressure in itself | Keep answers short. Hold your position, and concede gaps specifically |

## Question bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."; "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold: two or three principles you actually hold, worded your way, each anchored to one thing you did. Your material carries two anchors: the reliability quarter you pushed through, and the hiring loop you run. Let any principle drawn from them be your own conclusion. The pack doesn't name what they prove. If a principle has no story behind it, say so and keep it short | The recruiter's own description says this question is coming. VAL because it is the round's stated purpose |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote, using only its beats. Answer slot: if pushing the quarter through meant telling leadership something they didn't want to hear, say what and how it landed. If it didn't, say so plainly. Then give another story you actually have, or say how you would handle it | This is a standard Values question. F2 is the only quoted story with a stake in it |
| J3 | "Tell me about a call you made as a lead that you'd make differently now." | VAL | [generic] | Selection scaffold: pick a real decision from your three years as a lead, say what you'd change and why, and say what you do differently now. It needs a real decision and a real lesson. If none comes to mind, say so plainly and give the nearest thing you have. Don't invent a failure to seem humble | Leadership-philosophy rounds probe self-reflection. No quote carries a story here, so it's a scaffold |
| J4 | "What do you owe the engineers on your team, and what do they owe you?" | VAL | [generic] | Your own view, in a couple of sentences each way. Tie it to growth (F4's requirement) as something you'd do here, not as a record. If you have a real example from your team of six, tell it in your own words | It covers F4's growth requirement at the VP's altitude. VAL because it's philosophy, not process |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What do you think is hardest about building software for industrial customers, compared with payments?" | CO | [grounded] "currently at a payments company" | Be honest about where your knowledge ends: you know payments from the inside and industrial IoT from the outside. Give your view as a hypothesis, using what you heard on Thursday if anything applies, and ask the VP what they'd add. Don't recite Larkfield facts you haven't verified | Research on Larkfield's strategy couldn't run, so this stays generic (F7). CO because it tests whether you can think at the company's level |
| K2 | "Eighteen months from now, what does good look like for these two squads?" | CASE | [generic] | Structure it: delivery people can rely on (F2), a team that is growing and hiring well (F3, F4), a working rhythm with hardware and product (F5, F6), and service health. Say how you'd know you'd got there. No past claim is needed | This is the VP's question about how far you see. CASE because it's a live plan |
| K3 | "If your team doubled, how would your own leadership need to change?" | JD | [grounded] "I've never managed managers" | Give a forward answer: you'd need leads, and you'd be managing through people for the first time. Your own words cover the rest: "I've never managed managers." Then say how you'd learn it, as a plan | This tests growth at the VP's altitude using F1's stated negative. JD because team leadership is the listed job |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You've been a team lead for three years. Why are you ready to be the manager here?" | JD | [grounded] "3 as a team lead of 6"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold with what your quotes carry: three years as team lead of six, the hiring loop, and the reliability quarter, each at its own scope. Concede the two gaps you've already named, in the same words as on Tuesday. Consistency across rounds is part of what's scored. Don't fold on whether you're ready | This is the readiness objection behind F1 and F5, asked by the person who signs off. JD because it's scored against the listed role |
| L2 | "We're nearly out of time. Why you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Thirty seconds: three beats from your quotes, one line on what you want to build here, and stop | A time-boxed close is common in short executive slots. Rehearse it so you don't ramble |

## Reverse questions, Monday

| Question | Why it lands |
|---|---|
| "What do you see engineering managers here get wrong in their first year?" | It shows you want to calibrate, and the VP is the person best placed to answer |
| "How does engineering leadership here decide between hardware-driven dates and service health?" | It's F5's seam at the VP's level, and you'll have context from Tuesday and Thursday to follow up |
| "What does a great engineering manager here do that a good one doesn't?" | It's the leadership-philosophy question turned back to them, so you hear their values in their own words |
| "How do you expect this org to change over the next year or two?" | Strategy at the VP's altitude. The answer covers what research couldn't |
| "What would you want to hear from me six months in?" | It ends on how you'd work together, and it's short enough for a 30-minute slot |

---

## Sources

**Provided:** the role description, your background and the round schedule, all pasted in your message, plus the recruiter's description of the Monday round as you relayed it. No dossier was consumed.

**Searches sent:**
- `Larkfield Systems values`: refused
- `Larkfield Systems interview process engineering manager`: refused
- `Larkfield Systems industrial IoT news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the Monday values cheat sheet and themed the J bank on Larkfield's named values |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have checked each round's documented format; the persona weights rest on your schedule as you gave it |
| 3. `Larkfield Systems` strategy / recent news | unavailable | The search was refused. It would have grounded K1 and a reverse question in Larkfield's current priorities rather than leaving them generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form. The interviewer read is absent |
| 5. Representative Engineering Manager job description | skipped | The role description you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Larkfield's values page, pasted in or reachable by search → the Monday values cheat sheet, with each value mapped to your stories, and the J bank themed on Larkfield's own value names
- Interviewer names for the Director, the panel and the VP → an interviewer read, persona weights for each panel member, and at least one reverse question tied to each person's career path
- The full job posting, if there's more than the summary → more fit-snapshot rows, with coverage rechecked against its full list
- Your CV → evidence cells beyond the four sentences in your message, and more questions mapped to stories rather than scaffolds
- The recruiter's prep notes for Thursday (any system-design segment, presentation or take-home) → a build section for any announced deliverable
- Your answers to the answer slots on F1 (leading more than one team), F3 (hire decisions), F4 (growth work), F5 (working with hardware teams) and F7 (device work) → those rows regenerate on your own words, and A1, A2, B3, B4 and D5 sharpen
- How much prep time you have before Tuesday → a prioritised prep schedule
- A deeper research pass, if you allow search: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Larkfield's strategy and org context, and grounded CO questions for Monday
- A `tuesday-dossier.md` from an earlier session → evidence already verified, strategy limits for each weak area, and an evidence-based highest-ROI objection instead of an inferred one
