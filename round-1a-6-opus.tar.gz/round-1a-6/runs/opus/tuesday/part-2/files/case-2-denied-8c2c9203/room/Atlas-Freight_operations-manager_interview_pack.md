# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight ("regional logistics, 800 employees")
**Interviewer:** not known. **Round type:** not known. The pack is built for an unknown round, with flat persona weights (see the persona table). Tell me who you are meeting and it gets reweighted.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: friendly, skeptical, time-boxed, numbers-heavy. **Types** describe *what* is being scored.
- Type key:
  - **JD**: can you do the job as listed, gaps included
  - **EXP**: does your experience hold up when someone digs into it, and what was actually you
  - **CASE**: a live problem from the role, scored on structure and reasoning
  - **VAL**: behavioral stories (no published company values were available, so these are generic)
  - **CO**: company knowledge and motivation
- **Provenance labels:** `[grounded]` rests on your own words or the JD. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about you or Atlas.
- An **answer slot** is a spot where only you know the true answer. It gives you two honest branches: say what you did, or say plainly that it wasn't your work or didn't happen.
- The guidance is scaffolding, not a script. Say it in your own words.
- Question IDs go A–E, then G–H. F is kept for fit-snapshot rows.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution operations and one site's surge plan. It doesn't describe terminal operations across four sites, so your words stay at that scope: "Seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the four-site, terminal-operations line makes a probe here likely. If you have worked across more than one site, or in terminal operations, say where and what was yours, in your own words. If you haven't, say so plainly and stay with the site you know |
| F2 | "drive on-time performance" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate is not an on-time measure, and the 40% stays with mis-picks. Don't stretch the bridge. Answer slot: if on-time or dispatch performance was tracked at your site and moved because of work you did, say what was measured and what part was yours. If it wasn't tracked, or the work wasn't yours, say so plainly and say what you would measure first |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material doesn't show any cost work. Answer slot: if you have tracked or moved a cost measure at your site, say which one and what part was yours. If you haven't, say so plainly and walk through how you would approach it |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words at your own scope: "I'm a senior shift manager over three supervisors." The step from three to twelve is the pack's observation, not something you need to say about yourself. Answer slot: the 12-supervisor line makes a probe on leading through others likely. If you have led more people than that at any point, say when and how many. If you haven't, say so plainly and describe how you lead your three supervisors now, in your own words |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | medium | [grounded] | discovery | "Solid Excel" doesn't say whether you have built reports. Answer slot: if you have built reports or trackers in Excel that other people used, describe one in your own words. If you haven't, say so plainly and say what you would build first |
| F6 | "Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | You stated this gap, and wording can't close it. Words: "I've never used Power BI." Then how you will learn it, said as a plan and never as past experience. Never claim Power BI work, and add nothing to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years in ops is not the same as seven years leading people, and your material doesn't say how many of those years were in leadership roles. Answer slot: give the actual number of years you have led people, and in which roles. If it's under five, say the number plainly and don't round up |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but this is a stated certification with nothing inspected behind it, so expect a probe. Lead with it in its own terms: "I'm green belt certified." Answer slot: the Lean/Six Sigma line makes a question on applying it likely. If you used green belt methods on the pick-path redesign or other work, say which methods and how. If you didn't, say so plainly and stay with the certification |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| F1 terminal operations across 4 sites | A1, A2, B3, D1 |
| F2 on-time performance | B1, C3 |
| F3 cost-per-shipment | B2 |
| F4 lead 12 supervisors | A1, G2, H1 |
| F5 Excel reporting | B4, D3 |
| F6 Power BI | A4, B4, D3 |
| F7 5+ years operations leadership | A3 |
| F8 Lean/Six Sigma | E3 |

**Highest-ROI prep in this pack: A1.** The gap in scale (three supervisors at one site, against twelve across four) is the objection most likely to come up in some form, whoever you meet.

---

## Persona table

No loop source says how many rounds there are or who runs them, so this pack falls back to the **generic archetype** (screen → hiring manager → panel). The weights below are flat. They rest on a common pattern, not on Atlas Freight's documented process. The ordering only follows where the fit snapshot's gaps press hardest.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the scale and setting gaps in F1, F4 and F7 | Flat. Listed first because F1 and F4 are the snapshot's biggest gaps, and any hiring manager has to derisk them | Rehearse A1 until it's boring. State the limit before you're asked, then give a concrete ramp plan |
| Case / Strategist (B) | Live problems on on-time performance, cost-per-shipment and multi-site reporting | Flat. The JD names these as the job's outputs, so they're natural case material | Clarify, then objective, segment, approach, metrics, risks. Think out loud |
| Data-Driven Prober (C) | Digs into the 40% and the surge plan | Flat. A figure like 40% attracts probers in any round | Know how the figure was counted, or say plainly that you don't. Name your weakest assumption first |
| Pressure (D) | Time-boxed "why you" and "how much was you" questions | Flat. Common in panel rounds, and the gaps give it something to push on | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Conversational (E) | A friendly career walkthrough and "why Atlas" | Flat. Almost every round opens this way, and it's still scored | A pre-built 90-second arc made only of your own facts |
| Values / Behavioral (G) | "Tell me about a time" stories | Flat. No published values were available, so these are generic | Pick real stories. "We" for context, "I" for your contribution |
| Peer (H) | A supervisor or fellow site lead asking about working with you | Flat. Plausible in a panel round | Talk about what you'd bring them, not only what you'd need |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads 12 supervisors across four sites. You lead three today. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **Highest-ROI rehearsal.** Start with your current scope, in your own words: "Today I'm a senior shift manager over three supervisors." Then the heaviest thing you've run: "I ran the site's peak-season surge plan two years running." Answer slot: if peak season meant leading more people or shifts than usual, say how many and what was yours. If it didn't, say so and stay with the plan you ran. Then a ramp plan, said as a plan: what you'd do in your first weeks at each of the four sites and with each supervisor, in your own words. Hold through two follow-ups by coming back to these facts, never by adding to them. If pushed, concede plainly that the scale is the step up | F4 and F1 are the two widest gaps in the snapshot, and together they make the objection most likely to come up. JD-tagged because it scores the team-size and multi-site requirements directly |
| A2 | "Your background is warehouse and distribution. This is terminal operations. What's different, and how would you close that gap?" | JD | [grounded] "7 years in warehouse and distribution ops" | Your words: "Seven years in warehouse and distribution ops." Answer slot: if any of your work involved terminal operations, say what and where. If it didn't, say so plainly. Then say what you'd want to learn first about how their terminals run, framed as questions you'd ask, not things you already know | F1's setting gap. JD-tagged because "terminal operations" is the JD's own phrase |
| A3 | "The JD asks for five-plus years of operations leadership. How many years have you actually led people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: give the real number of years you've led people, and in which roles. If it's under five, say the number plainly. Don't let "seven years in ops" stand in for seven years of leadership | F7. A stated years requirement is often checked literally, and an answer rounded upward breaks on the second follow-up |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Pick a real gap with a clear ramp: "I've never used Power BI. My Excel is solid." Then your learning plan, said as a plan. If you've started learning before the interview, say exactly what you've done and nothing more | F6 is a gap you stated yourself, so naming it reads as honest self-assessment rather than a dodge. JD-tagged because the answer has to be one of the listed requirements |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals has slipped for three weeks. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and measured, and whether it's one site or spreading. Segment it: by shift, day, customer and type of freight. Ask what changed: volume, staffing, process, equipment. Talk to that site's supervisor early. Then the fix, how you'd measure it, and how you'd keep it from coming back. The question needs no claim about your past, so the guidance makes none | A live problem built on the JD's on-time line (F2's requirement), asked as a decision rather than a record |
| B2 | "We want cost-per-shipment down this year without hurting on-time. Where do you start?" | CASE | [generic] | Clarify what goes into cost-per-shipment here. Break it into its biggest parts and find the largest lever. Name the risk to on-time out loud and say how you'd protect it. Pilot at one site, then track cost and on-time side by side every week. Challenge one premise politely, for example whether the target applies equally to all four sites | F3 has no evidence behind it, so a structured approach is your strongest honest answer. CASE because it tests reasoning on the JD's own metric |
| B3 | "Our four sites all run a bit differently. How would you standardize without breaking what works?" | CASE | [generic] | Map how each site works today. Agree on a few shared metrics. Find the best performer on each metric and learn why. Standardize a small number of things first, and bring the supervisors in so they own the change. Say what you'd deliberately leave local | F1's multi-site requirement, asked as a forward problem, so experience you don't have isn't required |
| B4 | "What would the weekly operations report for four terminals look like if you built it?" | JD | [grounded] "solid Excel, never used Power BI" | Content first: on-time and cost-per-shipment (both named in the JD), by site, with trends and exceptions. Then the tool, honestly: "My Excel is solid. I've never used Power BI." Answer slot (F5): if you've built reports in Excel that others used, describe one. If you haven't, say so plainly and say how you'd build this one. Then the Power BI ramp, said as a plan | Covers F5 and F6 together. JD content with CASE delivery: the report design is the case, and the tool question is the JD check |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate 40%. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer each in your own words: how the 40% was counted (from what starting point, over what period), what it's sensitive to, and the assumption behind it you'd defend least. Say that assumption before they ask. If you don't know exactly how it was counted, say so. That's an honest branch. Never estimate a baseline on the spot | The headline figure, and the one a prober goes after first. EXP because it tests whether the number holds up |
| C2 | "What did the pick-path redesign involve, and what part of it was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your sentence carries: the pick path was redesigned, and the mis-pick rate fell 40%. Answer slot: say which part was yours. If others shared the work, say who did what. If it was mostly yours, say that plainly. Describe what changed in the path in your own words | The attribution half of the figure. Rehearsed separately from C1 because "what was you" questions come right after "how was it counted" |
| C3 | "How did you know whether the peak-season surge plan worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Your words: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's on-time line makes a measurement probe likely. If the plan was measured, say on what and what part was yours. If it wasn't formally measured, say so plainly and say what you'd measure next time | Your second strongest story, with no figure attached. The premise of a measure is allowed to be false here |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run multi-site terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" "cut mis-pick rate 40% by redesigning the pick path" "green belt certified" | Pause, then answer in three parts from your own facts: seven years in warehouse and distribution ops, the 40% mis-pick reduction from redesigning the pick path, and your green belt. Don't claim multi-site experience and don't run down the other candidate. Close with what you'd bring, in your own words. Stay inside the 60 seconds | F1 under time pressure. The test is composure and staying honest when brevity tempts you to inflate |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede. Hold the part that was yours, in your own words, through two follow-ups. Concede others' share specifically (who, what). If it was mostly yours, don't fold to "it was a team effort" just to ease the tension. Don't claim more than you did | Stress version of C2. The hold-then-concede structure is what's being scored |
| D3 | "You've never used Power BI. Why should we trust you to build our reporting?" | JD | [grounded] "solid Excel, never used Power BI" | Hold: "I've never used Power BI. My Excel is solid." Answer slot (F5): if you've built Excel reports others relied on, give one example. If not, say so. Then the ramp, said as a plan with a realistic timeframe you'd commit to. Concede the gap plainly. Hold that it's a learnable tool, not a missing operations skill | F6 under pressure. A rehearsed, calm answer turns a stated gap into a credibility point |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your career so far." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc made only of these facts: seven years in warehouse and distribution ops, now senior shift manager over three supervisors, the 40% mis-pick reduction from the pick-path redesign, two years running the site's peak-season surge plan, green belt certified. End with why this role is your next step, in your own words | Almost every round opens with this. A tight arc sets up the rest, and an arc made only of your own facts can't be broken by later probes |
| E2 | "What draws you to Atlas Freight?" | CO | [grounded] | The JD's own words are what you know for certain: regional logistics, 800 employees, terminal operations across four sites. Answer slot: give your real reason for wanting this company and this step, in your own words. Don't present facts about Atlas you haven't checked yourself | Research couldn't run (see Sources), so there are no company facts to build on beyond the JD. Labeled grounded on the JD alone |
| E3 | "Have you done much with Lean or Six Sigma?" | JD | [grounded] "green belt certified" | Treat the casual tone as scored. "I'm green belt certified." Answer slot (F8): if you applied it to the pick path or other work, say which methods and how. If you didn't, say so and stay with the certification | F8 is a JD plus item, and plus items often come up casually |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to give your site leadership news they didn't want to hear." | VAL | [generic] | Pick a time you raised a problem upward. It needs a clear stake, what you said and how, and how it landed. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you'd handle it | A standard persona stem. Ops managers carry bad news upward, so it's a likely theme. No published values were available, so it's generic |
| G2 | "Tell me about a time a supervisor on your team was struggling. What did you do?" | VAL | [grounded] | Pick a real instance with one of your supervisors: what you noticed, what you did, and how it turned out. Keep their identity private. If no such time comes to mind, say so plainly, then describe how you'd handle it | Themed on the JD's 12-supervisor line (F4). Leading through supervisors is the core of the role |

### H. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If I were one of your supervisors, what would I notice changing in your first month?" | JD | [generic] | Give your own plan in concrete terms: how often you'd meet, what you'd ask them, what you'd leave alone at first, and what you'd expect back. Talk about what you'd bring them, not only what you'd need | A peer or supervisor on a panel prices how the hire changes their own work. JD-tagged because it tests the leadership requirement (F4) |
| H2 | "How do you handle credit when an improvement involves several people?" | VAL | [generic] | Pick a real improvement that involved others. Name who did what, and your own share plainly. If no such time comes to mind, say so, then describe how you'd handle it | A standard peer stem. It also prepares you for D2's attribution pressure in a gentler register |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and where does each site stand against target?" | Shows you'd start with the definition. It also tells you how big the job really is |
| R2 | "What goes into cost-per-shipment here, and which part has been hardest to move?" | Signals a structured approach to the JD's second headline metric |
| R3 | "How are the 12 supervisors spread across the sites, and how long have they been in role?" | Shows you're already thinking about leading through them. The answer shapes your first 90 days |
| R4 | "What reporting exists now in Excel or Power BI, and what would you want built first?" | Gives you the real scope of the reporting work and of your Power BI ramp |
| R5 | "What would make the first 90 days in this role a success?" | Gets the success criteria in their words, which you can mirror in follow-up answers |
| R6 | "Why is this role open right now?" | Context on whether you'd be inheriting a backlog, a growth push, or a departure |
| R7 | "What are the next steps, and who else will I meet?" | Lets you prepare for the next round with real names and round types |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed multi-site or terminal operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says warehouse and distribution ops and one site's surge plan. A2's slot stays inside what you did |
| Led a team the size of twelve supervisors | Inflated form of F4 | F4's quote: "I'm a senior shift manager over three supervisors." A1's slot only asks whether you've led more at any point |
| Seven years of operations leadership | Inflated form of F7 | Seven years in ops, as you said it. A3's slot asks for the real leadership years |
| Improved on-time performance or cut errors by 40% | Inflated form of F2 (the 40% belongs to mis-picks) | F2's quote: the mis-pick rate fell 40% from redesigning the pick path. On-time is an answer slot |
| Designed or built the surge plan from scratch | Inflated form of "ran the site's peak-season surge plan" | "I ran the site's peak-season surge plan two years running." C3's slot stays inside running it |
| Led Six Sigma projects, or any belt above green | Inflated form of F8 | "I'm green belt certified." E3's slot only asks how you applied it |
| Has used Power BI | Negative you stated, F6 | "I've never used Power BI." No slot. A plan is fine, a past claim is not |

---

## Sources

- **Provided:** your message, containing the JD text and your background. Every quote in this pack comes from it.
- **Searches sent:**
  - `Atlas Freight regional logistics values`: refused (permission not granted)
  - `Atlas Freight interview process operations manager`: refused (permission not granted)
  - `Atlas Freight terminals news 2026`: refused (permission not granted)
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have supplied the company's published values to theme G-bank questions. Without a loop source, no values round is detected, so section 10 would still be dropped |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have given the loop structure and replaced the flat generic-archetype weights |
| 3. `Atlas Freight` strategy / recent news | unavailable | The search was refused. It would have grounded E2 and added a CO or CASE question on current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Operations Manager JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Who you're meeting and what kind of round it is (hiring manager, panel, recruiter screen) → real persona weights in place of flat ones, with banks resized to match
- The interviewer's name → a read of their public professional footprint, persona tilts, and a reverse question tied to their career path
- The recruiter's prep email or any stated focus areas → coverage of anything pre-declared, such as a presentation or a case
- Your CV text → evidence cells quoted from your own CV lines, with possible upgrades on F1, F4 and F7
- Permission to search → targets 1–3 run: Atlas Freight's values, interview process and recent news, which ground E2 and add a company-specific case question
- Deep research (up to 6 more searches and 2 more fetches, several more minutes) → strategy context, loop reports and recent org changes for the CO and CASE banks
- Your answers to the slots on F2, F3, F5 and F7 (on-time tracking, cost measures, Excel reports, years leading people) → those rows rebuilt on your words, and A3, B2, B4, C3 and D3 story-mapped
- Your green belt certificate → F8's confidence rises from medium to high
- How much prep time you have → a prioritized prep schedule
- A `tuesday-dossier.md` → carries verified evidence and named objections between sessions; this pack doesn't need one
