# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes, Tuesday
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director
**Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."

This pack was built with no JD and no web research (all six searches were refused, see Sources). The market report you read wasn't shared here, so everything about Kelverton and the rail market is a structure for you to fill from that report, not a claim about it.

---

## How to use this pack

- **Personas** describe how a question gets asked (who's asking and in what style). **Types** describe what's being scored.
- Type key:
  - **VAL**: whether your past behaviour shows the values they care about
  - **EXP**: whether your stated experience holds up under scrutiny, and what was actually yours
  - **JD**: whether you can do the job they're hiring for, gaps included
  - **CO**: company and market knowledge, whether you can think at their altitude
  - **CASE**: a live problem from the role, reasoned through out loud
- **Answer slot** means the pack doesn't know the answer and won't make one up. It names a likely probe and gives you two honest branches. Fill it from what actually happened.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage (about 4 hours)

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 60 min | Build the POV: choose your reading of "operator partnerships", pick one thesis, draft the three moves, and pull 3 points you can cite from the market report | Section: Graded deliverable |
| 2 | 45 min | Say the POV out loud twice with a timer. Aim for 13 minutes so you have 2 minutes of buffer | Graded deliverable, run-of-show |
| 3 | 45 min | The highest-ROI prep: B1 (no direct quota) and D1 (how the £4M was counted). Write out your own answers to both slots | B1, D1, C2 |
| 4 | 30 min | Ross's commercials: the year-one number, partners against direct sellers, what you'd measure | C1, C3, A4 |
| 5 | 20 min | The rail gap: no rail selling, and bus and light rail planning against train operators | B2, B3 |
| 6 | 20 min | Pick 3 reverse questions, at least one for each panellist | Reverse questions |

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | What your material shows is a partner channel you ran in payments. It doesn't show operator partnerships in rail, so keep the words at that scope: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: a POV invites "what would you bring from that". If a specific choice you made in that channel shapes your plan, name it in your own words. If none does, say so plainly and let the plan stand on its own reasoning |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The scope is consulting, on bus and light rail, doing network planning. That isn't train operators, and it isn't scheduling software. Words: "Before that I spent five years in transport consulting, on bus and light rail network planning." Answer slot: "the other side" invites "which side?". If your clients were operators, transport authorities or both, say which. Don't leave the panel to assume |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Keep both qualifiers, roughly and influenced, every time you say the figure. Answer slot (D1): how it was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part of it was yours, all in your own words. "I don't know exactly how it was counted" is an honest branch |
| F4 | Owning a direct revenue target, a common expectation for senior partnerships roles (no JD in hand) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so yourself. Words: "I haven't carried a direct quota; my number was influenced revenue." Then what you would sign up to here and how you'd want it counted, said as a plan and never as a past. Add nothing to make the gap feel smaller |
| F5 | Selling into rail operators, from your description of what the company sells | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I haven't sold into rail." Then your ramp plan, said as a plan. F2's consulting stays at its own scope next to it and never stands in for rail selling |
| F6 | Scaling a partner programme, a role-family expectation | "took it from 6 partners to 40" — your message; "9 years in partnerships" — your message | medium | [grounded] | none | No gap, but there's no CV and nothing inspected behind it, so expect a probe (D2, D3). Lead with the count in your own terms. Six partners existed when you started, so the sentence is "took it from 6 to 40", never "built" |
| F7 | Managing senior, multi-party partner relationships where interests conflict, a role-family expectation | none given | none | [generic] | discovery | Strong evidence looks like one named partner relationship where what the partner wanted and what your company or its customers needed pulled apart, and you held a position. Selection scaffold: pick that partnership, name the stake, the moment you didn't fold, and how the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

---

## Graded deliverable: the 15-minute POV

### What you're building on

- **The brief, in the recruiter's own words:** "where you'd take our operator partnerships over the next 18 months", "no slides needed", "Please land on what it means for the operators themselves", "Ross will push on commercials".
- **Your experience:** F1, "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue". F2, "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". F4, "never carried a direct quota, only influenced revenue". F5, "Never sold into rail specifically".
- **The market report:** you've read it and I haven't. It's also the one source everyone in the room shares, which is why the differentiation strategy below is built around it.

### Decide this first: what "operator partnerships" means

The phrase can be read two ways:

- **Reading 1:** partnerships *with* the operators themselves (design partners, co-development, strategic accounts).
- **Reading 2:** the partner ecosystem that serves operators (integration partners, resellers, consultancies).

Check how the report uses the phrase. Then say which reading you're taking in your first 30 seconds, and say that the other reading exists. That one sentence shows judgement before you've made a single argument.

### Thesis options (pick one to lead, keep one in reserve)

| Thesis | The argument | Mandatory concession | What it means for operators | Provenance |
|---|---|---|---|---|
| T1. Integration ecosystem first | Over 18 months, partner with the vendors whose systems sit around scheduling, so operators get connected workflows instead of one-off integration projects | Integration partnerships take engineering time and show revenue slowly. Say so before Ross does | Fewer bespoke integration projects, and data that moves between systems without manual effort. Frame these as outcomes you'd test, not promises | [generic] |
| T2. A small number of operators as design partners | Pick a few operators to co-shape the product and the partner programme, and use them as reference customers | It risks building for one operator's quirks, and other operators may see favouritism. Name how you'd guard against both | Product that reflects how operators actually run, and earlier influence over the roadmap | [generic] |
| T3. Route to market through firms already advising operators | Partner with consultancies and integrators operators already trust, so they open doors Kelverton can't open alone | Margin share, and losing the direct relationship. Also the partner's incentive may not match yours | A trusted adviser carries the implementation, which lowers the risk of a change for the operator | [generic] |

Where your experience touches these: F1's ISV channel is closest in shape to T1. A channel of software vendors in payments is still a different kind of partner from a rail-systems vendor, so say what carries over in F1's words and don't claim the match.

### Differentiation: don't recite the report

The panel has the same report. Reciting it scores as homework. Departing from it with reasons scores as judgement.

1. **One consensus point**, cited to the report by name, to show you've done the reading.
2. **One divergence**: a place where you'd weight things differently from the report, or sequence them differently, and why.
3. **One anti-pick**: something you would *not* do in the first 6 months. A candidate shape: no partner-count target until the commercial model per partner is proven. Use it only if the report gives you the reason, for example a concentrated operator base. If you use it, expect "you went from 6 to 40 though?". Your honest answer is in F6's words, plus what you'd do differently here and why.

### Run-of-show (aim for 13 minutes)

| Time | Beat |
|---|---|
| 0:00–1:00 | Your reading of "operator partnerships", your one-sentence thesis, and what you're basing it on: the report, plus your background stated at its real scope (F1, F2), including that you haven't sold into rail (F5) |
| 1:00–3:30 | Where things stand: 2–3 points from the report, one of them the consensus point |
| 3:30–9:00 | Three moves, at 0–6, 6–12 and 12–18 months. For each one: what you'd do, how you'd know it worked, and the concession |
| 9:00–11:00 | Commercials, before Ross asks: how partnerships make money for Kelverton (referral, resale margin, co-sell, or integration listing; pick what fits your thesis) and how you'd count it, sourced against influenced (this sets up B1) |
| 11:00–13:00 | The close they asked for: what changes for an operator, two or three outcomes, each framed as something you'd measure |

---

## Persona table

The recruiter's email establishes the loop: one session, a panel of two, a 15-minute POV, then Q&A. It names no values round. There's no public information about either panellist in hand, so weights come from their roles and the recruiter's words.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa extends the POV: first 90 days, priorities, metrics | High. She's the hiring manager, who usually buys capability through live problems, and the POV makes strategy the core of the hour | Clarify, then objective, approach, metrics, risks. Think out loud. Use the report's vocabulary |
| Skeptic | Quiet probing of the two stated gaps, no quota and no rail | High. Both gaps are on record in your own words (F4, F5), and a hiring manager is there to reduce risk | Rehearse B1 until it's boring. Plain acknowledgment, then plan |
| Pressure | Ross time-boxes, asks for numbers on the spot, plays devil's advocate on partner economics | Medium-high. "Ross will push on commercials" is the recruiter's own warning, and a commercial director often tests composure on numbers | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Data-Driven Prober | Unpicks "6 to 40" and "£4M influenced" | Medium. Both are your headline figures, and they're the obvious target for a commercials push | Know what you can and can't say about how each figure was counted. Name the weakest assumption first |
| Peer Evaluator | Ross on where partnerships and direct sales collide | Low-medium. Ross runs the function that partnerships sits next to | Propose principles for the seam, and frame it as reciprocity |
| Conversational | The opener, and the closing chat | Low, but still scored | A 90-second career arc |
| Values / Behavioural | One or two "tell me about a time" questions | Low. No values round is named | Selection scaffolds with honest branches |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you only had the first 90 days of that plan, what would you do?" | CASE | [generic] | Four beats: what you'd need to learn first (current partners, operator relationships, pipeline data), who you'd meet in weeks 1–4, one small test you'd run, and what you'd report to Deepa at day 90. The question needs no claim about your past, so the guidance makes none | The usual next question from a hiring manager after a long-horizon POV. CASE because it scores structure under a shorter horizon |
| A2 | "How would you decide which partners to go after first?" | CASE | [grounded] "took it from 6 partners to 40" | Give criteria: overlap with Kelverton's operators, integration effort, how the partner makes money with you, and whether the partner has a reason to prioritise you. You can mention the channel in the quote's own words as what happened. It isn't a method unless you say one was yours | It tests whether the POV's priorities are reasoned. F6 is the nearest evidence, held at its scope |
| A3 | "What does an operator actually get from our partnerships that it wouldn't get buying from us directly?" | CASE | [generic] | This is the recruiter's requested close, asked as a challenge. Name two or three operator outcomes from your thesis table, tie at least one to a point in the report, and say how you'd check each one. Don't promise outcomes | The recruiter flagged operator benefit as the landing point, so expect it to be tested. CASE with CO content |
| A4 | "What would you measure at 6, 12 and 18 months?" | CASE | [generic] | Leading indicators first (partners active, integrations live, joint pipeline), lagging ones second (partner-sourced revenue, operator retention or expansion). Say which ones you'd want Ross to sign off as the commercial measures | It links the POV to Ross's commercials push. CASE because it's a design problem |
| A5 | "Which part of your plan are you least sure about?" | CASE | [generic] | Give the concession from your lead thesis, then what evidence would change your mind and how soon you'd have it. Holding a plan while naming its weakest point is the move | It tests self-calibration. Strategy panels commonly ask it right after a POV |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why should we trust you with a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Acknowledge it first, plainly: "I haven't carried a direct quota; my number was influenced revenue, roughly £4M." Then plan, not past: how you'd want partner revenue counted here, the target you'd agree after a ramp, and how you'd report against it. Answer slot: the recruiter's commercials line makes a probe likely. If a target was set on that influenced figure and you reported against it, say what, in your own words. If none was, say so plainly and stay with the figure. Hold through two follow-ups. "Influenced is soft" gets how it was counted (D1). "So you've never been accountable" gets "not for a direct quota, no", and then you return to what the quote carries. Don't fold, and don't add | F4 is the most predictable objection, and the recruiter named commercials as Ross's line. Nothing is more likely to be asked, and nothing is more tempting to thicken. JD because it scores a core requirement |
| B2 | "You've never sold into rail. How do you get credible with operators quickly?" | JD | [grounded] "Never sold into rail specifically"; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Start with "I haven't sold into rail." Then the consulting years in their own words, bus and light rail network planning, with no extension to train operators. Then a ramp plan: who you'd learn from inside Kelverton, which operators you'd sit with, and what you'd read | F5 is the second stated gap. F2 is the honest neighbour, as long as it stays at scope |
| B3 | "Your consulting was bus and light rail network planning. What from that carries over to working with train operators?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Describe what the work was, in your own words, and let them draw the connection. Answer slot: if your clients were operators, authorities or both, say which. That's what "the other side" will be tested on. Don't claim scheduling or train-operator knowledge the quote doesn't carry | F2's bridge is where a relationship or kind drift is most tempting. EXP because it tests what the work actually was |
| B4 | "Payments ISVs and rail-tech partners are different worlds. Why would your channel approach work here?" | JD | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Don't argue that it will. Say what you'd keep and what you'd test first, and concede the differences you'd expect, like partner economics and how buyers buy. Answer slot: if a specific lesson from that channel shapes this, name it in your own words. If none does, say the plan stands on its own reasoning | F1's transferability limit, asked directly. JD because it scores fit to the role |
| B5 | "Why leave payments for rail, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your own reasons, in your own words. You can mention the consulting years as the link, at their scope. If the reason is a return to transport, say what draws you back, in your own words. Keep it to 60 seconds and positive about payments | A standard motivation check. A skeptic tests whether the story holds together |

### C. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Give me a year-one revenue number for partnerships. Right now." | CASE | [generic] | Pause. Don't invent a figure. Hold: say what you'd need to set it (current partner pipeline, deal sizes, sales cycle) and when you'd commit to one, for example inside your first 90 days. If he pushes twice, concede that you can't give a credible number without that data and offer to set out how you'd build it. A guessed number gets torn apart | The recruiter's commercials warning, asked in its sharpest form. It tests composure, not arithmetic |
| C2 | "Roughly £4M influenced. Is that actually a big number?" | EXP | [grounded] "roughly £4M of influenced revenue" | Don't argue about size. Answer slot: over what period it was counted and what it compared against, if you know. If you don't, say so plainly and stay with the figure as you gave it. The quote doesn't say whether £4M was total or per year, so make sure you know which before Tuesday, and say it the way you can defend | F3's figure under pressure. The ambiguity in it is exactly what a commercial director will find |
| C3 | "Partners take margin. Why not just hire two more direct sellers?" | CASE | [generic] | Compare on reach, cost of sale and what the operator gets. Concede where direct selling wins, for example on the largest accounts. Your POV's thesis is your answer for where partners win | A classic commercial challenge to any partnerships plan. CASE because it's a trade-off decision |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M influenced figure was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you'd defend least (name it before they do), and which part was yours. "I don't know exactly how it was counted" is an honest branch. Never supply a method you didn't use | F3's headline figure. Influenced revenue is the kind of number a prober unpicks first |
| D2 | "Of the 40 partners, how many were actually producing?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know how many were active, say so, with how "active" was judged. If you don't, say so plainly. Don't estimate on the spot | F6's count invites the denominator question |
| D3 | "Six to 40: how much of that was you, and how much the market or the team?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40" | Use "we" for context and "I" for what was yours. Answer slot: if particular decisions in that growth were yours, name them. If the growth was largely the market or others, say so and name your part | An attribution probe. The honest version of this answer is what earns credibility |

### E. Peer Evaluator (Ross, at the seam)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A partner brings a deal my team was already working. Who gets credit?" | CASE | [generic] | Propose principles: rules of engagement agreed upfront, a way to register deals, and one counting rule that both teams' numbers follow. Don't pretend to know how it works at Kelverton today. Ask | The partnerships and sales seam is Ross's territory. CASE, peer delivery |
| E2 | "What would you need from the commercial team in your first quarter?" | CASE | [generic] | Reciprocity: what you'd give his team (partner-sourced pipeline, intelligence on operators) before what you'd ask for (account access, a shared counting rule) | It tests whether the hire adds to or reduces his load |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk us through your journey so far." | EXP | [grounded] "9 years in partnerships"; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc in order: consulting (bus and light rail network planning), then the ISV channel (6 to 40, roughly £4M influenced), then why this role. Every clause comes from the quotes, at their scope | Almost certain as an opener, and scored on economy |
| F2 | "What did you make of the market report?" | CO | [generic] | One point you agree with, one where you'd differ, and why. You've read it and this pack hasn't, so this is yours to prepare. Never correct the authors' framing in front of them. Just offer your view | The recruiter sent it, so they may ask. CO because it tests homework depth |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time when what customers needed and what your number needed pulled apart, and you chose the customer. It needs a named stake, the choice, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's emphasis on "what it means for the operators themselves" makes customer-first framing likely |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, the moment you didn't fold, and a working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common senior-hire probe. A future manager tests whether you'll bring bad news upward |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 POV on operator partnerships, 18 months | Graded deliverable; A1, A2, A5, B4 |
| F2 Land on what it means for operators | Graded deliverable close; A3, B3, G1 |
| F3 Ross will push on commercials | A4, C1, C2, C3, D1 |
| F4 Owning a direct revenue target | B1 |
| F5 Selling into rail operators | B2 |
| F6 Scaling a partner programme | D2, D3, F1 |
| F7 Senior multi-party partner relationships | E1, G2. A JD would show whether this needs its own question |

---

## Reverse questions

| # | Question | For | Why it lands |
|---|---|---|---|
| R1 | "Eighteen months from now, what would make you say this hire worked?" | Deepa | It gets her success criteria in her own words, and you can check your POV against them on the spot |
| R2 | "How do you want partner revenue counted against your number: sourced, influenced, or both?" | Ross | It shows you understand the distinction your own figure rests on, and turns B1's weak spot into a working conversation |
| R3 | "Which operators already treat Kelverton as a partner rather than a supplier, and what made the difference?" | Both | It ties to the operator benefit they asked you to land on, and reveals what's already working |
| R4 | "What exists today that I'd inherit: partners, agreements, pipeline?" | Deepa | It grounds your 90-day plan (A1) in reality, and signals that you'd start from what's there |
| R5 | "Where do partnerships and direct sales collide most today?" | Ross | It opens the seam (E1) on your terms, and shows you'd rather solve it early than discover it later |
| R6 | "Where would you push back on the strategy team's report?" | Both | It invites their divergence after you've offered yours, so it reads as a peer conversation |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried or hit a direct sales quota | Negative you stated, F4 | "I haven't carried a direct quota; my number was influenced revenue." No slot |
| Has sold into rail | Negative you stated, F5 | "I haven't sold into rail." No slot |
| Generated, closed or sourced £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The material says influenced, not sourced or closed. D1's slot stays within how the influenced figure was counted |
| Built or founded the ISV channel | Inflated form of F1 and F6 | "took it from 6 partners to 40". Six partners existed already, and the material doesn't say you started the channel |
| Heavy-rail or train-operator experience | Inflated form of F2 | F2's quote at its own scope: consulting, on bus and light rail |
| Worked inside or for an operator | Inflated form of F2, relationship axis | "the other side", in your own words. B3's slot asks which side, and stays inside the consulting work |
| Rail scheduling or timetabling expertise | Inflated form of F2, kind axis | Network planning, in your own words. The material doesn't connect it to scheduling software |

---

## Sources

- **Provided:** your message, including the recruiter's email as you quoted it.
- **Referenced but not provided:** the market report from Kelverton's strategy team. You've read it, but its content isn't in this conversation, so nothing in this pack comes from it.
- **Searches, all refused** (web search permission wasn't granted):
  - "Kelverton Rail values": refused
  - "Kelverton Rail interview process partnerships": refused
  - "Kelverton Rail scheduling software train operating companies news": refused
  - "Deepa VP Partnerships Kelverton Rail": refused
  - "Ross Commercial Director Kelverton Rail": refused
  - "Senior Partnerships Manager rail software job description UK": refused
- **Fetches:** none.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused. Would have given published values to theme G1 and G2. No values round is named, so no values cheat sheet either way |
| 2. Kelverton Rail interview process | unavailable | Refused. The recruiter's email already sets out the session, so it would have only cross-checked it |
| 3. Kelverton Rail strategy and news | unavailable | Refused. Would have grounded the POV theses, A3 and F2 in current company moves. The market report you hold would do the same job |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Both refused. Would have given an interviewer read, persona weights from their public footprint, and a reverse question tied to their paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | Refused. Would have turned F4 to F7 from role-family prose into quoted, `[inferred]` requirements |

---

## Upgrade menu

- **The market report's key points**, pasted or summarised in your words → the thesis table and A3 become `[grounded]` in the report's own figures, and the consensus point, divergence and anti-pick get filled in concretely
- **The JD text** → F4 to F7 become quoted requirements, the coverage check runs against the real list, and any requirement this pack missed gets a question
- **Web search permission** → the five L1 targets above run: an interviewer read for Deepa and Ross, current-strategy CO questions, and published values. After that, an optional deeper pass (up to 6 more searches and 2 more fetches, several more minutes) on Kelverton's strategy and recent org context
- **Your answers to the slots in F1, F2 and F3** (how the £4M was counted and over what period, and which side of the operator world your consulting sat on) → B1, B3, C2 and D1 move from slots to story-mapped guidance
- **A tuesday-dossier.md** → verified evidence and a prohibited list checked against more than one message. This pack is complete without it
