# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 5 December 2026 · **Mode:** loop (three scheduled rounds)

| Round | Length | Who | What the recruiter said it holds |
|---|---|---|---|
| 1 | 30 min | The recruiter | Screen |
| 2 | 45 min | Head of Member Services, your would-be manager | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | "a 20-minute case on a complaint escalation"; "also the values round — they score against the four values" |

Interviewer names haven't been assigned yet, so there's no section on reading individual interviewers. Persona weights come from each round's role and from the recruiter's description.

---

## How to use this pack

- **Personas** describe *how* a question is asked: the interviewer's style. **Types** describe *what* is being scored.
- Question IDs use one letter per persona (A1, B2…), and they're unique across all three rounds. Fit-snapshot rows are F1–F9.
- **Guidance is scaffolding, not a script.** Any line in quotation marks for you to say is proposed language, pending your approval. If a word isn't how you'd say it, change it.
- **Answer slot** means the pack won't supply the detail, because only you know it. Each slot has two honest branches. Either one is a good answer.
- **Provenance labels:** `[grounded]` traces to something you or Ashgrove supplied. `[inferred]` is the pack's own derivation, and the derivation is named. `[generic]` is a pattern for this kind of role with no Ashgrove-specific claim.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values |
| EXP | Whether what you say about your experience survives follow-up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

---

## Fit snapshot (shared by all three rounds)

Every line here that is meant for you to say is proposed language, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, so your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on the log's stages likely, from a complaint arriving to it being closed. If any stage was yours to decide, say which and how, in your own words. If none was, or there was no such step, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Words: "I haven't worked in a contact centre." Then say how you'd learn that side, as a plan and never as past experience. Add nothing that makes the gap sound smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The spreadsheet is monthly and about complaints. Your material doesn't say what it counts. Answer slot: if it tracks volumes, resolution times or both, say which, in your own words. If it tracks something else, say what, and say plainly that it doesn't track these |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your material says "spreadsheet" and doesn't name the tool. Answer slot: if it's built in Excel, say so and say what you set up in it yourself. If it's built in another tool, name the tool and say so plainly |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material says you trained new tellers, not that you coached supervisors. Supervisor is the role you hold. Words: "I trained new tellers on our escalation script, and for the last three years I've been a branch supervisor." Answer slot: expect a probe on how you trained them. If you had a particular way of doing it, describe it in your own words. If it meant taking them through the script, say exactly that |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | Your material says "formal", not "regulated", and the pack won't swap the words for you. Answer slot: if the log's complaints fell under a regulator's complaint rules, say which rules and which part of handling them was yours. If you don't know, or they didn't, say so plainly and stay with the log |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Words: "I haven't presented above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words. If you haven't presented at all, say so plainly. Then say how you'd prepare for a first senior audience, as a plan |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Strong evidence would be a time you fed what members told you into an online, app or self-service change. Answer slot: if you've done this, say what happened and which part was yours. If you haven't, say so plainly and move to how you'd start working with the digital teams |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | This is the quote reworded and nothing more: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer connect retail banking to customer operations. Don't relabel your experience yourself |

**Requirement coverage:** every requirement and responsibility in the JD, with the questions that cover it.

| JD line | Covered by |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | D1, B3, J1, K2 |
| "report monthly on complaint volumes and resolution times" | G1, E2, K3 |
| "coach branch supervisors on escalations" | D3, K1 |
| "work with digital teams on self-service journeys" | E3, E1 |
| "4+ years in financial-services customer operations" | A1, A7 |
| "experience handling regulated complaints" | B1, C1 |
| "confident presenting to senior leaders" | D2, G2 |
| "comfortable with Excel reporting" | B2, G1 |

**Highest-ROI prep in the pack: D1.** The role covers complaints "across branches and the contact centre". Your evidence is one branch's log, and you've said you've never worked in a contact centre. Someone will raise this, probably in Round 2 and again in Round 3, so rehearse D1 until it bores you.

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced it, so treat it as graded. You don't know the scenario yet. This section is a build kit, and every line in it for you to say is proposed language, pending your approval.

**Grounded facts to build on**
- The recruiter's words: "a 20-minute case on a complaint escalation", run by "a panel of two branch managers", who "score against the four values".
- The JD lines the case tests: "Own the member complaints process end to end", "coach branch supervisors on escalations", "report monthly on complaint volumes and resolution times".
- Your side: F1, "I handled the branch's formal complaints log". F5, "trained new tellers on our escalation script". Mention either only at that scope, as the place you're reasoning from.
- Ashgrove's context, from the July 2026 brief as you summarised it: "consolidate eight branches into five hubs over 2027"; "move 40% of member service to digital channels by 2028".

**Structure to say out loud** (about 2 minutes of clarifying, 12 of working, 4 of recommending, 2 spare)
1. **Clarify:** who the member is, what they've already been told, which channel it came through, whether a deadline or regulatory clock applies (ask which one rather than assuming), and who holds it right now.
2. **Objective:** resolve this member's complaint fairly, then stop it happening again.
3. **Approach:** contact the member and acknowledge the complaint in plain words, establish the facts, decide, and explain the decision. Then look for the root cause.
4. **People:** support the branch supervisor who escalated it, rather than taking it off them, unless it has to leave the branch.
5. **Metrics:** whether this member's case closed and how long it took, whether similar complaints repeat, and how it shows up in the monthly report.
6. **Risks:** promising an outcome before you have the facts, and the member having to explain everything twice.

**Thesis options** (pick one to lead with; each comes with a concession you have to say)

| Thesis | Why it lands with this panel | Concession to say out loud |
|---|---|---|
| "Fix it for the member first, then fix the process." | "Members First, Always" and "Own the Fix" both point this way | "The systemic fix comes second, so if this is part of a pattern, a few more members may hit it before it's closed" |
| "Every escalation is data." Resolve this one, then check whether it's a pattern in the monthly numbers | Ties the case to the JD's monthly reporting line | "One case isn't a trend. I'd look before calling it one" |
| "Keep the hold with whoever found it." Coach the supervisor through it instead of taking it over | This is "Own the Fix" word for word, and the panel's own supervisors are the ones you'd coach | "Some complaints have to leave the branch, and I'd say clearly when this is one of them" |

**Differentiation:** the consensus answer is apologise, escalate, resolve, learn. Every prepared candidate gives it. Give it briefly to show you have the basics. Then diverge in two ways. Name which of the four values each step serves, since that's what they score. Then say what the case means for a branch that is about to become part of a hub.

**Anti-pick:** don't offer a goodwill payment or any outcome before the facts are in, and don't say you'd take the complaint away from the branch by default. Each of those is a quick, confident answer that undercuts a value the panel is scoring.

**Close:** the recruiter didn't specify one. End with what you'd tell the member, in one plain sentence, and the one thing you'd measure afterwards.

---

## Grounding brief: Ashgrove vocabulary to sound current

| Item | Detail | Provenance |
|---|---|---|
| Ownership | "member-owned, about 900 staff" — use "members", never "customers" | [grounded] JD |
| Values (official names) | "Members First, Always"; "Plain Words"; "Neighbours, Not Numbers"; "Own the Fix" | [grounded] values page text you pasted, copied 26 November 2026 |
| Channel shift | "move 40% of member service to digital channels by 2028" | [grounded] July 2026 strategy brief, as summarised in your message |
| Branch network | "consolidate eight branches into five hubs over 2027" | [grounded] same brief |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] same brief |
| Competition | "the main competitive pressure is app-only banks" | [grounded] same brief |

Your panel is two branch managers, and consolidation may affect their own branches. Talk about the hubs with care. Don't guess which branches are merging.

---

# Round 1 — Recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly openers: your story, why Ashgrove, logistics | High. This is the standard pattern for a recruiter screen, and 30 minutes leaves little room for anything else | Use the pre-built 90-second arc in A1, and treat every casual question as scored |
| Skeptic, light | Knockout checks against the JD's requirements list | Medium. Recruiters screen against the requirements list, and F2, F6 and F7 are where the list and your material don't meet | Use the plain acknowledgments from F2 and F7 and the answer slots in B1–B3, said without defensiveness |
| Others | Barely present | Low. The recruiter described Rounds 2 and 3 as the behavioural and values rounds | They come later in this pack |

### Question bank

Every line in this bank meant for you to say is proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | 90 seconds, built only from these four quotes, in this order: six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log. You trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. End with one sentence on why complaints work is what you want to do next, in your own words | F9, F1, F5 and F3 are your strongest rows, and this opener sets the frame for the whole loop. EXP because it's your own history, told under light scrutiny |
| A2 | "What's prompting the move now?" | EXP | [grounded] | Logistics slot: give your actual reason in your own words. You haven't told me one, so the pack supplies none. Keep it forward-looking and short | The recruiter reliably asks why you're leaving. EXP because it's about your own history |
| A3 | "What salary are you looking for?" | JD | [grounded] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Standard recruiter logistics. JD because it's about the listed job's terms |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period | Standard recruiter logistics, and it sets the start date |
| A5 | "The role works across branches — where are you based, and how do you feel about travelling between sites?" | JD | [grounded] | Logistics slot: give your actual location, and the travel you can do, in your own words | "across branches" in the JD makes travel a likely question. JD because it's about the listed job's terms |
| A6 | "Why Ashgrove — and why a credit union?" | CO | [grounded] | Selection scaffold: give one real reason you can connect to something Ashgrove published, such as being "member-owned" (JD) or one of the four values by name, and say what about it matters to you. If nothing in it genuinely draws you, say plainly what does draw you to the role instead | Asked casually in every screen and scored anyway. CO because it tests whether you've done your homework on Ashgrove |
| A7 | "What draws you from branch supervision to a member experience role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Story-mapped on F9 and F1: three years as a supervisor, and the branch's formal complaints log, which are the beats the quotes state. Give the reason in your own words. Answer slot: if handling the log is what pulled you towards this work, say how; if it wasn't, say plainly what did | F9 and F1 make this motivation question predictable. EXP because the answer has to stay consistent with A1 |
| B1 | "The role needs experience handling regulated complaints — tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log" | Say what the quote says: you handled the branch's formal complaints log. Answer slot: if those complaints fell under a regulator's complaint rules, say which rules and which part of handling them was yours. If you don't know, or they didn't, say so plainly and stay with the log | F6 is a listed requirement your material doesn't establish, so it's a likely knockout check. JD because it scores the requirement directly |
| B2 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the quote says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it's built in Excel, say so and say what you set up in it. If it's another tool, name the tool and say so plainly | F4 is a listed requirement, and the evidence doesn't name the tool |
| B3 | "Have you worked with a contact centre before?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment, from your own words: "I haven't worked in a contact centre." Then one sentence of plan, as a plan. Say it calmly and early. A recruiter who hears a clean answer here has little left to probe | F2 is in the JD's first line, so expect a knockout check on it. A clean answer here also prepares the ground for D1 |

### Reverse questions

| Question | Why it lands |
|---|---|
| "How is the 20-minute case run — do I see the scenario on the day, and is it a discussion or a short presentation?" | It's process detail the recruiter can give you and the case kit above needs |
| "Do the branch managers score each of the four values separately, or overall?" | It tells you whether to make sure each value gets its own story (H1–H4) |
| "Does the role own contact-centre complaints directly, or work alongside a contact-centre lead?" | It shows you how big F2 really is before you meet your manager |
| "Who receives the monthly complaints report today?" | It tells you who "senior leaders" means for F7, so you can prepare for that audience |
| "What happens after 5 December, and when would I hear?" | You need it anyway, and asking signals you're serious about the role |

---

# Round 2 — Head of Member Services (your manager), 45 minutes

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions | High. The recruiter said this round is "mostly behavioural" | Use a STAR-shaped story where you have one. "We" for context, "I" for what you did |
| Skeptic | Probes the gaps: contact centre, senior presenting, scope | High. A hiring manager is buying capability and reducing risk, and F1, F2 and F7 are the gaps | Rehearse D1 until it bores you. Use plain acknowledgments and ramp plans |
| Case / Strategist | Live problems drawn from Ashgrove's strategy | Medium. A manager tests whether you can do the job, and the brief gives them obvious material | Clarify, then objective, approach, metrics, risks. Use Ashgrove's own words |
| Data-Driven Prober | Digs into the spreadsheet | Low-to-medium. It's your one artifact, and the JD has a reporting line | Know what you can and can't say about it |
| Pressure | "Which part would you be weakest at?" | Low. Possible as one sharp question | Hold, then concede, as G2 shows |

### Question bank

Every line in this bank meant for you to say is proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint you handled that was hard to resolve." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: one complaint from the branch's formal complaints log, which is the beat the quote states. Answer slot: what made it hard, what you did and how it ended are yours to give, in your own words, with the member anonymised. If no single complaint comes to mind, say so plainly and describe how you handled the log | "Members First, Always" and the JD's regulated-complaints line both point here. VAL first because this round is behavioural, and it also covers F6 |
| C2 | "Tell me about a time you had to tell a member something they didn't want to hear." | VAL | [grounded] | Selection scaffold: pick a time when the answer was no or bad news, it had to be clear the first time, and the member left understanding why. That shows "Plain Words" and "Members First, Always". If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | Complaint work is mostly delivering decisions, and two published values meet here |
| C3 | "Tell me about a time you raised something unwelcome with someone more senior than you." | VAL | [grounded] | Selection scaffold: pick a time with a named stake, a moment you didn't back down, and a working relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | The JD's "presenting to senior leaders" line needs someone who will bring bad news upward. It's the behavioural side of F7 |
| C4 | "Tell me about a problem you found that wasn't strictly yours to fix — what did you do?" | VAL | [grounded] | Selection scaffold for "Own the Fix" ("whoever finds the problem keeps hold of it until it is solved"): you found the problem, kept hold of it, and it got solved. Use a different story from H4. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | Your manager will want to see the value they'd be managing you to. VAL because it's mapped to a published value |
| D1 | "This role owns complaints end to end across branches and the contact centre. You've handled one branch's log, and you've never worked in a contact centre. Why should I trust you with the whole thing?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **Highest-ROI prep in the pack.** Open with what the quotes carry, and no more: "I handled the branch's formal complaints log, and I haven't worked in a contact centre." Then a plan, said as a plan, for learning the contact centre's side in your first weeks. Answer slot: if any stage of the branch log was yours to decide, say which and how, in your own words. If none was, say so plainly and stay with the log you handled. **Follow-up 1** ("But that's one branch"): agree. "Yes, one branch's log." Don't widen it. **Follow-up 2** ("So you'd be learning on the job?"): concede exactly. "On the contact-centre side, yes." Keep your position on what the quote carries. Never call your own work "the complaints process" | F1 and F2 meet in the JD's first line, so some version of this will be asked. JD because it scores the headline responsibility. It gets the deepest rehearsal because it aims at exactly where your material is thinnest |
| D2 | "You'd be presenting the monthly report to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment, from your own words: "I haven't presented above regional level." Answer slot: if you have presented at regional level, say to whom and about what. If you haven't presented at all, say so plainly. Then the plan: how you'd prepare the first senior session, said as a plan | F7 is a listed requirement and a stated gap, so a manager will check it directly |
| D3 | "You'd be coaching branch supervisors — people at your level today — on escalations. How would you go about it?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | Story-mapped on F5: you trained new tellers on your escalation script, and you've been a branch supervisor for three years. Those are the beats. Answer slot: if you had a particular way of training the tellers, say how, in your own words. If it meant taking them through the script, say so. Then say how you'd approach supervisors differently, as a plan | F5 is adjacent work, not the requirement itself, and the gap is about audience (tellers versus supervisors). JD content, CASE delivery |
| E1 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | No claims about your past are needed. Clarify what counts as "member service" moving. Then three angles: members who don't move with the shift, new ways digital journeys can fail, and complaints as the digital teams' early-warning signal (the JD's self-service line). Close on what you'd count by channel. Tie in "Plain Words": if members need app wording explained, the wording is wrong | The brief's headline goal is the obvious strategy question. CO because it tests thinking at Ashgrove's level |
| E2 | "Complaint resolution times have gone up sharply over two months. Diagnose it." | CASE | [generic] | Clarify how resolution time is measured, and when the clock starts and stops. Split by channel, branch and complaint type. Separate rising volume from falling capacity from a change in the process. Form hypotheses, say what data would test each, then the fix and the metric you'd watch | This is the reporting line in the JD, asked as a problem to work through. `[generic]` because it's a pattern, not an Ashgrove fact |
| E3 | "One of our self-service journeys is generating complaints. How would you work with the digital team on it?" | JD | [grounded] | Answer slot: if you've worked with a digital or online-banking team before, say what happened and which part was yours. If you haven't, say so plainly and move to how you'd do it. The plan: bring what members said, in their words, agree what the problem is, test a fix, and check complaints afterwards | F8 is a JD responsibility with nothing in your material behind it. JD content, CASE delivery |
| G1 | "Walk me through the monthly complaints spreadsheet you built — what's in it, and how does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F4: you built it, it's monthly, and your regional manager uses it. Those are the beats. Answer slots: what it counts, in your own words, or say plainly if it doesn't count volumes or resolution times. Which tool it's built in. How your regional manager uses it, if you know; if you don't, say so plainly | It's your one concrete artifact, and it sits on two JD lines, so a prober will go to it. EXP because it tests what was yours |
| G2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one of the two gaps and name it plainly: "I haven't worked in a contact centre," or "I haven't presented above regional level." Then give your plan. Hold-then-concede: if they push ("Only one?"), concede the other one exactly, in its own words, and stop there. Don't name a weakness your material doesn't give you | It's a stock stem for this pressure question, and F2 and F7 give you true answers. JD because it scores readiness for the job |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would you want the first monthly complaints report to show you that you can't see today?" | It's about your manager's own reporting need and points straight at the JD's reporting line |
| "How is complaint handling split between the contact centre and the branches today?" | It turns F2 into a learning plan you're already starting |
| "Which senior leaders would I present to, and how often?" | It shows you're preparing for F7 rather than avoiding it |
| "How do you see this role changing as eight branches become five hubs?" | It shows you've read the strategy brief and are thinking about the role ahead |
| "Where do complaints and the digital teams meet today?" | It clarifies F8 and connects to the 40% channel goal |
| "What would a strong first six months look like to you?" | It gives you your manager's own definition of success |

---

# Round 3 — Panel of two branch managers, 60 minutes (values round + 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One value at a time, scored | High. The recruiter said "they score against the four values" | Use the values cheat sheet below and have a different story ready for each value |
| Case / Strategist | The 20-minute complaint-escalation case, plus the branch hubs | High. The case is pre-announced | Use the case kit above. Think aloud |
| Peer Evaluator | "What would you need from me?", and where their branch's work ends and yours begins | Medium. The role coaches their supervisors and handles their escalations, so they're pricing what you'd add to or take off their branches | Frame it reciprocally. Propose principles for the boundary. Don't claim to know how their branches work |
| Pressure | "Why you?" and "How much was actually you?" | Low-to-medium. A panel often has one member who presses | Hold, then concede, as L1 and L2 show |
| Conversational | Opening chat | Low | Have a shorter version of A1 ready |

### Question bank

Every line in this bank meant for you to say is proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a decision you made from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] | Selection scaffold for "Members First, Always": the member's interest and the branch's convenience pulled apart, you chose the member, and you can name the cost. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | One scored value. The question borrows the value's own wording |
| H2 | "Tell me about a time something had to be explained to a member twice — what did you change?" | VAL | [grounded] | Selection scaffold for "Plain Words": the first explanation failed, you noticed, and you changed the wording itself, not just repeated it. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | One scored value, and the question is the value's own test |
| H3 | "Every branch is part of its town. Tell me about a time you treated a member as a neighbour rather than a number." | VAL | [grounded] | Selection scaffold for "Neighbours, Not Numbers": a specific member, local knowledge or a relationship that changed what you did, and an outcome. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | Branch managers live this value, and the hubs put it under strain |
| H4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: a complaint from the branch's formal complaints log. That's the beat the quote states. Answer slot: how you kept hold of it and how it was solved, in your own words. If none stayed with you until it was solved, say so plainly and describe how you handled the log. Use a different complaint from C1 | "Own the Fix" ("whoever finds the problem keeps hold of it until it is solved") is the value closest to the role |
| J1 | The 20-minute complaint-escalation case | CASE | [grounded] | Use the case kit above: clarify, objective, approach, people, metrics, risks. Name which value each step serves. Lead with one thesis and say its concession | Pre-announced and graded. CASE because it's a live problem |
| J2 | "Over 2027 eight branches become five hubs. What happens to complaints during that, and what would you do?" | CO | [grounded] | No claims about your past. Clarify what changes for members, such as where they go and who they know. Expect more complaints that have nothing to do with a product. Watch the numbers branch by branch through each move. Say plainly what "Neighbours, Not Numbers" asks of a hub. Don't guess which branches are merging | The brief's branch plan affects this panel directly. CO because it's Ashgrove's own strategy |
| K1 | "If you coached my supervisors on escalations, what would I notice changing — and what would you need from me?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | Story-mapped on F5: you trained new tellers on your escalation script, and you've been a branch supervisor for three years. Answer reciprocally: what you'd bring their branch, and what you'd ask of them, said as a plan. Answer slot: if your teller training changed how escalations went, say how, in your own words. If you don't know that it did, say so plainly | It's the JD's coaching line asked by the people whose supervisors you'd coach. JD content, Peer delivery |
| K2 | "Where's the line between what my branch handles and what comes to you?" | JD | [grounded] | Propose principles, not a line you can't know yet. Whoever finds the problem keeps hold of it ("Own the Fix"). It comes to you when it needs something the branch can't give, or crosses branches or channels. The member never has to explain it twice. Ask how it works today | "end to end across branches" creates a boundary with their branches. Peer delivery |
| K3 | "What would you want branch managers to tell you about complaints that the monthly numbers won't show?" | JD | [grounded] | No claims about your past. Name what numbers miss: why a member was upset, who's close to leaving, local context. Then how you'd ask for it regularly without adding to their workload | The JD's reporting line meets "Neighbours, Not Numbers" |
| L1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Hold only what the quotes carry: six years in retail banking, three as a supervisor, the branch's formal complaints log, the monthly complaints spreadsheet your regional manager uses. Don't claim to know anything about the internal candidates. Hold-then-concede: if pushed ("They know the contact centre"), concede exactly ("They may, and I don't yet") and return to the quotes | A stock pressure stem. JD because it's about fit to the role |
| L2 | "That complaints spreadsheet your regional manager uses — how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: "I built it." Answer slot: if someone else decided what goes in it, or other people fill it in, say so plainly and say which part was yours. Hold through two follow-ups by returning to "I built it", without adding to it | F3 is your most concrete claim, so it's where an attribution check lands. EXP because it tests what was yours |

### Values cheat sheet (pending your approval)

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide as the member would see it | Scaffold (H1): a choice between the member and the branch's convenience, with a named cost. If none comes to mind, say so plainly, then the nearest thing your experience does carry, or how you'd handle it |
| Plain Words | If it needs explaining twice, the wording failed | Scaffold (H2): an explanation that failed, then a change of words. If none comes to mind, say so plainly, then the nearest thing, or how you'd handle it |
| Neighbours, Not Numbers | Each branch belongs to its town | Scaffold (H3): one specific member and local context. If none comes to mind, say so plainly, then the nearest thing, or how you'd handle it |
| Own the Fix | Whoever finds it keeps it until solved | F1, "I handled the branch's formal complaints log": one complaint from that log (H4), with how you kept hold of it as an answer slot. Use a different story for C4 |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could a new Member Experience Lead do in the first month that would genuinely help your branches?" | A reciprocity question: it asks what you can give, not what you need |
| "When a complaint escalates out of your branch today, what do you wish happened next?" | It's their own experience of the problem you'd own |
| "Which of the four values is hardest to live in a branch right now?" | It's the round's own scoring frame, asked as an honest question |
| "As branches become hubs, what do you most want protected for your members?" | It's "Neighbours, Not Numbers" applied to their real situation |
| "What do your supervisors find hardest about escalations?" | It's the JD's coaching line, put to the people who know |

---

## Prohibited claims (what this pack won't coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The pack observes that your material says the branch's log, not a process. D1 and H4 keep their slots inside the log |
| Contact-centre experience of any kind | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, executives or a board | A negative you stated, F7 | "I haven't presented above regional level." The slot covers regional level only |
| Coached supervisors or managers on escalations | Inflated form of F5 | F5's quote at its own scope: you trained new tellers. D3 and K1 put supervisors in the future tense |
| Wrote or designed the escalation script | Inflated form of F5 | F5's quote at its own scope: you trained tellers on "our escalation script". The material doesn't say who wrote it |
| Owns the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: you built the spreadsheet, and your regional manager uses it. L2's slot stays inside "I built it" |
| Advanced Excel or dashboard skills | Inflated form of F4 | F4's quote at its own scope: "spreadsheet". B2 and G1 have slots for naming the tool |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope: "formal complaints log". B1 has a slot for the rules, with an "I don't know" branch |

---

## Sources

**Provided documents:** the JD; the values text you pasted, copied 26 November 2026 from ashgrovecu.org/about/values (not fetched); the recruiter's email on the process; your summary of Ashgrove's July 2026 strategy brief; your background. No `tuesday-dossier.md` was present.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted this morning already fixes the cheat sheet and the H and C banks |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email sets out all three rounds, their lengths, interviewers, the case and the values scoring, so it fixes the persona weights and the structure |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, under six months old, already fixes the CO questions (E1, J2) and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewers have been named yet, so no search can be formed. There's no interviewer read, and the upgrade menu says what names would add |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your answers to the answer slots:** what the spreadsheet counts, which tool it's in, whether the log's complaints fell under a regulator's rules, and any digital work. These would turn F3, F4, F6 and F8 into story-mapped rows and sharpen B1, B2, G1, E3 and C1
- **A real story for each value** → the four scaffolds in the values cheat sheet and H1–H3 become mapped stories, so you go into the scored round with a story for each
- **Your full CV** → more quotes to map from, which could turn the C-bank scaffolds into stories
- **Interviewer names, once assigned** → a section on reading each interviewer, persona weights from their public professional profiles, and a reverse question tied to each one's career path
- **The prep time you have before 5 December** → a prioritised prep schedule sized to it
- **The full strategy brief text**, rather than four points → headline numbers and Ashgrove's own wording for the grounding brief, E1 and J2
- **Case format details from the recruiter** → a case kit built for the actual format (discussion or presentation, scenario in advance or on the day)
- **A deeper research pass** → up to 6 more searches and 2 more fetches, several more minutes: recent Ashgrove leadership or organisational news, and candidate reports of its interview loop
- **A `tuesday-dossier.md`** → verified evidence and a prohibited-claims list confirmed with you, which would make D1's wording rest on confirmed evidence instead of what the pack inferred from your message
