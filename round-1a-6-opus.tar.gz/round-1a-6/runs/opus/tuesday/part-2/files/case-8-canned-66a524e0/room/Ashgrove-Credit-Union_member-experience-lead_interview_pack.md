# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 5 December 2026, built from the recruiter's email.
1. Recruiter, 30 minutes
2. Head of Member Services, your future manager, 45 minutes, "mostly behavioural"
3. Panel of two branch managers, 60 minutes, "including a 20-minute case on a complaint escalation". This is also the values round: "they score against the four values"

**Interviewers:** not assigned yet, so this pack has no interviewer read and its reverse questions are written for the role.

---

## How to use this pack

Each question has two tags. **Personas** describe how a question is asked (who is asking, in what style). **Types** describe what is being scored.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix |
| EXP | Whether what you say about your experience holds up, and what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you understand Ashgrove's strategy and can think about the role at that level |
| CASE | How you structure a live problem from the role |

Read it in this order: fit snapshot, then the graded case build, then each round's mini-pack. **Guidance is scaffolding, not a script.** Every line about your past is built only from the four sentences you gave me, quoted exactly. Where an answer needs something you haven't told me, the pack gives you an **answer slot**: an instruction with two honest branches for you to fill from memory in the interview. It never fills them for you.

---

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, and your words should stay at that size: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on what handling the log involved likely. If any stage of a complaint, from arriving to closing, was yours to decide, say which stage and how you decided, in your own words. If handling the log meant recording rather than deciding, or the decisions were someone else's, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You have stated this gap, and no wording closes it. Words: "I haven't worked in a contact centre." Follow them with how you would learn the contact centre's side, said as a plan and never as something in your past: for example, time sitting with the team early on and learning how its complaints reach you. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote covers a monthly complaints spreadsheet. It does not say what the spreadsheet counts. Words at their own size: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet tracks. If it tracks either, say which, in your own words. If it tracks neither, say so plainly and say what it does track |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says "spreadsheet", not Excel. Where a sentence could be read two ways, the pack takes the reading that claims less. Answer slot: if the spreadsheet is in Excel, say so and describe what building it meant, in your own words. If it is in another tool, name the tool plainly |
| F5 | "coach branch supervisors on escalations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | There are two limits here, and both are the pack's observation, not words for you: you trained tellers, not supervisors, and you trained them on a script, which is different from coaching someone's judgement. "Our" escalation script doesn't say who wrote it. Words: "For the last three years I've been a branch supervisor, and I trained new tellers on our escalation script." Answer slot: if any of training tellers went beyond the script itself, say what, in your own words. If it was the script and nothing more, say so plainly and describe how you trained it |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show work with digital teams. Answer slot: if you have worked with a digital team on a self-service journey, say what it was and which part was yours. If you haven't, say so plainly, then say what you would bring a digital team from complaints, as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. It's a statement with nothing behind it to inspect, so expect a probe. Lead with the quote's own terms, six years in retail banking with three as a branch supervisor, and let the interviewer map that onto "customer operations" |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | "Formal" doesn't say "regulated", and the pack won't upgrade it. Answer slot: if the complaints on that log were handled under a regulator's rules, say which rules and which part of meeting them was yours, in your own words. If you're not sure, say so plainly and describe the log as you handled it |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated this gap. Words: "I haven't presented to anyone above regional level." Your sentence leaves open whether you've presented at regional level, and the pack doesn't assume you have. Follow with how you would prepare for a senior audience, said as a plan. Nothing more |

**Highest-ROI prep in this pack: D1** (round 2). It combines F2 and F9, the two gaps you stated yourself, against the role's scope. It will come up in some form, probably in more than one round.

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

**What the recruiter declared:** "a 20-minute case on a complaint escalation", run by "a panel of two branch managers", who "score against the four values". The recruiter named no particular close or recommendation format, and the case itself is unknown, so this is a build kit, not an answer.

**Your facts to build on.** Use these only as the sentences themselves:
- F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- F5: "6 years in retail banking, the last 3 as a branch supervisor"

**A 20-minute shape** [generic]: (1) Clarify, about 2 minutes: what happened, how many contacts, who holds it now, what the member wants, and whether a deadline applies. (2) The member today, about 4 minutes: what you would do and say to the member now. (3) Ownership and the fix, about 5 minutes: who keeps hold, what gets decided, by when. (4) The supervisor, about 4 minutes: what the branch supervisor learns from it. (5) The pattern, about 3 minutes: what goes in the monthly report and what you'd look for. (6) Leave about 2 minutes for their pushback.

| Thesis | The argument | Mandatory concession | Value it carries |
|---|---|---|---|
| T1. Escalate the decision, not the member | The person the member first told stays their contact. A specialist may decide, but the member never has to start again | Some complaints have to go to a specialist or a specific team. Keeping hold means tracking it and staying the member's contact, not doing every step yourself | Own the Fix: "whoever finds the problem keeps hold of it until it is solved" |
| T2. Fix this member first, then fix the pattern | Resolve the case in front of you, then use the monthly figures to see whether it's one branch or many | Root-cause work must not slow down this member's resolution, and one case is not a trend | Members First, Always; the JD's monthly reporting line |
| T3. Write the answer so it never needs a second explanation | The member's outcome, in words they understand the first time | Plain doesn't mean casual. A formal response may need precise wording, so plain words go around it, never in place of it | Plain Words: "if a member needs it explained twice, we wrote it wrong" |

**How to stand out from the textbook answer.** The textbook answer is the escalation ladder: acknowledge, investigate, resolve, close. Use it once to show you know it. Then diverge: name which value each step serves, and spend real time on step (4), because the panel are branch managers whose supervisors this role coaches (JD). **What to avoid saying:** never promise the member an outcome or compensation before you have the facts, and never fix it by overruling the branch in front of the member. Both break the panel's trust in you as the person who will coach their teams.

**Where your background can appear in the case:** only as the F1 and F5 sentences above, for example "I trained new tellers on our escalation script, so I'd start with where the script stopped helping." That line is pending your approval. Use it only if it's true that you'd start there.

---

## Grounding brief: Ashgrove's 2026 strategy, as summarised in your message

The four points below are your own summary of the July 2026 brief. The brief itself isn't attached.

| Point | Your summary's words | What it means for these rounds | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | The JD's "work with digital teams on self-service journeys" sits inside this goal. Expect E2, and possibly a version from the panel | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" | Your panel are branch managers going through this. Say "hubs" the way the brief does, and treat the change as their reality rather than as a talking point you've learned | [grounded] |
| Small-business lending | "launch a small-business lending product in Q1 2027" | A new product could bring new kinds of complaints. Raise it as a reverse question (R2-6), not as a claim | [inferred] |
| Competition | "the main competitive pressure is app-only banks" | You might read Neighbours, Not Numbers and the branch network as Ashgrove's answer to app-only competitors. That reading is yours to offer as an opinion; the brief doesn't say it | [inferred] |

None of this is stale: the values were copied today and the brief is from July 2026.

---

# Round 1: Recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly "walk me through it", why Ashgrove, logistics | High: this is the default for a recruiter screen, and the 30 minutes leave room for little else | Rehearse a 90-second background arc (A1) built only from your four sentences. Treat every casual question as scored |
| Skeptic (light) | Quick checks against the JD's requirements | Medium: recruiters commonly screen the requirements list, and F2 and F9 are gaps you've stated | Say each gap plainly once (B1), then move to what your sentences do carry |
| Others | Unlikely in a 30-minute screen | Low | Covered in rounds 2 and 3 |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with three beats, each one sentence you gave: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Answer slot: give your actual reason for wanting a complaints-focused role, or, if it's broader than complaints, say that plainly | F7, F1 and F3 are your strongest rows, and this is where the recruiter first hears them. EXP because it sets out what was yours; JD because it is the first check against "4+ years" |
| A2 | "Why Ashgrove?" | CO | [grounded] | Choose one published value and one strategy point that genuinely matter to you, and say why in your own words. Use the values' exact names (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix). Don't recite all four. If what draws you is something else, such as the member-owned model, say that instead | Recruiters test whether motivation is consistent across the loop, and the panel scores values later. CO because it rests on the values page and brief you pasted |
| A3 | "What salary are you looking for?" | JD | [grounded] | Logistics slot: give your own figure, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | The pay check is standard in a screen. JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words | Standard logistics check, and the answer can only be yours |
| A5 | "The role covers branches and the contact centre. Where can you be based, and how much travel between sites works for you?" | JD | [grounded] | Logistics slot: say where you can be based and how much travel suits you, in your own words. The JD doesn't state a base location, so ask where the role sits (R1-4) | The JD's "across branches and the contact centre" makes the question about base and travel likely |
| A6 | "Why are you looking to leave your current role?" | EXP | [grounded] | Logistics slot: give your own reason, in your own words. Keep it about moving towards this role rather than away from your current one, and keep it consistent across all three rounds | Every round may ask this, and inconsistency across rounds is the risk. EXP because it's about your own history |
| A7 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name the brief's four points briefly in your own words: 40% of member service digital by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, and pressure from app-only banks. Add one sentence on what that could mean for complaints, offered as your view | It's a quick homework check, and the brief came from the recruiter, so not using it would be noticed. CO by definition |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I haven't worked in a contact centre." Then what you do have: "I handled the branch's formal complaints log." Then one line of plan: how you would learn the contact centre's side early. Keep it short. The full version is D1 | F2 is a gap you've stated, and a recruiter may check it as a knockout. JD because it scores the stated scope |
| B2 | "The role asks for experience handling regulated complaints. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with the sentence: you handled the branch's formal complaints log. Answer slot: if those complaints were handled under a regulator's rules, say which rules and which part of meeting them was yours, in your own words. If you're not sure, say so plainly and describe the log as you handled it | F8 is a requirement whose evidence is silent on regulation, so rehearse the honest answer before the question arrives. JD by definition |
| B3 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it's in Excel, say so and describe what building it meant. If it's another tool, name it plainly. Don't grade yourself with "advanced" | F4: the JD says Excel and your sentence says spreadsheet. `[inferred]` because the step from spreadsheet to Excel is the pack's derivation, not your words |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Will the 20-minute case be given to me on the day, or is there anything to prepare beforehand?" | Clarifies the one graded deliverable, and recruiters respect a candidate who prepares the format |
| R1-2 | "When the panel scores against the four values, how is that weighed against the other two rounds?" | Shows you've taken the values round seriously, and the answer tells you where to spend prep time |
| R1-3 | "Once the interviewers are assigned, could you share their names and roles?" | A normal request, and names let you prepare for the actual people |
| R1-4 | "Where would the role be based, a central team or one of the hubs?" | The JD doesn't say, and the answer shapes A5 and your view of the role |
| R1-5 | "What's the timeline for a decision after 5 December?" | Practical, and it closes the screen cleanly |

---

# Round 2: Head of Member Services (your future manager), 45 minutes, "mostly behavioural"

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope gap: one branch against the whole process, no contact centre, no senior presenting | High: a hiring manager is taking on the risk of the gaps, and F2 and F9 are gaps you've stated | Rehearse D1 until it bores you. Say each limit before you're asked. Hold the facts your sentences carry |
| Values / Behavioural | "Tell me about a time…" questions | High: the recruiter said "mostly behavioural" | For each question, choose a real story using the selection guidance. Use "we" for context and "I" for what you did |
| Case / Strategist | A short live problem on reporting or the digital shift | Medium: a hiring manager would usually ask about the actual job, but "mostly behavioural" lowers the weight | Clarify, then structure, then answer. Use the brief's vocabulary |
| Data-Driven Prober | Questions about what the spreadsheet counts | Low to medium: it arrives inside D3 | Know what you can and can't say about your spreadsheet (F3, F4) |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre and you haven't presented above regional level. This role owns complaints across the contact centre and presents to senior leaders. Why should we take that bet?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level."; "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | **The highest-ROI rehearsal in this pack.** Open by naming both limits yourself: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then what your sentences carry, and nothing more: "For six years I've been in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." Then the plan, said as a plan: how you'd learn the contact centre's side in the first weeks, and how you'd prepare your first senior presentation from the monthly figures. **Follow-up 1:** "But one branch's log isn't a process across branches." Hold: agree that it's the step up and that's why you want the role, then come back to the log you handled. Don't stretch it. **Follow-up 2:** "So you'd be learning on the job." Concede it clearly: "On the contact centre and on senior presenting, yes. That's where I'd be newest." Don't give up the rest. **Never:** imply contact-centre exposure, or describe the regional manager as a senior audience you presented to | F2 and F9 against F1's scope is the most predictable objection to you in this loop. JD because it scores the stated requirements. It gets the deepest rehearsal because a calm answer turns your biggest risk into a credibility point |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level." | Pick one, say it plainly in your own words, and give the plan. Either "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level" is honest. Don't pick a false weakness. Then stop. Don't list them all | A standard Skeptic question. A rehearsed, short answer here keeps it from turning into D1 a second time |
| D3 | "Tell me about the monthly complaints spreadsheet you built. What does it show, and what does your regional manager do with it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it and your regional manager uses it; those are the beats your sentence states. Answer slot: if it tracks volumes or resolution times, say which, and say what goes into it, in your own words. If it doesn't track them, say so plainly and say what it does track. Answer slot: if you know what your regional manager does with it, say so; if you don't, say so plainly. Don't describe it as regional reporting | F3 is your closest evidence for the reporting requirement, and a manager who owns the monthly report will probe it. EXP because it tests what was yours |
| D4 | "What did handling the formal complaints log actually involve? What was yours?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I handled the branch's formal complaints log." Answer slot: if any stage of a complaint, from arriving to closing, was yours to decide, say which stage and how you decided. If handling it meant recording rather than deciding, or the decisions were someone else's, say so plainly and stay with the log you handled | F1 and F8 rest on this one sentence, so it's where "how much was you" lands |

### Bank C: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a member complaint needed escalating." | VAL, EXP | [generic] | Selection guidance: choose a real complaint where the escalation decision involved you. It needs what triggered the escalation, what you did, and how it ended for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the log you handled) or how you would handle it | The JD's escalation line, asked as a behavioural question. `[generic]` because no sentence you gave carries a specific escalation |
| C2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [generic] | Selection guidance: a real moment where your first explanation didn't land. It needs what you changed the second time and what you changed afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | The theme comes from Plain Words ("if a member needs it explained twice, we wrote it wrong"). A future manager may test the values before the panel does |
| C3 | "Tell me about training someone where it didn't land the first time." | VAL, JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5: you trained new tellers on your escalation script. That's the beat your sentence states. Answer slot: if a teller didn't get it the first time, say what you changed, in your own words. If none comes to mind, say so plainly and describe how you trained. Don't call it coaching supervisors | F5 is the nearest evidence for "coach branch supervisors on escalations". JD content delivered as a behavioural question |
| C4 | "Tell me about a time you told someone above you something they didn't want to hear." | VAL | [generic] | Selection guidance: a real moment with a named stake, where you didn't back down and the working relationship was still fine afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem tied to "confident presenting to senior leaders" (F9). A behavioural version of the senior-audience question |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your monthly report shows resolution times rising at two branches. What do you do?" | CASE, JD | [generic] | Clarify: since when, which complaint types, and whether volumes rose too. Then split the possible causes into staffing, process and complaint mix. Talk to both supervisors before drawing conclusions. Say what you'd report, and to whom. Name a risk: two branches over a short period may be noise | Comes straight from the JD's reporting line. CASE delivery. `[generic]` because it's a pattern, not Ashgrove data |
| E2 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CO, JD | [grounded] | Structure it: which journeys move first, what new complaint types digital creates, how complaints data could feed the digital teams' fixes, and what members who prefer a branch need. Offer one view and one risk. Answer slot: if you've worked with a digital team on a self-service journey, say what it was and which part was yours. If you haven't, say so plainly and give the plan | Brief plus the JD's digital line (F6). This is the strategy question most candidates can't answer well |
| E3 | "What would your first 90 days look like?" | CASE, JD | [generic] | Learn, then fix, then report: see the process at branches and in the contact centre (be honest that the contact centre is new to you), read the last months of complaint data, agree with your manager what senior leaders need, and pick one early fix. Make no claims about your past | Hiring managers often ask this. It lets you turn F2 and F9 into a plan without being pushed |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "Where does the complaints process break most today: branches, the contact centre, or the handoff between them?" | It's about your actual job, and it tells you where you'd be judged |
| R2-2 | "Who receives the monthly report, and what decisions does it feed?" | Gets at the senior-presenting requirement (F9) and shows you think about how the report gets used |
| R2-3 | "How will the move to five hubs over 2027 change complaints work?" | Shows you know the brief, and the answer shapes year one |
| R2-4 | "What would make you say, six months in, that this hire was right?" | Gives your manager the chance to state the bar. Good to ask a future manager |
| R2-5 | "How do the digital teams and Member Services work together on self-service now?" | F6 is a gap in your material, so the answer tells you what you'd be walking into |
| R2-6 | "Will complaints about the new small-business lending product come to this role?" | Shows you know the brief's Q1 2027 launch, and it's a real scope question |

---

# Round 3: Panel of two branch managers, 60 minutes, values round with the 20-minute case

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Value-by-value questions, scored | High: the recruiter's words, "they score against the four values" | One story per value, using the cheat sheet below. Use the values' exact names |
| Case / Strategist | The 20-minute escalation case and follow-ups | High: declared by the recruiter | The graded case build above |
| Peer Evaluator | "What would you need from us?", where the branch ends and your role starts | Medium: this role coaches their supervisors (JD), so they're judging how much easier or harder you'd make their teams' work | Frame it around what you bring their branches. Propose principles for where the line sits rather than claiming to know it already |
| Conversational | A warm opener | Low | Reuse A1 |

### Values cheat sheet

None of the four sentences you gave carries a values story, so each row is selection guidance. Telling me one real story per value (outside a drill) turns these rows into mapped stories.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, even when it costs the organisation something | Selection guidance: a real decision where you put the member's outcome ahead of what was easier for the branch. It needs the choice, what it cost, and the member's outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Used in G1 |
| Plain Words | If something needs explaining twice, the fault is in how it was written | Selection guidance: a time you rewrote or re-explained something so it landed the first time. Your F5 sentence, "trained new tellers on our escalation script", is nearby but doesn't carry the story by itself. If no such time comes to mind, say so plainly and say how you would handle it. Used in G2 |
| Neighbours, Not Numbers | Each branch belongs to its town; members are people, not metrics | Selection guidance: a time local knowledge of a member or the community changed what you did. If no such time comes to mind, say so plainly, then say how you would handle it. Used in G3 and G5 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Selection guidance: a problem you found and followed through to the end, including after handing parts of it on. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Used in G4 and the case's T1 |

### Bank G: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Use the Members First row of the cheat sheet. It needs the choice you faced, what you chose, and the member's outcome. If no such time comes to mind, say so plainly, then say how you would handle it | Uses the value's own words. Scored |
| G2 | "When did a member need something explained twice, and what did you change?" | VAL | [generic] | Use the Plain Words row. Say what changed afterwards, not only what happened in the moment. If no such time comes to mind, say so plainly, then say how you would handle it | Uses the value's own words. Scored |
| G3 | "Tell me about a time knowing your community changed how you handled a member." | VAL | [generic] | Use the Neighbours, Not Numbers row. If no such time comes to mind, say so plainly, then say how you would handle it | Uses the value's own words. Branch managers will recognise a real story immediately |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [generic] | Use the Own the Fix row. "I" for what you did. Answer slot: if you built the monthly complaints spreadsheet because of a problem you found, say what the problem was, in your own words. If not, say so plainly and choose another story | Uses the value's own words. F3 is the only sentence that might link to it, and only you know whether it does |
| G5 | "Over 2027 we're consolidating eight branches into five hubs. How does Neighbours, Not Numbers hold up through that, in complaints?" | VAL, CO | [grounded] | Treat it as their reality, not a debate. Give one principle (for example, members at a closing branch keep one named contact for open complaints), one risk (complaints about the change itself), and one thing you'd watch in the monthly figures. Don't take a side on the consolidation | Brief plus value. Your panel are the managers going through the change, so this is likely and sensitive |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would you bring?" | JD, VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with what you'd bring them, then what you'd need. What you can say about your own experience: you've been a branch supervisor for the last three years and trained new tellers on your escalation script. Propose a principle, for example coaching on live cases rather than in classrooms, as a plan. Don't call past work coaching supervisors | F5 is where this panel tests the JD's coaching line. They're judging whether you'd lighten or add to their teams' load |
| H2 | "One of my supervisors escalates everything to you. What do you do?" | CASE | [generic] | Find out why first: confidence, unclear limits, or a real pattern. Then agree a threshold with the supervisor and their manager, and coach on the next live case. Never by going around the branch manager. Close the loop with the branch manager | A typical peer scenario and a version of the JD's coaching line. `[generic]` because it's a pattern |
| H3 | "Where's the line between what my branch resolves and what comes to you?" | JD | [generic] | Propose principles rather than claiming to know it: resolve where the member is when possible, escalate the decision but not the member (T1), and agree the thresholds together. Ask them where it breaks today | The question about where their role ends and yours begins. Proposing principles works better than pretending you already know |

### Bank J: Case follow-ups (inside the 20 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | Practice prompt: "A member has complained at a branch three times about the same issue, and the supervisor wants to hand it to you. Walk us through it." | CASE | [generic] | Run the 20-minute shape from the graded case build. Clarify before you structure, and name the value at each step | Practice only, because the real case is unknown. `[generic]` |
| J2 | "Halfway through, the member says they're going public about it. What changes?" | CASE, VAL | [generic] | Hold the plan: the member's outcome doesn't change because the pressure did. Update the branch manager, keep one contact for the member, and respond in plain words. Concede that timing may tighten | Panels often add a twist to test whether the candidate stays composed |
| J3 | "What would you change so this doesn't come back?" | CASE, JD | [generic] | Fix the pattern (T2): check whether the same issue appears at other branches in the monthly figures, fix the underlying cause, and coach the supervisor on the next one | Links the case to the JD's reporting and coaching lines |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do your supervisors find hardest about escalations today?" | Asks the people who'd use your coaching what they need |
| R3-2 | "What could a complaints lead do in their first month that would genuinely help your branches?" | Asks what you can do for them, the right question for peers |
| R3-3 | "As the move to hubs happens, what do you most want to protect for your members?" | Respects their position in the consolidation and ties it to Neighbours, Not Numbers |
| R3-4 | "When a complaint goes well at your branch, what does that look like?" | Lets them describe their own standard, which you can use later |
| R3-5 | "Which of the four values gets tested most at the counter?" | Treats the values as practice rather than slogans, which matters in a values round |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre (F1, F2) | D1, D4, B1, E3, H3, J1 |
| Report monthly on complaint volumes and resolution times (F3) | D3, E1, J3 |
| Coach branch supervisors on escalations (F5) | C3, H1, H2 |
| Work with digital teams on self-service journeys (F6) | E2 |
| 4+ years in financial-services customer operations (F7) | A1 |
| Experience handling regulated complaints (F8) | B2, D4 |
| Confident presenting to senior leaders (F9) | D1, D2, C4 |
| Comfortable with Excel reporting (F4) | B3, D3 |

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across branches | Inflated form of F1 | F1's quote at its own size: "I handled the branch's formal complaints log." The pack's observation is that this describes one branch's log. D4's slot stays inside that log |
| Any contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, or above regional level | Negative you stated, F9 | "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors, or wrote the escalation script | Inflated form of F5 | F5's quote at its own size: "trained new tellers on our escalation script". "Our" doesn't say who wrote it. F5's slot stays inside training tellers |
| Built regional complaints reporting | Inflated form of F3 | F3's quote at its own size: "I built the monthly complaints spreadsheet our regional manager uses." D3's slots ask only what it tracks |
| Managed a branch | Inflated form of F7: a supervisor is not a manager, and the panel are branch managers | "the last 3 as a branch supervisor" |

---

## Sources

**Provided documents:**
- The JD text, pasted
- Ashgrove's values, pasted by you; your note says they were copied on 26 November 2026 from ashgrovecu.org/about/values. Not fetched: the text was already in hand
- The recruiter's email about the process, pasted. This is the loop source: it establishes all three rounds and names the values round
- The 2026 strategy brief (July 2026), as four points summarised in your message. The brief itself wasn't attached
- Your background (four sentences in your message)
- No `tuesday-dossier.md` was present

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | Your pasted values text, copied today, provides all four value names and definitions for the cheat sheet and bank G |
| 2. Ashgrove Credit Union interview process, member services | skipped | The recruiter's email establishes all three rounds, their lengths, the case and the values round, so persona weights follow it |
| 3. Ashgrove Credit Union strategy / recent news | skipped | Your summary of the July 2026 brief, under six months old, provides the CO questions (A7, E2, G5) and the grounding brief |
| 4. Interviewer name, Ashgrove Credit Union | n/a | No names have been assigned yet, so there was no query to run. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied sets the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Interviewers' names, once the recruiter assigns them → an interviewer read for each round, persona weights adjusted to their public professional background, and at least one reverse question tied to each person's career
- One real story per value, told to me outside a drill → the four values cheat sheet rows and G1–G4 become mapped stories instead of selection guidance
- Your answers to the answer slots: what the spreadsheet tracks and what tool it's in, what handling the log involved, whether the complaints were regulated, whether you've presented at regional level, any digital work → F3, F4, F8, F9 and F6 and the D3, D4, B2, B3 and E2 guidance are rebuilt on your words
- Your CV → more sentences for the fit snapshot to quote, and a clearer view of rows F7 and F5
- How much prep time you have before 5 December → a prioritised prep schedule tied to question IDs
- The full strategy brief instead of the four-point summary → a richer grounding brief and sharper versions of E2 and G5
- A deeper research pass, up to 6 more searches and 2 more fetches, taking several more minutes → recent news and organisational context about Ashgrove, and any public reports of its interview process. Offered once
- A `tuesday-dossier.md` → verified evidence, binding limits on what can be claimed, and an evidence-based highest-ROI objection to replace the one this pack inferred
