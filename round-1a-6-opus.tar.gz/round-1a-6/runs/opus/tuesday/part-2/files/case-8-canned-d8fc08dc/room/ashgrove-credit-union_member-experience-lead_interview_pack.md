# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Format:** Loop mode, three rounds on 5 December 2026, all from the recruiter's email: (1) 30 minutes with the recruiter; (2) 45 minutes with the Head of Member Services, your future manager, "mostly behavioural"; (3) 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers:** Not yet assigned beyond their roles, so this pack has no interviewer read. Names unlock one (see the upgrade menu).

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what is being scored*.
- Type key:
  - **VAL** — behavioural and values: does what you've done show *Ashgrove's published* values
  - **EXP** — experience deep-dive: does what you've said survive close questioning, and what was actually you
  - **JD** — role-driven: can you do the listed job, gaps included
  - **CO** — company and strategy: do you know where Ashgrove is going
  - **CASE** — a live problem from the role, worked out loud
- **Provenance** on every row: `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is derived, and the derivation is named; `[generic]` is a standard pattern for this kind of role, with no claim about Ashgrove or you.
- An **answer slot** is where the pack stops on purpose. It names what an interviewer is likely to probe and gives you two honest branches. You fill it from your own memory, in your own words, or you say plainly that it wasn't yours or didn't happen.
- The guidance is scaffolding, not a script. Every sentence the pack offers about your past is one of your own six sentences, quoted.

Question IDs run by persona across the loop: **A** Conversational, **B** Skeptic, **C** Values and Behavioural, **D** Case and Strategist, **E** Peer Evaluator, **G** Pressure.

---

# Shared sections

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length: six years against four. Say it in your own terms, retail banking and branch supervisor, rather than borrowing "customer operations"; the panel will make the link. It's a line with nothing behind it to inspect, so expect a probe on what the supervisor job covered |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal complaints and the log. It doesn't say whether those complaints came under regulatory complaint rules, or which part of each complaint was yours. Words: "I handled the branch's formal complaints log." Answer slot: "regulated" in the JD makes a probe on the rules likely. If the log covered complaints handled under regulatory rules, name the rules and say what part of handling them was yours, in your own words. If it didn't, or you're not sure, say so plainly and describe the log as it was |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch's log is not a multi-branch process, and the words stay at one branch. Answer slot: "end to end" makes a probe on a complaint's stages likely. If any stage of a complaint's path was yours to set or change, say which and how. If none was, say so plainly and stay with the log you handled |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You've stated this gap, and wording can't close it. Words: "I haven't worked in a contact centre." Then how you would learn the contact centre's side of complaints, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | A monthly complaints spreadsheet you built, used by your regional manager. Your material doesn't say what it counts. Keep "our regional manager uses" as it is: one regional manager uses it, which is not the same as being the region's reporting. Answer slot: if it tracks volumes or resolution times, say what it counts and how figures get into it. If it tracks something else, say what, plainly |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says spreadsheet, not Excel. Answer slot: if it's built in Excel, say so, and name the features you used if you can. If it's another tool, name the tool and say so plainly |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message and "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | You trained new tellers on the script and you've held the supervisor job. Your material doesn't describe coaching supervisors. Words: "I trained new tellers on our escalation script, and I've spent the last three years as a branch supervisor." Answer slot: if you've helped a fellow supervisor, or anyone beyond a new teller, with an escalation, say who and how. If not, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You've stated this gap. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan. Your sentence doesn't say you have presented at regional level, so the pack doesn't assume it (B5 holds the slot) |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't show digital or self-service work. Strong evidence would be a time when what members complained about changed how a website, app or self-service process worked. Answer slot: if you've worked with a digital team or on a self-service process, say what part was yours. If not, say so plainly and say how you would bring complaint patterns to a digital team |

## Grounding brief

From the July 2026 strategy brief, as you summarised it, plus the JD and values page. I only have your summary, not the brief's own text.

| Item | What it says | Provenance | Where it matters |
|---|---|---|---|
| Vocabulary | "member" throughout, never customer; "member-owned"; "self-service journeys"; "the member's side of the counter" | [grounded] | Every round. Say "members" naturally |
| Digital shift | 40% of member service to move to digital channels by 2028 | [grounded] | D2, D4, F9; what complaints data should feed |
| Branch network | Eight branches consolidating into five hubs over 2027 | [grounded] | A5, D1, D4; complaint themes during consolidation; the Neighbours, Not Numbers value |
| New product | Small-business lending launches Q1 2027 | [grounded] | Reverse questions; a new product means a new kind of complaint for the process to handle |
| Competition | App-only banks are the main competitive pressure | [grounded] | D2; why "Members First" and "Neighbours" are how Ashgrove competes, not slogans |
| Freshness | The brief is from July 2026. The hub plan may have moved since | [grounded] | Use the plan as stated. If an interviewer describes it differently, go with what they say and don't correct them |

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process end to end, or across branches | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The pack's own note on the limit: your material says one branch's log, not a process. F3's slot stays inside the log |
| Decided or resolved the outcomes of the branch's complaints | Inflated form of F2 | F2's quote at its own scope. "Handled the log" stays as handled the log. F2's slot asks what part was yours |
| Coached supervisors, or managed escalations across branches | Inflated form of F7 | F7's quotes at their own scope: new tellers, the script, the supervisor job |
| Wrote or designed the escalation script | Inflated form of F7 | Your sentence says "our escalation script". Trained on it, not authored it |
| Ran the region's complaints reporting, or presented it to regional leadership | Inflated form of F5 | F5's quote at its own scope: the spreadsheet you built, which one regional manager uses |
| Has contact-centre experience | Negative you stated, F4 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, executives or a board | Negative you stated, F8 | "I haven't presented to anyone above regional level." No slot for the senior part |

## Values cheat sheet (scored in Round 3, useful in Round 2)

The values come from the text you pasted, copied from ashgrovecu.org/about/values on 26 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's view, not the institution's convenience | No quoted sentence carries one. Selection scaffold: pick a time you chose what was right for a member over what was easier for the branch. It needs the member's situation, the easier option, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (C5) |
| Plain Words | If something needs explaining twice, the explanation is the problem | F7: "trained new tellers on our escalation script". Answer slot: if your training or the script's wording changed because it wasn't landing, say what changed. If not, say so plainly and describe how you trained them (C2, C6) |
| Neighbours, Not Numbers | Each branch belongs to its town | F1: "6 years in retail banking, the last 3 as a branch supervisor". The quote gives you the setting, not a story. Selection scaffold: pick a time a member's or the town's situation changed what you did at the branch. If none comes to mind, say so plainly and say how you would handle the hub move with this value in mind (C7, D4) |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | F5: "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: if you built it because something was missing, say what was missing and how you noticed. If it was assigned to you, say so plainly and describe what you built (C3, C8) |

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter's email says only "a 20-minute case on a complaint escalation." The format (written scenario, role-play or discussion) isn't known. Ask in Round 1 (reverse question R1-1).

**Facts to build on**
- The role: "Own the member complaints process end to end across branches and the contact centre" and "coach branch supervisors on escalations" — JD `[grounded]`
- The panel scores against the four values — recruiter `[grounded]`
- Context: the hub consolidation over 2027 and the digital shift — strategy brief `[grounded]`
- Your side: F2, "I handled the branch's formal complaints log"; F7, "trained new tellers on our escalation script" and "the last 3 as a branch supervisor". Say these at their own scope if you bring your background in. The case is about what you *would* do, so it needs no claims about your past

**A 20-minute structure** `[generic]`
1. **Clarify (2 min):** who the member is, what happened, where it came in (branch or contact centre), what's been said to them so far, and whether anything makes them vulnerable.
2. **The member today (4 min):** what you'd do or say to them now, in plain words, and who keeps hold of it (Own the Fix).
3. **The rules and the record (3 min):** the complaint goes on the formal record, and the regulatory clock starts. Your material doesn't name the rules Ashgrove works under, and neither does this pack. If you've confirmed them by the day, name the deadline. If not, say you'd confirm the clock first.
4. **The supervisor (4 min):** how you'd coach the supervisor who escalated it, rather than taking it off them.
5. **The pattern (4 min):** is this a one-off or a theme? Where it would show in the monthly report on volumes and resolution times, and whether it points at a process, a branch or a self-service journey.
6. **Close (3 min):** the resolution, what changes, and which value each step served.

**Theses to choose from, each with its concession** (pending your approval)

| Thesis | Concession you name yourself |
|---|---|
| Fix it for the member first, then fix the process | Speed can't skip the record or the regulatory clock. The quick fix still goes on the log |
| An escalation is a coaching moment for the supervisor, not a takeover: the person who found the problem keeps hold of it | Some cases you take on yourself: a vulnerable member, a possible regulatory breach, or a supervisor out of their depth |
| Treat each escalation as data and trend it monthly | One case isn't a trend. Don't redesign a process around a single complaint |

**Standing out:** the expected answer is apologise, investigate, resolve. Go further by tying each step to a named value and by asking whether the complaint touches the hub move or a digital journey. **The thing to say no to:** don't promise an outcome or compensation before the facts are in, and don't let the member be bounced between branch and contact centre. Say plainly that you would stop that happening.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| F1 4+ years financial-services operations | A1, B8 |
| F2 regulated complaints | B2, C1, D3 |
| F3 own the process across branches | B4, D1, D3 |
| F4 contact centre | B1, B4, G1 |
| F5 monthly reporting on volumes and resolution times | B7, E2 |
| F6 Excel reporting | B3, G2 |
| F7 coach supervisors on escalations | B6, E1, E3 |
| F8 presenting to senior leaders | B4, B5 |
| F9 digital and self-service | D2, D4 |
| Strategy: hubs, digital, small-business lending, app-only banks | A2, D1, D2, D4, reverse questions |

---

# Round 1 — Recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | High: a recruiter screen's default register, and logistics are always covered | A 90-second arc built from your quoted sentences. Treat casual questions as scored |
| Skeptic (light) | Knockout checks on the JD's named requirements | Medium: the JD names the contact centre, regulated complaints and Excel, and recruiters screen against named requirements | Short, honest answers at your quotes' scope. Save the depth for Round 2 |
| Values | A preview of the four values | Low: the recruiter told you the values are scored by the panel | Know the four names, word for word |

## Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | Ninety seconds, in this order: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log, and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. The pack doesn't supply your reason | The opener in every recruiter screen. F1, F2, F5 and F7 are the rows closest to the JD, so they make the arc. EXP because it sets the story every later round checks |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Your reason is yours, so give it in your own words. Material you can hook it to: member-owned; one value by its official name and why it matters to you; the hub and digital plans. If your reason is specific to credit unions, say so. If it's this role more than credit unions as such, say that plainly | Motivation consistency gets checked again by every later round. CO because it tests whether you've read Ashgrove's own material |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Standard in a recruiter screen. JD because it's the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Standard screen logistics. JD because it's the job's terms |
| A5 | "The role covers branches and the contact centre, and the branches are moving to hubs. Where could you be based, and how are you with travel?" | JD | [grounded] | Logistics slot: say where you can be based and how much travel works for you, in your own words | The JD's cross-branch scope and the hub plan make location a likely check. JD because it's the job's terms |
| A6 | "Why are you looking to move on?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, in a sentence or two | Standard screen question. EXP because it's about your path |

## Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre too. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Plain acknowledgment: "I haven't worked in a contact centre." Then one sentence you can stand on: "I handled the branch's formal complaints log." Then one line on how you would learn the contact centre's side, as a plan. Keep it short here; B4 is the deep version | F4 is a stated gap and the JD names the contact centre, so a screen checks it. JD because it scores a named requirement |
| B2 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log" | Words: "I handled the branch's formal complaints log." Answer slot: if those complaints came under regulatory rules, name the rules and what part was yours. If not, or you're not sure, say so plainly and describe the log as it was | F2 is the requirement nearest your background and the one most likely to be screened literally. JD for that reason |
| B3 | "Are you comfortable with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it at its scope: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it's in Excel, say so and name the features you used. If it's another tool, name it plainly | F6 is a named requirement, and a yes-or-no check is typical in a screen. JD because it scores the JD's line |

## Reverse questions, Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What does the 20-minute case look like on the day: a written scenario, a role-play, or a discussion?" | It fixes the format of the case build, and recruiters usually answer it |
| R1-2 | "Will I have the names of the Head of Member Services and the panel before 5 December?" | Interviewers aren't assigned yet, and names unlock real prep |
| R1-3 | "Is this a new role, or am I taking over from someone?" | It tells you whether you'd inherit a complaints process or shape one |
| R1-4 | "Where is the role based as the branches move to hubs?" | It shows you've read the strategy brief, and it's a real logistics question |
| R1-5 | "What made the last people who did well in Member Services stand out?" | It invites the recruiter to tell you what's scored, without asking them to break confidence |

---

# Round 2 — Head of Member Services (your future manager), 45 minutes, mostly behavioural

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioural | "Tell me about a time…" questions on the job's core: escalations, training, building fixes, disagreement | High: the recruiter said "mostly behavioural" | One story per theme, mapped from your quoted sentences, a selection scaffold where none carries one; "we" for context, "I" for your part |
| Skeptic | Pressing on the gaps between one branch and the whole network | High: a hiring manager is derisking the hire, and F3, F4 and F8 are the visible gaps | Rehearse B4 until it's boring: hold what your quotes carry, name the limits before they're asked for, give a plan |
| Case and Strategist | Problems from the role's actual roadmap | Medium: the hiring-manager default, lowered by "mostly behavioural" | Clarify, set the aim, structure, then name the risks; use Ashgrove's words |
| Pressure | Time-boxed "why you" questions and "how much was you" | Low: one or two probes are common from a manager hiring for a gap | Pause, hold through two follow-ups, concede specifically |

## Bank C: Values and Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint that needed escalating. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint from your time handling the branch's formal complaints log. It needs what the member raised, what you did, where it went and how it ended, with "I" for your part. If no such complaint comes to mind as yours, say so plainly and describe how the log worked | The JD's escalation and complaints lines (F2, F3) make this the core behavioural question. VAL first, JD content second |
| C2 | "Tell me about a time you trained someone and it didn't land the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story map: new tellers, the escalation script. Answer slot: if a teller didn't get it first time and you changed how you trained them, say what you changed. If it landed, or you can't recall a time it didn't, say so plainly and describe how you trained them | F7 is the evidence behind "coach branch supervisors". The Plain Words value is the theme. VAL, with EXP depth |
| C3 | "Tell me about something you built or changed because nobody else was going to." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story map: the spreadsheet you built, and the regional manager who uses it. Answer slot: if you built it because something was missing, say what was missing and how you noticed. If it was assigned to you, say so plainly and describe what you built | The Own the Fix value is the theme, and F5 is your nearest sentence. VAL |
| C4 | "Tell me about a time you disagreed with your manager about how something should be handled." | VAL | [generic] | Selection scaffold: pick a time you raised a different view with someone senior. It needs what was at stake, what you said, what happened and how the relationship was afterwards. If no such time comes to mind, say so plainly and say how you would raise one | A future manager tests whether you'll tell them hard things, and the role reports to senior leaders (F8). VAL |

## Bank B: Skeptic (deep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "This role owns complaints across every branch and the contact centre, and reports to senior leaders. You've handled one branch's log, you've never worked in a contact centre and you've never presented above regional level. Why are you ready?" | JD | [grounded] "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" "trained new tellers on our escalation script" "the last 3 as a branch supervisor" "Never worked in a contact centre" "I've never presented to anyone above regional level" | **The highest-ROI prep in this pack.** Name the limits first: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then hold on four sentences: "I handled the branch's formal complaints log", "I built the monthly complaints spreadsheet our regional manager uses", "I trained new tellers on our escalation script", and "I've spent the last three years as a branch supervisor." Then a plan, as a plan: time with the contact centre on live complaints early on, and an offer to have your first senior report reviewed before it goes up. **Follow-up 1** ("one branch is small"): hold — "It was one branch's log." Don't add size or figures. **Follow-up 2** ("why not hire someone from a contact centre?"): concede the gap is real, then hold on the supervisor job, since the role coaches branch supervisors. Say what you've done and let them draw the conclusion | F3, F4 and F8 are where this role presses hardest on your background, so this objection will come in some form. JD because it scores the role's scope against the stated gaps |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" "Never worked in a contact centre" | Pick one real one: senior presenting or the contact centre. Plain acknowledgment, then the plan. Answer slot: if you have presented at regional level, say to whom and about what. If not, say so plainly. Don't offer a weakness that's really a strength | F4 and F8 are stated gaps, and a rehearsed honest pick beats a dodge. JD |
| B6 | "You'd be coaching branch supervisors, people at your level today. Why would they listen to you?" | JD | [grounded] "trained new tellers on our escalation script" "the last 3 as a branch supervisor" | Hold at scope: you've been a branch supervisor for the last three years, and you trained new tellers on the escalation script. Answer slot: if you've helped a fellow supervisor with an escalation, say how. If not, say so plainly and say how you'd start with supervisors | F7 is a transferability row. The seat you share with them is what your quotes carry. JD |
| B7 | "Tell me about your monthly complaints spreadsheet. What does it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe it at its scope: you built it, and your regional manager uses it monthly. Answer slot: if it counts volumes or resolution times, say what and how figures get in. If it tracks something else, say what, plainly. If a figure comes up, say how it's counted, or say plainly that you don't know | F5 is your nearest evidence for the reporting requirement, and a manager will check it closely. EXP, with JD content |

## Bank D: Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Eight branches become five hubs over 2027. What happens to complaints, and what would you do?" | CASE | [grounded] | Clarify: which branches, when, how members are told. Hypotheses, said as hypotheses: access, travel and change-of-routine complaints. What you'd watch monthly: volumes and resolution times by branch before, during and after. What you'd do: brief supervisors at closing branches on escalations early, use plain words in member letters, tie it to Neighbours, Not Numbers. Risk: closing-branch staff carrying the complaints while their own jobs change | The strategy brief's hub plan sits right inside this role (F3). CASE delivery, CO content |
| D2 | "We want 40% of member service on digital by 2028. How should the complaints process support that?" | CASE | [grounded] | Structure: complaints as the signal of where self-service journeys break; a monthly theme fed to the digital teams; members who can't or won't go digital still served first (Members First, Always); app-only banks set members' expectations. If asked about your past digital work, use F9's slot: if you've worked on one, say what part was yours; if not, say so plainly and give this plan | The 40% target and the JD's self-service line (F9). CASE delivery, CO content |

## Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone from our own contact centre?" | JD | [grounded] "the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "Never worked in a contact centre" | Pause, then three beats: the branch supervisor job, the branch's formal complaints log, and "I haven't worked in a contact centre." Then what you'd do about that. Don't run down the other candidate | F4 is the obvious angle for a time-boxed challenge. JD, delivered under pressure |
| G2 | "That spreadsheet, how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold your sentence: "I built it." Answer slot: if others supplied data or shaped it, say who did what. If you built it alone, say so. Hold through two follow-ups; concede only what's true | F5 and F6 rest on one sentence, which makes it the obvious attribution probe. EXP |

## Reverse questions, Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would a good first six months look like from your side?" | It gets your future manager to define success for you |
| R2-2 | "Where does the complaints process work least well today: in branches, in the contact centre, or in the hand-offs between them?" | It shows you're thinking end to end, the JD's own phrase |
| R2-3 | "How are complaint volumes and resolution times reported to senior leaders now, and who would I be presenting to?" | It addresses F8 as planning rather than a weakness |
| R2-4 | "How much support is there early on for learning the contact centre's side?" | It turns F4 into a ramp plan, and their answer tells you a lot |
| R2-5 | "How will complaints be handled at branches during the move to hubs?" | It uses the strategy brief and goes straight to the role's hardest year |
| R2-6 | "When small-business lending launches in Q1 2027, how will its complaints come into this process?" | A new product means new complaint types, and it shows you read the brief |

---

# Round 3 — Panel of two branch managers, 60 minutes, includes the 20-minute case, scored on the four values

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioural | One question per value, scored | High: the recruiter said the panel "score against the four values" | Use the values cheat sheet: one story or honest scaffold per value, with the value named by its official title |
| Case and Strategist | The 20-minute escalation case, plus follow-ups | High: the recruiter named the case | Use the case build above: clarify, member, record, supervisor, pattern, close |
| Peer Evaluator | Where your job ends and theirs begins | Medium: branch managers would work with this role on their supervisors and escalations | Propose principles for where the line sits rather than pretending to know it; say what you'd bring their branches |
| Skeptic | One check on the step up | Low: the panel's focus is values and the case | Hold at your quotes' scope |

## Bank C: Values and Behavioural (scored)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Members First, Always: tell me about a time you decided from the member's side of the counter." | VAL | [generic] | Selection scaffold: pick a time you chose what was right for a member over what was easier for the branch. It needs the member's situation, the easier option, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A published, scored value. No quoted sentence carries a story for it. VAL |
| C6 | "Plain Words: tell me about a time something had to be explained twice, and what you changed." | VAL | [grounded] "trained new tellers on our escalation script" | Story map: training new tellers on the escalation script. Answer slot: if the script's wording or how you taught it changed because it wasn't landing, say what changed. If not, say so plainly and describe how you trained them | A published, scored value. F7 is your nearest sentence. VAL |
| C7 | "Neighbours, Not Numbers: tell me about a time your branch's place in its town shaped what you did." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a time a member's or the town's situation changed what you did at the branch. It needs the situation, what you did, and why the place mattered. If none comes to mind, say so plainly and say how you'd handle the hub move with this value in mind | A published, scored value, made sharper by the hub plan. F1 gives you the setting only. VAL |
| C8 | "Own the Fix: tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story map: the spreadsheet you built. Answer slot: if you built it because you found something missing, say what and how you saw it through. If it was assigned, say so plainly and pick another time you kept hold of a problem, or say none comes to mind | A published, scored value. F5 is your nearest sentence. VAL |

## Bank D: Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "Here's an escalated complaint. Walk us through what you'd do." (the 20-minute case) | CASE | [generic] | Use the case build: clarify, the member today, the rules and the record, the supervisor, the pattern, close on the values. Pick one thesis and name its concession yourself | The recruiter named this as the case. CASE |
| D4 | "A member at a branch that's becoming a hub says the app is no use to them and they want their branch kept. What do you do?" | CASE | [grounded] | Clarify what they actually need to do. Members First and Neighbours, Not Numbers: find how they can still be served (the hub, help with the app, the contact centre). Plain words on what's changing. Log it as a complaint if it is one, and trend it with D1's themes. Don't promise the branch stays | It combines the hub and digital plans with two values. CASE, CO content |

## Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "If you're coaching our supervisors on escalations, where's the line between your job and mine?" | JD | [generic] | Propose principles, not a turf map: managers run their branches; your role makes escalation consistent across branches and gives supervisors support. You'd agree the line with each manager rather than assume it. Say what they get: fewer escalations landing on them | F7's requirement, seen from their side. JD content, Peer delivery |
| E2 | "What would you need from branch managers to report complaints well each month?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Reciprocity: say what you'd need (consistent logging, a named contact) and what you'd give back (each branch's own trend, in plain words). If you bring up your background, say it at scope: you built the monthly complaints spreadsheet your regional manager uses | F5 and the monthly reporting line. JD content |
| E3 | "One of our supervisors keeps escalating things they should handle themselves. What would you do?" | CASE | [grounded] "trained new tellers on our escalation script" "the last 3 as a branch supervisor" | Structure: find out why first (unsure of their authority, the script, or fear of getting it wrong); coach rather than take over (Own the Fix); agree it with their manager. If you bring up your background, at scope: you've held the supervisor job, and you trained new tellers on the escalation script | Coaching supervisors is a JD line, and branch managers live with this. CASE |

## Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B8 | "You've worked in one branch. What will be hardest about working across all of them?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" | Honest and specific: each branch does things its own way, and you know one branch's log. Say what you'd do first, such as visiting every branch and reading each one's log. Stay at scope: the branch's formal complaints log | F1 and F3: the step up from one branch. JD |

## Reverse questions, Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What could someone in this role do in their first month that would genuinely help your branches?" | Reciprocity: it asks what you can give them, which is what a peer is weighing |
| R3-2 | "When a complaint escalates from your branch today, what happens next, and what would you change?" | It gets you their real process and their frustrations |
| R3-3 | "How are your teams preparing for the move to hubs, and where do you expect members to push back?" | Strategy plus Neighbours, Not Numbers, asked of the people living it |
| R3-4 | "Which of the four values do you see tested most at the counter?" | It shows you take the values as working rules |
| R3-5 | "How do your supervisors feel about escalations now: something they'd like more help with, or something they'd rather keep?" | It's about their people, and it's the seam E1 raised |

---

## Sources

**Provided documents**
- The JD for Member Experience Lead, pasted
- Ashgrove's values text, pasted; you copied it from ashgrovecu.org/about/values on 26 November 2026. The page wasn't fetched
- The recruiter's email on the process, pasted
- The 2026 strategy brief (published July 2026, sent by the recruiter), as you summarised it in your message
- Your background, from your message

No dossier was present.

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | You pasted the values text, copied this morning; it fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes all three rounds, the case and the values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 strategy brief is under six months old and supplies the CO and CASE content |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names have been assigned, so there was no query to form; there's no interviewer read |
| 5. representative Member Experience Lead JD | skipped | You supplied the JD |

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each round, persona weights per panel member, and a reverse question tied to each person's own career
- **Your CV** → CV lines alongside your message in the fit snapshot, and a defend-the-number question for any figure on it
- **Answers to the slots in F2, F5, F6, F7 and F9** (whether the log covered regulated complaints, what the spreadsheet counts and what it's built in, any help given to fellow supervisors, any digital or self-service work) → those rows, and B2, B3, B6, B7, D2, become story-mapped guidance instead of slots
- **A line from the recruiter on the case format, and which complaint rules Ashgrove works under** → the case build fixed to its real format and real regulatory deadlines
- **The strategy brief's own text** → the grounding brief in Ashgrove's exact wording and figures, beyond your summary
- **Prep time available** → a prioritised schedule for the days before 5 December
- **Deep research (L2)**, up to 6 more searches and 2 more fetches, several more minutes → recent context on the hub programme and small-business lending, and candidate reports on Ashgrove's interviews, labelled `[inferred]`
- **A `tuesday-dossier.md`** → verified evidence and a prohibited-claims list carried in from an earlier assessment, so the highest-ROI objection comes from evidence rather than being inferred
