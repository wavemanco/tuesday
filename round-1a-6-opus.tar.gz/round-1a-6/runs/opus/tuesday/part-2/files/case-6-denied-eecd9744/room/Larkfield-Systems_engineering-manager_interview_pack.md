# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** loop. Three scheduled rounds share one fit snapshot, then each round gets its own mini-pack.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus a cross-functional partner |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level, "values and leadership philosophy" (the recruiter's words) |

No interviewer names were given, so there is no interviewer read. Web research was refused in this session, so every case question is a role-family pattern rather than something about Larkfield itself.

---

## How to use this pack

**Personas** describe how a question gets asked: who is asking and in what style. **Types** describe what is being scored. A question in the pack has one of each.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values or leadership approach the round is looking for |
| EXP | Whether your claims hold up when someone digs into them: what was actually you |
| JD | Whether you can do the job as listed, gaps included |
| CO | How well you know the company's strategy, competitors and recent moves |
| CASE | How you structure a live problem from the role |

Provenance labels: `[grounded]` traces to what you told me; `[inferred]` is the pack's own reading of the fit, with the reasoning given; `[generic]` is a role-family pattern that says nothing specific about Larkfield.

An **answer slot** is a spot where the pack doesn't know the facts. It gives you both honest branches: if you did the thing, say how in your own words; if you didn't, say so plainly. The guidance is scaffolding, not a script.

**Highest-ROI prep in the pack: A1.** It is the scope-jump objection, and it will probably come up in every round. Round 3 asks it again under time pressure (J1).

---

## Fit snapshot (shared across all rounds)

Requirements are quoted from the role description in your message. Evidence is quoted from your message. Nothing else counts as evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material covers one team of six, not two squads of eleven, and your words stay at that scope: "I've been a team lead for three years, of a team of six." Answer slot: the two-squad line makes it likely you'll be asked about running more than one team. If you have ever coordinated work across a second team or group, say what it was and how you did it, in your own words. If you haven't, say so plainly and stay with the team of six. Also note "team lead" is the title you gave, and the material doesn't show whether it included line management. See F4 |
| F2 | "own delivery" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Pushing a reliability quarter through against roadmap pressure is a prioritisation call you made. It doesn't show that you owned delivery overall. Use the sentence as it stands. "After" says what came first; it doesn't claim one thing caused the other, so keep it. Answer slot: the "own delivery" line makes a question about how you plan and track delivery likely. If you set or tracked your team's delivery plans, say how, in your own words. If that sat with someone else, or there was no such process, say so plainly and come back to the reliability quarter |
| F3 | "hiring" — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap. But nothing sits behind this line yet, so expect a probe. Lead with the quote's own terms: you run the loop for backend roles, about 40 interviews last year. The 40 counts interviews, not hires, and "run" stays "run" |
| F4 | "growth for 11 engineers" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Being team lead of six touches people growth but doesn't show whether developing those six was your job. That's the pack's reading, not words for you. Answer slot: the growth line makes a question about developing engineers likely. If you held development conversations, wrote promotion cases or ran performance reviews for the six, say which ones and how, in your own words. If those sat with a manager above you, or didn't happen, say so plainly and stay with leading the team |
| F5 | "partner with hardware and product on roadmap" (the product side) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | "Against roadmap pressure" shows there was a roadmap and that it pressed on you. It doesn't show who you worked with on it. Answer slot: if you agreed the reliability quarter with a product manager or another roadmap owner, say who that was (by role) and how it went, in your own words. If not, say so plainly and stay with the sentence |
| F6 | "partner with hardware and product on roadmap" (the hardware side) — role description, your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | You've said this gap yourself, and no wording closes it. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as something you've done. Don't claim hardware roadmap work, and don't add anything to make the gap feel smaller |
| F7 | "device-management services" in "industrial IoT" — role description, your message | none given | none | [grounded] | discovery | Your material doesn't say whether any of your work has touched devices, fleets or firmware. Answer slot: if some of it did, say what, in your own words. If none did, say so plainly and stay with what your team at the payments company is on call for |

Your negative "I've never managed managers" matches no listed requirement, because the role description doesn't say whether the squads have their own leads. It's still the likeliest objection (A1, J1), and reverse question R1-1 asks the structure directly.

---

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "Lead two squads building device-management services" | A1, B1, J1, L2 |
| "own delivery" | B2, B4, G1, G2 |
| "hiring" | A5, H3 |
| "growth for 11 engineers" | B1, H4 |
| "partner with hardware and product on roadmap" | A2, A3, D3, D4, G1 |
| "industrial IoT" / device-management domain | C2, B3, G3, L1 |
| "values and leadership philosophy" (recruiter, via your message) | H1, H2, H3, H4, J1, J2 |
| "11 engineers" (scale) | A1, L2 |

---

## Round 1: Tuesday, hiring manager (Director of Engineering), 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope jump (F1), the hardware gap (F6) and why you're moving | High. A hiring manager is buying capability and looking for reasons to doubt the hire. This one would own your ramp, so the gaps are their risk to carry | Rehearse A1 until it's boring. Say the limit before they do, then build the bridge only from your quoted sentences, then give a ramp plan said as a plan |
| Case / Strategist | Live problems from the role: first 90 days, two-squad trade-offs, incidents | High. Hiring managers usually test with problems from their own roadmap. With no research, these are role-family versions | Clarify, then objective, then structure, then metrics and risks. Think aloud and challenge one premise respectfully |
| Conversational | The opener and the "why this move" chat | Low. Usually the first five minutes, but still scored | A 90-second arc built from F1's quote. Treat it as scored |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led one team of six and you've never managed managers. This is two squads and eleven engineers. Why are you ready?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | **Highest-ROI rehearsal in the pack.** Name the limit before they press: "I haven't managed managers." Then hold on what the quotes carry: three years as team lead of six, running the backend hiring loop (about 40 interviews last year), and pushing a reliability quarter through against roadmap pressure, after which your team's on-call burden dropped 60%. Then a ramp plan, said as a plan: how you'd learn the two squads, how you'd decide where your time goes, what you'd ask your director for. Follow-up 1, "So what would you do differently with eleven?": plan only, nothing presented as past. Follow-up 2, "And when both squads need you the same week?": concede that you haven't done this at that scale, then give your rule for choosing. Never fold on the three years, and never stretch them into two teams. Answer slot: if you have coordinated work beyond your own six, say what and how; if not, say so plainly and stay with the six | F1 plus your stated negative is the gap this role presses hardest, so this objection will come up in some form, probably more than once. JD because it scores the scope requirement head-on. It gets the most follow-up levels and the exact concession wording |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Answer it straight: "I haven't owned a hardware-adjacent roadmap." Then say what you'd do in the first month to close it, as a plan: who you'd sit with, which hardware milestones you'd learn first, how you'd find the dependency points. Hold if they push ("isn't that a big gap?"): agree it's real, restate the plan, and don't shrink the gap | F6 is the one gap you've stated yourself, and naming it before they find it turns a weakness question into a credibility gain. JD because it maps directly to the hardware-partnership line |
| A3 | "How would you partner with a hardware team on roadmap, given you haven't owned a hardware-adjacent roadmap?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Open with the plain acknowledgment from A2, then structure the answer: what you'd learn first (their release cycle and what fixes their dates), where the dependencies between their work and your services sit, a shared planning rhythm, and how you'd surface slips early in both directions. Say it as a plan. Ask one clarifying question back, such as how they handle dates today | F6 asked as a live problem rather than a record. CASE delivery on JD content. It lets you show structure exactly where you have no history |
| A4 | "Why leave a payments company, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your real reason, in your own words. The pack doesn't know it and won't supply one. Keep it forward-looking: what this role offers that you want, not what's wrong where you are. Under two minutes | The Skeptic's motivation check. Premised only on F1's "currently at a payments company". EXP because it tests whether your story holds together |
| A5 | "Walk me through how you run your hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Lead with the quote: you run the loop for backend roles, about 40 interviews last year. Describe what running it involves for you. Answer slot: if you set its stages, its scoring or how interviewers calibrate, say which ones and how; if those were set by someone else or don't exist, say so plainly and describe your part. If they probe the 40, say how it was counted (interviews you sat in, or loops you ran) in your own words; if you're unsure, say so. It counts interviews, not hires | F3 is your strongest direct match, and owning hiring is in the role, so a hiring manager will test it. EXP because the probe is about what "run" means |
| B1 | "You inherit two squads and eleven engineers. What do you do in your first 90 days?" | CASE | [generic] | Structure it: listen first (one-to-ones, the backlog, on-call and incident history, the roadmap with product and hardware), then name the two or three problems you'd tackle, then quick wins you'd use to earn trust, then what you'd measure at day 90. Include how you'd learn what each engineer wants to grow toward. Ask what the director sees as the biggest risk. The question needs no claim about your past, so the guidance makes none | The standard test of a step up in scope (F1, F4), asked as a plan. `[generic]` because no Larkfield context was researched |
| B2 | "Product wants a feature date. Your engineers say a device-management service needs a reliability investment first. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: what each option costs, what evidence you'd ask for on the reliability risk, who has to agree, and what you'd offer product (partial scope, a staged date). Then one line of evidence from your own experience, in the quote's own terms: you pushed a reliability quarter through against roadmap pressure, and afterwards your team's on-call burden dropped 60%. Keep "after"; don't claim the quarter alone caused the drop | Your quoted sentence is a close match to this exact trade-off, so a hiring manager who heard it will test it as a live problem. CASE delivery, drawing on F2 |
| B3 | "A firmware release breaks device check-ins with one of your services at 2am. Walk me through the first 24 hours." | CASE | [generic] | Structure: stabilise (roll back or isolate, and who decides), communicate (who hears what, when, including the hardware team), find the cause without blame, then prevent it next time (checks on the interface between firmware and services, staged rollouts, alerts). End with what you'd want from the hardware team afterwards. No claim about your past | A plausible live problem where hardware and software meet (F6, F7). `[generic]` because it's a role-family pattern, not a known Larkfield incident |
| B4 | "Six months in, how would you know whether your two squads are delivering well?" | CASE | [generic] | Give a short set of measures across outcomes (what shipped and whether it mattered), flow (lead time, predictability), and health (on-call load, attrition, morale), and say which one you'd watch most and why. Name one way each measure can mislead you. No claim about your past | Tests "own delivery" (F2) as a way of thinking rather than a record. `[generic]` as a role-family pattern |
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc on the quote's beats: nine years in engineering, the last three as team lead of six, now at a payments company. Close on why this role, in your own words. Don't add titles, team sizes or projects beyond what you'd stand behind | The opener sets the frame for everything after it. EXP because the arc is your claims in summary, and F1 is its only source |
| C2 | "What draws you to industrial IoT?" | JD | [grounded] | Your own reason, in your own words. Answer slot: if any of your work has touched devices, fleets or firmware, say what; if none has, say so plainly and say what draws you anyway. Don't pretend to domain knowledge you don't have | Asked casually, but it scores the domain fit that F7 leaves open. JD because it's tied to the role's stated industry |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "How are the two squads structured today? Do they have tech leads or squad leads, and who would report to me directly?" | Answers whether "never managed managers" matters for this seat, and shows you're thinking about structure on day one |
| R1-2 | "What would you need to see in the first 90 days to know this hire is working?" | Gets the real success criteria from the person who will judge them |
| R1-3 | "Where does the hardware–software seam cause the most friction right now?" | Points at the gap you've named (F6) as something to learn, not hide |
| R1-4 | "How is roadmap ownership split between you, product and hardware for these services?" | Clarifies how much of the roadmap you'd actually own |
| R1-5 | "What's the biggest delivery risk the squads carry into next year?" | Shows you're already thinking about their problems, not just your fit |
| R1-6 | "How do you like to work with the managers who report to you?" | A fair question for your would-be boss, and it tells you about the job |

---

## Round 2: the Thursday after, panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "Where's the seam between us", disagreement style, what you need from the PM and what they get from you | High. For a panel, the pack blends each member's top personas. Staff engineers and a PM are all working out what you'd add to or take off their plates | Frame it as reciprocity: what you bring them. Propose principles for the seam rather than pretending to know it. Tell disagreement stories that show spine and tact |
| Data-Driven Prober | The 60% figure taken apart: how it was counted, the denominator, what was yours | High. Technical specialists typically dig into the one number on your record | Know what you can and can't say about how the 60% was counted, and say plainly where you don't know. Name the assumption you'd defend least before they do |
| Case / Strategist | PM-led roadmap problems: features versus reliability, uncertain hardware dates | Medium. The PM is your future roadmap partner (F5) | Clarify the goal first, then structure. Use their words for things |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your team's on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slots for the number, each in your own words: how "on-call burden" was measured (pages, hours, incidents or something else); over what period, compared with what; what the figure is sensitive to; and the assumption behind it you'd defend least, said before they ask. If you don't know how it was counted, say so plainly. That's an honest answer and better than a method you can't defend a second time. The 60% belongs to "my team's on-call burden" and to nothing wider | Your headline figure, so staff engineers will press on it. EXP because it checks whether the claim holds up under scrutiny (F2) |
| E2 | "How do you know the drop came from the reliability quarter and not something else?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your sentence says "after", and that word is the honest one: it states the order of events. Hold it. Answer slot: if you looked at what else changed over the same period, say what you found, in your own words; if you didn't, say so plainly and don't claim the quarter caused the drop | This is the second follow-up a prober asks, and it breaks answers that stretched "after" into "because". EXP: the question is how much of the result you can claim |
| E3 | "What was actually in the reliability quarter? What did the team work on?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: describe the work as it happened, in your own words. The pack doesn't know what it was and won't supply it. Use "we" for the team's work and "I" for what was yours. What the quote says was yours is pushing the quarter through. If you also chose or shaped the work, say which parts; if others did, say so | Engineers want the technical substance behind the story (F2). EXP because it separates what you did from what the team did |
| E4 | "How do you stay technical enough to judge a design argument between two staff engineers?" | JD | [generic] | Answer slot plus approach: if you still review designs or code, say how and how often, in your own words; if not, say so plainly. Then the approach: you're not there to out-argue them. You make the decision criteria explicit (cost, risk, reversibility, operating load), ask for the strongest version of each side, and decide or escalate on a clear timeline | Staff engineers are checking whether you'll slow technical calls down or speed them up. JD because it maps to leading squads that build services |
| D1 | "We work across your squads. Where's the seam between your job and ours, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than claim to know their seam: they own the technical direction they're accountable for, you own priorities, people and delivery, and anything that crosses both gets decided openly with a named decider. For disagreement: talk it through first, write the options down, decide on a timeline, and both back the decision afterwards. Ask how it works today | The defining peer-panel question. `[generic]` because Larkfield's staff engineering role wasn't researched |
| D2 | "Tell me about a time you disagreed with a senior engineer on a technical call." | VAL | [generic] | Selection scaffold: pick a time with a real technical stake, where you didn't simply defer and didn't simply overrule, and where the working relationship survived. Say what you argued, how it was settled, and what you'd do the same or differently. If no such time comes to mind, say so plainly, then give the nearest thing your material supports, or how you would handle it | Checks your disagreement style with technical equals. VAL in the sense of working style. No quoted sentence carries a story here, so it's a scaffold |
| D3 | "When you pushed that reliability quarter through against roadmap pressure, who was pushing the roadmap, and how did it go between you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Lead with the quote. Answer slot: if the pressure came from a product manager or another person, say who it was (by role), what you traded or agreed, and where the relationship ended up, in your own words. If the pressure came from the plan itself rather than a person, or you can't say how it went, say so plainly and stay with the quote. Never describe the other side as the obstacle you beat | The PM will hear your strongest story as a story about a PM. This is the question that shows whether you're a partner (F5). EXP: it tests the part of the story the sentence doesn't state |
| D4 | "What would you need from me as your PM, and what would I get from you?" | CASE | [generic] | Answer both halves, with what they get first: predictable delivery and early warnings, honest estimates, and engineering trade-offs explained in product terms. What you'd need: clear priorities and the why behind them, room for reliability work, a shared view of hardware dependencies. Keep it as commitments for the future, not claims about the past | Reciprocity is what the Peer Evaluator scores. CASE because it's a working agreement built live (F5) |
| G1 | "A customer needs a feature that depends on new firmware next quarter, and the hardware team's date is uncertain. How do you plan your squads' work?" | CASE | [generic] | Clarify: how firm is the customer's date, what's the hardware team's confidence, and is there a version that ships without the firmware? Then structure: separate the work that doesn't depend on firmware, build against an agreed interface or a simulator, set checkpoints with hardware, and keep a fallback scope. Say how you'd communicate risk to the PM and the customer-facing team. No claim about your past | A live problem where hardware and product meet (F5, F6), likely from a PM on this panel. `[generic]` as a role-family pattern |
| G2 | "How would you split roadmap time between features, reliability and tech debt across two squads?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Give a principle, such as a standing share plus triggers that raise it (on-call load, incident trend), and how you'd agree it with product. Then one line of evidence, in the quote's terms: you pushed a reliability quarter through against roadmap pressure, and afterwards your team's on-call burden dropped 60%. Don't present a standing-share policy as something you ran unless you did | Product will want to know whether every quarter becomes a reliability quarter. CASE, drawing on F2 |
| G3 | "How familiar are you with device management: provisioning, over-the-air updates, fleet monitoring?" | JD | [grounded] | Answer slot: if any of your work touched these, say what, in your own words; if none did, say so plainly. Then a learning plan as a plan: what you'd read, who you'd shadow, and which service you'd learn end to end first. Don't bluff the vocabulary to people who own it | Staff engineers will check domain depth (F7) and will spot a bluff quickly. JD because the role builds device-management services |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | (to the staff engineers) "What could a new EM do in the first month that would genuinely help your work?" | The reciprocity question. It puts their needs ahead of yours |
| R2-2 | (to the staff engineers) "How are technical decisions across the two squads made today?" | Shows where the seam actually sits before you claim one |
| R2-3 | (to the PM) "How does a reliability or tech-debt request get onto the roadmap today?" | Connects to your own story (F2) without repeating it, and shows you'll negotiate rather than impose |
| R2-4 | "When a firmware change breaks one of your services, how do you usually find out?" | Shows you're curious about the hardware seam (F6) in their actual terms |
| R2-5 | "Where do the squads lose the most time today?" | An open question that tells you the real job |
| R2-6 | "From what you've seen, what should the person in this seat keep doing, and what should they change?" | Invites honest input without assuming who held the seat before |

---

## Round 3: the following Monday, VP Engineering, 30 min, "values and leadership philosophy"

The recruiter's description, via your message, is the source naming this as a values-style round. Larkfield's published values aren't in hand because research was refused, so there's no values cheat sheet. The upgrade menu says what one would add.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership-philosophy prompts and "tell me about a time" stories | High. The recruiter's own description of the round puts this first, ahead of the skip-level default | Two or three principles, each tied to something you actually did. Use "we" for context and "I" for your contribution. Where your material shows no ending, don't supply one |
| Pressure | Short time-boxed challenges, often the scope objection again | Medium. A skip-level default in a short session. Thirty minutes forces brevity | Pause, restate the question, anchor in what you stated, hold through two follow-ups, then concede what's real |
| Case / Strategist | Leadership at the org's altitude: structure, scale, what changes with devices in the field | Low. Thirty minutes and a values focus leave little room | State the frame first, then the answer, in under two minutes |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | Selection scaffold: two or three principles you'd genuinely defend, each followed by one thing you did. Two of your sentences can carry one each: pushing a reliability quarter through against roadmap pressure (afterwards your team's on-call burden dropped 60%), and running the backend hiring loop (about 40 interviews last year). The principles are yours to name. The pack won't write your beliefs for you. If a principle has no story behind it yet, say it's how you intend to lead rather than presenting it as a record | It's the round's stated subject (the recruiter's words), so it will come up. VAL because it scores whether your stated philosophy matches your behaviour |
| H2 | "Tell me about a time you pushed back on leadership or the roadmap and held your position." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Map it to the quote's beats: the roadmap pressure, the reliability quarter, that you pushed it through, and that afterwards your team's on-call burden dropped 60%. Answer slot: if you had to convince someone senior, say who it was (by role) and how, in your own words; if the pressure came from the plan itself rather than a person, say so plainly and tell the story at that scope. Keep "after" rather than "because" | Your one quoted story with a stake in it, so it's the natural choice for a values question on courage. VAL, mapped to F2 |
| H3 | "Tell me about a hiring decision that went wrong, or one you'd make differently now." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Context from the quote: you run the backend hiring loop, about 40 interviews last year. Selection scaffold: pick a real case with a lesson you then acted on. If no such case comes to mind, say so plainly, then say what you watch for in the loop, or how you would handle a bad hire | Hiring is in the role, and a VP will test judgement rather than volume. VAL, drawing on F3 for context only |
| H4 | "How do you grow engineers who are technically stronger than you?" | VAL | [grounded] | Philosophy plus slot: how you'd create scope for them, sponsor them, and keep out of their way. Answer slot: if you've done this for someone on your team of six, say what you did, in your own words; if not, say so plainly and give the approach as how you'd do it. Don't describe promotions you didn't drive | Tests the "growth for 11 engineers" line (F4) at the level of philosophy. VAL because the VP is scoring values, not process |
| J1 | "Sixty seconds: why you over an internal candidate who has already managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A1 compressed to sixty seconds. Concede first: "I haven't managed managers." Then hold on the quotes: three years as team lead of six, and pushing a reliability quarter through against roadmap pressure, after which your team's on-call burden dropped 60%. Then one sentence on what you'd bring. Don't knock the hypothetical candidate. If they push again, hold, don't add claims, and concede only what's real | The highest-ROI objection (F1) again, now under time pressure. JD because it scores scope, delivered as Pressure |
| J2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Split it the way the sentence does: the on-call burden was your team's, and pushing the quarter through was yours. Answer slot: if you also did or directed specific parts of the work, say which, in your own words; if the team did it, say so and credit them. Keep "after". Hold that the push was yours. Concede that the result was the team's | The classic attribution stem, and the one number on your record (F2). EXP because it's about attribution honesty |
| L1 | "What changes in how you lead when a bad release can affect devices in the field, not just a web request?" | CASE | [generic] | Frame first: higher cost of failure, slower and harder rollback, longer feedback loops, and more teams involved. Then what you'd change: release discipline (staged rollouts, kill switches), shared ownership with hardware, and calmer, slower decisions. Close with what you'd need to learn first. Answer slot on F7: if your work has touched devices, say so; if not, say it plainly | A strategy-level question suited to the VP's seat. `[generic]` because Larkfield's strategy wasn't researched. CASE delivery |
| L2 | "When would your two squads need a third squad, or a manager between you and them?" | CASE | [generic] | Give your signals: your one-to-one load, decision speed, the span of context you can hold, and growth paths for senior engineers. Then the options and their costs. You can say honestly that you haven't managed managers, using the plain acknowledgment from J1, and that this is how you'd think it through | Tests whether you can reason about org design one level up (F1). CASE because it's a live structural problem |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What does good engineering leadership look like here, in your words?" | Gets the values in their own vocabulary, which you couldn't research |
| R3-2 | "How do you support managers stepping up to a bigger scope than they've held before?" | Names your step-up honestly and asks about it |
| R3-3 | "Where does engineering need to be in two years that it isn't now?" | Thinks at the VP's altitude |
| R3-4 | "When reliability and roadmap pull against each other here, how does that usually get decided?" | Ties to your own story (F2) and tests the culture you'd work in |
| R3-5 | "A year from now, what would make you say this hire was a great call?" | Ends on their success criteria |

---

## Prohibited claims

Things this pack won't coach, built from the fit snapshot before any bank was written. These are the claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated: "I've never managed managers and never owned a hardware-adjacent roadmap" | "I haven't managed managers." No slot |
| Has owned or run a hardware-adjacent roadmap | A negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." Then a plan, said as a plan. No slot |
| Has led two squads, several teams, or around eleven engineers | Inflated form of F1 | F1's quote at its own scope. Pack's observation: your material covers one team of six. The A1 slot stays inside coordinating beyond the six |
| Owned delivery or the roadmap for the team | Inflated form of F2 | F2's quote at its own scope: you pushed a reliability quarter through against roadmap pressure |
| The reliability quarter caused, or "drove", the 60% drop; reliability or incidents improved 60% | Inflated form of F2. "After" became "because", and the 60% moved off "on-call burden" | The quote as written: "after", and the number attached to your team's on-call burden |
| Hired around 40 engineers, or designed the hiring process | Inflated form of F3. The 40 counts interviews, and "run" isn't "designed" | F3's quote at its own scope. The A5 slot asks only which parts were yours to set |

---

## Sources

**Provided:** your message (the role description, the three-round schedule, your background).

**Searches sent:**
- `Larkfield Systems values`: refused (web search not permitted in this session)
- `Larkfield Systems interview process engineering manager`: refused
- `Larkfield Systems industrial IoT news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The one search was refused. It would have supplied Larkfield's values by name, the values cheat sheet for Round 3, and VAL questions mapped to each value |
| 2. `{company} interview process {role family}` | unavailable | The one search was refused. Your own words already establish the three rounds, so the persona weights stand. It could have added what each round contains, such as whether the panel includes a system-design or case segment |
| 3. `{company} strategy` / recent news | unavailable | The one search was refused. It would have made B1–B4, G1 and L1 Larkfield-specific and added a CO question. Those questions are `[generic]` as a result |
| 4. `{interviewer name} {company}` | n/a | No names were given, so there was no query to form. There's no interviewer read, and the reverse questions are role-level |
| 5. representative `{role title}` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search (L1)** → Larkfield's values by name, a values cheat sheet for Round 3, and Larkfield-specific versions of B1–B4, G1 and L1, plus a CO question
- **Deeper research pass (L2)** → a strategy brief, recent org context and candidate reports on this loop, for sharper case and CO questions. Up to 6 more searches and 2 more fetches, several more minutes
- **Full posting text** → the requirements beyond the one-line summary become fit rows and JD questions, and the coverage table becomes complete
- **Your CV** → evidence rows beyond the four sentences in your message, and story-mapped guidance where the pack now has to use selection scaffolds (D2, H3)
- **Interviewer names (Director, the staff engineers, the PM, the VP)** → an interviewer read per round, persona weights based on their public profiles, and at least one reverse question tied to each person's own path
- **The recruiter's notes on the panel format** → whether Round 2 has a system-design, case or presentation segment, and a build section for any declared deliverable
- **Whether "team lead" included line management (reviews, development, promotion cases)** → upgrades F1 and F4 and sharpens A1, H4 and J1
- **How the 60% was measured, and over what period** → E1, E2, J2 and the F2 bridge get your own counting method in place of answer slots. Any record of it, such as a paging or incident dashboard export if one exists, would raise F2 from medium
- **What the hiring loop involves for you** (stages, scoring, calibration) → upgrades F3 and A5. Any loop artifact you had a hand in, such as an interview scorecard, would raise F3 from medium
- **A `tuesday-dossier.md` from an earlier fit check** → evidence-graded rows, a named objection in place of the inferred one in A1, and a prohibited-claims list confirmed by you rather than built here
