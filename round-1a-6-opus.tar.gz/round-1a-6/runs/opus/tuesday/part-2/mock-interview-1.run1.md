I'm reading the prep playbook's remaining rules, then running a few quick web checks on Northwind and Dan before I write the pack.
I've built Priya's prep pack for one 60-minute peer conversation with Dan. It has 23 questions in tables, grouped by interviewer persona and question type, and each one has answer guidance and a rationale. It's built only from your notes. Web search was blocked by this session's permissions, so I couldn't check Northwind's values, the interview loop, the Compass details or Dan's profile.

The questions sit in seven persona tables, ordered by how likely each style is with Dan:

| Persona | Questions | Main reason |
|---|---|---|
| Data-Driven Prober | 5 | He's a peer and calls himself "relentlessly data-driven" |
| Peer Evaluator | 5 | Same VP, and his lane overlaps hers |
| Case / Strategist | 4 | Leans toward pricing; uses the bundling threat and Compass from your research note |
| Skeptic | 3 | Quota/sales ops is his lane; his startup chapter suggests probes on scrappiness |
| Pressure, Conversational, Values | 2 each | Less likely, but she shouldn't meet these styles for the first time live |

- **Highest-ROI prep is D1:** "You haven't done sales ops or set quota, and your background is consumer tech. Why should I trust GTM plans from you?" Dan's own lane is sales strategy, so expect this in some form. The guidance has her say the limit before he finishes, then covers three follow-ups with exact concession wording.
- **Every JD requirement has questions,** and a coverage table maps each one to its question IDs. "Partner-motion design" gets two (A2 and C4) because it's the one marked required.
- **The ~$400M figure gets one wording everywhere.** It shows up in A1, B5 and E2, and the guidance keeps her to "I proposed the change, and it was credited with roughly $400M." Dan will go after the number, and three slightly different versions would hurt her.
- **Gaps are left as instructions to answer honestly in the interview.** Where your notes don't say something, the guidance gives her two honest branches instead of supplying details. Examples: how the $400M was counted, whether she was in the carrier negotiations, which AI tools she uses.

The pack also has:
- a requirement-by-evidence fit table
- notes on reading Dan
- six questions for her to ask Dan, one tied to his pricing and startup path
- a list of claims the pack won't coach, like "drove $400M" or "negotiated the carrier deals"

There's no section mapping Northwind's published values to her stories, because I couldn't look them up and nothing suggests a values round. The rows about Dan come from your summary of his profile.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-1-denied-8d77fa8d:
- Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md

Say the word and I'll play Dan as the Skeptic on D1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for Priya to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD and Priya's actual CV? I'd rebuild the fit table on her own lines and the JD's own wording instead of your summaries.

Web search was refused, so do you want to allow it for this session? That's up to 6 searches and 2 page fetches to check Northwind's values, the loop, whether the research note is current, and Dan's public profile.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, who would be Priya's **peer** (both report to the same VP). **Format:** one 60-minute conversation.

Built from the coach's notes: the JD highlights, Priya's background summary, Dan's profile summary and the coach's research note. The full JD and Priya's CV were not provided, and web research was refused by this session's permissions (see Sources). The coach's own description, one 60-minute conversation with Dan, sets the loop, so persona weights rest on that and not on a generic pattern.

---

## How to use this pack

- **Personas** describe *how* a question is asked (who is asking and in what style). **Types** describe *what is being scored*. Each question has one of each, so Priya can rehearse the content and the delivery.
- **Guidance is scaffolding, not a script.** Every claim about Priya's past rests on a sentence quoted in that row's Provenance cell. Where the material doesn't say something, the guidance is an **answer slot**: an instruction for the interview with two honest branches. Answer it from what actually happened, or say plainly that it didn't happen or wasn't hers.
- Question IDs go by persona: A, B, C, D, E, G, H. **There is no bank F**, so question IDs never clash with fit-snapshot rows F1 to F7.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the company's published values |
| EXP | Experience deep-dive | Whether claims survive scrutiny; what Priya actually did |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company & strategy | Homework depth; thinking at Northwind's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

---

## The fit snapshot

Requirements come from the JD highlights in the coach's notes, not the full JD text. Evidence comes from the coach's notes, not Priya's own CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says product strategy and ops at a consumer-tech company. It does not say GTM ownership or B2B, and the words stay there: "I spent nine years at a large consumer-tech company in product strategy and ops." Answer slot: the JD's own-GTM line makes a probe on taking products to market likely. If any of that work took a product to market and part of the go-to-market was hers, she says which part and how, in her own words. If there was no such step, or it wasn't hers, she says so plainly and stays with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote shows a change she proposed and an uplift it was credited with. It does not show whether this was whitespace across a customer lifecycle, so the bridge shouldn't be stretched. Words at the quote's scope: "I proposed a store-surface change that was credited with roughly $400M in ARR uplift." Answer slot: the JD's land/adopt/expand/renew line makes a probe on lifecycle whitespace likely. If that work, or other work, found growth in an existing customer or partner base, she says where and what part was hers. If not, she says so plainly and says how she would look for whitespace here (C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but nothing has been inspected behind it, and a self-described data-driven peer may test it live. Lead in the quote's terms: "I'm skilled in SQL and Tableau." The quote says skilled. It doesn't say how much analysis she ran alone, so A4's scaffold covers the "independent" part |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a model used in partner negotiations. It does not say she designed a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe likely on whether the model shaped partner terms or structure. If it did and that part was hers, she says which and how, in her own words. If she wasn't part of the negotiations or of any design, she says so plainly and stays with the model she built |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap. Lead with the quote's own terms: she set the annual volume targets, with cross-org consensus. Answer slot: the JD's influence line makes a probe on how consensus was reached likely. If the orgs disagreed, she says what happened and what part was hers. If they didn't, she says so plainly and stays with the targets |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The material says daily use of AI tools, not AI product work. Words: "I use AI tools daily." Answer slot: the JD's AI line makes a probe on what that use looks like likely. She names the tools and what she uses them for, in her own words. If any of it touched AI product or GTM work, she says which. If none did, she says so plainly and stays with daily use |
| F7 | Territory, capacity and quota planning, a role-family expectation for a GTM strategy seat that sits beside Sales Strategy. It is not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A stated gap that wording can't close. Words: "I haven't done classic sales-ops or quota-setting work." Then how she would learn it, said as a plan and never as a past: lean on Dan's team for the mechanics and learn the current territory and comp model early. She never claims quota work and never presents volume targets as quota |

---

## Reading the interviewer

Source: the coach's summary of Dan's public profile. The search for his public footprint was refused, so none of this was checked independently.

| Signal | Implication for Priya |
|---|---|
| Self-describes as "relentlessly data-driven" | Every number gets probed down to its assumptions. The ~$400M (F2) will be asked about in some form, so she needs a single wording she uses every time, plus "I don't know how that was counted" ready if it's true |
| Career built on pricing and monetization roles | Case questions will lean toward packaging, pricing and unit economics. The bundling threat and Compass packaging are his home ground (C1, C2) |
| One early-stage startup chapter | Builder stories land well. Expect scrappiness probes and some skepticism about big-company pace (D3) |
| Peer under the same VP, and his lane is Sales Strategy | He is weighing what this hire costs and gives *his* team. F7 sits squarely in his lane, which is why D1 is the highest-ROI prep |
| Shared vocabulary | F4's quote, "built a partner-level revenue model used in carrier negotiations", is monetization language. She can describe it in those terms and let him draw the connection. There is no shared career jump in the material, so none is offered |

---

## Persona table

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Asks for denominators, how numbers were counted, maybe a live SQL prompt | **High (5 questions).** The peer prior puts the Prober on top, and "relentlessly data-driven" pushes it further | Know what she can and can't say about how each figure was counted. Name the weakest assumption before he does |
| Peer Evaluator (B) | Seam-splitting with Sales Strategy, "what would you need from me", credit-sharing | **High (5).** This is a peer relationship under one VP, and an emerging-products GTM role overlaps his lane | Frame things in reciprocity. Propose principles for the seam rather than pretending to know where it sits |
| Case / Strategist (C) | Live problems on bundling, Compass packaging, whitespace, partner motion | **Mid-high (4).** His pricing spine tilts the cases toward monetization. The research note supplies live strategy topics | Clarify, then objective, segmentation, approach, metrics, risks. State a hypothesis early and challenge one premise per case |
| Skeptic (D) | Quiet probing of F7 and F1: no quota experience, consumer tech to B2B | **Mid (3).** F7 falls in his lane, and the startup chapter adds scrappiness probes | Rehearse D1 until it's boring. Name the limit first and attach a ramp plan |
| Pressure (E) | Time-boxed "why you" and attribution challenges | **Low (2).** Not a peer's default register, but a data-driven peer may push one metric hard | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational (G) | The opener, plus casual AI questions | **Low (2).** Openers still get scored, and AI is a JD plus | A scripted 90-second arc. Treat the AI aside as scored |
| Values / Behavioral (H) | Generic "unpopular truth" and "customer over metric" stems | **Low (2).** The coach's description of the session names no values round, and Northwind's values weren't researched | Use the selection scaffolds with their honest branches |

---

## Question banks

### A. Data-Driven Prober (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift on the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open at the quote's scope: "I proposed the store-surface change, and it was credited with roughly $400M in ARR uplift." Then four answer slots, in her own words. How it was counted: if she knows, she says how; if not, she says plainly "I don't know exactly how that figure was counted." What it's sensitive to: whatever she knows, and nothing guessed. The assumption she'd defend least: she names it before Dan does, or says how she'd find out. Which part was hers: the quote says *proposed*. Anything beyond proposing goes in only if it was hers; otherwise she says so plainly. She uses the same wording every time it comes up (B5, E2) | This is the headline metric in F2, and a self-described data-driven interviewer will go after it. EXP because it tests counting and attribution, not the role |
| A2 | "Walk me through the partner-level revenue model that was used in carrier negotiations." | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats are the quote's: she built it, it worked at partner level, and it was used in carrier negotiations. She explains its structure and inputs as she actually built them, in her own words. Answer slot: the JD's partner-motion line makes a probe likely on how the model shaped partner terms. If its outputs shaped specific terms and she knows how, she says which. If she wasn't in the negotiations, or doesn't know how it was used there, she says so plainly and returns to what the model did | F4 is her closest evidence for the one requirement marked required, so Dan will test the mechanics. Primarily EXP, because it checks what she built; secondarily JD, because of partner-motion design |
| A3 | "Say we have a usage table and a contracts table for one of the new product lines. How would you find the accounts most likely to expand? Talk me through the query and the Tableau view." | JD, CASE | [grounded] | Clarify the grain first: account or workspace, and over what time window. Define the expansion signal, such as usage growth, seat saturation or feature breadth. Walk through the joins and the cohort, check data quality aloud, then describe the view: segment against lifecycle stage, with drill-down. State a hypothesis early. The question asks nothing about her past, so the guidance claims nothing | This is the JD's SQL/Tableau line (F3's requirement) asked as a live problem, which a data-driven peer is likely to try. JD content with CASE delivery. Grounded on the JD highlight |
| A4 | "Tell me about an analysis you ran yourself, end to end, in SQL and Tableau." | JD, EXP | [grounded] "skilled in SQL/Tableau" | The quote carries the skill, not a particular analysis, so this is a selection scaffold. Pick one where she wrote the queries herself, it fed a real decision, and she can say what it showed and what changed. If no single analysis like that comes to mind, she says so plainly, then gives the nearest thing her material does carry, or walks through how she would do it (A3) | F3's quote says skilled. The JD says *independent*, and this question checks the difference. Open prompt themed on the JD line |
| A5 | "Which assumption behind the annual volume targets you set would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats from the quote: she set annual volume targets, with cross-org consensus. Weakest-assumption slot: she names the assumption she'd defend least, in her own words. If she can't name one, she says how she'd stress-test it. The pack supplies no assumption | F5 is the closest thing in the material to Dan's world of targets, and the weakest-assumption stem is a Prober staple. EXP because it tests what she knows about her own work |

### B. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side under the same VP. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD, CASE | [generic] | Propose principles for the seam instead of guessing where it sits. One: a single shared data source for the numbers. Two: an agreed cadence for joint reviews of the new product lines' targets and coverage. Three: decisions on the core number stay with his team, and decisions on the new products' GTM thesis stay with hers. Four: disagreements get settled on data, with each side saying up front what evidence would change their mind. Then ask him where he sees the seam today | This is the peer persona's signature question, scoring cross-functional influence (F5's requirement) with an equal. `[generic]` because nothing in the material describes this seam |
| B2 | "Tell me about a time you had to get a number agreed across orgs that didn't report to you." | JD, EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets she set, with cross-org consensus. She tells it in her own words. Answer slot: the JD's influence line makes a probe on disagreement likely. If the orgs disagreed, she says what happened and what part was hers. If they didn't, or she can't speak to the reporting lines, she says so plainly and stays with the targets | F5 is the direct evidence for the influence requirement, which a peer scores first-hand. JD because it maps to a stated requirement; EXP because the story will be probed |
| B3 | "What would you need from my team in the first 90 days, and what would you bring us?" | JD, CO | [grounded] "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Needs: bookings and pipeline data for the new lines, the current territory and coverage model, and the comp timing for new products. What she brings, in the quotes' terms: "I'm skilled in SQL and Tableau, and I built a partner-level revenue model that was used in carrier negotiations." She lets him decide what that's worth to his team. Then a give: offer an analysis his team would want, framed as a proposal | A reciprocity probe. A peer is measuring whether the hire adds to his load or lightens it. JD for collaboration, CO for knowing what a sales-strategy team runs on |
| B4 | "New products need reps to carry them. How would you get new SKUs onto plans without wrecking my core number?" | CASE, JD | [grounded] "No classic sales-ops or quota-setting experience." | Name the limit first: "I haven't done classic sales-ops or quota-setting work, so I'd lean on your team for the mechanics. Here's how I'd frame the GTM side." Structure: overlay vs. core credit, a pilot segment before a broad rollout, cannibalization measured against a holdout, and capacity checked against the core number. Then ask what his team would need to see before agreeing | This is F7 handed back to her in Dan's own lane, as a live problem. CASE first because it is a design problem; JD because it scores the GTM-ownership requirement |
| B5 | "How do you handle credit when work spans teams? Take the store-surface change." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | "We" for the context, "I" only for what the quote says: she proposed it. Same wording as A1: "I proposed the store-surface change, and it was credited with roughly $400M in ARR uplift." Answer slot: if part of building or shipping it was hers, she says which. If not, she says plainly that others built and shipped it, and names them as a team without inventing roles | Peers probe how credit gets shared, and F2's figure is the obvious target. Her wording must match A1 and E2 |

### C. Case / Strategist (mid-high weight, tilted toward pricing)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a good-enough version of one of our new products into its suite. What's your GTM response?" | CO, CASE | [grounded] | Clarify first: which product, which segment, and how many renewals are exposed. Objective: protect expansion without giving up the profitability goal. Segment: where the bundle really is good enough and where it isn't. Levers: packaging (attach to the core platform, a premium tier), the value metric for pricing, a co-sell partner motion, and switching costs. Metrics: win rate against the bundle, net retention by segment. Risk: a price war that hurts margin. Challenge one premise: is the bundle actually a substitute for enterprise buyers? | The coach's research note names bundling by a larger vendor as the main threat, and pricing is Dan's home ground. CO for the strategy, CASE for the delivery |
| C2 | "Compass is launching. Add-on, bundled into tiers, or usage-priced: how do you decide, and what data would you pull first?" | CO, CASE | [grounded] | State a hypothesis early, then the test. Data: usage telemetry from the pilot, attach rate by segment, willingness-to-pay signals, and the cost to serve set against gross margin. Decision rule: what moves enterprise expansion while protecting the profitability goal. Name the risk on each option: an add-on can slow adoption, bundling can give away value, and usage pricing makes revenue hard to predict | The research note lists the Compass launch and profitability as stated priorities, and packaging is a monetization question. CO for homework, CASE for structure |
| C3 | "Two new product lines, one planning cycle. Where's the whitespace across land, adopt, expand and renew, and which motion do you bet on first?" | JD, CASE | [grounded] | Framework: the installed base set against product fit, sized cell by cell with SQL. Each cell gets an account count, a propensity estimate and a revenue range. Pick the first bet using the enterprise-expansion priority from the research note, and say what would make her switch. She says aloud what she would want to check in Dan's data before committing | This is the whitespace requirement (F2) and the GTM-ownership requirement (F1) as one live problem. JD first because these are the JD's own lines |
| C4 | "Design the partner motion for one of the new lines. Which partners, what's in it for them, and how do we avoid channel conflict with my reps?" | JD, CASE | [grounded] | Structure: partner type (technology, SI, reseller) matched to the job each one does; partner economics (margin, referral fee, co-sell credit); rules of engagement with direct reps (deal registration, credit splits); and metrics for partner-sourced vs. partner-influenced pipeline. Ask about the current channel-conflict rules first. The question asks nothing about her past | Partner-motion design is the one requirement marked required (F4), and it collides directly with Dan's reps. JD content, CASE delivery |

### D. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **Highest-ROI prep in this pack.** "You haven't done sales ops or set quota, and your background is consumer tech. Why should I trust GTM plans from you for products my reps have to sell?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "9 at a large consumer-tech company in product strategy & ops" "set annual volume targets with cross-org consensus" "built a partner-level revenue model used in carrier negotiations" | **Name the limit before he finishes:** "That's fair. I haven't done classic sales-ops or quota-setting work." **Then what she did, at the quotes' scope:** "I spent nine years at a large consumer-tech company in product strategy and ops. I set annual volume targets with cross-org consensus, and I built a partner-level revenue model that was used in carrier negotiations." She doesn't call any of this quota-equivalent; he can draw his own conclusion. **Then the plan:** learn the territory and comp model early, with his team, and bring analysis to it. **Follow-up 1, "Volume targets aren't quota":** "Right, they're not the same thing." She concedes exactly that and holds on what the targets were. **Follow-up 2, "And B2B?":** the material doesn't show B2B. Answer slot: if any of her work dealt with business customers' lifecycle, she says which. If not, she says so plainly and stays with the partner-level model. **Follow-up 3, "So you'd be learning on the job":** "On quota mechanics, yes. Here's my first 90 days." She never folds on the analysis and partner-model work | F7 is in Dan's own lane and F1 is the background mismatch, so this objection will come up in some form. JD because it scores the stated GTM-ownership requirement against the role's gaps. Deepest rehearsal: three follow-ups, exact concession wording, and the limit stated first |
| D2 | "Why leave a large consumer-tech company for a 3,000-person B2B data-infrastructure company, and why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot: she gives her actual reasons for leaving in her own words. The pack supplies none. "Why here" can draw on the company: two new product lines, the Compass launch and enterprise expansion, all from the research note. She keeps it to 60 seconds | A Skeptic's motivation check, sharpened by F1's change of setting. EXP because the reason for leaving is about her own history |
| D3 | "Emerging products here won't come with a dashboard or an analyst. How do you work when nobody's built the data yet?" | JD, EXP | [grounded] "skilled in SQL/Tableau" | At the quote's scope: "I'm skilled in SQL and Tableau, so I can build the first cut myself." Selection scaffold: a time she built analysis from messy or missing data, with a named decision at the end. If no such time comes to mind, she says so plainly and walks through how she would do it here | Dan's startup chapter makes scrappiness probes likely, and the JD says *independent* analysis (F3). JD for the requirement, EXP for the story |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate who already knows our sales motion?" | JD | [grounded] "2 years strategy consulting at a top firm" "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | Pause first. Concede the true part: "An internal candidate knows your sales motion better than I do on day one." Hold on what the quotes carry: "I spent two years in strategy consulting at a top firm, built a partner-level revenue model that was used in carrier negotiations, and I'm skilled in SQL and Tableau." She holds through two follow-ups by returning to those facts and never adds to them | A time-boxed stem testing composure on the F1 mismatch. JD because it scores fit for the listed job |
| E2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change. It was credited with roughly $400M in ARR uplift." Follow-up, "Credited by whom?": an answer slot. If she knows, she says. If not, she says so plainly. Follow-up, "So someone else built it?": an answer slot. She says which parts, if any, were hers, and concedes the rest specifically. She never folds on "I proposed it" | The Pressure persona's attribution stem, aimed at F2's figure. Her wording must be the same as in A1 and B5 |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the quotes' beats: two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy and ops. Answer slot: why this role now, in her own words. She ends on the role, not the past | The near-certain opener, scored on economy. EXP because it is her history in her own framing |
| G2 | "What are you actually doing with AI these days?" | JD | [grounded] "uses AI tools daily" | At the quote's scope: "I use AI tools daily." Answer slot: she names which tools and what for, in her own words. She makes no claim to AI product work. A natural turn: what she'd want to learn about how Compass users work | A casual-sounding question on the JD's AI plus (F6). It is still scored |

### H. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a time with a named stake, a moment she didn't back down, and a working relationship still intact afterwards. "We" for context, "I" for her contribution. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it | A persona stem. Northwind's values weren't researched, so the question is `[generic]`. Low weight, but she shouldn't meet this style for the first time live |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric that paid for it, and what happened next. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it | A persona stem, kept generic for the same reason as H1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | C3, D1, E1, B4 |
| identify whitespace across land/adopt/expand/renew | C3, A3 |
| run independent analysis in SQL and Tableau | A3, A4, D3 |
| partner-motion design experience required | C4, A2 |
| strong cross-functional influence | B1, B2, A5 |
| AI experience a plus | G2, C2 |
| Research-note priorities: enterprise expansion, Compass, profitability, bundling threat | C1, C2, C3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization, with a startup stretch along the way. What from pricing do you use most in sales planning?" | Ties to his own path and turns the hour into a peer conversation |
| R2 | "What could someone in this seat do in the first month that would genuinely help your team?" | A reciprocity question. It shows she means to lighten his load, not add to it |
| R3 | "For the emerging products, where does Sales Strategy's ownership stop today: targets, coverage, comp? And where would you want this role to pick up?" | Gets the real seam from the person who owns the other side of it |
| R4 | "When the platform bundle hits, where does it show up first in your data: new logos, expansion, or renewals?" | Draws on the research note and asks for his numbers, his native language |
| R5 | "Is there a live debate about how Compass gets packaged and priced, and where does Sales Strategy sit in it?" | His pricing background plus a stated priority. It also tells her how much GTM authority the role really has |
| R6 | "With profitability a stated priority, how is the VP weighing investment in emerging products against the core number?" | Shows what the mandate really is, which she needs to know before accepting |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned B2B or GTM strategy | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops at a consumer-tech company |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: a model she built that was used in carrier negotiations. A2's slot stays inside the model |
| Negotiated the carrier deals | Inflated form of F4 | F4's quote: the model was *used in* negotiations. Whether she was in the room is only ever answered through A2's slot |
| Drove or delivered $400M of ARR | Inflated form of F2 | F2's quote: she *proposed* the change, which was *credited with* a ~$400M uplift. Same wording in A1, B5 and E2 |
| Set quotas or ran sales ops | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." No slot |
| Volume targets equal quota | Inflated form of F5 | F5's quote at its own scope: annual volume targets set with cross-org consensus. D1's concession, "they're not the same thing", is kept |
| Built or launched AI products | Inflated form of F6 | F6's quote: "I use AI tools daily." G2's slot names tools and uses only |

---

## Sources

**Provided documents:** the coach's message, covering the role, the JD highlights, Priya's background summary, Dan's profile summary and the research note on Northwind's priorities and competitive threat. No dossier was present.

**Searches sent:**
- `"Northwind Data" company values`: refused
- `"Northwind Data" interview process strategy`: refused
- `"Northwind Data" Compass AI copilot` (a check that the pasted research note is current): refused
- `"Dan Kovac" "Northwind" sales strategy`: refused

**Fetches:** none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. Published values would have themed the H bank and named values she could be asked about. H1 and H2 stay `[generic]` |
| 2. `Northwind Data interview process` | unavailable | The call was refused. The coach's words already set this session, so persona weights don't change. It would have shown whether a values or case round comes elsewhere in the loop |
| 3. `Northwind Data strategy` / recent news | unavailable | The call was refused; it would have checked that the pasted research note is current. C1, C2, C3, R4, R5 and R6 rest on the note as provided |
| 4. `Dan Kovac Northwind` | unavailable | The call was refused. It would have checked the interviewer read against his public profile, which now rests on the coach's summary |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied already set the fit-snapshot rows and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** the requirement column quotes the JD itself instead of the coach's highlights, and any mid-list requirements (named tools, methods, metrics) get their own rows and JD questions
- **Priya's actual CV:** evidence cells quote her own lines instead of the coach's summary, which may close the F1 and F2 gaps or reshape D1
- **Web search allowed for this session:** L1 targets 1 to 4 run: the H bank themed on published values, the loop checked, the research note checked for currency, and the interviewer read checked against Dan's public profile
- **Deeper research (L2):** up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief, Dan's talks or posts, loop reports and recent org context, which sharpens C1 to C4 and the reverse questions
- **Recruiter guidance (usually one email):** any stated focus areas, or a pre-declared deliverable such as a POV or case, which would get its own build section
- **Priya's answers to the answer slots:** how the ~$400M was counted and who credited it (A1, B5, E2), whether she took part in the carrier negotiations (A2), and which AI tools she uses and for what (G2). Each answer turns its slot into story-mapped guidance
- **An inspectable artifact for F2 or F4,** such as a performance review or internal recognition that names the store-surface change, or a redacted version of the revenue model. It could raise those rows from medium or low confidence
- **Prep time available:** adds a prioritized triage schedule
- **A `tuesday-dossier.md` from an underwriting pass:** an evidence-derived highest-ROI objection and a confirmed prohibited-claims list. It is never a prerequisite
