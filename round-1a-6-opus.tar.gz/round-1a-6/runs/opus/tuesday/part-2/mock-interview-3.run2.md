No dossier. Reading the files the playbook needs.
I've built your prep pack, but it's generic for now: I didn't have a job description, your resume, or web access. The four searches I tried for Stripe's values, its interview process, its recent news and a sample job posting were all blocked, so nothing in the pack comes from a Stripe source.

It's saved as `/var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-3-denied-5db658b6/stripe_product-operations-manager_interview_pack.md`. It has 22 practice questions, each with advice on how to answer, plus questions to ask your interviewers.

- **The interview format is a guess.** "Final round" didn't say how many sessions there are or who runs them. I assumed the usual pattern at large tech companies: live problem-solving and behavioral questions weigh most.
- **The job requirements are typical ones, not Stripe's.** They're the usual requirements for product operations roles, such as running launches, routing customer feedback, metrics, process design and working across teams. It's a worksheet: you fill in your own example for each before the interview.
- **Questions about your past only help you choose a story.** They tell you what a strong example needs and never invent one. If you have no example, the advice is to say so plainly.
- **The question to rehearse most is C1: "Which part of this role would you be weakest at on day one?"** It comes up in most final rounds, and it's the easiest one to answer by overstating.
- **Do your own Stripe research for C2 and H2.** These are "why Stripe, why now" and "which Stripe product would you change". The pack has no sourced facts about Stripe's products or strategy, so the substance has to come from you.

If you want, I'll play the skeptical interviewer on C1 now, follow up on what you actually say, and then give you feedback.
I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, I can convert it.

Who will you meet in the final round, and how many sessions are there? Has your recruiter sent focus areas or a set task, such as a case, a presentation or a writing exercise? That changes which question types get the most weight and may add a section for the task.

Can you paste the Stripe job description and your resume or a short background summary? That turns the worksheet into a real comparison of your experience against the role, with answers built on what you've actually done. If you'd rather not, the pack works as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewers: not known. Round: final round, number and order of sessions not known.

Built on: your message only. No job description, no CV, and no web research. All four research searches were refused in this session, so nothing here about Stripe's values, interview process or strategy comes from a source. Every row is labelled to show that.

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking, and in what style.
- **Types** describe *what* is being scored:
  - **VAL**: behavioral and values alignment. Does your past behavior show the company's values?
  - **EXP**: work-experience deep-dive. Does your story hold up, and what was actually you?
  - **JD**: the role itself. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. Have you done the homework, and can you think at the company's level?
  - **CASE**: a live problem from the role, solved out loud.
- **Provenance labels:** `[grounded]` = traceable to something you gave me or to cited research. `[inferred]` = derived, with the derivation named. `[generic]` = a pattern for the role family that makes no claim about Stripe or about you. In this version almost every row is `[generic]`, because the pack has no JD, CV or research yet. The upgrade menu says what turns each one `[grounded]`.
- **Question IDs** go by persona: A, B, C, D, E, G, H. F is skipped so the questions never collide with fit-snapshot rows F1–F8.
- **The guidance is scaffolding, not a script.** Where the pack has none of your own sentences to work from, the guidance tells you how to *choose* a story. It never tells you what the story is.

## Fit snapshot (self-assessment worksheet)

I don't have a JD or a CV, so this is the worksheet version. The requirements below are typical of product operations roles in general. They are not taken from Stripe's posting. Fill in the evidence column yourself before the interview. A row you can't fill is where your prep time should go.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launch or release-readiness processes across product, engineering and go-to-market teams (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: a named launch or release process, your exact part in it, how many teams it touched, and what changed because of it. Selection scaffold: pick a launch where the coordination was yours to run. It needs a named deadline, at least two teams that had to line up, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Collect, synthesize and route customer and user feedback to product teams (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: where the feedback came from, how you sorted it, who received it, and one product decision it reached. Selection scaffold: pick a time feedback you handled changed what a team built or fixed. It needs a source, a decision and a result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define and track operational metrics, and work with data (spreadsheets, SQL or dashboards) (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: a metric you defined or tracked, how it was counted, and the decision it informed. Know the weakest assumption behind it. Selection scaffold: pick a number you can explain end to end. If you can't say how it was counted, choose a different one. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Design, improve and scale cross-functional processes and tooling (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: a process before and after, what you changed, and what got faster, cheaper or more reliable. Selection scaffold: pick a process you changed rather than just followed. It needs a clear before, your change, and an after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence stakeholders without direct authority (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: a named disagreement, whose position moved, why it moved, and the relationship afterwards. Selection scaffold: pick a time you changed a decision you didn't own. It needs a stake, a counterparty and an outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Clear written communication: briefs, process documents, launch notes (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: a document you wrote that others used to make a decision or do work. Selection scaffold: pick one document and be ready to say who read it and what they did next. If no such document comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Handle escalations and incidents between support, product and engineering (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: an escalation, your role in it, how it was resolved, and what changed afterwards so it didn't recur. Selection scaffold: pick an escalation where the follow-up was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F8 | Fluency in the company's own products and customers (typical of the role family) | none given | none | [generic] | discovery | What strong evidence looks like: hands-on use of the company's products, or of comparable ones, and a specific view on one of them. This row is homework, not history. Do the reading yourself, because this pack has no sourced facts about Stripe's products or strategy |

## Persona table

**Loop basis.** "Final round" doesn't tell me how many sessions there are or who runs them, and no source I could read did either. The weights below therefore rest on a pattern, not on Stripe's documented process. My fallback is the *big-tech structured* archetype (recruiter, then hiring manager, then skills or case, then behavioral or values, then a decision). Picking that archetype is my judgement, `[inferred]` from Stripe being a large technology company. It tilts Values/Behavioral and Case upward. The weights are blended across sessions because I don't know which session is which.

| Persona | How it shows up in a product ops final round | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems: plan a launch, diagnose a spike, design a feedback loop | High. Final rounds for operations roles usually test live problem-solving, and the archetype tilts Case up | Clarify, then state the objective, segment, set out the approach, name the metrics, then the risks. Think aloud. Respectfully challenge one premise per case |
| Values / Behavioral | "Tell me about a time…" questions, often from someone outside the function | High. The fallback archetype has a values-style round somewhere in the loop | Before the day, pick one real story per theme. Say "we" for context and "I" for your own contribution. Where you have no story, say so rather than inventing one |
| Skeptic | Quiet probing of why this role, why now, and where you are weakest | Medium. A final round is where remaining doubts get tested | Rehearse your weakest-area answer until it is boring. Use only adjacent experience you actually have, plus a concrete plan for ramping up |
| Data-Driven Prober | Asks how a number was counted, what the denominator was, which assumption is weakest | Medium. Product ops roles are metric-heavy (F3) | For every metric you mention, know how it was counted and which assumption you'd defend least. Say plainly when you don't know |
| Peer Evaluator | A PM, engineer or ops peer asking where the seam between teams is, and what you'd need from them | Medium. Product ops sits between teams by design | Lead with what you'd bring their team, not just what you need. Propose principles for the seam rather than pretending to know where it is |
| Pressure | Time-boxed or devil's-advocate pushback | Low. There is no signal for it, but it should not be met for the first time live | Pause and restate the question. Hold your position through two follow-ups, then concede the specific uncertainty without folding on the core |
| Conversational | A friendly opener and "walk me through your background" | Low as a persona, but almost certain as an opener | A pre-scripted 90-second arc. Treat casual questions as scored |

## Question banks

All banks below are `[generic]`. They are rehearsal patterns for this role family, and they make no claim about Stripe's process or about your history.

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for launching a new feature to existing users in several countries. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what has to be true on launch day, and the fixed date or constraint. Objective: a launch with no surprises for users, support or sales. Segment by country, user type and the teams involved. Approach: a readiness checklist with owners, a go/no-go review, staged rollout, and a support briefing. Metrics: adoption, ticket volume, incident count. Risks: localization, regulatory review, support readiness. Name one trade-off out loud, such as speed against staged rollout | Covers F1, the role family's core work. Final-round cases tend to come from the role's real job. CASE because it is a live plan with no claim about your past |
| A2 | "Support tickets about one product doubled week over week after a release. Diagnose it." | CASE | [generic] | Clarify: are these the same customers, the same ticket type, the same channel? Check for a measurement change before looking for a real one. Segment by issue category, customer segment, region and release version. Form a hypothesis, such as a changed flow or unclear messaging, and say how you'd test it. Act: a short-term fix with support, a root cause with product, and a follow-up so it doesn't recur. Say what you'd tell leadership on day one | Covers F2 and F7, and fits the Prober's diagnose stem. CASE because it scores structure under ambiguity |
| A3 | "Product teams say they never see customer feedback. Support says they send it constantly. Design the feedback loop." | CASE | [generic] | Name the real problem first: feedback that arrives without being usable. Design intake (one channel, consistent tags), synthesis (a regular themed digest with counts and examples), routing (an owner per product area), and closing the loop (telling support what happened). Metrics: share of themes with a product response, and time to response. Risk: a digest nobody reads. Mitigate by tying it to an existing planning meeting | Covers F2 and F6. A common product ops design problem. CASE delivery |
| A4 | "Three teams each want their launch prioritized for the same review slot. How do you decide?" | CASE | [generic] | Clarify the criteria before choosing: customer impact, hard deadlines, risk and dependencies. Make the criteria explicit and get agreement on them before applying them, so the decision isn't personal. Decide, explain the decision, and give the teams who lost out a concrete next slot. Escalate only if the criteria themselves are contested | Covers F5. Tests prioritization without authority. CASE because it is a live decision |
| A5 | "A manual process ops runs every week is breaking as volume grows. Do you fix the process, build tooling, or ask engineering?" | CASE | [generic] | Clarify volume growth, error cost and how often the process changes. Fix the process first if it is broken by design. Build lightweight tooling if the process is stable but slow. Bring in engineering when the problem sits in the product, or when scale and risk justify it. Lay out cost against benefit for each option. Metrics: time per cycle, error rate. Close with what you'd do this week | Covers F4. A scaling problem is central to operations roles. CASE |

### B. Values / Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear, with a named stake, what you said and how, and what happened after, including if it didn't land. Say "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values-style rounds probe candor. The theme comes from the Values persona's stem. VAL because it scores past behavior against values |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where a metric and a customer pulled in different directions and you chose the customer, with the metric named, what you gave up, and what you'd do the same or differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the Values persona's stem. Customer judgement is central to product ops (F2). VAL |
| B3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick one piece of cross-team work and say exactly which part was yours and which was others'. Be precise about your own contribution and generous about everyone else's. If no example comes to mind, say so plainly and describe how you would handle it | The theme comes from the Peer persona's stem. Product ops work is shared by nature (F5). VAL because it scores attribution honesty |
| B4 | "You discover after a launch that a check in the process you own was skipped. Nothing has broken yet. What do you do?" | CASE | [generic] | Say it early and plainly to the people affected. Assess the risk now. Fix the gap in the process, not just this one instance. Share what changed. Hold the line on surfacing it even though nothing has broken: that is the point of the answer | A values-flavored live scenario that tests ownership without asking about your past. CASE delivery, VAL content |

### C. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **The highest-ROI rehearsal in this pack.** Selection scaffold: pick the fit-snapshot row where your evidence column is thinnest once you have filled it in. Name it plainly, in your own words. Give the nearest real experience you have, kept to its actual size. Then give a concrete 30-day plan to close it. Hold through two follow-ups by returning to the plan, never by enlarging the experience. Avoid fake weaknesses ("I care too much"). If every row felt strong, pick the one you'd most want to be probed on and say why | The Skeptic's stem, aimed at whatever is thinnest. It is asked in some form in most final rounds. JD because it scores you against the role. It is deepest here because it is the question most tempting to answer with inflation |
| C2 | "Why Stripe, and why now?" | CO | [generic] | Three beats, about 60 seconds: what draws you to this company's product or customers (do your own research, because this pack has no sourced facts about Stripe), why product ops specifically, and why this moment in your career. Make it specific enough that it couldn't be said about a competitor | The Skeptic's "why here, why now" probe. CO because it scores homework |
| C3 | "Why product operations rather than product management?" | JD | [generic] | Answer about the work you want to do: running systems across teams, improving how products get to customers. Don't frame product ops as a stepping stone or a consolation prize. If you are open to PM later, say so honestly, but anchor on this role | Motivation consistency is the Skeptic's core probe, and product ops candidates often get this one. JD |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which metrics would you put on a dashboard for a launch process, and which one would you defend least?" | CASE | [generic] | Three to five metrics across speed (cycle time from ready to launched), quality (incidents or rollbacks after launch), and customer impact (tickets and adoption). Then the weakest-assumption move: name the one you trust least and why, for example that ticket volume mixes real issues with confusion | Covers F3. Probers reward naming the weakness before they find it. CASE |
| D2 | "Launch-review time went from three days to eight over a quarter. Diagnose it." | CASE | [generic] | Check for a measurement change first. Then: volume up? Bigger or riskier launches? A new review step? Reviewers stretched thin? Segment by team and launch type. Find where the time is spent, whether in the queue or in the review itself, then propose a fix and a metric to watch | Covers F3 and F4. A typical Prober denominator probe. CASE |
| D3 | "How would you measure whether a support-to-product feedback loop is working?" | CASE | [generic] | Separate activity from outcome. Activity: feedback items captured and routed. Outcome: share of top themes that get a product decision, time to decision, and repeat-ticket rate on fixed issues. Name the weakest measure, such as attributing a drop in tickets to a fix | Covers F2 and F3, and pairs with A3. CASE |

### E. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Don't pretend to know their seam. Propose principles: clear ownership per decision, disagreement raised early and in writing, a named tie-breaker. Ask them where it hurts today | The Peer persona's stem. Product ops sits on seams by design (F5). JD |
| E2 | "What would you need from a product manager in your first month, and what would you bring their team?" | JD | [generic] | Lead with what you'd bring, such as fewer launch surprises and clearer feedback. Then what you need: access to the roadmap, a regular slot, and one decision-maker per area. Keep it reciprocal | Peers price what a hire costs and contributes. JD |
| E3 | "An engineering lead says your new launch process adds a week for nothing. How do you respond?" | CASE | [generic] | Take it seriously and ask which step costs the time. Separate the steps that prevent real incidents from ceremony. Offer to cut or automate the ceremony and keep the risk checks. Agree on a metric to settle it later | Pushback from peers is routine in this role (F4, F5). CASE |

### G. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate. Concede what an internal candidate has, which is context. Then give what you bring, in your own words and only what your experience carries. Stop at 60 seconds | The Pressure persona's stem. JD because it scores fit to the role |
| G2 | "Your plan in A1 is too heavy for a small launch. Defend it or cut it." | CASE | [generic] | Hold-then-concede: defend the core (owners and a go/no-go check) through two follow-ups, then concede the specific part that scales down (fewer reviewers, a lighter checklist for low-risk launches). Never drop the whole plan just to end the tension | Tests composure on your own case answer. CASE |

### H. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | Selection scaffold: a 90-second arc of three or four chapters, each with one line on what you did and one on what you learned, ending on why this role is the next step. Use only real roles and real work. Rehearse it out loud with a timer | The Conversational stem. It is the near-certain opener. EXP because it is scored on your actual history |
| H2 | "Which Stripe product have you used or looked at closely, and what would you change about it?" | CO | [generic] | Pick one product you have actually used or explored before the interview. Name one specific friction point and one concrete change, and say how you'd measure it. Don't invent usage you haven't had: "I explored it this week to prepare" is fine and honest | Casual-register product questions are still scored, and F8 is homework. CO |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Launch and release readiness | A1, G2 |
| F2 Customer feedback routing | A2, A3, B2, D3 |
| F3 Metrics and data | D1, D2, D3 |
| F4 Process and tooling | A5, D2, E3 |
| F5 Influence without authority | A4, B3, E1, E3 |
| F6 Written communication | A3. None asks for a writing sample directly, because whether the loop includes one is unknown. Ask your recruiter |
| F7 Escalations and incidents | A2, B4 |
| F8 Product and customer fluency | C2, H2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does product ops on this team own end to end today, and what does it hand off?" | Shows you're thinking about scope and seams, and tells you what the job really is |
| R2 | "Which process here most needs fixing, and why hasn't it been fixed yet?" | Invites a candid answer and shows you'd go after the hard problems |
| R3 | "Six months in, how would you know this hire was working?" | Makes the interviewer picture you succeeding, and gives you the real success metric |
| R4 | "Where do product ops and product managers disagree most often here?" | Shows awareness of the seam, and the answer predicts what your days will be like |
| R5 | "Which teams would I work with most, and what do they need most from this role?" | Signals that you think in terms of the people the role serves |
| R6 | "What's something a new person could do in their first month that would really help your team?" | The reciprocity question, for any peer interviewer. It turns the evaluation into a conversation between colleagues |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None yet | You haven't shared any of your own experience, so there are no sentences of yours that could be inflated, and no gaps you've stated | Nothing in this pack puts a claim about your past in your mouth. Every past-experience answer is a selection scaffold. Once you share a CV, this list gets built from it |

## Sources

- Provided: your message ("final-round interview at Stripe for a Product Operations Manager role").
- No dossier was present.
- Searches sent, all refused (web search permission not granted):
  - `Stripe operating principles`: refused
  - `Stripe interview process product operations`: refused
  - `Stripe strategy news 2026`: refused
  - `Stripe "Product Operations Manager" job description`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe` values / operating principles | unavailable | The values cheat sheet, with official principle names and one VAL question per principle. The search was refused, so the section is dropped |
| 2. `Stripe interview process product operations` | unavailable | The loop structure and persona weights. The search was refused, so weights rest on the big-tech structured archetype |
| 3. `Stripe` strategy / recent news | unavailable | CO and CASE questions grounded in current priorities. The search was refused, so C2 and H2 stay generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. The interviewer section is absent |
| 5. Representative `Product Operations Manager` JD | unavailable | The fit-snapshot requirements and JD questions, from a real posting. The search was refused, so all requirements are role-family patterns |

## Upgrade menu

- **The actual Stripe JD text**: F1–F8 become quoted, `[grounded]` requirements. Any requirements I guessed wrong get replaced, JD-specific questions get added, and coverage is checked against the real list.
- **Your CV or a short background note**: the worksheet becomes a real fit snapshot with your own sentences quoted. Scaffolds become story-mapped answers, every headline number on your CV gets a defend-the-number question, C1 gets aimed at your actual thinnest area, and the prohibited-claims list gets built.
- **The final-round schedule (sessions, interviewers, roles)**: if your final is several sessions, send the schedule and I'll build per-session mini-packs, each with its own persona weights and reverse questions.
- **Interviewer names**: an interviewer read from their public professional footprint, tailored persona weights, and a reverse question tied to their path.
- **The recruiter's prep email**: their stated focus areas, plus a build section for any announced deliverable, such as a case, a presentation or a writing exercise.
- **Allowing web search**: Stripe's published values with a cheat sheet, its documented interview loop, and strategy-grounded CO and CASE questions in place of the generic ones.
- **A deeper research pass**: up to 6 more searches and 2 more fetches, taking several more minutes, covering a strategy brief, interview reports for this role family, and recent org context. It needs web search allowed first.
- **A `tuesday-dossier.md`**: evidence you've already confirmed, a named likeliest objection, and a hard list of claims not to make, which would sharpen C1 and the prohibited list.
