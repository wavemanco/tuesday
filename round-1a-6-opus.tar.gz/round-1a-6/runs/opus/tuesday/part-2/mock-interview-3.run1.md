Getting ready to research Stripe: its operating principles, how its interviews run, recent strategy, and a representative Product Ops JD.
I've built your prep pack, but it's generic for now. The web searches for Stripe were blocked, and I don't have your job description or CV. So every question and answer outline is a typical pattern for this kind of role, not something specific to Stripe or to you.

The pack has 22 practice questions, each with an outline for your answer. It assumes a common big-tech final round with a case session and a values session, because I couldn't confirm how Stripe runs its final round. It also has a self-assessment table you can fill in against seven typical product ops requirements, plus six questions to ask your interviewers. The one to rehearse first is C1, "Which part of this role would you be weakest at on day one?"

It's saved as `/var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-3-denied-8cf2d965/stripe_product-operations-manager_interview_pack.md`.

Say the word and I'll play a skeptical interviewer on C1 as a live practice run.
I can also save a `tuesday-dossier.md` file noting the gaps this prep exposed, so you can use it in later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round, and how do they relate to the role: hiring manager, peers, skip-level or cross-functional? Has the recruiter mentioned focus areas or anything you need to prepare, like a case, presentation or written exercise? This changes how much weight each type of interviewer gets in the pack.
2. Can you paste the job description and your CV, or a few lines about your background? I'll keep working without them if you'd rather, but they turn the generic questions into ones built around your own experience.
3. Will you allow web search? Then I can look up Stripe's published operating principles, how its interviews actually run and its recent strategy, and rewrite the values and "why Stripe" questions around them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round prep pack

Final round. Interviewers and their relationship to you are not known yet. Built with no job description, no CV and no completed research, so every row is labeled `[generic]` and the upgrade menu says what each missing input turns into.

## How to use this pack

- **Personas** describe how a question is asked (who, in what register). **Types** describe what is being scored.
- Type key:
  - **VAL**: behavioral and values alignment, scored against the company's published values
  - **EXP**: work-experience deep-dive; whether your claims hold up and what was actually you
  - **JD**: the role's stated responsibilities, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, solved out loud
- Guidance is scaffolding, not a script. Since the pack has none of your own sentences yet, past-experience questions get a **selection scaffold**: what a good story needs, so you can pick one of your own. Each ends with an honest branch for when nothing fits.
- Labels: `[grounded]` traces to something you gave me or a cited source; `[inferred]` is derived from a representative source; `[generic]` is a role-family pattern with no claim about Stripe or about you.

## Fit snapshot

Worksheet version: you haven't shared a JD or a CV yet, so the requirements below are typical of product operations roles, written as plain prose, and the evidence column is yours to fill in. Paste the JD and your CV and these rows get rebuilt around your actual words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launch and release-readiness operations across product, engineering, support and go-to-market teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a launch you coordinated, which teams were involved, what you were responsible for, and how you knew it was ready. Selection scaffold: pick a launch or rollout where you owned part of the readiness work; it needs a named deliverable and a clear line between your part and other people's. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Build feedback loops that turn customer and field input into product priorities (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a feedback channel you set up or ran, what came through it, and one product decision it changed. Selection scaffold: pick a time feedback you gathered or summarized reached a product team; it needs the source, what you did with it, and what happened next, even if the answer is "nothing changed". If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define and track operational metrics, and analyze data to find problems (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a metric you defined or tracked, how it was counted, and a problem it surfaced. Selection scaffold: pick a number from your work you can explain end to end; it needs what was counted, where the data came from, and the assumption you trust least. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Design processes, tooling and documentation that scale with volume (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a process you designed or changed, the before and after, and who still uses it. Selection scaffold: pick a process you changed; it needs the problem, your specific change, and how you judged whether it worked. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence cross-functional stakeholders without formal authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a time you moved a team you didn't manage, what you asked for, and what they did. Selection scaffold: pick a disagreement with a peer team; it needs a named stake, what you did, and the state of the relationship afterward. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Triage operational issues and escalations that affect users (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: an issue you triaged, how you decided severity, and who you pulled in. Selection scaffold: pick an incident or escalation where you made a call; it needs what you knew at the time, what you decided, and what you would change. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Write clear operational documents and launch communications (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a document you wrote that other people relied on, and who used it. Selection scaffold: pick a document of yours that changed what someone did; it needs the audience and the result. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch and release readiness | A1, E3, B3 |
| F2 Feedback loops | A3, B2 |
| F3 Operational metrics and analysis | A2, A5, D1, D2, D3 |
| F4 Scalable process design | A4, D3 |
| F5 Cross-functional influence | E1, E2, E3, B1, B4 |
| F6 Issue triage and escalation | A2 |
| F7 Written communication | — none: written work usually shows up as an artifact or exercise, not an interview question. If the recruiter mentions a written exercise, it gets its own build section |

## Persona table

The loop structure below is a fallback pattern, not Stripe's documented process: the search for Stripe's interview process was refused (see Sources), and "final round" alone doesn't say how many sessions there are or who runs them. Weights use the **big-tech structured** archetype (recruiter, then hiring manager, then skills or case, then behavioral or values, then a hiring decision). That pattern pushes Values/Behavioral and Case up. Flat weights would be the alternative. If you know who you are meeting, tell me and these weights get reworked.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ops problems: plan a launch, diagnose a spike, design a process | High. Final rounds for operations roles typically include a problem-solving session, and the fallback archetype tilts toward case | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and respectfully challenge one premise per case |
| Values / Behavioral | "Tell me about a time…" questions, scored against published principles | High. The fallback archetype puts a values round somewhere in the loop. Stripe's own principles weren't retrieved, so these questions are generic | "We" for context, "I" for your own part. Choose stories where the hard truth actually landed. If you have none, say so rather than inventing an ending |
| Skeptic | Quiet probing: weakest area, why this move, why now | Medium. Present in almost every final round, and the most likely objection gets the deepest rehearsal here | Rehearse C1 until it's boring. Build bridges only from work you actually did, plus a concrete ramp-up plan |
| Data-Driven Prober | Asks how a number was counted and what the denominator is, then goes two levels deeper | Medium. Ops roles are scored on whether metrics hold up, and analytical interviewers often appear in finals | Know what you can and can't say about each figure you use. Name your weakest assumption before they do |
| Peer Evaluator | Probes the seam between teams: what you'd need, what happens in a disagreement | Medium. Product ops sits between product, engineering and go-to-market teams, so finals often include a cross-functional peer | Frame it as reciprocity: what you bring their team. Propose principles for the seam, not a pretended knowledge of it |
| Conversational | Friendly opener, "walk me through your journey" | Low. Opens most sessions, but it's still scored | A prepared 90-second arc. Treat casual questions as scored |
| Pressure | Time-boxed questions, "how much of that was you?" | Low. Possible in any final round, rarely the main register | Pause, restate, anchor in what you actually did. Hold your position through two follow-ups, then concede specifically |

## Question banks

### A — Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new product to existing users in three months. Walk me through how you'd run launch readiness." | CASE | [generic] | Clarify first: who the users are, what "launched" means, which teams are involved, and what the risk is if it goes wrong. Then structure: readiness criteria per team (support trained, docs written, sales briefed, monitoring in place), a timeline working back from the date, go/no-go checkpoints, and the metrics you'd watch in the first week. Name one risk you'd raise early. Makes no claim about your past | F1's core activity, asked as a live plan. CASE because it scores structure, not history |
| A2 | "Support tickets about one feature doubled in two weeks. Diagnose it." | CASE | [generic] | Clarify before hypothesizing: absolute numbers, which segment, did anything ship or change, is ticket tagging consistent? Split it: a real product problem, a change in user mix or volume, or a measurement artifact. Say what data you'd pull first and why, what you'd do today versus this week, and who you'd bring in. End with how you'd keep it from happening again | Covers F3 and F6 together. The persona's "metric dropped, diagnose it" stem applied to an ops signal |
| A3 | "Product, sales and support each send you a different list of top priorities. How do you turn that into something the product team will act on?" | CASE | [generic] | Normalize the inputs (what, who, how often, how much revenue or user impact), remove duplicates, then rank by impact against cost. Say how you'd close the loop with each team so they keep sending input. Name the trade-off you'd surface rather than resolve alone | F2's feedback-loop requirement as a live problem |
| A4 | "A manual process the ops team runs is slow and error-prone, and volume is growing. How would you redesign it?" | CASE | [generic] | Map the current process and measure it first (time, error rate, where errors start). Pick between fixing, automating and eliminating steps. Pilot, measure against the baseline, then roll out with documentation and an owner. Name what you wouldn't automate and why | F4's process-design requirement. Tests whether you measure before changing |
| A5 | "What would you put on a dashboard to tell whether a product's operations are healthy?" | CASE | [generic] | Group the metrics: user experience (contact rate, resolution time), reliability (incidents, time to detect), throughput (queue size, backlog age) and quality (error or rework rate). For each, say what action it would trigger. Volunteer one metric that's easy to game and how you'd guard against it | F3. Interviewers use this to separate a list of metrics from a decision system |

### B — Values / Behavioral (weight: high)

Stripe's published principles weren't retrieved, so these use generic themes. Once the principles are in hand, this bank gets rewritten around each one by name.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs the stake, how you framed it, what you backed it with, and what happened, including if it didn't land. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for values rounds. Covers F5, since influencing upward is part of the role |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where a customer's need and a team number pulled apart. It needs the metric, the customer impact, what you chose and the cost of choosing it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for values rounds. Connects to F2, since feedback loops exist so that the customer reaches priorities |
| B3 | "A launch date and a quality bar conflict. How do you decide?" | VAL | [generic] | Hypothetical, so no claim about your past is needed. Say what you'd want to know (severity, who is affected, whether it can be reversed), who owns the call, and how you'd make the trade-off visible rather than quietly absorbing it. Saying which way you lean, and why, scores better than "it depends" alone | F1 as a judgment question. VAL because it scores what you prioritize, delivered as a CASE |
| B4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick cross-team work where credit was shared. It needs what was yours, what wasn't, and how you talked about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer persona stem. F5. Tests attribution honesty, which is exactly what a values interviewer is listening for |

### C — Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Pick one real area from the fit snapshot rows F1 to F7 where your evidence is thinnest. Name it in one sentence, without padding it. Then give what is nearest to it in your own background, said at its true size, and a concrete 30-day plan for closing the gap. Hold through two follow-ups ("Why that one?" "Isn't that core to the job?") by going back to the plan, not by making the gap sound smaller. Concede specifically ("Yes, it is core, which is why it's first on my plan") and never claim the gap away | The Skeptic's most predictable question in any final round. Without your CV, the pack can't name your specific objection; once your CV is in, this row is rewritten around the gap the snapshot actually shows. JD because it scores self-assessment against the role |
| C2 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | Three short beats in your own words: what draws you to the work itself, what about this company specifically (from your own research, not general praise), and what in your timing makes it the right move now. Keep the "why now" forward-looking. If you're asked why you're leaving, say what you're moving toward | The Skeptic's motivation-consistency check. EXP because it tests whether your story holds together. The "why Stripe" part turns CO once research is in |
| C3 | "How would you handle the parts of this job you haven't done before?" | JD | [generic] | A method, not a confession: how you learn a new domain (who you'd talk to, what you'd read, what you'd shadow), how you'd show early progress, and when you'd ask for help. One real example of learning something fast, if you have one. If not, describe the plan | C1's follow-up in a different form. It makes no assumption about which parts are new |

### D — Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number from your work that you'd stand behind. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a figure you can explain end to end. Be ready with what was counted, the source of the data, the time window, and exactly which part was yours. If you don't know how it was counted, say so; that's an honest answer, and a better one than a guess. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3. A prober will ask this of whatever number you use anywhere in the loop, so pick it in advance |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they press: the assumption you trust least behind D1's figure, in your own words, and what would change if it were wrong. Turning the weak spot into a strength is the move | The weakest-assumption move. A prober's standard follow-up to D1 |
| D3 | "You change a process. How do you know it actually worked?" | CASE | [generic] | Baseline before the change, one primary metric and one guardrail metric, a comparison period long enough to rule out noise, and a check for anything else that changed at the same time. Say what result would make you roll it back | Covers F3 and F4. Tests whether you separate a change from a coincidence |

### E — Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles: clear owners for each decision, an agreed escalation path, disagreements raised early and in writing. Then ask what the seam looks like today | A peer persona stem. F5. Scores turf awareness |
| E2 | "What would you need from me, and what would I get from you?" | JD | [generic] | Lead with what you'd give: for example, fewer surprise escalations, clearer launch timelines, synthesized feedback instead of raw tickets. Then what you'd need: early visibility into the roadmap, and one point of contact. Keep it reciprocal | The peer persona's core probe. F5. Tests whether the hire adds to or reduces their load |
| E3 | "An engineering lead says your launch checklist slows them down. What do you do?" | CASE | [generic] | Ask which items cost the most and why. Separate what's genuinely needed for safety or support from habit. Offer to cut or automate the rest, and agree on a trial. Hold firm on the one or two items that protect users, and say why | F1 and F5. A collegial version of the "ops as bureaucracy" objection |

### G — Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A prepared 90-second arc: where you started, the one or two moves that matter for this role, and why this role is the next step. End on the role, not on the past. Each beat should be something you'll be happy to be asked about | Opens most sessions. Scored on how concise and clear you are |
| G2 | "What are you paying attention to in product operations these days?" | CO | [generic] | One real thing you've read, tried or changed your mind about, and what you'd do with it here. Specific beats broad | A persona stem in a casual register, still scored as a sign of genuine interest |

### H — Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats: an outside view the team doesn't have yet, a specific thing you'd do in the first 90 days, and the honest cost (ramp-up time) along with how you'd shorten it. Stop at sixty seconds | A pressure persona stem. Scores composure under a time box |
| H2 | "That result you just mentioned — how much of it was actually you?" | EXP | [generic] | For whatever result you just described: say exactly which part was yours and who did the rest, in one breath, without shrinking or inflating your part. If it was mostly the team, say so and name your piece. Hold that answer through a second push | A pressure persona stem. Rehearses attribution honesty, which is the whole test |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does product operations own here that no other team does, and where is that still unsettled?" | Shows you're thinking about the seam before day one, and the answer tells you where the job really is |
| "What would a great first 90 days look like in this role?" | Gets the real success criteria, which you can echo in the rest of the loop |
| "Which team will I work with most closely, and what do they most need from product ops right now?" | A reciprocity question: it signals that you're thinking about their load, not just yours |
| "What's an operational problem the team has tried to fix and hasn't yet?" | Invites a real conversation about the work and lets you show how you think on the spot |
| "How is success measured for this role, and who decides?" | Shows comfort with accountability and surfaces who the real stakeholders are |
| "What's the next step after today, and when should I expect to hear back?" | A clean close that sets expectations without pushing |

## Prohibited claims

Nothing is listed yet. The pack has none of your own sentences, so there is nothing it could stretch, and you haven't stated any gaps. Once your CV and any gaps you mention are in, this section will list the inflated versions of your lines that the pack won't coach, each with its honest form. The standing rule applies meanwhile: no answer in this pack claims anything about your past that you haven't said yourself.

## Sources

- Provided documents: none. The pack is built from your message alone: company (Stripe), role (Product Operations Manager) and round (final).
- Searches sent:
  - "Stripe operating principles" — refused
  - "Stripe interview process product operations onsite rounds" — refused
  - "Stripe strategy news 2026" — refused
  - "Stripe "Product Operations Manager" job description" — refused
- Fetches: none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | The search was refused. Would have produced the values cheat sheet and rewritten bank B around Stripe's principles by name |
| 2. Stripe interview process, product operations | unavailable | The search was refused. Would have replaced the big-tech fallback archetype with Stripe's documented rounds and reworked the persona weights |
| 3. Stripe strategy and recent news | unavailable | The search was refused. Would have added CO questions grounded in current strategy and a sharper "why Stripe" for C2 |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | The search was refused. Would have quoted real requirements in the fit snapshot as `[inferred]` rows instead of `[generic]` ones |

## Upgrade menu

- The job description text → F1 to F7 rebuilt from its own words as `[grounded]` rows, and a JD question for every requirement it lists
- Your CV or a short background summary → the worksheet turns into a real fit snapshot; selection scaffolds become story maps built on your own lines; C1 gets rewritten around your actual likeliest objection; the prohibited-claims list gets filled
- Who you're meeting and their relationship to you (hiring manager, peer, skip-level, cross-functional) → persona weights based on your actual loop instead of a fallback pattern
- If your final round is several sessions, the schedule → one mini-pack per session, each with its own weights, questions and reverse questions
- The recruiter's prep notes, including any announced case, presentation or written exercise → a build section for each graded deliverable and coverage of the focus areas they named
- Interviewer names → a read on each interviewer from their public professional profile, plus a reverse question tied to their own career path
- Allowing web search → Stripe's published principles by name, its documented interview process and current strategy, which upgrade banks B and C and add CO questions. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and role-specific loop reports
- How much prep time you have → a prioritized plan sized to it
- A tuesday-dossier.md, if you have one → verified evidence, the objection worth rehearsing most, and claims to keep out of your answers
