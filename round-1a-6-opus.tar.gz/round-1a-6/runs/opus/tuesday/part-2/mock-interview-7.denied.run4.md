Quick update: I've read the prep playbook. Now I'm running a few targeted searches on Saltmarsh Games and Tobias Wrenfield, then I'll build your prep pack.
I've saved your prep pack as `saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 practice questions with answer guidance built from your own sentences.

I built it for a hiring-manager round, because Tobias heads the department this role sits in, but you didn't say how the role reports to him. Web search was blocked, so the pack doesn't cover Saltmarsh's values, its two games, its interview process or Tobias's background. Those parts are written for this kind of role in general, and the pack says so where it applies.

**Spend most of your prep time on B1.** This is the question that comes from your associate title: "Were you the one coordinating design, art and engineering, or supporting whoever did?" Before he asks, say "associate producer" yourself, then lead with the calendar you ran. Where the pack doesn't know your story, it gives you two honest branches. Answer whichever is true. If the follow-up is "so you haven't led a team?", the answer is "I haven't led a team." Then stop and don't add anything to soften it.

**The other gap is in-app purchases (B2).** Say it plainly: "I haven't worked on a game with in-app purchases." Then mention the retention numbers you presented, and give a learning plan as a plan. Don't guess whether their games sell in-app purchases. Ask Tobias (reverse question R2).

**Your strongest points:** you ran the content calendar, which is close to word-for-word what the JD asks for. You also wrote the release checklist your QA team still uses. Open with both.

**Before Friday:** play both of their games if you can (D2), and rehearse your 90-second career summary using only your four facts (D1).

Say the word and I'll play the Skeptic on B1 in a live practice run.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Will Tobias be your manager, or does he sit above the person you'd report to? And did the recruiter mention any set task or focus areas for the hour? Either answer changes which questions get the most weight.
2. If you allow web search, I'll run the four searches that were blocked, so the pack can cover their games, values and Tobias's public profile. I can also do a deeper pass after that: up to 6 more searches and 2 more page fetches, taking several more minutes. Would you like either?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interview:** Friday, 60 minutes, one session with Tobias Wrenfield, Head of Live Operations. The pack assumes he is the hiring manager for this role. You gave his title but not how the role reports to him.
**Candidate:** Femi

---

## How to use this pack

Two ideas organise the pack. **Personas** describe *how* a question gets asked: the style, the pressure, the follow-ups. **Types** describe *what* the question scores:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether your stated experience holds up when probed, and what was actually yours |
| JD | Whether you can do the job as the JD lists it, gaps included |
| CO | Whether you have done your homework on the company and its games |
| CASE | How you structure and reason through a live problem from the role |

Each question row has a **Provenance** column. `[grounded]` means the row rests on your own sentences, which are quoted in the cell. `[inferred]` means the pack derived it. `[generic]` means it is a standard pattern for this kind of role and says nothing specific about Saltmarsh.

An **answer slot** is the pack declining to make up your story. It names the probe you can expect and gives you two honest branches. Answer whichever branch is true. The guidance is scaffolding, not a script: say it in your own words.

Question IDs go by persona: A, B, C, D, E, G, H. F is skipped so that question IDs don't get confused with fit-snapshot rows F1 to F8.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for one title, not a live-events calendar for two, and your words should stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: because the JD says "plan", expect a probe on who decided what went into each drop and when. If those calls were yours, say how you made them, in your own words. If someone else set them, or they weren't decided that way, say so plainly and stay with running the calendar. Your material doesn't name your title's platform, so state it plainly whatever it is. Running two titles at once is something you describe as a plan, never as your past |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | Coordinating teams on an update and leading a team are different things. Your material says nothing about the first. For the second, if asked, the words are: "I haven't led a team." Answer slot: the JD names four teams, so expect a probe on each one. For any team whose work you got onto the drop calendar, name the team and say how you did it, in your own words. If that was someone else's job, or the work wasn't organised that way, say so plainly and return to the calendar you ran. B1 rehearses this |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." and "Never led a team, and never worked on a game with in-app purchases." — your message | medium | [grounded] | transferability | Your material describes monthly retention numbers that you presented. It doesn't describe a review of an event, and it doesn't say who prepared the numbers. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you pulled or worked the numbers yourself, say which part, in your own words. If someone else prepared them, say so plainly and stay with presenting them. If the KPIs turn out to include revenue, the words are: "I haven't worked on a game with in-app purchases." Then ask which KPIs the review reports |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. Lead with the checklist in your own sentence's terms: you wrote it, and QA still uses it. Nothing has been inspected behind it, so expect a probe. Answer slot: "manage" means ongoing work. If you kept the checklist up to date from release to release, say how. If it stopped being yours once you'd written it, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your two years of weekly drops are in your own words. Your material doesn't show whether the rest of the four years was on a game that was being updated live. Words: "Four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: if the earlier years were on a live title, say which title and what you did, in your own words. If they weren't, say so plainly and count only the years you can stand behind. Describe the work and let Tobias put the label on it |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. This is your strongest match to the JD, said in the JD's own sense. Expect a probe on how you ran it. A2 rehearses that |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap. The numbers were retention numbers and you presented them, so lead with that. A metrics-minded interviewer will ask how they were counted. C1 rehearses that, and "I don't know how it was counted" is an honest answer if it's true |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist that people still use is one written document that lasted. The requirement covers more than one document. Let it stand as what it is, and don't present it as proof of writing in general. The interview itself, and any follow-up email you send, are the rest of the evidence. Answer slot: if you wrote other documents your team relied on, name them. If you didn't, say so plainly and stay with the checklist |

---

## Persona table

The weights below rest on two things. Your own words set the format: one 60-minute session, run by Tobias. The other is an assumption that, as Head of Live Operations, he is the hiring manager. If he sits above the hiring manager, change the weights (see the upgrade menu).

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Here's a quarter of events on two titles, build it." "An event dipped, diagnose it." | **High.** A hiring manager is buying the ability to run the calendar, and the JD is built around planning, coordinating and reviewing | Clarify, then objective, approach, metrics and risks. Think out loud. Challenge one premise politely |
| Skeptic | Quiet probing of the step from associate producer to producer, and of the in-app purchase gap | **High.** A hiring manager has to rule out the gaps. F2 and F3 are where your material is thinnest against the JD | Rehearse B1 until it bores you. Name your limits before he does. Pair every gap with a concrete ramp plan said as a plan |
| Data-Driven Prober | "How were those retention numbers counted?" | **Medium.** The JD's retention line and its KPI line make it likely, and F7 is the one metric in your material | Know what you can and can't say about how the numbers were counted, and say plainly where you don't know |
| Conversational / Rapport | "Walk me through your journey." "Have you played our games?" | **Medium.** Almost every 60-minute session opens and closes this way, and those parts are still scored | Prepare a 90-second arc built only from your four sentences. Have real reverse questions ready |
| Peer Evaluator | "Community wants X, engineering says no. Where do you land?" | **Low.** He's not a peer, but the JD's four-team coordination line will come up as collaboration scenarios | Show what you bring each team, not only what you need from them. Propose working principles rather than claiming to know their setup |
| Pressure | "Sixty seconds: why you?" "How much of that was actually you?" | **Low.** Nothing suggests a stress format, but a single-interviewer hour usually has one sharp moment | Pause, restate the question, anchor on what you actually said. Hold through two follow-ups, then concede only what's real |
| Values / Behavioural | "Tell me about a time a release didn't go to plan." | **Low.** Your words don't describe a values round, and the company's values page couldn't be checked | STAR-style structure, using "we" for context and "I" for your part. Only tell stories you actually have |

---

## Question banks

### A. Case / Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're handed the live-events calendar for both titles next quarter. What do you need to know first, and how do you build it?" | JD/CASE | [generic] | Clarify first: who each title's players are, what events each title already runs, what each event is judged on, and how much design, art and engineering capacity the two titles share. Then structure the calendar. Start with a backbone of recurring beats, add the bigger moments, and stagger the two titles so that shared teams aren't overloaded in the same week. Build in lead times and buffers for art and engineering, and a date when each event's content is locked. Close with risks and how you'd review the calendar after each event. This question asks nothing about your past, and the guidance makes no claims about it | It tests the JD's first line directly, live. JD content, CASE delivery |
| A2 | "How did you run the weekly content-drop calendar, and what would change running live events across two titles?" | JD/EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story beats from your sentence: weekly, the main title, two years, and you ran it. Tell how you ran it in your own words. Answer slot: because the JD says "plan", expect a probe on who decided what went into each drop and when. If that was yours, say how you decided. If someone else set it, or it wasn't decided that way, say so plainly and describe how you ran it. Then the second half, as a plan rather than a past: two titles means two sets of players and shared teams, and events differ from drops in ways you would want to learn first | F6 is your strongest match, and F1 is where it stops short of the JD. EXP because it checks what was yours, JD because it maps to the calendar line |
| A3 | "An event is two weeks out and engineering tells you a feature it depends on will slip. Walk me through your next 48 hours." | CASE | [generic] | First, confirm the facts: the new date and what exactly slips. Lay out the options: cut the feature from the event, swap in a different event, move the date, or ship without it. Weigh each option by its effect on players and on the community message. Decide with the right people, then tell design, art, engineering and community the same thing at the same time. Update the release checklist with QA. Close with what you'd change so the next slip shows up sooner | It covers the JD's coordination and checklist lines in a realistic shape for this role |
| A4 | "An event ended and seven-day retention came in below the last one. How would you diagnose it?" | CASE | [generic] | Check the data before the story: is the metric defined the same way, is it the same cohort, and did tracking change. Then segment: new versus returning players, players who joined the event versus those who didn't, each title, each platform. Then look at causes: the event's design and difficulty, its timing, outside factors such as holidays or app-store changes. Give two or three hypotheses, say what you would check next, and say how you'd write it up in the review | It tests the retention line and the post-event review line in a live problem. CASE because the structure is what's scored |
| A5 | "What should a good post-event review contain, and who is it for?" | JD/CASE | [generic] | A one-page structure: the event's goal, what shipped against what was planned, the KPIs against target, what players and the community said, what went wrong in production, and decisions with owners and dates. Say who reads it and what you'd want them to do differently afterwards. Keep it short, because short is the written-communication test in miniature. This question asks nothing about your past, and the guidance makes no claims about it | The JD makes you the owner of the review and of written communication. F3 and F8 are thinner than F6, so rehearse this one as a plan |

### B. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "As an associate producer, were you the one coordinating design, art and engineering on each drop, or supporting whoever did?" | JD/EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." | **This is the highest-value rehearsal in the pack.** Name the limit before he does, by opening with your title: "I was an associate producer for four years, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: for each of design, art and engineering, if you were the one getting that team's work onto the calendar, name the team and say how, in your own words. If that was someone else's job, or the work wasn't organised that way, say so plainly and come back to the calendar you ran. Follow-up 1, "Who did you report to?": answer plainly. Follow-up 2, "So you haven't led a team?": "I haven't led a team." Then stop and add nothing that makes the gap sound smaller. Concede that and only that, and keep the calendar. Then give, as a plan, how you'd work with four teams in your first months | F2 is the thinnest row against the JD's coordination line, and the associate title draws this question. It will come in some form. JD because it scores the coordination requirement, EXP because it scores attribution |
| B2 | "You haven't worked on a game with in-app purchases. How does that change how you'd run events and their reviews here?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | Hold, then concede. First the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you do have: "I presented the monthly retention numbers to the studio head." Then a ramp plan, said as a plan: learn which KPIs each title's review reports, read the last few reviews, and sit with whoever owns the numbers. Don't guess whether these two titles sell in-app purchases. Ask (reverse question R2). Never suggest that retention work covers revenue work | The JD's KPI line plus a gap you stated yourself make this likely. F3 carries it. JD because it scores the review requirement |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Pick one real answer from the rows where your material is thin: running two titles at once (F1), the four-team coordination (F2), or owning the review and its KPIs (F3). Say it plainly in one sentence, then say what you would do about it in the first 30 days, as a plan. Don't pick a fake weakness. He'll see through it, and it wastes the honesty points | A standard Skeptic question. The rows named give you a truthful choice ready in advance |
| B4 | "Why leave a puzzle studio for this role, and why now?" | EXP | [generic] | Use your actual reason, in your own words. The pack doesn't know it and won't supply one. If parts of the JD genuinely draw you, such as two titles, live events or owning the review, name the ones that are true. Keep it to about 30 seconds and point it forward, not as a complaint about your current studio | Motivation consistency is the Skeptic's other target, and a hiring manager will ask some version of it |

### C. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to your studio head. Walk me through how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start from your sentence: you presented them, monthly, to the studio head. Then fill these answer slots in your own words: how the numbers were counted, what they were sensitive to, the assumption behind them you'd defend least, and which part was yours. If someone else prepared them, say so plainly. "I don't know how it was counted" is an honest answer and beats a method you can't repeat under a second question. Name the weak assumption before he does, but only one you actually know | F7 is the only metric in your material, so it is the Prober's natural target. EXP because it tests attribution and depth |
| C2 | "What did the studio head do with those numbers? Did anything change because of them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a decision followed one of those presentations, say what it was and what your part in it was, in your own words. If nothing changed, or you don't know, say so plainly and stay with presenting the numbers. Don't add an outcome to make the story land | This is the standard second-level follow-up to C1. It is where a pack is most tempted to make up an outcome, so the slot keeps it honest |
| C3 | "Which retention metrics would you put in a post-event review, and why?" | JD | [generic] | Treat it as a design question, not a history question. Name two or three metrics, for example participation in the event and retention of players who joined versus players who didn't. Say why each one matters and what each one doesn't tell you. Say you'd confirm the definitions with whoever owns the data. This guidance makes no claims about your past | It tests the retention line and the review line together. JD because it scores whether you're comfortable with the metrics |

### D. Conversational / Rapport (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these four sentences: four years as an associate producer at a puzzle-game studio; for the last two, you ran the weekly content-drop calendar for the main title; you wrote the release checklist your QA team still uses; you presented the monthly retention numbers to the studio head. Then one honest line on why this role, in your own words. Stop there and let him pick the thread | This is the opener of almost every interview. A tight, accurate arc sets up every probe that follows. It also maps to F5 |
| D2 | "Have you played our games? What did you notice?" | CO | [generic] | Before Friday, play both titles if you can. Note one event or update you saw in each, one thing you liked, and one question you'd ask about how it was run. Say only what you actually saw. The pack couldn't look the titles up, so it gives no names or facts here | Homework is scored casually in this slot. The research for this was blocked (see Sources), so this row is generic |
| D3 | "What are you proudest of from the last few years?" | EXP/JD | [grounded] "Wrote the release checklist our QA team still uses." | One strong option is the checklist: you wrote it, and QA still uses it. Tell it in your own words and let the fact that it's still in use carry the point. Answer slot: because the JD says "manage", expect a probe on whether it changed after you wrote it. If it did and that work was yours, say how. If it didn't, or someone else changed it, say so plainly and stay with having written it | F4 is your cleanest match to a JD line. JD because it maps to the checklist requirement |

### E. Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Community wants an event announced early, and engineering won't commit to a date. Where do you land, and what do you tell each side?" | CASE | [generic] | Find out what each side needs: community needs something to say, engineering needs to avoid promising a date it can't hit. Look for the middle option, such as announcing the theme without the date, or setting a firm "date confirmed by" day. Agree one message, tell both sides at the same time, and record the decision. This guidance makes no claims about your past | It turns the JD's four-team coordination line into a seam scenario |
| E2 | "Tell me about a time you disagreed with another team about what went into a release." | EXP | [generic] | Selection scaffold: pick a real disagreement with a named stake, show your position and how it was resolved, and end with the relationship still intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Collaborative disagreement is the Peer persona's core test. The theme comes from the JD's coordination line |

### G. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who's already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Give three beats, each one a sentence you actually said: two years running the weekly content-drop calendar for the main title, the checklist QA still uses, and the monthly retention numbers you presented to the studio head. Concede plainly: "I haven't worked on a game with in-app purchases." Close in one line on how you'd close that gap. Hold through a second push, and don't fold on the calendar | It compresses B1 and B2 under time pressure, testing composure rather than content |
| G2 | "Your checklist: how much of that was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the position: "I wrote it." Answer slot: if others contributed items or reviewed it, say who did what, in your own words. If it was all yours, say so plainly. Under a second push, repeat what you said, don't add to it | This is the standard attribution probe, aimed at your strongest line (F4) |

### H. Values / Behavioural (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time a release didn't go to plan." | EXP | [generic] | Selection scaffold: pick a real release with a named problem, your specific part in handling it, and what changed afterwards. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's release-checklist line makes this likely in some form. VAL is not the tag because no published values were checked |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. If one of those monthly presentations carried news the studio head didn't want, that's a candidate story, but only if it did. Say what the news was and how you delivered it, in your own words. If none did, pick another real moment where you told someone senior something they didn't want to hear. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | This is a common behavioural question. F7 is the only sentence in your material that involves leadership, so the conditional keeps it honest |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2 |
| Coordinate design, art, engineering and community on each update | B1, A3, E1, E2 |
| Own the post-event review and the KPIs it reports | A5, B2, C3, A4 |
| Manage the release checklist with QA | D3, G2, A3 |
| 3+ years producing live-service games or apps | D1, B1 |
| Experience running a content calendar | A2 |
| Comfortable with player-retention metrics | C1, C2, C3, A4 |
| Clear written communication | A5. The interview itself also counts as evidence, and so does a short written follow-up afterwards |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical event look like on each title, and how far ahead is the calendar locked?" | You think in calendars, and his answer tells you the real cadence you'd inherit |
| R2 | "Which KPIs does the post-event review report today, and who reads it?" | It's the JD's own line, and his answer tells you how much revenue reporting the role involves, which settles B2 for you |
| R3 | "Are design, art, engineering and community shared between the two titles or dedicated to each?" | It shows you're already pricing the coordination load the JD describes |
| R4 | "Is there a recent event that taught the team something? What changed afterwards?" | It invites a real story and shows you care about the review loop, not only launches |
| R5 | "What would you want this person to have taken off your plate in the first 90 days?" | A hiring manager's answer is the real job description, and the question frames you as reducing his load |
| R6 | "How does QA work with live ops on the release checklist today?" | It ties directly to your strongest row (F4) without you needing to repeat it |

---

## Prohibited claims

These are claims the pack won't coach, built from the fit snapshot. They are what a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events or a live-events calendar | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation, not words for you: the material says content drops for one title. A2's slot stays inside the drops |
| Ran the calendar for four years, or across several titles | Inflated form of F1 and F5 | F5's and F1's quotes: four years as an associate producer, and two years running the main title's calendar |
| Owned post-event reviews or the KPIs they report | Inflated form of F3 | F3's quote: "Presented the monthly retention numbers to the studio head." C1's and C2's slots stay inside presenting |
| Managed the release process, or ran QA | Inflated form of F4 | F4's quote: "Wrote the release checklist our QA team still uses." |
| Led a team, or managed people | A negative you stated, F2 | "I haven't led a team." No slot |
| Worked on in-app purchases, monetisation or revenue KPIs | A negative you stated, F3 | "I haven't worked on a game with in-app purchases." No slot |

Coordinating the four teams isn't on this list. Your material is silent on it rather than stretched, so it gets an answer slot (F2, B1) instead.

---

## Sources

- **Provided documents:** the JD text and your background, both in your message. No `tuesday-dossier.md` was present.
- **Searches sent:**
  1. `Saltmarsh Games values`: refused
  2. `Saltmarsh Games interview process producer`: refused
  3. `Saltmarsh Games mobile studio news 2026`: refused
  4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused
- **Fetches:** none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. A values page would have themed values questions and, if a values round existed, a values cheat sheet. The H bank stays generic |
| 2. `Saltmarsh Games interview process producer` | unavailable | The search was refused. Your own words set the format (one 60-minute session with Tobias), so the persona weights rest on that plus the hiring-manager assumption. No values round was detected |
| 3. `Saltmarsh Games` strategy and recent news | unavailable | The search was refused. It would have grounded D2 and a strategy-based CO or CASE question in the two titles. Those rows stay generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have supplied an interviewer read, persona adjustments, and a reverse question tied to his own career path. All three are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Whether Tobias will be your manager or sits a level above → persona weights recomputed, with the Case and Skeptic banks re-tilted for a hiring-manager or skip-level round
- Permission for the four refused searches → D2 and a strategy-grounded question built on the two real titles, a "Reading the interviewer" section from Tobias's public professional profile, a reverse question tied to his career path, and a values cheat sheet if the process turns out to include a values round
- The names of the two titles → A1 and D2 made specific to them
- Any recruiter email or interview invite text → a build section for any set exercise (such as a calendar task or a written review), and coverage matched to the focus areas they named
- Your answers to the answer slots on F1, F2, F3 and F5 → those rows, and A2, B1 and C1, move from slots to your own story
- A redacted page of the release checklist or of one monthly retention deck → F4, F7 and F8 can rise from medium to high confidence, because there would be an artifact to inspect
- A `tuesday-dossier.md` → the highest-ROI objection derived from verified evidence, and a prohibited-claims guardrail checked against that evidence
