Quick update: I've read the prep playbook and I'm now running a few targeted searches on Atlas Freight (values, interview process, recent news) before I build your pack.
I've saved your prep pack as `atlas-freight_operations-manager_interview_pack.md` in your working folder. You didn't say who you're meeting, so I built it to cover every interviewer style equally (21 questions). It also has none of Atlas Freight's own values, interview process or news, because my web searches were blocked. The company-specific questions are generic for now.

**What to rehearse first:** question A1, "You manage 3 supervisors today. This role has 12 across four sites. Why are you ready for that?" Anyone reading your background will see that jump. The pack walks you through:
- stating your current scope plainly yourself;
- holding to it through two follow-ups;
- giving a 90-day plan for leading 12 supervisors across four sites.

Next in line:
- **C1 and D2:** how the 40% mis-pick cut was counted, and how much of it was yours.
- **A2 and E2:** answering "I haven't used Power BI" cleanly, then your plan to learn it.

**Where you're strong:**
- Your 7 years clears the 5+ year bar, though it's not a hard cutoff. But expect "how many of those years were leading people?"
- Your green belt matches the Lean/Six Sigma line in the JD directly.

**Where you're thin:**
- Your background is warehouse and distribution, not freight terminals.
- You lead 3 supervisors at your site; the role is 12 across 4 sites.
- Nothing you told me covers on-time performance or cost-per-shipment. The pack prepares those as live problem-solving questions (B1, B2) and gives you honest ways to answer if you're asked about your track record.

The pack also lists the claims it won't help you make, like multi-site or terminal experience, so you don't drift into them under pressure.

Whenever you're ready, I can play the Skeptic interviewer on A1.
I can also save a `tuesday-dossier.md` file that records the gaps this prep found, for you to use in later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Do you know what kind of round this is (recruiter screen, hiring manager, peer, panel), and did the recruiter mention any focus areas or anything to prepare, like a presentation? The answer changes which interviewer styles get the most questions.
2. Do you want me to research Atlas Freight? If you allow web search, a standard pass is up to 6 searches and 2 page reads. A deeper pass adds up to 6 more searches and 2 more page reads and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, own daily terminal operations across 4 sites. Company: Atlas Freight (regional logistics, 800 employees, per the JD). Interviewer: unknown; round type: unknown. Built as a full-loop pack with flat persona weights, which is noticeably weaker than a pack aimed at a known round.

## How to use this pack

Two axes. **Personas** describe how a question is asked (who, in what style). **Types** describe what is being scored:

- **JD**: can you do the listed job, including its gaps
- **EXP**: do your own claims survive a close look; what was actually you
- **CASE**: structure and reasoning on a live problem from the role
- **VAL**: behaviour and judgement, told as a real story
- **CO**: company and strategy knowledge (thin here: research did not run, see Sources)

Provenance labels: `[grounded]` traces to the JD or your own words; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about Atlas or you.

Guidance is scaffolding, not a script. An **answer slot** is where the pack does not know the answer: it tells you what the interviewer will likely probe, and gives you two honest branches. Fill it from your own memory, or say plainly the thing did not happen.

## Fit snapshot

Requirements are quoted from the JD text in your message. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a shift, not terminal operations across four sites, and the words stay there: "I've spent 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-site line makes a probe on multi-site work likely. If any of your work has covered or coordinated more than one site, say which and how, in your own words; if none has, say so plainly and stay with the work you do run |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | A peak surge plan touches service, but the material does not show whether on-time performance was measured or moved, and the bridge should not be stretched. Answer slot: if on-time or service results were tracked for your shift or the surge plan, say what was counted and how it went; if they were not, or you do not know, say so plainly and say what you would measure first at Atlas |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a cost measure you tracked and a change you made to it. Answer slot: the JD's cost-per-shipment line makes a probe likely. If you have tracked or reduced a cost measure (labour hours, overtime, cost per unit or similar), say which and what happened, in your own words; if you have not, say so plainly and walk through how you would break the number down (B2) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors, not 12, and the words stay there: "Today I'm a senior shift manager over 3 supervisors." Answer slot: expect a probe on how you lead supervisors. If you have a way of setting expectations, coaching or holding your supervisors accountable, describe it in your own words; if there is no set approach, say so plainly and say how you would lead 12, as a plan |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-rating, and the material does not show whether you have built reporting with it. Answer slot: if you have built reports or trackers in Excel, say what they showed and who used them; if not, say so plainly and say what you do in Excel |
| F6 | "build reporting in … Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Not a gate: a years-of-experience line is graded like any other requirement. The material says 7 years in ops, and does not say how many of them were in leadership roles. Answer slot: if asked, give your actual count of years leading people, and the titles; if it is under five, say so plainly and stay with what those years held |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | No gap, but a certification and a figure with nothing inspected behind them, so expect a probe. Lead with the certificate in its own terms, "I'm green belt certified", and keep the pick-path result as its own fact unless you used belt tools on it (C2's slot) |

## Persona table

No round type, interviewer or loop source was given, and research did not run, so this pack falls back to the **generic archetype** (screen, then hiring manager, then panel) with **flat weights**. Every persona gets 3 questions. Reweight once you know who you are meeting.

Bank letters skip F so they never clash with fit-snapshot rows.

| Bank | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| A | Skeptic | Quiet probing of the 3-to-12 and warehouse-to-terminal gaps | Flat. Listed first because it holds the pack's highest-ROI question (A1): F4 and F1 are the gaps any interviewer reading your background will see | Rehearse A1 until it is boring; hold to your own quotes; give a ramp plan as a plan |
| B | Case / Strategist | Live problems: an on-time drop, cost per shipment, a 90-day plan | Flat. The JD names two headline metrics, which makes live metric problems likely from a hiring manager | Clarify, objective, segment, approach, metrics, risks; think aloud |
| C | Data-Driven Prober | Line-by-line on the 40% and on reporting | Flat. A single headline figure (F8's 40%) is a magnet for this style | Know what you can and cannot say about how the 40% was counted |
| D | Pressure | Time-boxed, devil's advocate, "how much was you" | Flat. Common in panels; tests composure | Pause, restate, anchor in your own quote, hold through two follow-ups |
| E | Conversational | Friendly openers, "walk me through", casual Power BI question | Flat. Almost every round opens this way, and casual questions are still scored | Pre-scripted 90-second arc; treat casual JD topics as scored |
| G | Values / Behavioral | "Tell me about a time" stories | Flat. No values page was read, so these are themed by the JD and common stems, not Atlas's own values | "We" for context, "I" for your part; honest branch when no story fits |
| H | Peer Evaluator | Another site or ops manager pricing what you add | Flat. Four sites implies peers at other sites | Reciprocity: what you bring their site, not only what you need |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage 3 supervisors today. This role has 12 across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI rehearsal in this pack.** Name the scope before they push: "Today I'm a senior shift manager over 3 supervisors. Twelve is a real step up." Answer slot: if you have a way of setting expectations, coaching or holding your supervisors accountable, describe it in your own words; if there is no set approach, say so plainly. Then the plan, said as a plan: how you would get to know 12 supervisors and four sites in the first weeks. Hold through two follow-ups by returning to the 3 you lead, never by enlarging it. If pressed, concede specifically: the scale is new | F4 is the gap every reader of your background sees first, so this objection arrives in some form; JD because it scores the stated team-size requirement |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick the real one you already named: "I haven't used Power BI." Then the plan: how and when you would learn it, as a plan. Do not swap in a fake weakness; an interviewer who sees Power BI in the JD and not in your background will ask about it anyway | F6 is the one gap you stated, so it is the honest answer and also the one they will check; JD because it scores the reporting line |
| A3 | "Your background is warehouse and distribution. How does that carry over to running freight terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" | State the scope in your own terms: "I've spent 7 years in warehouse and distribution ops." Answer slot: if any of that work has touched terminal-style operations, say which and how, in your own words; if none has, say so plainly and stay with the warehouse and distribution work. Do not call it terminal experience. Close with what you would want to learn about Atlas's terminals first (reverse question 6) | F1 is a kind-of-work gap, and an interviewer from freight will notice the difference within a sentence; JD because it scores the terminal-operations line |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four terminals dropped this month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is measured here, since when, how big the drop. Segment: by shift, lane, customer, day of week, dock. Form two or three hypotheses and say what data would test each. Then contain (a short-term fix) before root cause, and say how you would know it worked. The question needs no claim about your past, so the guidance makes none | F2's requirement asked as a live problem; CASE because it scores structure, `[generic]` because it is a pattern, not a fact about Atlas |
| B2 | "Cost per shipment is our headline number. Where do you look first to bring it down?" | CASE | [generic] | Ask how Atlas counts it: what is in the cost, what counts as a shipment. Break the number into its parts and ask which part is largest and which moved most. Pick one lever to test first and say what you would watch so service does not suffer. Name the trade-off with on-time performance out loud | F3 has no evidence in your material, so a strong live answer is the main way to cover it; CASE delivery on JD content |
| B3 | "First 90 days: four sites, twelve supervisors you've never met. What's your plan?" | CASE | [generic] | Structure it in phases: listen and visit every site, meet each supervisor one to one, baseline the on-time and cost numbers, pick one early win, then set a regular review rhythm and the reporting to support it. Say what you would not change in the first month | Covers F1 and F4 as a plan rather than a past, which is the honest place for both gaps; CASE because it scores structure |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate 40%. How was that counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number in your own words, four slots: how the 40% was counted (from what to what, over what period); what it is sensitive to; the assumption behind it you would defend least, named before they find it; and which part was yours. If you do not know how it was counted, say so plainly; that is an honest answer and beats a guessed method | The headline figure in your material; EXP because it tests whether the number survives a second question |
| C2 | "Walk me through the pick-path redesign." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Story-mapped on F8: the pick path was redesigned, and the mis-pick rate fell 40%. Tell those beats in your own words. Answer slot: the JD's Lean/Six Sigma line makes a probe likely on whether you used Lean or Six Sigma tools on it. If you did, say which and how; if not, say so plainly and describe the redesign as it happened | F8 is the evidence for the Lean/Six Sigma plus; EXP because it tests what was actually yours |
| C3 | "Tell me about reporting you've built in Excel." | JD | [inferred] "solid Excel" | Answer slot: if you have built reports or trackers, say what they showed, how often, and who used them, in your own words; if you have not, say so plainly and say what you do in Excel. If Power BI comes up: "I haven't used Power BI," then your learning plan | F5 is a self-rating with nothing shown behind it; JD because it scores the reporting requirement, `[inferred]` because the link from "solid Excel" to building reports is this pack's |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already run multiple terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then three facts in their own words: 7 years in warehouse and distribution ops; you ran the site's peak-season surge plan two years running; you are green belt certified. Do not claim multi-site experience and do not knock the other candidate. End on what you would do in the role, not on what you lack | F1 and F4 framed as a comparison; tests composure under a time box |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold on what you said: the pick path was redesigned and mis-picks fell 40%. Answer slot: if others did parts of it, name what was yours and what was theirs; if it was yours alone, say so. Hold through two follow-ups; if pushed on counting, concede specifically what you do not know (C1) rather than folding on the core result | F8's figure under attribution pressure; hold-then-concede rehearsal |
| D3 | "Peak plan, two years running. What part of it was really yours?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Hold to your words: you ran the site's peak-season surge plan, two years running. Answer slot: the JD's on-time line makes a probe on results likely. If the plan's results were measured, say what was counted and how it went; if they were not, or you do not know, say so plainly and stay with what running it involved, in your own words | F2's thin bridge rehearsed under pressure, so the honest answer is ready before the push |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your background." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc from your own lines: 7 years in warehouse and distribution ops; now a senior shift manager over 3 supervisors; the pick-path redesign and the 40% cut in mis-picks; the peak-season surge plan two years running; green belt certified. Close with why this role, in your own words (E3) | The opener in almost every round; scored on economy even when it feels casual |
| E2 | "Have you done much with Power BI?" | JD | [grounded] "never used Power BI" | Casual tone, scored answer. "I haven't used Power BI." Answer slot: if you have started learning since, say what; if not, say how you would get up to speed, as a plan | F6 asked casually is still F6; JD because Power BI is in the reporting line |
| E3 | "Why Atlas, and why now?" | EXP | [generic] | Selection scaffold: your real reasons, in your own words, tied to what the JD says the role is (four sites, on-time, cost, 12 supervisors). Avoid any claim about Atlas you have not checked yourself; research did not run. Keep any reason for leaving short and true | Motivation consistency; `[generic]` because no Atlas facts are in hand |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to hold a supervisor accountable." | VAL | [generic] | Pick a real time with a clear expectation, a gap, the conversation you had, and how it ended for the work and the relationship. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's "lead a team of 12 supervisors" line makes this likely; VAL because it scores judgement through a story |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, what you said, and what happened next. Choose one where the message actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioural stem; with no Atlas values in hand it stands in for a values round |
| G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real trade-off: the customer need, the metric that suffered, how you decided, the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | On-time performance and cost per shipment pull against each other in this role, so a trade-off story is useful rehearsal |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our sites share freight and people. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Propose principles: agree the shared numbers, raise problems early, settle disagreements on data, escalate together not around each other | Four sites implies peer managers who will price what you add to their load |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a real time work crossed teams and say what you did about credit. If the pick-path or peak work involved others, the honest split is D2's slot. If no such time comes to mind, say so plainly and give your principle | Peers probe credit-sharing; ties to D2's attribution rehearsal |
| H3 | "What would you need from the other site managers in your first month?" | CASE | [generic] | Reciprocity: what you bring their sites as well as what you need. Ask for their read on the numbers and on supervisors, offer to share what you find at your sites | Reciprocity question; tests whether you reduce or add to a peer's load |

## Requirement coverage

| JD requirement | Fit row | Question IDs |
|---|---|---|
| Own daily terminal operations across 4 sites | F1 | A1, A3, B3, D1, H1 |
| Drive on-time performance | F2 | B1, D3 |
| Drive cost-per-shipment down | F3 | B2 |
| Lead a team of 12 supervisors | F4 | A1, B3, G1 |
| Build reporting in Excel | F5 | C3 |
| Build reporting in Power BI | F6 | A2, C3, E2 |
| 5+ years operations leadership required | F7 | A1, D1 — and expect a direct "how many years leading people?" (F7's slot) |
| Lean/Six Sigma a plus | F8 | C1, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured here, and which terminal is furthest from target?" | Shows you think in the JD's own metrics, and the answer gives you material for B1 if it comes up later |
| R2 | "What goes into cost per shipment as you count it?" | Shows you know a metric is only as good as its definition |
| R3 | "What does reporting look like today, and is there a Power BI setup already?" | Shows you have taken the Power BI line seriously and want to know what you would inherit |
| R4 | "What separates the supervisors who do well here from those who struggle?" | Puts you in the seat of the person leading 12 of them |
| R5 | "What would you need to see in the first 90 days to know this hire was right?" | Gets their scorecard in their words; you can answer against it in a thank-you note |
| R6 | "What's the biggest difference between running your terminals and running a warehouse?" | Names the F1 gap yourself, as curiosity, and gets you the vocabulary to use next round |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says warehouse and distribution ops and a shift, not four sites. F1's slot stays inside the work you name |
| Has led a team of supervisors this size | Inflated form of F4 | "Currently a senior shift manager over 3 supervisors," at its own scope. A1's slot asks only how you lead the supervisors you have |
| Has freight terminal experience | Inflated form of F1 ("warehouse and distribution ops" is a different kind of work) | "7 years in warehouse and distribution ops," at its own scope. A3's slot lets you say none of it was terminal work |
| Has 7 years of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops," at its own scope. F7's slot asks for your actual count of leadership years |
| The 40% cut lowered costs or improved on-time performance | Inflated form of the mis-pick quote in F8 | "Cut mis-pick rate 40% by redesigning the pick path," at its own scope. The pack observes the quote is about mis-picks, not cost or service |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form linking two F8 quotes | Each quote on its own. C2's slot asks whether you used those tools on it |
| Has used or built anything in Power BI | Negative you stated, F6 | "I haven't used Power BI." No slot |

## Sources

- Provided: the JD text and your background, both from your message
- Search "Atlas Freight values regional logistics": refused
- Search "Atlas Freight interview process operations manager": refused
- Search "Atlas Freight news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have given Atlas's own values by name, a values cheat sheet, and VAL questions mapped to them; G1 to G3 stay generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have named the rounds and reweighted the personas; weights stay flat |
| 3. `Atlas Freight` strategy / recent news | unavailable | The search was refused. It would have given a CO question and a current-strategy case; B1 to B3 stay generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; no interviewer read |
| 5. representative Operations Manager JD | skipped | Your JD text fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and in what round (hiring manager, peer, panel, recruiter) → persona weights stop being flat, the top persona gets 4 to 5 questions, and weak banks are trimmed
- Any recruiter guidance (focus areas, a presentation or case to prepare) → a build section for each declared deliverable
- The interviewer's name → an interviewer read from their public profile and a reverse question tied to their path
- Web search allowed → Atlas's values, interview process and recent news, replacing the `[generic]` rows in banks B, E and G with company-grounded ones
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and a "why Atlas" answer built on real company facts
- The full JD text, if what you sent was a summary → any requirement it adds gets a fit row and a question
- Your own answers to the slots in F1, F2, F3, F5 and F7 → those rows move from answer slots to story-mapped guidance, and A1, B2, C3 and D3 get stronger
- How many prep hours you have → a prioritized prep schedule
- A tuesday-dossier.md → verified evidence and a set of claims to avoid, carried in from a fit check
