I'm getting your Stripe prep pack together. Now I'm looking up Stripe's operating principles, how their interviews are run, recent company news, and a current Product Ops job description.
I've saved your prep pack as `Stripe_product-operations-manager_interview_pack.md`. It has 21 practice questions, each with answer guidance, plus a self-assessment worksheet and questions for you to ask them.

It's built only from your message. My web searches were blocked on this setup, so the pack doesn't cover Stripe's published values, its actual interview process or its current strategy. I haven't filled those in from memory, because those details change and a confident wrong one would hurt you. It's also built for a final round of unknown makeup, using a typical big-tech loop pattern, because I don't know who you're meeting.

Before the interview:

- **Fill in the eight-row worksheet** with real examples from your own work. Each row is a typical product-ops duty, such as launch readiness, process design, metrics, or influence without authority.
- **Rehearse C1 first:** "Which part of this role would you be weakest at on day one?" It's the most valuable thing to practise.
- **Read Stripe's operating principles on their own site** so you can use their wording.

Say the word and I'll play the Skeptic on C1, the question the pack names as its most valuable rehearsal.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two things would make the pack much sharper:

1. **Who are you meeting in the final round?** For example the hiring manager, peers or a cross-functional partner. Has the recruiter mentioned focus areas or anything to prepare, like a case, a presentation or a written exercise? This reweights every question bank.
2. **Can you paste the job description and your CV?** The worksheet would become real requirements matched to your own experience. I'll keep working without them if you'd rather.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewers: not known. Built for a final round of unknown makeup, from your message alone. No JD, CV or research was in hand: web search was refused on this host, so nothing below rests on Stripe's published values, its documented interview process or its current strategy.

## How to use this pack

Two axes. **Personas** describe how a question is asked: who is asking, in what style. **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes |
| EXP | Whether your claims about past work survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth: the company's strategy, competition and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

The guidance gives you scaffolding, not a script. Every story below is a *selection scaffold*: what a strong example looks like, and an honest way out if you don't have one. I have none of your history, so the pack picks no stories for you. Choose them from your own work and tell them in your own words.

## Fit snapshot (worksheet)

You gave no CV or background, so this is a self-assessment worksheet. There is no JD either, so the requirements are typical product-operations duties, not Stripe's. Fill each row with a real example before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Readiness for product launches across functions: support, documentation, risk and internal training ready before launch day. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a launch where you can name what had to be ready, who owned each piece, and what you checked before go-live. Pick a launch you prepared people or processes for. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing and scaling repeatable processes such as intake, escalation paths and runbooks. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a process you designed or changed, what it replaced, and how you knew it worked. Pick one where you can name the before and after. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Working with data: defining operational metrics, building or reading dashboards, querying data. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a metric you defined or reported, how it was counted, and a decision it changed. Pick one where you know the denominator. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Turning user feedback and operational signals into product priorities: the loop between support or ops and product teams. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a time a signal from users or ops reached a product team and something changed, with your part in it named exactly. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence without authority across product, engineering, support and business teams. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a time you moved a team you did not manage, with what they wanted, what you wanted and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritising and running programmes under ambiguity. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a time you had to choose between competing asks with incomplete information, what you chose and why. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Clear written communication: launch docs, process docs, updates to leadership. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a document you wrote that others acted on. Pick one you could describe in a minute. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F8 | Operational tooling and automation: workflow tools, internal tools, removing manual steps. Role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence: a manual step you removed or a tool you set up, and what it saved. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No source tells me how your final round is structured, so the weights below come from a fallback pattern, the big-tech structured loop: recruiter, then hiring manager, then skills or case, then behavioural or values, then committee. That pattern pushes Values/Behavioral and Case up. These are blended weights for a final round whose sessions are unknown, not a description of Stripe's process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ops problems: plan a launch, diagnose a spike, design an intake | High. The fallback pattern weights case work up, and product ops is judged on operational reasoning | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise per case |
| Values / Behavioral | "Tell me about a time…" probes, possibly from someone outside ops | High. The fallback pattern has a values or behavioural round somewhere in the loop | Pick each story from your own work. Use "we" for context and "I" for your contribution. Where you have no story, say so instead of inventing an ending |
| Skeptic | Quiet probes on gaps, plus why ops, why here, why now | Medium. Final rounds usually test motivation and self-assessment | Rehearse C1 until it bores you. Build bridges only from work you actually did, and name the limit plainly |
| Data-Driven Prober | Asks how a number was counted and which assumption is weakest | Medium. F3 is core to the role family | Know what you can and cannot say about each number you cite. Name your weakest assumption before they do |
| Peer Evaluator | "Where's the seam between us?", collaboration and credit | Medium. Ops roles sit between teams, so peers are plausible panellists | Frame reciprocity, offering seam principles rather than pretending to know the seam |
| Pressure | Time-boxed, devil's advocate, "how much was actually you?" | Low to medium. It may show up in any session | Pause, restate, anchor in what you actually did. Hold through two follow-ups, then concede specifically |
| Conversational | Friendly openers and "walk me through the journey" | Low as a style, but present in every session | Use a 90-second arc you have already scripted. Casual questions are still scored |

## Question banks

Ordered by persona weight. **The highest-ROI prep in this pack is C1.** Without your CV I can't name the objection most likely to land on you, so C1 makes you name it first.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A new feature launches to business users in a new market in eight weeks. Sketch the operational readiness plan. What do you need to know first?" | CASE | [generic] | Clarify first: who the users are, what the launch date depends on, what success means. Then workstreams with owners: support readiness (help content, escalation path, staffing), internal training, risk or compliance review, the metrics you'll watch in week one, and a rollback trigger. End with the two risks you'd watch most and what you'd do if one fired. The question asks nothing about your past, so the guidance makes no claim about it | F1's requirement as a live problem, likely from a hiring manager. CASE because it scores structure, not history |
| A2 | "Support contacts about one product flow rose 20% month over month. Diagnose it." | CASE | [generic] | Check the number first: contacts per active user, or raw contacts while usage grew? Segment by user type, region, channel and date, and line the curve up against releases and policy changes. Read a sample of tickets before you hypothesise. Then rank the hypotheses, size each one, route the fix to its owner, and say how you'd confirm the loop closed | F4 and F3 together. The persona stem for diagnosis questions, set in ops terms |
| A3 | "Product teams say ops requests reach them as an unprioritised stream. Design an intake process." | CASE | [generic] | Clarify who sends requests and what "unprioritised" costs today. Propose one front door, a short required template (problem, affected users, evidence, urgency), a triage cadence with named deciders, visible status, and a rule for true emergencies. Say how you'd measure whether it worked, such as time to decision or requests reopened, and the failure mode to watch: the process becomes the bottleneck | F2 and F6. Tests process design without asking for your history |
| A4 | "Pick a metric you'd use to judge whether an ops process is healthy, and tell me how it could mislead you." | CASE | [generic] | Name a metric, such as time to resolution. Say what it rewards and how it could be gamed or misread: closing tickets fast but reopening them, or averages hiding a long tail. Pair it with a counter-metric. This is a live problem, so answer as reasoning, not as something you did | F3. Probers and hiring managers use this to test metric judgment |
| A5 | "Two product teams both need you for launches in the same month. How do you decide?" | CASE | [generic] | Clarify the stakes of each: users affected, risk if it slips, hard dates. State a decision rule out loud, propose the call, and say who you would escalate to and when. Give the trade-off you'd tell both teams plainly | F6 and F5. Prioritisation under contention is the core of the role family |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said, and how it landed, including if it didn't. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for values rounds. The fallback pattern makes a values round likely somewhere in the loop. Stripe's published values were not in hand, so this is not mapped to them |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a decision where a user's need and a number you were measured on pulled apart. Say what you chose, what it cost, and what your part was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. Ops roles live between user pain and team metrics |
| B3 | "Tell me about a time a number you were watching moved the wrong way. What did you do?" | VAL | [generic] | Selection scaffold. Pick a real instance: what moved, how you noticed, what you did first, and what your part was compared with others'. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The diagnosis stem asked about the past. VAL first because it scores behaviour; EXP second |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal.** Choose your real weakest row from F1 to F8, not a disguised strength. Name it in one sentence, give the nearest real thing you have done, with its limit stated plainly, and give a concrete ramp plan for the first 30 days. Hold that answer through two follow-ups by returning to the plan, without adding experience you don't have | Skeptics ask this in some form in most final rounds. The answer most candidates get wrong is the evasive one. JD because it scores self-assessment against the listed job |
| C2 | "Why product operations, and why now?" | EXP | [generic] | Your own reasons in 60 to 90 seconds: what pulled you toward ops work, and what about this moment makes the move right. Keep it consistent with what you told earlier interviewers. If you don't know Stripe specifically from its own published material, don't improvise facts about it | The Skeptic's motivation probe. EXP because it tests consistency of your own story |
| C3 | "How would you handle the analysis side of this role from week one?" | JD | [generic] | Forward-looking. Describe how you would get to the data: who you'd ask, which first questions you'd answer, how you'd check a number before using it. Claim no tool skill you don't have. If you have one, the F3 row is where you'll have written it | F3 is often where ops candidates get probed. Phrased as a plan so it presupposes nothing about your past |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you've reported on in a past role. Walk me through how it was counted." | EXP | [generic] | Selection scaffold. Pick a figure you would actually cite. In your own words, say how it was counted, what it is sensitive to, and which part of the work was yours. If you don't know how it was counted, say so plainly. If no such number comes to mind, say so, then give the nearest thing your material does carry, or how you would handle it | A persona stem. Any figure you mention in any session can draw this |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | The weakest-assumption move: name it yourself, in your own words, before they do. If you don't know the assumptions behind it, say so plainly and say what you'd check | The follow-up a prober uses after D1. Rehearsing it turns the gotcha into a gain in credibility |
| D3 | "Tell me about an analysis you did yourself, end to end." | EXP | [generic] | Selection scaffold. Pick one where the question, the data, the method and the decision were yours, and say plainly any part that wasn't. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Comes from the prober's counter-strategy. Tests F3 and attribution |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles instead: one owner per decision, shared definitions for the metrics you both use, an agreed path for escalation, and disagreement in writing before it reaches a meeting. Ask what has gone wrong at that seam before | F5. A peer is pricing whether you add to their load or reduce it |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold. Pick a piece of shared work and say exactly what was yours and what was others'. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. Attribution honesty here signals the same in every other answer |
| E3 | "What would you need from me in your first month?" | CASE | [generic] | Answer with reciprocity: one thing you'd need, such as context on their current pain points, and one thing you'd bring them early, such as a fix to an intake or handoff that costs them time. Keep it concrete and small | Tests partnership fit. Pairs with the reciprocity reverse question |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats: what you bring from outside, pointing to your strongest filled-in F row; that you'd make up the missing context fast, with how you'd do it; and why you want this role. Don't knock the internal candidate. Stop at 60 seconds | A persona stem. Tests composure under a time box |
| G2 | "That result you just described: how much of it was actually you?" | EXP | [generic] | Hold, then concede. Restate your exact part in the words you used before, give the team its share without shrinking yours, and hold that through two follow-ups. If the honest answer is "less than it sounded", say so specifically. That is a credibility gain, not a loss | A persona stem. It can follow any story from B, D or E |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc you have already scripted, built only from your real roles: where you started, the thread that leads to ops work, and why this role is the next step. End by handing the conversation back | A persona stem. Asked in a casual register, but scored |
| H2 | "What are you actually playing with these days in ops tooling or automation?" | JD | [generic] | Name something you really use or are trying out, and what you've learned from it. If nothing comes to mind, say what you'd like to automate in this role and why. Don't name a tool you haven't used | F8, asked casually. Casual questions on a role's plus-skills are scored |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Launch readiness | A1 |
| F2 Process design | A3 |
| F3 Data and metrics | A2, A4, C3, D1, D2, D3 |
| F4 Feedback into product | A2 |
| F5 Influence without authority | A5, E1, E3 |
| F6 Prioritisation under ambiguity | A3, A5 |
| F7 Written communication | none. Writing is usually judged through a submitted document, not a spoken question. If your recruiter announces a written exercise, it gets its own build section |
| F8 Tooling and automation | H2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a great first six months look like in this role, and what would make you say the hire wasn't working?" | Shows you're thinking about being measured, and gives you the real success criteria |
| "Where do product ops and the product teams disagree most often today?" | Shows you expect the seam, and tells you where the job's friction is |
| "Which processes here are working well enough to leave alone?" | Signals judgment rather than an urge to rebuild everything, and it is rarely asked |
| "How does an ops signal, like a spike in support contacts, reach a product decision today?" | Tests F4 in their own words and shows you how mature the loop is |
| "What's the hardest trade-off this team made in the last year?" | Gives you the team's real priorities without asking them to sell the job |
| "What could someone new do in their first month that would genuinely help your team?" | Reciprocity question for any peer on the panel |

## Prohibited claims

Nothing is listed yet. You have shared no CV and no sentence about your past, so there is no wording to inflate and no stated gap to hold you to. This section fills in once you send material. Until then, the selection scaffolds above carry the same rule: tell only stories you lived, at their real scope.

| Not coached | Basis | Honest form |
|---|---|---|
| none yet | No candidate sentences in hand | Not applicable until a CV or background arrives |

## Sources

Provided documents: your message ("Final-round interview at Stripe for a Product Operations Manager role").

Searches sent, all refused by the host's permission settings, so none returned anything:

- "Stripe operating principles": refused
- "Stripe interview process product operations onsite rounds": refused
- "Stripe news 2026 strategy stablecoins agentic commerce": refused
- "Stripe "Product Operations" job description responsibilities": refused

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Refused. It would have supplied Stripe's published principles by name, mapped the B bank to them, and enabled a values cheat sheet |
| 2. Stripe interview process, product operations | unavailable | Refused. It would have shown whether a source establishes your final round's sessions, replacing the fallback pattern behind the persona weights |
| 3. Stripe strategy and recent news | unavailable | Refused. It would have added at least one CO or CASE question on current strategy. No CO question appears because of this |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Refused. It would have turned the F rows from typical duties into quoted, `[inferred]` requirements |

## Upgrade menu

- The JD text: F1 to F8 become the posting's own quoted, `[grounded]` requirements; gate rows appear if it sets location or other terms; the JD-tagged questions retarget to it
- Your CV or a short background: the fit snapshot stops being a worksheet; selection scaffolds become story-mapped answers on your own sentences; the prohibited list gets real entries; C1 becomes the objection most likely to land on you
- Who you're meeting, and the schedule if your final is several sessions: real persona weights per person, and per-session mini-packs
- The recruiter's prep email or guidance on focus areas: coverage of any announced case, presentation or written exercise as a graded build section
- Interviewer names: an interviewer read from their public professional footprint, and a reverse question tied to their path
- Stripe's operating principles page, pasted, or web search allowed: a values cheat sheet, with B-bank questions themed on Stripe's own principle names
- Web search allowed on this host: a rerun of research targets 1, 2, 3 and 5 above, within what is left of the L1 budget: 2 searches and 2 fetches
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, once search is allowed: a strategy brief, recent org context and role-family loop reports, which turn the generic CASE questions into Stripe-specific ones
- A `tuesday-dossier.md` from an earlier underwriting session: verified evidence, a named highest-ROI objection and a prohibited-claims list grounded in what you confirmed
