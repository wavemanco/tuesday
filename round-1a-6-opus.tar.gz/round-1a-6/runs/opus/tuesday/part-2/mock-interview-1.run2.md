No dossier in the working directory. Reading the references.
I've built Priya's prep pack for her 60-minute peer conversation with Dan: 21 questions in 7 persona tables, each tagged by question type, with answer guidance, a provenance label and a rationale for including and categorizing it.

**Web search was refused**, so nothing in the pack is checked against outside sources. Northwind's values, interview process, strategy and Dan's public profile all rest on what you told me. The bundling, Compass and profitability cases are grounded only in your research note.

- **Most important question (C1):** Dan asks how she can do GTM strategy credibly next to Sales without sales-ops or quota-setting experience. It's in Dan's own area and you've confirmed the gap, so some version of it is near-certain. The guidance has her say the limit first, give two things she has done (without calling volume targets quotas), then a plan, and it scripts three follow-ups.
- **Second priority (C3):** partner-motion design is the JD's only "required" item. Her nearest evidence is the revenue model used in carrier negotiations, so the guidance keeps that a model and never calls it a partner motion she designed.
- **The ~$400M figure:** it's tested three times (A1, B4, E1). The guidance keeps your wording, "proposed" and "credited with", and leaves how it was counted for Priya to answer. "I don't know how it was counted" is allowed as an honest answer.
- **Dan's background:** the three case questions lean on pricing, packaging and unit economics because that's his career. Two of the six questions Priya can ask Dan at the end come from his pricing work and his startup chapter.
- **What I left out:** there's no values cheat sheet, because no values round is planned and I couldn't look up Northwind's published values. The two values questions are generic.
- **The pack also includes** a table matching each JD requirement to her evidence, a list of claims the pack won't coach (like "drove $400M"), and a list of what would improve it.

Files are in the working folder:
- Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md

I can play Dan as the skeptic on C1 for a live run-through, with follow-ups that react to her answers.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
I can convert the pack to a Word document too.

Can you paste the full JD and Priya's CV? With them, the requirements and evidence would quote the actual documents instead of your summaries.

If you allow web search, should I rerun the basic lookups and add a deeper pass (up to 6 more searches and 2 page fetches, several more minutes) to check the strategy and Dan's profile?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview Prep Pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Session:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy. Dan is a **peer**, reporting to the same VP.

---

## How to use this pack

Two axes organize everything. **Personas** describe how a question will feel when it's asked. **Types** describe what's being scored. Every question has answer guidance and a rationale explaining why it's included and why it has its tags.

| Tag | What it's really testing |
|---|---|
| **VAL** | Behavioral / values: whether past behavior shows a value, not generic virtue |
| **EXP** | Work-experience deep-dive: whether the claims survive scrutiny, and what was actually hers |
| **JD** | Role / JD-driven: can she do the listed job, including its gaps |
| **CO** | Company and strategy: can she think at Northwind's altitude |
| **CASE** | Live problem: structure and reasoning on a problem from the actual role |

Provenance labels: `[grounded]` traces to what you provided. `[inferred]` is a derivation, which the row names. `[generic]` is a role-family pattern with no claim about Northwind or Priya.

The guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview, not a question for you. It names a likely probe, and both of its branches are honest answers. Priya fills it with what she actually did, or says plainly that she didn't do it.

Question IDs run A to H by persona. **F is skipped** so it can't be confused with fit-snapshot rows F1 to F8.

---

## Fit snapshot

The requirements are quoted from the JD highlights in your message. The evidence is quoted from your description of Priya, labelled "the coach's notes". F7 quotes your role summary, and F8 is a role-family requirement written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Her material says product strategy and ops, not GTM ownership of a product line, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's GTM-ownership line makes a probe on that work likely. Say what the product strategy and ops work covered and which parts were hers, in her own words. If a part wasn't hers, say so plainly and stay with the work she did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Her material doesn't show lifecycle or whitespace analysis. Answer slot: if she has found or sized untapped segments, accounts or usage anywhere, she says where and how, in her own words. If she hasn't, she says so plainly and says how she would look for it here. A4 rehearses that live |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap on the tools. Nothing has been inspected behind the claim, so expect Dan to test it. Lead in the quote's terms: SQL and Tableau. A3 holds the slot for an analysis she ran on her own |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Her material says a revenue model used in negotiations, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on the model likely. Say what it covered, what it was used to decide, and which parts were hers, in her own words. If a part wasn't hers, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | presentation | The first quote already reaches the requirement in other words. Reword only that quote: "I set the annual volume targets, with consensus across orgs." Tell the second quote at its own verbs: she proposed the change, and it was credited with the uplift. It is also the headline figure the Prober bank defends (A1, B4, E1) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Daily tool use touches the plus but doesn't show what kind of AI experience it is. Answer slot: name the tools and what she uses them for, in her own words. That is the whole claim. G2 rehearses it |
| F7 | Enterprise B2B context: "B2B data-infrastructure SaaS" — role summary, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | Her material doesn't show whether any of this work involved business or enterprise buyers. Answer slot: if a consulting project or consumer-tech work did, she names it and what she did, in her own words. If none did, she says so plainly and stays with what the work was |
| F8 | Sales-strategy fluency in territory, capacity and quota-setting: the domain a Director of Sales Strategy typically owns. A role-family requirement, not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A stated gap that wording can't close. Her words: "I haven't done classic sales-ops or quota-setting." Then how she'd learn Northwind's model, said as a plan and never as a past. Never call volume targets quotas, and add nothing to make the gap feel smaller |

**Gate rows:** none. The JD highlights name no location, travel, authorization or credential terms.

---

## Reading the interviewer

**Source:** your message. Web search was refused in this session, so none of this has been checked against Dan's public footprint (see Sources).

| Signal (from your message) | Provenance | What it means for this conversation |
|---|---|---|
| Self-describes as "relentlessly data-driven" | [grounded] | Every number will be probed to its assumptions. Priya should name her own weakest assumption before Dan does (A1, A5), and say plainly when she doesn't know how a figure was counted |
| "career spine is pricing and monetization roles" | [grounded] | The case questions tilt to pricing, packaging and unit economics (D1 to D3). A2's revenue model is the story most likely to land on Dan's home ground |
| "one early-stage-startup chapter" | [grounded] | Expect scrappiness probes and some skepticism about big-company pace. Her material holds no startup story, so she shouldn't invent one. Reverse question 2 turns this into a peer conversation |
| Peer, same VP | [grounded] | Dan is weighing what this hire costs or adds to their own team's work. The quota gap (F8) sits squarely in their lane, so candor beats bluffing (C1) |

**Mirror opportunity:** shared vocabulary only, no shared career jump. F4's quote, "built a partner-level revenue model used in carrier negotiations", speaks Dan's monetization language. Priya should describe it in those terms and let Dan draw the parallel.

---

## Persona table

**Loop:** your message establishes it as one 60-minute conversation run by Dan. No values-style round is named, so there is no values cheat sheet.

| Persona | How it shows up with Dan | Weight, with the reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Data-Driven Prober | "How was that counted? What's the denominator?" Two levels deeper than her answer | **Highest (5 questions).** The peer prior puts it in the top two, and "relentlessly data-driven" raises it further | Know what she can and can't say about each number. Name the weakest assumption first. Offer to walk through an analysis end to end | A |
| Peer Evaluator | Where the seam sits, what each side needs, credit and disagreement between equals | **High (4).** The peer prior's other dominant persona, and Dan shares the same VP | Lead with reciprocity. Propose seam principles rather than pretending to know the seam | B |
| Skeptic | Quiet probing of the gaps: quota (F8), partner-motion design (F4), B2B context (F7) | **Mid (3).** Raised above the peer prior because F8 sits in Dan's own domain and F4 is a "required" line. It carries the highest-ROI question | Rehearse C1 until it's boring. Say the limit before it's asked for. Bridge only from what she stated | C |
| Case / Strategist | Live problems on bundling, Compass and channel choice | **Mid (3).** Not a peer-round dominant, but the pricing career spine tilts case questions toward pricing and unit economics, and your research note supplies real material | Clarify, then objective, segmentation, approach, metrics and risks. Challenge one premise per case | D |
| Pressure / Stress | "How much of it was actually you?" and time-boxed challenges | **Low (2).** Nothing signals a stress style, but the $400M figure invites it | Pause, restate, hold through two follow-ups, then concede something specific | E |
| Conversational | The opener, plus a casual question on AI | **Low (2).** Every conversation opens somewhere, and AI is the JD's plus | A 90-second arc. Treat casual questions on hot topics as scored | G |
| Values / Behavioral | Generic behavioral probes | **Low (2).** No values round and no Northwind values in hand, so these are generic | Selection scaffolds with an honest branch | H |

---

## Question banks

> **Highest-ROI prep: C1, the quota and sales-ops objection.** Dan owns that world, and the gap is stated. Some version of this question is near-certain. A calm answer that states the limit first changes the conversation.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell it at the quote's own verbs: "I proposed the store-surface change, and it was credited with about $400M in ARR uplift." It's "proposed" and "credited", never "drove" or "delivered". Answer slots, each in her own words: how the figure was counted, if she knows ("I don't know how it was counted" is an honest answer); what it is sensitive to; the assumption behind it she'd defend least, named before Dan asks; which part was hers beyond the proposal. If a step wasn't hers, or there was no such step, say so plainly and return to the proposal | A headline figure in front of a self-described data-driven interviewer gets probed first. The figure is F5's second quote. Tagged EXP because it scores whether the claim survives scrutiny. The same figure comes back under pressure in E1 |
| A2 | "Walk me through the partner-level revenue model: what went in, and how it was used in the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Map the story to the quote: she built it, it was partner-level, and it was used in carrier negotiations. Offer to walk it end to end. Answer slots, in her own words: its inputs and structure; what its outputs were most sensitive to; her own part in the negotiations. The quote says the model was used in them, not that she negotiated. If she was in the room, she says what she did there. If she wasn't, she says so plainly and stays with the model | F4 is the closest evidence to the JD's only "required" line, and a revenue model is Dan's home ground. Tagged EXP because it separates what she built from what others did with it |
| A3 | "This role runs its own analysis in SQL and Tableau. Tell me about one you ran yourself, end to end." | JD | [grounded] "skilled in SQL/Tableau" | Lead in the quote's terms: SQL and Tableau. Answer slot: the JD says "independent analysis", so expect a probe on work she did alone. If she has an example, she walks it in order (the question, the data, what she built, what changed) in her own words. If her SQL and Tableau work was mostly done with others, she says so plainly and describes what she did with the tools. She can offer to sketch a query live | F3 is a named requirement, and a peer who will lean on the hire's numbers checks it early. Tagged JD because it scores the stated line, delivered in EXP style |
| A4 | "Say you find what looks like expansion whitespace in our installed base. How do you prove it's real before Sales chases it, and what's the denominator?" | CASE | [generic] | Structure it aloud. Define the unit (account, workspace, seat or usage) and ask Dan which one Northwind uses. Set the denominator as all eligible accounts, not just the promising ones. Pick the signal: usage, adjacent purchases or fit attributes. Validate with a holdout, a small pilot with one sales team, or a win-rate comparison. Say what result would make her drop it, and name the weakest assumption in her own plan. The question asks nothing about her past, so the guidance claims nothing | F2 has no evidence, so it's rehearsed as a live problem where structure can carry the answer. Tagged CASE. `[generic]` because the method is a pattern, not a Northwind fact |
| A5 | "How were those annual volume targets set, and how did you get consensus across orgs?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Map the story to the quote: she set annual volume targets, with cross-org consensus. Answer slots, in her own words: how they were set and whether the method was hers; what they were most sensitive to; how consensus was reached and which part of that was hers. If a step didn't exist or wasn't hers, she says so plainly and returns to the targets. Call them volume targets, never quotas | Targets are the item closest to Dan's lane, so they'll be tested hardest. F5's first quote. Tagged EXP because the claim depends on attribution, and the question protects the prohibited line on quotas |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [generic] | Don't pretend to know the seam. Offer principles as a hypothesis for Dan to correct: one shared source for pipeline and bookings data; Emerging Products owns the GTM thesis for the new lines; Sales Strategy shapes how that lands in territories and capacity. Disagreements settle on shared data first. If they still split, take them to the VP together, as one framed choice. End by asking Dan where the seam sits today | This is the Peer Evaluator's signature question, and it scores the JD's cross-functional influence line (F5's requirement). JD content, CASE delivery. `[generic]` because the seam is a pattern, not knowledge of Northwind's org |
| B2 | "Tell me about a time you got a number agreed across teams that wanted different things." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Map the story to the quote: the annual volume targets, set with cross-org consensus. Answer slot: the JD's influence line makes a probe on disagreement likely. If the orgs wanted different things, she says what they wanted, what she did and how it ended, in her own words. If they didn't, or consensus came easily, she says so plainly and picks another time from her own experience, or says none comes to mind | An open prompt themed on F5's requirement. Tagged EXP because it tests what she actually did to get there. A5 probes the method; this one probes the friction |
| B3 | "If you joined, what would you need from my team in the first 90 days, and what would we get back?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with what she gives. In the quote's terms, she can run her own SQL and Tableau analysis, said as an offer rather than a boast. What she needs: their definitions of pipeline, bookings and expansion; access to the same data; a slot in their planning cycle; their read on which accounts are sensitive for Sales. Close by asking what would genuinely help their team in month one | Tests whether the hire adds to Dan's load or reduces it (F3, and F5's requirement in practice). Tagged JD because it scores cross-functional influence |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote at its own verbs: she proposed the change, and it was credited with about $400M in ARR uplift. Answer slot: if other teams built, shipped or measured it, she names them and what they did. If it was hers end to end, she says so plainly. Never "my $400M" | A persona stem aimed at the figure most likely to be claimed loosely (F5). Tagged EXP because it scores attribution honesty, and it rehearses that before E1 adds pressure |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't done classic sales ops or quota-setting, and that's my world. How do you do GTM strategy credibly next to Sales without it?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep.** Say the limit first: "I haven't done classic sales-ops or quota-setting." Then two facts at their own scope, offered as what she has done, not as substitutes: "I set annual volume targets with cross-org consensus," and "I built a partner-level revenue model used in carrier negotiations." Then the plan, in the future tense: learn Northwind's capacity and quota logic from Dan's team early, and build new-line forecasts that plug into it rather than compete with it. **Follow-up 1**, "Volume targets are basically quotas, right?": "No, they're not, and I wouldn't call them that." **Follow-up 2**, "So why would I trust your expansion numbers?": offer her method for review by Dan's team before anything goes to Sales. **Follow-up 3**, "Then isn't this really a sales-strategy hire?": hold. The JD says "own GTM strategy for two new product lines", which she'd build with Sales Strategy, not instead of it. Never fold into "it's basically the same skill" | F8 is a stated gap in the interviewer's own domain, so in a peer conversation with a Sales Strategy director it's near-certain. Tagged JD because it scores fit for a GTM role that sits beside Sales. It gets the deepest rehearsal: drill it first |
| C2 | "We sell B2B data infrastructure. Where in your background have you worked with enterprise buyers?" | JD | [inferred] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" | State the background in the quote's own words: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Answer slot: the role's "B2B data-infrastructure SaaS" line makes this probe likely. If a consulting project or consumer-tech work dealt with business or enterprise buyers, she says which and what she did, in her own words. If none did, she says so plainly and stays with what the work was. Don't recast carriers as enterprise customers. The model was "used in carrier negotiations"; describe that relationship as what it was | F7 is the background mismatch a Skeptic reaches for. Tagged JD because it scores fit to the company's market, taken from your role summary. `[inferred]` because F7's gap is a derivation from silence |
| C3 | "Partner-motion design is a hard requirement here. Walk me through the partner work you've done." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: say what the model covered, what it was used to decide, and which parts were hers, in her own words. If a part wasn't hers, she says so plainly and stays with the model. Then, as a plan for Northwind and not as a past: how she'd design a partner motion for a new line (partner type, value exchange, economics, who sells and who supports). Through the follow-ups, the model stays a model. Never relabel it a motion | F4 is the JD's only "required" line, and the evidence is adjacent. Tagged JD because it scores that requirement directly. Second only to C1 in prep priority |

### D. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor starts bundling a good-enough version of one of our new products. What do you do in GTM: pricing, packaging, partners?" | CASE | [grounded] | Clarify first: which product, which segment, and whether the bundle is actually losing deals. Ask for win-loss data before reacting. Objective: defend share without breaking the profitability goal. Segment: new logos versus the installed base. Options: package it into enterprise-expansion deals rather than selling it standalone; price on the value the bundle can't match rather than racing to zero; partner with vendors who also compete with the platform. Metrics: win rate against the bundle, attach rate, discount depth. Risks: margin erosion and channel conflict. Challenge one premise: whether "bundled" means free once switching costs are counted. The question asks nothing about her past | Built on your research note's bundling threat and profitability priority. Tagged CASE with CO content, and tilted to pricing and packaging because that is Dan's career spine. `[grounded]` in your note, which web search could not confirm in this session |
| D2 | "Suppose Compass, our AI copilot, were one of your two lines. Sketch year one across land, adopt, expand and renew. What do you need to know first?" | CASE | [grounded] | Clarify: is it sold standalone, as an add-on or included; who buys; what usage data exists. Objective: tie it to enterprise expansion and profitability. Land: which customers first, and why. Adopt: what usage proves value. Expand: seat, usage or tier triggers. Renew: the churn signal to watch. One metric and one risk per stage. Name the monetization choice she'd test first. Claim no AI product experience; G2 holds her real AI answer | Grounded in your note's Compass launch and the JD's land/adopt/expand/renew line (F2's requirement). Framed as "suppose" because nothing supplied says Compass is one of the two lines. Tagged CASE because it scores live structure on the real roadmap |
| D3 | "We have two new lines and a profitability target. How do you decide which one goes partner-led first and which goes direct?" | CASE | [grounded] | Clarify: the two products, deal sizes, sales cycle and implementation burden. Criteria: unit economics per channel (partner margin against direct cost of sale); partner reach into segments the direct team can't reach; how much services the product needs; conflict with the direct team. Lay it out as a small scoring table, pick one, and say what would flip the decision. The question asks nothing about her past | Turns the JD's required partner-motion line (F4's requirement) and your note's profitability priority into a live decision. Tagged CASE. The unit-economics framing is native to a pricing-and-monetization interviewer |

### E. Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then restate the question. Hold on the quote: "I proposed the store-surface change, and it was credited with about $400M in ARR uplift." Follow-up 1: hold the same words, calmly. Follow-up 2: concede something specific. Answer slot: in her own words, what others did to build, ship or measure it, and who did the crediting, if she knows. If she doesn't know how the attribution was made, she says so. If she did propose it, don't fold to "it was a team thing", and never grow it into "I drove it" | A persona stem aimed at F5's headline figure. Tagged EXP because it scores attribution under pressure. Same claim as A1 and B4, so she meets it in three registers before the interview |
| E2 | "Sixty seconds: why you over someone from my team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" "No classic sales-ops or quota-setting experience." | Sixty seconds, three beats. What she brings, in the quotes' words: a partner-level revenue model used in carrier negotiations; annual volume targets set with cross-org consensus; her own SQL and Tableau. What she doesn't bring, said plainly: "I haven't done classic sales-ops or quota-setting." Why that mix suits GTM for new product lines, given as her view, not as proof. Stop at sixty seconds | A time-boxed C1 drawing on F3, F4, F5 and F8. Tagged JD because it scores fit to the role's requirements |

### G. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc in the quote's order: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Answer slot: why this move, and why now, in her own words. Nothing in her material says this yet, so she should script it before the interview. End on a question back to Dan | Casual openers are scored, and a peer listens for economy and a consistent motivation. Tagged EXP because it scores the career story as told (F7's quote) |
| G2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Treat it as scored: AI is the JD's plus, and Compass is a company priority per your note. Answer slot: name the tools and what she uses them for, in her own words. That is the whole claim. Then turn it around and ask Dan how Compass is being packaged, if that's been decided | F6 asked casually. Tagged JD because it scores the stated plus. `[inferred]` to match F6's low band |

### H. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time she told senior people something they didn't want to hear. It needs a named stake, what she said, and how it landed, with the relationship intact. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she'd handle it | A persona stem. No Northwind values were in hand, so values coverage stays generic. Tagged VAL because it scores behavior, not credentials |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision where a customer's interest beat a number she or her team was measured on, and what it cost. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she'd handle it | A persona stem. Data-driven interviewers often test whether metrics ever lose. Tagged VAL because it scores judgment, not homework |

---

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1: own GTM strategy for two new product lines | C1, D2, D3, E2 |
| F2: whitespace across land/adopt/expand/renew | A4, D2 |
| F3: independent analysis in SQL and Tableau | A3, B3, E2 |
| F4: partner-motion design (required) | C3, A2, D3 |
| F5: strong cross-functional influence | B1, B2, A5, B4 |
| F6: AI experience (plus) | G2, D2 |
| F7: B2B data-infrastructure context | C2 |
| F8: sales-strategy and quota fluency | C1, E2 |
| Company priorities from your note (enterprise expansion, Compass, profitability, bundling) | D1, D2, D3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization. How does pricing for a new product line get decided here, and where does your team come in?" | It's tied to Dan's own path, and the answer shows her where the seam actually sits |
| R2 | "What from your startup chapter shows up in how you run sales strategy at a company this size?" | It's tied to Dan's path, and it turns their likely scrappiness skepticism into a peer conversation |
| R3 | "What could someone in this role do in the first month that would genuinely help your team?" | The reciprocity question. It tells a peer she's thinking about their load, not just her own |
| R4 | "Where does the bundling pressure show up in your data today, if it does?" | It speaks Dan's data-first language, and it tests the threat in your note rather than assuming it |
| R5 | "How is Compass expected to show up in the expansion number, and who owns that forecast?" | It joins two of the stated priorities and surfaces a possible seam before she's in it |
| R6 | "When Emerging Products and Sales Strategy disagree, how does the VP like it brought to them?" | It's practical diligence about their shared manager, and it shows she plans to settle disagreements with Dan, not around them |

---

## Prohibited claims

Things this pack won't coach. The list was built locally from the fit snapshot, since there was no dossier.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, delivered or owned the $400M ARR | Inflated form of F5's second quote | The quote at its own scope: proposed, and credited with. The limit is the pack's observation: her material says she proposed the change, not that she delivered the uplift. A1, B4 and E1 stay inside that |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The pack's observation: her material says a model, not a motion. C3's slot asks only what the model covered and which parts were hers. Designing one is coached only as a future plan |
| Led or ran the carrier negotiations | Inflated form of F4 ("used in") | F4's quote. A2's slot asks for her part, with an honest branch if she wasn't in the room |
| Owned GTM for a product line | Inflated form of F1 | F1's quote: product strategy and ops. The pack's observation: her material says product strategy and ops, not GTM ownership |
| Has set quotas or done sales ops; volume targets are quotas | Negative the coach's notes state, F8 | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting." No slot |
| AI product or AI GTM experience | Inflated form of F6 | F6's quote: she uses AI tools daily. G2's slot asks only which tools and what for |

---

## Sources

**Provided:** your message, covering the role summary, JD highlights, the candidate description (the coach's notes), the interviewer description, and your research note on priorities and the competitive threat. No dossier was present.

**Searches sent, all refused** (web search permission wasn't granted in this session):

- `"Northwind Data" company values`: refused
- `"Northwind Data" interview process strategy role`: refused
- `"Northwind Data" Compass AI copilot launch`: refused
- `"Dan Kovac" "Northwind Data"`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The one call was refused. Official values would have themed the H bank. There's no values round in this session, so no cheat sheet either way |
| 2. `Northwind Data interview process`, strategy roles | unavailable | The one call was refused. It would have shown whether Northwind runs case-style peer conversations. Your message already sets this session's structure |
| 3. `Northwind Data strategy` / recent news | unavailable | The one call was refused. It would have checked how current your note is and added recent moves. Until then, D1 to D3 and R4 to R5 rest on your note alone |
| 4. `Dan Kovac Northwind Data` | unavailable | The one call was refused. It would have checked the profile you described and surfaced talks or posts to theme questions. The interviewer read rests on your message |
| 5. representative `GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** F1 to F6 would quote the posting itself, and any mid-list requirement the highlights left out gets its own row and question.
- **Priya's CV:** evidence cells in her own words. Story beats in A1, A2, A5 and B2 get firmer, and F7 may resolve one way or the other.
- **Web search permission:** reruns L1 targets 1 to 4. That confirms the strategy behind D1 to D3, checks Dan's public footprint, and replaces the H bank's generic themes with published values if Northwind has them.
- **A deeper research pass (L2):** up to 6 more searches and 2 more fetches, several more minutes. Adds a grounding brief on Compass, the bundling vendor and recent org context, so the D bank can use Northwind's own vocabulary.
- **Priya's own answers to the answer slots:** her counting method for the $400M figure (A1, E1), the model's structure and her part in it (A2, C3), any enterprise-buyer work (C2), and her why-now (G1). Each one turns a slot into a quoted, story-mapped row.
- **Recruiter or VP guidance:** if a case, a POV or a whiteboard exercise is expected, it gets its own build section.
- **Prep time available:** a prioritized schedule. Until then, start with C1, C3, A1 and A2.
- **A `tuesday-dossier.md`:** the highest-ROI objection would come from confirmed evidence rather than being inferred, and the prohibited list would carry confirmed boundaries.
