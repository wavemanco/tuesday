Building your prep pack now. First, a quick public-web check on Atlas Freight's values, interview process and recent news.
Using Edit instead.
Your prep pack is saved as `AtlasFreight_operations-manager_interview_pack.md`. You didn't say who you're meeting, so I gave every interviewer style equal weight. It has 22 practice questions, each with answer guidance built only from what you told me.

**What to rehearse first:**
- **A1, the most valuable to practise.** "Today you manage three supervisors. This role is twelve, across four sites. Why are you ready?" Some version of this will come up. Admit the jump before they raise it, then point to what you've actually done.
- **A4, Power BI.** Start with "I haven't used Power BI," then give your plan to learn it. Don't half-claim it.
- **A2, the 5+ years of leadership.** You have 7 years in ops, but you didn't say how many of those you've been managing people. Give the real number and don't round up.
- **C1 and D2, your 40% mis-pick cut.** Be ready to say how it was measured, the weakest assumption behind it, and which part was yours.
- **B1 and B2, live problems.** One is diagnosing an on-time drop, the other is rising cost per shipment. Those are the two numbers this job is judged on, and nothing you've told me covers them yet.

I couldn't look Atlas Freight up because web search wasn't allowed. So the "why Atlas" and case questions are general rather than about the company itself.

Say the word and I'll play the skeptical interviewer on A1.
I can also save a `tuesday-dossier.md` that records the gaps this prep found, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting: the hiring manager, a regional director, HR, a peer or a panel? And has the recruiter mentioned focus areas or anything to prepare, like a case or presentation? That changes which questions get the most weight.
2. Do you want me to research Atlas Freight? I can do the standard pass that was blocked, or a deeper one with up to 6 more searches and 2 more page reads, which takes several more minutes. Either way, web search needs to be allowed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: AtlasFreight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known. Round type: not known.
**Built on:** your pasted JD and the background in your message. No CV, no interviewer, no company research.

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what* is being scored. The same content can come at you as a friendly aside or a time-boxed challenge, so rehearse both the content and the delivery.
- **Type key:**
  - **VAL**: behavioral or values: does your past behavior show the values they care about
  - **EXP**: experience deep-dive: does what you said survive scrutiny, and what exactly was yours
  - **JD**: role-driven: can you do the listed job, including its gaps
  - **CO**: company knowledge: why this company, and how well you understand it
  - **CASE**: a live problem from the role, solved out loud
- **Provenance labels:** `[grounded]` traces to your JD or your own words; `[inferred]` is this pack's derivation, with its source named; `[generic]` is a role-family pattern with no claim about Atlas or about you.
- **Answer slots** are instructions for the interview, not questions for me. Each one has two honest branches. Pick the one that is true.
- Guidance is scaffolding, not a script. Say it in your own words.
- Question banks use letters A, B, C, D, E, G and H. F is skipped so bank IDs never clash with fit-snapshot rows (F1 to F8).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution operations and the site's surge plan. It does not show terminals or more than one site, and the words stay at that scope: "I've spent seven years in warehouse and distribution operations, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on how much of that plan was yours likely. If parts of the surge plan were yours to set rather than to carry out, say which and how you decided, in your own words. If none were, say so plainly and stay with how you ran it |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Strong evidence here is an on-time measure you tracked or moved, with how it was counted and what part was yours. Answer slot: the JD's on-time line makes this probe likely. If you have tracked or moved an on-time measure, say which one, how it was counted and what part was yours, in your own words. If you have not, say so plainly and say what you would measure first |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Strong evidence here is a cost measure you tracked or moved, with how it was counted and what part was yours. Answer slot: the JD's cost-per-shipment line makes this probe likely. If you have tracked or moved a cost measure, say which one and how, in your own words. If you have not, say so plainly and say how you would break the number down first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve, and the words stay at that scope: "Today I'm a senior shift manager over three supervisors." Answer slot: the JD's twelve-supervisor line makes a probe on how you lead supervisors likely. Say how you work with your three today, in your own words. If a practice the interviewer names isn't one you use, say so plainly and describe what you do instead |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | medium | [grounded] | discovery | "Solid Excel" touches the requirement but doesn't show that you have built reporting. Answer slot: if you have built reports in Excel, say what they tracked, who used them and how often, in your own words. If you have not, say so plainly and describe how you do use Excel |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap that wording can't close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material shows seven years in operations and a current leadership role. It does not show how many of those years were in leadership. Answer slot: give the actual number of years you have had people reporting to you. If it is five or more, say so and name the roles. If it is fewer, say the number plainly, don't round it up, and stay with the seven years in operations |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead with it in your words: "I'm green belt certified." Name the certification exactly as your certificate states it. Answer slot: the JD's Lean/Six Sigma line makes a probe on where you have applied it likely. If you have used the training on a piece of work, name the work and what you did, in your own words. If you haven't yet, say so plainly and stay with the certification |

---

## Persona table

No round type, interviewer or loop source was available, so the weights use the **Generic archetype** (screen, then hiring manager, then panel) and are **flat**. They rest on a pattern, not on Atlas Freight's documented process. Tell me who you are meeting and these get reweighted.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet pressure on the jumps: three supervisors to twelve, one site's plan to four sites, warehouse to terminal, Power BI | Flat, with one extra question, because the fit snapshot's biggest gaps (F1, F4, F6, F7) feed this bank and the highest-ROI objection lives here | Rehearse A1 until it's boring. Concede the size of the jump before it's raised. Bridge only from what you actually said, and say the limit plainly |
| Case / Strategist (bank B) | Live problems from the JD: an on-time drop, rising cost per shipment, a first-90-days plan | Flat. Typical of whoever owns the role, but the round type isn't known | Clarify, objective, segment, approach, metrics, risks. Think out loud. Challenge one premise respectfully |
| Data-Driven Prober (bank C) | Line-by-line on your 40% figure and your Excel reporting | Flat. Your one headline number makes this persona's questions predictable in any round | Know what you can and can't say about how the 40% was counted. Name the weakest assumption before they do |
| Pressure (bank D) | Time-boxed "why you", "how much was you" | Flat. The fit snapshot's gaps feed this bank too | Pause, restate, anchor on what you said, and hold through two follow-ups before conceding anything real |
| Conversational (bank E) | Friendly openers: your journey, why Atlas, green belt asked casually | Flat. Most rounds open this way, and the casual questions still count | A pre-built 90-second arc. Treat casual questions on JD topics as scored |
| Values / Behavioral (bank G) | Tell-me-about-a-time stories on leading supervisors and running a plan under pressure | Flat. The Generic archetype assumes no values round, and no published Atlas values were in hand, so this bank is generic | Pick stories with a named stake. "We" for context, "I" for contribution |
| Peer Evaluator (bank H) | Another site or ops lead probing where your area meets theirs | Flat. The Generic archetype ends in a panel, which may include a peer | Reciprocity: what you'd bring their site. Propose principles for where your work meets theirs, not claims about it |

---

## Question banks

**Highest-ROI prep in this pack: A1.** Some version of "three supervisors to twelve across four sites" is close to certain to come up, and a calm, rehearsed, non-defensive answer changes the interview.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Today you manage three supervisors. This role is twelve, across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | **Highest-ROI rehearsal.** Name the limit first, before they do: "Twelve across four sites is a bigger span than the three I lead today." Then hold on only what the quotes carry: "Today I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: if parts of that surge plan were yours to set, say which and how you decided. If none were, say so plainly and describe how you ran it. Close with how you'd approach the first 90 days with twelve supervisors, said as a plan and never as a past. Hold through two follow-ups by going back to those two facts, never by adding to them | F4 and F1 are the widest gaps between the JD and your material, so this objection will arrive in some form. JD because it scores the stated span directly |
| A2 | "The JD asks for five-plus years of operations leadership. How many of your seven years were in leadership?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Answer slot: give the actual number of years you've had people reporting to you. If it's five or more, say so and name the roles. If it's fewer, say the number plainly, don't round up, and go back to the seven years in warehouse and distribution operations and your current role over three supervisors | F7 is a stated requirement your material doesn't settle, so expect it to be checked. JD because it scores the stated requirement |
| A3 | "Our sites are terminals, not warehouses. What carries over, and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what you have run, in the quote's own terms: seven years in warehouse and distribution operations. Answer slot: the JD's terminal line makes a probe on freight flow likely. If any of your work involved dock scheduling or freight moving between carriers, say what, in your own words. If none did, say so plainly and name what you would need to learn first, as a plan | F1's terminal-versus-warehouse difference is the second seam a skeptic pulls on. The question's premise is the JD's terminals, and the guidance doesn't adopt anything beyond your quote |
| A4 | "Reporting here is in Power BI. Where are you with it?" | JD | [grounded] "solid Excel" "never used Power BI" | Plain and first: "I haven't used Power BI." Then: "My Excel is solid." Then how you would get up to speed, as a plan. Answer slot: if you start learning it before the interview, say exactly what you did. If you haven't, say how you will. Don't soften the first sentence | F6 is a gap you stated, so the honest line is ready-made. Rehearsing it stops a nervous half-claim. JD because Power BI is named in the role |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our terminals dropped last month. Walk me through how you'd diagnose it." | CASE, JD | [generic] | Clarify first: which on-time measure, how it's counted, which lanes or customers, when it started. Then segment where time is lost: inbound arrival, dock and sort, departure, carrier. Ask what data exists, form two or three hypotheses, test the cheapest one first, and say how you'd know the fix worked. The question needs no claim about your past, so the guidance makes none | Live problem on F2's requirement. Asked as reasoning, not as a record. Generic because no Atlas data was available |
| B2 | "Cost per shipment is up across the four sites. Where do you look first?" | CASE, JD | [generic] | Define the number: what's in the cost and what counts as a shipment. Split it into the big buckets (labor and overtime, linehaul, equipment, damage and claims) and compare sites to find where the gap sits. Pick one lever, say what you'd measure, and name the risk to on-time performance from cutting cost. No claim about your past | Live problem on F3's requirement. The trade-off with on-time is what a strong answer names |
| B3 | "It's your first 90 days with twelve supervisors across four sites. What's the plan?" | CASE | [generic] | Structure it: listen first (each site, each supervisor), baseline the JD's two metrics, set one shared daily report, pick one site for a first improvement, then roll out what works. Say what you'd *not* change early. All of this is a plan, never a past | Tests F1 and F4 as forward reasoning, the honest way to show readiness for a span your material doesn't yet show |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40%. How was that counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Four things in your own words, none supplied by this pack: how the figure was counted (mis-picks over what, over which periods); what it's sensitive to; the assumption behind it you'd defend least, said before they ask; and which part was yours. If you don't know how it was counted, say so plainly. That's an honest answer, not a failure. Keep the 40% attached to mis-pick rate, never to errors or costs in general | Your one headline number from F1's evidence. Probers aim at numbers first. EXP because it tests whether the claim survives scrutiny |
| C2 | "Tell me about the pick-path redesign. What did you change?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on the quote: the redesign and the mis-pick result. Tell what the change was in your own words. Answer slot: if others worked on the redesign, say who did what and which part was yours. If it was yours alone, say so | Behind C1's number sits the work. A prober will ask about both. EXP because it tests attribution |
| C3 | "What reporting have you built in Excel, and who used it?" | JD | [grounded] "solid Excel" | Answer slot: if you've built reports, say what they tracked, who used them and how often, in your own words. If you haven't, say so plainly and describe how you do use Excel. Don't describe a report you didn't build | F5 is a JD requirement your material touches but doesn't show. JD because building reporting is a listed duty |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" | Pause, then three beats in your words from the quotes: seven years in warehouse and distribution operations; the site's surge plan two years running; the 40% mis-pick reduction from redesigning the pick path. Concede the real point: an internal candidate already knows the terminals. Hold the rest through two follow-ups | Pressure tests composure on F1's evidence. Rehearsing the concession keeps it from sounding like a retreat |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede specifically. Answer slot: say exactly which part of the redesign was yours and which was others', in your own words. If it was yours alone, say so. Never take a bigger share to win the moment, and never fold on what was yours to restore harmony | The persona's stock attribution probe aimed at F1's number. Hold-then-concede is the bar |
| D3 | "Have you actually moved on-time performance or cost per shipment, or would this be new?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot, both measures: if you've moved one, say which, how it was counted and what part was yours. If you haven't, say so plainly, then go back to the 40% mis-pick rate cut from redesigning the pick path, and to how you'd approach these two (B1, B2) | F2 and F3 are the JD's headline metrics and your material says nothing on them, so a blunt version is likely. Rehearsing both branches removes the freeze |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | A 90-second arc from those five facts, in order, in your own words. Answer slot for the ending: say why this role and why now in your own words. That reason isn't in your material, so the pack doesn't supply it | Almost every round opens here. A crisp arc sets the frame for every later question |
| E2 | "Why Atlas Freight?" | CO | [generic] | Selection scaffold: one real reason you're looking, and one specific thing about Atlas or this role you have checked yourself, such as something in the JD or on their own site. If you have nothing specific about Atlas, say what in the JD draws you rather than inventing company facts | No company research ran, so this stays generic. A CO answer built on a fact you invented falls apart on one follow-up |
| E3 | "Green belt — where has it actually shown up in your work?" | JD | [grounded] "green belt certified" | Name the certification as your certificate states it. Answer slot: if you've used the training on a piece of work, name the work and what you did with it, in your own words. If you haven't yet, say so plainly and say where you'd apply it here. Don't link it to the pick-path redesign unless that's true | F8 is the JD's plus-skill, and the casual register is where plus-skills get tested. JD because Lean/Six Sigma is listed |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to hold a supervisor accountable for performance." | VAL | [generic] | Selection scaffold: pick a time with a named problem, what you said and did, and where the relationship ended up. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing you have or how you'd handle it | Theme from the JD's twelve-supervisor line (F4). Generic because no Atlas values were in hand |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a specific message, who heard it, and what happened next. Pick one where the point actually landed. If none did, say so rather than supplying an ending. If no such time comes to mind, say so plainly and say how you would handle it | The persona's standard stem. Ops managers sit between the sites and leadership, so it's a likely theme |
| G3 | "Walk me through running the peak-season surge plan." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on the quote: the site's plan, run two years running. Those are the beats it states, so tell them in your own words. Answer slot: the JD's "own daily terminal operations" makes a probe on ownership likely. If parts of the plan were yours to design rather than to carry out, say which. If it was handed to you, say so plainly and describe how you ran it | F1's strongest evidence for running operations under pressure. EXP because it tests what was actually yours |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When your terminal and mine compete for the same drivers or dock time, how do we settle it?" | CASE | [generic] | Propose principles, not claims about their setup: agree the shared metric first, settle it by data rather than by who shouts loudest, raise it early, and escalate together. Ask what happens today | Tests partnership fit across F1's four sites. Generic because Atlas's structure isn't known |
| H2 | "How do you handle credit when an improvement spans shifts or teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | If you use the pick-path redesign: answer slot. If others contributed, name who and what, then what was yours. If it was yours alone, say so and say how you'd handle a shared one. Or pick a different story using G1's scaffold | Peers probe credit-sharing directly. It ties back to D2's attribution question |
| H3 | "What would you need from the other site managers in your first month?" | CASE | [generic] | Reciprocity first: what you'd bring them, then what you'd need. Keep the asks small and specific, like an hour on each site's floor and their view of the two JD metrics | A peer is pricing whether you add to or reduce their load |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites (F1) | A1, A3, B3, D1, G3, H1 |
| Drive on-time performance (F2) | B1, D3 |
| Cost-per-shipment down (F3) | B2, D3 |
| Lead a team of 12 supervisors (F4) | A1, B3, G1 |
| Build reporting in Excel (F5) | C3 |
| Build reporting in Power BI (F6) | A4 |
| 5+ years operations leadership required (F7) | A2 |
| Lean/Six Sigma a plus (F8) | E3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and where does it stand?" | Starts with the JD's headline metric and shows you ask how a number is counted before you try to move it |
| R2 | "Of the four sites, which needs the most attention right now, and why?" | Gets you the real job behind the JD and shows you're already thinking site by site |
| R3 | "How are the twelve supervisors spread across the sites, and how do they work together today?" | Goes straight to F4's span, the thing they're most likely weighing, and shows you're planning for it |
| R4 | "What reporting exists today in Excel and Power BI, and what's missing?" | Turns F6 into a forward-looking build conversation rather than a gap |
| R5 | "What would make the first six months a clear success for you?" | Gives you their scoring sheet in their own words |
| R6 | "What are the next steps in the process after today?" | Practical, and tells you what to prepare for next |

---

## Prohibited claims

What this pack won't coach, and why. Built from the fit snapshot before any question was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations | Inflated form of F1 | F1's quote at its own scope: "7 years in warehouse and distribution ops". The limit is the pack's observation: your material says warehouse and distribution, not terminals. A3's slot stays inside your own work |
| Ran operations across multiple sites | Inflated form of F1 | F1's quote at its own scope: "ran the site's peak-season surge plan two years running". The material says the site, singular. A1's and G3's slots stay inside the surge plan |
| Led a dozen supervisors | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors" |
| Seven years of operations leadership | Inflated form of F1 and F7 | "7 years in warehouse and distribution ops" at its own scope. Years of leadership are A2's slot, in your actual number |
| Cut errors or costs by 40% | Inflated form of F1 | "cut mis-pick rate 40% by redesigning the pick path". The 40% stays attached to mis-pick rate |
| Has used or built reports in Power BI | Negative you stated, F6 | "I haven't used Power BI." No slot |

---

## Sources

- **Provided:** the job description and your background, both pasted in your message.
- **Searches sent:**
  - "Atlas Freight regional logistics company values": refused (web search not permitted in this session)
  - "Atlas Freight interview process operations manager": refused
  - "Atlas Freight logistics news 2026": refused
- **Fetches:** none.
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The one search was refused. It would have themed bank G with Atlas's published values, and with a values round confirmed, added a values cheat sheet |
| 2. Atlas Freight interview process, operations | unavailable | The one search was refused. It would have replaced the Generic-archetype flat weights with Atlas's documented rounds |
| 3. Atlas Freight strategy and recent news | unavailable | The one search was refused. It would have grounded B1, B2 and E2 in Atlas's current priorities instead of `[generic]` patterns |
| 4. Interviewer public footprint | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

---

## Upgrade menu

- **Round type and who you're meeting** (hiring manager, peer, regional director, HR, panel) → persona weights move from flat to relationship-based, and the banks resize around the personas that actually dominate
- **The interviewer's name** → an interviewer read from their public professional profile, and a reverse question tied to their own path
- **Any recruiter prep note** (focus areas, a case or presentation to prepare, the number of rounds) → a build section for any declared deliverable, and coverage aimed at their stated focus
- **Web research allowed** → Atlas's published values, interview process and recent news. B1, B2 and E2 become company-specific, and the loop is read from their process rather than a pattern
- **Your CV or résumé** → more of your own sentences to quote, which can turn F2, F3 and F5 from `none given` into evidence rows
- **Your answers to the answer slots** (years leading people, any on-time or cost measure you've tracked, Excel reports you've built) → F2, F3, F5 and F7 regenerate with your words quoted, along with A2, C3 and D3
- **One inspectable artifact** (a shift or site KPI report you built, the before-and-after mis-pick figures, your green belt certificate) → F1, F5 and F8 can rise from `medium` to `high`
- **A tuesday-dossier.md** → verified evidence, a prohibited-claims list carried over from an earlier session, and a highest-ROI objection drawn from evidence rather than inferred
