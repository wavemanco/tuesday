No dossier present. Reading the module's required references.
I've built one prep pack for all three rounds. It treats the role summary you pasted as the job description and your message as your background. I tried three web searches on Larkfield's values, interview process and recent news, and all three were refused in this session. So nothing in the pack about the company comes from research, and those parts are marked as generic.

The pack starts with one shared table matching each line of the role to what you told me. Then there's a section per round: 12 questions for Tuesday, 12 for Thursday and 8 for Monday, each with answer guidance and reverse questions. It ends with a list of claims the pack won't coach.

**What matters most:**

- **Practise question A1 more than anything else.** The question is "You've led a team of six; this is two squads, eleven engineers and hardware in the roadmap. Why are you ready?" Some version of it is almost certain on Tuesday. The pack has you hold on what you've actually done, then say "I haven't owned a hardware-adjacent roadmap" before they raise it, then give a 90-day plan.
- **Keep the 60% claim exactly as you told it:** your team's "on-call burden dropped 60% *after*" you pushed the reliability quarter through. Expect the staff engineers on Thursday to ask how it was counted, which assumption behind it is weakest, and which part was yours. Don't let it turn into "cut incidents by 60%" or "because of me".
- **Find out early whether the squads have managers.** The role text doesn't say if you'd be managing managers. A-R1, a question to ask on Tuesday, settles it, and the answer changes how much your gap there matters.
- **Monday has no list of Larkfield's values to prepare against.** The recruiter called it a "values and leadership philosophy" round, but I couldn't look up the company's published values. The values questions are built from the recruiter's wording and common stems, and the one on industry direction (M1) is generic until you do some reading of your own.

Files are in the working directory:
- `Larkfield-Systems_engineering-manager_interview_pack.md`

If you want to rehearse, I'll play the would-be boss on Tuesday's A1 and follow up on your answers.
I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Can you paste the full job posting and your CV? Either one adds rows to the shared table and turns several practice outlines into answers built on your own experience. If you'd rather not, the pack stands as it is.
2. Web searches were refused here. If you allow them, I'll fill in Larkfield's values and strategy. I can also run a deeper research pass: up to 6 more searches and 2 page reads, several more minutes. Do you want either?
3. Would the two staff engineers on Thursday's panel work in the squads you'd lead? The answer changes how Thursday's questions are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Loop (three scheduled rounds):**

- **Round 1, Tuesday:** 45 min with the hiring manager, a Director of Engineering (your would-be manager)
- **Round 2, the Thursday after:** 60-min panel, two staff engineers and a product manager
- **Round 3, the following Monday:** 30 min with the VP Engineering, described by the recruiter as 'values and leadership philosophy'

**Built from:** the role summary you pasted, which this pack treats as the JD, and the background in your message. Web research was attempted and refused in this session, so nothing here about Larkfield's values, strategy or process comes from research (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question gets asked. **Types** describe *what is being scored*.
- **Type key:**
  - **VAL**: behavioral or values alignment. Does your past behavior show the values they care about?
  - **EXP**: work-experience deep-dive. Do your claims survive scrutiny, and what was actually you?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. Can you think at Larkfield's altitude?
  - **CASE**: a live problem from the role. They score your structure and reasoning.
- **Provenance labels:**
  - `[grounded]` means traceable to your own words or the role text.
  - `[inferred]` means derived, with the derivation named.
  - `[generic]` means a role-family pattern with no claim about you or Larkfield.
- **IDs:**
  - Fit-snapshot rows are F1 to F7.
  - Questions run A to D (Round 1), E, G, H and J (Round 2), and K, L and M (Round 3). F and I are skipped so they can't be confused with fit rows.
- **Answer slots** are instructions for your answer in the room. They say "if you did this, say how; if not, say so plainly". Either branch is a good answer. The slot exists so you never have to improvise a practice you didn't have.
- **Guidance is scaffolding, not a script.** Say it in your own words, and say only what you actually did.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads of eleven, and the words stay there: "For three years I've been team lead of a team of six." Answer slot: the two-squads line makes a probe likely on leading more than one team, or leading through tech leads. If you have done any of that, say what and how, in your own words. If you haven't, say so plainly and stay with the team of six. Only if you're asked whether you've managed managers: "I haven't managed managers." The role text doesn't say whether these squads have managers, so ask (reverse question A-R1) |
| F2 | "building device-management services" — role text | none given | none | [grounded] | discovery | Your material doesn't show device-management work either way. Answer slot: if any of your work has touched managing devices, say what, in your own words. If none has, say so plainly and say what you would learn first and how |
| F3 | "own delivery, hiring and growth for 11 engineers" (delivery) — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | discovery | The quote shows you got a reliability quarter onto the plan against pressure. It doesn't show how delivery for your team was run. Answer slot: the "own delivery" line makes a probe likely on how you run delivery. If your team's planning and shipping commitments were yours to run, say how, in your own words. If they sat with someone else, say so plainly and stay with the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (hiring) — role text | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Running a loop is adjacent to owning hiring, and the words stay at the loop: "I run our hiring loop for backend roles, about 40 interviews last year." Answer slot: "own … hiring" makes a probe likely on who made the hire decision. If the decision or the offer was yours, say how you made it. If it wasn't, or the loop had no such step, say so plainly and stay with running the loop. "About 40 interviews" can be read two ways, as yours or the loop's, so say which in your own words |
| F5 | "own delivery, hiring and growth for 11 engineers" (growth) — role text | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: the growth line makes a probe likely on how you've grown people. If you have, pick one person and say what changed and what part was yours, in your own words. If not, say so plainly and say how you would approach it |
| F6 | "partner with hardware and product on roadmap" (hardware) — role text | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so. Words: "I haven't owned a hardware-adjacent roadmap." Then say how you would learn to partner with hardware, as a plan and never as a past. Don't claim hardware roadmap work, and don't add anything that makes the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" (product) — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Pushing a quarter through against roadmap pressure is adjacent to partnering on a roadmap, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the partnering line makes a probe likely on whom you worked it out with. If you worked it through with a product partner, say how and how the relationship came out. If the pressure came from somewhere else, or there was no negotiation, say so plainly and stay with the quarter |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "Lead two squads building device-management services" | A1, A4, B1, E1, M2 |
| "own delivery" | B1, B2, B3, M2 |
| "hiring … for 11 engineers" | B4, G3 |
| "growth for 11 engineers" | H3, K4 |
| "partner with hardware and product on roadmap" | A1, A2, B2, E3, E4, M2 |
| 'values and leadership philosophy' — recruiter | K1, K2, K3, K4, H1, H2 |

---

# Round 1 — Tuesday: hiring manager (Director of Engineering), 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probes on the jump from one team of six to two squads of eleven, and on hardware | High. Hiring-manager rounds lean Case plus Skeptic by default. F1 and F6 are the snapshot's biggest gaps, and a manager hiring a direct report checks those first | Rehearse A1 until it's boring. Bridge only from F1's quote and F6's stated negative, then give a concrete ramp plan |
| Case / Strategist | Live problems from the role: inheriting two squads, a hardware slip, reliability against the roadmap, hiring | High. The other hiring-manager default. The role text's delivery and roadmap lines turn naturally into scenarios | Clarify, then objective, approach, metrics and risks. Think aloud, and challenge one premise respectfully |
| Data-Driven Prober | One pass at your 60% figure | Medium. It's the headline number in your material, and a future manager will test it at least once | Know how it was counted, or say plainly that you don't. Name your weakest assumption first |
| Conversational | The opener, plus "what do you want from a manager" | Low to medium. Openers are scored even when they feel casual | A pre-built 90-second arc |
| Pressure, Values, Peer | Lighter here | Low. Rounds 2 and 3 carry them | Covered in those mini-packs |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led a team of six. This role is two squads and eleven engineers, with hardware in the roadmap. Why are you ready for that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | **This is the highest-ROI rehearsal in the pack.** Hold only what the quotes carry: "I've been team lead of six for three years, at a payments company." Name the hardware limit before they do: "I haven't owned a hardware-adjacent roadmap." Answer slot: the two-squads line makes a probe likely on leading more than one team. If you've done any of that, say what and how, in your own words. If you haven't, say so plainly and stay with the team of six. Then give a ramp plan, said as a plan: how you'd learn the hardware calendar and how you'd set up two squads in your first 90 days. Hold through two follow-ups by coming back to the team of six and the plan. Concede the hardware gap specifically. Don't fold into "maybe I'm not ready." If they ask whether you've managed managers: "I haven't managed managers." | F1 and F6 are where the role text presses hardest on your material, so this objection will come in some form. JD because it scores the stated scope. Skeptic delivery because it tests honest self-assessment under a quiet push |
| A2 | "What would you be weakest at on day one in this job?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick a real gap, not a disguised strength. The honest one for this role is in your own words: "I haven't owned a hardware-adjacent roadmap." Follow it with what you'd do about it, said as a plan: whom you'd learn from, and how early you'd get into hardware planning. Stop there, and don't stack a second gap on top | F6. A standard Skeptic stem, and the role's hardware line makes this the natural place to test candor |
| A3 | "Why leave payments, and why industrial IoT now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your material gives no reason, so this is a selection scaffold. Give your actual reason in your own words. A strong answer names something about this role (the larger scope, devices), something about your stage after three years as a lead, and nothing negative about your current employer. If the honest answer is mostly scope, say that plainly | A Skeptic stem: why leave, why here, why now. A story that holds together across all three rounds matters more than a polished one. EXP because it tests motivation consistency |
| A4 | "Device management is a domain of its own. What do you bring to it?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Stay at the quote: nine years of engineering, currently at a payments company. Answer slot: if any of your work has touched managing devices, say what, in your own words. If none has, say so plainly and say what you'd learn first and how. Don't stretch payments work into device experience. Let the interviewer draw any parallel | F2 is a silence, not a stated gap. The role names device-management services, so expect it |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's your first 90 days with two squads you've just inherited. What do you do?" | CASE | [generic] | Clarify first: what's shipping, what's on fire, who the tech leads are, and the hardware calendar. Objective: earn trust and protect delivery while you learn. Approach: one-to-ones with all eleven, map commitments and on-call load, meet the hardware and product partners early. Then name the first two decisions you'd expect to make, and what would tell you you're wrong. No claims about your past are needed | A live problem from "Lead two squads". CASE because structure is what gets scored |
| B2 | "Hardware tells you a firmware release slips six weeks. Your services were built to ship with it, and product still wants the date. What do you do?" | CASE | [generic] | Clarify what actually depends on the firmware. Lay out options: decouple where you can, re-sequence, or move the date. Make clear who decides, and how you'd tell product and hardware together rather than separately. Say plainly that you'd lean on hardware for its constraints. That's an honest place to show how you'd partner without claiming you've done it | A live problem from "partner with hardware and product on roadmap" (F6, F7). It presupposes nothing about your past |
| B3 | "Roadmap pressure is high and on-call is climbing. How do you decide when to stop feature work for reliability?" | CASE, EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer with a decision rule: the signals you watch, the cost you weigh, how you make the case. Use the quarter as your one example, in the quote's terms: you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after it. Answer slot: "own delivery" makes a probe likely on how you made the case. If you made it with data or a proposal, say how, in your own words. If it was simpler than that, say so plainly and stay with the quarter | F3 is your strongest material for the delivery line. CASE content with EXP evidence. Keep "after"; don't upgrade it to "because" |
| B4 | "If we gave you three open roles, how would you run hiring for two squads?" | JD, CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure: define the bar with the team, run a structured loop, keep interviewers calibrated, close well. Anchor in the quote's terms: you run your hiring loop for backend roles, about 40 interviews last year. Answer slot: "own … hiring" makes a probe likely on who made the hire decision. If the decision or the offer was yours, say how you made it. If it wasn't, or there was no such step, say so plainly and stay with running the loop | F4 is adjacent evidence for "own … hiring". CASE delivery on JD content |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words: how the figure was counted, what it's sensitive to, which assumption behind it you'd defend least (say that one before they ask), and which part was yours. If you don't know exactly how it was counted, say so plainly. That's a credible answer. Keep the figure attached to "on-call burden" and keep "after" | The headline figure in F3. Every headline number gets a defend-the-number question |
| C2 | "How much of that drop was you, and how much was the team?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The quote gives you the push, and "we" for the result: the team's burden dropped after you pushed the quarter through. Answer slot: if any of the reliability work itself was yours, say which, in your own words. If it wasn't, say so plainly and stay with pushing the quarter through | F3's attribution seam. Rehearsing exact credit now is cheaper than finding it live |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc using the quote's beats: nine years of engineering, the last three as team lead of six, at a payments company now. Close with your own reason for this role. Anything between those beats is yours to add, from what you actually did | The opener sets the frame for A1. It's scored even when it feels casual |
| D2 | "What would you want from me as your manager?" | JD | [generic] | An honest preference in your own words. One that ties to this role, such as early access to hardware leadership or clear decision rights on the roadmap, shows you've thought about the job. No claim about your past is needed | Conversational and still scored. It also signals how you'd work with them |

### Reverse questions (Round 1)

| # | Question | Why it lands |
|---|---|---|
| A-R1 | "Do the two squads have tech leads or managers today, and would I be managing them?" | It settles whether managing managers is in scope, and it shapes your ramp plan in A1 |
| A-R2 | "What would success look like at six and twelve months?" | It turns the conversation toward outcomes you can plan against |
| A-R3 | "Where does the hardware–software seam hurt most right now?" | It shows you're already thinking about the hardest partnership in the role |
| A-R4 | "How are roadmap trade-offs between hardware, product and these squads decided today, and who has the final say?" | It goes straight at "partner with hardware and product on roadmap" |
| A-R5 | "What's the reliability and on-call picture for device-management services?" | It connects naturally to the one story you're strongest on |
| A-R6 | "Is this a new role or a backfill?" | It tells you what you'd inherit |

---

# Round 2 — Thursday: panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Staff engineers ask how you'd work with them. The PM asks how roadmap trade-offs get made | High. Panels blend each member's top two personas. Staff engineers read as peers by default, with the PM as a cross-functional partner. F7's product line and F6's hardware line make the seams the obvious topic | Reciprocity framing: what you bring them, not only what you need. Propose seam principles rather than claiming to know the seam |
| Data-Driven Prober | Staff engineers test your 60% and your hiring numbers | Medium to high. Peer default, doubled by two engineers | Precise attribution. Say "I don't know how it was counted" if that's true |
| Values / Behavioral | The PM asks for stories about saying no, about customers, about growing people | Medium. Cross-functional default | Use "we" for context and "I" for your contribution. Scaffold where your material has no story |
| Conversational | Light openers | Low. The PM's second default | Treat casual questions about devices as scored |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | (Staff engineer) "How hands-on will you be, and what do you need from us?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Reciprocity first. Say what you'd take off their plate (unblocking, hiring, shielding them from roadmap churn) and what you'd rely on them for (technical judgment, design calls). On being hands-on, describe how technical you are today, in your own words, starting from your nine years of engineering. Don't promise a level of coding you won't keep up | Staff engineers are pricing what you cost and add to their work. JD because "Lead two squads" raises how leadership splits with senior ICs |
| E2 | (Staff engineer) "Suppose we disagree with you on a technical direction. How does that play out?" | VAL | [generic] | Selection scaffold. Pick a time you disagreed with a senior engineer. It needs a real stake, how it was resolved, and the relationship intact afterwards. If no such time comes to mind, say so plainly, then say how you'd handle it: when you defer to their expertise, and when you hold | A Peer stem. It shows spine and tact together. VAL because it scores disagreement style |
| E3 | (PM) "Product wants features and you want a reliability quarter. How do we work that out together?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your one story, in the quote's terms: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: if the pressure came from a product partner, say how you worked it through and how the relationship came out. If it came from somewhere else, or there was no negotiation, say so plainly and stay with the quarter. Then give working principles for the future: a shared view of what on-call costs in features lost, and agreeing trade-offs early rather than at the deadline | F7. The PM is the person you'd make these trade-offs with, so expect the collegial version of B3 |
| E4 | (PM) "Hardware, product and your squads all have a say on the roadmap. Where's the seam, and how do you keep it from becoming a fight?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Propose principles, not experience: joint planning around hardware milestones, explicit dependencies, one named decision owner per trade-off. If they ask about your track record here: "I haven't owned a hardware-adjacent roadmap." Then ask how it works at Larkfield today. That's a genuine question, and a good one | F6. Peers reward seam principles and catch pretended knowledge of the seam |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | (Staff engineer) "Walk us through the reliability quarter. What did the work actually consist of?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Beats from the quote only: the quarter, pushed through against roadmap pressure, and on-call burden down 60% after. Answer slot: engineers will ask what was fixed. If you know what the work consisted of, describe it in your own words and say which parts were yours. If you weren't close to the details, say so plainly and say who was | F3. Engineers go two levels deeper than a manager does. This is where they'll check the story is yours |
| G2 | (Staff engineer) "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name it yourself, in your own words. The pack doesn't supply one because your material doesn't state one. If you don't know how the figure was counted, say so: that's the honest answer and it reads as credible. Keep "after" | The weakest-assumption move turns a gotcha into credibility. A Prober stem, aimed at F3's headline figure |
| G3 | (Staff engineer) "You run your hiring loop, about 40 interviews last year. How do you decide what a strong hire looks like?" | EXP, JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Describe your bar in your own words. Answer slot: "own … hiring" makes a probe likely on how the bar is set. If you set the bar or designed the loop, say how. If it was set for you, or there's no written bar, say so plainly and describe how you run it. On "about 40": say whether those were your own interviews or the loop's, and how you got the number | F4's number gets defended like the 60% does. JD because "own … hiring" is a stated responsibility |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | (PM) "Tell me about a time you had to say no to a stakeholder." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The reliability quarter is one candidate story, at the quote's scope: you pushed the quarter through against roadmap pressure. Answer slot: if a specific stakeholder heard the no, say who, in role terms, and how it landed. If not, say so plainly. If you'd rather not reuse E3's story, pick another time with a real stake and the relationship intact. If none comes to mind, say so plainly and say how you'd handle it | A values-style stem for a cross-functional partner. Leaning on F7 here means aligning your answers to E3 beforehand |
| H2 | (PM) "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time with a named customer impact, a metric you let slip, and what came of it. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | A Values stem, and a natural one for a PM in industrial IoT |
| H3 | (Any panelist) "How do you grow the engineers on your team?" | JD | [generic] | F5 is a silence, so this is a selection scaffold. Pick one person you helped grow: where they started, what you did, what changed. If no such case comes to mind, say so plainly and describe how you'd approach growth for eleven people | "growth for 11 engineers" is a stated responsibility with no evidence in your material yet. Rehearse it so the honest answer is ready |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What have you been looking into on the devices side lately?" | JD | [generic] | Answer slot: if you've read up on or tried anything in IoT or device management, say what, in your own words. If you haven't yet, say so plainly and name what you plan to learn first. Do a little reading before Thursday so you have a real answer | A casual question on a hot topic in the role (F2) is still scored |
| J2 | "What would your current team say you're like to work for?" | EXP | [generic] | In your own words: one strength and one thing they'd say you're working on. Keep it specific and don't oversell | A rapport opener that also scores self-awareness |

### Reverse questions (Round 2)

| # | Question | Why it lands |
|---|---|---|
| E-R1 | (Staff engineers) "What could a new manager do in the first month that would genuinely help you?" | Reciprocity. It shows you'd make their load lighter, not heavier |
| E-R2 | (Staff engineers) "Would you be on the squads I'd lead, and how do staff engineers and the EM split technical decisions here?" | It clarifies your relationship to the panel and how leadership is split |
| E-R3 | (Staff engineers) "How do you test device-management services against real hardware?" | Genuine curiosity about the domain, and you'll learn something |
| E-R4 | (PM) "How is the roadmap worked out between product, hardware and these squads today? What's working and what isn't?" | It goes straight at the partnership line in the role |
| E-R5 | (PM) "What do you need most from the EM in this seat?" | It invites the PM to tell you how they'll score you |
| E-R6 | (Any) "Where does on-call hurt most in these services today?" | It links to your strongest story without restating it |

---

# Round 3 — Monday: VP Engineering, 30 min ('values and leadership philosophy')

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership philosophy, unpopular truths, customers, growing people | High. The recruiter described the round as 'values and leadership philosophy', which is a values-style round. Larkfield's published values aren't in hand, so the questions are themed from the recruiter's words and standard stems | Two or three principles of your own, each with one example kept at its quote's scope |
| Pressure | Time-boxed "why you" and a challenge to your reliability call | Medium. Skip-level rounds lean Case plus Pressure by default, and 30 minutes forces short answers | Pause, restate, hold through two follow-ups, then concede something specific |
| Case / Strategist | Where the domain is heading, and what two squads shouldn't do | Medium. Skip-level default. Research didn't run, so these are `[generic]` | Clarify their strategy before giving yours |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."; "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles stated in your own words, each with one example. Examples at the quotes' scope: the reliability quarter you pushed through against roadmap pressure, and the hiring loop you run. Principles are yours to choose. Make the examples prove them without stretching. Rehearse this to fit in 120 seconds | The recruiter's 'leadership philosophy' makes this nearly certain to come up. VAL because it scores values, not tasks |
| K2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The reliability quarter may fit, at the quote's scope. Answer slot: if the case for the quarter went to leadership, say who in role terms, how you made it and how it landed, in your own words. If it didn't go to leadership, say so plainly and pick another time with a real stake. If none comes to mind, say so plainly and say how you'd handle it | A Values stem. F3/F7 is your likeliest story, and this round tests whether the hard truth actually landed |
| K3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time with a named customer impact, a metric you deprioritised, and the outcome. If none comes to mind, say so plainly and give the nearest thing, or how you'd handle it. If you used H2 on Thursday, keep the two answers consistent, or use a different story | A Values stem. Values rounds come back to customers often |
| K4 | "How do you think about growing people, and eventually growing managers?" | VAL, JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Give your growth philosophy in your own words, and reuse H3's example if you have one. On managers: "I haven't managed managers." Then say how you'd approach it, as a plan: what you'd want to learn and from whom. Don't imply experience you don't have | F5 and the managers half of F1. A VP pricing your ceiling will go here |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Three facts at their quotes' scope: nine years of engineering with three as team lead of six; you run your hiring loop for backend roles; on-call burden dropped 60% after the reliability quarter you pushed through. Then one sentence on what you'd bring. Concede what an internal candidate has, such as hardware context, and hold on your own evidence. Time it | A Pressure stem. With 30 minutes, the VP may time-box. EXP because it's your record under compression |
| L2 | "You pushed reliability against the roadmap. Isn't that a manager who won't commit to dates?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold first: it was one deliberate quarter, pushed through against roadmap pressure, and on-call burden dropped 60% after. Keep it in those terms. Hold through two follow-ups. Then concede something specific, in your own words: the limit you actually know of. Don't fold, and don't invent a cost or a benefit the quote doesn't carry | It tests composure on your strongest story. The hold-then-concede structure is the skill being scored |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Where is device-management software heading for a company like ours, and what would you bet on?" | CO, CASE | [generic] | Research didn't run, so the pack has no Larkfield strategy to give you. Do your own reading before Monday. In the room, clarify first ("how do you see the bet today?"), then offer one hypothesis with its risk, framed as a question to test, not a verdict | `[generic]` is the honest cost of unavailable research. The upgrade menu says what research would add |
| M2 | "Two squads, a fixed headcount, and both hardware and product want more. How do you decide what the squads don't do?" | CASE | [generic] | Structure: what each ask serves, what each costs, which dependencies are hard (hardware dates), who decides, and how you'd say no visibly and early. A brief nod to how you think about reliability is fine. Keep any example at B3's quote | Skip-level altitude on "own delivery" and the partnership line (F3, F6, F7) |

### Reverse questions (Round 3)

| # | Question | Why it lands |
|---|---|---|
| K-R1 | "What do your strongest engineering managers here do that others don't?" | It invites the VP to describe the bar in their own words |
| K-R2 | "How does engineering decide between new device features and reliability?" | It lets the VP state a value you can reflect back |
| K-R3 | "What's the biggest bet engineering is making over the next year?" | It's altitude, and it fills in what the research couldn't |
| K-R4 | "How do EMs here grow toward managing managers, if that's a path?" | An honest ambition question that ties to F1 |
| K-R5 | "A year from now, what would tell you this hire was the right one?" | It closes on outcomes, and its answer is worth carrying into an offer conversation |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated (F1) | "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | A negative you stated (F6) | "I haven't owned a hardware-adjacent roadmap." Then a plan, said as a plan. No slot |
| Led two teams, or a team larger than six | Inflated form of F1 | F1's quote at its own scope: team lead of six for three years. The limit is the pack's observation: your material says one team of six. A1's slot stays inside leading that team |
| Owned hiring, or made the hire decisions | Inflated form of F4 | F4's quote: you run your hiring loop for backend roles, about 40 interviews last year. B4 and G3's slots stay inside the loop |
| Did all 40 interviews yourself | Inflated reading of F4 (the ambiguity resolves downward) | "About 40 interviews last year." Say whose they were in your own words |
| The reliability quarter cut incidents or outages by 60%, or caused the drop | Inflated form of F3: the figure moves to a different noun, and "after" becomes "because" | The quote: your team's on-call burden dropped 60% after you pushed the quarter through. C1, C2 and G2 ask how it was counted and what was yours |
| Owned or set your current roadmap | Inflated form of F7 | F7's quote: you pushed a reliability quarter through against roadmap pressure. E3's slot stays inside that quarter |

---

## Sources

**Provided documents:** your message: the role summary (treated as the JD), the three round descriptions including the recruiter's 'values and leadership philosophy', and your background.

**Searches sent:**

1. `Larkfield Systems values`: refused
2. `Larkfield Systems interview process engineering manager`: refused
3. `Larkfield Systems industrial IoT news 2026`: refused

**Fetches:** none.

**Dossier:** none present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. It would have supplied official value names, so Round 3 could carry a values cheat sheet with one mapped VAL question per value |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. Your message already establishes the three rounds and who runs each. The search would have added format details, such as whether the panel includes a live exercise |
| 3. `Larkfield Systems` strategy / recent news | unavailable | Refused. It would have grounded M1, B2 and the reverse questions in Larkfield's current priorities. M1 is `[generic]` instead |
| 4. Interviewer names at Larkfield Systems | n/a | No names were given, so no query could be formed. The interviewer read is absent |
| 5. Representative Engineering Manager JD | skipped | The role text you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full posting text:** mid-list requirements get their own rows and JD questions, and any terms such as location, on-site days or travel surface as fit rows
- **Your CV:** evidence cells gain CV lines. F2 (device management) and F5 (growth) may get quotes, and their scaffolds become story-mapped answers
- **Web search allowed in this session:** official value names, giving Round 3 a values cheat sheet; current strategy, grounding M1 and B2; panel format details
- **Interviewers' names** (Director, staff engineers, PM, VP): an interviewer read for each, per-person persona assignment on the panel, and a reverse question tied to each one's path
- **Recruiter guidance** (focus areas, or any exercise or presentation announced for the panel): a graded-deliverable build section. Usually one email to the recruiter
- **Prep time per round:** a prioritised prep schedule for each of the three dates
- **Your answers to the slots in A1, B3, B4, C1, G1 and H3, told to me outside a drill:** those rows become story-mapped on your own words
- **A `tuesday-dossier.md`:** verified evidence and an evidence-derived highest-ROI objection in place of the inferred one
