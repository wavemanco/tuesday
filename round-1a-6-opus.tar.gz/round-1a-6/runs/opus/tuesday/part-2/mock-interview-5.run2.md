Quick update: I've loaded the interview-prep playbook. Next I'm running a few targeted searches on Kelverton Rail and the panel, then I'll build your pack.
Web search was refused, so I'm building the pack from your message and the recruiter's brief alone. The searches I tried are listed in the pack's Sources.
Your prep pack is ready: [Kelverton-Rail_senior-partnerships-manager_interview_pack.md](/var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-5-denied-fd582fb0/Kelverton-Rail_senior-partnerships-manager_interview_pack.md). Web search was blocked, so it's built only from your message and the recruiter's brief. Anything about Kelverton or the rail market is either marked as general pattern or left as a slot for you to fill from the report.

**How it's organised:**
- **The 15-minute POV:** a 13-minute running order, three positions each with the concession you should make, one thing you'd refuse to do, and a close on operators.
- **A four-hour schedule:** a plan for your weekend.
- **About 22 practice questions:** split by panellist, mostly Deepa probing and Ross pushing on commercials.

**Where to spend the most time:** question B1, "You've never carried a direct quota. Why should we trust you with a number?" Ross is very likely to ask it in some form. Your strongest answer is to say it first, in your own terms: "roughly £4M of *influenced* revenue." Then turn to how this role is measured.

**What to avoid:** the trap in the POV is summarising the report back to the people who wrote it. Instead, name one point from it that everyone will recognise, then say where you'd go differently and why.

If you like, I'll play Ross on B1 with real follow-ups. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. And if you'd prefer the pack as a Word document, I can convert it.

Can you paste the job description and your CV? Either one would replace several general-pattern rows with ones grounded in the actual role and your real history. And if you turn on web search, should I run the research on Kelverton, Deepa and Ross?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes. The first 15 are your spoken POV, no slides, and the rest is Q&A where "Ross will push on commercials" (the recruiter's words).
**Built from:** your message and the recruiter's email as you quoted it. No JD or CV was supplied, and web research was refused in this session, so anything about the rail market or Kelverton itself is either a slot for you to fill from the report you've read or marked `[generic]`.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored. Rehearse both, because the same question about your quota sounds very different from Deepa (a quiet probe) than from Ross (a time-boxed challenge).
- **Type key:**
  - **VAL** tests whether your behaviour fits the values they care about.
  - **EXP** tests whether your claims survive scrutiny.
  - **JD** tests whether you can do the stated job.
  - **CO** tests whether you can think at the company's altitude.
  - **CASE** is a live problem, scored on structure.
- **Provenance labels:**
  - `[grounded]` means the row traces to your words or the recruiter's.
  - `[inferred]` means it was derived from them, with the derivation named.
  - `[generic]` means it's a role-family pattern with no claim about Kelverton.
- **Answer slots** are instructions for the interview, not questions for you to answer now. Each has two honest branches: either it happened and you say how, or it didn't and you say so plainly.
- Guidance is scaffolding, not a script. Say it in your own words.
- Question IDs go by persona. Letter **F** is skipped so the question IDs never clash with the fit-snapshot rows (F1, F2, and so on).

---

## Prep triage: your four hours

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV, then say it aloud twice with a timer, aiming for 13 minutes. Out loud matters because a talk without slides falls apart in places a written plan doesn't. | Section: Graded deliverable |
| 2 | 45 min | The quota objection, rehearsed until it's boring. Then Ross's three pressure questions. | B1, C1, C2, C3 |
| 3 | 30 min | Defend your two numbers, "6 partners to 40" and "roughly £4M of influenced revenue". Work out what you can and can't say about how each was counted. | D1, D2, C2 |
| 4 | 30 min | Re-read the report with two jobs only: pick the one point everyone in the room will recognise, and the one point where you'd go differently. Note its vocabulary for operator segments and its headline numbers. | POV slots; A5, E2 |
| 5 | 20 min | Your 90-second career story, and "why rail, why now". | E1, B3 |
| 6 | 15 min | Choose three reverse questions, one for each panellist plus one spare. | Reverse questions |
| 7 | 25 min | One live drill: Ross on B1, with follow-ups. | Drill offer |

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Adjacent work from another sector. Use the quote's own words: you ran the ISV channel and took it from 6 partners to 40. The limit is the pack's observation, not a line for you: this is payments partners, not rail operators. Answer slot: the recruiter's brief makes a probe on what carries over likely. Say what from that channel you would reuse here, in your own words. If something there depended on payments specifics, say so plainly and keep it out of the plan |
| F2 | "land on what it means for the operators themselves" — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your words are bus and light rail network planning, and you know "the operator world from the other side". Keep both exactly. Answer slot: expect "which side?" and "what kind of client?". Say who your clients were and what the planning work was, in your own words. If heavy rail or train operating companies were never part of it, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | A real commercial figure, but an influenced one, and "roughly" stays in. Answer slot (defend-the-number): how it was counted, what it is sensitive to, the assumption you'd defend least, and which part was yours. Answer each in your own words, and if you don't know how it was counted, say so |
| F4 | "Ross will push on commercials" — recruiter | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap you stated yourself. Words: "I haven't carried a direct quota; my number was influenced revenue." Follow it with how you would take on a number here, said as a plan and never as a past |
| F5 | Rail-sector selling experience, typical for a rail-tech partnerships role | "Never sold into rail specifically" — your message | none | [generic] | capability | A gap you stated yourself. Words: "I haven't sold into rail." Then F2's quote at its own scope, and a ramp plan. Don't add anything to make the gap feel smaller |
| F6 | Building and running a partner programme at scale | "took it from 6 partners to 40"; "9 years in partnerships" — your message | medium | [generic] | none | No gap, but these are self-reported with nothing inspected behind them, so expect a probe. Your material can be read two ways: whether the 5 consulting years sit inside the 9 partnership years or before them. Say it however it actually was, and never add the two together |
| F7 | Senior stakeholder and executive relationship management | none given | none | [generic] | discovery | Nothing in your message speaks to this yet. Selection scaffold: pick a time you held a position with a partner's or your own senior leadership. It needs a named stake and a relationship that stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry |
| F8 | Designing partner commercial models (referral, resale, revenue share) | none given | none | [generic] | discovery | Nothing in your message shows which models your ISV channel ran on. Selection scaffold: if you set or negotiated a partner commercial structure, pick that one and describe it in your own words. If you didn't, say so plainly and reason through the options live (C1, C3) |

---

## Graded deliverable: your 15-minute POV

The brief, in the recruiter's words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**The trap:** both panellists have read the same report you have. Summarising it scores as homework. Taking it as the shared starting point and then departing from it, with reasons, scores as judgment.

### What you can build on

| Building block | Source | Provenance |
|---|---|---|
| The ask: 18 months, operator partnerships, ending on operator benefit | Recruiter's email | [grounded] |
| You ran a channel and took it from 6 partners to 40 | F1: "running the ISV channel — took it from 6 partners to 40" | [grounded] |
| You know a commercial number, and its limits | F3: "roughly £4M of influenced revenue" | [grounded] |
| An operator-side vantage point | F2: "so I know the operator world from the other side" | [grounded] |
| The market picture | The report you read. Use its numbers and segment names, not mine | Slot, filled from the report |

### Suggested 13-minute running order (pending your approval)

| Clock | Beat | Notes |
|---|---|---|
| 0:00–1:30 | Frame | One line on who you are, using F1's and F2's quotes, then the three moves you'll cover and where you'll land: on operators |
| 1:30–3:30 | Where we start | Slot: name one point from the report the whole room will recognise, then the one place you read it differently, with your reason |
| 3:30–10:00 | Three moves over 18 months | The theses below, with phases from first 90 days to month 18 |
| 10:00–11:30 | How we'd know it's working | Raise commercials before Ross does: what counts, who it counts for, and how it gets agreed (T3) |
| 11:30–13:00 | What it means for operators | The close the brief asked for |
| 13:00 | Hand over | "Where would you push back?" This invites the Q&A instead of waiting for it |

### Three theses, each with its concession (pending your approval)

| # | Thesis | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | Organise partnerships around operator problems, not partner categories. Each partnership should exist because it closes a gap an operator feels in using the scheduling product. | You don't yet know Kelverton's operators' problems beyond what the report says, and you should say so. Diagnosis comes first, in the first 90 days | [generic] |
| T2 | For 18 months, depth beats count: a small set of partners that operators actually use alongside the product, rather than a long list. | Your own track record is a count story (F1). Say why here is different in your own words, and grant that narrower means slower coverage and some partners deprioritised | [generic] |
| T3 | Every partnership carries two lines: a commercial line Ross can underwrite and an operator outcome Deepa can sell. Agree definitions up front, including what counts as sourced versus influenced. | Attributing influenced revenue is contested, and your figure is an influenced one (F3). Say that before Ross does | [generic] |

**Anti-pick (pending your approval), the thing you'd say no to:** `[generic]` Pick one thing you would deliberately not do in the 18 months. Examples are a broad open partner programme before the core partnerships prove out, or partner deals that sit on the product roadmap without product sign-off. Choose the one you actually believe, and give your reason. A plan with nothing it refuses to do reads as a wish list.

**Close: what it means for operators (pending your approval).** `[generic]` Frame it in operator terms:
- fewer vendors to coordinate;
- integrations that work from day one;
- one accountable answer when something breaks;
- outcomes they can report up their own chain.

Slot: anchor each of these to whatever the report says operators are measured on or struggling with, using its words. Where the report says nothing about one, drop that one rather than assert it.

---

## Reading the panel

From the recruiter's email only. Public profiles were not researched (searches were refused).

| Panellist | What we know | What it implies |
|---|---|---|
| Deepa | "VP Partnerships, your future manager" | Scores whether she'd want to hand you her operator partnerships. Expect Case/Strategist questions on her actual roadmap, and Skeptic probes on rail and quota. Your POV is mainly for her |
| Ross | "Commercial Director"; "Ross will push on commercials" | Pressure and Prober. He will test the £4M, the quota gap and deal economics, probably interrupting and time-boxing. His native language is margin and accountability for a number. Answer in it |

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | "How would you…", live partner decisions | High. It's the hiring-manager prior, the POV invites it, and Ross's commercial case questions add to it | Clarify, then objective, segmentation, approach, metrics and risks. Think aloud, and challenge one premise politely |
| B. Skeptic | Quiet probes on rail, quota, "why now" | High. Hiring-manager prior, plus two gaps you stated yourself (F4, F5) | Rehearse B1 until it's boring. Bridge only from F1 to F3's quotes, and give a ramp plan |
| C. Pressure | Interrupts, "sixty seconds", "how much was you" | Medium-high. The recruiter flagged that Ross will push | Pause, restate the question, anchor in what you stated, hold through two follow-ups, then concede specifically |
| D. Prober | Asks for denominators and how numbers were counted | Medium. You have two headline numbers, and a commercial director will test both | Know what you can and can't say about how each was counted. Name your weakest assumption first |
| E. Conversational | "Walk us through your journey" | Low-medium. The Q&A opener and the warm-up are still scored | A ready 90-second arc. Treat a casual question about the report as scored |
| G. Peer | Where partnerships stops and sales starts | Low. Neither panellist is a peer, but Deepa will care about the seams with sales and product | Propose principles for the seam rather than pretend to know it |
| H. Values | Customer-over-metric stories | Low. No values round was named for this session | One story ready, mapped by the selection scaffold |

Weights come from the recruiter's description of this session plus the standard pattern for a hiring manager and a commercial director. No company interview guide was read.

---

## Question banks

### A. Case/Strategist (Deepa first, Ross second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you change anything in our operator partnerships, what do you need to know?" | CASE | [generic] | Clarify first: which partners exist today, what each brings in commercially, which operators use them, where operators complain. Then name the one decision you'd make by day 90. No claim about your past is needed | Deepa's likeliest opener after the POV. It tests whether you diagnose before prescribing. CASE because it's a live problem |
| A2 | "Which partner types matter most for a scheduling platform selling to operators, and which would you deprioritise?" | CO | [generic] | Rank by operator problem (T1), not by partner size. Give your anti-pick with its reason. Slot: use the report's own segment names; where you're guessing, say so | Tests altitude and the willingness to say no, which the role needs. CO because it rests on the report |
| A3 | "An operator wants a capability we don't build. Partner, build, or say no?" | CASE | [generic] | Structure: how many operators want it, how close it is to the core product, who owns the relationship if it breaks, and the economics. State your default, then what would change it | A classic partnerships decision. Shows judgment between product and partners |
| A4 | "In 18 months, how do we know operator partnerships worked?" | CASE | [generic] | Two lines (T3): a commercial line agreed with Ross, including sourced versus influenced, and an operator outcome. Name one leading indicator for each | Bridges Deepa's question and Ross's. Getting definitions agreed early is your strongest commercial signal |
| A5 | "Where does our strategy report get it wrong?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Answer slot: name one point where you read it differently, with your reason, in your own words. If you don't disagree with it, say so plainly and name the claim in it you'd test first in the market | The recruiter sent the report, so expect them to test how you used it. Disagreeing with reasons scores as judgment |

### B. Skeptic (mostly Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why should we trust you with a number?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Name the limit before it's pushed: "I haven't carried a direct quota; my number was influenced revenue — roughly £4M." Hold on exactly that: influenced, roughly £4M, and never more. Answer slot: if there was a rule for what counted as influenced, say what it was in your own words; if you don't know how it was counted, say so. Then turn to the future, said as a plan: ask how this role is measured, and what you'd need to own a number here. Hold through two follow-ups by returning to the quote, never by adding to it | F4 is the gap a commercial director is likeliest to press, and the recruiter flagged that Ross will. JD because it scores the commercial side of the job |
| B2 | "You've never sold into rail. Why would operators listen to you?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | "I haven't sold into rail." Then F2's quote at its own scope: bus and light rail network planning, and the operator world from the other side. Answer slot: if asked which side, say who your clients were in your own words. If heavy rail was never part of it, say so plainly. Close with a ramp plan for your first months | F5 and F2 together make your most predictable domain objection. Keep "bus and light rail" exact, because a rail panel will notice if it drifts |
| B3 | "Why leave payments for rail, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel"; "5 years in transport consulting" | Your actual reason, in your own words. Your two sentences sit side by side, partnerships and the operator world. Say both and let the panel make the link rather than claiming it | Motivation is the Skeptic's core check. Rationale rests on F1 and F2 |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two you stated, not a dressed-up strength. Say it plainly, then give a concrete ramp | Choosing your real gap here takes the sting out of B1 and B2. F4 and F5 supply it |
| B5 | "What from running an ISV channel in payments won't transfer here?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40" | Answer slot: name what in your channel depended on payments specifics, in your own words. If you believe the buyers here are fewer and slower, say that as your reading and say how you'd check it | Tests self-awareness about F1's limits. The honest answer here earns credibility for everything else |

### C. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: how does a partnership make Kelverton money?" | CASE | [generic] | Pause, then use a three-part structure: partners bring deals (referral or resale), partners make operators stay (integrations that reduce churn), partners extend what an operator buys. Say which you'd prioritise, and concede you'd need Kelverton's margin data to rank them properly | Ross's likely opener. Tests commercial fluency under a clock |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold the word "influenced" and the word "roughly". Answer slot: say which part was yours, in your own words. If you can't separate it, say so plainly. Concede specifically and don't fold: the figure is influenced, and you won't present it as closed revenue | F3, under pressure. The hold is only what the quote carries |
| C3 | "A big partner wants a 30% revenue share or they walk. What do you do?" | CASE | [generic] | Clarify what they bring (sourced deals or delivery), what it costs to replace them, and Kelverton's margin floor. State a position, offer a structure tied to performance, and name your walk-away. Concede the numbers you'd need first | F8 is thin. A live negotiation case lets you show reasoning without claiming a past |

### D. Data-driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M influenced number was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot, defend-the-number: how it was counted, what it is sensitive to, the assumption you'd defend least, and which part was yours, each in your own words. Name the weakest assumption yourself, before Ross does. If you don't know how it was counted, say so | Every headline number gets this test. F3 |
| D2 | "Of the 40 partners, how many were actually producing?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know how many were active, give that number and say how "active" was defined. If you don't know, say so plainly. Keep "40" attached to partners | A count invites a question about how many were really active. F6 |
| D3 | "Over those four years, what partner metric did you watch most closely?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" | Answer slot: if there was one metric you watched, name it and why. If there wasn't one, say so plainly and say what you'd watch here | Tests whether you managed by numbers. F1 |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your background." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | 90 seconds, using only those beats: consulting, then partnerships, then the channel and its two numbers as stated, then why this role. Say the years the way they actually were (F6's two-readings note) | The opener sets your credibility, and casual questions are still scored |
| E2 | "What did you make of the report we sent?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Treat it as scored. Answer slot: one thing you agreed with, one thing you'd test, in your own words and with the report's vocabulary | A casual question that is really about homework depth |

### G. Peer (seams)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "If our account team owns the operator relationship, where does partnerships stop and sales start?" | CASE | [generic] | Propose principles: one named owner per operator; partners brought in where they close a gap; credit rules agreed in writing. Ask how it works today | Deepa will want someone who reduces friction. CASE because you can't know their seam yet |
| G2 | "How do you handle credit when a deal is both partner-sourced and sales-sourced?" | CASE | [grounded] "only influenced revenue" | Answer slot: if your payments channel had a rule for splitting credit, describe it in your own words. If it didn't, say so plainly and propose one for here | Links to F3. Credit fights are where partnerships teams lose trust |

### H. Values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time you chose the end customer's or partner's interest over a number. It needs a named cost and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry | Mirrors the brief's "what it means for the operators themselves" |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, the moment you didn't fold, and a relationship intact afterwards. If none comes to mind, say so plainly and describe how you'd handle it | Ross's pressure style rewards someone who holds a position. F7 is thin |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: operator partnerships over 18 months | POV, A1, A2, A3, B5 |
| F2: what it means for operators | POV close, A4, B2, H1 |
| F3: commercials, influenced figure | C2, D1, A4, G2 |
| F4: commercials, quota | B1, B4 |
| F5: rail selling | B2, B4 |
| F6: programme at scale | D2, D3, E1 |
| F7: senior stakeholders | H2 |
| F8: commercial models | C1, C3 |

---

## Reverse questions

| # | Ask | To | Why it lands |
|---|---|---|---|
| R1 | "Is this role measured on sourced, influenced, or partner-closed revenue, and is there a number attached?" | Ross | Turns your biggest objection into a calibration question and shows you think about accountability for revenue |
| R2 | "Six months in, what would tell you this hire was the right call?" | Deepa | Gets her success criteria in her own words and signals you plan to be measured |
| R3 | "Which operator outcomes do you most want partners to move, and how do operators judge Kelverton on them today?" | Deepa | Keeps you on the brief's operator close and surfaces the real problem |
| R4 | "Of the report's conclusions, which ones does leadership actually debate?" | Either | Shows you read it, and asks for the live argument rather than the official version |
| R5 | "When a partner is involved in a deal, who owns the operator relationship today?" | Deepa | Finds the seam before you inherit it |
| R6 | "What partner commercial arrangement would you most like to change?" | Ross | Lets Ross talk in his native language and tells you where the work is |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a sales quota or owned direct revenue | A negative you stated, F4 | "I haven't carried a direct quota; my number was influenced revenue." |
| Has sold into rail | A negative you stated, F5 | "I haven't sold into rail." |
| Generated, closed or sourced £4M, or exactly £4M | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. Both "roughly" and "influenced" stay |
| Built, founded or single-handedly grew the channel; recruited 34 partners | Inflated form of F1 | F1's quote at its own scope: running the ISV channel and taking it from 6 partners to 40. The count belongs to partners, not to deals or integrations |
| Has worked with train operating companies or in heavy rail | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, and the operator world from the other side. The limit is the pack's observation: your material names bus and light rail, not heavy rail |
| 14 years of partnerships experience | Inflated form of F6 | Your two sentences, said separately and the way the years actually were |
| Knows Kelverton's operators or strategy beyond the report | No source | The report and what you'd test in it |

---

## Sources

**Provided:** your message, including the recruiter's email as you quoted it. The market report was referred to, but its contents were not shared with me.

**Searches sent, all refused by this session's permissions:**
1. "Kelverton Rail values": refused
2. "Kelverton Rail interview process": refused
3. "Kelverton Rail scheduling software train operating companies news 2026": refused
4. "Deepa VP Partnerships Kelverton Rail": refused
5. "Ross Commercial Director Kelverton Rail": refused
6. "Senior Partnerships Manager rail software job description train operators": refused

No dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The values cheat sheet and value names for H1 and H2. Not needed for a values round, since none was named, but it would theme the VAL questions |
| 2. `Kelverton Rail interview process` | unavailable | Wider loop context. This session's structure is set by the recruiter's own words, so the persona weights stand |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Current moves and competitors, which would ground A2, A5 and the POV's starting point beyond the report |
| 4. Interviewer names (Deepa, Ross) | unavailable | Their public career paths, persona tuning, and a reverse question tied to each one's path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would turn F5 to F8 from `[generic]` into `[inferred]` rows quoting a real posting |

---

## Upgrade menu

- **The JD text** → turns F5 to F8 into `[grounded]` rows, and adds a JD question for every listed requirement.
- **Your CV** → more story-mapped answers in place of scaffolds, especially F7, F8, H1 and H2.
- **Your own notes on the report:** the one point the room will agree on and the one you'd challenge. Share only what you're comfortable with, since it's an internal document. This fills the POV's starting-point slot and grounds A2, A5 and E2.
- **Web search enabled** → reruns the five targets above: Kelverton's news and competitors, Deepa's and Ross's public paths, and a representative JD.
- **Deeper research (L2)** → up to 6 more searches and 2 more fetches, several more minutes. Adds a company strategy brief and recent organisational context for the POV.
- **Your answers to the slots in F2 and F3** (which side of the operator world, and how the £4M was counted) → upgrades B1, B2, C2 and D1 from slots into rehearsed lines.
- **Something that documents the £4M**, such as a partner revenue or attribution report you're able to share → raises F3 from medium toward high.
- **A tuesday-dossier.md** → would carry verified evidence and prohibited claims between sessions, sharpening the highest-ROI objection.
