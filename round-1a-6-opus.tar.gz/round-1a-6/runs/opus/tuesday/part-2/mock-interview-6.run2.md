Building your three-round prep pack now; running a few quick searches on Larkfield Systems first.
I've built a prep pack covering all three rounds: **larkfield-systems_engineering-manager_interview_pack.md**. It has one shared fit table, a question bank for each round with suggested answers, and 5 questions for you to ask in each round.

I couldn't research Larkfield: web search permission wasn't granted, so all three searches were refused. That means the pack doesn't have the company's official values or strategy, and the questions about Larkfield's direction are generic. The pack says so where it applies.

**Biggest thing to rehearse (B1):** going from one team of six to two squads and 11 engineers, when you've said you haven't managed managers. It will come up in every round: directly from the Director on Tuesday, more collegially from the panel on Thursday, and under time pressure from the VP on Monday (J2). The suggested answer is to name the gap before they do, then lay out a plan. Don't add experience you don't have.

**How each round is weighted:**
- **Tuesday, Director:** mostly live role problems (your first 90 days, a hardware slip, hiring priorities) plus a sceptic's probing of your gaps.
- **Thursday, panel:** mostly peer questions (where the line sits between you and the staff engineers, settling roadmap trade-offs with the PM), plus close questioning of your 60% figure.
- **Monday, VP:** mostly leadership-philosophy questions, built on the recruiter's wording, plus time-boxed pressure questions.

**Two traps to avoid:**
- Your sentence says on-call dropped 60% *after* the reliability quarter. It doesn't say the quarter caused all of it. Keep that wording the same in all three rounds.
- The 40 is interviews, not hires. Running the loop doesn't mean you made the final hiring call.

The end of the pack lists what would improve it. The most useful additions are Larkfield's values page (pasted in, or search allowed) and the interviewers' names.

I can play the sceptical hiring manager and run you through B1 live, with follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, so you can bring it to later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Role:** Engineering Manager. Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.
**Mode:** Loop. Three scheduled rounds, one shared fit snapshot, then a mini-pack for each round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus a cross-functional partner |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level. The recruiter called it "values and leadership philosophy" |

No interviewer names were given, so persona weights below come from round-type priors, not from anyone's public profile.

---

## How to use this pack

- **Personas** describe how a question arrives: who is asking, in what style. **Types** describe what the question scores. The same objection will reach you three times in three different styles across this loop, and each round's bank rehearses the style that round will use.
- **Type key:**
  - **VAL**: whether your past behaviour shows the values or leadership philosophy they're scoring
  - **EXP**: whether what you've said about your work survives scrutiny, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, solved out loud
- **Provenance:** `[grounded]` rests on something you told me, quoted. `[inferred]` is this pack's derivation, with the derivation named. `[generic]` is a pattern for this kind of role, with no claim about Larkfield or about you.
- **Answer slots** are instructions for your answer in the interview, not questions for you now. Each has two honest branches. Use whichever one is true.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. Evidence is quoted from your message, and nothing else is used as evidence about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads or eleven people, and the words stay there: "I've spent three years as team lead of a team of six." If the squads have their own leads, the plain acknowledgment is yours to give: "I haven't managed managers." Answer slot: the two-squads line makes a probe on how you'd lead through other people likely. If anyone on your team of six led a piece of work with you above them, say how that worked, in your own words. If no one did, say so plainly and stay with how you led the six |
| F2 | "building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Your material shows payments, and it doesn't show whether any of your systems dealt with devices. Answer slot: the device-management line makes a probe on that likely. If any system you worked on talked to physical devices or managed things in the field, say what it was and what part was yours. If none did, say so plainly and say what you'd learn first. Never present payments work as device work |
| F3 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote is a prioritisation call that held against roadmap pressure. That sits next to owning delivery but isn't the same thing. Words at its own scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Answer slot: "own delivery" makes a probe on how you plan and ship day to day likely. If that was yours on your team, say how you ran it. If it sat with someone else, or there was no set process, say so plainly and stay with the reliability quarter |
| F4 | "hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap. It's something you've said with nothing yet to inspect behind it, so expect a probe. Lead in the quote's own terms: you run the hiring loop for backend roles, about 40 interviews last year. The number counts interviews, not hires, and "about" stays in |
| F5 | "growth for 11 engineers" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Leading a team touches growing people, but your material doesn't show what growth work you did. Answer slot: if you've run career conversations, growth plans or promotion cases for people on your team, say which ones and how, in your own words. If that sat with someone else or didn't happen, say so plainly and say how you'd approach it with eleven people |
| F6 | "partner with hardware ... on roadmap" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | This is a gap you've named yourself, and no wording closes it. Words: "I haven't owned a hardware-adjacent roadmap." Then how you'd learn it, said as a plan and never as something you've done. Add nothing to make the gap feel smaller |
| F7 | "partner with ... product on roadmap" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote shows you holding a priority against roadmap pressure. It doesn't say who the pressure came from. Words: the quote as you said it. Answer slot: the partner-with-product line makes a probe on how the quarter was agreed likely. If a product manager was part of agreeing it, say how it was settled, in your own words. If not, or the call wasn't yours, say so plainly and stay with what you pushed through |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Lead two squads | A1, B1, J2, C1 |
| F2 Device-management services | B2, E3, G3, K1 |
| F3 Own delivery | A1, A3, D2, J3 |
| F4 Hiring | A4, D3, H3 |
| F5 Growth for 11 engineers | A5, H4 |
| F6 Partner with hardware on roadmap | A2, B2, D4 |
| F7 Partner with product on roadmap | D2, G1, G2, K2 |
| The 60% on-call figure (headline metric) | B3, E1, J1 |

**Highest-ROI prep in this pack: B1**, the scope jump. It goes from one team of six to two squads and eleven engineers, and you have said you haven't managed managers. It will come up in some form in every round: openly on Tuesday, collegially on Thursday, under time pressure on Monday (J2). Rehearse it until it bores you.

---

## Sources

- **Provided:** your message (the role description, the three rounds, your background).
- **Searches sent:** `Larkfield Systems values` (refused); `Larkfield Systems interview process engineering manager` (refused); `Larkfield Systems industrial IoT news` (refused). Web search permission wasn't granted in this session, so all three were refused and returned nothing.
- **Loop structure:** comes from your own description of the three rounds, which names who runs each one. The Monday round counts as a values-style round because the recruiter described it as "values and leadership philosophy". No values cheat sheet is included, because Larkfield's published values aren't in hand.
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. It would have supplied the official value names for a Monday values cheat sheet and themed bank H by name |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. Your own description already establishes the three rounds. This would only have added round formats, such as whether the panel includes a system-design segment |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Refused. It would have grounded K1 and the CO angle in Larkfield's current priorities. Without it, those rows are `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form. There is no interviewer read, and the upgrade menu says what names would unlock |
| 5. representative Engineering Manager JD | skipped | The role description you quoted supplies the requirements for the fit snapshot and the JD-tagged questions |

---

## Round 1: Tuesday, Director of Engineering (45 min, hiring manager)

They're buying capability and taking the risk out of your gaps. They are also deciding whether they want to manage you, so expect live problems from their roadmap and direct questions about the scope jump.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "You inherit two squads. What do you do?" Hardware slips, split attention, headcount | High. A hiring-manager round leans on live problems from the actual role, and this director owns the roadmap you'd run | Clarify, then the objective, then the structure, then risks. Think aloud and challenge one premise per case |
| Skeptic | Quiet probing of the scope jump, the hardware gap, and why you're moving | High. A hiring-manager round's other prior. F1 and F6 are the visible gaps, and a would-be boss has the most reason to test them | Concede the limit before they reach it, then give a concrete plan. Use only the evidence you stated |
| Conversational | The opening "walk me through it" and a style question | Low, but scored. 45 minutes usually opens with your arc | A pre-built 90-second arc from C1. Treat the casual questions as scored |

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit two squads mid-quarter. What do you do in your first 90 days?" | CASE | [generic] | Clarify first: what's already committed, what's on fire, and who leads each squad today. Then structure it. Weeks 1–4: one-to-ones with all eleven, sit in on both squads' rituals, and map commitments to hardware and product. Weeks 5–8: one change you'd make, chosen with the squads. By day 90: a delivery rhythm the director can read at a glance. Say what you would not change before day 60 and why. The question needs no claim about your past, so the guidance makes none | Tests F1 and F3 as a plan rather than a record, which is where your evidence is thinner. CASE because it's scored on structure |
| A2 | "A hardware revision slips six weeks, and your squad's device-management release depends on it. Walk me through it." | CASE | [generic] | Clarify: is it a hard dependency, or a sequencing choice? Then options: decouple through simulation or emulation, feature flags, or a staged rollout that ships software-only parts first. Re-plan with product and say what drops. Then tell people, in the order they need to know. End with what you'd want to learn from hardware about how their timelines move. Say all of it as what you would do. F6 is a gap you named, so never present it as something you've done | F6 is the row with no evidence, so a live hardware case is the likeliest way the director tests it. CASE because it's a decision under a real constraint of this role |
| A3 | "One squad ships features while the other is buried in on-call. How do you split your attention and the roadmap?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the case: size the on-call load, decide what reliability work earns roadmap space, and agree it openly with product. You may bring in your own sentence as one data point, at its own scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Keep "after", and don't turn it into "because". Then return to the two squads in front of you | F3 is your strongest delivery-adjacent evidence, and this case lets it in naturally. CASE first, EXP second, because the story supports the reasoning rather than replacing it |
| A4 | "How would you decide hiring priorities across two squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure it: gaps by squad, skills the hardware partnership needs, and seniority balance. Then bring in your own sentence as it stands: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: the role's "hiring" line makes a probe on whether you've set hiring priorities or headcount likely. If you have, say how, in your own words. If that sat above you, say so plainly and stay with the loop you run | F4 covers the hiring requirement. Ownership of headcount is the step the quote doesn't reach. JD because "hiring" is named in the role |
| A5 | "How would you grow eleven engineers you didn't hire?" | JD | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: if you've run growth conversations or promotion cases for your team of six, say which ones and how. If not, say so plainly. Then give the plan: a growth conversation with each person in the first month, a visible next step for each, and where staff engineers can sponsor others. Say the plan as a plan | F5 is low and silent, so this is rehearsed so the honest answer is ready. JD because "growth for 11 engineers" is in the role |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've led one team of six. This is two squads and eleven engineers, and you haven't managed managers. Why is this the right next step and not too big a stretch?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I've never managed managers and never owned a hardware-adjacent roadmap." | **The highest-ROI rehearsal in this pack.** Name the limit before they finish: "I've spent three years as team lead of a team of six, and I haven't managed managers." Don't apologise and don't pad it. Then say what changes at eleven, as a plan: you can't be in every conversation, so the design has to run through senior engineers or squad leads. Follow-up 1, "So why should we believe you can?": go back to what you've stated, the six and the three years, and add nothing to it. Answer slot from F1: if anyone on your six led a piece of work with you above them, say how that worked; if no one did, say so plainly. Follow-up 2, "And if the squads have leads who'd report to you?": "I haven't managed managers. Here's what I'd do in month one." Then ask whether the squads have leads today. Concede the gap. Never concede that the step is wrong for you | F1 is the most visible gap in the loop and a would-be boss carries the most risk on it. It will come up somewhere, so a calm, rehearsed answer changes the conversation. JD because it scores the "lead two squads" requirement directly |
| B2 | "Industrial IoT isn't payments. What happens when firmware and hardware schedules drive your roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Plain acknowledgment first: "I haven't owned a hardware-adjacent roadmap." Answer slot from F2: if any system you worked on dealt with devices or things in the field, say what it was and what part was yours; if none did, say so plainly. Then the plan: learn the hardware cadence from the people who live it, find out where software can decouple from it, and say what you'd ask hardware in week one. Don't argue that payments is "basically the same". The director will know it isn't | F6 and F2 sit together here. Calm candour beats bluffing in front of someone who works with the hardware side. JD because the role names that partnership |
| B3 | "Walk me through that 60% on-call drop. How was it counted, and how much of it was the reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend the number in your own words, in four slots. How it was counted: say what "on-call burden" measured; if you don't know exactly, say so. What it's sensitive to. The assumption behind it you'd defend least: name it before they do. Which part was yours: you pushed the quarter through; say what else was yours, if anything was. Hold the sentence at its own scope, "dropped 60% after". If asked whether the quarter caused all of it, give an honest answer, even if that's "I can't separate it cleanly" | F3's headline figure is a magnet for probing. It comes back on Thursday (E1) and Monday (J1), so get it clean here. EXP because it tests attribution |
| B4 | "Why leave your current role for this, and why now?" | EXP | [generic] | Give your actual reason, in your own words. Keep it about what this role offers rather than what you're leaving. If part of your reason is something you'd rather not discuss, leave it out rather than inventing a different one. Keep it under a minute and keep it consistent across all three rounds | Motivation consistency is the Skeptic's other target, and it gets asked in every round. EXP because it's about your own story. `[generic]` because you haven't given a reason yet |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through how you got here." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | A 90-second arc, built only from your own sentences. Nine years in engineering, the last three as team lead of six, now at a payments company. Two beats: the reliability quarter, in its own words, and the hiring loop you run, about 40 interviews last year. Then why this role, in your own words. Stop at 90 seconds | The opener usually sets the director's frame for the whole round. EXP because it's a scored summary of your record |
| C2 | "How would you describe your management style in a sentence or two?" | EXP | [generic] | Pick one habit you actually practise and give one concrete instance of it. If you can't name one honestly, say what you're working on instead. Avoid adjectives like "servant leader" with no instance behind them | A casual question that the Monday VP will ask again more formally (H1). Keep the two answers consistent |

### Reverse questions: Tuesday

| Question | Why it lands |
|---|---|
| "Do the two squads have their own leads today, and how do you see this role working with them?" | Turns B1 from a test into a design conversation, and tells you whether managing managers is actually part of the job |
| "What would a great first six months look like from where you sit?" | Gives you your would-be boss's success criteria in their own words |
| "When the hardware schedule and the software roadmap conflict today, who decides, and how?" | Shows you're already thinking about F6, and tells you how much of that call would be yours |
| "What's the biggest delivery risk across the two squads right now?" | Gives you material for the Thursday panel and Monday's VP round |
| "How do you support managers who are stepping up in scope?" | Treats the scope jump as something you're planning for, and tests whether the support exists |

---

## Round 2: Thursday panel, two staff engineers and a product manager (60 min)

Panel weighting blends each member's relationship. The staff engineers are pricing what you add to, or take from, their work, and they'll check depth. The product manager is pricing you as a roadmap partner.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Where the seams are between you and staff engineers, roadmap disagreements with the PM, credit across teams | High. All three panellists are partners rather than bosses. B1 and B2 come back here in collegial wrapping | Lead with what you'd bring them. Propose principles for the seams rather than pretending you already know them. Show spine and tact together |
| Data-Driven Prober | Denominators on the 60%, technical judgement, rollout thinking | Medium. Staff engineers check depth and follow up two levels down | Know what you can and can't say about how the figure was counted. Name the weakest assumption first |
| Values / Behavioral | The PM's "tell me about a time" questions on pushback and communication | Medium. A cross-functional interviewer usually scores behaviour through stories | Use stories from your own sentences. Where none carries one, use the scaffold and its honest branch |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where's the line between what you decide and what we, as staff engineers, decide?" | CASE | [generic] | Propose principles rather than a fixed line. Technical direction sits with the people who'll live with it. You own priorities, staffing and delivery commitments. Disagreements surface early and get decided once, with the reasoning written down. Then ask how it works today. Make no claim about how you did this before unless it's true and you say it in your own words | Staff engineers will be checking for turf risk first. CASE because it's a live seam in this exact role |
| D2 | (PM) "I want a new device feature this quarter and you want reliability work. How do we settle it?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Principles first: a shared view of what on-call costs, a trade made in the open, and one decision owner. You may bring in your sentence at its own scope as evidence that you'll hold a reliability priority. Answer slot from F7: if a product manager was part of agreeing your quarter, say how it was settled; if not, or the call wasn't yours, say so plainly. Never imply a product partnership the sentence doesn't describe | F7's thin bridge, asked by the person it most affects. CASE because it's a live trade |
| D3 | "What would you need from us in your first month, and what would you bring?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Reciprocity framing. What you need: their read on the squads' real pain, and one honest map of the technical debt. What you bring: one concrete thing, such as hiring, in its own words: "I run our hiring loop for backend roles — about 40 interviews last year." Then ask what would actually help them | The panel is pricing whether you add to their load or take from it. F4 is evidence you can name without stretching. EXP because it rests on your stated work |
| D4 | "A release depends on hardware, firmware and our two squads. How do you handle credit and blame across all that?" | VAL | [generic] | Principles: credit goes out by name and blame stays general, and post-incident reviews look at systems rather than people. If you have a real instance from your own work, tell it in your own words. If none comes to mind, say so plainly and say how you'd handle it here. Don't claim cross-hardware experience. F6 is a gap you named | A peer-evaluator staple, aimed at the hardware seam where F6 is weakest. VAL because it scores behaviour across teams |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What was the on-call measure exactly, and what was it before?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Same four slots as B3, now to a technical audience. Say what was counted and what the baseline was, in your own words. If you don't know exactly, say so. Name the assumption you'd defend least before they ask. Say what part was yours. Hold "after", and don't upgrade it to "because". Staff engineers will respect "I can't fully separate the effect" far more than a clean-sounding causal story | The second pass at F3's figure, from people who'll ask for the denominator. Consistency with your Tuesday answer matters as much as content. EXP because it's the defend-the-number row |
| E2 | "Tell me about a technical decision your team made that you disagreed with and let stand." | VAL | [generic] | Pick a real instance. It needs the decision, why you disagreed, why you let it stand, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you'd handle it. Staff engineers are scoring whether you override them | Disagreement style with technical peers is what this panel scores. VAL because it's behavioural |
| E3 | "Device fleets fail in the field. How would you roll out a change to thousands of devices you can't easily reach?" | CASE | [generic] | Clarify: device types, connectivity, whether firmware is involved, and what rollback looks like. Then a structure: staged rollout and canaries, compatibility across versions, a kill switch or rollback path, behaviour when devices are offline, and monitoring that tells you early. End by saying what you'd want the staff engineers to teach you. That shows you'll learn from them rather than pretend | F2 is silent on devices. A live case lets you show structure without claiming experience. CASE because it's a role-specific problem |

### Bank G: Values / Behavioral (PM)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you pushed back on a roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on your sentence. Use the beats it states: there was roadmap pressure, you pushed a reliability quarter through, and on-call burden dropped 60% after. Say them in your own words. Answer slot: the partner-with-product line makes a probe on who applied the pressure and how it was resolved likely. If you can say that truthfully, say it and what part was yours. If it wasn't a product negotiation, or you don't know how it was resolved above you, say so plainly and stay with what you pushed through | F7's evidence, told as a story to the person most affected by roadmap trades. VAL because the PM is scoring behaviour |
| G2 | "How do you keep product informed when engineering learns something that changes the plan?" | VAL | [generic] | Principles: tell them early rather than once it's certain, bring options as well as the problem, and have one place where the plan lives. If you have a real instance, tell it in your own words. If none comes to mind, say so plainly and say how you'd run it here | Partnering with product is in the role, and the PM's question is whether you'll surprise them. VAL because it's about behaviour |
| G3 | "How would you get up to speed on our industrial customers?" | JD | [generic] | A plan: customer calls alongside product, field-support tickets, site visits if they exist, and the incidents that cost customers most. Say it as what you'd do. Don't imply customer-domain experience you haven't described | F2's domain gap, asked as a plan. JD because device-management services for this market are the role |

### Reverse questions: Thursday

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity with peers. It shows you're there to reduce their load |
| "Where do the squads and the hardware or firmware teams rub most today?" | Gets you a real read on F6 from the people living it |
| (PM) "How are priorities set between product and the two squads today, and where does it break?" | Shows partnership intent on F7 and tells you what you'd inherit |
| "What does on-call look like for device-management services right now?" | Ties to the reliability conversation you've already had with them, and tells you whether that work is needed here |
| "What's a decision you wish a past manager had left to you?" | Asks staff engineers to name the seam themselves, which is the one way you can learn it before you're in it |

---

## Round 3: Monday, VP Engineering (30 min, "values and leadership philosophy")

A short, senior round. Expect a values conversation with some executive pressure: time-boxed answers and some altitude. The recruiter's own description makes this a values-style round. **There is no values cheat sheet**, because Larkfield's published values aren't in hand (see Sources). Bank H is themed on the recruiter's words instead.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" plus "tell me about a time" stories | High. The recruiter named the round's focus as values and leadership philosophy | Two or three principles, each tied to something you've stated you did. "We" for context, "I" for your own contribution |
| Pressure | "Sixty seconds: why you?" "You haven't managed managers. Convince me." | Medium. A skip-level executive in 30 minutes tends to time-box answers and test composure | Pause before answering and restate the question. Hold your stated position through two follow-ups, then concede what's real |
| Case / Strategist | Altitude questions about where device management goes and when engineering says no | Low to medium. Executives test strategy fluency. Research didn't run, so these rows are generic | Clarify first, then ask what they see. Don't invent Larkfield's strategy |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Two or three principles, each followed by one thing you did that you've already stated. One option: you protect the team's ability to keep working, illustrated by the reliability quarter in its own words. Another option: who you hire matters most, illustrated by the hiring loop you run, about 40 interviews last year. If you hold a principle you haven't tested yet, say so: "this one I'm still testing." Stop at two minutes. Keep it consistent with C2 | The recruiter's description makes this the anchor question. VAL because it scores philosophy through behaviour, and both stories rest on F3 and F4 |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Candidate story: the reliability quarter, against roadmap pressure. Answer slot: the question asks about leadership, so if the pressure came from leadership and you made the case to them, say how and what part was yours. If it didn't, or the truth was delivered by someone else, say so plainly and pick another real instance. If none comes to mind, say so plainly and say how you'd do it | A values-persona staple. Your sentence may or may not carry it, so the slot keeps you honest about which. VAL |
| H3 | "Tell me about a candidate you argued against, or a hire you were part of that didn't work out." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Choose a real instance from the loop you run. It needs what you saw, what you said, and what happened. Say what part was yours, because running the loop doesn't mean you made the final call. If no such time comes to mind, say so plainly and say what you look for instead | F4 is your strongest leadership-adjacent record, and executives test judgement through hiring. VAL because it scores standards under pressure |
| H4 | "When did you get something wrong as a lead, and what changed afterwards?" | VAL | [generic] | Pick a real one with a cost, a moment when you saw it, and a change you actually made. If none comes to mind, say so plainly and give the nearest thing you have. Avoid "I care too much" answers. The VP is scoring self-awareness, and growth for eleven people starts with yours | Self-awareness is the core of a leadership-philosophy round and it touches F5. VAL |

### Bank J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over an internal staff engineer who wants this job?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, then three beats from your own sentences: three years leading a team, the hiring loop you run, and the reliability quarter with the 60% kept at "after". Concede that an internal candidate knows the hardware and the history better. Don't knock them. Finish inside sixty seconds | Pressure stem. It also checks that the 60% stays the same size across all three rounds (B3, E1). EXP because it's your record, defended under a time limit |
| J2 | "You've never managed managers. In two years this org will need you to. Convince me." | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold, then concede. Start with "I haven't managed managers", then the plan: how you'd learn it and what support you'd ask for. Follow-up 1, "That's not convincing": restate the plan and add no experience. Follow-up 2, "So why take the risk on you?": go back to what you have stated, the six people and the three years, and stop. Concede the gap. Never concede your fitness for the role just to end the pressure | B1 again, now time-boxed and from the person with final say. Rehearsed composure matters more than new content. JD because it presses on F1's requirement |
| J3 | "I halve your roadmap tomorrow. What do you cut first?" | CASE | [generic] | Clarify what "halve" means: people, time or scope. Then give the principle: protect commitments other teams depend on, protect reliability, and cut what has no committed customer. Name one thing you'd refuse to cut and why. Make the call quickly; the VP is timing you | Executive pressure in case form, testing F3 judgement. CASE |

### Bank K: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where should device-management services be in two years?" | CO | [generic] | Research didn't run, so don't present a view of Larkfield's strategy as fact. Clarify, then structure: fleet scale, security and updates in the field, the hardware cadence, and what customers pay for. Then ask what they see as the two-year bet. A thoughtful question beats an invented thesis | Executives test strategy fluency. `[generic]` because no Larkfield source was read, and the upgrade menu says what research would add. CO first, CASE second |
| K2 | "When should engineering say no to the business?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Principle first: say no when the cost is invisible to the people asking, and show them the cost. Then your sentence at its own scope as an example of holding a line. Follow-up "and when should you say yes?": give a real answer, not a reflex | Philosophy question with a stated story behind it from F7. VAL because it scores judgement |

### Reverse questions: Monday

| Question | Why it lands |
|---|---|
| "Does Larkfield have written values, and where did you last see one change a decision?" | Tells you what you couldn't research, and asks for the evidence rather than the slogan |
| "What separates the managers who do well here from the ones who struggle?" | An executive's answer is a direct read on the culture you'd be joining |
| "How do you develop managers who are growing into bigger scope?" | Shows you're planning for the gap in B1 and J2, and tests whether that support is real |
| "Where does engineering need to be stronger in two years, and where do these two squads fit?" | Lifts the conversation to their level and tells you what the role is really for |
| "What's a hard trade-off engineering made recently that you'd make again?" | Shows how leadership actually decides, which is the values round turned around on them |

---

## Prohibited claims (shared)

Built from the fit snapshot before the banks were written. Nothing in this pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led two teams, or more than six people | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The pack's own observation is that your material shows one team of six |
| Has managed managers or leads | A negative you stated, F1 | "I haven't managed managers." No slot |
| Has owned or co-owned a hardware-adjacent roadmap | A negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot |
| Cut on-call by 60%, or the reliability quarter caused the 60% drop | Inflated form of F3 (the verb and the logic) | The quote as you said it: your team's burden "dropped 60% after" you pushed the quarter through. The pack's own observation is that "after" doesn't say the quarter alone caused it |
| Owned delivery end to end | Inflated form of F3 | F3's quote at its own scope. F3's slot only asks how day-to-day delivery ran |
| Negotiated the roadmap with product | Inflated form of F7 | F7's quote at its own scope. The pack's own observation is that the sentence doesn't say who the pressure came from |
| Hired about 40 people, or made the hiring decisions | Inflated form of F4 (the number moved to a different noun, and a change of verb) | "I run our hiring loop for backend roles — about 40 interviews last year." Forty interviews, not hires. Running the loop doesn't mean making the final call |

---

## Upgrade menu

- **Web search permission, or Larkfield's values and careers pages pasted in.** Builds a Monday values cheat sheet with the official value names, themes bank H by those names, and grounds K1 in current strategy, turning `[generic]` rows into `[grounded]` ones.
- **A deeper research pass**, up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief, round-format reports and recent org context. It only makes sense once search is available.
- **The full job posting.** Mid-list requirements, such as a named tech stack, compliance or on-call expectations, become new fit-snapshot rows and JD-tagged questions.
- **Interviewer names**, for the director, the two staff engineers, the PM and the VP. Adds an interviewer read, persona weights per panel member, and a reverse question tied to each person's own career path.
- **Your CV.** More evidence rows. F3 and F5 could move from slots to stories you can tell.
- **Your answers to the slots.** Upgrades the rows that ask:
  - how on-call burden was measured: F3, B3, E1
  - whether product was part of the reliability quarter: F7, D2, G1, H2
  - whether any of your systems touched devices: F2, B2
  - what growth work you've done for your six: F5, A5
  - whether anyone on your team led work under you: F1, B1
- **Whether you've worked alongside hardware or firmware people in any capacity.** Sharpens F6, B2 and D4.
- **The recruiter's notes on the Thursday panel format**, such as whether there's a system-design or case segment. Adds a build section for any graded exercise. Usually one email.
- **How many prep hours you have before Tuesday.** Adds a prioritised prep schedule.
- **A tuesday-dossier.md.** The highest-ROI objection would rest on checked evidence rather than an inference from your message, and the prohibited list would be checked against your verified claims.
