I've read the interview-prep playbook and am now writing your pack: one section per round, the case prep, and a values cheat sheet.
I've built your prep pack, with one section per round on 5 December: `Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`.

**What it covers:**
- **Fit check:** every JD requirement is set against your own words, quoted exactly. Your strongest material is the formal complaints log, training tellers on the escalation script, and the monthly spreadsheet your regional manager uses. The gaps you named yourself (contact centre, presenting above regional level) are given back as plain admissions, each followed by a plan.
- **The question to rehearse most (C1, round 2):** "You handled the branch's formal complaints log. This role covers every branch and the contact centre and reports to senior leaders. What gets you from one to the other?" The pack walks through three follow-ups: name the gaps before they do, then stand on what you've actually done.
- **Round 3 case prep:** a 20-minute structure, three positions you can defend (each with a concession to make out loud), and how to stand out from the usual "apologise, escalate, follow up" answer.
- **Values cheat sheet:** one row per value. None of what you've told me yet is a full story, so each row helps you pick a real example and says what to do if nothing fits.
- **Strategy:** each of the four brief points is tied to the role. The move to hubs is where "Neighbours, Not Numbers" comes under most pressure, and the panel's branch managers are going through it themselves.
- **Things not to claim:** a list of easy overstatements to avoid, such as running complaints end to end, coaching supervisors or having written the escalation script.

I didn't search the web. The values page, the recruiter's email and the July brief you gave me already cover what a search would have found.

The quickest improvement is one real complaint story for each value, in your own words. Three questions would also go from "if you did this, say how" to answers built on your actual work: what your spreadsheet tracks, how it counts a complaint as resolved, and whether your formal complaints had regulatory deadlines.

Say the word and I'll play the sceptical hiring manager on C1, the question the pack names as the one to rehearse most.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 5 December 2026: (1) 30 minutes with the recruiter; (2) 45 minutes with the Head of Member Services, your would-be manager, mostly behavioural; (3) 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers:** named by role only. No names have been assigned yet, so this pack has no interviewer read.
**Mode:** loop. One shared fit snapshot, the case build, the strategy brief and the prohibited list, then a mini-pack per round.

---

## How to use this pack

- **Personas** describe *how* a question is asked: a friendly recruiter, a quietly sceptical manager, a values panel. **Types** describe *what* is being scored:
  - **VAL**: whether your past behaviour shows Ashgrove's four published values
  - **EXP**: whether what you say about your own work holds up when they dig into it
  - **JD**: whether you can do the listed job, including the parts you haven't done
  - **CO**: whether you know Ashgrove's strategy and can think at its level
  - **CASE**: a live problem from the role, worked through out loud
- **Provenance labels:** `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is this pack's derivation, with the derivation named; `[generic]` is a common pattern for the role, with no claim about Ashgrove.
- **Answer slots** are instructions for the interview, not questions for you to answer here. Each has two honest branches. Either one counts as a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

Every sentence below about your past comes from your message, quoted exactly. Nothing else in the pack speaks about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end across branches, and the words stay there: "I handled the branch's formal complaints log." Expect a probe on it, since nothing has been inspected behind it. Answer slot: the JD's "end to end" makes a probe on how a complaint moved from logged to closed likely. If any part of that was yours to decide, say which part and how you decided, in your own words. If none of it was yours, or there was no such step, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you've said so yourself. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as something you've done. Never claim contact-centre work, and add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | A monthly complaints spreadsheet touches this requirement, but your material doesn't show whether it tracks volumes or resolution times. Expect a probe. Answer slot: if it tracks volumes, resolution times or both, say which, and how each is counted, in your own words. If it tracks neither, say so plainly and describe what it does track |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says spreadsheet, not Excel. Answer slot: if it's built in Excel, say so and name what you used to build it. If it's built in another tool, name the tool plainly and say how comfortable you are moving to Excel |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training new tellers isn't the same as coaching supervisors: the audience is different and so is the seniority. Words at the quote's own scope: "I trained new tellers on our escalation script." Answer slot: the JD's line makes a probe on coaching people at your own level or above likely. If you've coached someone at or above your level on an escalation, say when and how, in your own words. If you haven't, say so plainly and stay with training tellers on the script |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material doesn't say anything about digital or self-service work. Answer slot: if you've worked with a digital team, or on a member-facing app or online journey, say what you did, in your own words. If you haven't, say so plainly and say what you'd bring from complaints, as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap. Your quote already covers the years and the sector. State it in its own terms, "six years in retail banking, the last three as a branch supervisor", and let the interviewer make the link to customer operations. Expect a probe on it, since it's your word with nothing inspected behind it |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" touches "regulated" but doesn't show it. Answer slot: if the formal complaints you logged had regulatory rules or deadlines attached, say which ones and what you did to meet them, in your own words. If you don't know, or they didn't, say so plainly and stay with the log you handled |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you've already stated, so the pack hands it back: "I haven't presented to anyone above regional level." Then how you'd prepare for it, as a plan and never as something you've done. Your sentence doesn't say you have presented at regional level, so don't claim that either unless it's true, and only in your own words |

**Highest-ROI objection.** F1, F2 and F9 together add up to the question your would-be manager is most likely to ask in some form: *you handled one branch's log, and this job covers every branch plus the contact centre, reporting to senior leaders.* That question is C1 below. Rehearse it until it's boring.

---

## Grounding brief: the July 2026 strategy brief

From the brief the recruiter sent, as summarised in your message. It's about four months old, so it's current. The middle column is this pack's reading, not Ashgrove's words.

| What the brief says (your message) | What it means for this role | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | Complaints about digital journeys are likely to become a bigger share of the volume you report on. That's where the JD's "work with digital teams on self-service journeys" connects | [inferred] from the brief plus the JD |
| "consolidate eight branches into five hubs over 2027" | Your first year would overlap the consolidation. Branch supervisors you coach may be dealing with members whose branch is closing. "Neighbours, Not Numbers" is under the most pressure exactly here | [inferred] from the brief plus the values |
| "launch a small-business lending product in Q1 2027" | A new product in your first months means new complaint types without much history behind them | [inferred] from the brief |
| "the main competitive pressure is app-only banks" | Speed and simplicity are what members can compare Ashgrove against. "Plain Words" and quick resolution times are where a credit union can compete | [inferred] from the brief plus the values |

Vocabulary to use naturally: *members* (never "customers"), *hubs*, *self-service journeys*, *member-owned*.

---

## Graded deliverable: the 20-minute complaint-escalation case (round 3)

The recruiter said the panel includes "a 20-minute case on a complaint escalation." Its content hasn't been shared. The build below works for most escalation cases. Practice it on I1.

**Grounded facts to build on**
- F1: "I handled the branch's formal complaints log". You know what a formal complaint looks like from the logging side.
- F5: "trained new tellers on our escalation script". You know an escalation script from the teaching side.
- F3: "I built the monthly complaints spreadsheet our regional manager uses". You know what reporting needs to capture.
- The four values, by name, are the scoring sheet.

**A 20-minute shape** `[generic]`: clarify (2 min) → the member's position (3) → contain it today (4) → who keeps hold of it (3) → what you tell the member, in plain words (3) → what the escalation tells you about the system (3) → close on the member (2).

**Three theses you can defend, each with a concession you must make out loud**

| Thesis | Concession | Value it lands |
|---|---|---|
| T1. Name one person who keeps hold of the complaint from the moment it's escalated, and tell the member who that is | Sometimes the right owner isn't at the branch, for example a specialist team. Ownership can pass on, but it only passes with a warm handover, never a referral | Own the Fix |
| T2. Tell the member what happens next and when, in words they won't need explained twice | Plain words can't override anything a formal complaint response has to contain. Check what the required wording is before you simplify it | Plain Words |
| T3. Treat each escalation as a signal. Log it so the monthly report shows whether the same thing keeps happening | In a 20-minute case the member in front of you comes first. The pattern work is the last few minutes, not the first | Members First, Always |

**Differentiation.** Most prepared candidates will say "apologise, escalate, follow up." Go further: name the single owner (T1), and say what the escalation tells the branch. If the case involves a branch moving into a hub, say how the member keeps a local point of contact. That's "Neighbours, Not Numbers" during the consolidation.

**The anti-pick.** Don't promise an outcome, refund or goodwill payment before the facts are known. You can say you'd hold back on that, and why: a promise the fix can't keep is the second complaint.

**Close.** No close was named. End on the member: what they hear, from whom, and by when.

---

## Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through", logistics | High. A recruiter screen is mostly this, and casual questions still get scored | A 90-second arc you've practised out loud (A1). Treat every "so, why us?" as scored |
| Skeptic (light) | Checks for knockouts: the contact centre, Excel, the step up | Medium. The JD lists requirements a recruiter can tick off, and F2 and F9 are visible | Give the stated gaps back in your own words (F2, F9) with a plan. Never bluff |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | 90 seconds, roughly: "Six years in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." Then why this role, in your own words. Stop there and let them choose where to dig | F7, F1, F5 and F3 are the whole of your relevant material, and the arc puts them in the order the JD asks for them. EXP because whatever they pick from it becomes the next question |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Use one thing from Ashgrove's own material, such as member-owned (JD) or a value by its exact name, and one from the strategy brief. Answer slot: give your actual reason for wanting a credit union in your own words. If it's mainly this role rather than credit unions, say that plainly | Recruiters check motivation early. CO because they're testing whether you know the organisation |
| A3 | "What are you looking for on salary?" | JD | [grounded] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Every screen covers pay. JD because it's the listed job's terms |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period | Standard screen check. JD because it's the start date for the listed job |
| A5 | "The role covers branches and the contact centre. Where are you based, and does travel work for you?" | JD | [grounded] | Logistics slot: give your actual location and any travel limits, in your own words | "Across branches" in the JD makes travel a fair question. JD for the same reason |
| A6 | "Why are you looking to leave?" | EXP | [grounded] | Logistics slot: give your own reason for leaving, in your own words, short and forward-looking | Asked in almost every screen. EXP because it's about your own history |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then one sentence of plan, such as asking to sit in with the contact-centre team early, said as something you'd do. Don't apologise twice | F2 is the most visible gap against the JD's first line. Answering it cleanly at the screen stops it becoming a knockout |
| B2 | "This would be a step up from branch supervisor. Why now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Hold the facts at their own scope: "six years in retail banking, the last three as a branch supervisor." Answer slot: give your actual reason for moving up now, in your own words | F7 is the base of the question. EXP because it tests your story's consistency |
| B3 | "How are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot (F4): if it's built in Excel, say so; if it's another tool, name it plainly | F3 and F4 rest on one sentence, so the recruiter's tick-box needs that sentence ready. JD because it's a listed requirement |

### Reverse questions: round 1

| Question | Why it lands |
|---|---|
| "How does the panel score against the four values? Is there a format I should know about?" | The recruiter said the panel is the values round, and asking shows you've read the process |
| "Is the 20-minute case given on the day, or in advance, and in what form?" | It directly shapes how you prepare the deliverable |
| "What would success look like in the first six months?" | It gives you language to reuse with the Head of Member Services |
| "Does this role work mostly with the Head of Member Services, or also day to day with the digital teams?" | It ties to the JD's self-service line and shows you read the whole posting |
| "What's the timeline after 5 December?" | A practical question, and recruiters expect it |

---

## Round 2: Head of Member Services (your would-be manager), 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quietly probes the scope jump: one branch's log versus everything, end to end | Highest. A hiring manager is reducing risk, and F1, F2 and F9 are where the risk sits | Rehearse C1 until it's boring. Give the stated gaps back with a ramp plan |
| Values / Behavioral | "Tell me about a time" questions | High. The recruiter said "mostly behavioural" | Story selection from your real complaints work, using "we" for context and "I" for your part. Use the honest branch when nothing fits |
| Case / Strategist | Short live problems drawn from the strategy | Medium. Hiring managers test the roadmap, and the strategy brief is public to you | Clarify, then structure, then use Ashgrove's own words (hubs, self-service) |
| Pressure | Time-boxed "why you" | Lower. It isn't signalled, but a manager hiring into a step-up role may test composure | Pause, restate, hold through two follow-ups, then concede specifically |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You handled the branch's formal complaints log. This role owns complaints across every branch and the contact centre, and reports to senior leaders. What gets you from one to the other?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses"; "trained new tellers on our escalation script" | **Highest-ROI rehearsal in this pack.** Name the limit before they do: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then hold on only what you've said: "I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." Then a plan, said as a plan. *Follow-up 1, "So you've never seen the contact-centre side?"*: "That's right. I'd want to sit with that team early." *Follow-up 2, "And senior leaders?"*: "I haven't presented above regional level. I'd ask what format the monthly report goes up in and rehearse it." *Follow-up 3, "Why take the risk?"*: go back to the three quoted facts and add nothing. Answer slot (F1): if any part of how complaints moved from logged to closed was yours to decide, say which part. If none of it was, say so and stay with the log | F1, F2 and F9 together are the scope objection, and this manager owns the scope. JD because it scores the listed requirements against your evidence. Deepest because it will come up in some form |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one stated gap. Don't name a fake weakness. Either "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level." Then what you'd do in your first month, as a plan | Skeptic stem. F2 and F9 are the honest answers, and choosing one shows calibrated candour |
| C3 | "Tell me about a formal complaint you'd handle differently now." | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint from the log where you'd now do something differently. It needs what happened, what you did, and what you'd change. Keep "I" to what was yours. If no such time comes to mind, say so plainly, then talk about how the log was kept, or how you'd handle a repeat | F1's quote is the pool for this question. EXP because it tests what was actually you |
| C4 | "You'd be coaching branch supervisors, the role you've held. How would that work?" | JD | [grounded] "the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | "I trained new tellers on our escalation script," and you've been in the supervisor's seat for the last three years. Answer slot (F5): if you've coached a peer or someone senior on an escalation, say when and how. If you haven't, say so plainly and describe how you'd adapt from teaching tellers, as a plan | F5 is the gap between the audience you've trained and the one you'd coach. JD because it's a listed duty |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you escalated something you couldn't fix yourself." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: choose a real escalation. It needs the problem, why it was beyond you, who you passed it to, and whether you kept track of it afterwards. That last beat is "Own the Fix". If no such time comes to mind, say so plainly, then walk through how the escalation script you trained tellers on is meant to work | "Own the Fix" is the published value most tied to escalation. VAL first, EXP delivery |
| D2 | "Tell me about a time you explained a decision to a member that didn't go their way." | VAL | [generic] | Selection scaffold: it needs the decision, what you said, and how you checked they understood. That's "Plain Words". If no such time comes to mind, say so plainly, then say how you'd approach it | "Plain Words" is published and behavioural rounds probe it. There's no quote for it, so the guidance is a scaffold |
| D3 | "Tell me about training someone where it didn't land first time." | EXP | [grounded] "trained new tellers on our escalation script" | Story map on F5: you trained new tellers on the escalation script. Answer slot: if a teller struggled with it and you changed how you taught it, say what you changed. If that didn't happen, say so plainly and describe how you trained them | F5 is the evidence closest to the coaching duty. EXP because it tests the detail behind the quote |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Complaints from members at a branch that's about to move into a hub have doubled in a month. What do you do in your first two weeks?" | CASE | [grounded] | Clarify: what are the complaints about, and through which channel? Then separate the causes: the move itself versus service during the move. Contain it: one owner per complaint. Report it: show the trend in the monthly report. Name one risk, which is the complaint volume hiding a single fixable cause | It comes straight from the brief's "consolidate eight branches into five hubs over 2027". CASE because it's a live problem from the role |
| E2 | "We're moving 40% of service to digital channels by 2028. What does that mean for complaints?" | CO | [grounded] | Structure: new complaint types (journeys that fail), new routes for complaints (in-app), and the reporting split by channel. Say you'd work with the digital teams early, as the JD says. Answer slot (F6): if you've worked with a digital team, say what you did; if you haven't, say so plainly | The brief's headline target. CO because it tests whether you can think at strategy level |

### Bank F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Sixty seconds: why you over someone who's run a contact-centre complaints team?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Pause. Concede first: "I haven't worked in a contact centre." Hold: "six years in retail banking, the last three as a branch supervisor, and I handled the branch's formal complaints log." Say why the branch side matters during the move to hubs, as your view rather than a claim about your past. Don't fold if they push a second time: repeat the same facts more calmly | F2 is the comparison a manager will make. Practise holding then conceding |
| F-2 | "Your spreadsheet. Would it stand up to questions from senior leaders?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; "I've never presented to anyone above regional level" | "I built the monthly complaints spreadsheet our regional manager uses. I haven't presented to anyone above regional level." Answer slot (F3): say what it tracks and how each figure is counted. If you don't know how a figure is counted, say so plainly. Name the figure you'd defend least before they ask | F3 and F9 meet here. EXP because it tests your own artefact |

*(IDs F-1 and F-2 have a hyphen so they don't clash with the fit-snapshot rows F1 to F9.)*

### Reverse questions: round 2

| Question | Why it lands |
|---|---|
| "How do you expect the move to five hubs to change the complaints picture during 2027?" | It shows you've read the brief and are thinking about your first year |
| "What would you want to see in the first monthly report from me?" | It gives you their definition of good, and it touches F9 without claiming anything |
| "Who are the senior leaders the monthly report goes to, and in what format?" | A practical question that turns F9 into a plan |
| "Where do you see the most friction, if any, between branches and the contact centre on complaints?" | It's the JD's "end to end" in their words, and it doesn't assume a problem exists |
| "How will the small-business lending launch in Q1 2027 feed into complaints handling?" | It uses the brief. New products bring new complaint types |
| "Who would I work with in digital on self-service journeys?" | It's a JD line, and it shows you'd look for that relationship early |

---

## Round 3: Panel of two branch managers, 60 minutes, values round plus the 20-minute case

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One question per value, scored | Highest. The recruiter said "they score against the four values" | Have one story or honest branch ready per value (cheat sheet below). Say the value's name only if it fits naturally |
| Case / Strategist | The 20-minute escalation case | Certain, because the recruiter declared it | The deliverable build above. Clarify first and think out loud |
| Peer Evaluator | "What would you need from my branch?" | High. These managers' supervisors are the people you'd coach, and their branches are going through consolidation | Reciprocity: what you'd bring them, not just what you'd need |
| Data-Driven Prober | "How do you count a resolution?" | Lower. Branch managers read the monthly reports | Know exactly what your spreadsheet counts (F3), or say plainly that you don't |

### Values cheat sheet

Ashgrove's values page, as you copied it on 26 November 2026. None of your quoted sentences carries a full story yet, so each row is a selection scaffold. The upgrade menu explains how to turn them into mapped stories.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view | Nearest material is F1, "I handled the branch's formal complaints log". Scaffold: pick a complaint where you weighed what the member needed against what was easier for the branch, and say what you chose. If no such time comes to mind, say so plainly, then say how you'd decide |
| Plain Words | If it needs explaining twice, it was written wrong | Nearest material is F5, "trained new tellers on our escalation script". Scaffold: pick a time you made something simpler for a member or a colleague to understand, and say how you could tell it had worked. If no such time comes to mind, say so plainly, then say how you'd approach it |
| Neighbours, Not Numbers | Each branch belongs to its town | Nearest material is F7, "6 years in retail banking, the last 3 as a branch supervisor". Scaffold: pick a time local knowledge of a member or the town changed what you did. If no such time comes to mind, say so plainly, then say what it means to you during the move to hubs |
| Own the Fix | Whoever finds the problem keeps it until it's solved | Nearest material is F3, "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: if you built it because you spotted a problem, say what the problem was. If not, say so plainly and pick another time you followed something through to the end. If none comes to mind, say how you'd do it |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell us about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Use the cheat sheet's Members First row. Context in "we", your part in "I". Give the honest branch if no story fits | "Members First, Always" is scored. The phrase in the question comes from the value's own wording |
| G2 | "Tell us about a time something had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Use the Plain Words row. Answer slot: if you changed how you explained the escalation script to tellers, say what you changed. If you didn't, say so and pick another time, or give the honest branch | The question takes "explained twice" straight from the value |
| G3 | "How does a branch stay part of its town when it becomes a hub?" | VAL | [grounded] | Your view, not a past claim: a named local contact, plain-words communication before the change, and complaints from that branch tracked separately. Answer slot: if you've seen a branch change affect members locally, say what you saw. If you haven't, say so | "Neighbours, Not Numbers" meets the brief's consolidation. These managers are living through it |
| G4 | "Tell us about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Use the Own the Fix row. The beat that scores is that you kept hold of it. Don't claim an outcome you didn't see through | "Own the Fix" in its own words. The spreadsheet is your nearest material, used only through the slot |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If you were coaching my supervisors on escalations, what would you need from me, and what would you bring?" | JD | [grounded] "the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Bring: you've been a branch supervisor for the last three years and you trained new tellers on the escalation script. Need: time with their supervisors, and their view of where escalations go wrong. Say it as asking, not as already knowing | F5 and F7 are your relevant material. Reciprocity is what these peers are scoring |
| H2 | "If my branch were merging into a hub next year, how would you help rather than add to my workload?" | CASE | [grounded] | Principles rather than pretending to know their branch: a single owner per complaint, a short monthly view of their branch's complaints, and no new forms. Ask what they'd want | It's built from the brief's consolidation line. Asked hypothetically, so it presumes nothing about their branch |
| H3 | "When a complaint turns out to be the branch's fault, how do you handle it with the branch manager?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: a time a complaint pointed at your own branch, what you said, and to whom. If none comes to mind, say so plainly, then say how you'd raise it: privately first, facts first, then the fix | Peers test how you disagree, and "Own the Fix" is underneath. F1's log is the pool to draw from |

### Bank I: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | Practice case: "A member comes into the branch upset that a complaint they made by phone three weeks ago has had no reply. They want it escalated today. Take us through it." | CASE | [generic] | Run the 20-minute shape from the deliverable section. Clarify what was logged and where. Acknowledge it in plain words. Name one owner today. Give the member a date. Then the pattern: why a phone complaint went quiet between channels. Make each concession aloud | A practice case, not Ashgrove's. It sits at the branch and contact-centre seam the JD names |
| I2 | "A supervisor escalates every complaint to you, to be safe. What do you do?" | CASE | [grounded] | Clarify why: confidence, unclear rules, or a past bad experience. Coach rather than take over: agree the triggers, review a few together, step back. Measure it by fewer unnecessary escalations without missing any that should have gone up | From the JD's "coach branch supervisors on escalations". A live problem, so it presumes nothing about your past |

### Bank J: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "In your monthly spreadsheet, when does a complaint count as resolved?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: say how a resolution is counted, in your own words. Say what the figure is sensitive to, and which assumption behind it you'd defend least. If you don't know how it's counted, or the spreadsheet doesn't record resolutions, say so plainly | F3 is your one artefact, so a prober will start there. EXP because it tests whether you know your own numbers |
| J2 | "How would you know whether escalation coaching is working?" | CASE | [grounded] | Pick two or three measures, such as escalations per branch, time to resolve escalated complaints and repeat complaints. Name the weakness of each: fewer escalations could mean under-escalating | From the JD's coaching and monthly-reporting lines. A design question, not a claim about your past |

### Reverse questions: round 3

| Question | Why it lands |
|---|---|
| "What could someone new in this role do in their first month that would really help your branches?" | Reciprocity, which is what peers score |
| "What do your supervisors find hardest about escalations today?" | It tells you what your coaching would need to fix |
| "When an escalation goes well in your branch, what does it look like?" | It shows you want their standard, not just yours |
| "How are you keeping each branch part of its town through the move to hubs?" | It uses the "Neighbours, Not Numbers" value and the consolidation together. Ask it with care, since it affects them directly |
| "Where do member letters already use plain words well, and where not yet?" | It turns "Plain Words" into a real question about their work |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | C1, C3, F-1, B1, I1 |
| Report monthly on complaint volumes and resolution times | J1, F-2, E1 |
| Coach branch supervisors on escalations | C4, H1, I2, J2, D3 |
| Work with digital teams on self-service journeys | E2 |
| 4+ years in financial-services customer operations | A1, B2 |
| Experience handling regulated complaints | C3. The F8 answer slot rides on C1 and I1. No standalone question, because your material doesn't establish it, and the slot is the honest rehearsal |
| Confident presenting to senior leaders | C1, C2, F-2 |
| Comfortable with Excel reporting | B3, F-2 |

---

## Prohibited claims

This pack won't coach you to say any of the following.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says the branch's log, not the process. C1's slot stays inside the log |
| Has worked in, or with, a contact centre | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, executives or a board | A negative you stated, F9 | "I haven't presented to anyone above regional level." No slot |
| Has coached supervisors | Inflated form of F5 | F5's quote at its own scope: you trained new tellers on the escalation script. C4's slot asks only about coaching at your level or above |
| Wrote or designed the escalation script | Inflated form of F5 | F5's quote: "our escalation script", which you trained people on. Your material doesn't say who wrote it |
| Runs regional complaints reporting | Inflated form of F3 | F3's quote: you built the spreadsheet, and your regional manager uses it. Your material doesn't say you report on it to the region |
| Has handled regulated complaints under named rules | Inflated form of F8 | F1's quote: "formal" complaints. Your material doesn't say "regulated". The F8 slot asks what rules applied, and "I don't know" is an honest branch |

---

## Sources

- **Provided documents:** the JD; Ashgrove's values page, pasted by you and copied on 26 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; your summary of the July 2026 strategy brief the recruiter sent; your background, as written in your message.
- **Searches and fetches:** none sent.
- **Dossier:** none present. Everything here is built from your inputs.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values page text you pasted fixes the cheat sheet and bank G, with all four values by name |
| 2. Ashgrove Credit Union interview process, member experience | skipped | The recruiter's email sets out all three rounds, who runs each, the case and the values scoring |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 brief is under six months old and supplies the grounding brief, E1, E2, G3 and H2 |
| 4. Interviewer name at Ashgrove Credit Union | n/a | No names have been assigned, so there's nothing to search. The interviewer read is left out (see the upgrade menu) |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each round, persona weights per panel member, and a reverse question tied to each person's own career path
- **One real complaint story per value**, said in your own words → the cheat-sheet scaffolds and G1, G2, G4 and H3 become mapped stories
- **What your monthly spreadsheet tracks and how it counts resolutions** → F3 and F4 rows, and J1, F-2 and B3, move from answer slots to story-mapped answers
- **A redacted copy or screenshot of that spreadsheet** → F3 and F4 confidence can rise from medium to high, since a working report is the artefact this field keeps
- **Whether your branch's formal complaints had regulatory rules or deadlines** → F8, C3 and the case build can speak to "regulated" directly
- **Your CV** → evidence rows can quote dates, titles and employers, and the fit snapshot can carry more than one sentence per requirement
- **How much prep time you have before 5 December** → a prioritised prep schedule tied to question IDs
- **The full strategy brief text, rather than your summary** → the grounding brief can quote Ashgrove's own wording and figures
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent news, leadership context and any public reports on Ashgrove's interview process
- **A `tuesday-dossier.md`** → a record of verified evidence and the objections to rehearse, carried between sessions
