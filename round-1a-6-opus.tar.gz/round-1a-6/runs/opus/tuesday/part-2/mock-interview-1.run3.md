Quick update: I've loaded the mock-interview playbook and its rules. Next I'll run a few targeted searches on Northwind's values, interview process and Dan's public profile, then write the pack.
I've built the full mock-interview pack for Priya's 60-minute conversation with Dan. It has 22 questions sorted into seven persona tables, and each row gives the question type, answer guidance and the reason it was included and tagged that way. I couldn't run any web searches, so the pack rests entirely on your notes. That means it has no Northwind values or public profile of Dan beyond what you gave me.

- **Persona weights:** it's built as a peer conversation. The top weights go to the Data-Driven Prober (because Dan calls himself "relentlessly data-driven") and the Peer Evaluator. The Skeptic and Case personas come next, with cases tilted toward pricing to match his background. The Pressure, Conversational and Values personas get lighter coverage.
- **Highest-priority rehearsal: C1.** This is the "no classic sales-ops or quota-setting experience" objection. It sits in Dan's own domain, so he is the person most likely to raise it. The guidance has her concede the gap first, then give what she does have, then a ramp plan.
- **The ~$400M figure:** expect it to be probed hard (questions A1, B3 and E1). The coaching keeps her to "proposed" and "credited with", never "delivered".
- **Fit snapshot:** this table at the top of the pack matches each JD line to her actual words from your notes. There is also a list of claims the pack deliberately won't coach, such as "designed a partner motion" or "set quotas".
- **Biggest improvement:** her actual CV. Right now every bit of evidence quotes your summary of her, not her own sentences. The pack ends with a list of other inputs that would make it stronger.

I can run Priya through a live practice round as the Skeptic on C1. I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document or a page you can share with Priya, I can convert it.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-1-denied-9fbc4570:
- northwind-data_senior-gtm-strategy-lead_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Session:** one 60-minute conversation with **Dan Kovac**, Director of Sales Strategy. He would be a **peer**, reporting to the same VP.
**Built from:** the coach's notes (JD highlights, candidate summary, interviewer notes, research note). The web searches were refused, so nothing here comes from outside research. See Sources.

---

## How to use this pack

Each question is tagged on two axes. The **persona** is how the question will be asked: the register, the pace, the follow-ups. The **type** is what is being scored. Rehearse both. The same content asked as a friendly aside and asked as a time-boxed challenge needs different delivery.

| Tag | What it scores |
|---|---|
| **VAL** | Whether past behavior shows the values the company publishes, not generic virtue |
| **EXP** | Whether the claims in Priya's background hold up under scrutiny, and what was actually hers |
| **JD** | Whether she can do the listed job, gaps included |
| **CO** | Whether her homework on Northwind's strategy and competition goes deep enough to think at its altitude |
| **CASE** | Structure and reasoning on a live problem from the role |

- **Guidance is scaffolding, not a script.** Priya should say it in her own words. Every quote in a Provenance cell is the exact sentence the guidance rests on. If her real answer is smaller than the scaffold, she gives her real answer.
- **Answer slots** are instructions for the interview, not questions for now. Each one has two honest branches, and either branch passes.
- **Question IDs** are lettered by persona. **F** is skipped because F1 to F7 are the fit-snapshot rows.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy & ops work and a proposed change. It does not show GTM ownership of a product line, and the words stay at that scope: "Nine years in product strategy and ops at a large consumer-tech company. I proposed a store-surface change that was credited with a roughly $400M ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market decisions likely. If any GTM decisions were hers (who to sell to, how, at what price), she says which ones and how she decided, in her own words. If there were no such decisions, or they were not hers, she says so plainly and stays with the product-strategy work and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | Strong evidence here is a time she found where customers had room to buy more, and what came of it. Answer slot: the JD's land/adopt/expand/renew line makes a probe on account-level or install-base analysis likely. If she did that kind of work, she says where, how, and what it found, in her own words. If she did not, she says so plainly and moves to how she would find the whitespace here (D2's structure) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but nothing has been inspected behind this line, and a self-described data-driven interviewer will test it. She leads with the quote's own terms: SQL and Tableau. Answer slot: the JD's word "independent" makes a probe on an analysis she ran herself likely. If she ran one end to end, she walks through it in her own words. If her SQL and Tableau work was never end to end, or not hers alone, she says so plainly and describes what she did with the tools |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material shows a revenue model used in carrier negotiations, not the design of a partner motion, and the words stay at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks partner-motion design as required, so a probe on what she designed is close to certain. If any part of the partner arrangement was hers to shape (terms, incentives, how partners went to market), she says which part and how, in her own words. If none was, she says so plainly and stays with the model she built and how it was used |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already meets the requirement in different words. She says it without adding anything: "I set annual volume targets with cross-org consensus." Expect a probe on how the consensus was reached. That is A4's slot |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Using AI tools daily touches this requirement but does not show whether it meets it. The derivation: the JD's AI line sits beside Compass, an AI copilot launch (research note), so "AI experience" may mean product or GTM work on AI. Answer slot: if she has worked on an AI product, its pricing or its launch, she says what and which part was hers. If her AI experience is daily use, she says so plainly and says what she uses the tools for, in her own words |
| F7 | Sales-planning and quota-setting fluency, which a sales-strategy peer will expect (role-family requirement, not in the JD highlights) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | Wording cannot close this gap, and it has been stated plainly. Her words: "I don't have classic sales-ops or quota-setting experience." Then how she would learn Northwind's planning cycle, said as a plan and never as past work. Nothing is added to make the gap feel smaller, and the volume targets in F5 are never relabeled as quota-setting |

---

## Reading the interviewer

Everything in this section comes from the coach's notes. The search for Dan's public footprint was refused, so nothing has been added from outside.

| Signal (coach's notes) | Practical implication |
|---|---|
| "Director of Sales Strategy at Northwind", "Priya's PEER, both reporting to the same VP" | He is weighing what this hire adds to his team's work and what it costs them. Expect seam, credit and disagreement probes in a collegial register. Sales planning is his own domain, so F7 is the gap he is best placed to see |
| Profile self-describes as "relentlessly data-driven" | Every number gets probed down to its assumptions, the ~$400M first. She names the weakest assumption before he does, and says "I don't know how that was counted" when that is true |
| "career spine is pricing and monetization roles" | Tilt case answers toward pricing, packaging and unit economics. Compass packaging and the bundling threat are his native ground (D1, B5) |
| "one early-stage-startup chapter" | Builder-style, scrappy answers will land. Expect some skepticism about big-company pace, so ramp plans should be concrete and short-cycle |

**Mirror opportunity, shared vocabulary:** monetization. F4's evidence is "built a partner-level revenue model used in carrier negotiations". Describing that model's mechanics plainly speaks his language without claiming more than the quote. **Shared career jump:** none offered. No fit-snapshot row carries a path that parallels his.

---

## Persona table

Your words establish the loop: one 60-minute conversation with Dan, who would be a peer. So no archetype fallback is used, and no values-style round is detected for this session.

| Persona | How it shows up with Dan | Weight and reasoning | Questions | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | "Walk me through how that was counted", two levels deep | **Top.** Prober is a peer-relationship default, and his "relentlessly data-driven" self-description pushes it higher | A1–A5 | Know what she can and cannot say about how each number was counted. Name the weakest assumption first. Offer to walk through her own analysis end to end |
| Peer Evaluator | Seams, "what do you need from me", credit, disagreement | **Top.** The other peer-relationship default. He shares a VP with this role | B1–B5 | Frame it as reciprocity. Propose principles for the seam rather than claiming to know the org. Disagreement answers show spine and tact together |
| Skeptic | "I don't see sales-ops in your background…" | **Mid.** F7 is a stated gap in his own domain, and F2 and F4 are thin | C1–C3 | Rehearse C1 until it is boring. Build bridges only from quotes, then a concrete ramp plan |
| Case / Strategist | Pricing, packaging and partner problems on Northwind's own priorities | **Mid.** His pricing and monetization background tilts it, and the research note gives real material | D1–D3 | Clarify, set the objective, segment, lay out the approach, name metrics and risks. Challenge one premise per case |
| Pressure | "How much of that was actually you?", "Sixty seconds" | **Low.** Peers rarely run stress interviews, but the ~$400M invites it | E1–E2 | Pause, restate the question, hold through two follow-ups, then concede something specific |
| Conversational | The opener and the AI aside | **Low.** Still scored: the AI plus and Compass make the casual AI question a real one | G1–G2 | A 90-second arc, and the casual AI question treated as scored |
| Values / Behavioral | Generic behavioral probes | **Low.** No values round is detected and no values page is in hand | H1–H2 | Selection scaffolds. Pick stories where the hard truth actually landed |

---

## Question banks

**Highest-ROI prep in this pack: C1**, the sales-ops and quota-setting objection. It sits in Dan's own domain and will come up in some form.

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the sentence at its own scope: she proposed the change, and the uplift was credited to it. She says "credited", never "I delivered". Then four slots, each in her own words: how the figure was counted, what it is sensitive to, the assumption behind it she would defend least (named before Dan names it), and which part was hers. If she does not know how it was counted, she says "I don't know how the attribution was calculated" plainly. That is an honest branch, not a failure. She never offers a baseline or method she could not repeat under a second question | This is F1's headline figure, and a self-described data-driven interviewer will probe any number down to its assumptions. Tagged EXP because it scores attribution, not the size of the number |
| A2 | "Walk me through the partner-level revenue model: what went into it, and how was it used in the carrier negotiations?" | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4. The beats the quote states: a model, built by her, partner-level, used in carrier negotiations. Answer slot: if she can walk the model end to end (inputs, structure, outputs), she does it in her own words. If parts were built by others or cannot be shared, she says so plainly. On how it was used: she says what she saw of it in the negotiations, and if she was not in the room, she says so and stays with the model. She lets Dan draw the monetization parallel rather than asserting it | F4 is the only evidence for the required partner-motion line, and someone with a monetization background will want the mechanics. EXP first because it tests what was hers; JD second because this is the bridge to a required item |
| A3 | "Tell me about an analysis you ran end to end in SQL and Tableau." | EXP, JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold. She picks one analysis where she wrote the queries and built the view herself, and where it changed a decision. The beats: the question, the data, the query logic, what the view showed, and what was decided. If no single analysis fits all of that, she says so plainly, gives the nearest one her experience carries, and says which parts were hers. She should be ready to describe the joins and filters at the level of logic | F3 is a skills line with nothing inspected behind it, and the JD's word "independent" invites exactly this test. Open prompt, themed on the JD line |
| A4 | "How did you set the annual volume targets? What went in, and how did you get the other orgs to agree?" | EXP, JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the targets were annual, she set them, and she did it with cross-org consensus. Answer slot: the JD's cross-functional-influence line makes a probe on how the consensus formed likely. If there was a method behind the targets and a point where an org pushed back, she says what it was and what she did, in her own words. If there was no such point, or the method was not hers, she says so plainly and describes how the targets were set. She does not call this quota-setting (see Prohibited claims) | F5 is the closest thing in her material to Dan's planning domain, so he will press on it. EXP because the scored part is her method, with the JD's influence requirement behind it |
| A5 | "Say Compass launches next quarter. Which three numbers would tell you by Q2 whether its GTM is working, and what would prove you wrong?" | CASE, CO | [grounded] | First, clarify what "working" means against Northwind's priorities: adoption in enterprise accounts, expansion revenue, or margin, given the profitability goal. Then pick three numbers: one leading indicator (activation or depth of usage), one monetization number (attach or expansion), and one guardrail (margin, or cannibalization of an existing product). For each, give the denominator and the threshold she would set before launch. Close with the assumption most likely to break the plan, and name it herself | This is the Prober's register applied to a live metric problem built on the research note's Compass priority. CASE because it presupposes nothing about her past; CO because it uses Northwind's stated priorities |

### B. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Propose principles for the seam rather than claiming to know the org. A working version: Sales Strategy owns the planning engine; this role owns the GTM thesis for the two new product lines; the two teams share how new products show up in targets and comp. Say once, plainly: "I don't have classic sales-ops or quota-setting experience." That is a reason for the planning mechanics to stay with his team. On disagreement, offer one principle: one shared fact base, and if they still disagree, go to the VP together rather than with two decks | This is the defining peer question, and F7 makes the seam easy to draw honestly. Tagged JD because it tests how the role's ownership fits beside his |
| B2 | "What would you need from my team in your first 90 days, and what would you give back?" | JD | [grounded] "skilled in SQL/Tableau" | What she needs: access to pipeline, bookings and install-base data; how current targets treat new products; and a standing slot with his team. What she gives back, as a plan: running her own analysis in SQL and Tableau rather than queuing on his analysts, and sharing every analysis back with his team. She keeps the give list as long as the need list | Peers want to know whether a hire adds to their load or takes some off it. Tagged JD because it scores how she would actually operate in the role |
| B3 | "How do you handle credit when work spans teams? The ~$400M, for example." | EXP, VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's own verbs: she proposed the change, and the uplift was credited to it. Answer slot: if other teams built, shipped or measured it, she names them and what was theirs. If she does not know how the credit was assigned, she says so plainly. "We" for the change, "I" only for the proposal | This is a peer's way of asking E1's question, and the word "credited" in F1 will draw it. EXP because it scores attribution; VAL because it is also about how she shares credit |
| B4 | "Tell me about a time you disagreed with a peer at your level and it got resolved." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold. She picks a disagreement with an equal, not a boss. It needs a named stake, her position, what she gave up and what she held, and a relationship that stayed intact. The volume-targets consensus is the nearest line her material carries; she uses it only if a disagreement really was part of that story, told as it happened. If no such time comes to mind, she says so plainly, then gives the nearest thing her material does carry, or how she would handle it | This is the peer persona's standard disagreement probe, and F5 is the nearest material. VAL because it scores how she disagrees, not what she knows |
| B5 | "The bundling threat makes my reps want to discount, and your new products need price integrity to prove themselves. A big deal comes in asking 40% off. What do you do?" | CASE, CO | [grounded] | First clarify: is the discount on the new product or the core one, is this a land or an expand, and what is the bundler offering? Objective: win the account without setting a price anchor the profitability goal cannot carry. Options: trade price for term or commitment; run the new product as a time-boxed pilot; discount the core product rather than the new one. Close with a rule she would propose to Dan for the next ten deals, not only this one | Pricing is his background, and both the bundling threat and the profitability goal come from the research note. This is the peer seam turned into a live case, so CASE first and CO second |

### C. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background doesn't include classic sales-ops or quota-setting, and our GTM sits on top of a sales-planning engine. Why should I believe you can own GTM strategy here?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "then 9 at a large consumer-tech company in product strategy & ops"; "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | **Highest-ROI prep in this pack.** Four moves. (1) Concede first, in these words: "I don't have classic sales-ops or quota-setting experience." (2) Say what she does have, at the quotes' own scope: "Nine years in product strategy and ops at a large consumer-tech company. I set annual volume targets with cross-org consensus." (3) Name the limit before he does: "Volume targets aren't a quota plan. I'd be learning your planning cycle, and I'd want your team owning it." (4) A ramp plan, said as a plan: sit in on his team's planning cadence for the first month, and rebuild one new-product target from his data in SQL. Follow-up 1, "So how would you set targets for the new products?": a plan, not past work. Follow-up 2, "Then what do you add over a sales-ops hire?": answer slot. She says which GTM-side decisions in her consumer-tech work were hers, in her own words. If there were none, she says so and returns to the product-strategy work and the store-surface proposal, at its scope. Follow-up 3, "Isn't consumer a different motion?": yes, and she says plainly what she does not yet know about land/adopt/expand/renew. What she holds: product strategy and analysis. What she concedes: planning mechanics | F7 is a stated gap that sits exactly in the interviewer's own domain, and F1 and F2 are where the GTM-ownership mandate presses hardest. It will come up in some form. Tagged JD because it scores the role's core requirement |
| C2 | "Land, adopt, expand, renew is a B2B motion. Which part of it have you worked on?" | JD | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | Answer slot (F2). If any of her work touched getting customers to adopt, buy more or renew, in consumer or partner contexts, she says what it was and which part was hers, in her own terms rather than the JD's. If none did, she says so plainly and moves to how she would find the whitespace here, using D2's structure. She does not relabel consumer metrics as land or expand | F2 has no evidence, and the JD's B2B motion vocabulary invites this probe. Tagged JD because it tests a listed responsibility |
| C3 | "Partner-motion design is a hard requirement. What have you actually designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The hold is only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot (F4): if any part of the partner arrangement was hers to shape, she says which part and how. If none was, she says so plainly; that is a stated limit, not a confession. Then she offers how she would design one here (D3). Through two follow-ups she holds by coming back to the model, never by adding to it | F4 is the JD's one marked requirement, and her bridge to it is adjacent work. Tagged JD because it scores that requirement directly |

### D. Case / Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass: do we bundle it into existing tiers, sell it as a paid add-on, or price on usage? How would you decide?" | CASE, CO | [grounded] | Clarify: who buys it, how the current tiers are structured, what the bundler offers in AI, and the cost to serve each query, since profitability is a priority. Objective: which of the three priorities Compass serves first. Segment: enterprise-expansion accounts versus smaller ones, existing customers versus new. Trade-offs: bundling defends against the bundler but gives margin away; an add-on monetizes but slows adoption; usage pricing tracks cost but can surprise enterprise buyers with their bills. A hybrid (an included allowance plus paid tiers) is a common pattern, offered as an option and not as Northwind's practice. Metrics: attach rate, depth of usage, gross margin per account, and churn in the accounts the bundler targets. Challenge one premise: is Compass a product to sell, or a feature that keeps customers? | Pricing and packaging are Dan's home ground, and Compass, profitability and the bundling threat all come from the research note. CASE because it is a live problem; CO because it uses Northwind's own priorities |
| D2 | "I give you our accounts, opportunities, product-usage and contracts tables. Find the expansion whitespace for one of the new product lines. Walk me through the query and the view." | CASE, JD | [generic] | Define whitespace: accounts that show fit signals but do not own the new product. Fit signals: usage of an adjacent product, firmographics, renewal timing. Logic: join accounts to the new product's subscriptions and keep the accounts with none; rank them by a propensity proxy times account size; tag each by land/adopt/expand/renew stage. The view: segment by stage with counts and potential ARR, drilling down to an account list for reps. Validate against reps' instincts on ten accounts. Weakest assumption: that adjacent usage predicts need for the new product, and she names it herself | This covers two JD lines (whitespace, independent SQL and Tableau) in a form a data-driven peer can test live. `[generic]` because the table names are a pattern, not Northwind's schema |
| D3 | "A much larger vendor bundles a competing capability for free. Design the partner motion for one of our new product lines that holds up against that." | CASE, JD, CO | [grounded] | Clarify the partner types in play (system integrators, resellers, cloud marketplaces, technology alliances) and where the bundler is strongest. Objective: reach and credibility where bundling hurts most. Structure: which partners, what is in it for them (margin, attached services, co-sell credit), rules of engagement with direct sales (that is Dan's seam, so name it), enablement, and a partner-economics model by tier. Metrics: partner-sourced versus partner-influenced pipeline, and time to first deal. Risks: channel conflict, and a margin hit against the profitability goal. Challenge one premise: does competing with bundling call for partners at all, or for packaging? | This is the required partner-motion line delivered as a case, set against the research note's main competitive threat. CASE first because it is a live design problem |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then restate the question. Hold: "I proposed the store-surface change, and the uplift was credited to it." Follow-up 1, "So you just had the idea?": she holds. Answer slot: if she did more than propose it, she says what, in her own words; if proposing was her part, she says so plainly. Follow-up 2, "Who else would claim it?": she concedes specifically, naming what others owned if she knows, or saying she does not know how the credit was assigned. She never trades "proposed" up to "delivered" to end the pressure | This is F1's figure under a stress probe, and it is the line Dan is most likely to push hard. EXP because the score is precise attribution under pressure |
| E2 | "Sixty seconds: why you over someone from our own sales-strategy team?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience." | Sixty seconds, and no attack on the internal candidate. Three beats from the quotes: two years of strategy consulting, then nine in product strategy and ops; analysis she runs herself in SQL and Tableau; and the concession, said inline: "I don't have classic sales-ops or quota-setting experience. An internal hire does, and I'd lean on Dan's team for it." Then what the emerging-products role needs beyond core planning, offered as her read of the JD. Hold through two pushes, and stop at sixty seconds | A peer with an internal bench may well ask this. JD because it scores fit to the role, and the time box tests composure |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "11 years"; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: eleven years, two in strategy consulting, nine in product strategy and ops at a large consumer-tech company. Then two lines that point at this role, both at the quotes' scope: the partner-level revenue model used in carrier negotiations, and the store-surface change she proposed, credited with a ~$400M ARR uplift. Answer slot: her real reason for moving to B2B and emerging products, in her own words, not borrowed from this pack. End by handing back to Dan | The opener is nearly certain and still scored, for economy above all. EXP because it previews the claims every other bank probes |
| G2 | "What are you actually playing with in AI these days?" | JD, CO | [inferred] "uses AI tools daily" | Treat it as scored: AI is a plus in the JD, and Compass is a company priority. Answer slot (F6): she names the tools and what she uses them for, in her own words. One concrete use in her analysis work beats a list. If she has done AI product or GTM work, she says so; if not, she does not imply it. She can bridge to Compass from a user's chair: "As a daily user, what I'd want from a copilot is…", followed by her own view | A casual question about a hot JD topic is still scored. `[inferred]` because F6 is low confidence and the reading of the JD's AI line is a derivation |

### H. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. It needs a named audience, the truth, why it was unpopular, the data that carried it (this is the interviewer's language), and how it actually landed. "We" for context, "I" for her contribution. If no such time comes to mind, she says so plainly, then gives the nearest thing her experience carries, or how she would handle it | A standard behavioral probe a peer may use. `[generic]` because the persona stem themes it and no Northwind values page is in hand |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. It needs the metric, the customer interest it conflicted with, her call, and what it cost. If no such time comes to mind, she says so plainly, then gives the nearest thing her experience carries, or how she would handle it | This tests judgment where metrics and customers conflict, which matters to a data-driven interviewer. `[generic]` for the same reason as H1 |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C1, D1, D3, E2 |
| "identify whitespace across land/adopt/expand/renew" | C2, D2 |
| "run independent analysis in SQL and Tableau" | A3, D2, B2 |
| "partner-motion design experience required" | A2, C3, D3 |
| "strong cross-functional influence" | A4, B1, B4 |
| "AI experience a plus" | G2, D1, A5 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "What could someone new do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows she is thinking about his load, not only her own needs |
| R2 | "You've spent most of your career in pricing and monetization. How are you thinking about pricing Compass against a bundled alternative?" | It is tied to his own career path and puts him on home ground. It turns the interview into a conversation between peers |
| R3 | "Having done an early-stage chapter, what carries over when you launch new products inside a 3,000-person company, and what doesn't?" | It is tied to his startup chapter, and the answer tells her how much room for builder-style work the role has |
| R4 | "Where do targets for new products get set today, and where has that caused friction?" | It goes straight at the seam (B1) and at F7. The answer shows her exactly what she would need to learn |
| R5 | "When enterprise expansion, Compass and profitability conflict for a new product line, which one usually wins?" | It uses the research note's three priorities and shows she can think at the company's altitude |
| R6 | "What's the one number you look at first every Monday?" | It speaks to his self-described data-driven style, and the answer tells her what he will judge her work by |

---

## Prohibited claims

These are claims the pack will not coach. They are built from the fit snapshot and bind every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for Priya: the material shows product strategy & ops and a proposal. C1's and E2's slots stay inside it |
| Drove or delivered the ~$400M ARR uplift | Inflated form of F1's second quote | "proposed a store-surface change credited with a ~$400M ARR uplift", at its own scope: proposed, and credited. A1, B3 and E1 stay inside the quote |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The material shows a model used in negotiations. A2's and C3's slots ask only which parts were hers to shape |
| Led or ran the carrier negotiations | Inflated form of F4 (the model was used in them) | "built a partner-level revenue model used in carrier negotiations". A2's slot covers what she saw of them |
| Owned the volume plan on her own, or set quotas | Inflated form of F5 | "set annual volume targets with cross-org consensus", with the consensus kept in and the word "quota" kept out |
| Has AI product or AI GTM experience | Inflated form of F6 | "uses AI tools daily". G2's slot stays inside it |
| Has set quotas or run sales ops | Negative stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |

---

## Sources

- **Provided:** the coach's notes, covering the role, the JD highlights, the candidate summary, the interviewer notes and the research note on priorities and competition.
- **Searches sent:** `"Northwind Data" company values`: refused. `"Northwind Data" interview process strategy role`: refused. `"Dan Kovac" "Northwind Data" sales strategy`: refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. It would have themed the H bank with Northwind's own values instead of generic stems |
| 2. `Northwind Data interview process GTM strategy` | unavailable | The call was refused. It would have shown whether a values-style round exists elsewhere in the loop. This session's structure already comes from your words |
| 3. `Northwind Data strategy` / recent news | skipped | The research note already supplies the three priorities and the bundling threat, which drive the CO and CASE questions |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. It would have checked and extended his public footprint (talks, posts) for the interviewer read and R2 and R3 |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Priya's actual CV** → her own sentences replace the coach's summary in every evidence cell. Lines like the ~$400M and the partner model may carry more scope than this summary shows, or less.
- **The full JD text** → mid-list requirements (tools, methods, named partners) become fit rows and questions. The highlights may have dropped some.
- **Priya's answers to the answer slots** → how the ~$400M was counted and credited would upgrade A1, B3 and E1; what she shaped in the partner arrangement would upgrade A2, C3 and F4; any account or expansion work would upgrade C2 and F2.
- **An inspectable artifact** → a sanitized version of the partner revenue model, or the store-surface proposal memo, would raise F1 and F4 from medium to high.
- **Allowing web search** → targets 1, 2 and 4 run. Northwind's published values would theme the H bank, and Dan's public footprint would sharpen the interviewer read and R2 and R3.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a Northwind strategy brief, the bundling vendor's moves and recent org context, which would make D1, D3 and B5 more specific.
- **Recruiter or HR guidance** → coverage of any stated focus areas or pre-declared deliverables.
- **Prep time available** → a prioritized prep schedule.
- **A `tuesday-dossier.md`** → evidence verified ahead of time, plus an objection list derived from that evidence rather than inferred, for this pack to build on.
