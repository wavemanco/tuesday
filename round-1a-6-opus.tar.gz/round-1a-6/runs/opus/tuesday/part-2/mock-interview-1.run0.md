Building the pack now: running a few targeted searches on Northwind Data and Dan Kovac, then writing it.
I've built Priya's prep pack: 21 questions in seven persona banks, each with a type tag, answer guidance, and the reasons for including and categorizing it.

**Web research didn't happen.** All four searches were refused because web search isn't permitted in this session. So the company strategy comes from your research note, unchecked for freshness, and the read on Dan comes from your profile notes. Northwind's published values weren't read, so the two values questions are generic patterns.

**How it's weighted for Dan.** Because he's her peer, and describes himself as "relentlessly data-driven," the banks lead with the number-probing style (5 questions) and the peer-collaboration style (4). The case questions lean on pricing and packaging, since that's his background. The three Northwind cases are built on your research note: the bundling threat, how to price the Compass copilot, and tracking Compass adoption in Tableau.

**The question to rehearse hardest is D1:** "You come from consumer tech and you haven't run sales ops or set quotas. Why should GTM for these products sit with you?" Sales ops and quota-setting are Dan's own territory, so it will come up in some form. The guidance has her name that limit first. She then holds only on what your notes say she did, and gives a plan for getting up to speed.

**On the ~$400M figure.** Dan will probe it twice: how it was counted (A1) and how much of it was hers (E1). Your notes say she "proposed" the change and that it was "credited with" the uplift. The pack keeps her at exactly that wording and leaves how it was counted and what her part was for her to answer. A "Prohibited claims" section lists the inflated versions she shouldn't reach for under pressure, such as "drove $400M" or "designed partner motions."

The pack also includes six questions for Priya to ask Dan, two of them tied to his pricing and startup background. It ends with what more input would improve, like the full job description or her own account of the $400M.

If you'd like, I can run a live drill on D1, playing Dan as the skeptic. I can also save a `tuesday-dossier.md` recording the gaps this prep turned up, for later sessions, or convert the pack to a Word document.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-1-denied-6f02d1e9:
- Northwind-Data_senior-gtm-strategy-lead_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview Prep Pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He would be Priya's **peer**, and both would report to the same VP.
**Format:** one 60-minute conversation (session mode)

---

## How to use this pack

Questions are sorted on two axes:

- **Persona** is how a question gets asked: the interviewer's style and register. Each persona has its own bank, A to G, with the most likely persona first.
- **Type** is what the question is scoring:

| Tag | What it scores |
|---|---|
| **VAL** | Behavioral and values alignment: whether past behavior shows the values the company has published |
| **EXP** | Work-experience deep-dive: whether the claims hold up and what was actually Priya's |
| **JD** | Role and JD: whether she can do the listed job, gaps included |
| **CO** | Company and strategy: homework depth, and whether she can think at the company's level |
| **CASE** | A live problem from the actual role, worked through out loud |

Every question row has a **Provenance** label:

- `[grounded]`: traces to something you gave me. Quoted coach's-notes lines sit next to the label.
- `[inferred]`: derived from those materials. The derivation is named.
- `[generic]`: a common pattern for this kind of role, with no fact about Northwind or Priya.

Two more terms:

- An **answer slot** is the part of a guidance cell where only Priya can supply the answer. The pack names the likely probe and gives two honest branches. It never fills in her answer.
- **Guidance is scaffolding, not a script.** Every claim about her past stays inside the sentences you wrote. Rehearse in her own words.

---

## Fit snapshot

The requirements are the JD highlights from your message (the full JD text was not supplied). The evidence is your notes on Priya, quoted word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm" — the coach's notes, "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy and ops, not GTM strategy for new B2B lines, and the words should stay there: "Nine years in product strategy and ops at a large consumer-tech company, after two years in strategy consulting." Answer slot: the JD's ownership line makes a probe on go-to-market work likely. If any launch or GTM decision was hers to make, she should say which one and how she decided, in her own words. If none was, she should say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [inferred] | discovery | Proposing a change that grew revenue touches on finding opportunity. Whether it reaches lifecycle whitespace analysis is not shown. Answer slot: if the proposal came from her own analysis of where revenue was being left on the table, she should say what she looked at, in her own words. If it did not, she should say so and describe how the proposal came about |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. It is a self-reported skill with nothing inspected behind it, and Dan will want to see it in action (A3, A5). She should lead with the skill on its own terms and let the live case do the proving |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in partner negotiations is adjacent to designing a partner motion. It is not the same work. Her words stay at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: since the requirement is listed as required, expect a probe on design. If any part of the partner terms, structure or program was hers to shape, she should say which part, in her own words. If none was, she should say so plainly and return to the model and how it was used |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap. The quote already speaks to influence across orgs. Lead with it in its own terms: annual volume targets, set, with cross-org consensus. Expect Dan to ask how the consensus was reached (A4, B3) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Using AI tools every day is a user's view, not AI product or GTM experience. Her words: "I use AI tools daily." Answer slot: if any of that use was building or shipping something for her team, she should say what, in her own words. If not, she should keep it to daily use and how it shapes her view of Compass's buyers |
| F7 | Fluency in sales-ops and quota mechanics that a Sales Strategy peer will expect. This is not in the JD highlights; it comes from Dan's function | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | This is a gap that wording cannot close, and it has been stated. Words: "I haven't done classic sales-ops or quota-setting work." Then how she would get up to speed, said as a plan and never as past experience. There should be no claim to quota or territory work and nothing added to make the gap feel smaller |

---

## Reading the interviewer

Source: your notes on Dan's profile. No public footprint was read, because the searches were refused (see Sources).

| What we know | Source | What it means for the interview |
|---|---|---|
| "Director of Sales Strategy", and Priya's "PEER" under the same VP | your message | He is pricing what she would cost and add to *his* work. Expect questions about the seam between their teams, who owns quota and coverage versus who owns emerging-product GTM, and whether she would reduce or add to his team's load. F7 is his home turf, so she should never bluff it |
| Self-described "relentlessly data-driven" | your message | Every number gets probed down to its assumptions, the ~$400M figure first. She should name the weakest assumption before he does and say plainly what she does not know about how a figure was counted |
| "career spine is pricing and monetization roles" | your message | Pricing, packaging and unit economics are his native language. The cases (C2, C3) lean this way on purpose, and she should frame the Compass and bundling answers in value-metric and margin terms |
| "one early-stage-startup chapter" | your message | Builder stories land well with him. Also expect some doubt about big-company pace ("how fast can you move without the machine?"). This is fair ground for a reverse question about pace (R6) |

**Mirror opportunities:** none offered. Nothing in Priya's evidence carries her side of a career jump that matches Dan's, so the pack does not invent one.

---

## Persona table

The weights start from the default for a **peer** round (Peer Evaluator and Data-Driven Prober on top). They are then adjusted for Dan's stated signals. The loop is set by your words, "a single 60-minute conversation with Dan", so the weights rest on that and not on an assumed company template.

| Persona | How it shows up with Dan | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "Walk me through how that was counted." Two levels of follow-up on every figure | **Highest (5 questions).** Peer default, raised by "relentlessly data-driven" | Know what she can and cannot say about how each number was counted. Name the weakest assumption first. Offer to walk through an analysis end to end |
| B. Peer Evaluator | Where the seams are, "what do you need from me", and credit-sharing | **High (4).** He is a true peer under the same VP | Frame it as give-and-take. Propose principles for the seam instead of pretending to know where it sits. Show both spine and tact when disagreeing |
| C. Case / Strategist | Live GTM problems with a pricing and packaging slant | **Mid (3).** His pricing background, plus the JD's strategy mandate | Clarify, then objective, segments, approach, metrics, risks. Use Northwind's own priorities as the vocabulary. Respectfully challenge one premise per case |
| D. Skeptic | "Consumer tech to B2B data infra, with no sales ops?" | **Mid (3).** F7 and F4 are the visible gaps, and the startup chapter adds doubt about pace | Rehearse D1 until it is boring. Bridge only from quoted evidence, name the limit, and give a concrete ramp plan |
| E. Pressure | "How much of the $400M was actually you?" | **Low (2).** Peers rarely run stress interviews, but a data-driven peer will press on attribution | Pause, restate, anchor on the quote, hold through two follow-ups, then concede exactly what is not hers |
| F. Conversational | The opener and an "AI these days?" aside | **Low (2).** Every 60-minute conversation opens and closes this way | A pre-scripted 90-second arc. Treat the AI aside as scored (it is a JD plus). Never say "I think you've covered everything" when asked for questions |
| G. Values / Behavioral | "Tell me about a time…" | **Low (2).** No values round is named, and Northwind's published values were not read | Choose stories with a real stake. Use "we" for context and "I" for her part, and keep the honest branch ready |

---

## Question banks

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift from the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Beats the quote carries: she proposed the change, and it was *credited with* a ~$400M ARR uplift. "Credited" means someone else did the attributing, so keep that word. Answer slots, in her own words: how the figure was counted, what it is most sensitive to, the assumption behind it she would defend least (say it before he asks), and exactly which part was hers. "I don't know exactly how finance attributed it" is an honest branch, and saying it beats a method she can't repeat under a second question | This is the headline metric on F2, and Dan is self-described as data-driven, so a defend-the-number probe is near-certain. EXP because it tests attribution and what was actually hers |
| A2 | "Your partner-level revenue model: what did it predict, and how did you know it was right?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats: she built the model, and it was used in carrier negotiations. Answer slot: Dan's "relentlessly data-driven" style makes a probe on validation likely. If she checked the model against actual results, she should say how, in her own words. If there was no validation step, or it was not hers, she should say so plainly and return to what the model was built to do and where it was used | F4 is her closest evidence for the partner-motion requirement, and Dan will test the model before accepting it as a bridge. EXP because the model's substance is what is being scored |
| A3 | "Say you have tables of accounts, products owned, seats and usage. In SQL, how would you find expansion whitespace?" | JD | [generic] | A live exercise, with no claim about her past. Define whitespace first: accounts with product A but not B, seats or usage near tier limits, renewals coming up. Then walk through the joins and filters out loud, cohort by segment, rank by an expected-value proxy, and say how she would sanity-check the list with sales before anyone acts on it. End with the decision the output drives | Tests F3 ("skilled in SQL/Tableau") and F2 (whitespace) together. JD content delivered as a case. `[generic]` because Northwind's data model is unknown |
| A4 | "How were the annual volume targets set, and how did you get consensus?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats: annual volume targets, set, with cross-org consensus. Answer slot: Dan's data-driven style makes a probe on method likely. If she used a specific method or model to set them, she should describe it in her own words. If there was no formal method, or the method was not hers, she should say so plainly and describe how consensus was reached. Say nothing about quotas here (see F7) | F5 is her strongest influence evidence, and Dan will test whether "set" means owned or facilitated. EXP because it tests what she personally did |
| A5 | "Design the Tableau view you'd use to track Compass adoption in its first 90 days." | CASE / CO | [grounded] research note: "an AI copilot launch ('Compass')" | Structure: what decision the dashboard serves (expand, fix or price). Then a metric tree: activation, weekly active accounts, depth of use, and attach or expansion among adopters, split into leading and lagging indicators, by account tier. Add one guardrail metric tied to the profitability priority, such as cost to serve. Offer to sketch it. Makes no claim about her past | It puts a live JD skill (F3) on a named Northwind priority, which is the differentiator most candidates miss. CASE delivery with CO grounding |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side. Where's the seam, and what happens when we disagree?" | JD / CASE | [generic] | Propose principles, not a map she can't know yet. His team owns core coverage, quota and territory. Emerging-products GTM owns new-line strategy. The shared zones are attach incentives, pricing and packaging interplay, and partner overlap. On disagreement: agree on the data first, write down who decides, and take it to the shared VP only as a last step. Ask him where the seam hurts today | Peer-relationship default plus F5. JD because cross-functional influence is listed, with CASE delivery since it is a live scenario |
| B2 | "What would you need from my team in the first 90 days, and what would you give us back?" | JD | [generic] | Give and take, in equal measure. Needs: the current coverage and capacity model, segment definitions, and a rep's-eye view of where new products stall. Gives back: analysis of the new lines his team can reuse, early warning on how new products affect quota, and a shared view of the account data. Ties to F7: learning his model is part of her ramp, and she says so | It tests whether she adds to his load or reduces it, which is what a peer is really scoring. JD because cross-functional influence is a listed requirement |
| B3 | "Tell me about a time you got several orgs to agree on something they didn't start out agreeing on." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, set, with cross-org consensus. Those are the beats the quote states, told in her own words. Answer slot: the JD's influence line makes a probe on the disagreement likely. If the orgs started apart, she should say where and what part of bringing them together was hers. If they did not, she should say so plainly and stay with how the targets were set | An open prompt themed on the JD's "strong cross-functional influence", where F5 is the mapped story. EXP because the score is her own part in it |
| B4 | "Work like the store-surface change spans a lot of teams. How do you handle credit?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use "we" for the change shipping and "I" for the proposal, which is the share her sentence gives her. Answer slot: if she also had a part in building, testing or launching it, she should say which, in her own words. If not, she should say so plainly and stay with the proposal. Show that she names other people's contributions without being asked | It is Dan's collegial version of E1. A peer who will share wins with her is scoring how she shares credit. EXP because attribution is the test |

### C. Case / Strategist (pricing and packaging slant)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick one of the two new product lines. Sketch the GTM plan. What do you need to know first?" | CASE / JD | [generic] | Clarify first: which product, the ideal customer, whether existing customers or new logos are the target, and current pricing. Objective: tie it to enterprise expansion. Segment by land, adopt, expand and renew, and pick the motion for each stage: direct, partner-led or product-led. Then metrics and risks. Challenge one premise, for example whether both lines need separate motions or one attach play. Makes no claim about her past | It is the core JD mandate (F1, F2) delivered as a live case. `[generic]` because the two lines are not named in the materials |
| C2 | "A much bigger platform vendor bundles a 'good-enough' version of our new product for free. How do you package and price against that?" | CASE / CO | [grounded] research note: "main competitive threat is bundling by a much larger platform vendor" | Don't race to zero, because profitability is a stated priority. Segment where good-enough wins and concede those buyers. Defend where depth matters: a value metric tied to outcomes, and packaging into existing enterprise contracts as expansion. Consider a partner motion such as SIs or resellers as a channel the bundler can't copy cheaply. Name a mandatory concession: some share loss at the low end is the price of margin | This is Northwind's named threat, put in Dan's pricing language. It also touches F4 (partner motion). CASE delivery with CO grounding |
| C3 | "Compass: paid add-on, bundled into enterprise tiers, or a renewal lever? How would you decide?" | CASE / CO | [grounded] research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Lay out the three options against the three stated priorities: an add-on helps profitability, bundling helps expansion and defense, and a renewal lever helps retention. Pick a hypothesis early, then name the test that would change her mind (pilot cohorts, willingness-to-pay signals, cost to serve per account). Close on what she would need from Dan's team to run it | It pulls all three stated priorities into one live problem, which is the CO differentiator. It uses Dan's monetization lens and draws in F6 |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You come from consumer tech and you haven't run sales ops or set quotas. Why should GTM for these products sit with you rather than someone from B2B sales strategy?" | JD | [grounded] "No classic sales-ops or quota-setting experience.", "9 at a large consumer-tech company in product strategy & ops", "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus" | **This is the highest-ROI prep in the pack.** Rehearse it until it is boring. **Name the limit first:** "I haven't done classic sales-ops or quota-setting work." **Then hold only on what the quotes carry:** nine years in product strategy and ops at a large consumer-tech company, a partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. She describes these and lets Dan draw the inference. She does not call them proof of B2B readiness. **Follow-up 1, "carriers aren't enterprise buyers":** she holds by describing the model and how it was used, without claiming the two are the same. **Follow-up 2, "so how would you build a land-and-expand plan?":** move to the C1 structure as a plan, not a past. **Concession, word for word in her own phrasing:** what she would lean on Dan's team for (the coverage and quota model) and how she would learn it in the first 30 days. Never claim B2B SaaS or sales-ops experience | F7 is a stated gap sitting exactly in Dan's own domain, and F1 and F4 are transferability gaps. Some version of this will be asked. JD because it scores whether she can do the listed job |
| D2 | "Partner-motion design is a hard requirement. What partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold on the quote: she built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: if any part of the partner terms, tiers or program structure was hers to design, she should say which, in her own words. If none was, she should say so plainly and return to the model. That is a limit, not a confession. Then pivot to a plan: how she would design Northwind's partner motion (partner types, economics, how partners are routed against direct sales) and why it matters against the bundler (C2) | The JD's one "required" item, and F4 only reaches it by transfer. JD because it scores the stated requirement head-on |
| D3 | "Why leave consumer tech for B2B data infrastructure, and why now?" | EXP | [generic] | No sentence in your notes carries her motivation, so this is a scaffold. Answer slot: her actual reasons, in her own words. A strong answer has a pull toward Northwind and its moment (the new lines, Compass), not only a push away from the old job, and stays consistent with D1. If her honest reason is mostly a push, she should say it plainly and briefly, then speak to the pull | The Skeptic's standard question on motive, made sharper by the move from consumer to B2B. EXP because it is about her own path. `[generic]` because there is no quoted motive |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold, then concede. Pause and restate the question. **Hold:** "I proposed the store-surface change, and it was credited with roughly $400M in ARR uplift." Hold that through two follow-ups by coming back to the proposal, never by adding to it. **Concede, specifically:** the uplift belongs to the change as shipped by the teams who built it, and her part is what the answer slot from A1 and B4 holds, in her own words. Never fold to "it was a team thing" and drop her real part | A1 asks how the figure was counted. This asks whose it was, in a harder register. The biggest number on her record will be tested both ways. EXP because attribution is the test |
| E2 | "Sixty seconds: why you over an internal candidate from my team?" | JD | [grounded] "2 years strategy consulting at a top firm", "skilled in SQL/Tableau", "built a partner-level revenue model used in carrier negotiations" | Keep it to three beats inside 60 seconds: strategy consulting, then SQL and Tableau, then the partner-level revenue model used in carrier negotiations. Close with what an outside view brings to emerging products. Never run down an internal candidate. If he interrupts, finish the beat she is on, then stop | It is a time-boxed composure test, and natural for a peer whose own team may have candidates. JD because it scores fit to the listed role |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm", "9 at a large consumer-tech company in product strategy & ops" | Use a pre-scripted 90-second arc: consulting, then product strategy and ops, then why Northwind's emerging products now (D3's slot). Answer slot: the reason for each move, in her own words. Pick one quoted achievement to name in passing (the revenue model or the volume targets) and save the ~$400M for when he asks, so she isn't opening on her most-probed number | Nearly every 60-minute conversation opens this way, and it is scored for economy. EXP because it is a summary of her career |
| F2 | "What are you actually playing with in AI these days?" | JD / CO | [grounded] "uses AI tools daily" | Treat it as scored, because it is a JD plus. Answer slot: name the actual tools and what she uses them for in her own words, with no inflation into building AI products. Bridge to Compass from a user's angle: what she would want a data copilot to do, and what would make an enterprise buyer pay for it | It is the casual form of F6's "AI experience a plus" and leads into C3. JD first because it is a listed plus, with CO for the Compass tie-in |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time she told senior people something they didn't want to hear. It needs a named stake, a moment she held her position, and what happened next, including a working relationship that held up. Use "we" for context and "I" for her part. If no such time comes to mind, she should say so plainly, then give the nearest thing her experience does carry, or how she would handle it | A standard behavioral prompt that peers use to test whether she will speak up in the shared VP's room. `[generic]` because Northwind's values were not read |
| G2 | "Tell me about a time the data told you that you were wrong." | VAL / EXP | [generic] | Selection scaffold: a belief she held, the analysis that overturned it, what she changed, and how fast. That last part lands with a data-driven interviewer. If no such time comes to mind, she should say so plainly, then give the nearest thing her experience does carry, or how she would handle it | Themed on Dan's own words, "relentlessly data-driven". It shows whether her rigor applies to her own views too. VAL first, with EXP because it is a story from her past |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines (F1) | C1, D1, E2 |
| Whitespace across land/adopt/expand/renew (F2) | A3, C1, A1 |
| Independent analysis in SQL and Tableau (F3) | A3, A5 |
| Partner-motion design, required (F4) | D2, A2, C2 |
| Strong cross-functional influence (F5) | B1, B2, B3, A4 |
| AI experience a plus (F6) | F2, C3, A5 |
| Sales-ops and quota fluency, Dan's domain (F7) | D1, B2 |
| Stated priorities: enterprise expansion, Compass, profitability, plus the bundling threat | C2, C3, A5, R4, R5 |
| Mid-list JD requirements | none, and why: only the highlights were supplied, so any further requirements can't be mapped (see the upgrade menu) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could someone in this seat do in the first month that would genuinely help your team?" | The reciprocity question. It turns a peer evaluation into a working conversation and tells her exactly where the seam is |
| R2 | "With your pricing and monetization background, how is pricing for Compass being decided, and where does sales strategy have a voice in it?" | It ties to Dan's own path, shows she researched *him*, and opens his favorite topic |
| R3 | "Will your reps carry the two new lines, and how are attach and comp being handled?" | It goes straight at the seam (B1) and shows she knows a new product dies if the sales motion doesn't include it |
| R4 | "Against the bundling threat, are we leaning into partners or the direct motion for the new lines?" | It connects the named threat to the JD's partner requirement and shows strategic altitude |
| R5 | "When enterprise expansion, Compass and profitability pull in different directions for these products, which one wins?" | It shows she has absorbed all three priorities and wants to know the real decision rule |
| R6 | "You've seen an early-stage startup up close. What pace do you expect from an emerging-products team inside a company Northwind's size?" | It uses his startup chapter respectfully and brings the "big-company pace" doubt into the open on her terms |

---

## Prohibited claims

These are claims the pack will not coach, because each one would fail a probe Dan is likely to run.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered the $400M ARR | Inflated form of F2's quote (proposing becomes delivering, and "credited" disappears) | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". Any further part of hers stays in the A1 and E1 answer slots |
| Designed partner motions or ran a partner program | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material shows a revenue model used in negotiations, not a motion designed. D2's slot stays inside the model |
| Owned GTM strategy or launches | Inflated form of F1 | F1's quotes at their own scope. The F1 slot asks only which GTM decisions, if any, were hers |
| AI product or AI GTM experience | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily" |
| Has set quotas or run sales ops | A negative stated in your notes, F7 | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." No slot |

---

## Sources

**Provided documents:** your message, covering the JD highlights, background notes on Priya, notes on Dan's profile, and your research note on Northwind's priorities and competitive threat.

**Searches sent (all refused, because web-search permission was not granted):**
- `"Northwind Data" company values`: refused
- `"Northwind Data" interview process strategy`: refused
- `"Northwind Data" Compass AI copilot`: refused. This was a check on your research note
- `"Dan Kovac" "Northwind Data"`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The search was refused. A values page would have set the VAL themes, and the values cheat sheet if a values round turns up. G1 and G2 stay `[generic]` |
| 2. Northwind Data interview process | unavailable | The search was refused. This moved nothing, because your words already set the session: one 60-minute conversation with Dan |
| 3. Northwind Data strategy / recent news | unavailable | The search was refused. It was a check that your research note is current. The note is used as provided for C2, C3, A5, R4 and R5, but its freshness is unchecked |
| 4. Dan Kovac at Northwind Data | unavailable | The search was refused. The interviewer read rests only on your profile notes. His public talks or posts would have added his recurring themes |
| 5. Representative JD for the title | skipped | The JD highlights you supplied set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text:** any mid-list requirements get their own questions, and the fit snapshot quotes the JD itself instead of the highlights
- **Priya's CV, or her own written answers:** the evidence cells quote her words instead of your notes, and G1, G2 and D3 move from scaffolds to mapped stories
- **Priya's own account of how the ~$400M was counted and what her part was:** A1, B4 and E1 become fully story-mapped
- **Allowing web search (it was refused this run):** Northwind's values, current strategy news and Dan's public footprint, checked against your notes
- **Deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and Dan's talks or posts. This would sharpen C1 to C3
- **Any recruiter guidance (focus areas, a case or presentation to prepare):** a build section for any announced deliverable
- **How much prep time Priya has:** a prioritized prep schedule at the top of the pack
- **A `tuesday-dossier.md`, if one exists:** verified evidence and a prohibited-claims list carried in from earlier work
