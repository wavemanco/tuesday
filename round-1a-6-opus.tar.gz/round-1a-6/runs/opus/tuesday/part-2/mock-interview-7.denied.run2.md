Quick update: I've read the prep playbook and am now running a few targeted searches on Saltmarsh Games and Tobias before building your pack.
I've built your prep pack for Friday's 60-minute interview with Tobias. One limit first: web search was blocked in this session, so the pack has no research on Saltmarsh's games or on Tobias. Everything in it comes from the job description and your message.

I assumed Tobias would be your manager, since he runs Live Operations. You didn't say so, so treat that as unconfirmed.

**The question to rehearse most:** "Our calendar covers two titles and four disciplines (design, art, engineering, community). What in your background says you can run that?" (B1 in the pack). Your strongest answer is your own line: for the last two years you ran the weekly content-drop calendar for your main title. Say the limit before he does: that was one title, not two. Then give a short plan for picking up both titles' rhythms.

**Your two stated gaps:** you've never led a team, and never worked on a game with in-app purchases.
- Keep the answer to each to one plain sentence, then how you'd learn it.
- Coordinating teams on an update isn't the same as leading them, so don't let the two blur.
- The job description doesn't mention in-app purchases. Don't guess how Saltmarsh makes money from its events; one of the pack's questions for Tobias asks what the post-event review reports.

**What's in the pack:**
- How your background matches each requirement in the job description, and where it falls short.
- 22 practice questions grouped by how they'd be asked, from friendly to skeptical.
- Six questions to ask Tobias.
- A list of claims not to make, such as calling yourself a producer rather than an associate producer.

Some answers in the pack depend on things your message didn't say, so you'll fill those in yourself. For example: was your game on mobile, which teams' work ran through your calendar, and who produced the retention numbers you presented.

**Order for tonight and Friday morning:**
1. B1 out loud three times, then B2.
2. Your 90-second career summary (E1). Time it.
3. The post-event review question (A2) and the calendar-planning question (A1).
4. Settle what you can say about how the retention numbers were counted (C1).
5. The in-app-purchase answer (B3), short and calm.
6. Pick three questions to ask Tobias.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-2/rooms/case-7-denied-0eaa4e41:
- Saltmarsh-Games_live-operations-producer_interview_pack.md

I can play the Skeptic on B1 and react to your actual answers.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Is Tobias your future manager, and did the recruiter mention any focus areas or anything to prepare, such as a planning exercise? The answer changes how the questions are weighted.

Do you want me to retry the research with web search allowed? It would add a section on Tobias's public background and real facts about Saltmarsh for "why us?".

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Session:** one 60-minute interview, Friday
**Built as:** a hiring-manager round. Your note doesn't say whether Tobias would be your manager. The role sits in live operations and he runs it, so that is the assumption, and it is unconfirmed.

---

## How to use this pack

Two axes. **Personas** describe how a question gets asked: the tone, the pressure, the follow-ups. **Types** describe what is being scored. Rehearse both, because the same content asked by a Skeptic feels very different from the same content asked by someone friendly.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values they care about |
| EXP | Whether what you say you did holds up under detail, and what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you know the company, its games and its current direction |
| CASE | How you structure a live problem from the role, out loud |

Provenance labels: `[grounded]` means it rests on your message or the JD. `[inferred]` means the pack derived it, and names the derivation. `[generic]` means it's a role-family pattern with no claim about Saltmarsh or about you.

The guidance is scaffolding, not a script. Wherever it says **answer slot**, the pack doesn't know the answer and won't guess it. You answer from what actually happened, and "no, that wasn't me" or "there was no such step" is always an allowed answer.

---

## Prep triage: tonight and Friday morning

1. **B1 out loud, three times**, then B2. This is the highest-ROI prep in the pack.
2. **E1, your 90-second journey.** Time it.
3. **A2 and A1 structures.** Say the steps aloud once each. The post-event review is a named part of the job.
4. **C1.** Settle what you can and can't say about the retention numbers you presented. Who produced them, what they measured.
5. **B3.** Practise the in-app-purchase acknowledgment until it sounds calm and short.
6. **Pick three reverse questions** from the list near the end.

Everything else is insurance.

---

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Close, but there are two differences, and both are the pack's observation: your material says one title, where the job has two, and content drops, where the job says live events. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD says "mobile titles" and "live-events", so expect a probe on what the drops were. If the title was on mobile and the drops included timed events, say so in your own words. If not, say plainly what they were and stay with the calendar you ran. How you'd handle two titles is a plan, said as a plan |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your material doesn't say whether other teams' work ran through your calendar. Coordinating is not leading, so the "never led a team" sentence doesn't answer this row either way. Keep the two separate. Answer slot: if design, art, engineering or community work had to land on your calendar's dates, say which teams and what part of getting it there was yours. If none did, or it wasn't yours, say so and describe how you'd do it here. If asked about leading people, use the plain acknowledgment "I've never led a team" |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review and choosing its KPIs, but it's not the same work. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you also compiled those numbers, chose what went into them, or wrote any review of a drop, say which and how. If someone else produced them, say so plainly and say what your part in presenting them was |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | discovery | A strong, specific line. It shows you wrote the checklist. Your material doesn't say whether you ran it with QA release by release. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA on each release, say how. If QA ran it after you wrote it, say so plainly and stay with the checklist itself |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Not a gate. It gets graded like any other requirement. Your material gives four years as an associate producer and two years on the drop calendar. It doesn't say how long the main title ran as a live service. Answer slot: if the title had regular live updates for longer than your two years on the calendar, say how long, in your own words. If not, say so and stay with the four years and the two. Keep the title as "associate producer" |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. It's a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, the main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in what the line says. Expect a probe on which numbers and how they were counted (C1). Name the measures you presented, in your own words, and say plainly where you don't know how a number was calculated |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The checklist is a written document, and one that a team still uses. That is the pack's reading, not evidence of writing quality. Answer slot: if you also wrote other recurring documents (drop plans, reports, notes to the studio head), name one. If not, stay with the checklist. The interview itself is the work sample here, so keep answers short and organised |
| F9 | Mobile live-events roles often tie events to in-app purchases. A role-family pattern, not stated in this JD | "Never worked on a game with in-app purchases" (part of "Never led a team, and never worked on a game with in-app purchases") — your message | none | [generic] | capability | A gap you have stated. Wording can't close it, and nothing should be added to make it feel smaller. Words: "I've never worked on a game with in-app purchases." Then how you'd learn it, said as a plan and never as a past. Whether Saltmarsh's events involve purchases at all isn't established. Ask (reverse question R3) |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Live-events calendar, two mobile titles (F1) | A1, B1 |
| Coordinate design, art, engineering, community (F2) | A3, B1, B2, P1 |
| Post-event review and its KPIs (F3) | A2, A4 |
| Release checklist with QA (F4) | A5, D1 |
| 3+ years live-service (F5) | B4 |
| Content calendar (F6) | A1, B1, E1 |
| Retention metrics (F7) | C1, C2, C3, A4 |
| Clear written communication (F8) | V2, A5 |
| In-app purchases, a generic pattern (F9) | B3, D2 |

---

## Persona table

The weights come from the round type (hiring manager, assumed). Your note establishes the format: one 60-minute session with Tobias. No public information about him was available because the searches were blocked (see Sources), so nothing about his style adjusts these weights.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Plan this calendar." "Diagnose this event." | High. A hiring manager is buying capability, and the JD's verbs (plan, run, review, manage) are all things you can be asked to do live | Clarify, then objective, approach, metrics, risks. Think aloud. Ask one clarifying question before structuring |
| Skeptic | Quiet probing of the gaps: one title against two, coordination, purchases | High. A hiring manager is de-risking, and F1, F2 and F9 are the visible gaps | Rehearse B1 until it's boring. Bridge only from what your quotes carry. State limits plainly, then give a ramp plan |
| Data-Driven Prober | "Which numbers? How were they counted?" | Medium. The JD names retention metrics and KPIs, and F7 is a line they will want to open | Know what you can and can't say about how each number was produced. Say "I don't know how that was calculated" where true |
| Conversational | "Walk me through your journey." "What are you playing?" | Medium. Most 60-minute manager rounds open and close softly, and those parts are still scored | A timed 90-second arc. Treat casual live-ops chat as scored |
| Pressure | "How much of that was actually you?" "Sixty seconds: why you?" | Low to medium. Not signalled anywhere, but cheap to rehearse | Pause, restate, anchor in what you stated. Hold through two follow-ups, then concede the real limit |
| Values / Behavioural | "Tell me about a time…" | Low. No values round is established for this session | Pick real stories. Where none comes to mind, say so |
| Peer Evaluator | Seams with design, community, engineering | Low. Tobias isn't a peer, but coordination questions often arrive in this register | Propose principles for the seam, not a pretend knowledge of it |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you'd plan a quarter of live events across two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: each title's goals, audience overlap, team capacity, fixed dates. Then a structure: anchor events, a cadence per title, where the titles share or avoid clashing dates, buffers for slips, how you'd review and adjust. You can anchor one step in what you've done. For the last two years you ran the weekly content-drop calendar for your main title. Describe how you ran it in your own words, then say what changes with two titles, as a plan | F1 and F6 are the core of the job, and a manager will test them live rather than take the line on trust. CASE delivery, JD content |
| A2 | "An event's participation came in well below the last comparable one. Walk me through your post-event review." | CASE | [generic] | Structure it: confirm the numbers and the comparison, check delivery (bugs, timing, store or notification issues), check design (rewards, difficulty, length), read community feedback, segment who dropped off. Then write it up: what happened, likely causes ranked by evidence, what you'd change next time, who owns each change. No claim about your past is needed | F3 names the post-event review as yours to own. This tests whether you can run one, which your material doesn't yet show. CASE |
| A3 | "Two days before an update, engineering tells you an event feature won't make it. Art and community have assets and announcements ready. What do you do?" | CASE | [generic] | Clarify: what's slipping, by how much, can the event run without it? Options: ship the event without the feature, delay the whole event, or swap in a ready backup. Talk to design about player impact and to community about messaging before anything goes public. Decide with the right owner, tell every team the same thing at once, and note it for the post-event review | F2 is the role's coordination mandate, and it is thin in your material, so a live scenario is the fair test. CASE |
| A4 | "What KPIs would you put in a post-event review, and how would you decide what good looks like?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Name measures in families: reach (who saw or joined), engagement (completion, sessions), retention around the event, and player sentiment. "Good" means against a baseline: the last comparable event, or the same period without one. If events here carry purchases, say plainly that you've never worked on a game with in-app purchases, and ask how they're measured here | F3 and F7. KPIs are named as yours to report, and this is where F9 can surface naturally. CASE, with JD content |
| A5 | "How would you set up a release checklist for an event update?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Start from what you built. You wrote the release checklist your QA team still uses. Describe what it covers, in your own words. Then what you'd adapt for live events across two titles, as a plan: per-title items, sign-off points, a go or no-go moment. Answer slot: if you ran it with QA on releases, say how; if QA ran it after you wrote it, say so | F4 is your strongest specific line. Let him hear it in a problem he cares about. CASE, with an EXP anchor |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our calendar covers two titles and four disciplines. What in your background says you can run that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team, and never worked on a game with in-app purchases" | **The highest-ROI rehearsal in this pack.** Hold: "For the last two years I ran the weekly content-drop calendar for our main title." Name the limit before he does: one title, not two. Answer slot: the JD's coordination line makes a probe on other teams likely. If design, art, engineering or community work had to hit your calendar's dates, say which teams and what part was yours. If not, or not yours, say so plainly and stay with the calendar. If he asks about leading people: "I've never led a team." Then the ramp plan, said as a plan: how you'd learn both titles' rhythms and each team's lead times in your first weeks. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 and F2 are the gap between your material and the role's headline duty, so this objection will arrive in some form. JD, because it scores the listed job |
| B2 | "You haven't led a team. How do you get design, art, engineering and community to hit an update date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment first, short: "I've never led a team." Then how you'd do it, as a method and not a past: shared calendar and dates agreed early, each team's lead time known, one check-in rhythm, risks raised early, decisions written down. Answer slot: if you've had to get another team's work in for a content drop, say what happened in your own words. If not, say so | F2. The negative is yours, so he can only ask this if you or your CV raise it. Be ready either way. JD |
| B3 | "You haven't worked on a game with in-app purchases. How would that affect how you'd run events here?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | "I've never worked on a game with in-app purchases." Don't pad it. Then a plan: ask how events and purchases connect here, which KPIs the review tracks for them, who in the studio owns that analysis, and learn from the last few reviews. Don't guess at how Saltmarsh monetises. That isn't established | F9 is a stated gap, and a live-ops head may ask about it. A rehearsed short answer beats a defensive long one. JD content, though F9's requirement is a role-family pattern |
| B4 | "The role asks for three-plus years producing live-service games. Talk me through yours." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for the main title. Answer slot: if the title ran with regular live updates for longer than your two years on the calendar, say how long. If not, say so plainly and stay with the four and the two. Keep the title as "associate producer" | F5. A years requirement is often read literally, so be exact. JD |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick one real one and give a plan. Your material states two absences: leading a team, and games with in-app purchases. Choose whichever you'd genuinely rank first. Name it plainly, then give how you'd close it in the first months. One gap, one plan, no list | F2 and F9. A calm, specific answer here is a credibility gain. JD, with Skeptic delivery |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Which numbers, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the measures you presented, in your own words. Answer slot: if you calculated or compiled them, say how they were counted, what they were sensitive to, and the assumption you'd defend least. If someone else produced them, say so plainly and say what your part was, presenting and explaining them. "I don't know exactly how that was calculated" is an honest answer | F7 and F3. A prober will open this line, and precise attribution is the whole test. EXP |
| C2 | "Tell me about a time the retention numbers moved and you had to explain why." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a month where a number moved and you were the one explaining it. It needs what moved, what you thought caused it, and what happened next. If no such time comes to mind, say so plainly, then say how you'd approach explaining a move | F7. The JD's retention line raises it, and your material doesn't yet carry the story. EXP |
| C3 | "One title's seven-day retention drops after an event. What do you check first?" | CASE | [generic] | Confirm it's real: data issue, cohort, platform, timing. Then compare event participants with non-participants, look for a difficulty or reward cliff, check for bugs or crash spikes, and read community feedback. Say which you'd check first and why. No claim about your past | F7 tested live. CASE |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Pause. Hold: "I wrote the release checklist our QA team still uses." Answer slot: if others contributed items or reviewed it, say what was theirs. If it was yours alone, say so plainly. Hold through two follow-ups, and concede only what's real | F4 is your strongest line, so expect it to be tested. EXP, Pressure delivery |
| D2 | "Sixty seconds: why you over a producer who's already run live events with purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "Never led a team, and never worked on a game with in-app purchases" | Under 60 seconds. Three facts: you ran the weekly content-drop calendar for your main title for the last two years, you wrote the release checklist your QA team still uses, and you presented the monthly retention numbers to the studio head. One plain line: you've never worked on a game with in-app purchases. Then one sentence on why this role, in your own words. Don't argue the comparison | F6, F4, F7 and F9 together. Composure is the test. EXP |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | 90 seconds. Four years as an associate producer at a puzzle-game studio. For the last two you ran the weekly content-drop calendar for the main title. You wrote the release checklist your QA team still uses, and you presented the monthly retention numbers to the studio head. End on why live operations next, in your own words | F5, F6, F4 and F7 in one arc. It's almost certainly asked, and it sets his frame for everything after. EXP |
| E2 | "Why live ops, and why Saltmarsh?" | EXP | [generic] | Give your own reasons. The research didn't run, so the pack supplies no facts about Saltmarsh's games or direction. If you've played their titles, say what you noticed. If you haven't, don't fake familiarity. Say what draws you to the role | A motivation question is near-certain. The honest cost of the blocked research is that this stays generic. EXP |
| E3 | "What are you playing at the moment? What do you think of its live events?" | CASE | [generic] | A casual question that is still scored. Pick a game you actually play. Name one event you thought worked, why, and one thing you'd change. Keep it short and specific | Live-ops heads often test taste this way. CASE content, casual delivery |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to push back on a date to protect a release." | VAL | [generic] | Selection scaffold: pick a time a release was at risk and you raised it. It needs the risk, what you said and to whom, and what happened. If no such time comes to mind, say so plainly, then say how you'd handle it | The JD's release-checklist line raises it. No values round is established, so this is light coverage. VAL |
| V2 | "Tell me about something you wrote that changed how a team works." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it. Those are the beats the quote states. Answer slot: if it replaced an older process, say what changed. If it didn't, say so and stay with the checklist | F8. The JD's writing line raises it, and the checklist is the nearest story in your material. VAL, with JD content |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Community says players hated the last event's rewards, but design wants to keep the format. What do you do?" | CASE | [generic] | Get the evidence on the table: feedback volume, participation data. Separate the format from the rewards. Propose a test or a small change. Agree who decides and when. Tell community what players will hear. Shows spine and tact together | F2's coordination mandate, set at a seam. CASE |
| P2 | "How do you handle credit when an update spans four teams?" | VAL | [generic] | Selection scaffold: pick a time credit on shared work came up. It needs who did what, and how you named it. If none comes to mind, say so plainly, then say how you'd handle it: credit by name, in writing, in the post-event review | A short collaboration probe a manager may use. VAL |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do the two titles' calendars relate? Shared events, or run separately?" | Tells you the real scope of F1, and shows you're already planning across both |
| R2 | "What does a good post-event review look like here, and who reads it?" | F3 is named as yours to own, so this is diligence, not small talk |
| R3 | "Which KPIs does the review report today, and which would you like it to report?" | Shows you think in measures, and tells you whether purchases feature (F9) without you guessing |
| R4 | "Where do handoffs between design, art, engineering and community slow down on an update today?" | Shows you're already thinking about the coordination job (F2) |
| R5 | "What would you want this person to have taken off your plate by month three?" | Turns the interview toward his priorities, and gives you a ramp plan to mirror back |
| R6 | "What's changed most in how you run live operations over the last year?" | An open invitation to talk about his own work, with no assumption about his path |

---

## Prohibited claims

This list is what the pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, or managed the design, art, engineering or community teams | A negative you stated, F2 | "I've never led a team." No slot |
| Has worked on live events with in-app purchases | A negative you stated, F9 | "I've never worked on a game with in-app purchases." No slot |
| Ran the live-events calendar across several titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one title's content-drop calendar. B1's slot stays inside that calendar |
| Owned the retention KPIs or the post-event review | Inflated form of F3 | F3's quote at its own scope. The material says you presented the numbers. C1's slot asks only what your part in them was |
| Managed QA, or ran the release process | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist. D1's and A5's slots stay inside the checklist |
| Producer, or senior producer, as a past title | Inflated form of F5 | F5's quote: associate producer, four years |

---

## Sources

- **Provided:** the JD and background you pasted in your message.
- **Searches sent, all refused by this session's permissions:**
  - "Saltmarsh Games values": refused
  - "Saltmarsh Games interview process producer": refused
  - "Saltmarsh Games mobile studio news 2026": refused
  - "Tobias Wrenfield Saltmarsh Games": refused
- No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search refused. Would have shown whether published values exist to theme questions on |
| 2. Saltmarsh Games interview process, producer | unavailable | Search refused. Your note already establishes this session's format. It would have added any wider loop context |
| 3. Saltmarsh Games strategy and recent news | unavailable | Search refused. Would have given E2 real company facts and a CO question grounded in current direction |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Search refused. Would have produced a read on the interviewer, adjusted persona weights, and given a reverse question tied to his path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Web search allowed in this session → targets 1 to 4 run: an interviewer read on Tobias, persona weights tuned to his public footprint, a reverse question tied to his path, real facts for E2, and a CO question on Saltmarsh's current direction
- Whether Tobias would be your manager → persona weights confirmed or rebuilt
- The recruiter's prep email, if there was one → coverage of any focus areas, and a build section for any exercise they announced, such as a calendar or review task
- Your CV text → evidence cells drawn from the CV as well as your message, and possibly stories this pack can't see
- Your answers to the answer slots (was the title on mobile and live for how long, which teams' work ran through your calendar, who produced the retention numbers, whether you ran the checklist with QA) → F1, F2, F3, F4 and F5 regraded, and B1, B4 and C1 story-mapped instead of slotted
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a strategy brief and a grounding section on Saltmarsh's titles
- A `tuesday-dossier.md` with underwriting on this role → a highest-ROI objection derived from verified evidence, rather than inferred
