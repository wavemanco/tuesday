Quick update: I've read the prep playbook and its rules. Next I'm running a few short web checks (company values, interview process, Dan's public profile), then I'll build the pack.
Priya's prep pack is ready: 23 questions sorted by interviewer style and by what each one scores, all built for a peer conversation with Dan. Each question comes with answer guidance and a short reason for including it and tagging it the way it is.

- **The question to rehearse most is D1**, "What have you designed on the partner side?" Partner-motion design is the only requirement the JD calls "required", and the closest thing Priya has is the partner-level revenue model. The pack walks through three follow-ups and how to answer without overstating.
- **Bank weighting follows Dan's profile.** Number-probing and peer questions get the most weight, because he calls himself "relentlessly data-driven" and he'd be her peer. The case questions lean on pricing and packaging because of his background, and they draw on your research note: Compass, enterprise expansion, profitability and the bundling threat.
- **Sales ops and quota-setting.** Your notes say Priya hasn't done either, so the pack hands that back to her as a plain admission. It also coaches her to keep calling her work "volume targets", not quotas. That matters with someone from sales strategy.
- **No web research was done.** The three searches (Northwind's values, its interview process, Dan's public profile) were blocked because web search permission wasn't granted. The pack rests only on what you gave me, which is why there's no values section. The upgrade menu at the end lists what search access, the full JD or Priya's CV would add.

Several answers depend on facts only Priya has, such as how the $400M figure was counted. The pack leaves those as two-branch prompts instead of inventing details.

Files are in the working directory:
- northwind-data_senior-gtm-strategy-lead_interview_pack.md

If you'd like, I can play Dan as a skeptical peer on D1, with live follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document or a shareable web page, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy. He's a **peer**: you'd both report to the same VP · **Format:** one 60-minute conversation

---

## How to use this pack

Every question has two tags:

- **Persona** (the bank letter, A to G) is *how* the question arrives: the tone, the follow-ups, the pressure.
- **Type** is *what* the question is scoring:

| Tag | Scores |
|---|---|
| VAL | Whether past behavior shows the values the company says it holds |
| EXP | Whether claims about past work hold up under probing, and what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you know the company's strategy and competition and can think at its level |
| CASE | How you structure and reason through a live problem from the role |

**Provenance labels:** `[grounded]` means traceable to something you supplied. `[inferred]` means derived by this pack, with the derivation named. `[generic]` means a common pattern for this kind of role, with no claim about Northwind or about Priya.

**Answer slots.** Some answers depend on facts only Priya has, such as how a figure was counted. In those places the guidance gives two branches instead of words: if she did it, she says how, in her own words. If she didn't, or it wasn't hers, she says so plainly. Both branches are good answers.

The guidance is scaffolding, not a script. Each answer should take 90 to 120 seconds to say aloud.

---

## Fit snapshot

Requirements are from the JD highlights in your message. Evidence is quoted word for word from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says product strategy & ops at a consumer-tech company. It does not say GTM strategy for a B2B product line, so her words stay at that scope: "Two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company." Answer slot: the JD's GTM-ownership line makes a probe on which GTM decisions were hers likely. If any were, she says which and how she decided, in her own words. If none were, she says so plainly and stays with the product strategy & ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote touches growth but doesn't show whitespace work across the customer lifecycle. Linking the two is this pack's inference, so don't stretch it. Words: "I proposed a store-surface change that was credited with about $400M in ARR uplift." Answer slot: the JD's whitespace line makes a probe on how the proposal came about likely. If analysis of her own led to it, she says what she looked at, in her own words. If not, or that part wasn't hers, she says so plainly and returns to the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. But nothing has been inspected behind the claim, so expect Dan to test it live (A4). She should state the skill in its own terms and show it by working the problem out loud, not by describing herself |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a revenue model that was used in negotiations. It does not say a partner motion she designed, so her words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "required" makes a probe likely. If the model shaped any partner terms that came out of those negotiations, she says which and what her part was, in her own words. If she doesn't know, or it didn't, she says so plainly and stays with the model she built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already shows influence, in other words. Reword only it: "I set annual volume targets with consensus across orgs." Keep the noun "volume targets", not "quotas" (see the prohibited list) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Using AI tools every day is not experience building or selling an AI product, so the words stay at that scope: "I use AI tools every day." Answer slot: the JD's AI line, with Compass launching, makes a probe on what she uses them for likely. She names the tools and what she uses them for, in her own words. If it's mostly personal productivity, she says so plainly |
| F7 | Working inside sales-planning mechanics such as quotas, territories and capacity (a common requirement for this role family, not in the JD highlights) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | You stated this gap, so the pack can give it back to her as words: "I haven't done classic sales ops or quota-setting." Then how she would learn it from the sales-strategy team, said as a plan and never as past experience. Don't add anything to make the gap feel smaller |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 own GTM strategy for two new product lines | C1, D2, D3 |
| F2 whitespace across land/adopt/expand/renew | C2, A5, A1 |
| F3 independent analysis in SQL and Tableau | A4, C2 |
| F4 partner-motion design (required) | **D1 (highest-ROI)**, A2, B3 |
| F5 strong cross-functional influence | B2, A3, B5, B4 |
| F6 AI experience a plus | E2, C4 |
| F7 sales-planning mechanics (generic) | B1, A3, F2 |
| Research note: enterprise expansion, Compass, profitability, bundling threat | C2, C4, C3, A5, C1 |

---

## Reading the interviewer

This section uses only what you supplied. The web searches for Dan's public profile were refused (see Sources).

| Signal (your note) | What it means for this conversation |
|---|---|
| Profile says "relentlessly data-driven" | He'll probe every number to its assumptions. The $400M figure (F2) and the revenue model (F4) are where his follow-ups will go two levels deep. Volunteer the assumption she'd defend least before he finds it |
| Career spine is "pricing and monetization roles" | Case questions will lean toward pricing, packaging, value metrics and unit economics (C3, C4, B5). That's his native language, so answers should use it |
| "one early-stage-startup chapter" | People with startup chapters often respond well to builder stories and may doubt big-company pace. Expect a scrappiness angle inside D2 and F2 |
| Peer, same VP | He's weighing whether this hire adds to his team's load or reduces it. Expect questions about the boundary between his work and hers, and about who gets credit (Bank B). In Priya's own field, the most honest answer is F7's plain acknowledgment |

**Mirror opportunity (shared vocabulary, not a shared career path):** Dan's pricing and monetization background and F4's "built a partner-level revenue model used in carrier negotiations" are both about revenue. In A2 she can talk about the model in revenue terms without stretching the sentence. There is no shared career jump to point to.

---

## Persona table

The format comes from your message (one 60-minute conversation with Dan), not from a guess at Northwind's process. No values round is part of it.

| Bank | Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| A | Data-Driven Prober | "How was that counted?", "Which assumption is weakest?" | **High.** Peer interviews lean this way by default, and his self-description "relentlessly data-driven" raises it further | Know what she can and can't say about how each number was counted. Name the weakest assumption first. Say "I don't know" plainly where that's true |
| B | Peer Evaluator | Where the boundary between their roles sits, what she'd need from him, credit, disagreement | **High.** Peer interviews lean this way by default, and they would share a VP | Talk about what she brings to his team, not only what she needs. Propose principles for splitting the work rather than pretending to know the current setup |
| C | Case / Strategist | Live problems on the two new product lines, Compass and bundling | **Mid.** His pricing background points the cases at packaging and unit economics. The research note gives the strategy context | Clarify, then objective, segmentation, approach, metrics, risks. Say the framework out loud. Challenge one premise respectfully per case |
| D | Skeptic | Partner-motion gap, consumer-to-B2B move, why now | **Mid.** F4 and F1 are transferability gaps, and the JD calls partner-motion design "required" | Rehearse D1 until it's boring. Bridge only from quoted sentences, and name the limit before he does |
| E | Conversational | "Walk me through the journey", "what are you doing with AI?" | **Low.** Still near-certain as an opener | A pre-planned 90-second arc. Treat casual AI questions as scored |
| F | Pressure | Time-boxed attribution and comparison questions | **Low.** Peers rarely run stress interviews, but a data-driven peer may press hard on the $400M | Pause. Hold the position through two follow-ups, then concede the specific point, never the core claim |
| G | Values / Behavioral | Stock behavioral questions | **Low.** No values round in this format, and Northwind's values weren't researched | Use a story only where her own sentence carries one. Otherwise pick an honest example, or say plainly that none comes to mind |

---

## Question banks

### Bank A — Data-Driven Prober (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the sentence's own verbs: she proposed the change, and it was credited with about $400M in ARR uplift. Then four answer slots, each in her own words: how the figure was counted, what it is sensitive to, the assumption behind it she'd defend least (named before he asks), and which part was hers. If she doesn't know how it was counted, "I don't know exactly how that figure was counted" is an honest answer. Then she returns to what she proposed | F2 holds her headline number, and Dan says he's "relentlessly data-driven," so he will take it to its assumptions. EXP because it tests the figure and who gets credit for it |
| A2 | "Tell me about the partner-level revenue model you built. What did it give the people negotiating with carriers?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | What the sentence states: she built it, it was partner-level, and it was used in carrier negotiations. Offer to walk through it end to end, in her own words. Answer slot: his "relentlessly data-driven" makes a probe on the model's inputs likely. If she knows them, she names them. If others set them, she says so. Answer slot: if she knows what the negotiators did with it, she says so. If not, she says so plainly and stays with what she built. She should not say she negotiated | F4 is the closest evidence to the JD's only "required" line. Dan will want to know what the model really was before the partner question in D1. EXP because it's a deep dive on a claim, in his pricing and monetization language |
| A3 | "How did you set the annual volume targets? What data went into them?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | What the sentence states: she set annual volume targets, and they had cross-org consensus. Answer slot: if she can name the data that went in, she does, in her own words. If the inputs came from others, she says whose. Keep the noun "volume targets". If he equates them with quotas, her words are: "I haven't done classic sales ops or quota-setting." Then stop, without explaining a difference she can't back | F5 is the closest thing to planning work in Dan's own field, and F7 sits right next to it, so he'll test whether "targets" means quota. EXP because it checks a claim's substance |
| A4 | "Say I gave you our bookings and product-usage tables tomorrow. What's the first query you'd write, and the first Tableau view you'd build?" | JD | [grounded] "skilled in SQL/Tableau" | First, clarify which decision the analysis serves, for example which accounts to target for a new line. Then: the grain (account × product × month), how bookings join to usage, a first cut by land, adopt, expand and renew, and one view comparing product penetration with usage depth. Say her assumptions about his tables out loud, since they're his tables. If he asks about past work, her words are "skilled in SQL/Tableau". She describes a real query only if she has one in mind | F3 covers the SQL and Tableau line, but nothing behind it has been inspected. A data-driven peer tests hands-on skill by asking for the first step. JD content, CASE delivery |
| A5 | "Ninety days after launch, how do you know a new line's GTM is working, before revenue shows it?" | CASE | [grounded] | Early indicators for each stage: land (qualified pipeline and win rate in the target segment), adopt (activation and depth of use), expand (attach rate in existing accounts), renew (early account health). Tie it to the research note's "reaching profitability": add the payback period or margin on the line. Say which numbers she'd watch weekly and what reading would make her change course. No claims about her past | Covers F2's requirement and the profitability priority from your research note. A prober expects every metric to have a definition. CASE because it's a live design problem |

### Bank B — Peer Evaluator (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see sales ops or quota-setting in your background. Our two roles will overlap. Where's the boundary, and what would you need from me?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "skilled in SQL/Tableau" | Lead with the plain acknowledgment: "I haven't done classic sales ops or quota-setting." Then principles, not a claimed map of his team: she'd first ask how his team handles planning today; one owner per number; shared data definitions across both teams. Then what she brings, in her own words: analysis she can run herself in SQL and Tableau. Close by asking what would help his team | F7 is the gap in Dan's own field, and as a peer he's judging whether she adds to his load. JD because this boundary is what the "cross-functional influence" line means in practice |
| B2 | "Tell me about a time you got teams that didn't report to you to agree on a number." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story from F5, if it fits: the annual volume targets, set with cross-org consensus. If the orgs involved didn't report to her, this is her story. If they did, she picks another time or says plainly that none comes to mind. "We" for the orgs, "I" for setting the targets. Answer slot: the JD's influence line makes a probe on how consensus was reached likely. If there was disagreement, she says what it was and what part of resolving it was hers. If there wasn't, or that part wasn't hers, she says so plainly and stays with the targets | F5 is the evidence for influence. Peer interviewers score how she disagrees with equals. VAL first because it's about behavior; the theme comes from the JD |
| B3 | "If you design a partner motion for a new line, how do you keep it from colliding with direct sales?" | CASE | [generic] | A hypothetical, so no claims about her past. Structure: which segments or use cases partners reach that direct sales doesn't; rules of engagement (deal registration, who owns which accounts); compensation that doesn't penalize reps for partner-sourced deals; one shared pipeline view; a regular review with sales strategy. End with what she'd need from Dan's team | Tests F4's requirement as reasoning rather than a claim about her record, at the seam Dan cares about most. CASE because it's a live problem; `[generic]` because the structure is a common pattern, not a Northwind fact |
| B4 | "How do you handle credit when your analysis ends up in someone else's deck or deal?" | VAL | [grounded] "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | Story from F4 and F2, keeping each sentence's verbs: she "built" the model and it was "used in" carrier negotiations; she "proposed" the change and it was "credited with" the uplift. Answer slot: if she did anything to share credit with the people who carried the work forward, she says what, in her own words. If not, she says so plainly and says how she'd handle it here | Both F4 and F2 describe work that other people carried forward. Credit-sharing is a standard peer probe. VAL because it's about conduct |
| B5 | "Say we disagree on how to price one of the new lines. How would you handle it with me?" | CASE | [generic] | A future scenario, so no past claims. Agree on what the decision is and who owns it. Agree on the data that would settle it, such as a test or a cohort comparison. State her view and its weakest assumption. If it has to go to the VP, go together with a framing they both accept | Pricing is the likely friction point with someone whose career is pricing. CASE because it's hypothetical, VAL second because it scores disagreement style |

### Bank C — Case / Strategist (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You own GTM for two new product lines. What do you need to know in your first two weeks, and what does your 90-day plan look like?" | CASE | [grounded] | Say the framework out loud. Clarify what each line is and who buys it. Objective: which of the research note's priorities each line serves (enterprise expansion, Compass, profitability). Segment existing customers vs new ones, across land, adopt, expand and renew. Choose the motion: direct, partner, or both. Then metrics, then risks, with the larger vendor's bundling first. Challenge one premise respectfully, such as whether both lines need the same motion | F1's requirement is the headline of the role, and your research note gives the company context. JD content, CASE delivery |
| C2 | "Enterprise expansion is a top priority. How would you find the whitespace for a new line in our existing customer base?" | CASE | [grounded] | Define whitespace: accounts that don't yet own the product but fit it. Build an account × product matrix in SQL. Rank accounts by signals such as use of adjacent products, size and renewal timing. Show it in Tableau by lifecycle stage. Separate landing in new departments from expanding in existing ones, and decide which accounts partners should lead. Name the data she'd need and where it's likely to be weak | Covers F2's and F3's requirements and the research note's "enterprise expansion". CASE delivery, CO grounding |
| C3 | "A much larger platform vendor bundles something close enough to our new product for free. How do you price and package against that?" | CASE | [grounded] | Don't match zero. Split the buyers the bundle serves well enough from the ones who need depth. Pick a pricing metric tied to what the bundle can't deliver. Packaging: standalone vs attached to the core platform, plus an entry offer. Use partners for reach. Profitability guardrail: no packaging that buys market share at a negative margin. Test before rolling out. Concede one premise: without win/loss data she can't know where the bundle actually wins | Your research note names bundling as the main competitive threat, and packaging is Dan's home ground. CASE delivery, CO content |
| C4 | "Compass is our AI copilot. Seat-based, usage-based, or included in a tier: which would you pick, and how would you test it?" | CASE | [grounded] "uses AI tools daily" | Trade-offs: seats are predictable but can under-charge heavy users. Usage tracks value and the cost of running the AI, but buyers can't predict the bill. Including it in a tier drives adoption and counters the bundle, but costs margin. Tie it to profitability: AI usage costs money to serve, so watch gross margin. Pick a hypothesis and propose a test, such as pilot groups or a packaging change at renewal. If he asks about her own AI background, her words are "I use AI tools every day". Offer views as a user, not as product experience | The Compass launch plus the profitability goal. Pricing questions come naturally from his background, and F6's gap means AI will come up as a case. CASE delivery, CO content |

### Bank D — Skeptic (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is required for this role. What have you designed on the partner side?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | **This is the highest-value thing to rehearse in the pack.** Open with only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model shaped any partner terms that came out of those negotiations, she says which and what her part was, in her own words. If she doesn't know, or it didn't, she says so plainly and stays with the model. If the model is the nearest thing she has to this requirement, she should say so herself before he asks: a limit she volunteers lands better than one he pulls out of her. **Follow-up 1** ("So it was a model, not a motion?"): add nothing. Restate the model and what it was used for. **Follow-up 2** ("How would you design ours?"): switch to a plan, said as a plan: which partner types reach which segments, what each side gets, rules of engagement with direct sales, and how to measure partner-sourced vs partner-influenced pipeline. **Follow-up 3** ("Why should we take that risk?"): concede in her own words anything the model didn't cover, and hold that the model was real and used | F4 covers the JD's only "required" item, and its evidence is adjacent rather than direct, so this objection will come up in some form. Dan will probably ask it in a friendly tone. JD because it scores the stated requirement |
| D2 | "Your background is consumer tech. Which part of this JD would you be weakest at on day one?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "No classic sales-ops or quota-setting experience." | Answer it directly with one real weakness: "I haven't done classic sales ops or quota-setting." Then a ramp plan, said as a plan: learn the planning calendar and definitions from sales strategy in the first weeks. Background only from the quote: "Two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company." Answer slot: the B2B scope of the role makes a probe on enterprise selling likely. If she has worked with B2B deals or enterprise buyers, she says where, in her own words. If not, she says so plainly | Combines F1's transferability gap and F7's stated gap, using the standard Skeptic question. JD because it scores the listed job against her gaps |
| D3 | "Why leave a large consumer-tech company for this, and why now?" | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: she gives her actual reason for leaving and for the timing, in her own words. The pack doesn't supply one. For "why here," anchor in what's on the record: the JD's emerging-products scope and the research note's priorities. She picks the one she genuinely cares about. State the move from consumer to B2B plainly, without dressing it up | F1 makes the consumer-to-B2B move the obvious motivation probe, and the Skeptic scores whether her story stays consistent. EXP first because it's about her reason for leaving, CO second |

### Bank E — Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: two years in strategy consulting at a top firm, then nine in product strategy & ops at a large consumer-tech company. Then one or two proof points in the sentences' own verbs: the partner-level revenue model she built, used in carrier negotiations, and the store-surface change she proposed, credited with about $400M in ARR uplift. Then why emerging-products GTM now, in her own words. Stop at 90 seconds and let him pick a thread | An almost certain opener. It feels casual but is scored on how concisely she tells it. EXP |
| E2 | "What are you actually doing with AI these days?" | JD | [grounded] "uses AI tools daily" | Her words: "I use AI tools every day." Answer slot: she names the tools and what she uses them for. If it's mostly personal productivity, she says so plainly. Then she can give a user's view of what makes a copilot worth paying for, offered as opinion. That connects to Compass without claiming product experience | The JD lists AI as a plus and Compass is launching. A casual question about a skill the JD wants is still scored. F6 is a transferability gap. JD |

### Bank F — Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold, then concede. Hold: "I proposed the change; it was credited with about $400M in ARR uplift." **Follow-up 1** ("Who built and shipped it?"): answer slot. She names the roles that did, in her own words. If she doesn't know how the work was split, she says so. **Follow-up 2** ("So your part was the idea?"): hold the sentence. The proposal was hers and that is the claim, with no upgrade to "led" or "drove". Concede specifically what belonged to others, never the proposal itself | The phrase "credited with" in F2 invites an attribution probe, and a data-driven peer may ask it bluntly. A standard Pressure question. EXP |
| F2 | "Sixty seconds: why you over an internal sales-strategy candidate who already knows our motion?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience." | Pause first. Then three points from the quotes only: the consulting plus product strategy & ops background, the partner-level revenue model used in carrier negotiations, and "skilled in SQL/Tableau". Concede what's true: an internal candidate knows the existing motion, and her words for her side of that are "I haven't done classic sales ops or quota-setting." Then hold: the JD is about new product lines, which don't have an established motion yet | A time-boxed comparison where F7 is exactly what an internal candidate would have. JD because it scores fit for the listed role |

### Bank G — Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time she told senior people something they didn't want to hear. It needs a clear stake, what she said, and how it landed, and the truth has to have actually landed. If no such time comes to mind, she says so plainly, then gives the nearest thing her experience does have, or how she'd handle it | No values round in this format and no researched values, so this uses a standard behavioral question. Low weight. VAL |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where a metric pointed one way and the customer's interest another, and she chose the customer. It needs the metric, the decision, and what happened. If no such time comes to mind, she says so plainly, then gives the nearest thing she has, or how she'd handle it | A standard behavioral question. People with pricing backgrounds often probe the tension between customers and metrics, but that's a general pattern, not something known about Dan. VAL |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "What could someone in this seat do in the first month that would genuinely help your team?" | Shows she's thinking about what she adds to his team, the peer's real concern, and gets her a practical first-month agenda |
| R2 | "You've spent your career in pricing and monetization. Where do you think pricing and packaging will make or break the two new lines?" | Ties to his own career, turns the interview into a conversation between peers, and invites his strongest views |
| R3 | "You've had an early-stage chapter too. What habit from that stage do you think a GTM team here should use more?" | Respects his startup experience and shows she's open to working leaner than a big company |
| R4 | "How do sales strategy and this role split ownership today: targets, territories, partner coverage?" | Gets the boundary between the roles defined before she starts, and shows she's aware of whose turf is whose |
| R5 | "With profitability a stated priority, how is the team weighing investment in new lines against margin?" | Uses the research note's priorities and shows she can think at the company's level |
| R6 | "Where does the bundling threat show up most in your data: win rates, renewals, or deal size?" | Asked in his data-first language about the research note's main threat, and the answer shapes her first analysis |

---

## Prohibited claims

Things this pack will not coach Priya to say, and why. These are the claims a candidate tends to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed a partner motion or partner program | Stretches F4 | F4's quote at its own scope. The pack's observation, not words for her: the material says a model, not a motion. D1's answer slot stays inside the model |
| Negotiated the carrier deals | Stretches F4 | F4's quote: the model was "used in carrier negotiations". The sentence doesn't say who negotiated |
| Led, drove or delivered the ~$400M ARR uplift | Stretches F2 | F2's quote keeps "proposed" and "credited with". F1's answer slot stays inside the proposal |
| Owned B2B GTM strategy | Stretches F1 | F1's quote at its own scope: product strategy & ops at a consumer-tech company |
| Volume targets described as quotas or sales plans | Stretches F5 (changes the kind of work) | F5's quote keeps "volume targets" |
| Set quotas or ran sales ops | A gap you stated, F7 | The plain acknowledgment: "I haven't done classic sales ops or quota-setting." |
| Has built or sold AI products | Stretches F6 | F6's quote at its own scope: "uses AI tools daily" |

---

## Sources

- **Provided:** your message, which included the JD highlights, your notes on Priya, a profile summary for Dan Kovac, and your research note on Northwind's priorities and competitive threat.
- **Searches sent:** `"Northwind Data" company values` (refused), `"Northwind Data" interview process strategy role` (refused), `"Dan Kovac" "Northwind Data" sales strategy` (refused). Web search permission was not granted in this session.
- No dossier was used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Refused. It would have given the official value names to theme Bank G. No values round is in this format, so no values cheat sheet would have been included either way |
| 2. `Northwind Data interview process` (strategy roles) | unavailable | Refused. Your message already establishes this session's format, so it would only have shown whether later rounds exist |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the current priorities and the main threat that feed C1 to C4 and A5 |
| 4. `Dan Kovac Northwind Data` | unavailable | Refused. It would have added his public talks or posts to the interviewer section and R2 and R3 |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → requirements beyond the highlights (named tools, methods, mid-list items) get their own questions, and the coverage table becomes complete.
- **Priya's CV** → more of her own sentences for the fit snapshot. F1, F2 and F6 could gain direct evidence.
- **Her answers to the answer slots** (how the ~$400M was counted, what the revenue model's inputs were and how negotiators used it, whether it shaped any partner terms) → A1, A2, D1, F1 and B4 move from answer slots to specific, rehearsable answers.
- **Allowing web search** → targets 1, 2 and 4 run: Northwind's official values, whether later rounds exist, and Dan's public talks or posts for the interviewer section and reverse questions.
- **Deeper research** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, Dan's longer-form talks and writing, candidate reports on this role family, and recent org changes, adding a vocabulary section and sharper C and R questions.
- **Prep time available** → a prioritized prep schedule sized to it.
- **Any recruiter guidance** (focus areas, a requested presentation or point of view) → a build section for each deliverable.
- **Other scheduled rounds** → a separate mini-pack for each round with its own persona weights.
- **A `tuesday-dossier.md`** → evidence Priya has confirmed, a named top objection, and a binding prohibited list carried in from earlier work.
