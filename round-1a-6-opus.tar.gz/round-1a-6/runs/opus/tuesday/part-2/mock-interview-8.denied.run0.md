Your prep pack is drafted. I'm fixing one citation in it, then I'll send it over.
I've built your prep pack, saved as `Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`. It has one section for each of the three rounds on 5 December, based on the recruiter's description of each. All of it rests on the five sentences you wrote about yourself; I didn't search the web, because what you pasted already covered the company, the rounds and the strategy.

**What's in it:**
- **Fit check:** each requirement in the job description, set against your own words. Strongest matches: your 6 years in banking, your work on the branch's complaints log, and the spreadsheet you built. The two gaps you stated yourself are working in a contact centre and presenting above regional level.
- **Round 1 (recruiter, 30 min):** 9 questions, covering salary, notice, location and your reason for leaving, plus quick checks on years of experience, Excel and regulated complaints.
- **Round 2 (Head of Member Services, 45 min):** 10 questions, mostly behavioural. **D1 is the most valuable thing to prepare:** "You haven't worked in a contact centre, and this complaints process runs through one." It has a full rehearsal: say the gap first, give a plan, and how to handle two follow-ups. D2, on presenting to senior leaders, is next.
- **Round 3 (panel of two branch managers, 60 min):** a plan for the 20-minute case, three positions you could take (each with a weakness you should admit), a cheat sheet for the four values, and 10 questions.
- **Claims to avoid:** six things not to say, each with an honest version. Examples: "handled regulated complaints" (you said "formal") and "coached supervisors" (you trained new tellers).

**Before 5 December:** many answers have a gap for you to fill in your own words, with an honest fallback if you don't have that experience. Settle these first:
- whether your complaints spreadsheet tracks volumes and resolution times
- whether the complaints in your log had rules or deadlines you had to meet
- what your teller training actually involved
- one real story for each of the four values (none of your five sentences gives a full one yet)

If you'd like to practise, I can play the Head of Member Services and put D1 to you, with follow-ups that react to your answers. I can also save a `tuesday-dossier.md` file recording the gaps this prep found, so you can bring it to later sessions. And if you'd like a Word version of the pack, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 5 December 2026 · **Mode:** loop (three rounds, one shared fit snapshot)

| Round | Length | Who (from the recruiter's email) | Interviewer names |
|---|---|---|---|
| 1 | 30 min | The recruiter | Not yet assigned |
| 2 | 45 min | Head of Member Services, your would-be manager; "mostly behavioural" | Not yet assigned |
| 3 | 60 min | Panel of two branch managers; "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" | Not yet assigned |

---

## How to use this pack

- **Personas** describe *how* a question is asked (friendly chat, quiet probing, a live problem). **Types** describe *what is being scored*. Rehearse both.
- **Type key:**
  - **VAL**: behaviour that shows Ashgrove's four published values
  - **EXP**: what you actually did; whether your account holds up under follow-ups
  - **JD**: can you do the job as written, gaps included
  - **CO**: Ashgrove's strategy and where it is heading
  - **CASE**: a live problem from the role, reasoned out loud
- **Provenance labels:** `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is this pack's derivation, with the derivation named; `[generic]` is a role-family pattern with no claim about Ashgrove or you.
- **Answer slots** are instructions for your answer in the room. Each has two honest branches. If you did the thing, say how in your own words. If you didn't, or it wasn't yours, say so plainly. Neither branch is wrong.
- The guidance gives you scaffolding, not a script. Every sentence about your past is built only from the five sentences you wrote about yourself, quoted in the fit snapshot.

---

## Fit snapshot (shared across all three rounds)

All evidence is quoted from your message. There's no CV, so each row rests on one of your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's log. It doesn't show a process across branches, and the words should stay where your sentence is: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe likely on which stages of a complaint, from receipt to closure, passed through your hands. If some did, name them in your own words. If your part was the log itself, say so plainly and stay with the log |
| F2 | "…and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | This is a gap you have stated, and no wording closes it. Words: "I haven't worked in a contact centre." Then say how you'd learn it, as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | A monthly complaints spreadsheet you built, used by your regional manager, is close to the requirement. Your material doesn't say whether it tracks volumes or resolution times. Answer slot: if it counts complaints or tracks how long they take to resolve, say what it counts in your own words. If it holds something else, say what it holds and stay with the fact that you built it and your regional manager uses it |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: say which tool you built it in and what you did in it, in your own words. If it was a simple sheet, say so plainly. Plainness reads better than overstatement here |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training new tellers on a script is adjacent work. It is not coaching supervisors, who would be your peers or above. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. Say what the training involved, in your own words. If it was the script alone, say so plainly and stay with it |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you fed member problems into a digital or self-service change, or worked alongside the people building one. Answer slot: if you have done anything like this, say what and what your part was, in your own words. If not, say so plainly, then say how you would start: what you'd bring the digital team from the complaints data |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in years. Say it in your sentence's terms ("six years in retail banking, the last three as a branch supervisor") rather than relabelling it in the JD's words. Expect a probe on what the supervisor role covered |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" is not the same word as "regulated", and the bridge shouldn't be stretched. Answer slot: if the complaints in that log had rules or deadlines you had to meet, say which and what they required of you, in your own words. If you don't know, or there weren't any, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you have stated. Words: "I've never presented to anyone above regional level." Then your plan for building it. Your sentence doesn't say whether you have presented at regional level, so the pack doesn't assume it. That is an answer slot in D2 |

---

## Grounding brief (from the July 2026 strategy brief and the JD)

The brief is about four months old, so it's current enough to quote. The two right-hand columns are the pack's reading, not Ashgrove's words.

| Fact | Source | Provenance | What it likely means in these rounds | Provenance of that reading |
|---|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief | [grounded] | The JD's "self-service journeys" line ties to this. Complaints about digital journeys are likely to grow as a share of the total. Expect a CO question on it from the Head of Member Services | [inferred] from the brief plus the JD line |
| Consolidate eight branches into five hubs over 2027 | Strategy brief | [grounded] | Escalation routes and complaint ownership change while branches merge. The panel are branch managers, so handle this topic with care and ask rather than assume | [inferred] from the brief plus the recruiter's panel description |
| Small-business lending product launching Q1 2027 | Strategy brief | [grounded] | A new product brings new kinds of complaint. That's a good forward-looking point for the monthly report | [inferred] |
| Main competitive pressure: app-only banks | Strategy brief | [grounded] | A badly handled complaint is a reason for a member to leave. Be ready to explain why complaint handling matters to retention | [inferred] |
| Member-owned, about 900 staff | JD | [grounded] | "Member" not "customer" is the house word. Use it | [grounded] in the JD and values wording |
| Values: Members First, Always · Plain Words · Neighbours, Not Numbers · Own the Fix | Values page, pasted 26 Nov 2026 | [grounded] | The panel scores against these by name (recruiter's email) | [grounded] |

---

## Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end across branches | F1 | C1, E2, G1, J2 |
| …and the contact centre | F2 | D1 (highest-ROI), E2 |
| Report monthly on volumes and resolution times | F3 | E1, E2, D2 |
| Coach branch supervisors on escalations | F5 | C2, J1 |
| Work with digital teams on self-service journeys | F6 | E3 |
| 4+ years in financial-services customer operations | F7 | A1, B1 |
| Experience handling regulated complaints | F8 | B3, G1 |
| Confident presenting to senior leaders | F9 | D2, C4 |
| Comfortable with Excel reporting | F4 | B2, E1 |
| Four published values | — | H1 to H4, plus C3 |

---

# Round 1: recruiter screen (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walkthrough, "why us", logistics | High. A recruiter-screen prior, and the recruiter named a 30-minute chat | Have a 90-second background arc ready (A1). Treat every casual question as scored |
| Skeptic (light) | Knockout checks against the JD's requirements | Medium. Recruiters screen the JD's hard lines: years, regulated complaints, Excel | One plain, quotable sentence per requirement, taken from your fit row |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | Ninety seconds, in this order: six years in retail banking, the last three as a branch supervisor. In that role you handled the branch's formal complaints log, trained new tellers on your escalation script, and built the monthly complaints spreadsheet your regional manager uses. Close with one line on why complaints work is the thread you want to follow, in your own words | Sets up F7, F1, F5 and F3 in the recruiter's notes. EXP because the recruiter is checking that your story matches what you applied with |
| A2 | "Why this role, and why Ashgrove?" | CO | [grounded] | Give your own reason first. Then tie it to one thing Ashgrove has published that genuinely draws you, such as a value by name or the strategy's digital and hub changes. Don't invent enthusiasm for something you don't feel | Motivation consistency is a recruiter staple. CO because a specific tie to Ashgrove's own words separates you from generic applicants |
| A3 | "What are your salary expectations?" | JD | [grounded] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Asked in nearly every screen. Your answer is yours alone |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period | Standard logistics |
| A5 | "The role covers branches and the contact centre. Where are you based, and how do you feel about moving between sites?" | JD | [grounded] | Logistics slot: give your actual position on where you can work and how much travel you can do | The JD's "across branches and the contact centre" makes this likely. The terms are yours to state |
| A6 | "Why are you looking to leave?" | EXP | [grounded] | Logistics slot: give your actual reason in a sentence or two, pointed toward what you want next rather than at what you're leaving | Reason-for-leaving is a standard screen line. Keep it short and forward-looking |
| B1 | "The JD asks for 4+ years in financial-services customer operations. Tell me about yours." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer in your sentence's terms: six years in retail banking, the last three as a branch supervisor. Answer slot: if asked what the supervisor role covered, say it in your own words | F7 is a knockout line, and a clean match is worth saying cleanly. JD because it checks the stated requirement |
| B2 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the spreadsheet: you built it, it's monthly, and your regional manager uses it. Answer slot: say which tool you built it in and what you did in it. If it was simple, say so plainly | F4 is unproven in your material. A plain, specific answer beats "very comfortable" |
| B3 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what you handled: the branch's formal complaints log. Answer slot: if those complaints had rules or deadlines you had to meet, name them in your own words. If you don't know or they didn't, say so plainly | F8 is a likely knockout check. Rehearsing the honest version now keeps you from saying "yes" to a word you can't back |

### Reverse questions

| Question | Why it lands |
|---|---|
| "How are the three rounds weighed against each other in the final decision?" | Shows you're preparing seriously and tells you where to spend your prep |
| "Is the 20-minute case given in the room, or beforehand, and will there be any materials?" | Directly shapes how you prepare the Round 3 case |
| "Is this a new role or a replacement?" | A new role means defining the process. A replacement means inheriting one. You answer D1 differently in each case |
| "How is the role's time split between branches, the contact centre and head office?" | Clarifies the F2 gap before you meet your manager |
| "What happens after 5 December, and when will I hear?" | Basic logistics, and the recruiter expects it |

---

# Round 2: Head of Member Services (45 minutes, mostly behavioural)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" with STAR-shaped follow-ups | High. The recruiter said "mostly behavioural", which outweighs the hiring-manager prior | Pick stories from your own record. Say "we" for context and "I" for your part. Where you have no story, say so and give how you would handle it |
| Skeptic | Quiet probing of the contact-centre and senior-presenting gaps | High. A hiring-manager prior, and F2 and F9 are stated gaps on JD lines this person probably owns | Rehearse D1 until it bores you. Hold what you said, concede plainly, and give a ramp plan |
| Case / Strategist | One or two live problems, likely on reporting or digital | Medium. A hiring-manager prior, scaled down by "mostly behavioural" | Clarify, structure, then answer, using Ashgrove's words: member, hubs, self-service |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre, and this complaints process runs through one. How would you take ownership of that part in your first months?" | JD | [grounded] "Never worked in a contact centre" | **This is the highest-ROI prep in the pack.** Say the limit before they press: "I haven't worked in a contact centre." Then a plan, said as a plan: sit with contact-centre colleagues early, listen to calls or read cases, learn how their complaints are logged and escalated, and compare that with the branch route you know. Follow-up 1 ("so how can you own it?"): hold. Owning a process means understanding it, and the plan is how you get there. Don't claim you already understand it. Follow-up 2 ("we need someone who knows it now"): concede plainly that a contact-centre hire would know it sooner. Then return to what your sentences carry: the branch's formal complaints log and the monthly spreadsheet you built. Never imply contact-centre exposure you didn't state | F2 is a stated gap on a JD line this manager probably owns, so it will come up in some form. JD because it scores the stated requirement. Deepest rehearsal because a calm, early concession changes how the rest of the interview goes |
| D2 | "This role presents to senior leaders every month. What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Second-deepest rehearsal. Say it straight: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom, in your own words. If you haven't presented at all, say so plainly. Then the plan: how you'd prepare the first monthly report, such as asking what decisions it drives and rehearsing it with your manager. Hold-then-concede: don't fold into apology, and don't inflate | F9 is the second stated gap and sits on a hard JD line. It's likely to follow D1 directly |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | Pick one honestly, F2 or F9, and give it in your stated words, then the plan from D1 or D2. Choosing a real gap reads as self-awareness. A disguised strength reads as evasion | A Skeptic stem that tests honest self-assessment. Rehearsing D1 and D2 makes this one easy |
| C1 | "Tell me about a time you handled a complaint that had to be escalated." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint from your time with the log. It needs a member, a reason it had to go beyond the counter, what you did, and how it ended. Say "we" for the branch and "I" for your part. If no single case comes to mind, say so plainly, then describe how escalations moved through the log and what your role in them was | Your work on F1 is the obvious source for this question, but your sentence names the log, not a specific case. The story has to come from you |
| C2 | "Tell me about a time you trained or coached someone on handling an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5: new tellers, the escalation script, and you trained them. Answer slot: the coaching line makes a probe on how you trained likely. Say what it involved in your own words. If it was the script alone, say so. Then say what you'd do differently coaching supervisors, who'd be your peers | F5 is the evidence for the coaching requirement, and the interviewer will test the gap between tellers and supervisors |
| C3 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold, themed on Own the Fix. You need a problem you spotted, what you did about it, and when it was actually fixed. Answer slot: if you built the spreadsheet because you saw a problem, say what it was in your own words. If it was simply requested, say so and pick another time. If none comes to mind, say so and describe how you'd handle it | Ashgrove's managers live these values too, and Own the Fix maps directly onto owning complaints end to end |
| C4 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: a named stake, a moment you didn't back down, and a working relationship intact at the end. It could be a regional manager or anyone above you. If no such time comes to mind, say so plainly, then say how you'd raise a bad monthly number with leadership | Relevant to the monthly senior reporting (F9). It's a persona stem, so it's `[generic]` |
| E1 | "Walk me through the monthly complaints spreadsheet you built. What does it track, and how is it used?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it, it's monthly, and your regional manager uses it. Those are the beats your sentence carries. Answer slot: say what it tracks in your own words, and whether that includes volumes or time to resolve. If it doesn't, say so plainly. If asked how the regional manager uses it and you know, say so. If you don't, say that | F3 and F4 hang on this one artifact, so expect it to be probed hard. EXP because it tests what was actually yours |
| E2 | "Complaint resolution times have crept up for three months, mostly in the contact centre. Diagnose it." | CASE | [generic] | Clarify first. Is it more complaints, harder complaints, fewer people, or a change in how time is counted? Split by channel, complaint type and stage. Look at where cases wait. Name what you'd check first and who you'd talk to, including contact-centre staff, since you'd be learning that channel (D1). Close on what you'd report next month. No claim about your past is needed | A live problem from the JD's resolution-times line. `[generic]` because the pattern isn't Ashgrove's data |
| E3 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints, and how would you work with the digital teams?" | CO | [grounded] | Use Ashgrove's own frame: 40% to digital by 2028. Complaints are the best map of where self-service journeys fail members, so the monthly report can feed the digital team. Answer slot: if you've worked with a digital or systems team before, say what and what your part was. If not, say so plainly and give how you'd start: one shared view of top digital complaint reasons, reviewed together | The one CO question grounded in the brief. It covers F6, the JD line your material doesn't touch |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would good look like from this role in the first 90 days?" | Lets you tie your D1 plan to their priorities in their own words |
| "Where do complaints get stuck today, between branches, the contact centre and digital?" | Shows you think about the process as a whole, which is what "end to end" means |
| "Who does the monthly report go to, and what decisions does it drive?" | Shows you care about F9 and F3 for the right reason: the report exists to drive decisions |
| "As more service moves to digital, what changes are you expecting in what members complain about?" | Brings the strategy into the room as a shared problem rather than a recital |
| "Which complaint-handling rules does the team work to, and where do you most want that tightened?" | Turns the F8 uncertainty into diligence rather than a gap |

---

# Round 3: branch-manager panel (60 minutes; case plus values)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The 20-minute complaint escalation case, plus follow-ups | Certain. The recruiter named it | Use the build section below: clarify, member's side, fix, root cause, report, coach |
| Values / Behavioral | Questions scored against each of the four values | Certain. The recruiter called this the values round | Use the cheat sheet below. Name the values naturally, not as a checklist |
| Peer Evaluator | "How would you work with our branches and supervisors?" | Medium-high. These are branch managers whose supervisors you'd coach (JD), so they're weighing what you add to their load | Frame it as reciprocity: what you'd bring their branches, not just what you'd need from them |

## Graded deliverable: the 20-minute complaint escalation case

**What's known (recruiter's words):** "a 20-minute case on a complaint escalation", run by "a panel of two branch managers", who "score against the four values". Nothing else is known about the case's content. Ask the recruiter whether it's given in advance (R1 reverse question).

**What you bring (F-rows):** F1, "I handled the branch's formal complaints log". F5, "trained new tellers on our escalation script". Use these only if the case invites it, and only in these words.

**Suggested shape for 20 minutes** (agree the format first: "How would you like me to use the time?")

1. **Clarify (2 min).** Who is the member? What happened, and on which channel? How long has it been open? What has already been promised? Are there signs the member needs extra care? Which complaint rules and deadlines apply? What authority would I have?
2. **The member's side (3 min).** Restate the complaint as the member would put it. *Members First, Always.*
3. **Fix it now (5 min).** Who speaks to the member, what you can resolve today, and how you explain the outcome so it doesn't need explaining twice. *Plain Words.*
4. **Keep hold of it (4 min).** Root cause. Is this one member, or a pattern in the log? Who owns it until it's closed? How does it show up in the monthly report? *Own the Fix.*
5. **The branch and its people (4 min).** Coach the supervisor who escalated, and protect the branch's standing in its town. *Neighbours, Not Numbers.*
6. **Close (2 min).** What you'd record, and what you'd check in a month.

**Three defensible theses, each with its concession**

| Thesis | Mandatory concession |
|---|---|
| Resolve as close to the member as possible. Escalate only what the branch can't fix | Some complaints must escalate whatever the branch could do, for example because of rules or the member's circumstances. Speed at the counter can't override that |
| Every escalation is also a data point. The case should end up in the monthly report as a pattern, not just a closed ticket | Recording adds work for branch staff, and during consolidation they have little to spare. Keep it light |
| During the move from eight branches to five hubs, name who owns a member's open complaint when their branch changes | The panel knows the consolidation plan far better than you do. Ask how it's being handled rather than prescribing it |

**Standing out:** the consensus answer is "apologise, investigate, resolve, follow up". Give that briefly to show you know it. Then diverge on root cause and reporting (thesis 2) and on the hub transition (thesis 3). That's what an *owner* of the process adds.

**The anti-pick, where saying no is the job:** don't promise the member an outcome or a timescale before you have the facts. Don't overrule the branch in front of the member. Don't offer a goodwill payment as a reflex.

## Values cheat sheet

None of your five sentences carries a full values story, so each row is a selection scaffold. Choose your stories this week, in your own words.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, not the organisation's | Selection scaffold: pick a time you changed what you did because of how it looked to the member. You need the member's view, the choice, and the result. F1's log ("I handled the branch's formal complaints log") is the natural place to look. If no such time comes to mind, say so plainly, then say how you'd apply it in the case |
| Plain Words | If a member needs it explained twice, the explanation was at fault | Selection scaffold: pick a time you rewrote or re-explained something so it landed the first time. Answer slot: if training tellers on the escalation script (F5, "trained new tellers on our escalation script") involved making it clearer, say how. If not, say so and pick another time. If none comes to mind, say so and give how you'd do it |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold: pick a time a member or local situation got personal attention beyond the process. If no such time comes to mind, say so plainly, then say how you'd keep that during the hub consolidation |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | Selection scaffold: a problem you spotted and saw through. Answer slot: if you built the spreadsheet (F3, "I built the monthly complaints spreadsheet our regional manager uses.") because of a problem you found, say what. If it was requested, say so and pick another time. If none comes to mind, say so plainly |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | The 20-minute complaint escalation case | CASE | [grounded] | Use the build section above. Agree the format, clarify, then work through the six beats out loud, naming the values as you go | The recruiter pre-declared it, so it's a graded deliverable. It also covers F1 and F8's requirements live |
| G2 | "The member says they'll move to an app-only bank unless this is sorted today. What do you do?" | CASE | [grounded] | Acknowledge the frustration in plain words. Say what can be done today and what can't, and why. Don't promise beyond your authority. Then the retention point: a complaint handled well is a reason to stay | A likely case twist. App-only banks are the brief's named competitive pressure |
| G3 | "Eight branches become five hubs over 2027. What happens to complaints during that change?" | CO | [grounded] | Say you'd expect more complaints about access and change, as a reading rather than a fact. Name who owns each open complaint, use plain-words explanations for affected members, and track consolidation complaints separately in the monthly report. Ask the panel how their branches are preparing rather than telling them | CO grounded in the brief. These are branch managers, so tact counts as much as content |
| H1 | "Tell me about a time you put the member first when the process said otherwise." | VAL | [generic] | Use the Members First, Always row of the cheat sheet | One VAL question per value (the panel scores all four) |
| H2 | "When have you had to explain something complicated to a member or colleague?" | VAL | [grounded] "trained new tellers on our escalation script" | Use the Plain Words row, including its F5 answer slot | Plain Words. F5 is a possible source, and the slot keeps it honest |
| H3 | "Tell me about a time you treated a member as a neighbour rather than a number." | VAL | [generic] | Use the Neighbours, Not Numbers row | Neighbours, Not Numbers. It matters to branch managers in particular |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use the Own the Fix row, including its F3 answer slot. If you answered C3 in Round 2, a different story here shows range | Own the Fix is the value closest to this role's core. The panel may reuse Round 2's theme |
| J1 | "You'd be coaching our supervisors on escalations. They know their branches better than you. How would you work with them?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor." | Start from what's true: you've trained new tellers on an escalation script, and you've been a branch supervisor yourself (F7). Then the approach: listen first, learn each branch's patterns from its complaints, and coach on the cases they bring. Don't claim you've coached supervisors before | F5's gap between tellers and supervisors, asked by the people whose supervisors it would be. JD because it scores the coaching line |
| J2 | "When a complaint escalates from my branch, where's the line between your job and mine?" | JD | [generic] | Propose a principle rather than pretending to know the line. The branch owns the member relationship. You own the process, the record and the pattern. Then ask what works for them today | A Peer Evaluator stem. Branch managers are weighing whether you add to their load or take it off |
| J3 | "What would you need from us?" | JD | [generic] | Keep it short: timely escalation, honest feedback on what's not working, and their help shaping the process during the hub changes. Then turn it around: what you'd give them back, such as the monthly picture of their branch's complaints | A reciprocity check. The answer should show what you'd give, not just what you'd take |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could someone in this role do in their first month that would genuinely help your branches?" | Reciprocity with the people you'd serve. Panels of peers weigh this slot heavily |
| "When a complaint escalates from your branch today, where does it go, and what do you hear back?" | Gets you the real process, and it gives them a chance to tell you what's broken |
| "What do your supervisors most want help with on escalations?" | Ties directly to the JD's coaching line and shows you'd listen before coaching |
| "Which of the four values is hardest to live up to on a busy day in branch?" | A thoughtful values question in a values round. It invites honesty, not recital |
| "As branches move to hubs, what are members asking you most?" | Shows you care about members through the change. Ask it gently |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a complaints process across branches, end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation is that your material covers one branch's log, not a cross-branch process. The answer slots stay inside the log |
| Has worked in, or with, a contact centre | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | "I've never presented to anyone above regional level." The D2 slot asks only about regional level |
| Has coached branch supervisors | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The slots ask only what that training involved |
| Built the region's complaints reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." It's one spreadsheet, and the regional manager uses it. The slots ask only what it tracks |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope: "I handled the branch's formal complaints log." The slots ask only what rules or deadlines the log's complaints had to meet |

---

## Sources

**Provided documents:** the JD, pasted. Ashgrove's values, pasted (copied from the values page on 26 November 2026). The recruiter's email describing the three rounds. A summary of the July 2026 strategy brief the recruiter sent. Dara's background, in the message. No dossier was present.

**Searches and fetches sent:** none. Every declared target was already answered by what you pasted.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and the H questions, with the four values by official name |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes all three rounds, their lengths, who runs them, the case and the values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief, under six months old, supplies the priorities behind E3, G2 and G3 |
| 4. Interviewer name | n/a | No names have been assigned, so there's no query to form. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a "reading the interviewer" section, persona weights for each panel member, and a reverse question tied to each person's own path
- **Your answers to the answer slots in F1, F3, F4, F5, F6 and F8** → those rows become story-mapped guidance, upgrading C1, C2, C3, E1, E3, B2, B3 and H2 to H4
- **Your CV** → more of your own sentences to quote, which could turn some of the cheat sheet's selection scaffolds into mapped stories
- **The full strategy brief text** → a richer grounding brief with its own headline numbers and wording
- **How much prep time you have before 5 December** → a prioritised prep schedule sized to it
- **The recruiter's answer on the case format** (in advance or live, any materials) → a sharper G1 build
- **Deep research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news and context on consolidation, and which complaint-handling rules apply to a credit union in Ashgrove's jurisdiction
- **A `tuesday-dossier.md`** → evidence already graded and confirmed by you, plus a prohibited-claims list built from it rather than inferred here
