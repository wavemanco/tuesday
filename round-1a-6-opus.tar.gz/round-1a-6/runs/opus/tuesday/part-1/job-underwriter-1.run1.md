Reading the required reference files.
**Yes, you're a strong fit for the core of this role. It's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R7a (Partner with product managers on roadmap decisions), R7b (Partner with clinicians) · unclear: R6 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience (HIPAA))

R6, R8: your background doesn't mention either one, which isn't the same as a gap, so each gets a question below. R9: GDPR/CCPA work is a credible bridge, but it isn't HIPAA.

**Opportunity ledger.** Nothing here is alarming, but little is confirmed. I couldn't check that Harborlight exists as described (RR1), and the posting doesn't state pay, location or how success is measured (RR2, RR3, RR4). One entry is positive: a team and a BI tool are already in place (RR5).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting check out (RR1); (2) pay and location meet your own limits, which you haven't told me (RR2, RR3); (3) R9 is described as adjacent privacy experience, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Scope read | One senior analyst who does hands-on work (tests, dashboards, metrics) and also leads two juniors informally. It reads as a senior individual-contributor role with mentoring, not a manager role | `[inferred]` from "mentor" rather than "manage" and from the list of hands-on duties |
| Market calibration | Not established: the role-family sweep couldn't run, so I have no band to give | — |
| Unknowns | Pay, location and remote policy, employment type, reporting line, who owns the metrics layer today, success measures | `[grounded]` JD silent on each |
| Contradictions | None in the posting as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years stated against 5+ asked. Self-reported and specific; `medium` is the ceiling until something is checked | `[grounded]` intake background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, plus building a Looker instance on top of it. "Expert" is the JD's word, not yours. Expect a live SQL exercise to test it | `[grounded]` intake background; `[generic]` that senior analytics loops commonly include a SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the experimentation program: 30+ A/B tests a year on a base of ~2M subscribers, including the pricing test behind an 11% retention lift. Strongest row. Expect to be asked which parts of the lift you can attribute to the test | `[grounded]` intake background | offer: a redacted test readout would make this the anchor story |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, with 40+ governed dashboards. This is the JD's named tool, not a substitute | `[grounded]` intake background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. A redacted memo excerpt is the artifact this field keeps | `[grounded]` intake background | offer: redacted memo excerpt as a writing sample (see P4) |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" points toward shared, defined metrics, but you haven't said you defined metric definitions or owned the modelling layer. Assuming you did would mean claiming work you haven't stated | `[grounded]` background silent on metric definitions | see G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Reporting to the VP Product monthly and a pricing test tied to a retention lift are close to this. What's unstated is ongoing, embedded work with PMs, and a roadmap decision your analysis changed | `[grounded]` intake background | see G3 |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | Writing for non-technical execs carries over. Limit: you haven't worked with clinicians, whose idea of success is clinical, not commercial | `[grounded]` background has no clinical stakeholders; `[generic]` that clinicians weigh safety and outcomes above engagement | see G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring, managing or onboarding analysts. That is missing information, not a demonstrated gap | `[grounded]` background silent | see G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Handling GDPR/CCPA consumer PII and building the warehouse's consent-state model show real privacy-engineering discipline. Limit: HIPAA's rules for health data (PHI) and healthcare metrics weren't part of it | `[grounded]` intake background; `[generic]` HIPAA's PHI rules differ from GDPR/CCPA | see G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Looker built from scratch, with dashboards described as governed; nothing said about who defined the metrics | It's the first responsibility the JD lists, so it's the likeliest place for a senior-level probe | Writing the canonical definition of "active subscriber" or "retained"; writing LookML views and explores others built on; a metrics catalogue or review process for new metrics | A redacted metric definition doc, a LookML repo excerpt, a metrics glossary | `[grounded]` background silence; `[inferred]` from the JD's ordering that it's weighted heavily |
| G2 | Mentoring (R8, important) | discovery | No mention of juniors, interns or reviewing others' work | Two named reports-in-spirit make this a stated part of the job | Reviewing junior analysts' SQL or test designs; onboarding new hires to Looker; running an experimentation office-hours or review | A review checklist, onboarding doc, or a mentee's outcome you can describe | `[grounded]` background silence |
| G3 | PM partnership (R7a, important) | discovery | VP-level reporting and a high-impact test; no example of a roadmap call your analysis changed | It turns a strong analyst story into a decision-maker story | A feature killed or reprioritized after a test; a PM-requested analysis that changed a launch plan | A decision memo or test readout naming the decision | `[grounded]` background |
| G4 | Clinician partnership (R7b, important) | transferability | Non-technical exec writing; no clinical audiences | Clinicians are named stakeholders | Carries over: translating metrics for non-analysts. Limit: clinical framing and safety constraints. Strengthener: show how you'd present a metric to someone who cares about outcomes over revenue | A memo excerpt written for a non-commercial audience | `[grounded]` background; `[generic]` clinician-stakeholder pattern |
| G5 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling; consent-state model | A "plus", not a requirement; framing matters more than closing it | Carries over: consent modelling, PII access controls. Limit: PHI rules, business associate agreements (BAAs), de-identification standards. Strengthener: basic HIPAA familiarity before interviews | A design note on the consent-state model | `[grounded]` background; `[generic]` HIPAA specifics |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this company; research couldn't run here | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | (posting states no pay) | The budgeted figure is unknown, and not publishing it is itself worth asking about | `[grounded]` JD silent | What salary range and equity are budgeted for this role? | unresolved |
| RR3 | Location and working pattern unstated | unknown | — | (posting states no location) | The role could be remote, hybrid or on-site; that matters only against your own constraints | `[grounded]` JD silent | Where is the role based, and how many office days are expected? | unresolved |
| RR4 | No success measures or first-year outcomes stated | unknown | — | "Own product analytics for our care-navigation app" | Ownership without a stated definition of success can mean an unclear mandate, or just a short posting | `[inferred]` from the JD's scope language against its silence on outcomes | What would make this hire a success after the first year? | unresolved |
| RR5 | Team and tooling already in place | positive_signal | — | "mentor two junior analysts"; "self-serve dashboards in Looker" | Resources exist and the BI stack is chosen, so the role isn't starting from nothing | `[inferred]` from the JD's named team and tool | Who owns the Looker model today, and who does this role report to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program: 30+ tests a year and the pricing test behind the 11% retention lift, in those words. Be ready to separate what you designed from what drove the lift | see R3 | `[grounded]` intake background | pending your approval |
| P2 | Present Looker as "built from scratch, 40+ governed dashboards". Say nothing about owning metric definitions until G1 is answered | see R4, R6 | `[grounded]` intake background | pending your approval |
| P3 | Present GDPR/CCPA work and the consent-state model as transferable privacy discipline, explicitly not HIPAA experience | see R9 | `[grounded]` intake background | pending your approval |
| P4 | Prepare a redacted excerpt of the monthly metrics memo as a writing sample | see R5, R7b | `[grounded]` R5 | pending your approval |
| P5 | Find this role on Harborlight's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Ask the verification questions for RR1, RR2, RR3, RR4 and RR5 word for word in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; the call was refused (search permission not granted). It would have confirmed the company and the live posting, and cleared or kept RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; the call was refused. It would have given the market band for RR2 and the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you want to keep this, I can save the assessment as a `tuesday-dossier.md`.

**Upgrade menu**
- Granting search permission (or pasting the posting's link) would let me run targets 1 and 2. That checks RR1 and puts a market band against RR2.
- Your pay floor, location and remote limits would add hard-gate rows, and the hard-gates line would become a real check.
- A redacted test readout or metrics memo would give R3 or R5 an artifact to inspect.
- The hiring manager's name would tell us which of your stories to lead with for that reader.
- A deeper research pass on Harborlight (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) runs if you say the word.

**Questions**

RR2/RR3: What are your non-negotiables: pay floor, location or remote requirement, and anything else that would rule a role out?

G1 (R6): Did you define the metrics behind those governed dashboards, for example the canonical "active subscriber" or "retention" definitions, or build the modelling layer others relied on? Or did someone else own that?

G2 (R8): Have you mentored, onboarded or reviewed the work of other analysts? Who were they, and what did you do?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.