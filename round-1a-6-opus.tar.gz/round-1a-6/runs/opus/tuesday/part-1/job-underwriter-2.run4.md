Still reading the underwriting playbook's reference files before I write your assessment. Next up are the risk and decision rules.
**No, you're not wasting your time.** Most of what you've done is product work without the title. The hard part is the posting's "3+ years product management experience (must-have)". You've said you've never held the title, so that requirement is where you're most likely to be screened out. How you apply will matter as much as whether you apply. **Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (PM-shaped work over 3+ years), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery experience) · absent: R1b (3+ years with a product manager title)
- `important`: direct: R8 · adjacent: R6 (Discovery with integration partners), R7 (Owning a roadmap), R10 (Launch coordination with sales and support) · unclear: R9 (Defining and tracking adoption metrics)

R1b: absent by your own statement, and the requirement most likely to be screened literally. R2 and R7: credible bridges, but you never owned the final decision. R5 and R9: still open, and each needs only one answer.

**Opportunity ledger.** The role itself looks well defined. It names its resources and its measure of success (RR5). I couldn't confirm the employer from here (RR1), and the posting doesn't state pay (RR2), location (RR3) or who actually decides the roadmap (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting checks out on Quartzline's own careers page (RR1).
  2. You apply through a route where a person reads your experience before a title filter does (R1b, A2).
  3. You present R2 and R7 as adjacent experience, never as having owned an API product or a roadmap.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics tech, about 150 people, Series B | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; deliver with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | The only PM over a partner-facing platform with two squads. This is a full platform-PM mandate, not an associate role, so the 3+ year bar is consistent with the scope | `[inferred]` from squad count and mandate breadth |
| Market calibration | Not established. The role-family sweep couldn't run (see Evidence status), so I have no salary or title band to set this against | — |
| Unknowns | Pay, location, reporting line, who holds roadmap authority, how mature the API is (new build or existing), how many partners | `[grounded]` JD silent on each |
| Contradictions | None inside the JD. I couldn't check it against the careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | PM-shaped work over 3+ years: requirements, prioritization input, delivery coordination | must_have | adjacent | medium | transferability | Seven years of requirements documents, roadmap-input sessions and coordinating custom builds. These are PM activities. Limit: prioritization decisions sat with the PMs you fed | `[grounded]` your resume summary, self-reported and not yet probed | Make the bridge explicit in the application (A2, P2) |
| R1b | 3+ years with a product manager title | must_have | absent | none | capability | You state you have never held a PM title. No discovery can create titled years | `[grounded]` your statement; `[generic]` that a literal "3+ years PM" requirement is often screened by title | Closure path: a referral or a direct line to the hiring manager (A2). Otherwise carry it as the main risk |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs, end to end, on the provider's side, which is the side Quartzline sits on. Limit: implementing an existing API isn't owning its design or roadmap. The custom builds you coordinated may move this row | `[grounded]` your summary | G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | You stated Postman, SQL, reading OpenAPI specs, and integration architecture across 30+ integrations. That's specific, but nothing has been inspected yet | `[grounded]` your summary | Optional: a sanitized integration architecture doc would raise this to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, the client's engineers and PMs on custom builds | `[grounded]` your summary | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your summary doesn't mention working with sales | `[grounded]` summary silent | Ask in a later turn; not asked here to stay within three questions |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | Your summary doesn't mention sprints, backlogs or any delivery method | `[grounded]` summary silent | G3 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions are discovery. Limit: you gathered and passed on input, and someone else turned it into product decisions | `[grounded]` your summary | Bridge in the application, limit stated |
| R7 | Own the roadmap | important | adjacent | medium | transferability | You fed the roadmap through quarterly sessions. Owning it means deciding trade-offs, which your summary doesn't claim | `[grounded]` your summary | Bridge, limit stated; RR4 may lower the bar |
| R8 | Write specs | important | direct | medium | none | Requirements documents for custom builds, plus the integration playbook your whole team uses | `[grounded]` your summary | Optional: a sanitized requirements doc → high |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your summary doesn't mention metrics. A note from a prior conversation mentions an internal triage tool that support agents adopted. It's unconfirmed, so it only prompts a question | `[grounded]` summary silent; memory lead, unconfirmed | G2 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You took 30+ integrations to go-live. Limit: a client go-live isn't a product launch with sales and support enablement | `[grounded]` your summary | Bridge, limit stated |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform products (R2, must_have) | discovery | You coordinated custom builds, but your summary doesn't say whether any became product capability, or what you decided about them | A shipped capability you shaped would strengthen R2 | A custom endpoint or field that later went into the standard API; a spec of yours that engineers built from; a pattern from the playbook that changed the product | A requirements doc, a release note, a changelog entry | `[grounded]` summary silent on outcomes |
| G2 | Adoption metrics (R9, important) | discovery | Your summary doesn't mention metrics; there's an unconfirmed lead about a triage tool | A tool people adopted, with adoption you measured, is direct evidence for R9 | The triage tool, if it exists; playbook usage; integration time-to-live or failure rates you tracked | A dashboard screenshot, a usage report, an internal post | `[grounded]` summary silent; memory lead, unconfirmed |
| G3 | Agile delivery (R5, must_have) | discovery | Your summary doesn't mention any delivery method | A must-have; if this is already true, one answer moves it to direct | Working inside engineering sprints for custom builds; writing or grooming tickets; sprint reviews or demos with clients | A ticket you wrote, a sprint board excerpt | `[grounded]` summary silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not confirmed from attributable sources (the searches were refused in this session; nothing negative was found) | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have much of a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (posting states no figure) | The range may be set in the screen, and its level against the market is unknown | `[inferred]` from the posting's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | (posting states neither) | It could be remote, hybrid or office-based; this matters only against your own constraints | `[inferred]` from the posting's silence | Is this role remote, hybrid or office-based, and where? | unresolved |
| RR4 | Roadmap authority not defined | unknown | — | "Own the roadmap for our partner-facing API platform" | "Own" could mean deciding priorities, or carrying out a roadmap set by a head of product or the CTO | `[inferred]` from the JD's silence on reporting line | Who sets platform priorities today, and which trade-offs does this PM decide alone? | unresolved |
| RR5 | Scope comes with resources and a success measure | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The mandate names both a team and a way to measure success | `[grounded]` JD | What adoption metrics exist today, and what's the current baseline? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find this role on Quartzline's own careers page before you put in effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Apply through a referral or a direct note to the hiring manager, not cold through the portal | R1b | `[generic]` titled-years requirements are often filtered before a person reads the resume | pending your approval |
| P1 | Lead with: "30+ client integrations of our REST APIs, end to end, from scoping workshops to go-live" | R2, R3, R4a | `[grounded]` your own sentence, unchanged in substance | pending your approval |
| P2 | Address the title gap directly: "I haven't held the PM title. Here's the product work I've done without it": requirements documents, the integration playbook your team uses, quarterly roadmap-input sessions | R1a, R1b | `[grounded]` your summary | pending your approval |
| W1 | A one-page work sample: a short spec plus an adoption-metric plan for a partner API, built from public docs or a made-up example | R2, R7, R9 | `[generic]` work samples are a common way career-changers make an adjacent case concrete | pending your approval |
| Q1 | Ask the verification questions from RR1–RR5 word for word in the loop | Register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a memory note about an internal request-triage tool that support agents adopted. It's unconfirmed and only prompts G2.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform careers"; refused (search permission not granted). It would have tested RR1 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs salary Series B B2B SaaS 2026"; refused. It would have filled market calibration and given RR2 a band |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as a `tuesday-dossier.md` if you want to carry it into later steps.

**Upgrade menu**
- Allow web search in this session → targets 1 and 2 run: RR1 may clear and market calibration gets a band. A deeper pass (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) can follow if you say so.
- Your constraints (pay floor, location, work authorization) → the hard-gates check runs against you rather than coming back unknown.
- A sanitized requirements doc or integration architecture doc → R3 and R8 to high.
- Answers to G1–G3 → R2, R9 and R5 move.
- The hiring manager's name → a sharper scope read and a choice of which story to lead with for that reader.

**Questions**

G1: Did any custom build you scoped become part of the standard product? What did you decide about it, as opposed to the PM?

G2: My notes from an earlier conversation mention an internal request-triage tool that support agents adopted. Is that real? If so, what was yours, and did you track how many people used it?

G3: Did your custom builds run through engineering sprints, and what was your part in them (writing tickets, grooming, reviews)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.