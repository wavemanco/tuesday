Let me read the required references, and try fetching the posting in parallel.
Research is done; writing up the assessment now.

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week)
- `must_have`: direct: R2, R3, R4a, R8 · adjacent: R5 (Experience owning a forecast) · unclear: R4b (Spreadsheet modelling), R6 (Working with finance on revenue data) · absent: R7 (Billing data)

R5: a real bridge from your pipeline review, with its limit stated; R7: a gap you've stated yourself, which can be closed but not by rewording; R6: the one answer that could make R7 cost you less.

**Opportunity ledger.** The role looks sound and open about its terms. The employer exists as described (RR2), and the pay is stated and sits inside the market band (RR1). Three things are still open: whether the posting is live on Quillfield's own site (RR3), whether this is a team of one (RR4), and who owns the forecast number (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the office pattern works for you (R1); (2) you present R5 as adjacent and R7 as absent, never as forecast ownership or billing experience; (3) the team shape and who owns the forecast come out acceptable in the recruiter screen (RR4, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A in April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | "own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Terms | Bristol, hybrid with two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; before that, sales operations manager at Corvane Payments for four years | `[grounded]` public profile (search result) |
| Scope read | The forecast and billing-data duties put this role on the finance side of revenue operations, not only the sales side. Those two duties are exactly where your background stops | `[inferred]` from the mandate's wording against your stated history |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400 (n=438, 2026). The posting's range sits in the middle of that band | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting figure |
| Unknowns | Team size under this role; who owns the forecast number (this role or the CFO); which billing system they use; whether the role is listed on Quillfield's own site | — |
| Contradictions | None between the posting and Quillfield's About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what office pattern you can do, so this gate isn't settled | `[grounded]` posting terms; your message is silent | Closing question on R1 |
| R2 | 4+ years in revenue operations, sales operations or similar at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations. One open point: whether a "B2B payments company" counts as "B2B software" to this reader. The function and the years match | `[grounded]` your stated background; `[inferred]` that the sector question is the only open point | none |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | You state you hold the Salesforce admin certification. It hasn't been inspected yet, so this stays at `medium` | `[grounded]` your stated background | Optional: a link to your certification record would raise this to `high` |
| R4a | Strong SQL | must_have | direct | medium | none | "SQL weekly" is stated and specific about how often, but says nothing about depth | `[grounded]` your stated background | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" doesn't establish modelling (scenarios, drivers, forecasts). It may well be there, but the input doesn't settle it | `[grounded]` what your message does and doesn't say | Closing question G2 |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is the input to a forecast. Limit: you've stated you never owned the company forecast (finance did), so you haven't owned the number, the method, or the call with a CFO | `[grounded]` your own words, including the limit | See G3; frame honestly |
| R6 | Working with finance on revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue data". Billing is ruled out (R7), but renewal dashboards may have meant reconciling bookings, ARR or renewals data with finance. Nothing confirms it yet | `[grounded]` posting's "or"; `[inferred]` that renewal reporting may have touched finance data | Closing question G1 |
| R7 | Billing data (own it; work with finance on it) | must_have | absent | none | capability | You've said you have never worked on billing data. This is a stated gap, not a hidden one | `[grounded]` your own statement | Closure path in G4; carried as the main risk |
| R8 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | "Rebuilt our pipeline and renewal dashboards" is a direct match for the duty. It hasn't been inspected yet | `[grounded]` your stated background | Optional: a sanitized dashboard screenshot would raise this to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working with finance on revenue data (R6, must_have) | discovery | Renewal dashboards built, but no word on whether finance's numbers fed them or were checked against them | If R6 becomes `adjacent` or `direct`, the billing gap (R7) becomes one weak spot in finance-facing work rather than the whole area missing | Reconciling closed-won bookings in Salesforce against finance's revenue or ARR figures; agreeing renewal dates or contract values with finance; supplying pipeline or renewal numbers that went into finance's forecast or board pack | A sanitized reconciliation sheet, a dashboard definition doc, an email thread with finance about mismatched numbers | `[grounded]` your message's silence; `[inferred]` that this changes how R7 reads |
| G2 | Spreadsheet modelling (R4b, must_have) | discovery | "Excel daily", with no modelling described | A must-have, and the forecast duty depends on it | A capacity or quota model; a renewal-rate or churn projection; a what-if model for the sales director's pipeline review | A sanitized model file or a screenshot of its structure | `[grounded]` your message's silence |
| G3 | Owning a forecast (R5, must_have) | transferability | Monthly pipeline review run with the sales director; finance owned the forecast | Carries over: pipeline inspection, deal-stage judgement, working with sales leadership. Doesn't carry over: building the forecast method, owning the number, defending it to a CFO. Would strengthen it: a short worked example of how you'd turn your pipeline review into a quarterly call | Your pipeline review, its stage definitions, any coverage ratios you report | A sanitized pipeline-review deck | `[grounded]` your own words; `[generic]` that interviewers for forecast-owning roles probe method and accountability |
| G4 | Billing data (R7, must_have) | capability | You've stated no billing-data experience | Closure path: Quillfield's own product is invoicing software, so its billing data is the domain the company teaches. A short self-study of subscription-billing concepts (invoices against bookings, credit notes, revenue against billings) before interviews narrows the distance. Your payments-company background is industry context, not billing-data experience | — | — | `[grounded]` About page and your statement; `[inferred]` that the employer's domain makes this learnable on the job |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range is open and around the market middle for this title | `[grounded]` posting; `[generic]` Ledgerline band | How are the share options structured, and what's the vesting schedule? | noted |
| RR2 | Employer established as described | positive_signal | — | "Quillfield, Bristol" | Company site matches the posting: invoicing software, Bristol | `[grounded]` About page | — | noted |
| RR3 | Posting not found on the company's own site | unknown | — | Listing is on Tallyboard; quillfield.co.uk/careers returned no page | The company may simply list jobs only on job boards, or the posting may be older than the board shows | `[generic]` pattern for job-board listings, not a claim about this one | Is this role still open, and where on your own site is it listed? | unresolved |
| RR4 | Team shape unstated against a wide mandate | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | CRM, billing data, reporting and the forecast could all be one person's job at a 96-person company | `[inferred]` from the mandate's breadth against the posting's silence on team | Does this role have anyone reporting to it, and how is work split with Tamsin and with finance? | unresolved |
| RR5 | Forecast ownership boundary | unknown | — | "run the quarterly revenue forecast with the CFO" | It's unclear whether this role builds and owns the number, or prepares inputs the CFO owns. That decides how much R5 counts against you | `[inferred]` from "with the CFO" | Who owns the quarterly forecast number today, and what will this role own in the first two quarters? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dashboard rebuild and the monthly pipeline review, in your own words: "rebuilt our pipeline and renewal dashboards"; "run the monthly pipeline review with our sales director" | See R8, R5. These are the closest matches to the mandate | `[grounded]` your stated background | pending your approval |
| P2 | Name the forecast and billing limits yourself, for example: "Finance owned the company forecast; I ran the pipeline review that fed it. I haven't worked on billing data." Don't let the reader find the limits first | See R5, R7. Two of the posting's five listed requirements | `[grounded]` your own words | pending your approval |
| P3 | Expect a short read of your background by someone with a similar path: Tamsin's public profile shows payments sales ops moving into revenue operations, so your payments context may need less translating | See role reality, hiring manager | `[grounded]` profile; `[inferred]` that less translating is needed | pending your approval |
| P4 | Ask RR4's and RR5's questions in the recruiter screen before investing in later rounds | They decide how much R5 and R7 weigh | `[grounded]` register | pending your approval |
| P5 | Before interviews, do the billing self-study in G4 | Narrows R7; it can't close it | `[inferred]` from G4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization row, RR2 and RR3 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager row and P3 |

I can save all of this as a `tuesday-dossier.md` if you'd like a copy to keep.

**Upgrade menu**
- Your location, office-day limits and pay floor → R1 settles, and the pay range is checked against your own floor.
- Answers to G1 and G2 → R6 and R4b get proper calls, and the decision may firm up.
- Your Salesforce certification record or a sanitized dashboard screenshot → R3 or R8 rises to `high`.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1: Can you work from Bristol two days a week?

G1: Did your renewal or pipeline reporting ever use, or get checked against, finance's revenue, bookings or ARR figures? What did you do with them, and who in finance was involved?

G2: Have you built a spreadsheet model (capacity, quota, churn or a what-if) rather than reports? What did it model, and who used it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.