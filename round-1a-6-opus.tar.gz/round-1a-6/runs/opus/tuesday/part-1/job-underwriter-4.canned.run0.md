Running the job-underwriter check now. I've read the method; next I'm verifying Brindlemoor and the market for this role.
Yes, apply, but first settle one thing: whether the job is really remote. Your record matches the job description's core requirements. What isn't settled is the work location, because the posting and the company's own careers page disagree.

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Working location: "Fully remote (UK)")
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R8 (Pet-insurance product) · unclear: R9 (Recommendations for product)
- `preferred`: direct: R10

R6 (`medium`): you ran the tests, but you haven't said whether you designed them. R8: the motor-to-pet bridge holds, and its limit is named. R9: you haven't mentioned any recommendations made to a product team.

**Opportunity ledger.** The posting says fully remote, but the employer's own careers page says Leeds four days a week (RR1). The salary isn't given (RR2), and how much support sits behind "own pricing analytics" isn't stated (RR3). On the positive side, the employer and the live posting both check out, and the hiring manager has spoken publicly on monitoring rating models (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Working location: fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm with the employer where the job is actually done, and it works for you (R1, RR1); (2) the budgeted salary meets your floor (RR2); (3) you present pet insurance honestly as new ground for you, never as experience you have (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; the name comes from you |
| Line management | No people-management requirement appears anywhere in the JD | `[grounded]` JD |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` JD and careers page; see RR1 |
| Scope read | "Own" points to one analyst holding the product's pricing analytics end to end, with no team or tooling named | `[inferred]` from the JD's verb against its silence on team |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900. This is what to expect, not Brindlemoor's offer, and the posting gives no salary (RR2) | `[generic]` Pricewell 2026 UK pay survey (n=612); `[grounded]` JD silent on pay |
| Unknowns | Salary; team size and support; which work pattern is the real one | n/a |
| Contradictions | Fully remote (JD) against Leeds four days a week (careers page) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working location: "Fully remote (UK)" | hard_gate | unclear | none | hard_gate | You haven't said whether you need remote work or could do Leeds four days a week, and the employer's two sources disagree on the terms | `[grounded]` JD against careers page; your constraint not stated | Question 1; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific but self-reported, with nothing to inspect | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You say "daily". Specific, but there's no artifact yet, so expect a technical probe | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained a GLM rating model for the young-driver book | `[grounded]` your intake | A sanitized model-documentation excerpt would raise this to high |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers the build. Monitoring isn't named, but maintaining a live model usually includes it | `[grounded]` your intake; `[inferred]` that maintenance included monitoring | Confirm what monitoring you did (drift checks, actual-vs-expected) before leading with it |
| R6 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests last year with the underwriting team" shows you ran and read them. Whether the design was yours isn't stated, so the smaller reading stands | `[grounded]` your intake | G1, Question 2 |
| R7 | Present to underwriting or actuarial leads; turn results into recommendations | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R8 | Pet-insurance product pricing | important | adjacent | medium | transferability | Motor GLM rating and price testing carry over as method. You haven't priced pet risk, and `[generic]` pet rating runs on different factors and claims patterns from motor | `[inferred]` requirement from "our pet-insurance product"; `[generic]` the domain difference | G2 |
| R9 | Recommendations for product, not only underwriting | important | unclear | none | discovery | Your stated audience is underwriting. Nothing mentions a product team | `[grounded]` JD "for underwriting and product"; intake silent | G3 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R6, must_have) | discovery | 14 tests run with underwriting, but no word on who chose the cells, the sample sizes or the success metric | The JD says "design and read", and design ownership is the part a pricing director will test | Setting the test and control splits; choosing the sample size or test duration; defining the conversion or loss-ratio metric; deciding when to stop a test | A test plan or readout deck (sanitized) | `[grounded]` your intake; `[generic]` that design ownership gets probed |
| G2 | Pet-insurance product (R8, important) | transferability | Strong motor pricing method, with no pet exposure stated | It's the most visible difference between your CV and this role | Any non-motor line you touched; small-book or new-segment rating work; tests run on a new product | n/a; the honest framing is the closure | `[inferred]` bridge from your motor work |
| G3 | Product-facing recommendations (R9, important) | discovery | Only underwriting is named as your audience | The JD names product as a second audience | Pricing input to a product launch or redesign; a recommendation on cover or excess options | A review slide or recommendation memo | `[grounded]` JD against intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work location contradicts between JD and careers page | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One of the two is out of date, or the role changed after one was written | `[grounded]` both sources; `[inferred]` the causes | Is this role fully remote, or based in Leeds four days a week, and is that fixed? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in JD or on careers page) | The budget may sit inside the £52–65k band in role reality, or outside it | `[inferred]` from the missing figure, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Ownership with no team or tooling named | unknown | — | "Own pricing analytics for our pet-insurance product" | You could be the only pricing analyst on the product | `[inferred]` from "own" against the JD's silence on team | Who else works on pet pricing, and what data and tooling would I inherit? | unresolved |
| RR4 | Employer and posting verify; the manager speaks publicly on model monitoring | positive_signal | — | Careers page: "Accepting applications… reports to the Director of Pricing"; talk: "Small Books, Loud Errors" (2025 Insurance Pricing Forum) | The posting is live, and the manager's published interest overlaps with R5 | `[grounded]` careers page and public profile | How do you monitor the pet rating model today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask Brindlemoor about the work pattern (RR1) before you put effort into an application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with your own sentence: "Built and maintained the GLM rating model for our young-driver book". Add monitoring only once you've confirmed what you did (R5) | This reader's public talk is about monitoring rating models (RR4) | `[grounded]` your intake and her public profile | pending your approval |
| P2 | Second story: the 14 price tests run with underwriting, then the quarterly review to the head of underwriting. Claim design only if G1 confirms it | see R6, R7 | `[grounded]` your intake | pending your approval |
| P3 | Present pet as new ground: "I've priced motor, not pet; the GLM and testing method is what carries over" | see R8; never claim pet experience | `[grounded]` your intake | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3 and RR4 word for word during the interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

On management: the JD asks for none, so not having managed anyone doesn't count against you here.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The employer and live posting check out, and this found the Leeds contradiction (RR1, RR4) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Gave the market calibration band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned her public profile (linkedin.example/in/odile-varga): Director of Pricing, a 2025 talk on monitoring rating models, previously head of pricing analytics at Calloway Re. Fed P1 and RR4 |

If you want to keep this, I can save it as a `tuesday-dossier.md` file.

## Upgrade menu

- **Your location constraint:** settles whether R1 is met or failed.
- **Your salary floor:** lets me set RR2's answer against the band.
- **A sanitized model-documentation or validation excerpt:** raises R4 and R5 to `high`.
- **A sanitized price-test plan or readout deck:** settles G1 and raises R6 to `high`.
- **A slide from the quarterly review:** raises R7, and R9 if any of it went to product.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, hiring pattern, employee reports; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

**R1 / RR1:** Do you need the job to be fully remote, or could you work from Leeds four days a week?

**G1:** For the 14 price tests, which parts did you design yourself, such as the test cells, sample size or success metric, and which came from underwriting?

**RR2:** What's the lowest base salary you'd accept for this move?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.