Now the referenced files.
## Decision snapshot

**Yes, apply, as long as the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R10 (Fully remote (UK))
- `must_have`: direct: R1, R2, R3, R4, R6a, R7 · unclear: R6b (Monitor rating models)
- `important`: direct: R8a · adjacent: R9 (Pet-insurance pricing knowledge) · unclear: R8b (Recommendations to product)
- `preferred`: direct: R5

R9: you can carry your motor pricing across to pet, but the limits of that need saying; R6b, R8b: the CV doesn't show these yet, and one answer each would settle them.

**Opportunity ledger.** The role reads as well defined. The responsibilities and the people you'd report results to are named (RR4). Three things are open: the employer and posting are unverified because the search was blocked (RR1), the salary isn't given (RR2), and the team size behind "own pricing analytics" isn't stated (RR3).

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting check out (RR1); (2) you're UK-based with UK right to work (R10); (3) you present the motor-to-pet move honestly as adjacent experience, not as pet-insurance experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Line management | The JD lists none: no direct reports, no team lead duties | `[grounded]` JD silence |
| Scope read | A senior individual-contributor role. "Own" suggests you'd be the main pricing analyst for one product, possibly without much team around you | `[inferred]` from "Own pricing analytics" plus the JD naming no team (RR3) |
| First-90-days outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not established: the role-family search was blocked, so there's no salary band to quote | n/a |
| Unknowns | Salary; team size and who you'd work with; the main KPIs; which pricing tools they use | n/a |
| Contradictions | None in the JD; it couldn't be checked against Brindlemoor's own careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Stated and specific, nothing inspectable yet | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily": you use them daily; how strong you are will be tested | `[grounded]` your background; `[generic]` pricing roles often include a technical test | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R5 | Insurance experience | preferred | direct | medium | none | 5 years at a UK insurer | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | Built the young-driver GLM | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" could mean ongoing monitoring (checking predictions against outcomes, factor drift, refits) or just upkeep. Read conservatively until you confirm | `[grounded]` your wording "maintained" | G1 |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. "With" leaves open which parts of the design were yours, and an interviewer may probe that | `[grounded]` your background; `[generic]` that interviews probe who owned what | G1 |
| R8a | Recommendations for underwriting | important | direct | medium | none | Your quarterly review to the head of underwriting, and tests run with underwriting | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Your background mentions only underwriting, not a product team | `[grounded]` your background is silent on product | G2 |
| R9 | Pet-insurance pricing knowledge | important | adjacent | medium | transferability | What carries over: GLM rating, price testing, presenting to underwriting. The limit: you haven't worked with pet-specific rating factors or claims patterns | `[inferred]` requirement, from the product being pet insurance; `[grounded]` you've never worked on pet; `[generic]` pet rating uses risk factors different from motor's | G3 |
| R10 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The posting implies UK-based work. Your location and right to work aren't stated; working at a UK insurer suggests them but doesn't confirm them | `[grounded]` JD "Fully remote (UK)"; `[inferred]` from your UK employer | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring models and designing tests (R6b, R7) | discovery | Built and maintained the model; ran 14 tests with underwriting. Monitoring and design ownership aren't stated | Both are must-haves, and this is where an interviewer is most likely to dig in | Regular checks of predicted vs actual claims on the young-driver book; deciding when to refit; choosing test cells, sample sizes or the success metric; writing up the test results | A sanitized test readout or monitoring dashboard | `[grounded]` your wording; `[generic]` that ownership gets probed |
| G2 | Recommendations for product (R8b) | discovery | Only underwriting is mentioned | The JD names product as a second audience | Pricing input on a cover change, a new tier or excess option, or a launch; working with marketing or product on conversion | An email or slide that went to a product owner | `[grounded]` your background is silent on product |
| G3 | Pet-insurance knowledge (R9) | transferability | Strong motor pricing, no pet experience | The likeliest objection to your application | What you know about how pet risk factors and covers differ from motor, shown through how you would approach the problem | A short note on how you'd approach pet rating factors (only if you want to write one) | `[generic]` that domain switching is the likely objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not confirmed from sources I could check (search blocked) | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to show up much online, the posting may be stale or reposted elsewhere, or it may not be a real hiring employer | `[generic]` common pattern, not a claim about Brindlemoor | Can you point me to this role on Brindlemoor's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Salary not given | unknown | — | (none stated) | The pay may be below what the senior title suggests, or they may simply not publish salaries | `[inferred]` from the posting leaving out pay | What salary range is budgeted for this role? | unresolved |
| RR3 | Owns the function, team not described | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only pricing analyst, with limited data engineering or actuarial support | `[inferred]` from "own" plus no team being mentioned | Who else works on pet pricing, and what data and engineering support does the role have? | unresolved |
| RR4 | Responsibilities and audiences clearly defined | positive_signal | — | "build and monitor rating models, design and read price tests… recommendations for underwriting and product" | The scope is concrete and matches the title | `[grounded]` JD | What would a strong first six months look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Brindlemoor's own careers site before you apply | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Open with three facts in your own words: "Built and maintained the GLM rating model for our young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting" | R3, R7, R4: the JD's core asks | `[grounded]` your background | pending your approval |
| P1 | Present pet as a new product line where your pricing method carries over, not as a domain you already know | R9 | `[grounded]` R9 row | pending your approval |
| Q2 | Ask the questions from RR2, RR3 and RR4 word for word if you get a call | The register doubles as interview prep | `[grounded]` register | pending your approval |

On management: the JD asks for none, so not having managed anyone isn't a gap for this role.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused ("Brindlemoor pet insurance careers"). It would have confirmed or cleared RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Search refused ("senior pricing analyst insurance UK salary remote GLM"). It would have given the market calibration line and a salary band for RR2 |
| 3. Hiring manager's public footprint | unavailable | Search refused ("Odile Varga Director of Pricing"). It would have shown which of your stories to lead with for Odile Varga (E1) |

I can save this as a `tuesday-dossier.md` for later steps if you'd like.

## Upgrade menu

- **Allow web search:** fills all three research targets, could clear RR1 and gives a salary band for RR2.
- **Your CV:** a full evidence inventory and sharper rows.
- **An artifact you can show**, like a sanitized test readout, model documentation summary or quarterly review deck: raises R3, R6a, R7 or R4 to `high` confidence.
- **Your non-negotiables** (salary floor, location, contract type): turns the hard-gates check from unknown to real.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, employee reviews, recent news). It takes up to 5 more searches and 2 more fetches; just say the word.

Q1 (R10): Are you based in the UK with the right to work here without sponsorship?

G1: For the young-driver model and the 14 tests: did you run ongoing monitoring of the model, and which parts of each test's design (cells, sample size, success metric) were yours rather than underwriting's?

G2: Has any of your pricing work gone to a product team, for example on a cover change, a new tier or a launch, rather than only to underwriting?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.