Posting read. Now checking Quillfield's own site, the market band, and the hiring manager's public profile before writing the assessment.
Yes, I think it's worth applying, on conditions. Your strongest asset lines up with the hiring manager's own background. Your two gaps (forecasting and billing data) are real, and the posting names both as requirements. The full assessment follows.

## Decision snapshot

**Yes, worth applying, on the conditions below. R5 (forecast) and R7 (billing data) are the gaps you named, and R1 (Bristol, two office days a week) isn't confirmed yet. Status: `conditional_go`.**

**How well you fit, row by row**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week)
- `must_have`: direct: R2a, R3, R4a · adjacent: R5 (Experience owning a forecast) · unclear: R2b (at a B2B software company), R4b (Spreadsheet modelling), R6 (Working with finance on billing or revenue data)
- `important`: direct: R8 · absent: R7 (Owning billing data)

R5: a credible bridge from your monthly pipeline review, with its limit stated; R6: still open; R7: absent by your own account; R2b and R4b: still open, not asked about this turn.

**How sound the role looks.** It looks sound. The pay is stated and sits inside the market range (RR1), and the employer and hiring manager both check out (RR5). Three things are still open: one role covers systems, billing data, reporting and the forecast, with no team mentioned (RR2); who signs off the forecast (RR3); and I couldn't find the posting on Quillfield's own site (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) two office days a week in Bristol works for you (R1); (2) you present R5 as adjacent: you ran the pipeline review, but finance owned the forecast; (3) you're open about R7 as a gap, and RR2's question about support for billing data gets a workable answer in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | One lead role covering CRM admin, billing data, reporting and forecasting, with no team or reports mentioned | `[inferred]` from the posting's four responsibilities and its silence on a team |
| Market calibration | Ledgerline's 2026 guide (UK B2B software, n=438) puts revenue operations leads at a median base of £64,200, middle half £57,800–£70,400. The posted range sits inside that and straddles the median. The guide's figures are a market range, not this employer's offer | `[generic]` role-family sweep, 2026 pay guide; `[grounded]` posting, for the stated range |
| Unknowns | Team size or reports; who signs off the forecast; how billing data is set up today; success measures for the first year; share option terms | — |
| Contradictions | None between the posting and Quillfield's about page. No careers page found at quillfield.co.uk/careers | `[grounded]` about page via search; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You didn't say where you're based or how many office days you'll work, so the gate isn't established either way | `[grounded]` posting states the terms; your background is silent on them | Closing question on R1 |
| R2a | 4+ years in revenue operations or sales operations | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue ops for the UK team. Specific, but self-reported and not yet probed | `[grounded]` your background | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | You described the employer as "a B2B payments company". Whether it sells software isn't stated, and the posting asks for "a B2B software company" | `[grounded]` your wording against the posting's | Say what the payments company sells (platform, API, merchant software) when you apply |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate can be checked but hasn't been | `[grounded]` your background | Upgrade menu: the credential link |
| R4a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. Frequency is stated; depth will be probed | `[grounded]` your background; `[generic]` that ops-analytics interviews often include a SQL exercise | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" is stated; modelling (drivers, scenarios, a forecast model) isn't. Kept separate so daily use isn't read as modelling | `[grounded]` your wording against the posting's | Recall a model you built (capacity, quota, renewal or pipeline coverage) |
| R5 | Experience owning a forecast (the quarterly revenue forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. That's next to forecasting, but you said "I've never owned the company forecast — finance did that." Your word "company" leaves open whether you owned a UK team-level number | `[grounded]` your own statement; `[inferred]` that the pipeline review sits next to forecasting | Gap queue G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Billing is ruled out by your own account. The posting says "billing **or** revenue data", and renewal dashboards and handing data to a finance-owned forecast may count, but neither is stated | `[grounded]` your statement and the posting's "or" | Gap queue G2 |
| R7 | Owning billing data | important | absent | none | capability | You said you've never worked on billing data, and the posting puts it in the role's first sentence of duties | `[grounded]` your own statement | Gap queue G3: closure path, carried as a material risk |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. That the audience included finance isn't stated | `[grounded]` your background | Upgrade menu: sanitized screenshots |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R5, must_have) | transferability | **Carries over:** running the monthly pipeline review with the sales director. **Limit:** finance owned the company forecast, so you've never owned the number signed off with a CFO. **Strengthener:** any team-level call you made yourself | R5 is a must-have at `adjacent`, and the role's forecast duty sits right beside the CFO | Calling a UK commit or a best-case number each month or quarter; building the pipeline-weighted view finance used as input; tracking forecast vs actual for the UK team | A sanitized pipeline-review deck, or a forecast-vs-actual sheet | `[grounded]` your statement; `[inferred]` that a team-level call would narrow the limit |
| G2 | Finance on billing or revenue data (R6, must_have) | discovery | Renewal dashboards and a finance-owned forecast both exist in your background. Whether you worked with finance on revenue data isn't stated | Settling R6 could move the condition on R7 | Reconciling renewal or ARR figures with finance; supplying pipeline or renewal data for finance's forecast; agreeing revenue definitions (bookings vs ARR) with finance | A definitions doc, a reconciliation sheet, a sanitized dashboard | `[grounded]` your background is silent on finance work |
| G3 | Owning billing data (R7, important) | capability | No direct or adjacent billing-data work, by your own account | It's the first duty in the posting; carried as a material risk, not something wording can fix | Closure path: learn subscription billing data models (invoices, credit notes, revenue recognition basics) and how they join to CRM records before interviews | A short self-study note or worked SQL join you could talk through | `[grounded]` your statement; `[generic]` that billing-to-CRM reconciliation is core RevOps work |
| G4 | B2B software company (R2b, must_have) | discovery | "B2B payments company" | The posting asks for software specifically | A payments platform, API or merchant software product | The company's own product description | `[grounded]` your wording |
| G5 | Spreadsheet modelling (R4b, must_have) | discovery | "Excel daily" | Modelling is named in the requirements | A quota, capacity, territory or renewal model with assumptions you set | A sanitized model | `[grounded]` your wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and within the market range | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The stated range sits inside the 2026 guide's middle half, so pay is transparent and market-normal | `[grounded]` posting; `[generic]` guide range | Where in the range would an offer land, and what are the share option terms? | noted |
| RR2 | Four responsibilities in one role, no team mentioned | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast" | The role may combine systems admin, data and forecasting with no support. Low, because a RevOps lead at around 100 people often does all four | `[inferred]` from the posting's scope and its silence on a team; `[generic]` company-size pattern | Does anyone report into this role, and who supports billing data today, finance or a data team? | unresolved |
| RR3 | Forecast decision rights unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast while the CFO owns the number | `[inferred]` from "with the CFO" | Who signs off the quarterly forecast: this role, the CFO, or the Head of Revenue Operations? | unresolved |
| RR4 | Posting not found on Quillfield's own site | unknown | — | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | The role may be advertised only on job boards, or the careers page may be at another address | `[generic]` hiring pattern, not a claim about Quillfield | Is this role still open, and is it listed on Quillfield's own site? | unresolved |
| RR5 | Employer and hiring manager check out | positive_signal | — | Recruiter named Tamsin Achebe | Quillfield exists as described, and a public profile shows Tamsin Achebe as its Head of Revenue Operations | `[grounded]` about page; public profile | What does the first year in this role look like to you? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dashboard rebuild and the monthly pipeline review | See R8 and R5. Tamsin Achebe's public profile shows four years as a sales operations manager at a payments company, so your setting maps closely to hers | `[grounded]` public profile; `[inferred]` that the parallel helps this reader follow your story | pending your approval |
| P2 | Describe R5 in your own terms, for example: "I run the monthly pipeline review with our sales director; finance owned the company forecast." | Honest about the limit, which interviewers can check | `[grounded]` your sentences, unchanged | pending your approval |
| P3 | Say plainly that billing data is new to you, and name how you'd get up to speed (G3) | R7 is absent, and the posting leads with it | `[grounded]` your statement | pending your approval |
| P4 | Ask RR2 and RR3 word for word in the loop | Together they decide whether R5 and R7 are survivable | `[grounded]` register | pending your approval |
| P5 | Confirm with the recruiter that the role is live and that two days a week in Bristol is fixed | See RR4 and R1 | `[grounded]` RR4, R1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield "Revenue Operations Lead" job Bristol", which returned nothing. Fetched quillfield.co.uk/careers, which had no page. Moved: the organization and contradictions rows, plus RR4 and RR5 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: P1's positioning and RR5 |

I can save all of this as a `tuesday-dossier.md` file if you'd like a copy to keep.

## Upgrade menu

- **Your location and office-day limit, and your salary floor:** settles R1 and checks the pay against what you need.
- **Your CV:** every row is checked against what you've actually written, and R2b's employer description gets settled.
- **Your Salesforce admin credential link:** raises R3 to `high`.
- **Sanitized dashboard screenshots or a pipeline-review deck:** raises R8 and strengthens G1's bridge.
- **A deeper research pass on Quillfield** (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

**R1:** Does working from the Bristol office two days a week work for you, given where you're based?

**G1:** In the monthly pipeline review, did you ever call a number yourself, such as a UK commit or a best case, or track forecast against actual for the UK team, even though finance owned the company forecast?

**G2:** Have you worked with finance on revenue figures, for example reconciling renewal or ARR numbers, or supplying the pipeline data their forecast used?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.