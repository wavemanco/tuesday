I've read the job-underwriter playbook and am now checking Brindlemoor, the market and the hiring manager online.
# Should Renata apply? Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, it's worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote)
- `must_have`: direct: R2, R3, R4, R5, R7, R8 · unclear: R6 (Own pricing analytics for the product)
- `important`: adjacent: R11 (Pet-insurance domain) · unclear: R9 (Recommendations for product)
- `preferred`: direct: R10

R6: owning a whole product's pricing versus one book is not yet established. R7: running tests is confirmed, but designing them isn't stated. R11: a credible bridge from motor, with its limit named. R9: product-facing work isn't stated.

**Opportunity ledger.** The role is clearly scoped with named audiences (RR3). The employer and posting could not be checked from here (RR1), the salary is not given (RR2), and the size of the pricing team is not stated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're based in the UK with the right to work here (R1); (2) the posting is live on Brindlemoor's own careers page (RR1); (3) the salary clears your floor (RR2); (4) the pet move is framed as a bridge from motor, never as pet experience (R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing, named as hiring manager | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Line management | None mentioned anywhere in the JD | `[grounded]` JD silence |
| Scope read | A senior individual-contributor role. "Own" plus a director above it reads as product-level ownership without a team | `[inferred]` from the JD's verbs, its silence on reports and the named director |
| Market calibration | Not run: the role-family search was refused in this session | — |
| Unknowns | Salary; the size of the pricing team; whether "own" means sole analyst | — |
| Contradictions | None in the posting as pasted. Not checked against the careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based for a fully remote UK role | hard_gate | unclear | low | hard_gate | A current UK employer suggests it, but you haven't stated your location or right to work | `[inferred]` from "UK motor insurer" | Question 1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, the last 2 as senior. You stated it, but there's nothing to inspect yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily". Stated and specific, but no work to inspect | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model. A strong, specific claim; expect a technical probe | `[grounded]` your background | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" matches "build and monitor" for one book | `[grounded]` your background | none |
| R6 | Own pricing analytics for a whole product | must_have | unclear | low | discovery | Your model covered the young-driver book. Whether you owned pricing beyond that segment isn't stated | `[grounded]` your background's own scope | G1 / Question 2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | 14 tests last year is strong evidence of running tests. "Ran… with the underwriting team" doesn't say who designed them or wrote the read-out, so I've read it as the smaller claim | `[grounded]` your background | G2 / Question 3 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. A direct match | `[grounded]` your background | none |
| R9 | Recommendations for product teams | important | unclear | low | discovery | Underwriting is covered (R8). Product-facing work isn't mentioned | `[grounded]` your background's silence | G3 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R11 | Pet-insurance pricing domain | important | adjacent | medium | transferability | GLMs, price tests and underwriting sign-off carry across. Limit: no pet product, rating factors or claims data | `[inferred]` requirement, from the product named in the JD; `[grounded]` your "never worked on pet insurance"; `[generic]` that pet and motor books use different rating factors and claims patterns | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-product ownership (R6, must_have) | discovery | A model for one book; no wider scope stated | "Own pricing analytics" is the headline of the role | Covering pricing for other segments; running rate reviews across the book; being the go-to pricing person for a product | Sanitized rate-review summary, scope note | `[grounded]` your background; `[inferred]` that this is the scope question to settle |
| G2 | Price-test design (R7, must_have) | discovery | 14 tests run; design and read-out ownership not stated | The JD names design and reading as separate duties | Setting test cells and sample sizes; choosing success metrics; writing the conclusion underwriting acted on | Sanitized test plan or read-out deck | `[grounded]` JD wording; `[generic]` that interviewers probe test design |
| G3 | Product-facing recommendations (R9, important) | discovery | Only underwriting audiences mentioned | Half of the JD's stated audience | Advising on product features, discounts or distribution-channel pricing | Any memo to a product or commercial team | `[grounded]` JD; your background's silence |
| G4 | Pet domain (R11, important) | transferability | Motor only | You need to show you can learn a new book quickly | Times you picked up an unfamiliar segment or new rating data | A short self-study note on pet pricing as a work sample | `[inferred]` bridge from your motor GLM work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have much online presence, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. I couldn't check because the search was refused | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me to this role on your own careers site? | unresolved |
| RR2 | Salary not given | unknown | — | (no salary in the posting) | The figure may sit below what a senior pricing role usually pays, or the company may just not publish salaries | `[inferred]` from the missing figure; band not calibrated | What salary range is budgeted for this role? | unresolved |
| RR3 | Clear mandate and named audiences | positive_signal | — | "turn the results into recommendations for underwriting and product" | The scope is defined and the readers are named | `[grounded]` JD | Which pricing decisions has this role fed into recently? | noted |
| RR4 | "Own" with no team or resources stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the only pricing analyst, carrying the whole product without support | `[inferred]` from "own" against the JD's silence on team size | How many people work in pricing, and who would I work with day to day? | unresolved |

## Application plan

The positioning in A1–A3 is proposed language: it is `resume_edits_pending_approval`, and each row needs your approval before you use it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your own words: "built and maintained the GLM rating model for our young-driver book"; "ran 14 price tests last year with the underwriting team"; "present the quarterly pricing review to the head of underwriting". Don't write "designed" or "owned pricing" unless G1 and G2 confirm it | See R4, R7, R8, R6 | `[grounded]` your background | pending your approval |
| A2 | Frame pet as a bridge: "the same GLM and price-testing toolkit, applied to a new book". Claim no pet knowledge | See R11 | `[grounded]` your "never worked on pet insurance" | pending your approval |
| A3 | Don't raise the lack of people management. The JD asks for none; if asked, say it plainly | See role reality, line management | `[grounded]` JD silence | pending your approval |
| A4 | Confirm the posting on Brindlemoor's own careers page before applying | See RR1 | `[grounded]` RR1 | pending your approval |
| A5 | Ask the RR2 and RR4 questions at the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; refused by permissions. It would have resolved RR1 and checked the posting is live |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary 2026 remote"; refused. It would have given a market salary band for RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing insurance"; refused. It would have shown which of your stories to lead with for this reader |

I can save this as a `tuesday-dossier.md` file you can reuse at later stages, if that's useful.

**Upgrade menu**
- **Allow web search:** resolves RR1, sets a salary band against RR2, and reads Odile Varga's public professional background for the application plan.
- **Your salary floor and location:** closes R1 and RR2.
- **A sanitized price-test plan or read-out:** raises R7 to `high`.
- **A sanitized quarterly pricing review deck:** raises R8 to `high`.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, hiring patterns; up to 5 more searches and 2 more fetches, and it needs search permission): say the word and it runs.

**Questions**

R1: Are you based in the UK with the right to work here, and what's the lowest salary you'd accept?

G1: Did your pricing work cover anything beyond the young-driver book, such as other segments or rate reviews across the whole book?

G2: On the 14 price tests, which parts were yours: choosing the test design, running it, or writing the conclusion underwriting acted on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.