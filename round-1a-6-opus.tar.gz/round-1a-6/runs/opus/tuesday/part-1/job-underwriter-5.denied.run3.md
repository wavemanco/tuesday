Lots of references. Let me read the required ones.
**Short answer: yes, it's worth applying to, on three conditions listed in the snapshot.** Every core requirement matches your background, and the pay is at or above your recruiter's market band. The gaps are that you haven't used BigQuery, I couldn't confirm the posting myself (my web search was refused), and I don't know where you live or your salary floor. The full assessment is below.

## Decision snapshot

**Yes, worth applying to: R1, R2, R3, R4, R6 and R7 match directly, and RR2 puts the pay at or above the market band. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R10 (Remote (US) or our Denver office)
- `must_have`: direct: R1, R2, R3, R4, R6, R7
- `important`: adjacent: R5 (warehouse in BigQuery) · unclear: R8 (ingestion from our app and CRM), R9 (data contracts our analysts depend on)

R5: you know dbt and a cloud warehouse well, but you haven't used BigQuery itself. R8 and R9: your background doesn't mention them, which isn't the same as saying you lack them.

**Opportunity ledger.** Two signals are positive: the pay band (RR2) and a recent Series C (RR6). The equity terms (RR3) and the team and reporting line (RR4) are open questions. RR1 is what holds this at `conditional_go`: I couldn't run a search, so I haven't confirmed the employer or the posting myself.

- **Hard gates:** none failed; unconfirmed: R10 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is live on Pellucid's own careers page (RR1).
  2. You're US-based or can work from Denver, with US work authorization (R10).
  3. You describe BigQuery as a new platform for you, never as experience you have (R5).
- **What would flip it to `no_go`:** a base-pay floor above $166,000, or R10 failing.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning. Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the about page, as you pasted it. Not checked live (RR1) |
| Mandate | "Build and run the pipelines behind our tutoring platform's reporting": ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Must-haves | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Hard gate | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One area's pipelines (reporting), end to end, with no direct reports mentioned. That is a normal remit for the title, not a few roles bundled into one | `[inferred]` from the JD's mandate, set against the report's scope line; `[grounded]` the JD doesn't mention reports |
| Market calibration | The report puts Senior Data Engineer at Series B–D companies at a $151,000 median base, with the middle half earning $139,000–$163,500, and defines "Senior" as 5–8 years. The posting's $148,000–$166,000 starts $9,000 above the bottom of that middle range and tops out $2,500 above its top. Its midpoint, $157,000, is $6,000 above the median. Your 6 years fall inside the report's Senior range | `[grounded]` the Datawright 2026 report you pasted (n=2,310) and the JD; `[generic]` the band is a market pattern, not this employer's offer |
| Unknowns | Hiring manager; team size; equity terms; how much BigQuery depth they expect on day one; how "data contracts" works in practice there; which states remote covers | — |
| Contradictions | None between the JD and the about page as pasted. I haven't checked the live posting (RR1) | `[grounded]` the pasted text only |

## Evidence map

Your background was typed into the conversation, so I treat it like a resume: self-reported, not yet verified. That caps every row at `medium` for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. That's over the minimum and inside the report's 5–8 year Senior range. Self-reported so far | `[grounded]` your background; the report's seniority line | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You state "Python and SQL daily" | `[grounded]` your background | none |
| R3 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models. Specific, but nothing inspectable yet | `[grounded]` your background | Optional: an artifact that would raise this to `high` (see the upgrade menu) |
| R4 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement doesn't name a vendor | `[grounded]` the JD's wording and your background | none |
| R5 | Warehouse in BigQuery | important | adjacent | medium | transferability | The BigQuery stack is in the role description, not the requirements list, so I tiered it `important`. Your dbt modelling and warehouse SQL carry over. The limit: you've never used BigQuery. Interviewers will likely probe its own concerns: its SQL dialect, partitioning and clustering, and its cost model | `[grounded]` your "Never used BigQuery"; `[generic]` what interviewers probe on a platform switch | See G1 |
| R6 | Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | important | unclear | low | discovery | You don't mention ingestion sources. Running Airflow pipelines hints at it but doesn't establish it | `[grounded]` your background is silent; `[inferred]` the hint from the Airflow work | See G2 |
| R9 | Data contracts our analysts depend on | important | unclear | low | discovery | The test suite and dbt project are related work, but a data contract with analysts is a specific practice you haven't mentioned | `[grounded]` your background is silent on contracts | See G3 |
| R10 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what your US work authorization is | `[grounded]` the JD's term; nothing stated by you | Q1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Warehouse in BigQuery (R5, important) | transferability | dbt and Snowflake depth; no BigQuery use | The stack named in the posting is what they'll probe | Any Google Cloud use at all; a warehouse migration you worked on; tuning Snowflake costs or clustering, which uses similar reasoning | A small dbt-on-BigQuery practice project in a public repo | `[grounded]` your statement; `[generic]` that a platform gap gets probed |
| G2 | Ingestion from our app and CRM (R8, important) | discovery | Nothing on ingestion sources | It's the first responsibility the JD lists | Loading product or app event data; pulling from a CRM or a SaaS API; using an ingestion tool or custom connectors | A DAG excerpt or a design doc | `[grounded]` your background is silent |
| G3 | Data contracts our analysts depend on (R9, important) | discovery | A test suite and a dbt project; no contracts mentioned | The JD names contracts as something analysts depend on | Schema or freshness guarantees for downstream users; dbt model contracts or versioning; a breaking-change process; test results analysts could see | A contract spec, a dbt schema file, a runbook | `[grounded]` your background is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | I couldn't confirm the employer from my own sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver." | My one search was refused, so nothing is confirmed from my side. Possible reasons it might not hold up, none ranked as likely: the posting may be stale or reposted elsewhere, or the details may differ from the live page | `[generic]` a standard pattern check, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Stated pay is at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posting's range sits slightly higher than the report's middle half, $139,000–$163,500 | `[grounded]` JD and the pasted report; `[generic]` the report is not this employer's offer | Where in the $148,000–$166,000 range do offers for six years' experience usually land? | noted |
| RR3 | Equity terms not stated | unknown | — | "plus equity" | The amount, the type (options or shares) and the vesting schedule are all open | `[inferred]` from what the JD leaves out | What form does the equity take, how much is it, and on what vesting schedule? | unresolved |
| RR4 | Hiring manager, team size and reporting line not stated | unknown | — | (no hiring manager named) | The role could be one of several data engineers or the only one, and those are different jobs | `[inferred]` from what the JD leaves out | Who would this role report to, and how many people work on the data team? | unresolved |
| RR6 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | Raised nine months ago; not checked live (RR1) | `[grounded]` the about page as pasted | How do you expect the data team to change over the next year? | noted |

## Application plan

Each row below is a proposal. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt project you built on Snowflake (about 180 models) and the Great Expectations test suite you set up. Use your own verbs, "built" and "set up", and don't upgrade them | See R3, R4, R7 | `[grounded]` your background | pending your approval |
| P2 | Say plainly that BigQuery is new to you. Your case is that the modelling and testing carry over (R5). Optionally build the practice project from G1 before the interview | See R5, G1 | `[grounded]` your statement; `[generic]` that an honest framing holds up better under probing | pending your approval |
| P3 | Before applying, open Pellucid's own careers page yourself and confirm the posting is live | See RR1 | `[grounded]` RR1 | pending your approval |
| P4 | Ask the verification questions from RR2, RR3, RR4 and RR6 in the recruiter screen, word for word | The register doubles as screen prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search, "Pellucid Learning online tutoring Denver Senior Data Engineer", was refused by this session's permissions. It would have confirmed the posting is live and the about-page facts. RR1 stays open |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted already covers the market calibration row and RR2, so I sent no search |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was nothing to search |

If it would help, I can write this up as a `tuesday-dossier.md` file you can reuse later.

**Upgrade menu**
- **Search permission, or the live posting for me to read:** RR1 closes, and the status could move to `go`.
- **Your location and US work authorization:** R10 is settled either way.
- **Your base-pay floor and other non-negotiables:** I can check the $148,000–$166,000 range and the equity against them.
- **An answer on ingestion (G2):** R8 is resolved.
- **A public repo, a dbt docs or lineage export, or your Great Expectations config:** R3 and R7 rise to `high`.
- **The hiring manager's name:** target 3 runs, and P1 can be aimed at that reader.
- **A deeper research pass on Pellucid:** funding and leadership changes, hiring patterns, employee reports and recent news, using up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

Q1 (R10): Are you based in the US, or able to work from Denver, and are you authorized to work in the US without sponsorship?

Q2 (constraints): What's the lowest base salary you'd accept, and do you have other non-negotiables, such as remote-only, equity or a start date?

Q3 (G3, R9): Have you set up agreements with the analysts who use your models, such as schema or freshness guarantees, dbt contracts, or a breaking-change process? Which part of that was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.