Lots of required reading. Let me read the step-1 files.
## Decision snapshot

**No, this posting isn't worth pursuing: R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week, no exceptions), R2 (Base salary of $70–85k)
- `must_have`: direct: R4, R5, R6 · unclear: R3 (8+ years growth leadership), R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R11 (Team of one to start), R13 (E-commerce enablement business model) · unclear: R12 (Dotted line to the board)

R1, R2: fail on your own non-negotiables; R4, R5, R6 (`medium`): your revenue, paid and lifecycle record matches directly; R7, R8, R9, R10: channels your background doesn't mention, left open but irrelevant while R1 and R2 fail.

**Opportunity ledger.** Your sense that something is off is backed by the posting's own words. RR1 and RR2 are the terms that conflict with your floor and your location. RR3, RR4, RR5 and RR6 would be warning signs for anyone: a seven-function mandate with a team of one, open-ended hours, success metrics that "will evolve", and a base set against an 8+-years bar. RR7 is unspecified equity. RR9 is an employer I couldn't check from here. RR10 points the other way: the posting claims profitability and a CEO reporting line.

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week, no exceptions), R2 (Base salary of $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** Novaline would have to offer *both* a fully remote arrangement for a Portland-based hire *and* a base of at least $150k. Either change alone still fails the other gate. The only other route is you revising one of your non-negotiables, which is your call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup at Series A, which says it has been "profitable since day one" | `[grounded]` posting; not checked, see RR9 |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | To the CEO, with a dotted line to the board | `[grounded]` posting |
| Resources | "A team of one to start"; no budget stated | `[grounded]` posting; `[inferred]` from its silence on budget |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` posting |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | Several separate functions folded into one hands-on role at a senior title | `[inferred]` from the seven named functions against "team of one" |
| Market calibration | Not established: the role-family search was refused in this session (see Evidence status), so I'm giving no market band | — |
| Unknowns | Budget, equity terms, how success is measured, how the board relationship works | — |
| Contradictions | The posting asks for 8+ years of leadership and a board-facing mandate, then puts the base at $70–85k (RR3) | `[inferred]` from the posting's own terms set against each other |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint ("remote-only… not relocating"), which is specific and confirmed. The fit fails because the posting rules out exceptions | `[grounded]` posting and your stated constraint | Only you or the employer changing terms resolves it |
| R2 | Base salary of $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated $150k base floor. The posting's top figure is $65k under it, and equity is not base | `[grounded]` posting and your stated constraint | Only you or the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You state 9 years in growth, moving from Growth lead to Head of Growth. How many of those years were in leadership roles isn't stated, so I take the lower reading | `[grounded]` your background | See G1 |
| R4 | Own revenue growth end to end | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years, with a budget you controlled. It's specific, but nothing inspectable is attached yet | `[grounded]` your background | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You owned paid at both companies | `[grounded]` your background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle, and you're deep in Braze | `[grounded]` your background | none |
| R7 | SEO/content | must_have | unclear | none | discovery | Not mentioned in your background. That makes it unclear rather than absent on a first pass | `[grounded]` silence in your background | See G2 |
| R8 | Brand and PR | must_have | unclear | none | discovery | Not mentioned | `[grounded]` silence in your background | See G2 |
| R9 | Partnerships | must_have | unclear | none | discovery | Not mentioned | `[grounded]` silence in your background | See G2 |
| R10 | Sales ops | must_have | unclear | none | discovery | Not mentioned. Your background is B2C subscription | `[grounded]` your background | See G2 |
| R11 | Team of one to start | important | adjacent | medium | transferability | You built and led teams of 3–7, and SQL, GA4 and Braze depth points to hands-on ability. Limit: nothing stated shows you running every channel alone | `[grounded]` your background; `[inferred]` hands-on ability from your tool depth | See G3 |
| R12 | Dotted line to the board | important | unclear | none | discovery | Nothing stated about reporting to a board | `[grounded]` silence in your background | See G4 |
| R13 | E-commerce enablement business model | important | adjacent | medium | transferability | Your scaling record is B2C subscription. "Sales ops" in the mandate points to selling to merchants. Limit: no stated work selling to businesses | `[inferred]` from "e-commerce enablement" plus "sales ops" in the posting | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3, must_have) | discovery | 9 years in growth, split between lead and head roles; the split isn't given | Irrelevant here, but other Head of Growth postings set the same bar | Time as Growth lead with direct reports; time as Head of Growth | Titles and dates from your resume | `[grounded]` your background; `[generic]` that this bar recurs on similar postings |
| G2 | SEO/content, brand, PR, partnerships, sales ops (R7, R8, R9, R10, must_have) | discovery | None of these appears in what you shared | Irrelevant here. Full-funnel postings like this one bundle these functions | Content programs your team ran; agency or PR relationships you managed; co-marketing or affiliate deals | A content traffic dashboard, a partnership one-pager | `[grounded]` silence in your background; `[generic]` the bundling pattern |
| G3 | Solo, merchant-facing growth (R11, R13, important) | transferability | Team-led B2C subscription growth | It's the honest limit to name if you pitch yourself for B2B or solo roles | Periods with no team; B2B or marketplace side projects | Experiment logs you ran yourself | `[inferred]` bridge from your stated tools and model |
| G4 | Board reporting (R12, important) | discovery | Not stated | Irrelevant here | Board decks you contributed growth slides to | A sanitized board slide | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base sits at least $65k under your $150k minimum | `[grounded]` posting and your constraint | Is there flexibility in the base, and up to what figure? | confirmed |
| RR2 | On-site only against your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting says outright that it won't make an exception | `[grounded]` posting | Is there any fully remote path for this role? | confirmed |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required" | The posting wants senior leadership and a board-facing mandate at a base that reads as junior to mid-level. Market confirmation couldn't run | `[inferred]` from the posting's terms against each other | How did you set the base band for this role? | unresolved |
| RR4 | Bundled specializations, no resources | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several functions are folded into one hands-on seat, with no stated budget or hiring plan | `[inferred]` from the function list against "team of one" | What budget and headcount are committed in year one? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work is described as the culture, not an exception | `[grounded]` posting language | How often in the last quarter did "when it matters" happen? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for "all revenue growth" with no definition of success | `[inferred]` from the scope of the mandate against the unstated metrics | What would make this hire a success at 6 and 12 months? | unresolved |
| RR7 | Equity unspecified | unknown | — | "meaningful equity upside" | The equity's size, vesting and strike price are unstated, so its value can't be weighed | `[grounded]` posting withholds terms | What percentage, vesting schedule and last valuation apply? | unresolved |
| RR9 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR10 | Profitability and CEO reporting line | positive_signal | — | "profitable since day one… Report to the CEO" | If accurate, the company has runway and the role sits close to decisions | `[grounded]` posting claim, not checked | How has profitability held up since the Series A? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | See R1, R2 | `[grounded]` evidence map | pending your approval |
| A2 | If you want a definitive answer, send one message to the recruiter asking RR1's and RR2's questions, and stop if either answer is no | Only an employer changing terms reopens R1 and R2 | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Use RR3–RR6's questions as a screening checklist for similar postings | The register doubles as a filter | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1, R2 claims (your own stated constraints). Unverified leads: none.

Research tier: L1 (searches 2 of 5, fetches 0 of 2)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin"; the search was refused (no permission granted). It would have resolved RR9 and checked the stage and profitability claims |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026"; refused. It would have filled market calibration and confirmed or cleared RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save this as a `tuesday-dossier.md` for later sessions if you'd like.

**Upgrade menu**
- Allow web search → targets 1 and 2 run: RR9 resolves, market calibration gets a band, RR3 is confirmed or cleared. The decision stays `no_go` either way.
- A deeper research pass on Novaline (funding, leadership churn, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.
- Your resume → G1–G4 close, which helps with the next Head of Growth posting, not this one.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.