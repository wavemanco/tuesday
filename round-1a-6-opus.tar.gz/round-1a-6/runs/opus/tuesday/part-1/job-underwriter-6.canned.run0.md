Reading the reference files took a while. Next I'm opening the posting you linked, then doing a few quick searches.
Yes, it's worth applying, as long as the office days work for you. Status: `conditional_go`. I've only seen what you wrote in your message, not your CV, so every one of your claims below is graded `medium` at best.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid, two days a week in the office)
- `must_have` — direct: R2a, R3, R4a · adjacent: R5 (Experience owning a forecast) · unclear: R2b (At a B2B software company), R4b (Spreadsheet modelling), R6 (Working with finance on billing or revenue data)
- `important` — direct: R7

R7 — your strongest match and what to lead with; R5 — a real bridge, with a named limit: you never owned the number; R6 — the gap to work on first; R1 — the one thing that could stop this.

**Opportunity ledger.** The role looks sound. The pay is published and sits mid-market (RR3). The hiring manager the recruiter named matches public records (RR5). Open items: how forecast ownership is split with the CFO (RR1), whether there's a team behind the role (RR2), and the posting doesn't appear on Quillfield's own site (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two days a week in the office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) two office days a week in Bristol works for you (R1). (2) You describe R5 as adjacent: you ran the pipeline review, finance owned the forecast. Never claim you owned the forecast. (3) G1 brings out some revenue-data work with finance, or you go in with a clear plan for learning billing data (R6, see P4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about (search result) |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations; previously sales operations manager at Corvane Payments for four years | `[grounded]` public profile (search result); recruiter's name matches |
| Scope read | A broad seat: CRM, billing data, reporting and the forecast sit in one role. That's common for a "Lead" title at around 100 staff | `[inferred]` from the mandate against headcount; `[generic]` that companies this size merge these jobs |
| Market calibration | Ledgerline 2026: UK B2B software RevOps lead median base £64,200, IQR £57,800–£70,400. The posting's range sits around the median | `[generic]` role-family band (Ledgerline 2026, n=438); `[grounded]` posting figure |
| First-year outcomes | Not stated; probably a running quarterly forecast and reporting that finance trusts | `[inferred]` from the mandate wording |
| Unknowns | Team size; who owns the forecast number; which billing system; terms of the share options | — |
| Contradictions | None between the posting and Quillfield's About page (Bristol, invoicing software) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The posting states the term. You haven't said where you're based or whether you can travel in | `[grounded]` posting; your message is silent | Closing question on R1 |
| R2a | 4+ years in revenue ops, sales ops or a similar role | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. Clearly over the bar; it's your own account with no CV seen | `[grounded]` your message | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | "B2B payments company" may or may not read as software. Depends on whether your employer sells a software product | `[grounded]` your wording; `[generic]` that screeners read "software company" literally | G4 |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. A credential is checkable but I haven't checked it | `[grounded]` your message | Upgrade menu: the credential link |
| R4a | Strong SQL | must_have | direct | medium | none | "SQL weekly" shows regular use; how deep it goes isn't stated | `[grounded]` your message | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows use, not modelling (drivers, scenarios, a forecast build) | `[grounded]` your wording | G3 |
| R5 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, which is the input to a forecast. You state plainly that finance owned the company forecast | `[grounded]` your message | G2 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Never on billing data, by your own account. Still open: whether your renewal dashboards used revenue/ARR figures you checked against finance's numbers | `[grounded]` your message; `[inferred]` that renewal reporting usually touches revenue data | G1 |
| R7 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards, an almost word-for-word match. Dashboard screenshots would make it checkable | `[grounded]` your message | Upgrade menu: a cleaned-up screenshot |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Finance and revenue data (R6, must_have) | discovery | No billing work. Renewal dashboards exist, but their data source is unknown | One of two must-haves you flagged yourself, and the core of "own… billing data" | Matching renewal values or ARR to finance's figures; feeding bookings or churn numbers into a finance report; agreeing revenue definitions with finance | A dashboard screenshot showing revenue fields, a definitions doc | `[grounded]` your message; `[inferred]` that this answer moves R6 |
| G2 | Forecast ownership (R5, must_have) | transferability | You run the pipeline review; finance owned the forecast | What carries over: pipeline inspection, stage hygiene, deal-level judgement. The limit: you never built or signed off a company number with a CFO | Producing a UK commit/best-case call, tracking forecast accuracy, preparing the pipeline inputs finance used | The pipeline review deck, a commit-tracking sheet | `[grounded]` your message; `[generic]` that interviewers probe this distinction |
| G3 | Spreadsheet modelling (R4b, must_have) | discovery | Daily Excel, no modelling described | A "strong" requirement, and the forecast role leans on it | Capacity or quota models, renewal-rate scenarios, territory planning | A cleaned-up model | `[grounded]` your wording |
| G4 | B2B software employer (R2b, must_have) | discovery | "B2B payments company" | A literal keyword screen could catch it | Your employer sells a platform, API or SaaS product | Company description | `[generic]` screening pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast split between the role and the CFO is undefined | unknown | — | "run the quarterly revenue forecast with the CFO" | You might run the process while the CFO owns the number, or own both | `[inferred]` from "with the CFO" | Who owns the forecast number today, and what would this role sign off? | unresolved |
| RR2 | Broad mandate with no team mentioned | risk_signal | low | "own our CRM and billing data, build… reporting… run the quarterly revenue forecast" | It may be a one-person function | `[inferred]` from the mandate against the posting's silence on team | Is there anyone in RevOps besides you and Tamsin, and what systems support is there for billing data? | unresolved |
| RR3 | Salary published, mid-market | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is open and competitive for the title | `[grounded]` posting; `[generic]` Ledgerline band | What are the share option terms? | noted |
| RR4 | Posting not found on Quillfield's own site | unknown | — | Listed on Tallyboard; quillfield.co.uk/careers returned no page | A company this size may post only on job boards, or the listing may be stale | `[generic]` pattern, not a claim about Quillfield | Is this role still open, and is it listed anywhere on Quillfield's own site? | unresolved |
| RR5 | Hiring manager confirmed in post | positive_signal | — | "Tamsin Achebe, Head of Revenue Operations at Quillfield" | The recruiter's information checks out | `[grounded]` public profile | What does success look like in the first two quarters? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "rebuilt our pipeline and renewal dashboards", in your own words | see R7 | `[grounded]` your message | pending your approval |
| P2 | Describe the forecast honestly: "I run the monthly pipeline review with our sales director; finance owned the company forecast" | see R5; this costs you less than being caught overclaiming | `[grounded]` your message | pending your approval |
| P3 | Your payments-company background is familiar ground for this reader: Tamsin Achebe's public profile shows four years in sales ops at a payments company | see R2b, RR5 | `[grounded]` profile; `[inferred]` that it reads as familiar | pending your approval |
| P4 | Before interviews, learn how invoicing data becomes revenue (ask your finance team how billing is reconciled) so you can describe a concrete ramp-up plan | see R6 | `[generic]` closure path | pending your approval |
| P5 | Ask the RR1, RR2 and RR4 questions in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield "Revenue Operations Lead" job" (no results). Fetched quillfield.co.uk/careers (no page). Fed the Organization and Contradictions rows and RR4 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example). Fed market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Fed RR5 and P3 |

I can save all of this as a `tuesday-dossier.md` for later steps if that's useful.

**Upgrade menu**
- Your CV: claims can move from your own account to confirmed, and I can check R2b and R4b against your actual wording.
- Your Salesforce certification link: R3 goes to `high`.
- A cleaned-up screenshot of the pipeline or renewal dashboard: R7 goes to `high`, and it may answer G1.
- Your location and pay floor: R1 closes and the pay band gets checked against your floor.
- A deeper research pass on Quillfield covering leadership changes, hiring patterns, employee reviews and recent news. It costs up to 5 more searches and 2 more fetches; say the word and it runs.

**Questions**

R1 — Does two days a week in the Bristol office work for you?

G1 — Did your renewal dashboards use revenue or ARR figures that you had to match against finance's numbers? If so, what did you own in that?

G2 — In the monthly pipeline review, did you produce a UK team commit or best-case call, or track how accurate it turned out to be?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.