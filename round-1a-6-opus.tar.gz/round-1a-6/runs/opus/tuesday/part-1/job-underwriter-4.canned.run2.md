Now the worked report, interaction-grammar §4, and reframing audit.
Running L1 research now.
**Yes, it's worth applying — `conditional_go`. The catch is the working pattern, not your experience.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R10 (Fully remote (UK))
- `must_have`: direct: R1, R2, R3, R4, R5, R6a, R7 · unclear: R6b (recommendations for … product)
- `important`: adjacent: R9 (Pet-insurance domain)
- `preferred`: direct: R8

R6b: no product-side work stated yet; R9: a real bridge from motor, with its limit named.

**Opportunity ledger.** The employer's own careers page contradicts the JD on where you'd work (RR1), and the salary isn't stated (RR2). Two things point the other way: the posting is live on Brindlemoor's own site with the same reporting line (RR3), and the hiring manager's public work matches this mandate (RR5). The company's stage and size aren't established yet (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 is settled: the actual working pattern is confirmed, and it's one you'll accept (R10); (2) R6b is either evidenced or framed honestly as underwriting-facing work; (3) R9 is presented as a motor-to-pet bridge, never as pet-insurance experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD; `[grounded]` careers page confirms the product |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page; name from your message |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` JD and fetched careers page; see RR1 |
| Scope read | A hands-on senior individual-contributor role. The JD lists no line-management duties or requirement, so not having managed anyone isn't a gap against this posting | `[grounded]` JD's silence on management; `[inferred]` IC reading from the responsibilities listed |
| Hiring manager | Director of Pricing; previously head of pricing analytics at Calloway Re for six years; spoke in 2025 on "Small Books, Loud Errors", about monitoring rating models in small books | `[grounded]` public profile snippet |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base about £58.4k, middle half £52.1k–£64.9k. This is a market band, not Brindlemoor's offer | `[generic]` Pricewell 2026 survey, n=612 |
| Unknowns | Salary; company stage and size; whether "monitor" means owning monitoring end to end; how much the product team uses pricing work | — |
| Contradictions | Working pattern differs between the JD and the careers page (RR1) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific, but stated rather than inspected | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Used daily, as you stated. Nothing to inspect yet, so expect a technical probe | `[grounded]` your background | none |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R4 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers build directly. Monitoring is the likely reading of "maintained", but you haven't stated what it involved, so expect a probe on drift and performance tracking | `[grounded]` your background; `[inferred]` monitoring read from "maintained" | none, prep only |
| R5 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team. You said "ran"; whether you also designed them isn't stated, so describe them as tests you ran | `[grounded]` your background | none |
| R6a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, and the tests ran with underwriting | `[grounded]` your background | none |
| R6b | Turn results into recommendations for product | must_have | unclear | low | discovery | Your background doesn't mention product, proposition or digital teams | `[grounded]` silence in your background | G1 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting. That is the JD's own example almost word for word | `[grounded]` your background | none |
| R8 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R9 | Pet-insurance domain: rating factors, claims patterns | important | adjacent | medium | transferability | What carries over: GLM rating, price testing and underwriting partnership. The limit: pet rating factors (breed, age, pre-existing conditions, vet-fee inflation) and lifetime-cover structures aren't motor's. Brindlemoor's book is likely smaller than a motor book | `[inferred]` requirement from the product named in the JD; `[generic]` what pet rating usually involves; `[grounded]` you've never worked on pet | G2 |
| R10 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. You haven't said whether either works for you, so neither side of the gate is settled | `[grounded]` JD and careers page; constraint not given | Q on R10; RR1's question to the employer |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R6b, must_have) | discovery | Underwriting-facing work is clear, but nothing on product | It is the one must-have not yet at `direct` | Pricing input to a new product, tier or excess structure; test results that changed a quote journey or proposition; working with a product owner on discounts or add-ons | A sanitized test-readout deck, or a paper where a product decision cites your analysis | `[grounded]` silence in your background |
| G2 | Pet-insurance domain (R9, important) | transferability | Motor only | `[generic]` "never worked in pet" is the likeliest objection from a pricing panel | Low-data or small-segment modelling (the young-driver book may count); claims-frequency or severity work; any non-motor line; work on inflation trends in claims | A short note on how you'd adapt your GLM approach to pet rating factors | `[inferred]` bridge from your young-driver work; `[generic]` objection pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R10) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One version may be outdated, or the pattern may have changed after the posting was written | `[inferred]` from the two sources disagreeing | Is this role fully remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in the JD or on the careers page) | The figure may sit anywhere relative to the £52.1k–£64.9k band | `[inferred]` from the withheld figure; `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Posting is live on the employer's own site, with a consistent reporting line | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The role exists as described, apart from the working pattern | `[grounded]` fetched careers page | — | noted |
| RR4 | Company stage and size not established | unknown | — | "insurtech" | A search for the company and product returned nothing beyond the careers page, which may simply mean a small or young firm | `[generic]` pattern for young firms, not a claim about this one | How big is the pet book today, and how is the company funded? | unresolved |
| RR5 | Hiring manager's public work matches the mandate | positive_signal | — | "Small Books, Loud Errors", on monitoring rating models in small books | The monitoring part of the role is likely a real priority for this manager | `[grounded]` public profile snippet; `[inferred]` the priority | What does model monitoring look like on the pet book today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Odile Varga before you put real effort into the application | RR1, R10 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the young-driver GLM and the 14 price tests run with the underwriting team, using "built and maintained" and "ran", not "designed" or "owned" | R3, R5; matches the mandate and the hiring manager's monitoring theme | `[grounded]` your background; `[grounded]` RR5 | pending your approval |
| P2 | Present motor-to-pet as transferable method, and name the limit yourself | R9 | `[inferred]` G2 bridge | pending your approval |
| Q1 | Ask the RR1, RR2, RR4 and RR5 questions in the process, word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

P1 and P2 are proposed positioning only. Nothing goes into a CV or message until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). This moved the working-pattern contradiction (RR1), RR3 and RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary 2026", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). This moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). This moved the hiring-manager row, RR5 and P1 |

If you'd like, I can save all of this as a `tuesday-dossier.md` you can carry into later steps.

**Upgrade menu**
- Your working-pattern constraint (remote only, or is Leeds possible?) settles R10 one way or the other, and with it the decision.
- An answer to G1 moves R6b to `direct`, or confirms it should be framed as underwriting-facing.
- A sanitized price-test readout or model-monitoring pack would raise R4 and R5 toward `high`. These are the documents pricing teams actually keep.
- The salary range closes RR2 and lets you compare it with the £52.1k–£64.9k band.
- A deeper research pass on Brindlemoor (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) would address RR4. Say the word and I'll run it.
- Once you decide to apply, mock-interview can prep you for Odile Varga's round.

**Questions**

R10: Could you work from Leeds four days a week, or is fully remote a must for you?

G1: Has any of your pricing or test work fed a product decision, such as a new tier, an excess option or a change to the quote journey? What was your part?

G2: Beyond the young-driver book, have you modelled small or low-data segments, or any non-motor line?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.