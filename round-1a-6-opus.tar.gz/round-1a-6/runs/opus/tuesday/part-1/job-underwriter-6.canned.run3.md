Let me read the required references.
I've read the posting and done the background checks. Here's my assessment.

## Decision snapshot

**Yes, it's worth applying, as long as the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid, two office days a week), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R5, R6 · adjacent: R8 (Experience owning a forecast) · unclear: R4 (At a B2B software company), R7 (Spreadsheet modelling), R9 (Working with finance on billing or revenue data)
- `important`: direct: R10

R8: a real bridge from your pipeline review, with its limit stated; R9: the row most likely to decide the interview loop; R4, R7: each waiting on one answer.

**Opportunity ledger.** The pay is stated and sits inside the market band (RR1). The posting doesn't appear on Quillfield's own careers page (RR3). The team, the billing system and how forecast success is measured are all unstated (RR2, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two office days a week), R2 (Salary £61,500–£67,000); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 work for you; (2) R8 is framed as adjacent, never as having owned the company forecast; (3) R9: your answer to G2, or the interviews, shows a credible route into billing data; (4) RR3: the recruiter confirms the posting is live.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Bristol, founded 2018, 96 employees, Series A (£11M) in April 2025 | `[grounded]` quillfield.co.uk/about (search result) |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield. Previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter's name; public profile (search result) |
| Scope read | One role covering CRM admin, billing data ownership and the forecast with the CFO. At about 100 people that is a full-stack RevOps role with no team mentioned | `[inferred]` from the mandate against the stated headcount and the JD's silence on team |
| Market calibration | RevOps lead, UK B2B software: median base £64,200, interquartile range £57,800–£70,400. The posting's £61.5–67k range brackets the median | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide (n=438); `[grounded]` posting's figure |
| Unknowns | Team and reporting line; which billing system; how forecast accuracy is judged; terms of the share options | — |
| Contradictions | None between the posting and the About page. Quillfield's own /careers page returned no page | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't told me where you're based or whether two office days work for you | `[grounded]` posting; no stated constraint | Closing question on R1/R2 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated, so I can't check it. The band itself is at market (RR1) | `[grounded]` posting; no stated constraint | Closing question on R1/R2 |
| R3 | 4+ years in revenue operations or sales operations | must_have | direct | medium | none | Five years in sales ops, the last two running RevOps for the UK team. Self-reported and specific, with no artifact | `[grounded]` your background | none |
| R4 | At a B2B software company | must_have | unclear | low | discovery | "B2B payments company" may or may not sell software. That depends on what the product is | `[grounded]` your wording | see G3 |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certification record would make this inspectable | `[grounded]` your background | Upgrade menu: the cert verification link raises this to high |
| R6 | Strong SQL | must_have | direct | medium | none | "SQL weekly", backed by dashboards you rebuilt. Expect a technical probe | `[grounded]` your background; `[generic]` that this role family tests SQL live | none |
| R7 | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows you use Excel. Modelling (driver-based, scenario or capacity models) is different work, and you haven't said you've built one | `[grounded]` your wording | see G4 |
| R8 | Owning a forecast; "run the quarterly revenue forecast with the CFO" | must_have | adjacent | medium | transferability | Adjacent: you run the monthly pipeline review with the sales director, which works from the same pipeline inputs. Limit: you have "never owned the company forecast — finance did", so you haven't set or answered for the number | `[grounded]` your background; `[inferred]` the adjacency from pipeline review to forecast inputs | see G1 |
| R9 | Working with finance on billing or revenue data; "own our CRM and billing data" | must_have | unclear | low | discovery | You said you've never worked on billing data. The JD also accepts "revenue data", and renewal dashboards may have touched ARR or contract values that finance used. Unconfirmed | `[grounded]` your statement; `[inferred]` that renewal work may involve revenue data | see G2 |
| R10 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | "Rebuilt our pipeline and renewal dashboards", almost word for word the mandate | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R8, must_have) | transferability | You run the monthly pipeline review; finance owned the company forecast | The JD gives this role the quarterly forecast with the CFO, so it is the clearest stretch | Building the commit/best-case roll-up finance used; tracking forecast accuracy or slippage; supplying the pipeline-coverage inputs to finance's model | A sanitized pipeline-review deck or a forecast-accuracy tracker | `[grounded]` your background; `[generic]` that hiring managers probe forecast ownership for this title |
| G2 | Billing or revenue data with finance (R9, must_have) | discovery | No billing data; possible revenue-data work through renewals | Combined with R8, this decides whether the finance half of the role reads as reachable | Reconciling CRM contract values to finance's ARR or revenue numbers; renewal pricing or uplift reporting finance relied on; churn or NRR figures for board packs | A dashboard screenshot, a reconciliation sheet | `[grounded]` your statement; `[inferred]` that renewal work can involve revenue data |
| G3 | B2B software employer (R4, must_have) | discovery | "B2B payments company" | A screener may read the requirement literally | A payments platform or API sold to businesses on subscription counts | Your company's product page | `[generic]` that screeners read sector literally |
| G4 | Spreadsheet modelling (R7, must_have) | discovery | "Excel daily" | Modelling may come up in a case exercise | A capacity or quota model, a territory plan, a renewal-forecast workbook | A sanitized model | `[generic]` that RevOps loops often include a modelling task |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and at market | positive_signal | — | "£61,500–£67,000 plus share options" | The range brackets the role-family median | `[grounded]` posting; `[generic]` Ledgerline band | What are the share option terms: amount, strike, vesting? | noted |
| RR2 | Wide mandate, no team named | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | You may be a one-person function covering admin, data and forecasting | `[inferred]` from the mandate against the JD's silence on team | Who would I work with day to day, and does anyone report to this role? | unresolved |
| RR3 | Posting not found on Quillfield's own careers page | unknown | — | Tallyboard listing "Revenue Operations Lead — Quillfield" | Quillfield may just not host a careers page, or the listing may only be on job boards | `[grounded]` quillfield.co.uk/careers returned no page; `[generic]` that smaller firms often post only on boards | Is this role open now, and where does Quillfield list its vacancies? | unresolved |
| RR4 | No success measure for the forecast | unknown | — | "run the quarterly revenue forecast with the CFO" | You'd be accountable for the forecast with no stated accuracy target or shared ownership | `[inferred]` from the JD's silence on measures | How is forecast accuracy judged today, and who signs off the number, you or the CFO? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dashboard rebuild and the monthly pipeline review: "I rebuilt our pipeline and renewal dashboards and run the monthly pipeline review with our sales director." | see R10, R8 | `[grounded]` your own sentences | pending your approval |
| P2 | Say the forecast limit plainly: "Finance owned the company forecast; I ran the pipeline review that fed it." Only use the second half if G1 confirms you fed finance's number | see R8, G1 | `[grounded]` your statement | pending your approval |
| P3 | With this hiring manager, the sales-ops-at-a-payments-company story is a familiar path, so lead with the RevOps work, not the sector | see R3, R4 | `[grounded]` Tamsin Achebe's public role history; `[inferred]` that a shared background makes your story easy to place | pending your approval |
| P4 | Before interviewing, learn how subscription billing data maps to CRM and revenue reporting (invoices, credit notes, ARR), so you can show a route into R9 | see R9 | `[generic]` closure path for a billing-data gap | pending your approval |
| P5 | Ask the RR2, RR3 and RR4 questions word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Gave the organization row and RR3 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Gave the market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Gave the hiring manager row and P3 |

If you want, I can write all this up as a `tuesday-dossier.md` file to carry into later steps.

## Upgrade menu

- Your Salesforce certification verification link would raise R5 to `high`.
- A sanitized pipeline-review deck or forecast-accuracy tracker would strengthen the R8 bridge.
- A dashboard screenshot showing revenue or ARR figures finance used could move R9 to `adjacent`.
- Your company's product page, or one line describing it, would settle R4.
- A sanitized model you built would settle R7.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

R1/R2: Do two office days a week in Bristol work for you, and is £61,500–£67,000 at or above your pay floor?

G1: In the monthly pipeline review, did you produce a number finance used, such as a commit or best-case call or coverage figures, and did you ever track how accurate it turned out?

G2: Have you reconciled CRM data against finance's revenue or ARR figures, or built renewal reporting finance relied on?

For any of these, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.