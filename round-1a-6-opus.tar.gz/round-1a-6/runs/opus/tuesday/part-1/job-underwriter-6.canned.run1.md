Let me read the required references.
Fetching the posting and running the research checks. One more search to find the role on Quillfield's own site, then I'll write the assessment.
**Yes, it's worth applying, as long as the Bristol office days and the pay band work for you (R1, R2). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid: two days a week in the office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3a, R4, R5a · adjacent: R6 (Experience owning a forecast) · unclear: R3b (…at a B2B software company), R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data)
- `important`: direct: R9 · absent: R8 (Own billing data)

R6: a real bridge from your pipeline review, with its limit stated; R7 and R8: the billing side, where R7 can still close through revenue data; R3b and R5b: not settled by what you've told me yet.

**Opportunity ledger.** The role looks sound. Pay is published and sits in the market's middle range (RR2). The company exists as the posting describes it (RR1), though I couldn't find the posting on Quillfield's own site. The open questions are about scope: one person may be expected to own the CRM, billing data and the forecast with no team mentioned (RR3), and it isn't clear who owns the forecast number (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid: two days a week in the office), R2 (Salary £61,500–£67,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 both meet your own terms; (2) R6 is presented as adjacent, never as forecast ownership; (3) R7 gets answered: did your renewal work put you next to finance on revenue figures?; (4) RR3 and RR4 come back reasonable in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance use; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid with two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | The hiring manager is Head of Revenue Operations, so this Lead role reports into an existing RevOps head rather than starting the function from scratch | `[grounded]` public profile listing for Tamsin Achebe; `[inferred]` the reporting line, from her title against this role's |
| Market calibration | UK B2B software RevOps leads: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posted band sits inside that range | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting, for its own figure |
| Unknowns | Team size; who runs the billing system today; who signs off the forecast number; right-to-work terms (not stated) | — |
| Contradictions | None between the posting and the company's About page (both say Bristol and invoicing software). The posting wasn't found on Quillfield's own site (RR1) | `[grounded]` About page; careers page fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what commute works. The term is clear; whether you meet it isn't | `[grounded]` posting; your message is silent | Question on R1/R2 |
| R2 | Salary £61,500–£67,000 against your floor | hard_gate | unclear | none | hard_gate | No pay floor given, so the band can't be checked against your terms | `[grounded]` posting; your message is silent | Question on R1/R2 |
| R3a | 4+ years in revenue ops, sales ops or a similar analytics role | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. Specific, but stated in prose with nothing to inspect | `[grounded]` your message | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You describe your employer as "a B2B payments company". Whether what it sells is software isn't stated. A titled-years line like this one is often screened literally, so the wording matters | `[grounded]` your message; `[generic]` that such lines are screened literally | G3 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certification can be checked but hasn't been yet | `[grounded]` your message | Upgrade: certification verification link |
| R5a | Strong SQL | must_have | direct | medium | none | You use SQL weekly, so it's regular use. How "strong" it is gets tested in interview, not on paper | `[grounded]` your message; `[generic]` that SQL depth is usually tested live | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows use. Modelling (driver-based, scenario or forecast models) is a different kind of work and isn't established | `[grounded]` your message | G4 |
| R6 | Experience owning a forecast; run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, which feeds a forecast. Limit: "I've never owned the company forecast — finance did that." That limit is named wherever this bridge is used | `[grounded]` your message, both clauses | G2 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | The requirement is "billing *or* revenue". You've ruled out billing. Revenue data is open: renewal dashboards may carry contract values, but that isn't stated | `[grounded]` your message; `[inferred]` that renewal reporting may touch revenue values | G1 |
| R8 | Own billing data | important | absent | none | capability | You said "never worked on billing data." No adjacent claim is on the table. It's the core data of an invoicing product, so it will be asked about | `[grounded]` your message; `[inferred]` its salience, from Quillfield's product | G5: closure path |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is open and sits under R7 | `[grounded]` your message | Upgrade: sanitized dashboard screenshot |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Finance on revenue data (R7, must_have) | discovery | Renewal dashboards rebuilt; no mention of revenue values or of finance | One "yes" here moves a must-have from unclear to direct | Renewal dashboards showing contract value or ARR; reconciling CRM bookings against finance's numbers; agreeing revenue definitions with finance | A sanitized dashboard screenshot; a reconciliation sheet | `[grounded]` your message; `[inferred]` that it moves the row |
| G2 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review with the sales director; finance owned the company forecast | The posting makes the forecast a named duty with the CFO, so this is the row most likely to be probed | Producing the UK team's commit or call; a renewal forecast; calling deals in or out of the number you handed finance | A review pack template; a commit sheet | `[grounded]` your message; `[generic]` that a named duty gets probed |
| G3 | B2B software employer (R3b, must_have) | discovery | "B2B payments company" | Decides whether R3 reads direct on a literal screen | Selling a payments platform, API or merchant software on subscription | Company description from its own site | `[grounded]` your message |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | "Excel daily" | Modelling is a different kind of work from daily use | A capacity or quota model; a scenario model for the pipeline review; renewal-rate projections | A sanitized model | `[grounded]` your message |
| G5 | Billing data (R8, important) | capability | Stated absent | Core data at an invoicing company | Closure path: learn how invoices, credit notes and payment status are structured in Quillfield's product before interviews, and say plainly it's new to you | — | `[grounded]` your message; `[inferred]` product salience |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield … Tallyboard Jobs" | Quillfield may only advertise through job boards, or the site's listing may live at another address. The recruiter's contact suggests the role is live | `[grounded]` careers page returned no page and the site search returned nothing; `[generic]` that small firms often post only on job boards | Is this role listed on your own careers site, and is the Tallyboard posting current? | unresolved |
| RR2 | Pay published and in the market middle | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posted band sits inside the role-family interquartile range | `[grounded]` posting; `[generic]` Ledgerline band | What is the share option grant, and on what vesting? | noted |
| RR3 | Wide scope with no team stated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting … and run the quarterly revenue forecast" | Could be a one-person function covering three jobs. Low severity because a Head of RevOps sits above it | `[inferred]` from the scope list against the posting's silence on team | Who else is in RevOps, and who looks after the billing system day to day? | unresolved |
| RR4 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The number may be finance's with RevOps running the process, or the reverse | `[inferred]` from "with the CFO" | Who signs off the forecast number, this role or the CFO? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the renewal and pipeline dashboard rebuild and your Salesforce admin certification | See R9, R4 | `[grounded]` your message | pending your approval |
| A2 | Describe the forecast in these words: "I run the monthly pipeline review with our sales director; the company forecast sat with finance." Don't claim forecast ownership | See R6 | `[grounded]` your two sentences, unchanged in substance | pending your approval |
| A3 | Name the billing gap plainly and show you've studied Quillfield's invoicing model | See R8, G5 | `[grounded]` your message | pending your approval |
| A4 | Describe your payments sales-ops work in its own terms rather than translating it into software language. The hiring manager also came from payments sales ops | See R3b | `[grounded]` profile listing: previously sales operations manager at Corvane Payments; `[inferred]` that she'll recognise that background | pending your approval |
| Q1 | Ask the verification questions for RR1, RR3 and RR4 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers: no page. Searched "quillfield.co.uk jobs Revenue Operations Lead": no results. Moved the Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the Market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the Scope read row and A4 |

I can save all of this as a `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Where you're based and your pay floor: R1 and R2 settle, and the decision firms up.
- Your Salesforce certification verification link: R4 moves to `high`.
- A sanitized screenshot of a renewal dashboard or pipeline review pack: R9 moves to `high`, and it may settle R7.
- Your CV: a full evidence inventory, and R3b may settle.
- Quillfield's own listing for this role, if the recruiter has one: RR1 closes.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**R1/R2:** Do the Bristol pattern of two office days a week and the £61,500–£67,000 band both work for you?

**G1:** Did your renewal dashboards show contract or revenue values, and did you ever reconcile or agree those figures with finance?

**G2:** Did any number you produced, such as a UK commit or a renewal forecast, go into finance's company forecast? If so, what part was yours?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.