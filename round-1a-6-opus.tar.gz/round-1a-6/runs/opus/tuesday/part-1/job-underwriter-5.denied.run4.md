Checking whether Pellucid Learning's posting is still live before I write the assessment.
Yes, it looks worth applying to, on three conditions. My web search was blocked, so everything below rests only on what you pasted. I couldn't confirm that the posting is still live.

## Decision snapshot

**Yes, worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7
- `important`: adjacent: R5b (dbt-modelled warehouse in BigQuery) · unclear: R8 (ingestion from our app and CRM), R9 (data contracts our analysts depend on)

R5b: a credible bridge from Snowflake, with its limit stated; R8, R9: nothing in your background covers them yet, and one answer each could settle them.

**Opportunity ledger.** The terms are open and fair: the posted pay sits at or above the market band (RR2) and the company states recent funding (RR6). The open items are the equity terms (RR3), who you'd report to (RR4) and whether there's on-call (RR5). I couldn't confirm the employer and posting are live because the search was refused (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you're US-based or can work from Denver; (2) RR1: the posting checks out on Pellucid's own careers page; (3) R5b: you describe BigQuery as adjacent to your Snowflake work and never claim it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page as you pasted it; not checked live |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Location and pay | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | One platform's reporting pipelines, with no direct reports mentioned: an individual-contributor role that owns one domain | `[inferred]` from the JD's mandate, and from its silence on managing anyone |
| Market calibration | Senior DE at Series B–D: median base $151,000, middle half of salaries $139,000–$163,500, "Senior" typically 5–8 years, scope typically one domain's pipelines with no reports. This role's title, years and scope sit at that norm. The posted range starts just below the median and its top runs above the upper quartile (RR2) | `[generic]` Datawright 2026 report (US, n=2,310), as your recruiter sent it; `[grounded]` JD for the posted figures |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Reporting line and team size; equity form and size; on-call; which CRM; what "data contracts" means in tooling and ownership | — |
| Contradictions | None between the JD and the about page as pasted; neither was checked against the live site | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based, so the gate isn't settled either way | `[grounded]` JD term; your background is silent | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated; specific but self-reported, nothing to inspect yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily": stated, not yet inspectable; expect a technical probe | `[grounded]` your background | none |
| R4 | dbt | must_have | direct | medium | none | Built the dbt project, about 180 models: specific, not yet inspectable | `[grounded]` your background | A public repo or a dbt docs export would raise it to high |
| R5a | A cloud warehouse | must_have | direct | medium | none | Snowflake meets the requirement as the requirements list words it ("a cloud warehouse") | `[grounded]` JD and your background | none |
| R5b | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: dbt modelling, warehouse SQL, orchestration. Limit: you've never used BigQuery `[grounded]`. BigQuery-specific cost, partitioning and clustering practice differs from Snowflake's `[generic]` | `[grounded]` your statement; `[generic]` how the warehouses differ | See G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated as your orchestrator | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite: specific ownership, not yet inspectable | `[grounded]` your background | Suite config or a sanitized sample would raise it to high |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't mention source ingestion; six years of DE is indirect context only | `[grounded]` your background is silent | See G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | A GE suite is quality testing. Contracts mean agreed schemas and guarantees with the people who use the data, and your background doesn't say whether you've done that | `[grounded]` your background is silent; `[generic]` what contracts usually cover | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5b, important) | transferability | Deep dbt on Snowflake, no BigQuery | It's the warehouse you'd run from day one | A small dbt-bigquery project on public data; any GCP work at all | A public repo with a dbt-bigquery profile | `[grounded]` your statement; `[generic]` that a hands-on sample narrows a warehouse switch |
| G2 | App and CRM ingestion (R8, important) | discovery | Not mentioned | Half the mandate is ingestion | Pulling payroll-app databases or event streams into Snowflake; syncing a CRM (Salesforce, HubSpot) through Fivetran, Airbyte or custom Python; handling schema drift from a source system | A DAG diagram, a sanitized connector config | `[grounded]` JD and your silence on it |
| G3 | Data contracts (R9, important) | discovery | GE suite, but no contracts work described | It's a named deliverable that analysts rely on | Agreeing schemas or freshness guarantees with analysts or finance; dbt model contracts or versioned models; GE checkpoints that block bad loads before analysts see them | A contract YAML, an agreed-schema doc, a dbt `contract: enforced` config | `[grounded]` JD; `[generic]` what typically counts as contract work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver." | The search was refused, so nothing is checked. The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` standing pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Posted pay at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is published, its midpoint ($157k) sits above the report's $151k median, and its top passes the upper quartile | `[grounded]` JD figure; `[generic]` report band | Where in the range does this level land for someone with 6 years, and what drives where an offer lands? | noted |
| RR3 | Equity unspecified | unknown | — | "plus equity" | The form, size and vesting aren't stated; at Series C its value depends on terms not shown | `[inferred]` from the posting's silence | What form does the equity take, how much, and on what vesting schedule? | unresolved |
| RR4 | No hiring manager or team named | unknown | — | The posting names no hiring manager | The reporting line, team size and analyst ratio are unknown | `[grounded]` posting is silent | Who does this role report to, and how many data engineers and analysts are on the team? | unresolved |
| RR5 | "Build and run": operational load unstated | unknown | — | "Build and run the pipelines" | Running the pipelines may come with on-call duty; the posting doesn't say | `[inferred]` from "run" against silence on on-call | Is there an on-call rotation for the pipelines, and how often does it come round? | unresolved |
| RR6 | Recent Series C funding | positive_signal | — | "Series C ($52M, February 2026)" | Funded nine months ago; suggests budget for the data function | `[grounded]` about page as pasted; `[inferred]` that it supports the budget | How is the data team's headcount planned over the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "Built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite", in your own words | Covers R4, R5a, R7 | `[grounded]` your background | pending your approval |
| P2 | Say plainly: "I haven't used BigQuery; my warehouse work is on Snowflake." Never list BigQuery as a skill | R5b; no BigQuery claim survives a probe | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small public dbt-bigquery project on a public dataset, before or during the process | Narrows R5b, and gives an inspectable artifact for R4 | `[generic]` a work sample narrows a warehouse-switch objection | pending your approval |
| A1 | Confirm the posting on Pellucid's own careers page before writing the application | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR2–RR6 verification questions verbatim in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning senior data engineer careers"; the host refused it. It would have checked that the pasted posting and about page are live and current, which feeds role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | The Datawright 2026 report excerpt you pasted already sets the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can write this up as a `tuesday-dossier.md` to carry into your next steps, if you'd like.

## Upgrade menu

- Where you're based (or whether Denver works) → R1 closes, and the decision can move to `go` once RR1 clears.
- Your pay floor and any other non-negotiables → the hard-gate checks against your constraints actually run.
- A link to the live posting, or permission to search → RR1 resolves and the `conditional_go` cap lifts.
- Your CV → I can check whether it communicates each `direct` row in this role's terms.
- A public repo, a dbt docs site, or your sanitized GE suite config → R4 and R7 rise to `high`.
- The hiring manager's name → a scope read, and which story to lead with for that reader.
- A deeper research pass on Pellucid Learning (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**R1:** Are you based in the US, or would you work from the Denver office?

**G2:** Have you built ingestion from an application database or a CRM into Snowflake? Which sources, what tooling, and which parts were yours?

**G3:** Have you agreed schemas or freshness guarantees with the analysts who use your models, through dbt contracts, GE checkpoints or a written agreement? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.