Now the referenced files.
Both web searches were refused, so this assessment rests only on the posting and what you told me. Here it is:

## Decision snapshot

**No, it isn't worth pursuing. You aren't misreading it: R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay), R2 (On-site Austin, 5 days)
- `must_have`: direct: R3, R4, R5 · adjacent: R10 (Team of one to start) · unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)
- `important`: adjacent: R11 (E-commerce enablement context)

R3, R4, R5: your core growth experience lands directly; R6–R9: four owned functions your background doesn't yet speak to; R10: you've led teams, but this role has no team.

**Opportunity ledger.** Apart from your fit, the role itself looks thin. Seven functions sit in one seat with no team (RR3). The pay is low for the seniority it asks for (RR4). It expects always-on availability (RR5) and gives no success metrics (RR6). I couldn't verify the employer because research didn't run (RR7). Two entries run the other way: you'd report directly to the CEO with board visibility (RR8). The two gate conflicts are also severe red flags for you specifically (RR1, RR2).

- **Hard gates:** failed: R1 (Base pay), R2 (On-site Austin, 5 days).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would have to differ:** Novaline would need to raise base pay to $150k or more (R1) and drop "no exceptions" for a fully remote arrangement (R2). Both would have to change. Neither is likely from a posting that states its range and says "no exceptions", and no wording on your application can fix either one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup at Series A, "profitable since day one" | `[grounded]` JD header; not checked against any outside source |
| Mandate | Owns all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Resources | "Team of one to start." No budget or hiring plan stated | `[grounded]` JD |
| Reporting | To the CEO, with a dotted line to the board | `[grounded]` JD |
| Terms | $70–85k base plus equity; on-site in Austin 5 days, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| First-year outcomes | None stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | This is a head-level title and board-facing mandate, but the work is a hands-on generalist doing seven functions alone | `[inferred]` from the function list against "team of one" |
| Unknowns | Growth budget; equity size and terms; whether and when the team grows; what "profitable" means at this stage | — |
| Contradictions | "Head of Growth" and "8+ years leadership" against "team of one" and $70–85k | `[inferred]` from the JD's own terms set side by side |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of $70–85k (your floor is $150k) | hard_gate | hard_gate_fail | high | hard_gate | You stated your floor yourself, so confidence is high. The posting's top figure is $65k below it, and equity doesn't count toward a base-pay floor | `[grounded]` JD range and your stated floor | Only the employer changing its terms resolves this |
| R2 | On-site in Austin 5 days, "no exceptions" (you are remote-only in Portland and won't relocate) | hard_gate | hard_gate_fail | high | hard_gate | Your own confirmed constraint. The JD explicitly rules out exceptions | `[grounded]` JD and your stated constraint | Only the employer changing its terms resolves this |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | 9 years, with Growth Lead then Head of Growth titles. Self-reported and not yet probed, which caps confidence at medium on a first pass | `[grounded]` your background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid, and scaled one company from $8M to $40M ARR on a budget you controlled | `[grounded]` your background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and work deeply in Braze | `[grounded]` your background | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` your background is silent | Moot under `no_go` |
| R7 | Brand and PR | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` your background is silent | Moot under `no_go` |
| R8 | Partnerships | must_have | unclear | low | discovery | Your background doesn't mention it | `[grounded]` your background is silent | Moot under `no_go` |
| R9 | Sales ops | must_have | unclear | low | discovery | Your background doesn't mention it. B2C subscription companies often have no sales motion to run | `[grounded]` your background is silent; `[generic]` the point about B2C sales motions | Moot under `no_go` |
| R10 | Executing alone as a team of one | must_have | adjacent | medium | transferability | Leading teams of 3–7 plus hands-on SQL and GA4 work suggests you can execute yourself. What it doesn't show is running seven functions alone with no team | `[grounded]` your background; `[inferred]` the solo-execution bridge | Moot under `no_go` |
| R11 | E-commerce enablement context | important | adjacent | medium | transferability | Your growth work was B2C subscription. The posting's "enablement" wording suggests Novaline sells to merchants | `[inferred]` B2B from "e-commerce enablement" | Moot under `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand/PR, partnerships, sales ops (R6, R7, R8, R9, must_have) | discovery | Nothing in your background on these four | They would matter only if both gates changed. As things stand, they can't change the decision | Content programs you ran; agency or PR relationships you managed; affiliate or co-marketing deals; CRM or pipeline work alongside a sales team | A content performance dashboard, a partnership deck, a launch plan | `[grounded]` your background is silent; `[inferred]` that they can't move the status |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay conflicts with your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base is about half your floor, and equity is being offered to make up the difference | `[grounded]` JD range against your stated floor | Is the base range flexible to $150k for the right candidate? | confirmed |
| RR2 | Location conflicts with your constraint (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Remote work is ruled out in so many words | `[grounded]` JD | Is fully remote possible for this role? | confirmed |
| RR3 | Several specializations bundled into one role, with no resources | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one to start" | Seven functions with no team or stated budget. You would be accountable without the means to deliver | `[inferred]` from the function list against "team of one"; `[generic]` that bundled roles like this are often priced as junior roles | What budget and headcount come with this role in year one? | unresolved |
| RR4 | Seniority and pay don't match | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | A head-level, board-facing mandate priced below what that seniority usually earns. I couldn't confirm a market band because the role-family search was refused | `[inferred]` from the JD's own ask against its own range | How did you set the range for this role? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work is framed as identity, not as an exception | `[inferred]` from the JD's wording | How often in the last quarter did "when it matters" happen? | unresolved |
| RR6 | No success metrics for a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd carry accountability for growth with no agreed definition of success | `[inferred]` from the JD | What would make this hire a success at 6 and 12 months? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a public footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The search to check was refused | `[generic]` a pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Direct CEO reporting with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Real seniority of access and influence | `[grounded]` JD | What does the board expect to see from growth each quarter? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply. Put the time into roles that meet your floor and are remote | see R1, R2 | `[grounded]` R1, R2 | pending your approval |
| A2 | Only if you're curious: send one short note asking whether base pay and remote work are negotiable, before investing any effort | Only the employer changing terms can reopen this | `[grounded]` R1, R2, RR1, RR2 | pending your approval |
| Q1 | If A2 gets a yes, ask the RR3–RR7 questions verbatim on a first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin" (refused). Would have checked the organization row and RR7 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026" (refused). Would have added a market calibration line and confirmed or cleared RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

If you'd like a reusable `tuesday-dossier.md` of this assessment, just say so.

**Upgrade menu**
- Allow web search, and target 1 checks that Novaline and this posting are real (clears or confirms RR7). Target 2 sets the $70–85k against a market band (RR4).
- A deeper research pass on Novaline (funding, leadership churn, employee reports; up to 5 more searches and 2 more fetches) would sharpen RR3–RR6. Say the word and it runs, but it can't change R1 or R2.
- A written yes from Novaline on $150k+ and fully remote would be the only thing that reopens R1, R2, RR1 and RR2.

No questions from me: nothing you could tell me changes this.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.