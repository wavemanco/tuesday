Now the referenced files for Step 1.
Reading the job-underwriter playbook took a while. Now I'm checking the employer and market pay, and then I'll give you the assessment.
**Yes, you're a strong fit, and it's worth applying once two things check out: that Harborlight and this posting are real and live, and that the pay and location work for you. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important`: adjacent: R7b (Partner with clinicians) · unclear: R7a (Partner with PMs to turn analysis into roadmap decisions), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R6, R7a, R8: the experience probably exists but your background doesn't say it yet. R7b, R9: honest bridges from related work, with their limits named.

**Opportunity ledger.** I couldn't check anything about the employer (RR1). Pay and location are not stated (RR2, RR3), and I don't know how much traffic is available for testing (RR5). The mandate itself is clear and well scoped (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting check out (RR1); (2) the pay and location meet your floor (RR2, RR3); (3) you present R9 as consumer-privacy work next to HIPAA, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C | `[grounded]` JD header, not checked against outside sources (RR1) |
| Mandate | Own product analytics for a care-navigation app: the metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD is silent on them |
| Scope read | A full senior individual-contributor analytics role with light people leadership. Owning both the metrics layer and the test program puts this person at the center of the function | `[inferred]` from the responsibility list plus "mentor two junior analysts" |
| Market calibration | Not available on this pass, because the role-family sweep couldn't run (see Evidence status) | — |
| Unknowns | Pay; location and working pattern; app traffic for testing; what PHI access the role has; who the analysts report to | — |
| Contradictions | None in the pasted JD. I couldn't compare it with the careers page | `[grounded]` pasted JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years at a consumer-subscription company. Specific, but self-reported with nothing to inspect, so `medium` is the most a first pass allows | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse, and you built a consent-state model in that warehouse. Self-reported, so expect a live SQL exercise | `[grounded]` your background; `[generic]` that senior analyst loops often include a SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year with about 2M subscribers, including the pricing test behind an 11% retention lift. This is your strongest row | `[grounded]` your background | Optional: a sanitized test readout would raise this to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. It's the same tool the JD names | `[grounded]` your background | Optional: screenshots or a description of the instance's structure |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | The exec team reads your monthly metrics memo, and you present to the VP Product every month | `[grounded]` your background | Optional: a sanitized memo excerpt as a writing sample |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests you defined the metrics underneath them, but you haven't said that you owned those definitions | `[grounded]` background is silent on metric-definition ownership; `[generic]` that governed Looker dashboards usually sit on a modeled semantic layer | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | unclear | low | discovery | Presenting monthly to the VP Product shows you're in the room. Your background doesn't say whether a specific analysis changed a roadmap decision | `[grounded]` your background | See G3 |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | Writing for and presenting to execs shows you can serve non-technical audiences. Limit: you haven't worked with clinical stakeholders, whose priorities include patient safety and clinical evidence | `[grounded]` your background; `[generic]` that clinicians judge analysis by clinical relevance and safety | See G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or managing anyone | `[grounded]` background is silent on it | See G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. Limit: no work under HIPAA's PHI rules, such as de-identification, minimum-necessary access or BAAs | `[grounded]` your background; `[generic]` that HIPAA PHI handling differs from GDPR/CCPA in these ways | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed Looker dashboards, but no stated ownership of metric definitions | It's the only `must_have` row not at `direct`. If you confirm it, the fit side has no open must-haves | Writing the LookML model or explores; settling one definition of "active subscriber" or "retention"; a dbt metrics layer feeding Looker; retiring duplicate or conflicting metrics | A sanitized LookML or metric-definition doc, or a data dictionary | `[grounded]` background is silent on it; `[inferred]` that confirming it closes the must-have tier |
| G2 | Mentoring (R8, important) | discovery | Nothing stated | The JD names two direct mentees, so expect to be asked about it | Onboarding new analysts; reviewing others' SQL or test designs; coaching someone through their first experiment readout | A note from someone you mentored, or an onboarding doc you wrote | `[grounded]` background is silent on it |
| G3 | Analysis into roadmap decisions (R7a, important) | discovery | Monthly VP Product presentations; the pricing test result | A specific decision your work changed is likely the story this panel will want | The pricing test turning into a pricing change; a roadmap item killed or reprioritized because of your analysis | A decision memo or roadmap doc that cites your analysis | `[grounded]` your background; `[generic]` that product-analyst loops probe impact on decisions |
| G4 | Clinician partnership (R7b, important) | transferability | Experience with non-technical executives only | You'll be working with a new kind of stakeholder | Your exec memo, offered as proof you can write for non-analysts | The memo excerpt (see R5) | `[grounded]` your background |
| G5 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | It's a plus, not a requirement, so the bridge is worth stating but doesn't decide anything | The consent-state model as evidence of privacy-aware warehouse design | A sanitized schema or design note for the consent model | `[grounded]` your background; `[inferred]` low decision impact because it's a preferred tier |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a public footprint, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. None of these is more likely than the others; the check simply couldn't run | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | Nothing in the JD | The pay may or may not meet your floor. Leaving it out is common but worth asking about | `[inferred]` from the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | Nothing in the JD | The role could be remote, hybrid or onsite | `[inferred]` from the JD's silence | Is this role remote, hybrid or onsite, and where? | unresolved |
| RR4 | Clear, coherent mandate | positive_signal | — | "define and maintain the metrics layer… mentor two junior analysts" | The scope is concrete, the tools are named, and the team is stated | `[grounded]` JD | What would a great first year look like in this role? | noted |
| RR5 | Testing "at scale" with an unknown user base | unknown | — | "experiment design at scale" | A care-navigation app may have far less traffic than 2M subscribers, which would change how you run tests (longer tests, fewer at once, other methods) | `[inferred]` from the JD's phrase against its silence on volume; `[generic]` that healthcare experimentation can be limited by ethics and traffic | Roughly how many active users does the app have, and how many tests run each quarter? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program, in your own words: "Designed and ran the experimentation program — 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | See R3, your strongest must-have | `[grounded]` your background | pending your approval |
| P2 | Second, the Looker work: "Built the company's Looker instance from scratch — 40+ governed dashboards." Don't call them "self-serve" unless people outside analytics actually used them on their own | See R4. "Self-serve" is the JD's word, not yours | `[grounded]` your background | pending your approval |
| P3 | Present healthcare honestly: "Handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse; no HIPAA experience yet." | See R9. Saying it up front heads off the probe | `[grounded]` your background | pending your approval |
| P4 | Have a sanitized excerpt of your monthly metrics memo ready as a writing sample | See R5, R7b | `[grounded]` your background; `[generic]` that analyst loops sometimes ask for writing samples | pending your approval |
| P5 | Ask the verification questions for RR1, RR2, RR3 and RR5 word for word with the recruiter, starting with RR2 and RR3 | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers". The search was refused because web search permission hasn't been granted. It would have checked the employer and the live posting for RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range 2026". Also refused for lack of permission. It would have produced the market calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want, I can save all of this as a `tuesday-dossier.md` you can bring to later steps.

**Upgrade menu**
- Allow web search → I check the employer and posting (RR1) and fill in the market pay band (RR2).
- A link to the live posting → it may clear RR1 directly and fill in pay and location.
- The hiring manager's name → role reality's scope read, and which story P1 should lead with for that reader.
- A sanitized test readout, LookML or metric-definition doc, or memo excerpt → raises R3, R6 or R5 toward `high`.
- A deeper research pass on Harborlight (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). It also needs search permission. Say the word and it runs.

**G1:** Did you personally define and maintain the metric definitions under those 40+ dashboards (for example the LookML model, or the single definition of retention)? What did you own, and what did others own?

**G2:** Have you mentored, onboarded or reviewed the work of other analysts? Who, and what did that involve?

**Constraints:** What are your non-negotiables: your pay floor, location or remote needs, and whether you need visa sponsorship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.