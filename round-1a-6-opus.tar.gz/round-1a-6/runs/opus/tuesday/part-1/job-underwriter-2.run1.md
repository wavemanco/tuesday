Now the Step 1 references.
I've loaded the job-evaluation playbook and am now running a short check on the company and on what roles like this usually involve before I write up the assessment.
I couldn't check Quartzline itself: both web searches were refused for permission, so everything about the company below comes from the job description alone.

## Decision snapshot

**No, you're not wasting your time. But this is a stretch application because of R1b (3+ years with a PM title), and no rewording can close that gap. How you apply matters as much as whether you apply. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (PM-type work in place of the 3+ years), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1b (3+ years with a product management title)
- `important`: direct: R8 · adjacent: R6 (Own the roadmap), R7 (Discovery with integration partners), R10 (Coordinate launches with sales and support), R11 (Drive delivery with two engineering squads) · unclear: R9 (Define and track adoption metrics)

R1b: only the employer can close it, by deciding your years next to the PM job count; R2, R6, R7: real bridges, limited because you implemented the platform rather than decided what it should be; R5, R9: your resume is silent on both, and one answer each could move them.

**Opportunity ledger.** The employer couldn't be checked from here (RR1), which caps the decision at `conditional_go`. Pay and location aren't stated (RR2, RR5), and nobody knows yet how strictly the 3+ years is screened (RR3). One entry is good news: the scope, resources and success measure are concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline turns out to exist as described and the posting is live (RR1); (2) someone with a say in hiring will count adjacent years toward the 3+ years, best tested through a referral, not a cold application (R1b, RR3); (3) your answers on R5 and R9 bring them to at least `adjacent`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, about 150 people, Series B | `[grounded]` JD header; not checked externally (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Must-haves | 3+ years of PM experience; shipped API or platform products; strong technical fluency (API docs, schemas); stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD lists these as requirements, and the 3+ years is marked "must-have" in so many words |
| First-year outcomes | Not stated; most likely a roadmap the partners have validated, plus a working adoption measure | `[inferred]` from "own the roadmap" and "define and track adoption metrics" |
| Scope read | A normal scope for a single-platform PM: one product area and two named squads, with a success measure stated | `[inferred]` from the JD's squad count and metrics line |
| Market calibration | Not run: the role-family search was refused | — |
| Unknowns | Pay, location and remote policy, reporting line, how strictly the PM years are screened | `[grounded]` JD is silent on each |
| Contradictions | None inside the JD; nothing outside it to compare against | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | PM-type work counted toward "3+ years product management experience" | must_have | adjacent | medium | transferability | 7 years running requirements documents, scoping workshops and roadmap-input sessions is PM-type work done from the implementation side. Limit: you didn't own what got built or the priorities | `[grounded]` resume; `[generic]` some hiring teams count solutions-engineering years, many don't | see G4 |
| R1b | 3+ years with a product management title | must_have | absent | none | capability | You say you've never held a PM title. This is a stated fact, not missing evidence. It isn't a hard gate (length of experience is graded, not pass/fail), but it is a must-have | `[grounded]` your statement | closure path in G4; carried as the main risk |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ client integrations of your company's REST APIs, end to end. That's shipping integrations on someone else's product, not shipping the product. The triage-tool lead might change this (see R9) | `[grounded]` resume | see G4; G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, and designing integration architecture. Specific, but no inspectable proof yet, so expect a technical probe | `[grounded]` resume | optional: a sanitized integration architecture doc would raise this to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | Coordinated your engineers, the client's engineers and product managers on custom builds | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your resume doesn't mention sales. Solutions engineers usually work closely with sales, but you haven't said so | `[grounded]` resume silence; `[generic]` that solutions-engineering roles usually sit next to sales | ask later if R5 and R9 resolve |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | Your resume doesn't mention sprints, backlogs or how your custom builds were run | `[grounded]` resume silence | G2 |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions that fed product. That's gathering input, not deciding priorities. Whether any of it shipped is unknown | `[grounded]` resume | G3 |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | 30+ scoping workshops with integrating clients is close. The limit: those scoped one client's build, while platform discovery decides what to build for all partners | `[grounded]` resume | see G4 |
| R8 | Write specs | important | direct | medium | none | Requirements documents and integration architecture for 30+ integrations, plus the integration playbook your whole team uses | `[grounded]` resume | optional: a sanitized requirements doc or the playbook outline as an artifact |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your resume doesn't mention metrics. A memory note from a past conversation suggests you built an internal request-triage tool that support agents adopted. It's unconfirmed, so it's a question to ask, not evidence | `[grounded]` resume silence; memory lead unconfirmed | G1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You took 30+ integrations from UAT to go-live. Client go-lives aren't product launches, and sales and support aren't named | `[grounded]` resume | see G4 |
| R11 | Drive delivery with two engineering squads | important | adjacent | medium | transferability | You coordinated engineers on custom builds, but as a coordinator, not as the person who sets their backlog | `[grounded]` resume | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics (R9, important); also R2 | discovery | Resume is silent; the triage-tool memory lead is unconfirmed | If it's real, it's the one place you built something and people chose to use it, which is the main product signal your resume lacks | Building the triage tool and getting support agents to use it; tracking integration time-to-live or API call volume after go-live; reporting which playbook steps cut UAT defects | A screenshot of the tool, a usage chart, an internal announcement | `[grounded]` resume silence; `[generic]` that a built-and-adopted tool is read as product evidence |
| G2 | Agile delivery (R5, must_have) | discovery | No mention of how builds were run | A must-have at `unclear`; often checked literally in screens | Sprints or standups for custom builds; writing or grooming tickets in Jira; sprint reviews with the client | A sanitized ticket set or a delivery plan | `[grounded]` resume silence; `[generic]` that agile is screened literally |
| G3 | Roadmap ownership (R6, important) | transferability | You collected input; whether it turned into product decisions is unknown | Moves the bridge from "passed on feedback" to "shaped what shipped" | A client need you raised that became a feature; a prioritization case you made to product; an API change you specified | A feedback summary deck, a feature request that shipped | `[grounded]` resume |
| G4 | Titled PM years (R1b), with the bridges R1a, R2, R7, R10, R11 | capability | No PM title; strong adjacent work | The main risk to an application. Wording can't close it, only how the employer reads it | Closure paths: a referral into the hiring manager; an internal move to PM at your current employer first; a one-page work sample (see P3) | The integration playbook; the work sample | `[grounded]` your statement; `[generic]` that referrals get past literal title screens more often than cold applications |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the check simply couldn't run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | (no compensation stated) | The figure may sit below market for a PM, or the company may just not publish pay | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Titled years marked must-have | unknown | — | "3+ years product management experience (must-have)" | It may be screened literally, or it may flex for adjacent years | `[inferred]` from the posting's explicit "must-have" | Would you consider someone whose 3+ years are solutions engineering and implementation leadership on API products? | unresolved |
| RR4 | Concrete scope and resources | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | Named squads and a success measure point to a real mandate | `[grounded]` JD | Who owns adoption targets today, and what are they? | noted |
| RR5 | Location and work pattern unstated | unknown | — | (not stated) | Could conflict with constraints you haven't given yet | `[inferred]` from the posting's silence | Is this role remote, hybrid or on-site, and where? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Look for a referral or a direct note to the hiring manager before applying cold | see R1b, RR3 | `[generic]` title screens are often literal in automated stages | pending your approval |
| P2 | Lead with the 30+ REST API integrations and the playbook, in your resume's own words ("led", "wrote", "coordinated"); don't describe the integrations as products you shipped or owned | see R2, R3, R8 | `[grounded]` resume | pending your approval |
| P3 | A one-page work sample, such as a short spec for a partner-API improvement drawn from real feedback you collected | narrows the limits on R2, R6, R7 | `[inferred]` from R6's roadmap-input sessions | pending your approval |
| P4 | Ask the questions in RR1, RR2, RR3 and RR5 as written, starting with RR3 | the register doubles as screen prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the internal request-triage tool (from memory, unconfirmed), which prompts G1 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Query "Quartzline logistics API platform Series B" was refused for permission. It would have checked the company and whether the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Query "platform API product manager requirements solutions engineer transition" was refused for permission. It would have supplied the market calibration and a pay band (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as a `tuesday-dossier.md` so later steps can pick it up. Just say so.

**Upgrade menu**
- Allow web search and I'll check Quartzline's site and careers page, which would close RR1 and add a pay band (RR2).
- An answer to G1, plus a screenshot or usage data → R9, and possibly R2, move up.
- The hiring manager's name → a read on scope and which story to lead with.
- Your constraints (pay floor, location, remote) → real hard-gate checks against RR2 and RR5.
- A deeper research pass on Quartzline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1: Did you build an internal request-triage tool that support agents used? If so, what was yours, how many people used it, and how did you know it was working?

G2: How were your custom builds run day to day: sprints, a ticket backlog, standups? What part of that was yours?

G3: Can you name one piece of client feedback from your roadmap sessions that turned into something product shipped, and what you did to make it happen?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you decide to apply, mock-interview can prep you for the screen.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.