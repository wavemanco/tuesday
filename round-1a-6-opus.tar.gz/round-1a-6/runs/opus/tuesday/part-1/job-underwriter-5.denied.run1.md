Now the referenced files for Step 1.
Still working through the assessment rules; next I'll run a quick check that the posting is live, then write up the verdict.
**Yes, it's worth applying, with a few conditions. Status: `conditional_go`.** Your experience covers most of what they ask for. BigQuery (R5b) is the one known gap, and it's an adjacent one: you've done the same work in Snowflake. The pay looks good. What holds this back from a full `go` is that I couldn't confirm the posting is still open.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7
- `important`: adjacent: R5b (BigQuery as the warehouse) · unclear: R8 (Ingestion from our app and CRM), R9 (Data contracts our analysts depend on)

R5b: a credible bridge from Snowflake, with its limit stated; R8, R9: your background doesn't show these either way yet; one question each below.

**Opportunity ledger.** The pay sits at or above the market band your recruiter sent (RR2), and the recent funding is a good sign (RR3). I couldn't check from here that the posting is live (RR1). The job may cover the whole data stack rather than one area (RR5). The reporting line isn't named (RR4) and the equity isn't specified (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is still live on Pellucid's own careers page (RR1); (2) you can work remotely from the US or from Denver (R1); (3) you describe BigQuery honestly as a tool you haven't used yet, with Snowflake as the transferable experience (R5b); (4) you check the scope in the recruiter screen before putting real time into the process (RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page as you pasted it |
| Mandate | "Build and run the pipelines behind our tutoring platform's reporting": ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Ingestion, warehouse and contracts listed together could be the whole reporting data stack rather than one area's pipelines | `[inferred]` from the JD's three-part mandate compared with the report's "ownership of one domain's pipelines" |
| Market calibration | "Senior" at 5+ years matches the report's 5–8 years. The posted $148,000–$166,000 starts $9,000 above the report's 25th percentile ($139,000), tops out $2,500 above its 75th ($163,500), and its midpoint ($157,000) is $6,000 above the median ($151,000). The band is a market pattern, not this employer's offer; the posting's own range is | `[grounded]` the Datawright 2026 report you pasted (US, n=2,310, Series B–D) and the JD's figure; `[generic]` as a role-family norm |
| Unknowns | Data team size and reporting line; how much of the ingestion, BigQuery and contracts work already exists; which CRM; on-call duties for "run"; equity form and size | none |
| Contradictions | None between the JD and the about page as pasted; that the posting is live is not checked (RR1) | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | You didn't say where you're based or whether you can work in the US, so this gate isn't settled either way | `[grounded]` JD; background silent | Question R1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company": specific, but stated in prose with nothing to inspect, so `medium` is the first-pass ceiling | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", backed up by the dbt and Airflow work | `[grounded]` your background | none |
| R4 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models". Specific; no repo or docs inspected | `[grounded]` your background | A sanitized repo or dbt docs would raise this to `high` |
| R5a | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the JD words the requirement | `[grounded]` JD and your background | none |
| R5b | BigQuery as the warehouse the role runs | important | adjacent | medium | transferability | The adjacency is real: dbt modelling and warehouse work transfer. The limit: "Never used BigQuery", so its cost model, partitioning and clustering, nested fields and GCP permissions are new to you | `[grounded]` your own statement; `[inferred]` priority, from BigQuery appearing in the responsibilities and not the requirements; `[generic]` the list of what differs between warehouses | Gap queue G3 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite" | `[grounded]` your background | A suite config or sanitized test docs would raise this to `high` |
| R8 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your background covers modelling, orchestration and testing but doesn't say which sources you ingested or who built those pipelines. `low`, not `none`, because six years of the work makes it a likely thread | `[grounded]` background silent on ingestion | Question G1 below |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is a partial thread. Whether you defined schemas or guarantees that other people relied on isn't stated | `[grounded]` background; `[inferred]` that the test suite is related to contracts | Question G2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8, important) | discovery | Modelling, orchestration and testing are covered; ingestion sources and ownership aren't stated | It's the first part of the mandate, and if the scope is the whole stack (RR5) it's work you'd own | Pulling payroll-app database data into Snowflake through CDC or batch loads; a Salesforce or HubSpot sync via Fivetran, Airbyte or custom Python; Airflow DAGs calling SaaS APIs | A DAG excerpt, a pipeline diagram, a runbook | `[grounded]` background silent; `[inferred]` link to RR5 |
| G2 | Data contracts (R9, important) | discovery | The Great Expectations suite is there; nothing yet about agreed schemas or guarantees | Contracts are named as something "our analysts depend on", so they're likely a core deliverable | dbt model contracts or enforced schemas; freshness or SLA checks analysts relied on; agreeing column definitions with finance or analytics; tests that blocked bad loads | A contract YAML, a schema-change policy, an SLA document | `[grounded]` JD wording; `[inferred]` that it's a core deliverable |
| G3 | BigQuery (R5b, important) | transferability | Snowflake plus dbt at roughly 180 models; no BigQuery | It's the one requirement you know you don't have, and a screen will likely ask about it | dbt logic you'd move across unchanged; any cost or performance tuning you did in Snowflake | A small personal dbt project run on BigQuery | `[grounded]` your own statement; `[generic]` that screens check a named tool |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "pellucidlearning.com/careers/senior-data-engineer" | Research couldn't run, so it's unchecked whether the posting is live. The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. These are side-by-side possibilities, none ranked as likely | `[generic]` pattern for any unchecked posting, not a claim about this one | Is this role open on your careers site now, and who would I be interviewing with? | unresolved |
| RR2 | Posted pay at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range covers and slightly exceeds the report's interquartile range, and the pay is stated openly | `[grounded]` JD and the pasted Datawright report | Where in the range would someone with six years land? | noted |
| RR3 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | Funding about nine months ago makes a short runway less likely to be an early concern | `[grounded]` about page as pasted; `[generic]` link between funding and runway | How is the data team expected to grow over the next year? | noted |
| RR4 | Hiring manager and reporting line unnamed | unknown | — | "The posting names no hiring manager" (your note) | Whether you'd report to a data lead, analytics or engineering changes the scope and the support | `[grounded]` posting silent | Who would this role report to, and how large is the data team today? | unresolved |
| RR5 | Mandate may be the whole stack, not one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role may be the sole or first data engineer across all three layers. That's broader than the report's typical scope, but at a 264-person company it may simply be normal. Low, because nothing in the JD claims a solo role | `[inferred]` from the three-part mandate against the pasted report's scope line | How many data engineers are there, and which of ingestion, the warehouse and contracts exist today versus need building? | unresolved |
| RR6 | Equity unspecified | unknown | — | "plus equity" | Form, size and vesting are unknown, so total pay can't be compared | `[grounded]` JD | What form does the equity take (options or RSUs), and roughly how large is a senior grant? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the role on pellucidlearning.com's own careers page and confirm it's live before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with the three things you described in your own words: you built the dbt project on Snowflake (about 180 models), use Airflow for orchestration, and set up the Great Expectations test suite | see R4, R6, R7 | `[grounded]` your background | pending your approval |
| E2 | Say plainly that you haven't used BigQuery and present Snowflake as the transferable warehouse experience; never list BigQuery as a skill | see R5b | `[grounded]` your own statement | pending your approval |
| W1 | Optional: a small personal dbt project on BigQuery that you can point to | see R5b, G3 | `[generic]` that a hands-on sample narrows a named-tool gap | pending your approval |
| Q1 | Ask the verification questions from RR1, RR4, RR5 and RR6 word for word in the recruiter screen | The register doubles as screen preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Pellucid Learning Senior Data Engineer careers" was refused by this host. It would have settled RR1 and role reality's contradictions row |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted already sets the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can also save all of this as a `tuesday-dossier.md` to pick up later.

## Upgrade menu

- **Allow web search, or paste the live careers page:** this would settle RR1 and lift the cap, so the status could become `go`.
- **Your location, work authorization and any pay floor:** this settles R1 and lets me check the role against your real constraints.
- **Answers to G1 and G2:** these move R8 and R9 off `unclear`.
- **A sanitized dbt repo, dbt docs or your Great Expectations config:** this raises R4 and R7 to `high`.
- **The hiring manager's name:** this sharpens the scope read and which story to lead with.
- **A deeper research pass on Pellucid** (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): this needs search allowed. Say the word and it runs.

**R1:** Are you in the US and able to work either remotely from the US or from Denver? And is there a pay floor or other non-negotiable I should check this role against?

**G1:** At the payroll company, did you build or run ingestion from the product's database or from a CRM or other SaaS tool? Which sources, which tooling, and which parts were yours?

**G2:** Have you defined schemas, freshness guarantees or dbt model contracts that analysts or other teams relied on? If so, who agreed them with you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.