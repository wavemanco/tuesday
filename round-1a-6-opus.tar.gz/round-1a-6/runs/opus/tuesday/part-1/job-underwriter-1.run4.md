Reading the required references.
Web search was declined, so I'm doing the assessment from what you pasted.

## Decision snapshot

**Yes, you look like a strong fit. Your must-haves R1, R2, R3, R4 and R5 are all `direct`. Apply once you've confirmed the posting is real and live. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · adjacent: R7b (Partner with clinicians) · unclear: R6 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience (HIPAA))

R6: probably a strength, but your background doesn't show it yet. R8: no evidence either way so far. R7b and R9: honest bridges from consumer data, with their limits named.

**Opportunity ledger.** I couldn't confirm the employer because my searches were refused (RR1). Pay and location aren't in what you pasted (RR2, RR3). How much of the data modelling sits with this role is open (RR4), and so is what "at scale" means for a care-navigation product (RR5). One entry is good news: there's a team to lead and a BI tool already in use (RR6).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is live on Harborlight's own careers page (RR1); (2) the pay and location work for you once you know them (RR2, RR3); (3) you present R7b and R9 as adjacent experience, never as healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` JD header, not checked independently (RR1) |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior IC role that leads a small team. It owns the analytics surface end to end but isn't written as a manager title | `[inferred]` from "mentor two junior analysts" next to "Senior Product Analyst" with no management language |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Compensation; location and working pattern; whether analytics engineering support exists for the metrics layer; experiment traffic volumes; who the role reports to | — |
| Contradictions | None in the pasted JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years at a meal-kit subscription company, above the bar. Self-reported and not yet probed, so `medium` | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is the JD's word, and nothing inspectable supports it yet: expect a live SQL exercise | `[grounded]` your background; `[generic]` that senior analyst loops often test SQL live | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year across ~2M subscribers, including the pricing test behind an 11% retention lift | `[grounded]` your background | Optional: a sanitized experiment readout would raise this to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards. An exact tool match | `[grounded]` your background | Optional: sanitized LookML or a dashboard screenshot would raise this to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | Optional: a redacted memo would raise this to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" and building the Looker instance suggest a modelled semantic layer, but your background doesn't say you defined the metric definitions or the modelling yourself | `[inferred]` from "built the Looker instance from scratch" and "governed" | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Monthly VP Product presentations and a pricing test tied to a retention outcome. What part you played in the decision itself isn't stated, so expect a probe | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | What carries over: translating analysis for non-technical leaders (R5). The limit: you haven't worked with clinical stakeholders | `[grounded]` your background; `[generic]` that clinical partners usually weigh patient safety and evidence standards differently from commercial leaders | See G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or leading people | `[grounded]` background silent | Closing question G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | What carries over: handling GDPR/CCPA consumer PII and building the warehouse's consent-state model. The limit: you haven't worked under HIPAA | `[grounded]` your background; `[generic]` that HIPAA work involves PHI-specific rules (de-identification standards, minimum-necessary access, business associate agreements) that consumer-privacy regimes don't | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | A Looker build with governed dashboards; no stated ownership of metric definitions or the model underneath | It's the first responsibility the JD lists; if it's yours, it turns into a headline strength | Writing the LookML views and explores yourself; settling the canonical definition of "active subscriber" or "churn" across teams; owning a dbt or Snowflake model the dashboards read from | A LookML snippet, a metric-definitions doc, a dbt model list | `[grounded]` background silent on ownership; `[inferred]` that it would become a strength |
| G2 | Clinician partnership (R7b, important) | transferability | Strong exec and VP communication; no clinical audience | A bridge you can name honestly is stronger than leaving it out | Working with ops or food-safety and nutrition specialists on metrics; turning analysis into a decision for a domain-expert audience | A memo written for a specialist audience | `[grounded]` background; `[generic]` that panels in this space probe clinical collaboration |
| G3 | Mentoring (R8, important) | discovery | Nothing either way | Two junior analysts report in, so this is part of the daily job | Onboarding new analysts onto Looker; reviewing others' SQL or test designs; running office hours for self-serve users | A training doc, a review checklist | `[grounded]` background silent |
| G4 | HIPAA data (R9, preferred) | transferability | GDPR/CCPA PII handling; built the consent-state model | It's preferred, not required, so it's a differentiator rather than a blocker | The consent-state model itself; access controls or masking you set up on PII columns | A sanitized schema or design note for the consent model | `[grounded]` background; `[generic]` that the PHI rules differ, as R9 says |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here the searches were refused, so nothing was checked | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me to this role on Harborlight's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | Pasted JD has no pay line | Pay may sit anywhere relative to the senior band. No band was researched | `[inferred]` from the JD's silence | What salary range and equity are budgeted for this role? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | Pasted JD has no location | Could be remote, hybrid or on-site | `[inferred]` from the JD's silence | Where is this role based, and how many office days are expected? | unresolved |
| RR4 | Metrics-layer ownership without stated data-engineering support | unknown | — | "define and maintain the metrics layer" | The role may also carry analytics-engineering work on top of analysis, testing and mentoring | `[inferred]` from the breadth of the mandate against its silence on data-team support | Who builds and maintains the underlying data models, and does this role have analytics-engineering support? | unresolved |
| RR5 | "Experiment design at scale" with undefined scale | unknown | — | "experiment design at scale" | A care-navigation app's traffic and its limits on testing care pathways may differ a lot from a 2M-subscriber consumer product | `[generic]` that healthcare products often face smaller samples and ethical limits on randomization | Roughly how many tests a quarter do you run, at what traffic, and what can't be A/B tested for clinical reasons? | unresolved |
| RR6 | Team and tooling exist | positive_signal | — | "mentor two junior analysts"; "build self-serve dashboards in Looker" | Headcount and a BI tool are already in place, so the role isn't starting from zero | `[grounded]` JD | What do the two junior analysts work on today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with three stories in your own words: you "designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift"; you "built the company's Looker instance from scratch, 40+ governed dashboards"; you write the monthly metrics memo the exec team reads | see R3, R4, R5 | `[grounded]` your background | pending your approval |
| P2 | Describe privacy experience as: "I haven't worked under HIPAA; I've handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse" | see R9: adjacent, so state the limit before anyone asks | `[grounded]` your background | pending your approval |
| P3 | Answer G1 and G3 before applying. Add metrics-layer or mentoring lines only if you confirm them | see R6, R8 | `[grounded]` background silent | pending your approval |
| P4 | Ask the questions from RR1, RR2, RR3, RR4 and RR5 word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

These are proposals only. Please check each row's wording before you use it anywhere.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app"; refused by the host. It would have confirmed the company and the live posting, closing RR1 and lifting the cap on the decision |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; refused by the host. It would have added a market calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

I can save all of this as a `tuesday-dossier.md` if you want a portable copy.

## Upgrade menu

- **Allow web search:** confirms the employer and the live posting (RR1) and adds a senior-analyst pay band (RR2).
- **Your constraints (pay floor, location, start date):** they become rows in the map and fill in the hard-gates line.
- **Sanitized LookML or a metric-definitions doc:** R4 to `high`, and possibly closes R6.
- **A redacted experiment readout or metrics memo:** R3 or R5 to `high`.
- **The hiring manager's name:** which story to lead with for that reader.
- **Deeper research on Harborlight** (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches, and it needs search allowed): say the word and it runs.

## Questions

G1: Did you personally define the metric definitions, or write the LookML or data models behind those 40+ dashboards? Which parts were yours and which were the team's?

G3: Have you onboarded, trained or reviewed the work of other analysts, even informally? What did that look like?

Constraints: What's your pay floor, which locations or working patterns work for you, and where are you in the process (just evaluating, or about to apply)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.