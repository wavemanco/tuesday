Let me read the required reference files.
## Decision snapshot

**Yes, apply, once two things check out (listed below). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R10 (pricing a pet-insurance product) · unclear: R8 (recommendations for product)
- `preferred`: direct: R9

R10: a motor-to-pet bridge, with its limit stated; R8: you haven't yet shown recommendations aimed at product teams; R1: you haven't told me where you live or about your right to work in the UK.

**Opportunity ledger.** I couldn't verify the employer because the web searches were refused in this session (RR1). The salary isn't stated (RR2), and the posting doesn't say what modelling stack or team size you'd have (RR3, RR4). One entry is a positive: the mandate and the people you'd present to are stated plainly (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting check out on its own careers site (RR1); (2) you confirm you're UK-based with the right to work here (R1); (3) you present pet insurance honestly as a new product line for methods you already use, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling a pet-insurance product | `[grounded]` JD header; not checked (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to / reader | Odile Varga, Director of Pricing | `[grounded]` your message |
| Management scope | The JD lists no line management, team leadership or mentoring | `[grounded]` JD silence |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One analyst owning the analytics for one product line, with two audiences (underwriting and product). Normal scope for a senior individual-contributor pricing role, not a lead role | `[inferred]` from "own pricing analytics" plus no mention of reports |
| Market calibration | Not established. The role-family sweep was refused, so I have no salary band to give | none |
| Unknowns | Salary; team size; whether the current rating model is a GLM or a machine-learning model; who in product receives the recommendations | none |
| Contradictions | None in the JD as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): UK-based, with right to work | hard_gate | unclear | low | hard_gate | You worked at a UK insurer, but you haven't said where you live or what your right-to-work status is. Working at a UK firm doesn't settle either one | `[grounded]` your background; `[inferred]` that it leaves the gate open | G3's question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior. Specific, but self-reported with nothing to inspect | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily in pricing work. "Strong" is the employer's word, and a technical exercise may test it | `[grounded]` your background; `[generic]` that pricing loops often include a SQL or Python exercise | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintain the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. You haven't said which parts were yours (design, read-out, or both) | `[grounded]` your background | Expect a probe on what was yours; be ready to say it precisely |
| R7 | Build and monitor rating models | must_have | direct | medium | none | Same evidence as R4: "built and maintained" covers both building and monitoring | `[grounded]` your background | none |
| R8 | Turn results into recommendations for product | important | unclear | low | discovery | Your recommendations to underwriting are evidenced (R5, R6). Nothing yet shows recommendations going to product or proposition teams | `[grounded]` background silent on product | G2's question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pricing a pet-insurance product | important | adjacent | medium | transferability | The methods carry over: GLM rating, price testing, presenting to underwriting. What doesn't carry over is pet-specific risk factors, claim patterns and renewal dynamics, which you say you've never worked on | `[inferred]` requirement, from "pricing analytics for our pet-insurance product"; `[grounded]` "never worked on pet insurance" | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R10, important) | transferability | Motor pricing methods that carry over; no pet-product work | Domain is the obvious difference between you and a pet-insurance hire, so how you frame it shapes the application | Renewal or retention pricing; claims-inflation or frequency/severity trend work; pricing a book with thin data (young drivers is one); any non-motor line you touched | A sanitized test read-out or model-monitoring summary | `[grounded]` your stated gap; `[generic]` that domain is the likeliest objection |
| G2 | Recommendations to product (R8, important) | discovery | Underwriting audience evidenced; product audience not | The JD names product as a second audience for your recommendations | A test result that changed a cover option, excess level or discount; work with marketing or product on a launch or a price change | A deck or memo written for a non-underwriting audience | `[grounded]` background silence |
| G3 | UK residence and right to work (R1, hard_gate) | hard_gate | Not stated | It's a term you either meet or don't, and no wording can fix it | — | — | `[grounded]` JD's "Fully remote (UK)" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a public footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. These are possibilities, none ranked above the others; my searches were refused, so nothing was checked | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in the JD) | The figure may sit below what a senior pricing analyst expects, or the company may just not publish salaries | `[inferred]` from the missing salary in the posting | What salary range is budgeted for this role? | unresolved |
| RR3 | Modelling stack not stated | unknown | — | "build and monitor rating models" | The pet rating model may not be a GLM (for example a GBM), which would change how far R4 carries | `[inferred]` from the JD's silence on method | Is the current pet rating model a GLM, and is a move to other methods planned? | unresolved |
| RR4 | "Own" with no team or support mentioned | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only pricing analyst on the product, with no data engineering or actuarial support | `[inferred]` from "own" alongside no mention of a team | Who else works on pet pricing, and what data and engineering support does the role have? | unresolved |
| RR5 | Clear mandate and named audiences | positive_signal | — | "turn the results into recommendations for underwriting and product" | The scope is concrete, and you'd be presenting to the same kind of audience you present to now | `[grounded]` JD | How are price-test results acted on today, and who signs them off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with: "I built and maintain the GLM rating model for our young-driver book, and last year ran 14 price tests with the underwriting team." | Hits R4, R6 and R7 in your own words. Keep "with the underwriting team"; don't upgrade it to "led" unless that's accurate | `[grounded]` your background | pending your approval |
| P2 | Say plainly: "I haven't priced pet insurance; what I'd bring is GLM rating, price testing and presenting results to underwriting." | Frames R10 as a bridge with its limit stated, not as experience you don't have | `[grounded]` your background | pending your approval |
| P3 | Find Brindlemoor's own careers page and confirm the posting is live before you put effort into the application | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions for RR1 through RR5 word for word during the interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

On never having managed anyone: no row covers it, because the JD doesn't ask for management (role reality, Management scope).

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech"; the call was refused (no search permission). It would have confirmed the company and the live posting, and could have cleared RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary 2026 remote"; refused. It would have given the market calibration and a salary band to set against RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have shaped which of your stories P1 leads with for this reader |

I can write all of this up as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- **Allow web search** and I'll rerun targets 1–3. That could clear RR1, give a salary band for RR2, and tune P1 to Odile Varga's background.
- **Your CV** would let me check how it already presents R4, R6 and R7, and spot any `presentation` gaps.
- **A sanitized test read-out or monitoring summary** would raise R4, R6 and R7 from `medium` toward `high`.
- **Your salary floor and any location or contract constraints** would let me check the hard gates against them, not just against the JD.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs once search is allowed.

## Questions

G3: Are you UK-based with the right to work in the UK without sponsorship?

G2: Have any of your price-test results or reviews gone to product or proposition teams rather than underwriting, for example changing a cover option, an excess or a discount? What was yours in it?

G1: Beyond young-driver motor, have you done renewal pricing, claims-inflation trend work or anything on a non-motor line?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.