Reading the job-underwriter's reference files before writing your assessment.
**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R10 (Remote (US) or our Denver office)
- `must_have`: direct: R1, R2, R3, R4, R6, R7
- `important`: adjacent: R5 (a dbt-modelled warehouse in BigQuery) · unclear: R8 (ingestion from our app and CRM), R9 (the data contracts our analysts depend on)

R5: a credible bridge from Snowflake, with its limit named; R8, R9: your background doesn't mention them yet, one question each.

**Opportunity ledger.** The scope is clear and the posted pay sits at or above the band in your recruiter's report (RR2, RR5). The equity, the reporting line and the on-call expectations are not stated (RR3, RR4, RR6). I couldn't check the employer from here, and that caps the call (RR1).

- **Hard gates:** none failed; unconfirmed: R10 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Pellucid's own careers page (RR1); (2) you're US-based or can work from Denver (R10); (3) you present BigQuery honestly as something you'd be learning, not something you've used (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` the About page text you pasted; not checked live (RR1) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Must-haves | 5+ yrs DE; strong SQL and Python; dbt plus a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Hard gate | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain (reporting) end to end, no direct reports mentioned. That is ordinary scope for a Senior IC | `[inferred]` from the JD's mandate set against the report's scope description |
| Market calibration | The report puts Senior DE at Series B–D at 5–8 yrs and one domain with no reports, base median $151k, IQR $139k–$163.5k. The posting's $148k–$166k starts $3k below the median and ends $2.5k above the 75th percentile | `[grounded]` the Datawright figures you pasted (recruiter-sent, not checked); `[generic]` that a survey band describes the role family, not this employer's offer |
| Unknowns | Equity terms; reporting line and team size; on-call; how big the CRM/app ingestion surface is | none |
| Contradictions | None between the JD and the About text | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated; prose background is the same as a CV at intake, so it caps at `medium` | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" | `[grounded]` your background | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. That's ownership, not just usage | `[grounded]` your background | A repo or dbt docs/lineage screenshot would raise to `high` |
| R4 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the JD writes it | `[grounded]` JD wording plus your background | none |
| R5 | BigQuery specifically (the named stack) | important | adjacent | medium | transferability | You've never used BigQuery. The dbt modelling, testing and orchestration carry over. The limit is BigQuery's own cost model, partitioning and clustering, and its SQL dialect differences | `[inferred]` tier from the JD's responsibilities line; `[generic]` that warehouse-specific tuning is the part that doesn't carry over | see G1 |
| R6 | Airflow or similar | must_have | direct | medium | none | Airflow, exact match | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite yourself | `[grounded]` your background | A sanitized GE data-docs page would raise to `high` |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Your background doesn't mention which sources you ingested | `[grounded]` background is silent | see G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Your background is silent. GE tests and dbt model ownership are near it but aren't the same thing | `[grounded]` background is silent | see G3 |
| R10 | Remote within the US, or the Denver office | hard_gate | unclear | none | hard_gate | No location or work authorization stated, so the gate is unsettled | `[grounded]` JD; nothing from you yet | Question R10 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, important) | transferability | 180-model dbt project on Snowflake; no BigQuery | It's the one named-stack gap, so expect it to come up | Carries over: dbt project design, incremental models, testing, Airflow DAGs. Limit: no BigQuery cost or partitioning work. Strengthener: a small dbt-on-BigQuery project before interviews | A public repo of that project | `[grounded]` your background; `[generic]` that a named-stack gap draws a probe |
| G2 | App/CRM ingestion (R8, important) | discovery | Ingestion isn't mentioned | Half the stated mandate | Pulling from a production app DB (CDC, replicas, event streams); a CRM or HRIS/payroll API into the warehouse; Fivetran/Airbyte or custom Python loaders | A DAG or a design doc, sanitized | `[grounded]` background is silent |
| G3 | Data contracts (R9, important) | discovery | GE suite and dbt ownership, but no "contracts" yet | Named in the mandate; a likely differentiator for a Senior hire | dbt model contracts or enforced schemas; agreed SLAs/freshness with analysts; schema-change rules with upstream app teams; GE checks that block bad loads | A contract YAML, a schema-change policy, an SLA doc | `[grounded]` background is silent; `[inferred]` that GE plus dbt ownership sits near it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. These are possibilities, not ranked | `[generic]` pattern, not a claim about this company; my checks were refused, so this is unverified, not a negative finding | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay posted, at or above the pasted band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range runs from just under the report's median to above its 75th percentile | `[grounded]` JD and the pasted report | Where in the range does a 6-year candidate typically land? | noted |
| RR3 | Equity unspecified | unknown | — | "plus equity" | The type, size and vesting could be anything | `[grounded]` JD says nothing more | What form does the equity take (options or RSUs), how much, on what vesting schedule, and what's the current strike or 409A price? | unresolved |
| RR4 | No hiring manager or reporting line named | unknown | — | (posting names no hiring manager) | Who you report to and the team size are unknown | `[grounded]` your note | Who does this role report to, and how many data engineers and analysts are there? | unresolved |
| RR5 | Concrete stack, deliverables and funding | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The scope is defined; it's not a vague catch-all role | `[grounded]` JD and About text | What does a successful first 90 days look like? | noted |
| RR6 | "Run" implies operational ownership; on-call is unstated | unknown | — | "Build and run the pipelines" | There may be an on-call rotation | `[inferred]` from "run" | Is there an on-call rotation for pipeline failures, and how often does it come round? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting is live on pellucidlearning.com/careers before you apply | RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with your dbt build (~180 models), the Great Expectations suite you set up, and Airflow | R3, R6, R7: exact matches to the must-haves | `[grounded]` your background | pending your approval |
| P2 | Say plainly "Snowflake, not BigQuery" and name what carries over and what you'd be learning | R5, G1 | `[grounded]` R5 row | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery repo before interviews | Narrows G1's limit | `[generic]` hands-on proof beats a claim | pending your approval |
| Q1 | Ask the verification questions for RR3, RR4 and RR6 word for word in early calls | The risk register doubles as interview prep | `[grounded]` register | pending your approval |
| N1 | At offer stage, aim for the upper half of $148k–$166k, using 6 years against the report's 5–8 | RR2 | `[grounded]` the pasted figures | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring Denver Senior Data Engineer". The call was refused (search permission not granted). It would have confirmed the posting is live and the About facts are right, which would close RR1 |
| 2. Role-family sweep | unavailable | Searched "Datawright 2026 Data Engineering Pay Report". The call was refused. It would have confirmed the pasted report is real and current. The pasted figures are used as given |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can write all of this up as a `tuesday-dossier.md` for later steps if you'd like.

**Upgrade menu**
- Allow web search → RR1 can close, and the pay report gets checked; that may lift the status to `go`.
- Your location, work authorization and pay floor → R10 settles, and the pay floor is checked against $148k–$166k.
- A repo, a dbt docs/lineage page or GE data docs (sanitized) → R3 and R7 rise to `high`.
- The hiring manager's name → a better scope read and better positioning.
- A deeper research pass on Pellucid (funding, leadership changes, employee reports; up to 5 more searches and 2 more fetches) → just say so.

**Questions**

R10: Are you based in the US (or willing to work from Denver) and authorized to work there without sponsorship?

G3: Have you set up anything like a data contract: enforced schemas or dbt model contracts, agreed freshness or SLAs with analysts, or rules for how upstream teams change schemas? What was yours?

G2: Which sources did you ingest yourself at the payroll company: the app database, a CRM or other SaaS APIs, event streams? What tooling did you use?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.