Now the required references.
# Underwriting: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, you are not wasting your time. The one serious problem is the "3+ years product management" must-have (R1b), and it is about getting past the screen, not about whether you can do the job. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct R3, R4a · adjacent R1a (3+ years product management, the PM-shaped work), R2 (Shipped API or platform products) · unclear R4b (Stakeholder management with sales), R5 (Experience with agile delivery) · absent R1b (3+ years in a PM title)
- `important`: direct R8 · adjacent R6 (Own the roadmap), R7 (Run discovery with integration partners), R10 (Coordinate launches with sales and support) · unclear R9 (Define and track adoption metrics)

R1b is the screen to plan around, not a verdict on your skills. R2 is the bridge that decides how you interview. R9 is where the unconfirmed triage-tool lead could count.

**Opportunity ledger.** The mandate is concrete and names its resources (RR4). I couldn't confirm the employer from here (RR1). The posting doesn't state pay or location (RR2, RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the live posting check out, see RR1. (2) You reach a person and not only a keyword or title screen, given R1b; see plan A1. (3) R2 is framed as adjacent work and never as "shipped a product", unless G1's answer changes that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics tech, about 150 people, Series B | `[grounded]` JD header, not checked (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Must-haves | 3+ years PM experience; shipped API or platform products; technical fluency with API docs and schemas; stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| First-year outcomes | None stated. Likely judged on partner adoption of the API, because the JD names "adoption metrics" as something you own | `[inferred]` from the JD's metrics line |
| Scope read | A single-platform PM role with two squads. The work is mostly partner-facing, which is the same audience as your current job | `[inferred]` from the JD's responsibilities, set against your described work |
| Hard gates | None stated in the JD (no location, authorization, pay or travel terms) | `[grounded]` JD silence |
| Unknowns | Pay; location or remote policy; who sets roadmap priorities above this role; how the "3+ years" is screened | — |
| Contradictions | None in the pasted JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management: the PM-shaped work | must_have | adjacent | medium | transferability | You have 7 years of requirements docs, cross-team coordination and quarterly roadmap-input sessions for product. That is the input side of product work. The limit is that none of it was owning prioritization or the roadmap itself | `[grounded]` your background; `[inferred]` that this is the input side of product management | Bridge it in the application plan (P1) |
| R1b | 3+ years in a PM title | must_have | absent | none | capability | You've said you never held a PM title. Wording can't fix that and no line should imply otherwise. `[generic]` Title-and-years requirements are often screened literally at the first filter | `[grounded]` your statement; `[generic]` screening pattern | Get past the screen through a person (A1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations led end to end, plus custom builds coordinated with PMs. That is deep delivery on someone else's platform. The limit is that nothing yet shows you owned what the product became | `[grounded]` your background | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI specs, plus integration architecture across 30+ builds. Specific, but you'll get a probe on it | `[grounded]` your background | none |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and PMs on custom builds | `[grounded]` your background | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | Your background doesn't mention sales | `[grounded]` silence in your background | Upgrade menu |
| R5 | Agile delivery | must_have | unclear | low | discovery | Your background doesn't mention sprints, backlogs or ceremonies | `[grounded]` silence in your background | Upgrade menu |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You fed the roadmap (quarterly input sessions) but didn't own it | `[grounded]` your background | Frame as input, not ownership (P1) |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops with client engineers sit close to partner discovery. The limit is that they scoped one integration, not what the platform should become | `[grounded]` your background; `[inferred]` closeness to partner discovery | P1 |
| R8 | Write specs | important | direct | medium | none | Requirements documents and integration architecture handed to engineers, plus a playbook the whole team uses | `[grounded]` your background | none |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your background doesn't mention metrics. An unconfirmed lead from earlier memory says you built an internal request-triage tool that support agents adopted. It is a basis for a question, not evidence | `[grounded]` silence in your background; memory lead unconfirmed | G2 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | 30+ go-lives are client launches, not product launches to a market | `[grounded]` your background | P1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform products (R2, must_have) | transferability | Delivery of integrations on your company's API; custom builds alongside PMs; no decision you owned about the product itself | R2 is a must-have at `adjacent`. A stronger bridge narrows the question an interviewer is likeliest to press | A custom build you specced that became a standard feature or endpoint; a change to the API or its docs that came from your feedback sessions; a scoping decision where you set what got built and what didn't | A requirements doc, a release note, the playbook itself (redacted) | `[grounded]` your background; `[generic]` that this is the likeliest probe |
| G2 | Adoption metrics (R9, important) | discovery | The unconfirmed triage-tool lead; no metrics in your background | If confirmed, it is an internal product you built, that people adopted, with a way to measure that. It would touch R9 and R2 | Number of support agents using it; tickets routed; time saved; how you knew whether people used it; the playbook's uptake across your team | A screenshot of the tool or its usage, a before/after figure, a team note | `[grounded]` memory lead, unconfirmed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. My research calls were refused, so none of these was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation withheld | unknown | — | No pay range in the posting | The figure may sit below what you'd expect, or the company may simply not publish ranges | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | No location in the posting | It may need an office or region you haven't stated | `[inferred]` from the posting's silence | Where is this role based, and what is the in-office expectation? | unresolved |
| RR4 | Concrete mandate with resources named | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The scope comes with teams and a measure of success | `[grounded]` JD | What adoption numbers does the platform have today, and who set them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the integration playbook and the 30+ end-to-end API integrations. Describe the roadmap sessions as "collected client feedback for product", never as owning the roadmap | See R1a, R2, R6, R7 | `[grounded]` your background | pending your approval |
| A1 | Reach the hiring manager or a Quartzline PM through a referral or a direct note before or alongside applying, so a person reads the case behind R1b | Title-and-years screens favour a human reader over a keyword pass | `[generic]` hiring pattern, not a fact about this employer | pending your approval |
| W1 | Optional: a one-page sample spec or adoption-metrics proposal for a partner API, written from public material only | Gives the interviewer something to inspect for R2, R6 and R9 | `[inferred]` from the JD's spec and metrics duties | pending your approval |
| Q1 | Ask the verification questions for RR1–RR4 word for word in early calls | The register doubles as interview prep | `[grounded]` register | pending your approval |

All wording in P1 and W1 is proposed, pending your approval. Once you decide to apply, the resume-tailor module can rework the resume for this posting.

## Evidence status

Verified: none yet. Unverified leads: the internal request-triage tool from earlier memory (G2).

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics API platform" was refused. It would have checked whether the company exists as described and whether the posting is live (RR1, role reality's organization row) |
| 2. Role-family sweep | unavailable | The search "platform API product manager salary Series B B2B SaaS 2026" was refused. It would have given a market calibration line and a pay band to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can save all of this as a `tuesday-dossier.md` whenever you want it.

**Upgrade menu**
- Allow web search → RR1 is checked and can close; a market pay band fills RR2 and the market calibration line.
- Your pay floor, location and work authorization → hard-gate rows that today read "constraints not given."
- An answer on sales and agile work (R4b, R5) → two must-haves move from `unclear`.
- A redacted page of the integration playbook or a requirements doc → R8 and R2 gain something to inspect.
- The hiring manager's name → target 3 runs, and P1 picks which story to lead with for that reader.
- A deeper research pass on Quartzline (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1: Think of a custom build or a piece of client feedback where you decided, or strongly shaped, what the product itself became, such as an endpoint, a feature or a docs change. What was your part, and did it ship to more clients than one?

G2: Earlier context suggests you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you build, how many people used it, and how did you know it was working?

C1: Do you have a pay floor, location or remote requirement, or work-authorization limit that this role would need to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.