I'm reading the rest of the skill's rules before writing your fit assessment.
**Yes, you fit the core of this role, and it's worth applying to: every `must_have` row (R1–R5) is `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R8 (Partner with clinicians) · unclear: R6 (Define and maintain the metrics layer), R7 (Partner with PMs on roadmap decisions), R9 (Mentor two junior analysts)
- `preferred`: adjacent: R10 (Healthcare data experience, HIPAA)

R6, R7, R9: the JD asks for these and your background says nothing about them yet; R8, R10: a real bridge from consumer PII work and exec writing, with its limit stated.

**Opportunity ledger.** I couldn't verify the employer or posting because my searches were refused (RR1). Pay and work location aren't stated (RR2, RR3), and the traffic behind "experiment design at scale" isn't stated either (RR5). On the plus side, the scope is concrete: a named BI tool, a named team and named duties (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight and this posting check out as live on the company's own careers page (RR1). (2) Pay and work pattern meet your floor (RR2, RR3), which I can't check until you tell me your constraints. (3) R8 and R10 are presented as adjacent experience, never as healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C; makes a care-navigation app | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians on roadmap decisions | `[grounded]` JD |
| Team | Two junior analysts to mentor | `[grounded]` JD |
| First-90-days outcomes | Probably an audit of the existing metrics layer and Looker set-up before building on it | `[inferred]` from "define and maintain the metrics layer" alongside an existing Looker stack |
| Scope read | A senior individual contributor with mentoring duties, not a people manager | `[inferred]` from "mentor" rather than "manage", and no reports beyond the two juniors |
| Market calibration | Not established: the role-family sweep couldn't run | — |
| Unknowns | Pay; location and work pattern; reporting line; warehouse stack; user volume available for experiments | — |
| Contradictions | None within the JD; careers page not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years stated. Medium is the most this pass can give without probing | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" is direct. "Expert" will be tested live, so expect a SQL exercise | `[grounded]` your background; `[generic]` that this role family tests SQL live | Prep: window functions, cohort and retention queries |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program: 30+ tests a year, including the pricing test behind an 11% retention lift. Scale at Harborlight is unknown (RR5) | `[grounded]` your background | Lead with this (E1) |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch, with 40+ governed dashboards. Exact tool match | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo the exec team reads; monthly presentations to the VP Product | `[grounded]` your background | A redacted memo would raise this to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" suggests a modeled semantic layer (LookML explores, metric definitions), but you didn't say you defined or own one | `[inferred]` from "built from scratch" plus "governed" | G2 |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | unclear | low | discovery | The pricing test is a decision outcome; working day to day with PMs on roadmap calls isn't stated | `[grounded]` your background is silent on PM partnership | G3 |
| R8 | Partner with clinicians | important | adjacent | medium | transferability | What transfers: translating analysis for non-technical execs (R5). Limit: no clinical stakeholders, so no experience with clinical outcome measures or safety review of experiments | `[grounded]` you stated no healthcare experience; `[inferred]` bridge from R5 | G4 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Your background is silent on mentoring or leading analysts | `[grounded]` silence in your background | G1 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | What transfers: GDPR/CCPA consumer PII, and you built the warehouse's consent-state model. Limit: no PHI, HIPAA minimum-necessary access, de-identification or BAAs | `[grounded]` your background; `[generic]` that HIPAA work centres on PHI access and de-identification | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R9, important) | discovery | Nothing about developing other analysts | Named in the JD; senior-level loops usually probe it | Onboarding a new analyst to the Looker models; reviewing others' SQL or test designs; running an experiment-design review; being the main point of contact for an intern | A review checklist, an onboarding doc, a manager's or peer's comment | `[grounded]` silence in your background; `[generic]` that senior loops probe mentoring |
| G2 | Metrics layer (R6, important) | discovery | A Looker build, but ownership of metric definitions isn't stated | The first item in the mandate; also sharpens the R4 story | Writing LookML views/explores; settling a "what counts as an active subscriber" dispute; a metrics dictionary; dbt models feeding Looker | A sanitized LookML snippet, a metric glossary, a definitions doc | `[grounded]` your background; `[inferred]` from "governed" |
| G3 | PM roadmap partnership (R7, important) | discovery | Upward reporting is clear; working with PMs isn't | The "turn analysis into decisions" part of the JD | A feature you killed or shipped because of your analysis; sizing an opportunity for a PM's roadmap | A one-page decision memo | `[grounded]` your background |
| G4 | Clinicians and HIPAA (R8, R10) | transferability | Consumer PII governance and exec communication | Preferred tier, so it adds to your case but won't block it | Consent-state model design; access controls on PII tables; a deletion or DSAR pipeline | A schema diagram of the consent model (redacted) | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the check simply couldn't run | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | Posting gives no figure | The figure may sit below what you expect, or the company may simply not publish pay | `[inferred]` from the missing figure | What's the budgeted range for this role, including equity? | unresolved |
| RR3 | Location and work pattern not stated | unknown | — | Posting gives no location | Could be remote, hybrid or on-site | `[inferred]` from the missing terms | Is this role remote, hybrid or office-based, and where? | unresolved |
| RR4 | Concrete scope and resources | positive_signal | — | "build self-serve dashboards in Looker… mentor two junior analysts" | The role has a named tool, a team and defined duties | `[grounded]` JD | Who do the juniors report to today? | noted |
| RR5 | "At scale" with unstated traffic | unknown | — | "experiment design at scale" | A care-navigation app may have far fewer users than a 2M-subscriber base, so experiments may need variance reduction or sequential testing | `[generic]` health apps often run on smaller samples than consumer subscription products | How many experiments ran last quarter, and what's the typical weekly sample per arm? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open with "designed and ran the experimentation program — 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Keep "program" as the subject unless you personally designed the pricing test | see R3 | `[grounded]` your wording | pending your approval |
| E2 | Describe the Looker build as a governed metrics layer, but only after G2 confirms you owned the definitions | see R4, R6 | `[grounded]` R4; R6 unconfirmed | pending your approval |
| E3 | Bridge line: "handled GDPR/CCPA consumer PII and built the warehouse's consent-state model." No "HIPAA" claim | see R10 | `[grounded]` your wording | pending your approval |
| Q1 | Ask the verification questions for RR1–RR5 word for word during interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Confirm the posting on Harborlight's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |

All language in E1–E3 is proposed only; none of it is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; the search was refused (no permission). It would have confirmed the company and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; refused. It would have given the market calibration and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name given |

If you'd like, I can save this as a `tuesday-dossier.md` so later steps can pick it up.

**Upgrade menu**
- Grant web search → RR1 resolved and a pay band for role reality and RR2.
- Your constraints (pay floor, location, work authorization) → real hard-gate checks.
- A redacted metrics memo or LookML snippet → R5 or R6 toward high.
- The hiring manager's name → which of your stories to lead with for that reader.
- A deeper research pass on Harborlight (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: Have you formally or informally developed other analysts, for example onboarding, reviewing SQL or test designs, or being someone's go-to person? What did you own?

G2: In the Looker build, did you personally define the core metrics and write the LookML or dbt models behind them, or did someone else own the definitions?

RR2/RR3: What's your pay floor, and do you need remote, hybrid or a specific location?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.