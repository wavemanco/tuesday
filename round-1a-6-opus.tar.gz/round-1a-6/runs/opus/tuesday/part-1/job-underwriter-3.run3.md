Reading the required reference files.
Here's my full assessment. My two web searches were refused, so it rests only on the posting and the background you gave me.

## Decision snapshot

**No, it isn't worth pursuing. R1 and R2 are both hard gates and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (At least $150k base), R2 (Remote-only, from Portland)
- `must_have`: direct: R3a, R4, R5 · unclear: R3b (8+ years of growth *leadership*), R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships and sales ops)
- `important`: unclear: R9 (Executing hands-on as a team of one)

R1, R2: both fail on the posting's own stated terms; R6, R7, R8, R9: only worth closing if R1 and R2 ever change.

**Opportunity ledger.** The off feeling has a source in the text. The role bundles seven functions into one person with no team (RR1). It asks for 8+ years of leadership and a board line at a base the posting's own terms make look low for that mandate (RR4). It expects evenings and weekends (RR5) and sets no success metrics (RR6). Budget and decision rights aren't mentioned (RR7). Against your terms, pay (RR2) and location (RR3) are confirmed conflicts. Two entries cut the other way: you'd report to the CEO with a board line (RR8), and they claim to be profitable (RR9). I couldn't verify the employer (RR10).

- **Hard gates:** failed: R1 (At least $150k base), R2 (Remote-only, from Portland).
- **Severe red flags:** RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** both facts would have to change. The base would need to reach at least $150k, not $70–85k, and the role would need to be fully remote, against "5 days a week — no exceptions". You'd also have to accept RR1 and RR5 as the job.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, says it has been profitable since day one | `[grounded]` posting header; not verified (RR10) |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Resourcing | "Team of one to start"; no budget named | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` posting |
| Scope read | This is several roles' worth of work. It's set up as a senior leader with a board line, but staffed and paid like a single hands-on hire. | `[inferred]` from the seven named functions, team of one and stated base |
| Market calibration | Not established. The role-family sweep couldn't run, so I give no market band here. | — |
| Unknowns | Growth budget; decision rights; equity terms (percentage, vesting, strike price); what "success" means in year one | — |
| Contradictions | A senior mandate ("8+ years", "dotted line to the board") against a junior-priced base and no team | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | At least $150k base (your hard constraint) against the posted $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. Fit fails because the top of the posted range is $65k below your floor. Equity doesn't count toward a base floor. | `[grounded]` posting figure and your stated constraint | none unless Novaline restates the base |
| R2 | Remote-only from Portland, against on-site in Austin 5 days, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint, which includes not relocating. The posting rules out any flex in advance. | `[grounded]` posting and your stated constraint | none, since the posting says "no exceptions" |
| R3a | Growth leadership roles held | must_have | direct | medium | none | Growth lead, then Head of Growth, at two B2C subscription companies. Self-reported, so it stops at `medium`. | `[grounded]` your background | none |
| R3b | 8+ years of growth *leadership* specifically | must_have | unclear | low | discovery | You give 9 years in growth overall but not how many were in lead roles. The posting counts leadership years. | `[grounded]` your background against the posting's wording | G1 |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid, with a budget you controlled, while scaling from $8M to $40M ARR. | `[grounded]` your background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and have deep Braze experience. | `[grounded]` your background | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention it either way | `[grounded]` silence in your background | G2 |
| R7 | Brand and PR | must_have | unclear | none | discovery | Your background doesn't mention it either way | `[grounded]` silence in your background | G2 |
| R8 | Partnerships and sales ops | must_have | unclear | none | discovery | Your background doesn't mention it, and both sit outside a B2C subscription growth remit. | `[grounded]` silence; `[inferred]` that it's outside your B2C remit | G2 |
| R9 | Executing hands-on as a team of one | important | unclear | low | discovery | Your recent roles managed teams of 3–7, and your background doesn't say how hands-on you were. | `[grounded]` your background | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3b, must_have) | discovery | 9 years in growth with no split by title | Only matters if R1 and R2 change | Years as growth lead plus years as Head of Growth | Dated titles from your CV | `[grounded]` your background |
| G2 | SEO/content, brand/PR, partnerships/sales ops (R6, R7, R8, must_have) | discovery | Nothing either way | Only matters if R1 and R2 change | Any time owning organic, comms or B2B channels | Channel results, launches | `[grounded]` silence in your background |
| G3 | Solo execution (R9, important) | discovery | Recent roles were managerial | Only matters if R1 and R2 change | Early-stage or growth-lead years when you did the work yourself | Specific campaigns you built personally | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one" | One person is accountable for several functions that usually have separate owners, so depth in each is likely to be thin | `[inferred]` from the seven functions against "team of one"; `[generic]` that these usually have separate owners | When does headcount arrive, and which functions get hires first? | unresolved |
| RR2 | Base below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted base can't meet your floor, and equity can't make up a base shortfall | `[grounded]` posting figure against your constraint | Is there flexibility above the posted range for the base? | confirmed |
| RR3 | On-site mandate against your remote-only constraint (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Remote is ruled out in advance | `[grounded]` posting against your constraint | Is any fully remote arrangement possible for this role? | confirmed |
| RR4 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required … $70–85k base" | A board-facing role needing 8+ years of leadership, paid a base that looks junior for it. It's a risk signal, not a red flag, until a market band confirms it. | `[inferred]` from the posting's own terms; no market band established | How was the band set, and what are the equity terms (percentage, vesting, strike)? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work is framed as identity, not an exception | `[inferred]` from the wording | How often in the last quarter did "when it matters" happen? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | low | "success metrics will evolve as we learn" | You'd be accountable with no agreed definition of success. Rated low because early-stage roles often leave this open. | `[inferred]` from the wording; `[generic]` that early stages often leave it open | What would make the first 12 months a success for this role? | unresolved |
| RR7 | Budget and authority not stated | unknown | — | "Own all revenue growth end to end" | Ownership may come without a budget or decision rights to match | `[inferred]` from the posting's silence on budget | What growth budget comes with the role, and who signs off on spend? | unresolved |
| RR8 | Direct CEO reporting with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | You'd have real access and a seat near decisions | `[grounded]` posting | What does the board line involve in practice? | noted |
| RR9 | Profitable since founding (claimed) | positive_signal | — | "profitable since day one" | If true, there's less runway pressure. Not verified. | `[grounded]` posting claim | Can you share the revenue and margin trend? | noted |
| RR10 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | See R1, R2 | `[grounded]` the map | pending your approval |
| A2 | If you still want to make contact, ask the questions for RR2 and RR3 before you spend any other effort | They're the only answers that could reopen this | `[grounded]` the register | pending your approval |
| A3 | Filter future searches for a posted base of $150k+ and remote roles | Your two constraints decided this role on its own terms | `[grounded]` your stated constraints | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth", but the search was refused. It would have checked the organization row, the contradictions row and RR10. |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026", but the search was refused. It would have set the market calibration row and confirmed or cleared RR4. |
| 3. Hiring manager's public footprint | n/a | The posting gives no name, so there was no query to form |

I can save all of this as a `tuesday-dossier.md` if you want a record.

## Upgrade menu

- Allowing web search: targets 1 and 2 run, which checks whether Novaline exists as described (RR10) and gives a market band to test RR4 against. It wouldn't change the decision, because R1 and R2 fail on the posting's own terms.
- A deeper research pass on Novaline, covering funding, leadership churn, employee reports and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.
- A written answer from Novaline on base and remote (RR2, RR3): the only input that could reopen R1 and R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.