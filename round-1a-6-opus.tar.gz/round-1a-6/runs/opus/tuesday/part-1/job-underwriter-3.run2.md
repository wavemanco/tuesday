I'm running the job-underwriter check on this posting. Next I'll do a quick search to see whether Novaline can be found online and what this kind of role normally pays.
# Novaline, Head of Growth: job-underwriter check

## Decision snapshot

**No, this one isn't worth pursuing. R1 and R2 are both hard gates, and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 ($70–85k base), R2 (On-site in Austin 5 days a week)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (8+ years growth leadership), R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships and sales ops)
- `important`: adjacent: R10 (Team of one to start), R12 (E-commerce enablement context) · unclear: R11 (Dotted line to the board)

R1, R2: each fails on terms the posting states outright; R7, R8, R9: unresolved, and they don't matter while R1 and R2 fail.

**Opportunity ledger.** The posting conflicts with both of your stated terms (RR1, RR2). It also has four structural risk signals: seven functions bundled into one hire (RR3), no team or budget in sight (RR4), always-on hours stated as culture (RR5), and a board-facing mandate with no definition of success (RR6). Seniority against pay (RR7) and the employer (RR8) can't be checked from here, and the equity is unquantified (RR10). Two things run the other way: it claims profitability and gives you a direct line to the CEO (RR9).

- **Hard gates:** failed: R1 ($70–85k base), R2 (On-site in Austin 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the base would have to reach $150k or more (R1, RR1), *and* the role would have to become fully remote from Portland (R2, RR2). The posting rules out the second with "no exceptions." Otherwise you would have to revise a constraint you've called non-negotiable.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline: an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; not verified, because research didn't run (see Evidence status) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and resources | "A team of one to start." No budget, headcount plan or tooling is mentioned | `[grounded]` posting |
| Reporting | To the CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin, 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" (equity not quantified) | `[grounded]` posting |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | The title and the 8+ year bar describe a function leader. "Team of one" plus seven listed functions describes a hands-on generalist doing the work of several roles | `[inferred]` from the title and seniority bar set against the team-of-one line and the function list |
| Market calibration | Not established. The role-family sweep was refused, so the $70–85k figure isn't checked against a market band here (RR7) | none: no research ran |
| Unknowns | Growth budget; hiring plan and its timing; equity size and terms; how success will be judged; what the board line involves | — |
| Contradictions | "Head of" title and "8+ years growth leadership required" next to "players who don't need a bench" | `[inferred]` from the posting's own lines read together |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "$70–85k base" vs. your $150k base floor | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor, which is specific and your own. The posting's top figure is $85k, $65k under your floor | `[grounded]` posting figure and your stated constraint | Only the employer changing terms, or you revising the floor, resolves it |
| R2 | "On-site in our Austin office 5 days a week — no exceptions" vs. remote-only from Portland, no relocation | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The posting rules out the exception the gate would need | `[grounded]` posting and your stated constraint | None. The posting itself closes this |
| R3 | Own revenue growth end to end | must_have | direct | medium | none | You scaled a company from $8M to $40M ARR over three years with a budget you controlled. Specific, but self-reported with no inspectable proof yet | `[grounded]` your intake description | A board deck or growth dashboard would raise this to high |
| R4 | 8+ years growth leadership | must_have | unclear | medium | discovery | You have 9 years in growth and held Growth Lead and Head of Growth titles. How many of those years were in leadership roles isn't stated | `[grounded]` your intake description | See G1 |
| R5 | Paid acquisition | must_have | direct | medium | none | You owned paid at two companies, as stated | `[grounded]` your intake description | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and work deeply in Braze, as stated | `[grounded]` your intake description | none |
| R7 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention it either way | `[grounded]` intake silence | See G2 |
| R8 | Brand and PR | must_have | unclear | low | discovery | Your background doesn't mention it either way | `[grounded]` intake silence | See G3 |
| R9 | Partnerships and sales ops | must_have | unclear | low | discovery | Your background doesn't mention it. Your two companies were B2C subscription businesses | `[grounded]` intake silence | See G4 |
| R10 | "A team of one to start" (hands-on execution across functions) | important | adjacent | medium | transferability | Deep SQL, GA4 and Braze suggest hands-on capability. Your recent roles managed teams of 3–7, which is a different mode of working | `[inferred]` hands-on capability read from the tools you named | See G5 |
| R11 | "Dotted line to the board" | important | unclear | low | discovery | Your background doesn't mention reporting to a board | `[grounded]` intake silence | See G6 |
| R12 | E-commerce enablement context | important | adjacent | medium | transferability | Your growth work was at B2C subscription companies. Selling to merchants is a different buyer | `[inferred]` from the posting describing Novaline as e-commerce *enablement*, read as merchant-facing | See G7 |

## Gap recovery queue

These gaps only matter if R1 and R2 change. They're listed so the map is complete, not because they need work now.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 8+ years growth leadership (R4, must_have) | discovery | 9 years in growth; the years spent in lead roles aren't stated | A must-have tied to the title | Years as Growth Lead or Head of Growth; earlier roles where you owned a channel P&L | Title history with dates | `[grounded]` intake |
| G2 | SEO/content (R7, must_have) | discovery | Nothing either way | One of the seven listed functions | Content programs, organic acquisition, landing-page testing | A traffic or organic channel report | `[grounded]` intake silence |
| G3 | Brand and PR (R8, must_have) | discovery | Nothing either way | One of the seven listed functions | Launch campaigns, agency management, press coverage | A campaign brief or coverage list | `[grounded]` intake silence |
| G4 | Partnerships and sales ops (R9, must_have) | discovery | Nothing either way; B2C background | One of the seven listed functions | Affiliate or channel partnerships, CRM pipeline ownership | A partner program summary | `[grounded]` intake silence |
| G5 | Solo execution (R10, important) | transferability | Hands-on tools; managed teams recently | A team of one means doing the work yourself | Building campaigns yourself, writing your own SQL models | A dashboard or analysis you built yourself | `[inferred]` from the tools you named |
| G6 | Board-facing reporting (R11, important) | discovery | Nothing either way | Part of the reporting line | Presenting growth results to a board or investors | A sanitized board slide | `[grounded]` intake silence |
| G7 | E-commerce enablement context (R12, important) | transferability | B2C subscription only | Selling to merchants is a different motion from selling to subscribers | Any merchant-facing or B2B2C work | A case summary | `[inferred]` from the posting's company description |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The cash part of the role can't meet your floor, and equity is offered in place of the difference | `[grounded]` posting figure against your stated floor | Is the base band fixed, or is there room above $85k for this hire? | confirmed |
| RR2 | On-site only, conflicting with remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role can't be done from Portland | `[grounded]` posting and your stated constraint | Is there any remote arrangement for this role? | confirmed |
| RR3 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Seven functions sit with one person and no support staff | `[inferred]` from the function list against "team of one" | Which of these seven functions matter most in year one, and which can wait? | unresolved |
| RR4 | Responsibility without stated resources | risk_signal | medium | "Own all revenue growth end to end… a team of one to start" | You'd be accountable for all revenue with no stated budget or hiring plan | `[inferred]` from the mandate against the posting's silence on budget and headcount | What growth budget and hiring plan come with this role, and on what timeline? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work is described as part of the culture, not as an exception | `[grounded]` posting language | How often in the last quarter did "when it matters" apply? | unresolved |
| RR6 | No success metrics on a board-facing mandate | risk_signal | medium | "success metrics will evolve as we learn… dotted line to the board" | You could be judged by the board against targets nobody has defined yet | `[inferred]` from the open-ended metrics line set beside board reporting | What would the CEO and board need to see at 6 and 12 months to call this hire a success? | unresolved |
| RR7 | Seniority vs. pay, not checked against the market | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | The pay may sit below what this seniority and mandate usually command. Unconfirmed because the market search was refused | `[inferred]` from the seniority bar and scope against the stated base | How did you arrive at the base band for this role? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Profitability claim and a direct CEO line | positive_signal | — | "profitable since day one… Report to the CEO" | If accurate, the company has its own revenue and the role has a short line to decisions | `[grounded]` posting claims, not verified | How has growth been driven to date, and by whom? | noted |
| RR10 | Equity not quantified | unknown | — | "meaningful equity upside" | The equity's size, vesting and type are unknown | `[grounded]` posting language | What percentage or share count, what vesting terms, and at what valuation? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting | See R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If Novaline contacts you directly, ask the RR1 and RR2 questions before anything else | Those answers are the only things that could reopen it | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2 claims (your stated pay floor and remote-only constraint). Unverified leads: everything else in your intake description, which is self-reported until it's probed. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin"; the search was refused because web search isn't permitted in this session. It would have checked the role reality organization row and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026"; refused the same way. It would have set the market calibration row and settled RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can save this assessment as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- Allow web search → targets 1 and 2 run: RR8 is confirmed or cleared, and RR7 gets checked against a real market band. Neither changes the `no_go`.
- A deeper research pass on Novaline (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds the register. Say the word and it runs.
- A growth dashboard, board deck or ARR chart from your $8M→$40M run → raises R3 to `high`, useful for your next application.
- The hiring manager's name → would show what kind of reader you'd be pitching to.
- Answers to G1–G7 → only worth giving if R1 or R2 ever changes.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.