Next I'll read the reference files the playbook requires.
Now the worked report for structure.
**No, you're not wasting your time, but R1b ("3+ years product management", marked must-have) is a real screening risk. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (Product-management-type work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1b (3+ years titled PM experience)
- `important`: direct: R6 · adjacent: R7 (Write specs and drive delivery with two squads), R9 (Own the platform roadmap), R10 (Coordinate launches with sales and support) · unclear: R8 (Define and track adoption metrics)

R1b: you have no PM title, and better wording won't fix that, only reaching a person who reads past it; R2, R9: credible bridges, but you implemented and fed the product rather than owned it; R8: your answer to G1 could close it.

**Opportunity ledger.** On paper the role is properly resourced (RR4). But I couldn't verify that the employer or the posting exists (RR1). Pay, decision rights and how strictly the must-have is screened are all unstated (RR2, RR3, RR5).

- **Hard gates:** none stated; you haven't given me your constraints, so I couldn't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Quartzline's own site (RR1); (2) you reach the hiring manager or get a referral instead of relying on a cold application, because R1b is the row a literal screen catches (A1, RR5); (3) R2 and R9 are presented honestly as implementation-side work, never as having shipped or owned an API product.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked against the company's site (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Resources | Two engineering squads | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A platform PM role facing partners. The daily work is integration partners, API docs and schemas, the same ground as your last 7 years. The new parts are roadmap ownership and adoption metrics | `[inferred]` from the JD's responsibilities set against your resume |
| Market calibration | Not available: the role-family search was refused (see Evidence status). I have no market band for title, scope or pay | — |
| Unknowns | Pay; reporting line; who has the final say on the roadmap; whether the must-have is screened literally | — |
| Contradictions | None inside the JD; the company's own site wasn't checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product-management-type work (requirements, client feedback fed to product, cross-team coordination) | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions, requirements documents and coordination with PMs on custom builds are real product-side work. Limit: you supplied input to product decisions; nothing yet shows you made them. Medium is the ceiling for unprobed resume text | `[grounded]` resume | See G1, G4 |
| R1b | 3+ years titled PM experience | must_have | absent | none | capability | You told me you've never held a PM title, so this needs no question. It's a length-of-experience requirement, not a gate, but it's the line a literal screen catches | `[grounded]` your statement; `[inferred]` that it is screened literally | Carry as material risk; A1 is the closure path |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ end-to-end client integrations of your company's REST APIs. Limit: that was implementation of someone else's product, not shipping the API product itself. `[generic]` Implementation and solutions-engineering backgrounds are a recognized route into platform PM roles | `[grounded]` resume; `[generic]` route pattern | G4; W1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, and integration architecture across 30+ integrations. Specific, but nothing to inspect yet | `[grounded]` resume | Optional: a sanitized integration architecture doc would raise this to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and product managers on custom builds | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your resume doesn't mention sales. `[generic]` Solutions engineers usually work closely with sales, so the evidence probably exists but isn't on the page | `[grounded]` resume silence; `[generic]` role pattern | G2 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | Your resume says nothing about delivery method | `[grounded]` resume silence | G3 |
| R6 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly roadmap-input sessions with clients are this activity. The resume frames them as client service, not as product input | `[grounded]` resume | E1 |
| R7 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: coordinating a project is not the same as setting priorities for a team that runs continuously | `[grounded]` resume | W1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing on the resume. A note from an earlier conversation suggests you built an internal request-triage tool that support agents adopted. That is unconfirmed, so it's a lead for a question, not evidence | `[grounded]` resume silence; lead from earlier conversation | G1 |
| R9 | Own the platform roadmap | important | adjacent | medium | transferability | You fed client input into the roadmap; nothing yet shows you owned the roadmap. The playbook the whole team uses shows something you owned and others adopted, but it's an internal process document, not a product roadmap | `[grounded]` resume | G4; W1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You took 30+ client integrations to go-live. Those were per-client launches, not product launches across sales and support | `[grounded]` resume | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics and owned product work (R8, R1a) | discovery | An unconfirmed lead about a triage tool support agents adopted; nothing on the resume | It's the only possible evidence of building something, getting people to use it, and measuring the result, which is what R8 and the PM-experience row test | The triage tool; usage or adoption numbers you tracked for the playbook; SQL queries you ran to measure integration health or API usage | A screenshot, usage numbers, a short write-up, or the tool's documentation | `[grounded]` resume silence; `[inferred]` that it bears on R1a |
| G2 | Sales collaboration and launches (R4b, R10) | discovery | Your resume doesn't mention sales | R4b is a must-have that is currently unclear | Pre-sales scoping with account executives; handing go-lives over to support; release notes or enablement material you wrote | A deck, an enablement document, a go-live runbook | `[grounded]` resume silence |
| G3 | Agile delivery (R5) | discovery | Your resume doesn't mention delivery method | A must-have, though answering it changes the decision less than G1 does | Sprint ceremonies on custom builds; a backlog you groomed with engineers; Jira epics you wrote | A sanitized ticket or epic | `[grounded]` resume silence |
| G4 | From implementing to owning (R2, R9) | transferability | Deep API implementation experience; no product ownership | The bridge is credible. Its limit is likely to be what an interviewer pushes on | Times you changed what got built: custom builds that became standard features, or roadmap input that shipped | W1, or a feature you can trace back to your input | `[grounded]` resume; `[generic]` that interviews probe this limit |
| G5 | Titled years (R1b) | capability | You confirmed there are none | Wording can't close it | Closing it means a referral or a direct line to the hiring manager, or an internal move to a PM title at your current employer | — | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from sources I could check | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; the search was refused rather than returning nothing | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (the posting gives no figure) | The figure may or may not fit your floor; I have no market band to compare it with | `[inferred]` from the posting not giving a figure | What salary range is budgeted for this role? | unresolved |
| RR3 | Roadmap authority not defined | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership may be shared with an engineering or product lead whose role the JD doesn't state | `[inferred]` from the ownership language and the posting saying nothing about who the role reports to | Who does this role report to, and which roadmap decisions does it make on its own? | unresolved |
| RR4 | Resources named | positive_signal | — | "drive delivery with two engineering squads" | The mandate comes with real engineering capacity | `[grounded]` JD | How are the two squads split between platform work and partner requests? | noted |
| RR5 | How strictly the must-have is screened | unknown | — | "3+ years product management experience (must-have)" | It may be screened literally, or the hiring manager may weigh adjacent experience | `[inferred]` from the explicit "(must-have)" label | Would you consider product experience gained in solutions engineering, such as roadmap input and integration requirements? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Contact the hiring manager directly or get a referral before applying, instead of applying cold | see R1b, RR5 | `[inferred]` from the explicit must-have label | pending your approval |
| E1 | Move the "quarterly roadmap-input sessions" and "integration playbook the whole team uses" bullets to the top, worded exactly as you wrote them. Don't borrow the JD's "discovery" or "roadmap ownership" for your own history | see R6, R1a | `[grounded]` resume | resume_edits_pending_approval |
| W1 | A one-page spec or teardown for a partner-facing logistics API capability, to show product thinking rather than claim it | see R2, R7, R9 | `[grounded]` the limits in R2, R7 and R9 | pending your approval |
| Q1 | Ask the RR1–RR5 verification questions word for word on the first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

When you want the resume rewritten line by line, resume-tailor does that.

## Evidence status

Verified: none yet. Unverified leads: the request-triage tool support agents adopted, from an earlier conversation. It's unconfirmed and asked about in G1.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform company" and "Quartzline careers Product Manager Platform APIs". Web search permission was refused for both. These would have checked RR1 and the Organization and Contradictions rows in Role reality |
| 2. Role-family sweep | unavailable | Searched "platform API product manager Series B salary range 3 years experience 2026". Refused. This would have given the market calibration row and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

Want me to save this as `tuesday-dossier.md` so later steps can build on it?

**Upgrade menu**
- Allowing web search lets me rerun L1: RR1 could close, and Role reality would get a market band. On top of that, a deeper pass (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) is available if you say so.
- Your constraints (pay floor, location, remote or on-site) let me check the role against your hard constraints, which currently can't be checked.
- The hiring manager's name helps me pick which story you lead with in A1.
- A sanitized integration architecture doc would raise R3 to `high`.
- Answers to G1–G3 could move R8, R4b and R5.

G1: Tell me about the request-triage tool support agents adopted. Did you build it, and how many agents used it? Did you track usage in any way?

G2: Where did you work with sales, for example scoping deals before signature or handing go-lives over?

Constraints: What's your pay floor, and any location or remote requirements?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.