Several reference files are needed. Let me read them.
Yes, apply, but first find out whether the job is really remote. Brindlemoor's own careers page says "Leeds office four days a week", while your JD says "Fully remote (UK)". Your skills match almost every requirement, and never having managed anyone doesn't count against you, because the JD doesn't ask for it.

## Decision snapshot

**Yes, go for it, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK) working pattern)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R9 (Own pricing analytics for our pet-insurance product) · unclear: R10 (Turn results into recommendations for … product)
- `preferred`: direct: R8

R9: a credible bridge from motor pricing, with its limit named. R10: your background shows underwriting as an audience but not product yet. R2 to R7 (`medium`): each one is confirmed only by your own account so far. Expect them to be tested in interview.

**Opportunity ledger.** The employer and the live posting check out, and the hiring manager publishes on exactly the monitoring work this role does (RR3). Two things are open: the posting and the careers page disagree on where you'd work (RR1), and the salary isn't stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working pattern); candidate constraints not given, so they haven't been checked against the role.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern turns out to be one you can do: fully remote as the JD says, or Leeds four days a week as the careers page says (R1, RR1). (2) Pet insurance is framed honestly as a bridge from motor, never as pet-pricing experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Its careers page lists this role as "Accepting applications" | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page; your message |
| Line management | The JD names none. Nothing in the posting asks for people management | `[grounded]` JD silence |
| Scope read | An individual-contributor senior post that owns one product's pricing end to end | `[inferred]` from the mandate against the JD's silence on reports |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. The JD doesn't state a salary, so this band is what to expect, not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (n=612), snippet; `[grounded]` JD, for the missing salary |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Salary; working pattern; who in product takes the recommendations; whether "senior" includes mentoring | — |
| Contradictions | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` JD against the fetched careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint, so there's nothing to grade yet. The role's own terms contradict each other: remote in the JD, Leeds four days a week on the careers page | `[grounded]` JD against the careers page | G3's question; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Self-reported and not yet probed | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily. Self-reported; a technical exercise is a common way to test this | `[grounded]` your background; `[generic]` that pricing loops often test this hands-on | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Same model as R4, and "maintained" covers the monitoring side. Responsibility tiered `must_have` because it is the role's core | `[grounded]` your background; `[inferred]` tiering from the mandate | none |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team. Your share of design versus readout isn't stated yet | `[grounded]` your background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R9 | Own pricing analytics for our pet-insurance product | important | adjacent | medium | transferability | What carries over: GLM rating, price testing and underwriting-facing work all apply directly. The limit: no exposure to pet rating factors (breed, animal age) or vet-cost claims dynamics | `[grounded]` your background, and you say you've never worked on pet; `[generic]` that pet rating rests on different factors from motor | see G1 |
| R10 | Turn results into recommendations for … product | important | unclear | low | discovery | Your stated audience is underwriting. A product team as the receiver of your recommendations isn't mentioned either way | `[grounded]` your background is silent on product | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor pricing only; no pet or other personal lines | It's the most obvious difference between you and someone already in pet insurance. A stronger bridge narrows it | Pricing a small or thin-data segment, as a young-driver book may be; handling claims inflation in repair or medical costs; any home, travel or other non-motor work | A sanitized model-monitoring pack, a factor-review note | `[grounded]` your background; `[generic]` that domain switch is the likeliest probe |
| G2 | Recommendations to product (R10, important) | discovery | Underwriting is your audience; product isn't mentioned | The JD names product as a second audience | Price-test results that changed a product feature, excess option, cover tier or customer journey; working with a product or proposition manager | A test readout deck, a recommendation memo | `[grounded]` your background is silent |
| G3 | Working pattern (R1, hard_gate) | hard_gate | No constraint stated; the employer's two sources disagree | If the role is really four days in Leeds and you can't do that, the decision flips to `no_go` | — | — | `[grounded]` JD against the careers page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts between posting and careers page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be out of date, or the pattern may have changed after posting | `[grounded]` both sources; `[generic]` that stale copies are a common cause | Is this role fully remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in the JD) | The budget may sit anywhere in or outside the market band in role reality | `[inferred]` from the missing figure, against the `[generic]` band | What base salary is budgeted for this post? | unresolved |
| RR3 | Employer and role verify; the hiring manager publishes on this work | positive_signal | — | "Accepting applications"; her 2025 talk "Small Books, Loud Errors", on monitoring rating models in small books | The live posting matches the JD's mandate, and the manager is a pricing specialist who will judge the technical work closely | `[grounded]` careers page fetched; public profile snippet | How is model monitoring set up on the pet book today, and what would you want changed first? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with building and maintaining the young-driver GLM, giving the monitoring side equal weight | See R4 and R5. Odile Varga's published talk is about monitoring rating models | `[grounded]` your background; her public profile | pending your approval |
| P2 | Describe the tests as "14 price tests last year with the underwriting team", keeping the number attached to the tests | See R6 | `[grounded]` your background | pending your approval |
| P3 | Frame pet insurance plainly: "My pricing is motor. The GLM and testing methods carry over; pet's rating factors are what I'd learn first." | See R9. It's honest about the limit | `[grounded]` your background | pending your approval |
| P4 | Settle RR1 with the recruiter before you spend effort on the application | See R1 and RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the RR1, RR2 and RR3 questions word for word during the interviews | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality's organization and contradictions rows; RR1; RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM remote 2026", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). RR3; P1 |

I can save all of this as a `tuesday-dossier.md` whenever you want it.

**Upgrade menu**
- Your answer on working pattern, plus any other non-negotiables such as a salary floor: settles R1, and the decision becomes `go` or `no_go`.
- A sanitized model-monitoring pack, factor-review note or price-test readout deck: raises R4 to R6 from `medium` to `high` and strengthens G1.
- The budgeted salary: closes RR2 and lets me compare it with the band in role reality.
- A deeper research pass on Brindlemoor (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G3: Could you work from Leeds four days a week, or is fully remote a must for you?

G2: Have any of your price-test results gone to a product or proposition team and changed a product feature, excess option or cover tier? What was your part?

G1: Have you priced anything outside motor, or a small, thin-data segment where you had to watch the model closely?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.