I'm working through the underwriting playbook's reference files before writing your assessment.
**Yes, it's worth applying to. You need to confirm one thing first: that you can work from the US or the Denver office (R9). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or our Denver office)
- `must_have`: direct: R1, R2, R3, R4a, R5, R6
- `important`: adjacent: R4b (a dbt-modelled warehouse in BigQuery) · unclear: R7 (the data contracts our analysts depend on), R8 (ingestion from our app and CRM)

R4b: a credible bridge from Snowflake, with its limit named; R7, R8: not yet established either way, which is different from missing.

**Opportunity ledger.** The posting is open and fairly priced. The pay is stated and its midpoint sits above the report's median (RR1). The scope matches the title's norm (RR4). The live posting matches what you pasted (RR5). Two things are still open: what the equity is (RR2) and who you'd report to (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work US-remote or from Denver (R9); (2) you present BigQuery honestly as a skill you don't have yet, never as experience (R4b, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted (not fetched) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts rely on | `[grounded]` JD |
| Scope read | One domain (reporting) owned end to end, with no direct reports mentioned | `[inferred]` from the JD's mandate and its silence on managing people |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Market calibration | "Senior" usually means 5–8 years and owning one domain's pipelines with no reports, so the title, seniority and scope here are typical. The report's base median is $151,000 (IQR $139,000–$163,500). This posting's $148,000–$166,000 starts above the 25th percentile, has its midpoint ($157,000) above the median, and tops out above the 75th percentile (RR1). | `[generic]` Datawright 2026 report you pasted (US, n=2,310, Series B–D); `[grounded]` JD for the posted range |
| Unknowns | Equity terms; reporting line; data-team size; which CRM; on-call expectations | — |
| Contradictions | None. The live careers page matches the JD you pasted word for word. | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, stated in prose. That is self-report, so it can't go above `medium` on a first pass | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", stated and plausible; nothing to inspect yet | `[grounded]` your background | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Specific, but nothing to inspect yet: expect a probe on model design and testing | `[grounded]` your background | Optional: a sanitized lineage graph or dbt docs screenshot would raise this to `high` |
| R4a | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the requirements list words it | `[grounded]` JD and your background | none |
| R4b | BigQuery specifically | important | adjacent | medium | transferability | You state you've never used BigQuery, so the bridge is Snowflake plus dbt. `[generic]` What doesn't carry over: BigQuery's own cost model, partitioning and clustering conventions, and GCP permissions | `[grounded]` your own statement; `[generic]` platform differences | See G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is stated by name | `[grounded]` your background | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is direct ownership, stated | `[grounded]` your background | Optional: a sanitized expectation suite or data-docs page would raise this to `high` |
| R7 | Data contracts analysts depend on | important | unclear | low | discovery | The GE suite is close to this but isn't the same thing. Whether you've agreed schemas or SLAs with data producers or consumers isn't stated | `[grounded]` your background is silent on contracts | See G2 |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background names modelling, orchestration and testing, but not which sources you ingested or how | `[grounded]` your background is silent on ingestion | See G3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you'd work from. Confidence grades your statement of this, and there is none yet | `[grounded]` JD; nothing from you yet | R9 question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4b, important) | transferability | dbt on Snowflake at about 180 models; no BigQuery | It's the platform you'd work in from day one; an honest bridge holds up better under questioning than vague claims of being warehouse-agnostic | Any GCP work at all; adapting dbt models or macros across adapters; tuning warehouse cost or performance on Snowflake | A small public repo running a few dbt models on BigQuery's free tier (W1) | `[grounded]` your statement; `[generic]` that interviews probe platform specifics |
| G2 | Data contracts (R7, important) | discovery | GE suite set up; contracts not mentioned | Contracts are one of the three things the JD lists, and they decide whether R7 is a bridge or a direct match | Schema checks that block a broken upstream change; agreements with app engineers on event formats; freshness or SLA commitments to analysts; dbt model contracts or versioned models | A contract YAML, an SLA document, an incident write-up | `[grounded]` JD lists contracts; `[inferred]` that this moves R7 |
| G3 | App and CRM ingestion (R8, important) | discovery | No ingestion sources named | Ingestion is the first item in the mandate | Loading product-database or event data; pulling from a CRM (Salesforce, HubSpot) via Fivetran, Airbyte or custom Python; incremental loads, backfills | A DAG or connector config, sanitized | `[grounded]` JD mandate order |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, midpoint above the report's median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posted range starts above the report's 25th percentile and tops out above its 75th percentile | `[grounded]` JD; `[generic]` report band | Where in the range do you expect to place someone with six years of experience? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | You can't value the equity from the posting alone | `[inferred]` from equity being named without terms | What form does the equity take (options or RSUs), how large is the grant, and what is the vesting schedule? | unresolved |
| RR3 | Reporting line and team size unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Build and run" could mean you'd be the only data engineer carrying both build work and operations | `[inferred]` from the JD's silence on team and manager | Who does this role report to, and how many data engineers are on the team today? | unresolved |
| RR4 | Scope matches the title's norm | positive_signal | — | "Senior Data Engineer… the pipelines behind our tutoring platform's reporting" | One domain with no reports is the typical scope for this title | `[generic]` report; `[grounded]` JD | Does this role own reporting end to end, or share pipelines with other teams? | noted |
| RR5 | Posting live and consistent | positive_signal | — | "Accepting applications." | The role is actively open | `[grounded]` careers page fetched | What's the hiring timeline for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with what you built, in your own words: "built our dbt project on Snowflake — about 180 models", Airflow orchestration, and "set up our Great Expectations test suite" | See R3, R5, R6 | `[grounded]` your background | pending your approval |
| A2 | Say plainly that you haven't used BigQuery; present Snowflake as the warehouse you've run dbt on, with no "warehouse-agnostic" claim | See R4b, G1 | `[grounded]` your own statement | pending your approval |
| W1 | Optional: port a handful of dbt models to BigQuery's free tier in a public repo before the technical round | Narrows R4b's limit with something an interviewer can inspect | `[inferred]` closure path for G1 | pending your approval |
| Q1 | Ask the questions from RR1–RR5 verbatim in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Senior Data Engineer careers"; fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It checked the pasted JD: the page is accepting applications and matches word for word (role reality's contradictions row, RR5). I didn't fetch the about page, so the company facts rest on your paste |
| 2. Role-family sweep | skipped | The Datawright report you pasted already gives the band, the seniority norm and the typical scope that market calibration and RR1 use |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

If it's useful later, I can save this assessment as a `tuesday-dossier.md` file that the resume and interview modules can pick up.

**Upgrade menu**

- Your constraints (where you'd work from, your pay floor, your US work authorization): R9 closes, and RR1 gets checked against your floor.
- A sanitized dbt lineage graph, docs site, or GE data-docs page: R3 and R6 rise to `high`.
- Answers to G2 and G3: R7 and R8 resolve, either to direct matches or to named bridges.
- The hiring manager's name: target 3 runs, and the plan can pick which story to lead with for that reader.
- A deeper pass on Pellucid Learning (funding and leadership changes, hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

R9: Can you work for a US-based employer remotely from the US, or from the Denver office?

G2: Have you set up agreements with the people who send or use the data, such as schema checks that block a breaking upstream change, event-format agreements with app engineers, or freshness commitments to analysts? What was yours?

G3: Which sources did you ingest at the payroll company (app databases, events, a CRM, other SaaS tools), and what did you use to load them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.