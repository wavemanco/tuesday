Now the reference files named for Step 1.
**Yes, it's worth applying to, provided the two conditions below hold. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery) · unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R8: a credible bridge from Snowflake, with its limit named; R9, R10: not yet established from what you've shared; R2–R7 (`medium`): stated and specific, but not yet backed by anything I can inspect.

**Opportunity ledger.** The posting is live and matches what you pasted (RR2). The base range sits at and above the market middle (RR1). Still unknown: team size and reporting line (RR3), the equity terms (RR4), and what "run" means for on-call (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remotely from the US or from Denver (R1); (2) the $148k–$166k base and the equity terms clear your own floor (RR1, RR4), which you haven't told me; (3) you present BigQuery honestly as a gap that Snowflake bridges, never as experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` the about-page text you pasted |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar", data quality testing | `[grounded]` JD |
| Scope read | Reporting pipelines end to end, from ingestion to contracts. Reads as one domain, not the whole data platform, but the JD doesn't say how big the team is | `[inferred]` from the JD's single "reporting" framing against its silence on team size |
| Market calibration | Senior DE at Series B–D: 5–8 years, owns one domain's pipelines, no direct reports. Base median $151,000, IQR $139,000–$163,500 | `[generic]` Datawright 2026 report (n=2,310), as pasted and found by search |
| Compensation | $148,000–$166,000 plus equity: the floor is below the market median, the midpoint above it, and the top above the IQR's upper end (RR1) | `[grounded]` JD; `[generic]` band |
| Unknowns | Hiring manager and reporting line; team size; equity terms; on-call duties | — |
| Contradictions | None. The live careers page matches the pasted JD | `[grounded]` search result for the careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US. The term itself is clear | `[grounded]` JD; your background is silent on it | Closing question for G4 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated, inside the report's 5–8 "Senior" range. Specific but uninspected | `[grounded]` your background; `[generic]` the range | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific about frequency. Depth is only shown by examples | `[grounded]` your background | none |
| R4 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Specific ownership, nothing inspected yet | `[grounded]` your background | A sanitized model DAG or repo excerpt would raise this to high |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the JD's wording is met as written. BigQuery is a separate row, R8 | `[grounded]` JD wording and your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated directly. Your scope (authoring DAGs vs. running the deployment) isn't stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite: specific ownership | `[grounded]` your background | A sanitized suite excerpt would raise this to high |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt carries over; the modelling patterns carry over. Limit: you've never used BigQuery's cost model, partitioning/clustering or dbt-bigquery adapter quirks. `[generic]` Warehouse-to-warehouse moves are commonly treated as ramp-up rather than a disqualifier for a senior hire, but some screens read the stack literally | `[grounded]` "Never used BigQuery"; `[inferred]` requirement from the JD's mandate line; `[generic]` screening pattern | See G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Your background lists modelling, orchestration and testing but no ingestion sources. Payroll work points to source integration, but you haven't said so | `[grounded]` your background is silent; `[inferred]` from the payroll-domain context | Closing question for G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The GE suite is close to this, but a contract with downstream consumers is a different thing and isn't stated | `[grounded]` your background; `[inferred]` adjacency to GE | Closing question for G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Deep dbt on Snowflake; no BigQuery | Likely the first technical objection; a bridge with its limit named holds up better than silence | A small public dbt + BigQuery project (free tier) showing partitioning and incremental models | A repo link | `[grounded]` your background; `[generic]` that this is the likeliest objection |
| G2 | Ingestion (R9, important) | discovery | No ingestion sources named | A third of the mandate | Pulling from a product database (CDC, replicas), a CRM such as Salesforce or HubSpot, Fivetran/Airbyte connectors, or custom Python extractors | A pipeline diagram or a sanitized DAG | `[grounded]` background silent; `[inferred]` share of mandate from the JD's three-part list |
| G3 | Data contracts (R10, important) | discovery | GE suite stated; no contract with consumers | It's named in the JD as what analysts depend on | Schema agreements with analysts, enforced dbt model contracts, alerting when an upstream change breaks a downstream model, SLAs on freshness | A contract YAML, a README, an incident write-up | `[grounded]` JD and background |
| G4 | Location / work authorization (R1, hard_gate) | hard_gate | Not stated | It's the only term that could rule this out | — | — | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay at or above the market middle | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range's midpoint ($157k) is above the $151k median and its top is above the IQR's upper end | `[grounded]` JD; `[generic]` Datawright band | Where in the range do you expect to land someone with 6 years and no BigQuery? | noted |
| RR2 | Posting live and consistent | positive_signal | — | "Accepting applications" | The role is open as described | `[grounded]` careers-page search result | — | noted |
| RR3 | Hiring manager, team size and reporting line unstated | unknown | — | (no hiring manager named) | You could be the sole data engineer with platform-wide scope, which is wider than the one-domain norm | `[generic]` role-family scope pattern | How many data engineers are on the team, and who does this role report to? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Its value can't be judged without type, size and vesting | `[inferred]` from the bare phrase | What is the equity grant: options or RSUs, how many, at what strike, and on what vesting schedule? | unresolved |
| RR5 | "Run" scope undefined | unknown | — | "Build and run the pipelines" | The role may carry on-call for reporting that schools rely on | `[inferred]` from "run" against the JD's silence on support | What does on-call look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your own words: "Built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite" | R4, R7 are your strongest direct matches | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Say "Snowflake, not yet BigQuery" plainly in the application. Don't use "cloud warehouse" to blur the two | R8; the honest bridge holds up better under a probe | `[grounded]` your background | pending your approval |
| W1 | Optional: a small dbt + BigQuery repo before interviews | Shrinks G1's limit | `[generic]` work samples narrow stack gaps | pending your approval |
| Q1 | Ask the verification questions for RR1, RR3, RR4 and RR5 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers"; got "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It checks the pasted JD: the role is live and the wording matches. Moved role reality's contradictions row and RR2 |
| 2. Role-family sweep | yes | Quick check on the pasted survey. Searched "Datawright 2026 Data Engineering Pay Report"; got "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report), whose figures match yours. Moved market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name given. The upgrade menu says what a name would unlock |

---

I can package all of this as a `tuesday-dossier.md` for later steps if that's useful.

**Upgrade menu**
- **Your base floor and how much the equity matters to you:** settles condition (2) against RR1 and RR4.
- **Your current resume:** checks whether R2–R7 come through on paper or have presentation gaps.
- **A sanitized dbt DAG or Great Expectations suite excerpt:** raises R4 and R7 to `high`.
- **The hiring manager's name:** a scope read for RR3, and which story to lead with.
- **A deeper research pass on Pellucid Learning** (leadership churn, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G4: Are you based in the US, and able to work there, either remotely or from Denver?

G3: Have you set up an agreement with analysts or other downstream users about a table's schema, freshness or breaking changes, such as dbt model contracts or alerts? What was your part in it?

G2: What sources did your pipelines pull from at the payroll company (product database, CRM, third-party APIs), and did you build or run that ingestion yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.