Let me read the required references.
# Harborlight Health — Senior Product Analyst

## Decision snapshot

**Yes, apply. Your experience covers R1, R2, R3, R4 and R5 directly. The one condition is that the posting checks out (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R7 (Define and maintain the metrics layer)
- `important`: direct: R8a · adjacent: R8b (Partner with clinicians) · unclear: R9 (Mentor two junior analysts)
- `preferred`: adjacent: R6 (Healthcare data experience (HIPAA))

R6: a real bridge from your GDPR/CCPA and consent-state work, with its limit named. R7: one answer about who owned the Looker model could close it. R9: your background doesn't mention mentoring.

**Opportunity ledger.** The role itself reads well: the mandate, tools and team are named (RR4). But I couldn't confirm the employer (RR1), and pay and location aren't stated (RR2, RR5). Whether "mentor" means managing people is also open (RR3).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting checks out on Harborlight's own careers page (RR1).
  2. You present R6 as adjacent privacy work, never as HIPAA experience.
  3. Pay and location are acceptable to you (RR2, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: a digital-health scale-up, about 400 people, Series C | `[grounded]` JD header only; not checked independently (RR1) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual contributor who owns a product's analytics and has two juniors to mentor. That is ordinary for the title; it is not a head-of-analytics remit | `[inferred]` from "mentor two junior analysts" against the title |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD is silent |
| Market calibration | Not run: the role-family search was refused | — |
| Unknowns | Pay, location or remote policy, whether mentoring includes formal reporting lines, user base size (which sets how much testing is possible) | — |
| Contradictions | None in the JD as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years of product analytics, stated and specific. Nothing to inspect yet, so `medium` | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake. Expect a live SQL exercise to test "expert" | `[grounded]` your background; `[generic]` that this role family tests SQL live | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program at 30+ tests a year, including the pricing test behind an 11% retention lift. Care-navigation apps often have smaller user bases and outcome-based success measures, so "at scale" there may mean different design choices | `[grounded]` your background; `[generic]` that digital-health apps differ in sample size and success measures | none; see the application plan, E1 |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | a sanitized memo excerpt would raise this to `high` |
| R6 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | What carries over: GDPR/CCPA consumer PII, and you built the warehouse's consent-state model. The limit: none of that touched PHI, BAAs, HIPAA's minimum-necessary rule, or HIPAA de-identification methods | `[grounded]` your background, including "never worked in healthcare"; `[generic]` the HIPAA concepts named as the limit | see G3 |
| R7 | Define and maintain the metrics layer | must_have | unclear | medium | discovery | Building a Looker instance with governed dashboards suggests a modeled metrics layer. But you didn't say whether you owned the metric definitions and the LookML model or someone else did | `[inferred]` from "built from scratch" plus "governed" | ask G1 |
| R8a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | You present to the VP Product monthly, and the pricing test led to a retention result | `[grounded]` your background | none |
| R8b | Partner with clinicians | important | adjacent | medium | transferability | What carries over: translating analysis for non-technical execs. The limit: no clinical stakeholders, so no work with clinical-safety or care-outcome framing | `[grounded]` your background; `[generic]` that clinicians judge by care outcomes | see G4 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Your background is silent on mentoring or managing anyone | `[grounded]` silence in your background | ask G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R7, must_have) | discovery | A Looker instance and 40+ governed dashboards; whether you owned the metric definitions isn't established | It's the only `must_have` row not at `direct` | Writing the LookML views and explores; setting the canonical definition of retention or active subscriber; running metric change control or a definitions doc | A sanitized LookML snippet, a metric-definitions doc, a governance page | `[grounded]` what you said; `[inferred]` that closing it strengthens the decision |
| G2 | Mentoring (R9, important) | discovery | Nothing either way | The JD names two juniors explicitly | Onboarding a new analyst; reviewing others' SQL or test designs; running analytics office hours; being someone's go-to reviewer | A peer review mention, or an onboarding guide you wrote | `[grounded]` silence in your background |
| G3 | HIPAA (R6, preferred) | transferability | Consumer-PII compliance work and a consent-state model | It's the one healthcare-specific line in the JD, so expect questions on it | Your consent-state model; PII masking or access tiers in Snowflake; handling deletion requests | A sanitized diagram of the consent model | `[grounded]` your background; `[generic]` that domain gaps draw questions |
| G4 | Clinician partnership (R8b, important) | transferability | Exec and VP Product audiences, no clinicians | Roadmap decisions here involve clinicians | Any test where you had to explain a result to a skeptical, non-analytical expert | The memo excerpt from R5 | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for unverified postings, not a claim about this one; verification searches were refused here | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | (nothing on pay in the JD) | The figure may or may not meet your floor; no market band could be pulled | `[grounded]` JD is silent | What's the budgeted range for this role, including equity? | unresolved |
| RR3 | "Mentor" with no stated reporting line | unknown | — | "mentor two junior analysts" | It could be informal mentoring or formal people management; that changes the job and possibly the level | `[inferred]` from the wording against the JD's silence on reports | Will the two analysts report to this role, and how much of the week goes to their work? | unresolved |
| RR4 | Concrete mandate, tools and team | positive_signal | — | "define and maintain the metrics layer… Looker… mentor two junior analysts" | The scope is well defined and resourced | `[grounded]` JD | What would success look like in the first six months? | noted |
| RR5 | Location and remote policy unstated | unknown | — | (nothing in the JD) | It could conflict with constraints you haven't told me yet | `[grounded]` JD is silent | Is this role remote, hybrid or on-site, and where? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find this role on Harborlight's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift | see R3; it's your strongest `must_have` evidence | `[grounded]` your own words | pending your approval |
| E2 | Second, the Looker instance you built from scratch with 40+ governed dashboards. Add "metrics layer" wording only if G1 confirms you owned the definitions | see R4, R7 | `[grounded]` your own words | pending your approval |
| E3 | Describe privacy work exactly as "handled GDPR/CCPA consumer PII; built the consent-state model for our warehouse." Never "HIPAA" or "health data" | see R6 | `[grounded]` your own words | pending your approval |
| Q1 | Ask the verification questions in RR1, RR2, RR3 and RR5 in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app"; the call was refused (search permission not granted). It would have confirmed the company and the live posting, which would close RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Product Analyst digital health salary scope"; refused. It would have set the market band for RR2 and the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

If useful, I can save this as a `tuesday-dossier.md` for later steps.

## Upgrade menu

- **A link to the live posting on Harborlight's site, or search permission:** RR1 can close, which would lift the status toward `go`. The market band for RR2 also gets filled.
- **Your pay floor, location and remote needs:** the hard-gates line is checked against you, not just the JD.
- **A sanitized LookML snippet or metric-definitions doc:** closes R7.
- **A sanitized memo excerpt or an experiment readout:** R5 or R3 rise to `high`.
- **The hiring manager's name:** sharpens the scope read and which story to lead with.
- **Deeper research on Harborlight** (funding, leadership changes, employee reports; up to 5 more searches and 2 more fetches; needs search permission): say the word and it runs.

## Questions

**G1:** On the Looker build, did you personally write the LookML model and set the metric definitions (for example, what counted as retained), or did someone else own them?

**G2:** Have you onboarded, reviewed the work of, or regularly coached another analyst, even informally?

**Constraints:** What's your pay floor, and do you need remote, hybrid or a specific location?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.