Now the referenced files for Step 1.
Now the worked report and interaction grammar.
**No, it isn't worth pursuing, and you're right that something is off. Status: `no_go`.** Two of your hard gates fail: R1 (pay) and R2 (location).

## Decision snapshot

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)
- `important`: adjacent: R10 (Hands-on execution as a team of one), R11 (E-commerce enablement context) · unclear: R12 (Board-facing reporting)

R1, R2: each fails on its own; R6, R7, R8, R9: functions your background doesn't show yet, and they don't matter while R1 and R2 fail; R10: you have led teams, and this role has no team.

**Opportunity ledger.** Even setting your constraints aside, the role is poorly built. RR3 is a senior mandate at a junior base. RR4 folds about seven functions into one job. RR5 gives that job no team and no stated budget. RR6 is an always-on norm, RR7 is accountability with no defined metrics, and RR9 is equity with no terms. The employer isn't established yet (RR8). One point in its favor is the stated profitability and a direct line to the CEO (RR10).

- **Hard gates:** failed: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** Novaline would have to offer a base of at least $150k (it posts $70–85k, so the top of its range would need to rise by about 76%) and drop "5 days a week, no exceptions" in favor of fully remote. Or you would have to revise one of your own non-negotiables. Better wording on your side can't fix either one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not checked against any outside source (see Evidence status) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Structure | "Team of one to start"; reports to the CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` JD |
| First-year outcomes | None stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | The scope of a full growth org (a head plus specialists), priced and staffed like a single IC role | `[inferred]` from the seven named functions against "team of one" and the posted base |
| Implied customer | Probably B2B: selling to merchants rather than consumers, which "sales ops" and "partnerships" also suggest | `[inferred]` from "e-commerce enablement" and the function list |
| Unknowns | Growth budget, equity terms (percentage, vesting, strike), what the board expects from the dotted line, hiring plan beyond "to start" | — |
| Contradictions | "Series A, profitable since day one" and a demand for 8+ years of leadership, set against a $70–85k base | `[inferred]` from the JD's own terms; the market band wasn't checked (see Evidence status) |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your hard constraint), against the posted base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor. Fit fails because the top of the posted range is $85k, $65k below the floor | `[grounded]` JD "$70–85k base"; your stated floor | Surface it; only the employer changing terms or you revising the floor resolves it |
| R2 | Remote-only from Portland (your hard constraint), against "On-site in our Austin office 5 days a week — no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The JD rules out the exception in writing | `[grounded]` JD; your stated constraint | Same as R1 |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | 9 years in growth, as Growth Lead and then Head of Growth at two companies. This is intake self-report, so it is capped at `medium` until probed | `[grounded]` your intake | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid with a budget you controlled during the $8M→$40M ARR scale-up. Self-report, `medium` | `[grounded]` your intake | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; deep Braze experience. Self-report, `medium` | `[grounded]` your intake | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention SEO or content | `[grounded]` silence in the intake | G1 |
| R7 | Brand and PR | must_have | unclear | low | discovery | Not mentioned | `[grounded]` silence in the intake | G1 |
| R8 | Partnerships | must_have | unclear | low | discovery | Not mentioned | `[grounded]` silence in the intake | G1 |
| R9 | Sales ops | must_have | unclear | low | discovery | Not mentioned. Your companies were B2C subscription businesses, where sales ops may not have existed | `[grounded]` silence in the intake; `[inferred]` from the B2C subscription model | G1 |
| R10 | Hands-on execution as a team of one | important | adjacent | medium | transferability | You managed teams of 3–7, and your SQL and GA4 depth suggests hands-on work. Limit: no stated period of running every function alone | `[grounded]` your intake; `[inferred]` hands-on work from the tool depth | G2 |
| R11 | E-commerce enablement (likely B2B) context | important | adjacent | medium | transferability | B2C subscription growth carries over on funnel, lifecycle and experimentation. Limit: no stated B2B or merchant-facing motion | `[inferred]` B2B reading of the JD (see Role reality) | G2 |
| R12 | Board-facing reporting (dotted line to the board) | important | unclear | low | discovery | As Head of Growth you may have reported to a board, but it isn't stated | `[grounded]` silence in the intake | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand/PR, partnerships, sales ops, board reporting (R6, R7, R8, R9, R12) | discovery | Your stated ownership covers paid, lifecycle and experimentation, and none of these | These rows can't change the decision while R1 and R2 fail. They would matter for a similar role whose terms fit you | Content or SEO programs you ran or oversaw; launch PR you coordinated; affiliate or co-marketing deals; board decks you presented | A board-deck excerpt, a partnership one-pager, an organic-traffic dashboard | `[grounded]` silence in the intake |
| G2 | Solo execution; B2B context (R10, R11) | transferability | Team leadership in B2C subscription | A bridge you'd need to show for any role built like this one | Periods before you had a team; any merchant- or business-facing campaigns | An experiment log, a self-built SQL dashboard | `[inferred]` from your intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay conflicts with your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | Even the top of the range is $65k under your floor | `[grounded]` JD against your stated floor | Is there any flexibility in base above $85k, up to $150k? | confirmed |
| RR2 | On-site requirement conflicts with remote-only (see R2) | red_flag | high | "5 days a week — no exceptions" | The posting rules out remote work in writing | `[grounded]` JD | Is fully remote ever considered for this role? | confirmed |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required" / "$70–85k base" | Senior, board-facing ownership of all revenue at a base usually paid for mid-level ICs. The market band wasn't checked, so this stays `medium` | `[inferred]` from the JD's own terms; `[generic]` that heads of growth with this mandate are usually paid more | How did you set the base range, and what level did you benchmark it against? | unresolved |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several specialist roles folded into one title | `[inferred]` from the function list | Which two of these functions matter most in year one, and which are deferred? | unresolved |
| RR5 | Responsibility without resources | risk_signal | medium | "team of one to start — we believe in players who don't need a bench" | Accountable for all revenue with no team and no stated budget | `[inferred]` from the JD's silence on budget and hiring | What growth budget is committed, and when is the first hire approved? | unresolved |
| RR6 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Framed as company identity rather than an occasional exception | `[inferred]` from the wording | How often in the last quarter did "when it matters" apply? | unresolved |
| RR7 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You would be judged against targets that don't exist yet and may shift | `[inferred]` from the wording | What revenue number would make year one a success? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Equity terms unstated | unknown | — | "meaningful equity upside" | The equity is the main offset to the low base, and its size and terms aren't given | `[inferred]` from the wording | What percentage, vesting schedule and strike price are on offer? | unresolved |
| RR10 | Profitable, with a direct line to the CEO | positive_signal | — | "profitable since day one" / "Report to the CEO" | If true, this suggests real runway and decision access | `[grounded]` JD's claim, not verified | What were last year's revenue and growth rate? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | See R1, R2 | `[grounded]` the map | pending your approval |
| A2 | Optional: before writing it off, send one short note to the recruiter asking RR1's and RR2's questions | This is the only route to a different answer: the employer changing its terms | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Use this posting's red flags (RR3–RR7) as a screen for similar roles | Your intake shows a profile built for scaling with a team and budget, which this role lacks | `[grounded]` your intake, RR4, RR5 | pending your approval |

## Evidence status

Verified: R1 and R2 are your own stated constraints. Everything else is self-report from your intake: leads, not proof.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused in this session. It would have confirmed whether Novaline exists as described and whether the posting is live, which would resolve or keep RR8 |
| 2. Role-family sweep | unavailable | Search refused in this session. It would have set a market band for Head of Growth at Series A to confirm or reduce RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save this as a `tuesday-dossier.md` if you'd like a record of it.

**Upgrade menu**
- Allow web search → RR8 resolves or stands, and RR3 is checked against a real market band.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds the register. Say the word and it runs.
- A growth artifact (an ARR or cohort dashboard, an experiment log, a budget-to-revenue summary) → R3, R4 and R5 move from `medium` to `high`, which helps with the next role that does meet your constraints.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.