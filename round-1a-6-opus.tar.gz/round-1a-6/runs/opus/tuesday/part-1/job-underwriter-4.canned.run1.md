Still reading the assessment playbook's worked examples; I'll have your go/no-go shortly.
**Yes, apply. Your fit is strong, but first check one thing: the posting says it's fully remote, and Brindlemoor's own careers page says it isn't (R1, RR1). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — adjacent: R9 (Pet-insurance product knowledge) · unclear: R8 (Recommendations for product)
- `preferred` — direct: R10

R1 — the location terms contradict each other; R5b, R8 — your experience probably covers these, but you need to confirm it; R9 — a real bridge from motor, with its limit named.

**Opportunity ledger.** The posting is live and the hiring manager is easy to find publicly (RR3). Against that, the working pattern contradicts itself (RR1) and the salary isn't stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor confirms the working pattern, and it's one you'll accept (R1, RR1); (2) the budgeted salary meets your floor (RR2); (3) the pet-insurance case is framed as a bridge from motor, never as pet experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; JD names her |
| Line management | The JD lists no management duties, so your lack of management experience isn't against any stated requirement | `[grounded]` JD silence |
| Hiring manager | Director of Pricing. Gave a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile search result |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (n=612). This is the market band, not Brindlemoor's offer | `[generic]` Pricewell 2026 pay survey |
| Unknowns | Salary; working pattern; size of the pet book; who in product receives the recommendations | — |
| Contradictions | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` JD vs. careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You stated no location constraint, so there's nothing to grade, and the employer's two sources disagree on the terms | `[grounded]` JD vs. careers page; no candidate statement | Closing question R1; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Self-reported and specific, nothing inspected yet | `[grounded]` your intake message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is the employer's word, and a technical exercise usually tests it | `[grounded]` intake; `[generic]` that this role family uses technical tests | Have a code sample you can talk through |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained a GLM rating model | `[grounded]` intake | none |
| R5a | Build rating models | must_have | direct | medium | none | "Built … the GLM rating model for our young-driver book" | `[grounded]` intake | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" might include monitoring (drift, actual-vs-expected, refits), but it might not, so I've read it as claiming less | `[grounded]` intake wording | G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Who designed them and who read them out isn't stated, so expect a probe | `[grounded]` intake | Be ready to say which parts of the tests were yours |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to your head of underwriting | `[grounded]` intake | none |
| R8 | Turn results into recommendations for product | important | unclear | low | discovery | Your underwriting audience is established; a product audience isn't mentioned | `[grounded]` intake silence on product | G3 |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Inferred from "our pet-insurance product". The GLM, testing and review work all carries over. Limit: you haven't worked with pet rating factors or pet claims patterns | `[inferred]` requirement from the JD's product line; `[generic]` that pet rating factors differ from motor | G2 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R5b, must_have) | discovery | "Maintained" is stated; monitoring isn't described | It's a must-have, and it's the subject of the hiring manager's public talk | Actual-vs-expected tracking on the young-driver book; drift or stability checks; deciding when to refit or recalibrate; flagging a factor that misbehaved | A sanitized monitoring dashboard or a refit memo | `[grounded]` intake wording; `[grounded]` talk title from the search result |
| G2 | Pet-insurance knowledge (R9, important) | transferability | Motor pricing, with nothing on pet | This is the obvious objection to a motor candidate | Pricing a niche or small book (young drivers is a segment); thin-data credibility work; any claims-frequency or severity modelling | A short note on how you'd approach a first pet rating review | `[inferred]` bridge from your motor GLM work; `[generic]` that this is the likeliest objection |
| G3 | Recommendations for product (R8, important) | discovery | Only an underwriting audience is mentioned | The JD names product as a second audience | Price-test results that changed a product feature, excess or cover option; work with marketing or product on a launch | A test readout or a recommendation deck | `[grounded]` JD and intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts itself | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One of the two is out of date, or the pattern has changed since the JD was written | `[grounded]` both sources; `[inferred]` that one is out of date | Is this role fully remote, or Leeds four days a week as the careers page says? | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in the JD or on the careers page | It may sit inside the £52–65k market band or outside it | `[inferred]` from the withheld figure, against the `[generic]` band | What salary is budgeted for this role? | unresolved |
| RR3 | Live posting and an attributable hiring manager | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The employer and the role are real and current | `[grounded]` careers page fetched; public profile search result | How big is the pet book today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Brindlemoor before you write a tailored application | RR1, R1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the young-driver GLM and the 14 price tests, in your own words: "built and maintained", "ran … with the underwriting team" | R5a, R6. Matches what the role is for | `[grounded]` intake | pending your approval |
| P2 | If G1 confirms monitoring work, put it near the top: Odile Varga's public talk is on monitoring rating models in small books | R5b | `[grounded]` talk title; whether it lands with her is untested | pending your approval |
| P3 | Present pet insurance as a bridge: "motor GLM pricing, not yet pet", with its limit stated | R9 | `[inferred]` from R9 | pending your approval |
| Q1 | Ask the questions in RR1, RR2 and RR3 word for word in the first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

All wording above stays a proposal until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the posting is live; found the Leeds contradiction (RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary remote GLM", which returned the "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Gave the market calibration band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Gave the talk topic and prior role (P2) |

---

I can save all of this as a `tuesday-dossier.md` for later steps whenever you want it.

**Upgrade menu**
- Your location and salary constraints → R1 resolves, and RR2 gets a floor to test against.
- Your CV → every row is checked against what the document actually says, and I can spot buried evidence.
- A sanitized model doc, monitoring pack or test readout → raises R4, R5a, R5b and R6 toward `high`.
- Deeper research on Brindlemoor (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches) → just say the word.

**Questions**

R1 — Would a Leeds office four days a week work for you, or do you need fully remote?

G1 — On the young-driver model, did "maintained" include monitoring, such as actual-vs-expected tracking, drift checks or deciding when to refit? What was yours?

G3 — Did any of your price-test results go to product or marketing, rather than underwriting, and change something?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.