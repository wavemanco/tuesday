I'm going through the assessment playbook's reference files. Next is the worked example, which sets the exact output shape. After that I'll check the company and the posting.
## Decision snapshot

**Yes, it's worth applying, on the condition below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote within the US, or the Denver office)
- `must_have`: direct: R2, R3, R4, R6, R7
- `important`: adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (Ingestion from the app and CRM), R9 (Data contracts analysts depend on)

R5: you can credibly move from Snowflake to BigQuery, as long as you say plainly what you haven't done; R8, R9: your background doesn't mention either, so it's worth checking what you've done.

**Opportunity ledger.** Sound. The employer and the live posting are confirmed (RR2), and the stated pay matches the market (RR1). Still open: the team size and how much of the stack you'd own (RR3), the equity terms (RR4), and on-call load (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote within the US, or the Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're based in the US or can work from Denver (R1); (2) BigQuery is presented as adjacent experience, never as experience you have (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page you pasted, matched by a search result from pellucidlearning.com/about |
| Mandate | "Build and run the pipelines behind our tutoring platform's reporting": ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar", SQL, Python, data quality testing | `[grounded]` JD |
| Scope read | The posting covers ingestion, warehouse and contracts: the whole reporting path from source to analyst, not one slice of it | `[inferred]` from the three named components with no team or split of work mentioned |
| Market calibration | The report's "Senior" means 5–8 years, and the posting asks for 5+, so the seniority matches. The report's typical scope is one domain's pipelines with no direct reports. This posting may be broader (RR3). Pay is $148,000–$166,000 against a base median of $151,000 and an interquartile range of $139,000–$163,500. The bottom of the range is $3,000 below the median and the top is $2,500 above the upper quartile | `[generic]` Datawright 2026 report you pasted (US, n=2,310, Series B–D); `[grounded]` JD for the posting's range |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Team size and who you'd report to; equity form and size; on-call expectations; how many CRM and app sources there are | — |
| Contradictions | None. The live careers page matches what you pasted, word for word, and shows "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | You didn't say where you're based or whether you're authorized to work in the US, so this term is unsettled | `[grounded]` JD; background silent | R1 question below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated, above the 5+ ask. You typed this yourself and nothing has been inspected, so it stays at `medium` | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" for 6 years. Expect it to be tested live, since nothing has been inspected | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your team's dbt project on Snowflake, about 180 models. Snowflake meets "a cloud warehouse" | `[grounded]` your background | A sanitized dbt docs page or project structure would raise this to `high` |
| R5 | BigQuery as the warehouse ("a dbt-modelled warehouse in BigQuery") | important | adjacent | medium | transferability | The dbt models and warehouse modelling carry over. What doesn't: you've never used BigQuery, so its cost model, partitioning and clustering, and GCP IAM are untested. The requirement asks for "a cloud warehouse", which is why this is `important`, not `must_have` | `[grounded]` you say you've never used BigQuery; `[inferred]` the parts that carry over, from dbt being independent of the warehouse | see G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in your background and is the JD's first-named tool | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite": you set it up, you didn't just use it | `[grounded]` your background | none |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background covers modelling and orchestration but says nothing about getting data in: sources, connectors, CDC, APIs | `[grounded]` background silent | G2 question below |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations work sits close to this, but you don't mention agreeing schemas or contracts with downstream users | `[grounded]` background silent; `[inferred]` closeness of the test suite to contract enforcement | G3 question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, important) | transferability | What carries over: dbt modelling at about 180 models, warehouse work on Snowflake. The gap: BigQuery itself | It's the stack you'd work in on day one, so expect it to be the first thing probed | Any GCP exposure; dbt adapter or cross-warehouse work; Snowflake cost or performance tuning you did (it maps to BigQuery partitioning) | A small public dbt + BigQuery sandbox project | `[grounded]` you say you've never used BigQuery; `[generic]` that interviews probe the warehouse a team actually runs |
| G2 | Ingestion from the app and CRM (R8, important) | discovery | Nothing on ingestion in your background | A third of the stated mandate; resolving it moves R8 to `direct` or names a real gap | Payroll-system or HRIS feeds you pulled in; Salesforce/HubSpot-style CRM extracts; Fivetran/Airbyte/custom Python loaders; event or CDC streams from an app database | A sanitized DAG or loader, a source inventory | `[grounded]` background silent |
| G3 | Data contracts (R9, important) | discovery | A Great Expectations suite you set up; no mention of contracts with analysts | The JD names contracts analysts "depend on"; a test suite is close to this but isn't the same thing | Schema agreements with analytics or finance; dbt model contracts or exposures; breaking-change policies; GE checks written to an analyst's spec | A contract or schema doc, a GE suite config | `[grounded]` background; `[inferred]` closeness of GE to contract enforcement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in line with the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The employer publishes a real band, and the band runs from just below the report's median to just above its upper quartile | `[grounded]` JD figure; `[generic]` Datawright band | Where in the range do you expect to place someone with 6 years? | noted |
| RR2 | Employer and posting confirmed | positive_signal | — | "Accepting applications" | The company exists as described and the role is live | `[grounded]` careers page fetched; about page matched by search | — | noted |
| RR3 | Team size and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | This may be the whole reporting data platform held by one person, broader than the one-domain norm | `[inferred]` from three components with no team mentioned; `[generic]` one-domain norm from the report | How many data engineers are on the team, and which parts of ingestion, warehouse and contracts would this role own alone? | unresolved |
| RR4 | Equity unspecified | unknown | — | "plus equity" | The form (options or RSUs), size and vesting are unknown, so total pay can't be compared yet | `[grounded]` JD silent on terms | What form and size of equity grant comes with this role, and on what vesting schedule? | unresolved |
| RR5 | Operational load unstated | unknown | — | "Build and run" | "Run" may mean on-call ownership of the pipelines | `[inferred]` from "run" in the mandate | Is there an on-call rotation for the pipelines, and how often would I be on it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put three things at the top of your resume, in your own figures: "Built our dbt project on Snowflake (about 180 models)", "Airflow orchestration", "Set up our Great Expectations test suite" | They cover R4, R6, R7 using your own words | `[grounded]` your background | pending your approval |
| E2 | List Snowflake, not BigQuery. If asked, say: "My warehouse is Snowflake; I haven't used BigQuery yet" | R5 is adjacent; claiming BigQuery would fail the first probe | `[grounded]` you say you've never used BigQuery | pending your approval |
| W1 | Optional: a small public dbt + BigQuery sandbox project before the technical rounds | Narrows the limit on R5 with something an interviewer can inspect | `[inferred]` from G1's limit | pending your approval |
| Q1 | Ask the RR1, RR3, RR4 and RR5 questions word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Ground any salary discussion in the posting's own range and the report's median and quartiles | Both are figures you hold | `[grounded]` JD; `[generic]` Datawright report | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) to check the pasted posting. It is live and identical to your paste. Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching your paste. This moved role reality's organization and contradictions rows, and RR2 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already gives the band, seniority and scope norm that market calibration and RR1 need |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Upgrade menu

I can write all of this into a `tuesday-dossier.md` file you can keep using, if you want it.

- Where you're based and whether you're authorized to work in the US → R1 closes, and the decision becomes `go` or `no_go`.
- A sanitized look at the dbt project (docs site, folder structure, a model or two), an Airflow DAG, or the Great Expectations suite config → R4, R6, R7 could move to `high`.
- Answers to G2 and G3 → R8 and R9 move to `direct` or become named gaps.
- The hiring manager's name, once the recruiter shares it → target 3 runs, and the plan picks which of your stories to lead with for that reader.
- A deeper research pass on Pellucid Learning (leadership and hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Just say the word and it runs.

## Questions

**R1:** Are you based in the US (or able to work from Denver) and authorized to work there without sponsorship?

**G2:** Have you built ingestion yourself, for example payroll or HRIS feeds, CRM extracts, app-database or event streams? What were the sources, and was it a tool like Fivetran or custom Python?

**G3:** Did you ever agree schemas or breaking-change rules with analysts or finance, or write Great Expectations checks to their spec?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.