Quick update: I've read the job-underwriter playbook. Now I'm running a couple of checks on Pellucid's own site to make sure the posting is still live before I write the assessment.
## Decision snapshot

**Yes, it's worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office)
- `must_have`: direct: R2, R3, R4, R6, R7
- `important`: adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R5: a Snowflake-to-BigQuery bridge, with its limit named; R8, R9: your background doesn't mention them yet, so these are open questions rather than gaps found.

**Opportunity ledger.** The role looks sound and is open about its terms. The pay range is stated and sits at the market (RR1), and the posting is live and matches your copy (RR2). The reporting line is unknown (RR3), and so are the equity terms (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); you didn't give your own constraints, so I couldn't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from the US or the Denver office (R1); (2) you present BigQuery honestly as a warehouse you haven't used yet, never as experience you have (R5, G1); (3) the screen confirms the scope and reporting line (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About page text you pasted; I didn't fetch it myself |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for the analysts | `[grounded]` JD |
| Must-haves | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Owning one domain (reporting), from ingestion through to what analysts consume. No people management is mentioned | `[inferred]` from the JD's mandate and its silence on reports |
| Market calibration | "Senior" usually means 5–8 years and owning one domain's pipelines with no direct reports, and this posting matches that. The stated range starts just under the $151,000 median and tops out above the upper quartile ($163,500). Its midpoint is about $157,000 | `[generic]` Datawright 2026 pay report, US, n=2,310, Series B–D, as pasted; `[grounded]` JD for the range |
| Unknowns | Hiring manager and reporting line; team size; equity form and amount; whether the in-office option has a set number of days | — |
| Contradictions | None. The live posting matches the text you pasted | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US, so this gate is open | `[grounded]` JD terms; your background doesn't say | Closing question R1 |
| R2 | 5+ years of data engineering | must_have | direct | medium | none | You say 6 years at a B2B payroll company. That's specific but not yet backed by anything I can inspect. It's a length of experience, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily." Expect an interviewer to test this | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | "Built our dbt project on Snowflake, about 180 models." Snowflake meets "a cloud warehouse" as the requirement is worded | `[grounded]` your background | none |
| R5 | BigQuery as the warehouse | important | adjacent | medium | transferability | The posting names BigQuery as its stack but not as a requirement. Your dbt-on-Snowflake work carries over. The limit: you haven't worked with what is specific to BigQuery, such as partitioning and clustering, slot- and bytes-based cost control, or GCP permissions | `[inferred]` from the JD naming BigQuery under the mandate, not under requirements; `[generic]` what sets BigQuery apart from Snowflake | See G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You say you used Airflow for orchestration, which matches what's asked | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite." That's specific and yours | `[grounded]` your background | none |
| R8 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your background covers modelling and testing but doesn't say where your data came from or who built the ingestion | `[grounded]` JD; your background doesn't say | See G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is related, but contracts with the teams who consume the data aren't mentioned | `[grounded]` JD; `[inferred]` that a test suite is near contract work but isn't the same | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, important) | transferability | Carries over: dbt, the warehouse modelling behind your 180 models, Airflow. Doesn't yet cover: BigQuery's cost model, partitioning and clustering, IAM | This is the one place where your stack differs from theirs | Any GCP work; dbt adapter differences you've dealt with; managing Snowflake costs (warehouse sizing, clustering keys) as a comparable skill | A small public dbt-on-BigQuery repo using a free public dataset | `[inferred]` bridge from your Snowflake work; `[generic]` that a stack mismatch gets probed in interviews |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Your background doesn't name any sources or ingestion tools | This is one third of the stated mandate | Pulling data from an HR or CRM SaaS API; loading production database replicas or change data capture; managed connectors such as Fivetran or Airbyte you set up or maintained | An Airflow DAG description, an architecture sketch | `[grounded]` JD mandate; your background doesn't say |
| G3 | Data contracts (R9, important) | discovery | A test suite is there; agreements with the teams who use the data aren't | This is a named deliverable and differs from testing | Agreeing schema or freshness guarantees with analysts or finance; alerting owners when a source breaks a model; defining sources and exposures in dbt | A contract doc, a dbt schema.yml excerpt, a runbook | `[grounded]` JD; `[inferred]` the difference between tests and contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay is stated and sits at the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range runs from below the median to above the upper quartile. There's no sign that the senior title is underpaid | `[grounded]` JD; `[generic]` Datawright band | Where in the range do candidates with 6 years usually land? | noted |
| RR2 | Posting is live and matches your copy | positive_signal | — | "Accepting applications" | The role is open as described | `[grounded]` careers page fetched | — | noted |
| RR3 | No hiring manager or reporting line named | unknown | — | (the posting names no hiring manager) | You might report to analytics, to engineering or to a data lead, and that changes who sets your priorities | `[inferred]` from the posting's silence | Who does this role report to, and how many data engineers are on the team? | unresolved |
| RR4 | Equity not specified | unknown | — | "plus equity" | The type, size and vesting are all unstated | `[grounded]` JD wording | What form does the equity take (options or RSUs), and what's the typical grant and vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your own words: "built our dbt project on Snowflake, about 180 models" and "set up our Great Expectations test suite" | See R4, R7, which are the closest match to the mandate | `[grounded]` your background | pending your approval |
| A2 | Name BigQuery as new to you and describe the Snowflake work as what carries over. Don't list it as a skill | See R5 | `[grounded]` your background ("Never used BigQuery") | pending your approval |
| W1 | Optional: a weekend dbt-on-BigQuery project using a public dataset | Turns R5's limit into something an interviewer can look at | `[generic]` that a work sample narrows a stack gap | pending your approval |
| Q1 | Ask RR3 and RR4's questions in the recruiter screen | The register doubles as screen prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 (searches 1 of 5, fetches 1 of 2)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers" and fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). This checked the posting you pasted: it's live, and the text matches. That supports RR2 and the contradictions row. I didn't fetch the About page, so the company facts rest on your paste |
| 2. Role-family sweep | skipped | The Datawright report you pasted already gives the market calibration and RR1's band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier, upgrade menu and questions

If useful, I can save all of this as a `tuesday-dossier.md` for later steps.

**Upgrade menu**
- Your location and any non-negotiables (a pay floor, remote-only) → closes R1 and adds rows for your constraints. The status could then move to `go`.
- Answers to G2 and G3 → R8 and R9 resolve one way or the other.
- A repo, DAG or schema.yml you can share → raises R4, R6 or R7 above `medium`.
- The hiring manager's name → sharpens the scope read and which of your stories to lead with.
- A deeper look at Pellucid (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and I'll run it.

**Questions**

R1: Are you based in the US and able to work there, either remotely or from Denver?

G2: At the payroll company, did you build or own any ingestion, such as API pulls from SaaS tools, database replication or connector setup? What were the sources, and which parts were yours?

G3: Did you ever agree formal guarantees with the people who use your data, like schemas, freshness or who gets alerted when something breaks, beyond the Great Expectations tests?

For any of these, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.