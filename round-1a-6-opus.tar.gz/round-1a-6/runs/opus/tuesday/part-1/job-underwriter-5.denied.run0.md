I'm reading the job-underwriter playbook's worked example. Then I'll check Pellucid's site and do one market sweep before giving you the assessment.
Yes, I think it's worth applying to. You meet every listed requirement. The one thing you don't have, BigQuery, sits in the job description rather than the requirements list. Three things need confirming first, set out below.

## Decision snapshot

**Yes, it looks worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (dbt-modelled warehouse in BigQuery) · unclear: R10 (Ingestion from our app and CRM), R11 (Data contracts our analysts depend on)

R9: Snowflake carries over to BigQuery, but only so far, and the limit is named in the map. R10, R11: you haven't mentioned this work yet; that doesn't mean you lack it.

**Opportunity ledger.** The pay is posted and in line with the market: the range spans the report's median (RR2). I couldn't verify the employer or the posting because my search was blocked (RR1). Still unknown: how big the data team is and who you'd report to (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Pellucid's own careers page (RR1); (2) you can work from the US or Denver (R1); (3) the range clears your own floor (R2); (4) you present BigQuery honestly as a skill you'd be adding, not one you have (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states; founded 2016 in Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page as you pasted it, not checked by me |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Listed requirements | 5+ years; SQL and Python; dbt and "a cloud warehouse"; Airflow "or similar"; data quality testing. BigQuery appears in the responsibilities, not the requirements | `[grounded]` JD |
| Terms | $148,000–$166,000 base plus equity (equity form unstated); remote within the US or the Denver office | `[grounded]` JD |
| Scope read | Three responsibilities inside one domain (reporting), with no direct reports mentioned | `[inferred]` from the JD's responsibilities against the report's scope norm |
| Market calibration | Senior at Series B–D means 5–8 years, owning one domain's pipelines, no reports; median base $151,000, middle half $139,000–$163,500. The posted range starts just under that median and tops out above the upper quartile. Title, years and scope all match the norm | `[generic]` Datawright 2026 report, as you pasted it; `[grounded]` JD figures |
| Unknowns | Size of the data team; on-call duty; who the role reports to; what form the equity takes | — |
| Contradictions | None between the JD and the about page as pasted. Not checked against the live site (RR1) | `[grounded]` your pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US | `[grounded]` JD; your background is silent | Closing question R1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor stated, so the posted range can't be checked against one | `[grounded]` JD; your background is silent | Closing question R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years, stated specifically; nothing to inspect yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", specific but self-reported | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Specific, with no artifact inspected | `[grounded]` your background | A repo or a sanitized dbt docs/lineage screenshot would raise this to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse" and Snowflake is one | `[grounded]` JD wording and your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, the tool the posting names | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | Suite config or sanitized checkpoint output would raise this to `high` |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You've done the same job on Snowflake (dbt modelling, SQL, warehouse design) but never used BigQuery. You said so yourself; that sets the limit | `[grounded]` your background; `[inferred]` that the dbt and SQL skills carry over | See G1 |
| R10 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background doesn't say which sources you've pulled data from | `[grounded]` your background is silent | See G2 |
| R11 | Data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations work is nearby, but contracts with analysts aren't mentioned | `[grounded]` your background is silent; `[inferred]` that the tests are related | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | What carries over: dbt project design, SQL, Airflow, testing. The limit: no BigQuery-specific work, such as partitioning and clustering, its cost model, or GCP permissions | It's the one row below `direct` that's grounded in the role's actual stack; interviewers are likely to ask about it | Any GCP exposure at all; switching dbt adapters; tuning Snowflake cost or clustering | A small public dbt project running on BigQuery | `[grounded]` your own "never used BigQuery"; `[generic]` which BigQuery topics interviews tend to cover |
| G2 | App and CRM ingestion (R10, important) | discovery | Nothing yet on sources or tooling | It's a third of the role's stated scope | Replicating a production app database (CDC, Fivetran, Airbyte); pulling a CRM such as Salesforce or HubSpot through an API; Python extractors you wrote and then ran in Airflow | A DAG excerpt or an architecture diagram | `[grounded]` your background is silent |
| G3 | Data contracts (R11, important) | discovery | Great Expectations suite, but no contracts with analysts or upstream teams mentioned | The posting names it as something analysts depend on, so it's likely to come up | Agreeing schemas or freshness SLAs with analysts; dbt model contracts or enforced schemas; Great Expectations checks that blocked bad data before it reached analysts' models; working with app engineers on schema changes | A contract spec, an SLA document, or a sanitized incident write-up | `[grounded]` the JD's wording; `[inferred]` that your test suite is related work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver." | The posting may be stale or aggregated, the company may have little public footprint, or it may not be a real hiring employer. These are possibilities, none ranked as likely; I couldn't check any of them | `[generic]` pattern for companies in general, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay posted and calibrated | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range spans the market median, and its top end is above the upper quartile for this scope | `[grounded]` JD figure; `[generic]` Datawright band, as you pasted it | Where in the range would you place someone with six years and no BigQuery experience, and what form does the equity take? | noted |
| RR3 | Team size and on-call not stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Build and run" could mean a data team of one, carrying ingestion, the warehouse and contracts alone | `[inferred]` from the JD's scope against its silence on team | How many data engineers are on the team today, and how is on-call handled for these pipelines? | unresolved |
| RR4 | No hiring manager named | unknown | — | The posting names no hiring manager | The reporting line could be data, engineering or analytics leadership, which changes who sets priorities | `[inferred]` from the posting's silence | Who does this role report to, and how do the analysts' requests reach it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own words: you "built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite" | See R5, R8, R11 | `[grounded]` your background | pending your approval |
| P2 | Name BigQuery plainly as the warehouse you'd be adding, alongside the dbt and SQL work that carries over. Never claim BigQuery experience | See R9, G1 | `[grounded]` R9 | pending your approval |
| P3 | Optional: before interviews, build a small dbt project on BigQuery that you can show | See G1; this would narrow the gap R9 records | `[inferred]` from G1's strengthener | pending your approval |
| P4 | Check that the posting is live on Pellucid's own careers page before you spend time on the application | See RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the RR2–RR4 questions word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent one search, "Pellucid Learning online tutoring Denver Senior Data Engineer", and the permission prompt refused it. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright 2026 report you pasted already sets the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

I can write all of this up as a `tuesday-dossier.md` file if you want to keep it.

**Upgrade menu**
- **Allow search, or check the careers page yourself:** clears RR1 and lifts the cap, so the status could become `go`.
- **Your location and pay floor:** settles R1 and R2.
- **Answers to G2 and G3:** settle R10 and R11.
- **A public dbt repo, or sanitized Great Expectations config:** raises R5 and R8 to `high`.
- **The hiring manager's name:** sharpens the scope read and tells you which story to lead with.
- **A deeper research pass, if you allow search** (funding and leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches): just say the word.

**R1:** Do you live in the US, or could you work from Denver?
**R2:** What's the lowest base salary you'd accept?
**G3:** Have you agreed schemas, freshness SLAs or other "contracts" with analysts or upstream teams? If so, what was yours, and what broke when one was violated?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.