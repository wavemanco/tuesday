Checking that Pellucid's posting is live, then I'll give you the full assessment.
Yes, it's worth applying, as long as you can work from the US or Denver. Status: `conditional_go`.

## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (dbt-modelled warehouse in BigQuery) · unclear: R9 (Ingestion from our app and CRM), R10 (The data contracts our analysts depend on)

R6: a Snowflake-to-BigQuery bridge, and its limit is named; R9, R10: your background doesn't mention these, so one question each.

**Opportunity ledger.** Sound and open about terms. The posting is live and matches what you pasted (RR4). The posted pay sits at or above the recruiter report's range (RR1). The open items are scope and reporting line (RR2, RR3) and the equity terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're based in the US or can work from Denver (R1); (2) you present BigQuery honestly as a warehouse you haven't used yet, with Snowflake as the warehouse you know (R6); (3) the scope checks out as one data platform you can own, not a solo build of everything (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page text you pasted |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, matches the live careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | "Build and run" across ingestion, warehouse and contracts reads as owning the whole reporting stack, not one domain within it | `[inferred]` from the JD's three-part mandate; team size isn't stated |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" usually means 5–8 years and owning one domain, with no reports. The posted range starts $3k under the median and tops out $2,500 above the IQR's upper end. This is a market pattern, not Pellucid's offer | `[generic]` Datawright 2026 report, n=2,310, as you pasted it; `[grounded]` JD for the posted range |
| Unknowns | Hiring manager and reporting line; data team size; equity terms | — |
| Contradictions | None between your pasted JD and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US | `[grounded]` JD; your background is silent | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years, self-reported and specific. This is your own account, so `medium` | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", self-reported | `[grounded]` your background | none |
| R4 | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models. Specific, but nothing to inspect yet | `[grounded]` your background | none |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as worded | `[grounded]` JD wording and your background | none |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Your Snowflake and dbt work carries over; you have never used BigQuery. The JD's requirement says "a cloud warehouse", and BigQuery appears only in the responsibilities, so this is `important` rather than `must_have` | `[grounded]` your "never used BigQuery"; `[inferred]` tier from the JD's wording | See G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, self-reported | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | none |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background covers modelling and orchestration but not where the data came from or who built ingestion | `[grounded]` background silent on ingestion | See G2 |
| R10 | The data contracts our analysts depend on | important | unclear | low | discovery | Your tests could be part of a contract, but you haven't said whether you set schemas, SLAs or agreements with analysts | `[inferred]` from the Great Expectations work; contracts aren't mentioned | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Bridge: dbt, SQL modelling and a cloud warehouse all carry over. Limit: none of the BigQuery-specific work (partitioning and clustering, nested and repeated fields, its cost model, GCP permissions). Strengthener: a small dbt-on-BigQuery sandbox project | A gap you name honestly makes a weaker headline but holds up better in interviews | Moving models between warehouses; tuning warehouse cost or performance on Snowflake | A public repo of a dbt project running on the BigQuery sandbox | `[grounded]` your background; `[generic]` that BigQuery's main differences sit in those areas |
| G2 | Ingestion from app and CRM (R9, important) | discovery | No mention of where the data came from | Ingestion is a third of the stated mandate | Pulling from the payroll app's production database; syncing a CRM like Salesforce or HubSpot; Fivetran or Airbyte connectors; custom Python extractors in Airflow | A DAG, an architecture diagram, a design doc | `[grounded]` background silent |
| G3 | Data contracts (R10, important) | discovery | Tests exist; there's no word of any agreement with analysts | It's named in the mandate and is easy to over-claim | Schema rules analysts relied on; freshness SLAs; dbt model contracts or exposures; a change process for breaking schema changes | dbt `contract:` configs, an SLA doc | `[inferred]` from the Great Expectations work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay range transparent and at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range sits at or above the report's IQR for this stage | `[grounded]` JD; `[generic]` recruiter's report | Where in the range do candidates with 6 years usually land? | noted |
| RR2 | No hiring manager named | unknown | — | (posting names none) | Reporting line unknown: could be a data lead, an analytics head or engineering | `[inferred]` from the posting's silence | Who would this role report to, and how is the data team structured? | unresolved |
| RR3 | Mandate may be the whole stack | unknown | — | "Build and run the pipelines … ingestion … warehouse … data contracts" | The role may own all reporting data, which is wider than the report's "one domain" norm, at senior pay | `[inferred]` from the mandate; `[generic]` scope norm from the report | How many data engineers are there today, and which parts of the stack would I own alone? | unresolved |
| RR4 | Posting live and consistent | positive_signal | — | "Accepting applications." | The role is open, and its text matches what you pasted | `[grounded]` careers page fetched | — | noted |
| RR5 | Equity unspecified | unknown | — | "plus equity" | The type, size and vesting terms aren't stated | `[grounded]` JD | What form does the equity take (options or RSUs), and on what vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with what you said you did: "built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite" | Matches R4, R5 and R8 | `[grounded]` your own words | pending your approval |
| P2 | Say plainly that you haven't used BigQuery; position Snowflake as your cloud warehouse | R6 | `[grounded]` your background | pending your approval |
| W1 | Optional: a small public dbt project on the BigQuery sandbox before interviews | Narrows G1's limit | `[generic]` closure path | pending your approval |
| Q1 | Ask RR2, RR3 and RR5's questions in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It's live and matches your pasted JD (RR4, Contradictions row). I didn't fetch the about page, so the company facts rest on your paste |
| 2. Role-family sweep | skipped | Your recruiter's Datawright report already settles the market line and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as a `tuesday-dossier.md` file if you want to keep it for later steps.

**Upgrade menu**
- Where you're based and whether you're authorized to work in the US: closes R1 and may make this a `go`.
- Your pay floor and any other non-negotiables: lets me check the posted range against your number, not just the market.
- Your CV: shows whether R2–R8 come through on the page, and could turn R9/R10 up as rows already met.
- The hiring manager's name: fills target 3 and tells you which story to lead with.
- A deeper research pass on Pellucid (leadership and funding changes, employee reviews, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**R1:** Are you based in the US with work authorization, or able to work from Denver?
**G2:** Where did the data feeding your dbt project come from (app database, CRM, third-party tools), and which of those ingestion pipelines did you build yourself?
**G3:** Did you ever agree schemas, freshness or change rules with analysts, such as dbt contracts or written SLAs, or did your Great Expectations tests stand on their own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.