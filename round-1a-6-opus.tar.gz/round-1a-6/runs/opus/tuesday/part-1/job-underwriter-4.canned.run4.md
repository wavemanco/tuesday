Now the required reference files.
Yes, it's worth applying, once you've settled one location question. The JD you pasted says fully remote, but Brindlemoor's own careers page says Leeds four days a week. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important`: adjacent: R9 (Pet-insurance product knowledge)
- `preferred`: direct: R8

R1: the employer's own pages disagree on location. R9: a credible bridge from motor pricing, with its limit named. R5b: "maintained" may cover monitoring, but that isn't confirmed yet.

**Opportunity ledger.** The employer and the posting check out and the reporting line is clear (RR3). The location terms contradict each other (RR1), the salary isn't stated (RR2), and the JD doesn't say whether "own pricing analytics" comes with a team (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor confirms the working pattern and it suits you (R1, RR1). (2) You present the pet-insurance gap honestly as an adjacent move, not as pet experience (R9). (3) The budgeted salary meets your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The role is live on its careers page | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, and make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` careers page; your message |
| Working pattern | The pasted JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both sources, in conflict |
| Line management | The JD doesn't mention managing anyone, so your lack of management experience is not a gap against this posting | `[grounded]` JD silent |
| Scope read | One product, one owner, with a senior title. It looks like a hands-on individual-contributor role, not a team lead | `[inferred]` from "own pricing analytics" and the Senior Analyst title, with no team mentioned |
| Hiring manager's footprint | Six years as head of pricing analytics at Calloway Re. Gave a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books | `[grounded]` public professional profile |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900. The posting gives no salary, so this is what to expect, not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 pay survey (n=612) |
| Unknowns | Salary; working pattern; whether there's a team; the size of the pet book | — |
| Contradictions | Fully remote (pasted JD) vs Leeds four days a week (careers page) | `[grounded]` see RR1 |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint, so there's nothing to grade yet. The employer's two sources disagree on the terms | `[grounded]` JD vs careers page; no stated constraint | G1's question; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Stated in your message, no artifact yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Stated, not inspected | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book | `[grounded]` your message | none |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built a production rating model | `[grounded]` your message | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" could mean ongoing performance monitoring or just periodic refreshes. Taken at the lower reading until you confirm | `[grounded]` your wording; `[inferred]` that monitoring isn't established by it | G2's question |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with underwriting. You said "ran", so it isn't yet stated who designed them versus who executed them, and interviews will probe that | `[grounded]` your message; `[generic]` that interviews probe design ownership | Be ready to say exactly which parts of the test design were yours |
| R7 | Present recommendations to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R8 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your message | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | The GLM rating, price testing and underwriting work carry over. Limit: you've never priced pet. Its rating factors and claims drivers (breed, pet age, vet-cost inflation, cover type) differ from motor's | `[inferred]` requirement from "pricing analytics for our pet-insurance product"; `[generic]` how pet rating factors differ | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | No location constraint from you, and the employer's terms conflict | A gate that could fail if you need remote and the careers page is the current version | — | Your own constraint; Brindlemoor's written answer | `[grounded]` the two sources |
| G2 | Model monitoring (R5b, must_have) | discovery | "Built and maintained" covers the build. It doesn't show performance tracking after go-live | Monitoring is in the JD's first line of duties and is the subject of the hiring manager's published talk | Actual-vs-expected tracking by factor or segment; drift or stability checks; loss-ratio monitoring for the young-driver book; fixing a factor that slipped between refreshes | A sanitized monitoring dashboard, A-vs-E pack, or refresh paper | `[grounded]` your wording and her talk title |
| G3 | Pet-insurance knowledge (R9, important) | transferability | Motor only, confirmed | A recruiter screen is likely to raise it first | Small-book or thin-data modelling (young drivers are a niche segment); any non-motor exposure; self-study on pet rating factors | A short note on how you'd approach a pet rating structure | `[inferred]` bridge from your young-driver book; `[generic]` that domain switches get screened |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | One version may be outdated, or the pattern may have changed since one of them was posted | `[inferred]` from the two sources disagreeing | Is this role fully remote within the UK, or Leeds-based four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | JD gives no figure | The budget may sit anywhere in or outside the £52k–£65k band | `[inferred]` from the posting's silence, against the `[generic]` band | What base salary range is budgeted for this role? | unresolved |
| RR3 | Employer and posting verified; clear reporting line | positive_signal | — | "Accepting applications… reports to the Director of Pricing" | The role is real, live and placed in the organization | `[grounded]` careers page fetched | Who else sits in the pricing team today? | noted |
| RR4 | Ownership with no team or resources stated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only pricing analyst on the product | `[inferred]` from "own" with no team mentioned | Is this a solo role on the product, and what actuarial or data support is there? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern in writing before applying | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | For Odile Varga, lead with the young-driver GLM as a niche-book model you kept accurate over time, but only once G2 confirms you did the monitoring | Her published talk is on monitoring rating models in small books | `[grounded]` her public profile; R4, R5b | pending your approval |
| P2 | Name the pet gap yourself: "I've priced motor, not pet. The GLM and price-testing work is what carries over" | See R9 | `[grounded]` your message | pending your approval |
| Q1 | Ask the RR1, RR2, RR3 and RR4 questions word for word in the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the employer and the live posting (RR3) and turned up the location contradiction (RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary 2026 GLM remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). That gave the market calibration band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). That fed role reality and P1 |

If you'd like, I can save all of this as a `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- **Your location and pay constraints:** R1 settles (met or failed), and the salary band gets set against your floor.
- **Your CV:** every row's evidence gets a document behind it, and any line it buries gets flagged.
- **A sanitized artifact** (your quarterly pricing review deck, a price-test readout, or a model-monitoring pack): R5a, R6 and R7 can move to `high`.
- **Brindlemoor's answer on salary:** closes RR2.
- **A deeper research pass on Brindlemoor** (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**G1:** Can you work from a Leeds office four days a week, or do you need fully remote?

**G2:** When you maintained the young-driver GLM, did you track how it performed after go-live (actual vs expected, drift, loss ratio)? If so, what did you do when something slipped?

**RR2:** What's the lowest base salary you'd accept for a move?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.