I need to read the referenced files.
Now the worked report (I'll read the first part; reframing audit and citations are the rest).
## Decision snapshot

**Yes, it's worth going for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (monitor rating models)
- `important`: direct: R8a · adjacent: R9 (pet-insurance product knowledge) · unclear: R8b (recommendations for product)
- `preferred`: direct: R10

R9: motor pricing carries over, but you haven't priced pet. R6b and R8b: you may have this experience, but you haven't told me about it yet.

**Opportunity ledger.** Nothing wrong found, but nothing checked either: I couldn't confirm the employer (RR1), the pay isn't stated (RR2), and the team and who signs off pricing decisions aren't stated (RR3). One entry is positive: the role names concrete outputs (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're UK-based and can work here without sponsorship (R1); (2) the employer and the live posting check out (RR1); (3) you present pet as a move from motor, not as experience you already have (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD header; not checked, see RR1 |
| Mandate | Own pricing analytics for pet: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Line management | The JD lists no reports and no requirement to have managed people | `[grounded]` JD's requirements list |
| Scope read | An individual-contributor senior role with a product-level remit. "Own" suggests you'd be the pricing lead for one product, not one of several analysts on it | `[inferred]` from "own pricing analytics for our pet-insurance product" and the absence of any reports |
| Market calibration | Not available: the role-family search was refused in this session | — |
| Unknowns | Salary; team size; whether actuaries sit alongside; who signs off rate changes; size of the book | — |
| Contradictions | None within the JD; careers page not checked | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): UK-based, right to work | hard_gate | unclear | low | hard_gate | You work at a UK motor insurer, but you haven't stated your location or right to work | `[inferred]` from "a UK motor insurer" | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics… the last 2 as senior analyst" is above the bar; it's your own account, with nothing to inspect yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; how strong you are is what a technical round will test | `[grounded]` your background | Have a modelling or data-pipeline example ready |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "I present the quarterly pricing review to the head of underwriting" | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built one and maintained it | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include tracking performance, but you didn't say so. I'm reading it as the smaller claim until you confirm | `[grounded]` your wording | Q2 |
| R7 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." How much of the design was yours vs. underwriting's isn't stated | `[grounded]` your background | Have a split of what was yours ready (plan P3) |
| R8a | Recommendations to underwriting | important | direct | medium | none | Quarterly review to the head of underwriting plus joint tests | `[grounded]` your background | none |
| R8b | Recommendations to product | important | unclear | low | discovery | Your background names only underwriting as the audience | `[grounded]` your background is silent on product | Q3 |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Implied by "our pet-insurance product". What carries over: GLM rating and price testing on a personal-lines book. The limit: "never worked on pet insurance." `[generic]` Pet risk factors (breed, age, vet-cost inflation, cover types) differ from motor's | `[inferred]` the requirement, from the JD's product focus; `[grounded]` your statement | Bridge case in the application plan |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R6b, must_have) | discovery | You maintained the young-driver GLM; you haven't said whether you tracked its performance | It's half of a named responsibility, so it's likely to come up in interview | Actual-vs-expected or loss-ratio tracking by segment; checking for drift and deciding when to refit; a monitoring dashboard or monthly pack | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your wording; `[generic]` that monitoring is probed in pricing interviews |
| G2 | Recommendations to product (R8b, important) | discovery | Only underwriting appears as an audience | Product is a named audience in the mandate | Input on cover options, excesses or rollout of features; price-test results that changed a proposition; work with distribution or aggregator teams | A redacted recommendation note or deck | `[grounded]` your background's silence on product |
| G3 | Pet-insurance knowledge (R9, important) | transferability | Strong motor pricing record; no pet exposure | The likeliest objection to your application | Your GLM and test record; any work on another personal-lines product; any self-study on pet pricing | A short note on how you'd approach a pet rating structure | `[inferred]` bridge from motor; `[generic]` that domain switch is the likely objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company; searches were refused this session | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in JD) | The figure may be below the market band, or they may just not publish salaries | `[inferred]` from the missing figure; no band available to compare | What salary range is budgeted for this role? | unresolved |
| RR3 | Ownership without stated team or sign-off | unknown | — | "Own pricing analytics for our pet-insurance product" | You could be the sole pricing person, with no actuarial or analyst support | `[inferred]` from "own" against the JD's silence on team | Who else works on pet pricing, and who signs off rate changes? | unresolved |
| RR4 | Concrete, named outputs | positive_signal | — | "build and monitor rating models, design and read price tests… recommendations for underwriting and product" | The role is well defined and success can be measured | `[grounded]` JD | How do you measure success for this role in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own lines: "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team" | see R4, R7 | `[grounded]` your background | pending your approval |
| P2 | Name the domain switch yourself: motor rating and testing experience, no pet experience yet. Don't claim pet knowledge | see R9 | `[grounded]` your statement | pending your approval |
| P3 | Before interviews, write out which parts of the 14 tests were yours (hypothesis, test design, sample sizing, reading the results) and which were underwriting's | see R7 | `[grounded]` your wording leaves this open | pending your approval |
| P4 | Don't bring up management. It isn't asked for, and adding it would claim something you haven't done | see role reality, line management | `[grounded]` JD | pending your approval |
| P5 | Confirm the live posting on Brindlemoor's own careers page before you spend effort on the application | see RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Ask the RR2–RR4 questions word for word in interviews | the register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance". The search permission was refused. It would have checked the company and posting (RR1, role reality) |
| 2. Role-family sweep | unavailable | Searched "Senior Pricing Analyst insurance UK salary remote GLM". The search permission was refused. It would have given the market calibration and a salary band for RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor". The search permission was refused. It would have helped pick which story to lead with for that reader |

I can write all of this up as a `tuesday-dossier.md` if you'd like a file to carry into the next steps.

**Upgrade menu**
- Allow web search, and I'll rerun targets 1–3. That would check the employer (RR1), add a salary band (RR2) and sharpen P1.
- Your salary floor and any other non-negotiables would add gate rows and remove the "constraints not given" flag.
- A sanitized monitoring pack or recommendation note would raise R6b and R8b, and could lift some rows to `high`.
- A deeper research pass on Brindlemoor (funding, leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs once search is allowed.

**Questions**

Q1 (R1): Are you based in the UK with the right to work here without sponsorship?

Q2 (R6b): Once the young-driver GLM was live, did you track how it performed (actual vs. expected, drift, when to refit), and what did that involve?

Q3 (R8b): Have any of your pricing or test results gone to product teams, for example on cover options or excess levels?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.