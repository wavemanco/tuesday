Now the required references.
I looked at both. The Duinvaart role is worth applying to. The Kroonhaven role mostly isn't. I couldn't check either company because the web searches weren't permitted, so nothing below is verified against their own sites.

## Decision snapshots

### A. Operations Analyst, Duinvaart Cold Chain

**Yes, this one is worth your time, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: A-R1 (hybrid, three days a week in Rotterdam office)
- `must_have`: direct: A-R2, A-R3, A-R4
- `important`: direct: A-R5, A-R7 · adjacent: A-R6 (temperature compliance across refrigerated fleet)
- `preferred`: direct: A-R8

A-R6: a credible bridge from on-time compliance work, with its cold-chain limit named; A-R2 (`medium`), A-R3 (`medium`), A-R4 (`medium`): stated in your message, but no CV or artifact seen yet.

**Opportunity ledger.** I couldn't confirm the employer or that the posting is live (RA1). Salary and level aren't stated (RA2, RA4). On the plus side, the posting names concrete metrics, tools and working partners (RA3).

- **Hard gates:** none failed; unconfirmed: A-R1 (hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) three days a week in Rotterdam works for you (A-R1); (2) Duinvaart and the posting check out on its own site (RA1); (3) you present temperature compliance as adjacent experience, not as cold-chain experience (A-R6).

### B. Supply Planner, Kroonhaven Foods

**No, not as posted. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: B-R1 (on-site in Utrecht)
- `must_have`: adjacent: B-R2 (fluent Dutch), B-R5 (run the weekly S&OP meeting) · unclear: B-R6 (advanced Excel), B-R7 (SAP IBP or a similar planning system) · absent: B-R3 (3+ years of supply or demand planning in FMCG), B-R4 (own the 13-week supply plan)

B-R3, B-R4: capability gaps at the core of the role, by your own account; B-R2: conversational Dutch against a "fluent" requirement, which wording can't close.

**Opportunity ledger.** I couldn't confirm the employer (RB1), and the salary is unstated (RB2). The mandate itself is concretely defined (RB3).

- **Hard gates:** none failed; unconfirmed: B-R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would have to differ:** you have planning work you haven't mentioned (B-R3, B-R4); Kroonhaven hires this role at a junior level that trains people in; your Dutch is at working fluency (B-R2).

---

## A. Duinvaart Cold Chain: Operations Analyst

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; runs a refrigerated fleet | `[grounded]` JD header and text |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An individual-contributor analyst role; "2+ years" suggests mid-level, below your 4 years | `[inferred]` from the experience ask and the absence of any team or leadership language |
| Unknowns | Salary; level and who it reports to; size of fleet and number of depots; whether the employer exists as described | — |
| Contradictions | None within the posting | `[grounded]` JD |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A-R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | low | hard_gate | Your last job was in Amsterdam, but you haven't said where you live or whether a Rotterdam commute works | `[grounded]` your message; silent on commute | Closing question 1 |
| A-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier. Stated in prose, no CV seen, so `medium` is the ceiling | `[grounded]` your message | Make sure your CV states the title and dates |
| A-R3 | Strong SQL | must_have | direct | medium | none | "SQL … daily", specific but self-reported | `[grounded]` your message | Expect a technical probe or SQL test |
| A-R4 | Power BI or Tableau; weekly Power BI dashboards | must_have | direct | medium | none | Power BI daily, including a dashboard depot managers use | `[grounded]` your message | A sanitized dashboard screenshot would raise this to high |
| A-R5 | Track on-time delivery across the fleet | important | direct | medium | none | You work on the on-time delivery dashboard depot managers use. You didn't say whether you built it, maintain it or report from it | `[grounded]` your message | Be ready to say exactly which part was yours |
| A-R6 | Track temperature compliance across a refrigerated fleet | important | adjacent | medium | transferability | What carries over: tracking compliance against a threshold, per vehicle and route, for depot managers. Limit: nothing stated touches temperature data, reefer telematics or food-safety rules. Cold-chain analyst roles usually involve that sensor and regulatory context `[generic]` | `[grounded]` your message; `[generic]` cold-chain context | See GA1 |
| A-R7 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your on-time dashboard. Whether the reviews led to route changes isn't stated | `[grounded]` your message | Have one concrete review-to-change example ready |
| A-R8 | Dutch a plus | preferred | direct | medium | none | Conversational Dutch meets a "plus" that sets no level | `[grounded]` your message and JD | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A-R6, important) | transferability | Strong on-time compliance work; no temperature or cold-chain data mentioned | Half of the role's tracking mandate is temperature compliance, so it's the likeliest probe | Parcels with handling or temperature requirements (pharma, food, perishables); any vehicle sensor or telematics feed you queried; exception or claims reporting tied to damaged goods | A dashboard page or SQL query on sensor or exception data (sanitized) | `[grounded]` your message; `[generic]` that this is the likeliest probe |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RA2 | Salary not stated | unknown | — | (no pay language in posting) | The figure may fit your expectations or fall short; the posting gives nothing to judge by | `[inferred]` from the posting's silence on pay | What salary range is budgeted for this role? | unresolved |
| RA3 | Concrete metrics, tools and partners named | positive_signal | — | "on-time delivery and temperature compliance … Power BI … depot managers" | The role's scope is defined and measurable | `[grounded]` JD | Which compliance metric is the biggest problem right now? | noted |
| RA4 | Level possibly below your experience | unknown | — | "2+ years in logistics or operations analysis" | The role may be levelled and paid for someone with less experience than your 4 years | `[inferred]` from the experience ask against your 4 years | What level is this role, and who does it report to? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm Duinvaart and this posting on its own website before spending real time | see RA1 | `[grounded]` RA1 | pending your approval |
| P2 | Lead with the on-time delivery dashboard depot managers use and the weekly route-performance review you ran, worded as you stated them | see A-R5, A-R7 | `[grounded]` your message | pending your approval |
| P3 | Present cold chain honestly: compliance tracking transfers, temperature data is new to you | see A-R6 | `[grounded]` A-R6 row | pending your approval |
| P4 | Ask the RA2 and RA4 questions at the first recruiter call | see RA2, RA4 | `[grounded]` register | pending your approval |

---

## B. Kroonhaven Foods: Supply Planner

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; a chilled ready-meals range | `[grounded]` JD |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run weekly S&OP | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A planning-function owner role that expects someone already practised in planning cycles | `[inferred]` from "own", "run" and "3+ years of supply or demand planning" |
| Unknowns | Salary; level; team size; whether the employer exists as described | — |
| Contradictions | None within the posting | `[grounded]` JD |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B-R1 | On-site in Utrecht | hard_gate | unclear | low | hard_gate | No commute or location constraint stated | `[grounded]` your message; silent on commute | Settle it only if B becomes live |
| B-R2 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, in your own words. Limit: running a weekly S&OP meeting fluently in Dutch is beyond what you've stated | `[grounded]` your message and JD | Not closable by wording; closing it means language study |
| B-R3 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You stated you've never worked in planning, and a parcel carrier isn't FMCG | `[grounded]` your message | Closure path in plan P6 |
| B-R4 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning ownership stated; analysis work feeds plans but isn't owning one | `[grounded]` your message | Carried as material risk |
| B-R5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | What carries over: running a weekly performance review. Limit: S&OP is a cross-functional decision forum (demand, supply, finance) `[generic]`, and your review was route performance | `[grounded]` your message; `[generic]` S&OP format | none while `no_go` |
| B-R6 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned; SQL and Power BI don't establish it | `[grounded]` silence in your message | Only matters if B becomes live |
| B-R7 | SAP IBP or a similar planning system | must_have | unclear | low | discovery | Not mentioned; having never worked in planning makes a planning system unlikely, but SAP exposure elsewhere is possible | `[inferred]` from your stated history | Only matters if B becomes live |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GB1 | Planning ownership (B-R3, B-R4, must_have) | capability | You said you've never worked in planning | These two rows are the core of the role and drive the `no_go` | Not asked, because you've already answered it | — | `[grounded]` your message |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RB2 | Salary not stated | unknown | — | (no pay language in posting) | Pay can't be judged from the posting | `[inferred]` from the posting's silence on pay | What salary range is budgeted for this role? | unresolved |
| RB3 | Defined horizon and cadence | positive_signal | — | "13-week supply plan … weekly S&OP meeting" | Success is measurable and the rhythm is clear | `[grounded]` JD | Who attends S&OP, and who makes the final call? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P5 | Spend your time on A and similar analyst roles rather than on B | see B-R3, B-R4, B-R2 | `[grounded]` B map rows | pending your approval |
| P6 | If you want to move into planning later, look for junior or assistant planner roles or English-language planning teams, where planning experience is built on the job | closure path for B-R3, B-R4 | `[generic]` role-family pattern | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both refused (search permission not granted). Would have cleared RA1 and RB1 and filled the organization rows |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary Power BI SQL" and "supply planner FMCG Netherlands salary S&OP"; both refused. Would have added market calibration and salary bands to role reality, RA2, RA4 and RB2 |
| 3. Hiring manager's public footprint | n/a | No name given for either role |

I can write all of this up as a `tuesday-dossier.md` file if you'd find that useful.

**Upgrade menu**
- Allow web search → I can check whether both employers exist and the postings are live (clears or confirms RA1 and RB1), and add salary bands for both titles.
- Your CV → raises A-R2, A-R3 and A-R4 above self-report and shows how your current wording reads against posting A.
- A sanitized screenshot of the on-time dashboard → A-R4 and A-R5 to `high`.
- An answer to GA1 → strengthens or resolves A-R6.
- Your pay floor and location → settles A-R1 and B-R1, and lets the salary questions be judged against a number.
- The hiring manager's name for A → which of your stories to lead with for that reader.
- A deeper research pass on both companies (leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

A-R1: Would three days a week in the Rotterdam office work from where you live?

GA1: Did any of your parcel work involve temperature-controlled or handling-sensitive shipments, or vehicle sensor or telematics data you queried?

Constraints: Is there a salary floor, or another term (location, contract type, start date), you won't go below?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.