Still reading the job-check playbook's rules so I can answer you properly. Nearly there.
**Yes, this is normal.** Employers ask for bank details, your PPS number and a passport scan after they've made you a written offer, and that's what has happened here. The advice you were given is about people asking *before* an offer, or senders you can't trace. Your offer names the role, the pay and your manager. It came from the employer's own domain after two in-person interviews at their office. My recommendation is `conditional_go`: accepting looks sound, with the conditions below.

I tried three web searches to confirm the employer, check typical pay and look up the hiring manager, but all three were blocked because web search wasn't allowed in this session. So I'm going only on what you pasted.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R10 (Hybrid, two days a week in our Limerick office), R11 (€40,000 a year), R12 (right-to-work check)
- `must_have`: direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI and USC)
- `important`: direct: R6, R8 · adjacent: R5 (monthly payroll for 240 staff) · unclear: R9 (answer staff payroll queries) · absent: R7 (pension changes)

R7: a real gap, worth raising before you start; R2: probably settled by one answer; R5: the same work at a bigger scale on a monthly cycle.

**Opportunity ledger.** RR2 and RR3 are in your favour: a written offer that names the role, pay and manager, with pay inside the advertised band. RR1 is open only because my searches were blocked.

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days a week in our Limerick office), R11 (€40,000 a year), R12 (right-to-work check); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm the employer is the one you visited (RR1). Their own website and the office where you interviewed settle this.
  2. The office days, pay and right to work suit you (R10, R11, R12).
  3. You raise the pension-changes gap (R7) so training is planned, not discovered on payroll day.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` job ad |
| Terms offered | Permanent, €40,000 a year, reporting to Declan Garvagh (Finance Manager), hybrid with two days a week in Limerick, start date agreed after your notice period | `[grounded]` offer email |
| Onboarding | After you accept: a portal link for bank details, PPS number and a passport scan; original passport on day one | `[grounded]` offer email |
| Scope read | A step up in volume (240 staff vs 90) and a change of cycle (monthly vs fortnightly). It's the same kind of work, not a more senior job | `[inferred]` from the ad against your background |
| Unknowns | Payroll software; pension scheme(s) and how changes are handled; when the written contract arrives | n/a |
| Contradictions | None. Ad and offer agree on hybrid working and Limerick, and €40,000 sits inside the €38,000–€42,000 band | `[grounded]` ad and offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years running fortnightly payroll, as you described it. Specific, but nothing inspectable yet | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say whether the hotel payroll was run under Irish PAYE, PRSI and USC. Likely, but not stated | `[grounded]` background silent on jurisdiction | Question R2 below |
| R3 | Strong Excel | must_have | direct | medium | none | Excel daily, pivot tables and XLOOKUP | `[grounded]` your background | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R5 | Run the monthly payroll for 240 staff | important | adjacent | medium | transferability | Same core work, but 90 staff on a fortnightly cycle. Limit: not yet at 240 or on a monthly run | `[grounded]` your background; `[inferred]` that the core work carries over | Gap G2 |
| R6 | Process starters and leavers | important | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R7 | Process pension changes | important | absent | none | capability | You've never done these yourself; your manager handled them | `[grounded]` your own words | Gap G3: raise it with your manager-to-be |
| R8 | Reconcile payroll to the general ledger each month | important | direct | medium | none | You did the monthly payroll-to-ledger reconciliation | `[grounded]` your background | none |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` background silent | Question R9 below |
| R10 | Hybrid, two days a week in our Limerick office | hard_gate | unclear | none | hard_gate | You attended in person twice, but haven't said whether two days a week suits you | `[grounded]` ad and offer; constraint not stated | Question R10–R12 below |
| R11 | €40,000 a year | hard_gate | unclear | none | hard_gate | No salary floor stated | `[grounded]` offer; constraint not stated | Question R10–R12 below |
| R12 | Right-to-work check | hard_gate | unclear | none | hard_gate | The offer includes a right-to-work check; your status isn't stated | `[grounded]` offer; status not stated | Question R10–R12 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R2, must_have) | discovery | Three years of payroll, jurisdiction not stated | A must-have; one answer probably closes it | Handling Revenue payroll notifications, emergency tax, USC bands or PRSI classes; your Payroll Technician syllabus | Certificate syllabus, a redacted payslip layout you built | `[grounded]` background silent |
| G2 | Monthly payroll for 240 staff (R5, important) | transferability | 90 staff, fortnightly | Volume and cycle are what change on day one | Peak-season headcount at the hotel; multi-site runs; month-end reconciliation volume | None needed | `[inferred]` core work carries over; limit is scale and cycle |
| G3 | Pension changes (R7, important) | capability | No hands-on experience | A named part of the job | Closure path: ask how pension changes are handled and whether shadowing or training is planned in your first months; a pensions module in further payroll study | Training plan, once agreed | `[grounded]` your own words |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not confirmed from outside sources (my searches were blocked) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The organisation may be too new or small to have a footprint, the posting may be old or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this one | Can you confirm the onboarding portal's address so I can match it to your website? | unresolved |
| RR2 | Written offer names role, pay, manager and terms | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | Terms are concrete and match the ad | `[grounded]` offer and ad | When will I receive the written contract? | noted |
| RR3 | Salary published in the ad, and the offer sits inside it | positive_signal | — | "Salary €38,000–€42,000" | Pay is transparent | `[grounded]` ad and offer | Is there a salary review after probation? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter your bank details, PPS number and passport scan only in the portal, and check its link leads to the employer's own site (the web address marrowgatehousing.ie's website gives) before typing anything. Don't send them by plain email | It's the one check that matters for routine onboarding | `[generic]` standard onboarding practice | pending your approval |
| A2 | When you reply to accept, ask when the written contract will arrive | see RR2 | `[grounded]` offer silent on the contract | pending your approval |
| A3 | Raise pension changes with Declan Garvagh, either before you start or in week one, and ask how training is planned | see R7, G3 | `[grounded]` your own words | pending your approval |
| Q1 | Ask the RR1–RR3 verification questions | They close the open items | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; blocked because web search wasn't allowed. Would have confirmed the employer and the posting, closing RR1 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026 Limerick"; blocked because web search wasn't allowed. Would have set €40,000 against typical pay |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; blocked because web search wasn't allowed. Would have informed the scope read |

I can save all this as a `tuesday-dossier.md` you can pick up later, if that's useful.

## Upgrade menu

- **Allow web search:** targets 1–3 run. RR1 closes if the employer checks out, and a typical-pay line appears in role reality.
- **Your answer on R2:** settles a must-have.
- **Your answer on R10–R12:** the hard-gates line resolves.
- **A deeper research pass:** board and staff changes, regulator listings and news. That's up to 5 more searches and 2 more fetches; say the word and it runs.

## Questions

- **R2:** Was the hotel group's payroll Irish payroll (PAYE, PRSI and USC through Revenue), and which parts of it did you handle yourself?
- **R10–R12:** Do the two Limerick office days, the €40,000 salary and your right to work in Ireland all suit you as they stand?
- **R9:** Did your hotel role include answering staff payroll queries?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.