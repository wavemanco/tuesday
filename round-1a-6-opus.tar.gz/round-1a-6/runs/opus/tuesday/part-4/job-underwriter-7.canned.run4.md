I'm reading the assessment playbook's worked example. The full verdict on the Calderbrook role follows.
**Yes, it's worth applying for. Status: `conditional_go`.** You meet both essentials that are pass/fail (registration and licence). What's left is to show in your application evidence the CV doesn't yet give.

Your National Insurance number isn't needed for this assessment, so I haven't used it. You don't need it on the CV you send either.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5a, R8, R10 · adjacent: R6 (Catheter and continence care), R11 (A small caseload of your own) · unclear: R5b (Leg-ulcer care), R7 (End-of-life visits), R9 (Care planning)
- `preferred`: absent: R12 (Doppler assessment)

R4: your CV doesn't mention record-keeping, and that's the condition below; R11: your discharge-to-assess home visits are a credible bridge, with its limit named; R12: a desirable skill you don't have, with a training route.

**Opportunity ledger.** This looks like a sound, well-supported post. The pay sits in the normal range (RR1), mileage and pool cars are provided (RR2), the caseload comes with senior support (RR3), and the team lead has spoken publicly about Doppler training for nurses new to community work (RR4). One thing is open: I couldn't find the vacancy on the employer's careers page (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your application shows electronic record-keeping evidence (R4); (2) the vacancy is confirmed live (RR5); (3) the caseload and Doppler points are described honestly: you have adjacent experience and no Doppler experience, never more than that (R11, R12).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` advert header; employer's About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all on an electronic patient record | `[grounded]` advert |
| Scope | Band 5, a small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | A normal entry-level community post. The senior support suggests they expect people new to holding a caseload | `[inferred]` from "supported by a senior community nurse" at Band 5 |
| Market calibration | The survey puts community staff nurse Band 5 pay in England at a median of £34,300 (middle half £32,400–£36,600). The advert's £31,050–£37,800 spans that range. That's a market pattern, not this employer's offer to you | `[generic]` Wardround 2026 pay guide; `[grounded]` advert, for the posted band |
| Unknowns | Whether the vacancy is live and when it closes; what the caseload support looks like in practice; whether Doppler training is offered | — |
| Contradictions | None found between the advert and the About page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Your CV states active Adult registration, with revalidation due March 2028. You've stated it, but I haven't checked it | `[grounded]` CV | Check your own entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV states a full UK category B licence, which covers a pool car. Stated, not checked | `[grounded]` CV | Check your own driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward is well over the minimum. It comes from your CV, so expect it to be probed | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | Your CV says nothing about documentation, an EPR system or care records. It's very likely part of a ward and D2A role, but nothing here shows it yet | `[grounded]` CV silent; `[inferred]` that the work involved it | G1 |
| R5a | Wound care: pressure ulcers and surgical wounds | important | direct | medium | none | Stated in your CV in the advert's own terms | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Your CV lists pressure ulcers and surgical wounds. Leg ulcers aren't mentioned, and I won't widen your claim to cover them | `[grounded]` CV | G2 |
| R6 | Catheter and continence care | important | adjacent | medium | transferability | Catheter care is stated. Wider continence assessment and management isn't | `[grounded]` CV | G6 |
| R7 | End-of-life visits | important | unclear | low | discovery | Your CV doesn't mention it. Acute medical wards often care for dying patients, but that's a lead, not evidence | `[grounded]` CV silent; `[generic]` that acute medical wards often do | G3 |
| R8 | Insulin administration | important | direct | medium | none | Stated in your CV | `[grounded]` CV | none |
| R9 | Care planning | important | unclear | low | discovery | Your CV doesn't mention it | `[grounded]` CV silent | G4 |
| R10 | Caring for adults in their own homes | important | direct | medium | none | 18 months of D2A home visits in patients' first week after discharge | `[grounded]` CV | none |
| R11 | Holding a small caseload of your own, with support | important | adjacent | medium | transferability | You visited patients at home and managed a ward allocation. Limit: you've told me you've never held your own caseload, so the ongoing accountability is new | `[grounded]` your own statement and CV | G5 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've told me you've never done one. It's listed as desirable, not essential | `[grounded]` your own statement | G7, closure path |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records (R4, must_have) | discovery | Your CV doesn't mention documentation | It's the only must-have below `direct`; closing it removes condition 1 | Documenting care on the hospital's EPR; D2A visit notes and handover to GPs or community teams; risk assessments, wound charts or care-plan updates you wrote | The EPR system's name and what you recorded on it. Never patient records | `[grounded]` CV silent |
| G2 | Leg-ulcer care (R5b) | discovery | Pressure and surgical wounds only | It's the advert's first-listed task | Dressing or bandaging leg ulcers on the ward; seeing leg ulcers on D2A visits; compression bandaging | A training certificate or competency sign-off | `[grounded]` CV |
| G3 | End-of-life (R7) | discovery | Not mentioned | A named part of the visiting work | Caring for dying patients on the ward; syringe drivers; supporting families; anticipatory medicines | An end-of-life or syringe-driver competency | `[generic]` acute ward pattern |
| G4 | Care planning (R9) | discovery | Not mentioned | Part of running a caseload | Writing or updating care plans; D2A goal-setting | — | `[grounded]` CV silent |
| G5 | Own caseload (R11) | transferability | D2A home visits; a ward allocation | Bridge: home visiting and working alone. Limit: no ongoing caseload accountability. Strengthener: describe how you planned and prioritised D2A visits | Prioritising a day's visits; escalating concerns from a home visit | — | `[grounded]` your statement |
| G6 | Continence (R6) | transferability | Catheter care only | Small gap | Continence assessments; bladder and bowel care on the ward | — | `[grounded]` CV |
| G7 | Doppler (R12, preferred) | capability | None | Desirable only. The team lead has spoken on Doppler training for staff new to community work (RR4) | Ask about training in the informal chat | — | `[grounded]` forum speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, in the normal range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posted band spans the surveyed range for this title | `[generic]` Wardround 2026 band; `[grounded]` advert figure | Where on the band would someone with five years' acute experience start? | noted |
| RR2 | Pool cars and mileage provided | positive_signal | — | "pool cars are provided" | You won't need your own car for work | `[grounded]` advert | Are pool cars available every shift, or shared across the team? | noted |
| RR3 | The caseload comes with senior support | positive_signal | — | "supported by a senior community nurse" | The post is set up for people new to holding a caseload | `[inferred]` from the advert's wording | What does that support look like in your first three months? | noted |
| RR4 | The team lead has spoken on Doppler training for nurses new to community work | positive_signal | — | Forum speaker page, 2025 | Doppler training may be available, which would cover R12 | `[grounded]` speaker page; `[inferred]` that it applies to this post | Would Doppler training be part of my induction? | noted |
| RR5 | Vacancy not found on the employer's careers page | unknown | — | Careers page returned no page | The page may have moved, the vacancy may be advertised elsewhere (for example NHS Jobs), or it may have closed | `[generic]` patterns, none ranked | Is the post still open, and when is the closing date? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott. Confirm the post is open and ask the RR1–RR5 questions | Closes RR5 and the unknowns | `[grounded]` advert offers the chat | pending your approval |
| A2 | Check your NMC register entry and your driving record before applying | R1, R2 | `[grounded]` CV | pending your approval |
| E1 | Lead your supporting statement with the D2A home visits, described as exactly that: visiting patients at home in their first week after discharge, never as holding a community caseload | R10, R11 | `[grounded]` CV | pending your approval |
| E2 | Say plainly that you haven't done Doppler assessment yet and want to train | R12, RR4 | `[grounded]` your statement | pending your approval |

Any wording above is a proposal. Nothing goes into your application until you approve it. If you want the CV itself tailored to this post, resume-tailor does that.

## Evidence status

Verified: none yet.

Research tier: L1, searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. This gave the Organization and Contradictions rows and RR5 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026/27 community staff nurse district nursing", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). This gave the market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned her speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). This gave RR4 and G7 |

If you'd like, I can save all of this as a `tuesday-dossier.md` file for later steps.

**Upgrade menu**
- Answers to G1–G3 would update R4, R5b and R7 and could remove condition 1.
- Your non-negotiables (hours, shift pattern, pay floor, travel within Calderdale) would let me check the post against them.
- The live vacancy link or closing date would close RR5.
- A deeper research pass (CQC or inspection reports, staff reviews, recent news; up to 5 more searches and 2 more fetches) would fill out the risk register. Just say if you want it.

**Questions**

G1: On the ward or on D2A visits, what did you record, on which electronic system, and did anyone ever audit or comment on your notes?

G2: Have you dressed or bandaged leg ulcers, or done compression bandaging, even occasionally?

G3: Have you cared for patients at the end of life? For example, syringe drivers, anticipatory medicines or supporting families.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.