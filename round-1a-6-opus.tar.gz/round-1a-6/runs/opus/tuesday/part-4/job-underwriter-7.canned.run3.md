I'm running the job-underwriter check now: next I'll look up the employer and the Band 5 pay scale online.
I ran the job-underwriter check on the advert and your CV: 3 web searches and 1 page fetch.

## Decision snapshot

**Yes, it looks worth applying for, with the two conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records on an electronic patient record)
- `important` — direct: R5a, R6a, R8, R11 · adjacent: R10 (Hold a small caseload of your own) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R9 (Care planning)
- `preferred` — absent: R12 (Doppler assessment for leg ulcers)

R4 — your CV doesn't mention record-keeping, and it's the one must-have you still need to show; R10 (`medium`) — your discharge-to-assess home visits lead towards holding a caseload, but you haven't held one; R12 — missing, but only desirable.

**Opportunity ledger.** In the role's favour: the pay is stated (RR2), pool cars and mileage are provided (RR3), the caseload comes with named senior support (RR1), and the team lead has spoken publicly on Doppler training for staff new to community work (RR5). Still open: I couldn't find the advert on the employer's own careers page (RR4), and the working pattern isn't stated (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can describe your record-keeping in concrete terms, ideally including electronic records (R4, G1); (2) the post is confirmed as currently open (RR4); (3) you describe your discharge-to-assess visits as home visiting and never as holding a caseload (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the employer's About page (search result) |
| Mandate | District nursing for housebound adults: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all recorded on an electronic patient record | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay and travel | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | A pay guide for England's Band 5 community staff nurses gives a median of £34,300 (middle half £32,400–£36,600). The advert's range brackets that, so it isn't below market. The guide is a pattern, not this employer's offer | `[generic]` Wardround 2026 UK Community Nursing Pay Guide; `[grounded]` advert figure |
| Hiring lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; in 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` community nursing forum speaker page |
| Unknowns | Shift pattern and weekend rota; how the caseload is built up for someone new; where on the pay range you'd start; whether the post is live | — |
| Contradictions | None between the advert and the employer's About page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states active Adult registration, revalidation due March 2028. You've stated it, but nobody has checked it | `[grounded]` CV | Check your own entry on the NMC register is current |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Stated, not checked | `[grounded]` CV | Check your own DVLA driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse is well over the bar | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | none | discovery | The CV says nothing about record-keeping or which record systems you've used | `[grounded]` CV silent | See G1 |
| R5a | Wound care | important | direct | medium | none | CV: "wound care including pressure ulcers and surgical wounds" | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Your CV's wound-care list ("including…") doesn't name leg ulcers, which leaves room for them. Low, not none | `[grounded]` CV wording | See G2 |
| R6a | Catheter care | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | none | discovery | CV names catheter care only, and catheter care isn't widened to cover continence here | `[grounded]` CV silent | See G5 |
| R7 | End-of-life visits | important | unclear | none | discovery | CV silent | `[grounded]` CV silent | See G3 |
| R8 | Insulin administration | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R9 | Care planning | important | unclear | none | discovery | CV silent | `[grounded]` CV silent | See G4 |
| R10 | Hold a small caseload of your own | important | adjacent | medium | transferability | Home visits in patients' first week after discharge carry over. Limit: you say you've never held your own caseload | `[grounded]` CV and your own statement | See G6 |
| R11 | Caring for adults in their own homes | important | direct | medium | none | 18 months seconded to discharge-to-assess, visiting patients at home | `[grounded]` CV | none |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. It's only desirable | `[grounded]` your own statement | See G7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records on an EPR (R4, must_have) | discovery | No mention of documentation or record systems | A must-have, and closing it removes condition (1) | Writing up home visits for the discharge-to-assess team; ward notes, care-plan updates or referrals on an electronic system; any audit of notes you took part in | Reflective accounts from your revalidation portfolio; an appraisal comment on documentation | `[grounded]` CV silence; `[inferred]` that closing it moves the status |
| G2 | Leg-ulcer care (R5b) | discovery | Wound care listed without leg ulcers | A core part of the work and the hiring lead's own specialism | Dressing venous or mixed ulcers at home or on the ward; applying compression bandaging; referrals to tissue viability | A tissue-viability or compression competency sign-off | `[grounded]` CV wording; `[grounded]` lead's talk topics |
| G3 | End-of-life visits (R7) | discovery | CV silent | Named in the advert's duties | Caring for dying patients on the ward; just-in-case meds; visits after discharge home to die | A palliative care study-day certificate | `[grounded]` CV silence |
| G4 | Care planning (R9) | discovery | CV silent | Goes with holding a caseload | Writing or reviewing care plans for discharge-to-assess patients; setting goals at the first home visit | Revalidation reflective account | `[grounded]` CV silence |
| G5 | Continence care (R6b) | discovery | Catheter care only | Named in the advert's duties | Continence assessments; product reviews; bowel care | Training record | `[grounded]` CV silence |
| G6 | Own caseload (R10) | transferability | Home visits, no caseload | Carries over: home-based, independent visits. Limit: deciding visit frequency, prioritising and discharging patients across a caseload. Strengthener: be specific about what you decided on your own during visits | Anything you decided alone on a visit | — | `[grounded]` CV and your own statement |
| G7 | Doppler (R12) | capability | Never done | Desirable only. The way to close it is training, and the hiring lead has spoken on Doppler training for staff new to community work | — | — | `[grounded]` your own statement; `[grounded]` forum page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload with named senior support | positive_signal | — | "a small caseload of your own, supported by a senior community nurse" | The role is pitched at someone stepping up to their own caseload | `[grounded]` advert | How is the caseload built up for someone new to holding one, and how often does the senior nurse review it? | noted |
| RR2 | Pay stated and in market range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is transparent and not below the market band | `[grounded]` advert; `[generic]` pay guide band | Where on the range would five years' post-registration experience start? | noted |
| RR3 | Pool cars plus mileage | positive_signal | — | "pool cars are provided" | Travel costs are covered | `[grounded]` advert | Is a pool car guaranteed each shift, or do staff use their own car on mileage when none is free? | noted |
| RR4 | Post not found on the employer's careers page | unknown | — | "Current vacancies are listed on our careers page" | The careers page address I tried returned no page, so whether the post is still open isn't established | `[grounded]` fetch returned no page | Is this post currently open, and where is it advertised? | unresolved |
| RR5 | Hiring lead with a public interest in Doppler training | positive_signal | — | "Doppler training for staff new to community work" | Your Doppler gap may be one the team expects to train | `[grounded]` forum speaker page | Is Doppler training offered to new starters, and when? | noted |
| RR6 | Working pattern unstated | unknown | — | (advert silent) | Shifts, weekends and bank holidays aren't stated | `[grounded]` advert silent | What's the shift pattern, and how often are weekends and bank holidays worked? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and DVLA record are current | R1, R2 | `[grounded]` CV | pending your approval |
| A2 | Book the informal chat the advert offers with Rhiannon Mabbott, and ask the questions for RR1, RR4, RR5 and RR6 | It confirms the post is open (RR4) and tests the support around the caseload | `[grounded]` advert invites the chat | pending your approval |
| E1 | Open your supporting statement with the 18 months on discharge-to-assess, in your own words: "visiting patients at home in their first week after discharge", not "community caseload" | R11, R10 | `[grounded]` CV | pending your approval |
| E2 | Say plainly that you haven't yet held your own caseload or done a Doppler assessment, and (only if true) that you'd welcome Doppler training | R10, R12; it fits the support the advert describes | `[grounded]` your own statements; `[grounded]` RR1, RR5 | pending your approval |

## Evidence status

Verified: none yet. You included your National Insurance number. It isn't needed for this, and I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). It set the organization row. Fetched calderbrookhealth.example/careers, which returned no page, giving RR4 |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay 2025/26 £31,049 £37,797", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It set the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It set the hiring-lead row, RR5 and G7 |

I can save all of this as a `tuesday-dossier.md` file if you'd like to keep it.

**Upgrade menu**
- Your answer to G1, or reflective accounts from your revalidation portfolio → R4 closes and condition (1) clears.
- A compression or tissue-viability competency sign-off → R5b could move to `direct`.
- A live link to the advert on Calderbrook's own site → RR4 closes.
- Your non-negotiables (hours, weekends, pay floor) → the hard-gates line can check against them instead of reading "unknown".
- A deeper research pass on Calderbrook (inspection reports, staff reviews, recent news): up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

G1 — In discharge-to-assess or on the ward, how did you write up visits and care, and on which electronic record system?
G2 — Have you dressed leg ulcers or applied compression bandaging, at home or on the ward?
G4 — Did you write or review care plans for discharge-to-assess patients?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.