Now the files named at Step 1.
I'm checking whether Velloway Logistics can be found online. The full assessment comes right after.
**No, don't go ahead. The requests in these messages are very likely a scam. Don't send your IBAN, PPS number or passport photo, don't pay anything, and don't lodge the cheque. Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year pay floor)
- `must_have`: direct: R3 · adjacent: R2 (Strong attention to detail) · unclear: R4 (Good written English), R5 (A quiet place to work)
- `important`: adjacent: R6 (Processing orders)

R1: reachable only near the top of the hours range; R2, R6: credible bridges from parcel-courier customer service; R4, R5: not yet stated.

**Opportunity ledger.** The messages ask you for bank, tax and ID details before any offer (RR1). They ask you to pay for equipment (RR2) and to lodge a cheque and pass most of it on (RR3), and the whole process runs only on Telegram (RR4). I couldn't establish the employer (RR5), and the pay is stated as "up to" (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year pay floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer from an employer whose own website confirms the role, interviews held somewhere you can place, and no request for money, a cheque deposit, or bank, tax or ID details before that offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" | `[grounded]` posting. I couldn't find it in two searches (RR5) |
| Mandate | Remote order processing, 15–30 hours a week, own hours | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission". At €26 that is about €20,280 a year for 15 hours a week and €40,560 for 30 hours. Your €30,000 needs about 22 hours a week at the full rate | `[grounded]` posting; the arithmetic is mine |
| Process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Order processing and customer operations coordinators in Ireland: median base €31,200, middle half €28,400–€34,100, salaried roles only. This is a market band, not an offer from this employer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |
| Unknowns | Whether the employer exists as described; guaranteed hours; the actual hourly rate; employment basis | none |
| Contradictions | The posting promises "full training provided" but has no calls or video at any stage | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year pay floor (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The fit is unclear because "up to €26" with 15–30 hours spans about €20k–€40k, so the posting doesn't settle it | `[grounded]` your statement and the posting | Only a credible written offer with a fixed rate and hours would settle it |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day for 3 years shows careful, high-volume handling. Limit: ticket work isn't order data entry | `[grounded]` your background | none, given the decision |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. That's self-reported, with no inspectable file | `[grounded]` your background | none |
| R4 | Good written English | must_have | unclear | low | discovery | Your background doesn't say whether your tickets were written replies | `[grounded]` background is silent | none, given the decision |
| R5 | A quiet place to work | must_have | unclear | low | discovery | Not stated | `[grounded]` background is silent | none |
| R6 | Processing orders (from the job title) | important | adjacent | medium | transferability | Parcel-courier customer service is close to order handling. Limit: you haven't stated that you processed orders yourself | `[inferred]` from the title, against your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | "Up to" a rate, with variable hours | Decides whether any version of this role meets €30,000 | none | A written offer with a fixed rate and hours | `[grounded]` posting |
| G2 | Written English (R4, must_have) | discovery | Your background doesn't say | Matters for similar roles elsewhere | Written ticket replies, macros you wrote, training notes for the new starters | A sanitised reply sample | `[grounded]` background is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details asked before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Employers don't need an IBAN, PPS number or passport before an offer. Once sent, these can be used to open accounts or move money in your name. This request is very likely a scam | `[generic]` how this kind of request works | Asked of the employer through contacts on its own website: "Did your payroll team ask me for my IBAN, PPS and passport before an offer?" | confirmed |
| RR2 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Employers don't charge applicants for work kit. A bank transfer, once sent, is very hard to get back | `[generic]` | Same route as RR1 | confirmed |
| RR3 | Cheque to lodge and pass on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show as funds and then bounce days later. Money you've transferred on is gone, and the bank recovers the full amount from you. This request is very likely a scam | `[generic]` | Same route as RR1 | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." The offer came after a chat-only interview, with contact at a non-company address | You have no way to confirm who you're dealing with. The sender's identity is unresolved | `[generic]` | Same route as RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` a general pattern, not a claim about this firm | "Can you point me to this role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR6 | Pay stated as a ceiling (see R1) | risk_signal | medium | "Earn up to €26 an hour plus commission" | The actual rate and hours may fall well below €30,000. The market median is €31,200 salaried | `[grounded]` posting; `[generic]` band | "What is the guaranteed hourly rate, and how many hours are guaranteed each week?" | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer through contact details on the employer's own website, not the chat or the address these messages came from. Who sent them is not yet confirmed. I couldn't find the firm, so there may be no independent route. In that case, treat everything above as on hold permanently.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste your IBAN, and don't send your PPS number or passport photo, in the chat or by email | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Don't transfer the €349 | see RR2 | `[grounded]` RR2 | pending your approval |
| A3 | If a cheque arrives, don't lodge it. Keep it and the envelope | see RR3 | `[grounded]` RR3 | pending your approval |
| A4 | Report the posting to the jobs site where you found it so they can check it | The site can review its own listings | `[generic]` | pending your approval |
| A5 | Put your effort into other order-processing and customer-operations openings: salaried roles that interview by phone or video | Your Zendesk volume, training of two new starters and Excel tracker match the R2, R3 and R6 rows | `[grounded]` R2, R3, R6; `[generic]` €28,400–€34,100 band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator". Both returned nothing, so the employer is not established (RR5) |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example). This gave the market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want a saved record, I can write this up as a `tuesday-dossier.md` file.

**Upgrade menu**
- The employer's own website or careers page listing this role would let RR5 close and give a route to check RR1–RR4.
- A written offer with a fixed rate and hours would settle R1.
- A sample written reply from your ticket work would raise R4.
- A deeper research pass (up to 5 more searches and 2 more fetches) is available if you want it, though it's unlikely to change this decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.