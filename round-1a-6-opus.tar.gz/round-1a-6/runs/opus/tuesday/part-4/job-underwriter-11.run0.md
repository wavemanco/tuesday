Reading the assessment rules, then I'll check both companies and write up the two verdicts.
I'd go for the first role and skip the second. The two web searches I tried were blocked (search permission wasn't granted), so this is based only on the postings and what you told me.

## Decision snapshot — Duinvaart, Operations Analyst

**Yes, this one is worth your time, if the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: A1 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: A2, A3, A4, A5 · unclear: A6 (Temperature compliance)
- `important`: adjacent: A7 (Work with depot managers on route changes)
- `preferred`: adjacent: A8 (Dutch a plus)

A6: the cold-chain duty, with no evidence yet. A7: route reviews lead toward route changes, with the limit named in the map. A5 (`medium`): be ready to say which part of the dashboard was yours.

**Opportunity ledger.** I couldn't confirm the employer because the searches were blocked (RA1). The pay isn't stated (RA2). The scope is concrete and ordinary (RA3).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) three days a week in Rotterdam works for you (A1); (2) the employer and the live posting check out (RA1); (3) you describe A6 and A7 as near your experience, not the same as it.

## Decision snapshot — Kroonhaven, Supply Planner

**No, probably not worth much of your time. B2 and B3, both must-haves, are absent by your own account, and B7 falls short of fluent. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: B1 (On-site in Utrecht)
- `must_have`: adjacent: B7 (Fluent Dutch) · unclear: B5 (Advanced Excel), B6 (SAP IBP or a similar planning system) · absent: B2 (3+ years supply or demand planning in FMCG), B3 (Own the 13-week supply plan)
- `important`: adjacent: B4 (Run the weekly S&OP meeting)

B2 and B3: this is the core of the job, and you've never done it. B7: the posting asks for fluent Dutch and yours is conversational. B4: a real bridge, but not enough on its own.

**Opportunity ledger.** The employer couldn't be confirmed (RB1) and the pay isn't stated (RB2). The mandate itself is clearly scoped (RB3). The problem is the fit, not the role.

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would have to be different:** having done demand or supply planning (B2, B3) and having fluent Dutch (B7). It's your call. If you apply anyway, treat it as a long shot and spend little time on it.

---

## Role reality

| Element | Duinvaart (A) | Kroonhaven (B) | Provenance |
|---|---|---|---|
| Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet; weekly Power BI dashboards; route changes with depot managers | Own the 13-week supply plan for chilled ready meals; balance production capacity against the forecast; run weekly S&OP | `[grounded]` JDs |
| Working pattern | Hybrid, 3 days a week in Rotterdam | On-site in Utrecht | `[grounded]` JDs |
| Scope read | An analyst role that reports and recommends. It doesn't own a plan | A planner role that owns a plan and the forecast-to-capacity trade-off, a different job family from ops analysis | `[inferred]` from the JD verbs ("track", "build" vs "own", "balance", "run") |
| Market calibration | Not run, because the role-family search was blocked | Not run, for the same reason | — |
| Unknowns | Salary; team size; who decides route changes | Salary; size of the range; who owns the forecast | — |
| Contradictions | None in the posting | None in the posting | `[grounded]` JDs |

## Evidence map — Duinvaart (A)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You didn't say whether three days a week in Rotterdam works for you. Your last job was in Amsterdam, and I don't know where you live | `[grounded]` JD; no constraint stated | Question Q3 |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an ops analyst at a parcel carrier, which is past the stated minimum. Self-reported and not probed yet, so `medium` | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | "SQL … daily." Specific, but nothing to inspect yet | `[grounded]` your background | none |
| A4 | Power BI or Tableau | must_have | direct | medium | none | "Power BI daily." Same standing as A3 | `[grounded]` your background | A dashboard screenshot with data hidden would raise this to `high` |
| A5 | Track on-time delivery across the fleet | must_have | direct | medium | none | You named the on-time delivery dashboard your depot managers use, the same metric for the same audience. Your wording ("including") doesn't say whether you built it, maintain it, or contribute to it | `[grounded]` your background | Know exactly which part was yours before the interview |
| A6 | Track temperature compliance | must_have | unclear | low | discovery | Parcel work as you describe it says nothing about chilled or temperature-logged freight. It may exist and simply wasn't mentioned | `[grounded]` your background is silent on it | Question GA1 |
| A7 | Work with depot managers on route changes | important | adjacent | medium | transferability | Bridge: you ran the weekly route-performance review for depot managers. Limit: reviewing performance isn't the same as proposing or carrying out route changes, unless your reviews led to some | `[grounded]` your background; `[inferred]` the limit | Question GA2 |
| A8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch. The posting calls it "a plus", not a requirement | `[grounded]` your background and the JD | none |

## Evidence map — Kroonhaven (B)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You didn't state a location constraint | `[grounded]` JD; no constraint stated | Only matters if you apply anyway |
| B2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | "I've never worked in planning", your own words. Parcel logistics isn't FMCG | `[grounded]` your background | A realistic way in is a junior or associate planner role, or a planning-adjacent analyst role |
| B3 | Own the 13-week supply plan; balance capacity against the forecast | must_have | absent | none | capability | Same basis as B2. Your analyst work measured past performance and didn't plan future supply | `[grounded]` your background; `[inferred]` the backward- vs forward-looking contrast, from your stated duties | Carry as a material risk |
| B4 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | Bridge: you ran a weekly operational review. Limit: S&OP balances sales, production and supply, which is a wider set of trade-offs than route performance | `[grounded]` your background; `[generic]` what S&OP usually covers | none |
| B5 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned. Daily SQL and Power BI make it plausible, but that's a guess | `[inferred]` from your tool use | Not asked, because it can't change the decision |
| B6 | SAP IBP or a similar planning system | must_have | unclear | low | discovery | Not mentioned. With no planning roles, planning-system use seems unlikely, but it isn't confirmed | `[inferred]` from "never worked in planning" | Not asked, because it can't change the decision |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Your Dutch is conversational, not fluent, by your own account. Limit: running a weekly S&OP meeting means leading the discussion in the language the posting requires | `[grounded]` your background and the JD | Close it only through language study. Wording can't change it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A6, must_have) | discovery | No mention of chilled, pharma or temperature-logged shipments | It's the one cold-chain-specific duty in role A, so an answer either way decides how you frame the application | Flagging chilled or pharma parcels; exception reports on SLA breaches for sensitive goods; any sensor, logger or threshold data you queried | A query, a report spec, or a dashboard page with data hidden | `[grounded]` your background is silent; `[inferred]` that it shapes the framing |
| GA2 | Route changes (A7, important) | transferability | You ran the weekly route-performance review; it's unclear whether changes came out of it | It decides whether A7 counts as direct or adjacent | A review finding that led a depot to change a route or a time slot; analysis you did for a re-route; before/after numbers for a change | A slide from a review, or a before/after chart | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here the search was also blocked, so nothing was checked | `[generic]` pattern, not a claim about this company | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RA2 | Salary not stated | unknown | — | (no pay line in the posting) | It may be published later, or set by negotiation | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RA3 | Concrete, measurable responsibilities | positive_signal | — | "Track on-time delivery and temperature compliance … weekly dashboards" | The scope is defined and success can be measured | `[inferred]` from the JD's specific metrics | Which of the two metrics matters most to the team right now? | noted |
| RB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as RA1, none ranked as likely | `[generic]` pattern, not a claim about this company | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RB2 | Salary not stated | unknown | — | (no pay line in the posting) | Same as RA2 | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RB3 | Clearly scoped mandate | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | A well-defined role, just not one your evidence fits | `[inferred]` from the JD | Who owns the forecast that the supply plan balances against? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | For role A, lead with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran, saying exactly which part of the dashboard was yours | See A5, A7 | `[grounded]` your background | pending your approval |
| P2 | Before applying, check that Duinvaart's own website lists the role | See RA1 | `[grounded]` RA1 | pending your approval |
| P3 | Ask RA2's salary question at the recruiter screen | See RA2 | `[grounded]` register | pending your approval |
| P4 | If you apply to role B anyway: a quick application, no planning claims, with your weekly review described as near S&OP, not as S&OP | See B2, B3, B4 | `[grounded]` B rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both refused (search permission not granted). They would have confirmed both employers and the live postings, and cleared or kept RA1 and RB1 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands Rotterdam 2026" and "supply planner FMCG salary Netherlands S&OP SAP IBP"; both refused. They would have filled the market calibration and given salary ranges against RA2 and RB2 |
| 3. Hiring manager's public footprint | n/a | No name was given for either role |

---

I can save all this as a `tuesday-dossier.md` file you can reuse later.

**Upgrade menu**
- **Allow web search:** confirms both employers (RA1, RB1) and adds salary ranges for both roles. I have one search and two page fetches left at the default level, or up to 5 more searches and 2 more fetches if you want a deeper pass.
- **Your CV:** checks A2–A5 against what's on the page, not just what you told me.
- **A dashboard screenshot with the data hidden:** raises A4 and A5 to `high`.
- **Answers to GA1 and GA2:** settle A6 and A7.
- **Your pay floor and where you live:** turns "candidate constraints not given" into actual checks on A1 and the salary.

**Questions**

GA1: Did any of your parcel work involve chilled, pharma or temperature-sensitive shipments, or data from temperature loggers? What did you do with it?

GA2: Did your weekly route-performance review ever lead a depot to change a route? What was your part in that?

Q3 (A1): Does three days a week in Rotterdam work for you, and do you have a minimum salary?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.