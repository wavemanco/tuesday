Checking whether both employers can be found online before I write up the two assessments.
## A. Operations Analyst at Duinvaart Cold Chain, Rotterdam

### Decision snapshot

**Yes, this one is worth your time, as long as the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: A-R1 (three days a week in Rotterdam)
- `must_have`: direct: A-R2, A-R3, A-R4, A-R5
- `important`: adjacent: A-R7 (route changes with depot managers) · unclear: A-R6 (temperature compliance)
- `preferred`: direct: A-R8

A-R2, A-R3, A-R4, A-R5 (`medium`): from your own description, with nothing to show yet; A-R6: cold-chain experience not yet shown; A-R7: you ran a review, and it's not yet clear you drove the route changes that came from it.

**Opportunity ledger.** The role has defined measures and a weekly rhythm (A-RR3). I couldn't confirm the employer exists (A-RR1), and pay isn't stated (A-RR2).

- **Hard gates:** none failed; unconfirmed: A-R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) three days a week in Rotterdam works for you (A-R1); (2) the employer and a live posting check out (A-RR1); (3) you describe A-R6 honestly as new to you, unless A-G1 turns up refrigerated or temperature work.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator in Rotterdam | `[grounded]` posting header |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An individual analyst role, set at the 2+ year level, with defined metrics and a weekly cadence. Your 4 years sit above its stated floor | `[inferred]` from the posting's requirements set against your stated tenure |
| Unknowns | Salary; team size and who the role reports to; whether "work with" means recommending route changes or deciding them | — |
| Contradictions | None in the posting. I couldn't check it against a careers page | `[grounded]` posting; search refused |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A-R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't said where you live or what commute you'll accept, so the gate isn't settled | `[grounded]` posting; your message is silent on location | Closing question on A-R1 |
| A-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | "4 years as an operations analyst at a parcel carrier": the same title and sector, above the floor. From your own description, with nothing to inspect yet | `[grounded]` your background | none |
| A-R3 | Strong SQL | must_have | direct | medium | none | "SQL … daily". Specific, but nothing to inspect yet, so expect a technical probe | `[grounded]` your background | Have a query or a model you can talk through |
| A-R4 | Power BI or Tableau | must_have | direct | medium | none | "Power BI daily" | `[grounded]` your background | A screenshot of a dashboard with the data removed would raise this |
| A-R5 | Track on-time delivery; build weekly dashboards | must_have | direct | medium | none | "the on-time delivery dashboard our depot managers use": the same metric for the same audience. Whether you built it or maintained it isn't stated, so this cell claims only what you said | `[grounded]` your background | Say exactly what part of that dashboard was yours |
| A-R6 | Temperature compliance across a refrigerated fleet | important | unclear | low | discovery | Nothing about temperature or cold chain so far. Parcel work may or may not have included temperature-controlled lanes | `[grounded]` your message is silent; `[inferred]` that a parcel carrier may run some temperature-controlled lanes | See A-G1 |
| A-R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | "I ran our weekly route-performance review" covers performance review with depot staff. Proposing or putting route changes in place isn't stated | `[grounded]` your background | See A-G2 |
| A-R8 | Dutch a plus | preferred | direct | medium | none | Conversational Dutch meets a "plus" that sets no level | `[inferred]` from the posting naming no level | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| A-G1 | Temperature compliance (A-R6, important) | discovery | Nothing about temperature, pharma, food or chilled freight | It's the one part of the mandate your history doesn't yet touch | Tracking chilled or pharma parcels; exception or SLA reporting on any time-sensitive or temperature-sensitive product; sensor or telematics data in your SQL work | A dashboard page, a report spec, an incident write-up | `[grounded]` silence in your message; `[inferred]` that exception reporting is the nearest carry-over |
| A-G2 | Route changes (A-R7, important) | discovery | You ran the route-performance review; the outcomes aren't stated | It decides whether you can say "drove route changes" or only "reviewed route performance" | A route you flagged that depot managers then changed; a recommendation that came out of the review; before-and-after on-time figures | Review minutes, a before-and-after chart | `[grounded]` your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| A-RR1 | Employer not established from sources I could check | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to show up online, the posting may be old or copied from elsewhere, or it may not be a real hiring employer | `[generic]` common pattern, not a claim about this company; my search was refused | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| A-RR2 | Salary not stated | unknown | — | (no pay given) | The figure may be below what you'd accept, or they may simply not publish salaries | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| A-RR3 | Clear, measurable mandate | positive_signal | — | "Track on-time delivery and temperature compliance … weekly dashboards" | The scope is defined and success can be measured | `[grounded]` posting | Which compliance threshold does the business report against today? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open with the on-time delivery dashboard depot managers use and the weekly route-performance review you ran, in those words, without "built" or "owned" until you confirm which applies | see A-R5, A-R7 | `[grounded]` your background | pending your approval |
| P2 | If A-G1 finds nothing, call temperature compliance new to you but a metric of the same kind as on-time delivery. Don't claim cold-chain experience | see A-R6 | `[grounded]` A-R6 row | pending your approval |
| P3 | Find the role on Duinvaart's own site before you put in much effort | see A-RR1 | `[grounded]` A-RR1 | pending your approval |
| P4 | resume-tailor can tailor your CV to this posting if you share it | see A-R5 | `[grounded]` map rows | pending your approval |

---

## B. Supply Planner at Kroonhaven Foods, Utrecht

### Decision snapshot

**No, not worth your time. B-R3 and B-R4, both must-haves, are planning work you've said you haven't done. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: B-R1 (On-site in Utrecht)
- `must_have`: adjacent: B-R2 (fluent Dutch), B-R5 (run the weekly S&OP meeting) · unclear: B-R6 (advanced Excel), B-R7 (SAP IBP or similar) · absent: B-R3 (3+ years of planning in FMCG), B-R4 (own the 13-week supply plan)

B-R3, B-R4: no planning experience, in your own words; B-R2: conversational Dutch against a "fluent" requirement; B-R5: your meeting experience is real, but S&OP is a different meeting.

**Opportunity ledger.** The scope is clearly defined (B-RR3). I couldn't confirm the employer exists (B-RR1), and pay isn't stated (B-RR2). This ledger doesn't drive the decision; the fit ledger does.

- **Hard gates:** none failed; unconfirmed: B-R1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would have to be different:** planning experience on your record (B-R3, B-R4), plus fluent Dutch (B-R2).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals producer in Utrecht | `[grounded]` posting header |
| Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planning role that owns the plan, not an analyst role that supports it, and it chairs a cross-functional meeting in Dutch | `[inferred]` from "own" and "run" alongside "fluent Dutch" |
| Unknowns | Salary; team size; who forecasts demand | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B-R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and commute limits aren't stated | `[grounded]` posting; your message is silent | none, given the decision |
| B-R2 | Fluent Dutch | must_have | adjacent | medium | transferability | "My Dutch is conversational, not fluent." It carries over for daily work, but its limit is chairing S&OP in Dutch | `[grounded]` your own words; `[inferred]` that S&OP runs in Dutch, from the posting's fluency requirement | Closing it takes time, not wording |
| B-R3 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | "I've never worked in planning," and your sector is parcel delivery, not FMCG | `[grounded]` your own words | Closure path: a demand or supply analyst role first |
| B-R4 | Own the 13-week supply plan; balance capacity against the forecast | must_have | absent | none | capability | Same basis as B-R3. Your analysis work reports on operations rather than planning them | `[grounded]` your own words | Same closure path as B-R3 |
| B-R5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | "I ran our weekly route-performance review" shows you can run a weekly cross-team review. Its limit: S&OP decides supply against demand, and you haven't done that | `[grounded]` your background | none, given the decision |
| B-R6 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned. Daily SQL and Power BI work suggests it but doesn't establish it | `[inferred]` from your daily tools | none, given the decision |
| B-R7 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | Not mentioned, and with no planning roles behind you, a planning system is unlikely to have been yours | `[inferred]` from "never worked in planning" | none, given the decision |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| B-G1 | Planning experience (B-R3, B-R4, must_have) | capability | None, in your own words | Two must-haves; this is what decides the `no_go` | A demand or supply analyst role, or an S&OP support role, would build it over time | — | `[grounded]` your own words |
| B-G2 | Fluent Dutch (B-R2, must_have) | transferability | Conversational | Rules out chairing the S&OP meeting in Dutch | Formal Dutch study toward fluency | A language certificate | `[grounded]` your own words |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| B-RR1 | Employer not established from sources I could check | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The company may be too new or small to show up online, the posting may be old or copied from elsewhere, or it may not be a real hiring employer | `[generic]` common pattern, not a claim about this company; my search was refused | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| B-RR2 | Salary not stated | unknown | — | (no pay given) | Pay may sit anywhere relative to what you'd accept | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| B-RR3 | Clearly defined scope | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | Success is measurable | `[grounded]` posting | Who owns the demand forecast? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P5 | Skip this one, and spend the time on operations-analyst openings like Duinvaart | see B-R3, B-R4 | `[grounded]` B-R3, B-R4 rows | pending your approval |
| P6 | If you apply anyway, say plainly that you'd be moving into planning, and ask B-RR2's question early | see B-R3, B-RR2 | `[grounded]` map and register | pending your approval |

---

### Evidence status

Verified: none yet.

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht", and both were refused because search permission wasn't granted. A result would have confirmed or cleared A-RR1 and B-RR1 |
| 2. Role-family sweep | unavailable | Not sent, since search isn't available in this session. It would have given market pay bands for A-RR2 and B-RR2 and a market-calibration line for each role |
| 3. Hiring manager's public footprint | n/a | Neither posting names a hiring manager, so there was nothing to search for |

### Closing

I can save these two assessments as a `tuesday-dossier.md` file if you'd like to keep them.

**Upgrade menu**
- Allow web search → checks that both employers and postings exist (A-RR1, B-RR1) and gets salary bands (A-RR2, B-RR2).
- After that, a deeper check on Duinvaart (leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Just say the word.
- Your CV → firmer rows for A-R3, A-R4, A-R5, and a check on A-R6.
- A dashboard screenshot with the data removed → A-R4 and A-R5 move from `medium` toward `high`.
- The hiring manager's name → a sharper scope read, and which part of your experience to lead with.

**Questions**

A-R1: Does three days a week in Rotterdam work for you, given where you live?

A-G1: Did any of your parcel work involve chilled, pharma or other time-sensitive or temperature-sensitive shipments, such as exception reports, SLA tracking or sensor data?

A-G2: When your route-performance review flagged a problem, what happened next? Did you recommend changes that depot managers then made, and did on-time figures move?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.