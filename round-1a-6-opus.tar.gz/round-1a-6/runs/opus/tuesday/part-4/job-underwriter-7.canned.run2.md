Now the required reference files.
I'm checking the employer, the Band 5 pay scale and the named team lead online before I write up the assessment.
## Decision snapshot

**Yes, it's worth applying for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R8 · adjacent: R6 (Catheter and continence care) · unclear: R4 (Clear, timely written records), R5b (Leg-ulcer care), R7 (End-of-life visits)
- `important`: direct: R10 · adjacent: R9 (A small caseload of your own)
- `preferred`: absent: R11 (Doppler assessment for leg ulcers)

R4, R5b, R7: your CV doesn't mention these yet, so they're questions about your evidence, not gaps in what you can do; R9: your discharge-to-assess home visits are a real bridge to holding a caseload, but they aren't a caseload; R11: desirable only.

**Opportunity ledger.** This looks like a sound opportunity. Built-in senior support (RR1), stated pay with mileage and pool cars (RR2), and a team lead who has spoken publicly about Doppler training for staff new to community work (RR3) all count in its favour. Still open: whether the posting is live (RR4), how big the caseload is and when it starts (RR5), and the working pattern (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can confirm the experience behind R4, R5b and R7 (questions below); (2) you present R9 honestly, as supported home visiting rather than caseload holding; (3) RR4 confirms the role is still open.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a CIC running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` company About page, fetched |
| Mandate | District nursing for housebound adults: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, records on an electronic patient record | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | A Band 5 role that brings a new community nurse in with support, not one that expects an experienced caseload holder | `[inferred]` from "small caseload" plus "supported", and Doppler listed as desirable rather than essential |
| Market calibration | Wardround 2026 survey, Band 5 community staff nurse in England (n=1,240): median £34,300, middle half £32,400–£36,600. The advert's £31,050–£37,800 spans that band | `[generic]` pay survey; `[grounded]` advert figure |
| Unknowns | Whether the posting is live, closing date, caseload size, hours and weekend or evening rota | — |
| Contradictions | None found between the advert and the company's site | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Your CV says the registration is active, with revalidation due March 2028. This is your statement and I haven't checked it | `[grounded]` CV | Check your entry on the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV says category B, full. I haven't checked it | `[grounded]` CV | Check your own driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse meets the "at least one year" bar. Self-reported | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | Your CV doesn't mention records, an EPR system or care plans | `[grounded]` CV silence | Question G3 |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds are named in your CV | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | unclear | low | discovery | Leg ulcers aren't named. You may have managed them on the ward or on home visits | `[grounded]` CV silence | Question G1 |
| R6 | Catheter and continence care | must_have | adjacent | medium | discovery | Catheter care is stated. Continence assessment and products aren't | `[grounded]` CV | See G4 |
| R7 | End-of-life visits | must_have | unclear | low | discovery | Your CV doesn't mention end-of-life care | `[grounded]` CV silence | Question G2 |
| R8 | Insulin administration | must_have | direct | medium | none | Stated in your CV | `[grounded]` CV | none |
| R9 | A small caseload of your own, with care planning | important | adjacent | medium | transferability | You say you've never held a caseload. Visiting discharged patients at home for 18 months is the nearest work. Its limit is that it covered patients' first week after discharge, not ongoing ownership of a caseload | `[grounded]` CV and your own statement | See G5 |
| R10 | Visiting patients in their own homes | important | direct | medium | none | 18 months on discharge-to-assess home visits | `[grounded]` CV | Lead with it (P1) |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. It's desirable, not essential | `[grounded]` your own statement | Closure path in G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | discovery | Wound care stated, leg ulcers not | It's listed first among the duties | Venous or mixed ulcers on the ward; compression dressings; ulcers seen on discharge-to-assess visits | A competency record or training certificate | `[grounded]` advert and CV |
| G2 | End-of-life visits (R7, must_have) | discovery | No mention | It's a core district nursing duty in the advert | End-of-life patients on an acute medical ward; syringe drivers; anticipatory medicines; supporting families; fast-track discharges home | Syringe-driver competency, end-of-life training | `[grounded]` advert; `[inferred]` that an acute medical ward involves end-of-life care |
| G3 | Clear, timely records (R4, must_have) | discovery | No mention | An essential criterion | Which EPR you used (SystmOne, EMIS or a hospital system); care plans written on discharge-to-assess; risk assessments | Name of the system, any documentation audit | `[grounded]` advert |
| G4 | Continence care (R6, must_have) | discovery | Catheter care only | It completes R6 | Continence assessments, product ordering, bowel care | A competency record | `[grounded]` advert |
| G5 | Caseload (R9, important) | transferability | Supported home visiting, not caseload ownership | Interviewers are likely to ask how you would plan your day | Planning your own discharge-to-assess visits; prioritising; handing over to district nurses | — | `[grounded]` CV; `[generic]` that community interviews probe workload planning |
| G6 | Doppler (R11, preferred) | capability | None | Desirable only; closing it is training, not discovery | — | A Doppler or ABPI course certificate later | `[grounded]` your statement; RR3 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Senior support built in | positive_signal | — | "supported by a senior community nurse" | The role is set up for someone new to holding a caseload | `[grounded]` advert | How is the support structured in the first months: shadowing, joint visits, case reviews? | noted |
| RR2 | Pay stated, in line with the market, travel covered | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Pay is transparent and travel isn't left for you to cover | `[grounded]` advert; `[generic]` survey band | Where on the scale would someone with five years' experience start? | noted |
| RR3 | Team lead has spoken on Doppler training for staff new to community work | positive_signal | — | "spoke on … Doppler training for staff new to community work" (2025 forum page) | Doppler training may be available here | `[grounded]` forum speaker page; `[inferred]` that it applies to this post | Is Doppler training offered to new starters, and how soon? | noted |
| RR4 | Posting not found live | unknown | — | About page: "Current vacancies are listed on our careers page" | The posting may simply not be indexed yet, or it may have closed | `[inferred]` from two searches that didn't return the posting | Is the post still open, and what's the closing date? | unresolved |
| RR5 | Caseload size unstated | unknown | — | "a small caseload of your own" | "Small" is undefined | `[grounded]` advert | How many patients, and from when? | unresolved |
| RR6 | Working pattern unstated | unknown | — | (advert silent) | District nursing often runs evening or weekend rotas | `[generic]` role-family pattern | What are the hours, and is there a weekend or evening rota? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your discharge-to-assess secondment in your own words: "18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" | see R10, R9 | `[grounded]` CV | pending your approval |
| P2 | Say plainly that you haven't held your own caseload, and point to the support the advert describes | see R9, RR1 | `[grounded]` your statement and the advert | pending your approval |
| P3 | Say you haven't done Doppler yet, and ask about training | see R11, RR3 | `[grounded]` your statement | pending your approval |
| P4 | Book the informal chat with Rhiannon Mabbott, using the contact route in the advert, and ask the RR1–RR6 questions | Settles RR4–RR6 before you write the application | `[grounded]` advert | pending your approval |
| P5 | Check your NMC register entry and driving record match what you'll write | see R1, R2 | `[grounded]` CV | pending your approval |

## Evidence status

Verified: none yet. You included your National Insurance number. It isn't needed for this and I haven't used it. Your NMC PIN wasn't used in any search.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse" and "Calderbrook Community Health careers vacancies community staff nurse band 5"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). The employer exists as described. The posting itself wasn't found (RR4) |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026/27 community staff nurse district nursing", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: RR3 and P3 |

## Upgrade menu

I can write all of this up as a `tuesday-dossier.md` file you can keep or reuse later. Just ask.

- Answers to G1–G3 → R4, R5b and R7 move from `unclear`, which could lift the status to `go`.
- A competency or training record (wound, syringe-driver or continence) → the matching row's confidence rises.
- The careers-page link or closing date → RR4 closes.
- Your non-negotiables (hours, weekends, pay floor, start date) → hard-gate checks against your terms, instead of "unknown".
- A deeper research pass on Calderbrook (CQC reports, staff reviews, recent news; up to 5 more searches and 2 more fetches) → just say the word.

G1: Have you cared for leg ulcers, on the ward or on home visits? What did you do, for example dressings or compression?
G2: Have you cared for patients at the end of life? Did that include syringe drivers, anticipatory medicines or supporting families at home?
G3: Which record system did you use, on the ward and in discharge-to-assess, and did you write care plans in it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.