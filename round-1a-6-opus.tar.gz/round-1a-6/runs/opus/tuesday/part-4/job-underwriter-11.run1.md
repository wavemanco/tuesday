Now the files Step 1 names.
Quick update: I've read the job-assessment rules and I'm about to check whether both employers and postings are real before I write up each role.
# Role A — Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Yes, this one is worth your time, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Three days a week in our Rotterdam office)
- `must_have`: direct: R2, R3, R4, R5 · unclear: R6 (Temperature compliance across our refrigerated fleet)
- `important`: adjacent: R7 (Work with depot managers on route changes)
- `preferred`: direct: R8

R6: new cold-chain ground, open to discovery; R7: the route-performance review is yours, but nothing yet shows route changes coming out of it.

**Opportunity ledger.** The employer and posting could not be verified (RR1), and pay and contract basis aren't stated (RR2, RR3). On the plus side, the scope is concrete and the experience bar is modest (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Three days a week in our Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can do three office days in Rotterdam (R1); (2) the posting appears on Duinvaart's own careers page (RR1); (3) temperature compliance is presented as new ground for you unless G1 turns something up (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator in Rotterdam | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An individual-contributor analyst post: no team, budget or decision rights mentioned, and route changes are done "with" depot managers | `[inferred]` from the JD's verbs and the 2+ year bar |
| Unknowns | Salary; contract basis; who the role reports to; whether the role can change routes or only recommend changes | — |
| Contradictions | None in the posting. It couldn't be checked against a careers page because search was refused | `[grounded]` JD; research refused |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Three days a week in our Rotterdam office | hard_gate | unclear | none | hard_gate | You worked in Amsterdam; you haven't said where you live or what office pattern you'll accept | `[grounded]` JD term; your message is silent on constraints | Question R1 below |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, nothing inspectable yet | `[grounded]` your stated background | none |
| R3 | Strong SQL | must_have | direct | medium | none | You use SQL daily; no work sample yet | `[grounded]` your stated background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily | `[grounded]` your stated background | none |
| R5 | Track on-time delivery, build weekly dashboards | must_have | direct | medium | none | You named "the on-time delivery dashboard our depot managers use". You didn't say whether you built it or maintained it, so the plan words it the way you did | `[grounded]` your stated background | none |
| R6 | Temperature compliance across our refrigerated fleet | must_have | unclear | none | discovery | Nothing in your background touches temperature-controlled freight yet. Parcel work may still include compliance or SLA metrics shaped like this | `[grounded]` your background is silent on it; `[inferred]` that compliance tracking may sit near your on-time work | Question G1 below |
| R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review, and depot managers use your dashboard. Whether the review produced route changes, and what your part was, isn't stated | `[grounded]` your stated background | Question G2 below |
| R8 | Dutch a plus | preferred | direct | medium | none | Conversational Dutch meets a "plus" whose level isn't specified | `[grounded]` JD wording and your stated level | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, must_have) | discovery | No temperature-controlled work mentioned | This is the one must-have below `direct`. Closing it moves you from "bridging" to "done it" | Pharma or food parcels with temperature handling; tracking any compliance rate (SLA breaches, damage, scan compliance) by depot or route; exception reporting that depot managers acted on | A screenshot of a compliance or exception page with data removed; a metric definition you wrote | `[grounded]` your background is silent; `[inferred]` that compliance dashboards transfer across freight types |
| G2 | Route changes (R7, important) | discovery | You ran the review; outcomes aren't stated | The JD's verb is "route changes", so a concrete change you influenced is the story this reader will look for | A route you flagged that was re-planned; a depot that changed stop sequence or cut-off times after your review | A before/after metric from one change, approximate is fine | `[grounded]` your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this company; search was refused, so nothing was checked | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in posting) | The figure may sit anywhere; no market band was gathered | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Contract basis not stated | unknown | — | (no contract type in posting) | It could be permanent, fixed-term or via an agency | `[inferred]` from the posting's silence | Is this a permanent contract with Duinvaart directly? | unresolved |
| RR4 | Concrete scope and a realistic bar | positive_signal | — | "Track on-time delivery and temperature compliance… build weekly dashboards in Power BI" | The work is defined, measurable and pitched at its stated level | `[grounded]` JD | Which two or three metrics matter most to the depot managers today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with SQL and Power BI daily, "the on-time delivery dashboard our depot managers use", and running the weekly route-performance review, in those words. Say "built" or "drove route changes" only if G1 or G2 confirms it | see R3, R4, R5, R7 | `[grounded]` your stated background | pending your approval |
| P2 | Before you apply, find the posting on Duinvaart's own website | see RR1 | `[grounded]` RR1 | pending your approval |
| P3 | Ask RR2 and RR3 in the first recruiter call | Pay and contract basis are both unknown | `[grounded]` register | pending your approval |

---

# Role B — Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**Probably not worth your time right now: R2 and R3, both must-haves, are gaps you named yourself, and R5 asks for fluency above your Dutch. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (On-site in Utrecht)
- `must_have`: adjacent: R4 (Run the weekly S&OP meeting), R5 (Fluent Dutch) · unclear: R6 (Advanced Excel), R7 (SAP IBP or a similar planning system) · absent: R2 (3+ years of supply or demand planning in FMCG), R3 (Own the 13-week supply plan)

R2, R3: capability gaps at the core of the role, by your own account; R5: conversational against a fluency bar.

**Opportunity ledger.** The employer couldn't be verified (RR1) and salary isn't stated (RR2). The scope itself is clearly defined (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would have to differ:** real planning experience your message didn't mention, such as forecasting volume or planning depot capacity against it (R2, R3), or Dutch that holds up chairing a meeting (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals producer in Utrecht | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run weekly S&OP | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A planner who owns the plan and chairs the cross-functional meeting, which is a step beyond an entry-level planning post | `[inferred]` from "own" and "run" alongside the 3+ year bar |
| Unknowns | Salary; contract basis; team size | — |
| Contradictions | None in the posting; not checked against a careers page because search was refused | `[grounded]` JD; research refused |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and office constraints aren't stated | `[grounded]` JD term; your message is silent | Upgrade menu; asked under Role A's R1 question |
| R2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said "I've never worked in planning", and parcel carriage isn't FMCG | `[grounded]` your own statement | Carried as material risk |
| R3 | Own the 13-week plan, balance capacity against forecast | must_have | absent | none | capability | Same statement. Analysing delivery performance is a different kind of work from owning a forward production plan | `[grounded]` your own statement | Carried as material risk |
| R4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Carries over: you ran a weekly cross-functional review. Limit: S&OP trades off demand, supply and finance decisions, and here it would likely be held in Dutch | `[grounded]` your stated background; `[inferred]` the meeting language, from the fluency requirement | none |
| R5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch handles everyday exchanges; your own description says it isn't fluent, and wording can't close that gap | `[grounded]` your stated level | none |
| R6 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned; daily SQL and Power BI suggest it but don't establish it | `[inferred]` from your tooling | Not asked: it can't move a `no_go` |
| R7 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | No planning system mentioned | `[grounded]` your background is silent | Not asked: it can't move a `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning experience (R2, R3, must_have) | capability | No planning work, by your own statement | These rows decide the `no_go`. Without them this applicant reads as an analyst applying for a planner role | Closure path: an analyst role on a planning team, or a junior or associate planner role, then this title | — | `[grounded]` your own statement; `[generic]` that planner roles are usually reached through a planning-adjacent step |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this company; search was refused | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in posting) | No band was gathered | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Clearly defined scope | positive_signal | — | "Own the 13-week supply plan… run the weekly S&OP meeting" | The role's outputs are concrete | `[grounded]` JD | Who attends S&OP, and what decisions does it make? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P4 | Skip this one and spend the time on Role A and similar analyst roles | see R2, R3, R5 | `[grounded]` evidence map | pending your approval |
| P5 | If you apply anyway, call your route-performance review "a weekly cross-functional performance review", not S&OP or planning | see R4; describing it as planning would overstate it | `[grounded]` your stated background | pending your approval |

---

## Evidence status

Verified: none yet (both roles).

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both refused. A result would have settled RR1 in each register and the contradictions rows |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands Rotterdam" and "supply planner FMCG salary Netherlands"; both refused. A result would have added a market calibration line and a salary band against RR2 in both roles |
| 3. Hiring manager's public footprint | n/a | No name was given for either role |

If you want to save this, I can write it up as a `tuesday-dossier.md` you can bring back later.

## Upgrade menu

- Your location and office-day limits → R1 in both roles is settled.
- The live posting links, or the companies' own careers pages → RR1 closes in both; Role A could move to `go`.
- Allowing web search → targets 1 and 2 run, both RR1 entries can be checked, and salary bands are added against RR2. After that, a deeper pass on Duinvaart (news, hiring patterns, employee reports; up to 5 more searches and 2 more fetches) is available if you say so.
- Your CV → the map reads from your actual wording, not a summary; any buried evidence becomes a proposed edit.
- A sanitized dashboard screenshot or metric definition → R5 and R6 could rise to `high`.
- Your salary floor → RR2 can be set against it once a band exists.

## Questions

**R1** — Can you do three days a week in a Rotterdam office (and, for Role B, daily on-site in Utrecht)? Where are you based?

**G1** — Did any of your parcel work involve temperature-controlled shipments (pharma, food) or tracking a compliance rate (SLA breaches, exceptions) by depot or route? What did you track, and who acted on it?

**G2** — Did your weekly route-performance review lead to actual route changes? Give one example: what you flagged, what changed, and which part was yours. Also, did you build the on-time delivery dashboard, or maintain one someone else built?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.