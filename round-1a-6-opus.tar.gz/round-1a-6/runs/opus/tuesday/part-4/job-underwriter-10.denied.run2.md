Now the Step 1 references.
**Yes, it's worth taking the call, and nothing you've shown me looks off. Status: `conditional_go`.** Scheduling an interview over WhatsApp, with a video call booked through an emailed calendar invite, is a normal step. Nobody is asking you for money, bank details or ID. The one open point is that I couldn't confirm Fernquay exists as described: my web searches were blocked in this session (RR1).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R8 (Salary €52,000–€60,000 plus 0.5–1% equity)
- `must_have` — direct: R2, R3, R4, R5, R7a
- `important` — adjacent: R6 (Research calls with school owners) · unclear: R7b (Being the first and only designer)

R7b — the real open question: you've never worked without other designers; R6 — a credible bridge from your usability sessions, its limit named.

**Opportunity ledger.** Clear and concrete: pay and equity are stated (RR2), and the invite names two senior interviewers and mentions your actual case study (RR3). On the other side, Fernquay isn't established from here (RR1), the equity terms are open (RR4), and how much "first designer" covers beyond the booking flow is unstated (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R8 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay checks out as a real, registered company with this role — RR1; (2) the salary and equity clear your own floor — R8; (3) you're comfortable with R7b after asking what support a first designer gets — RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, making booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Portfolio expectation | "would rather see one messy real project than a polished deck" | `[grounded]` posting |
| Process so far | Ronan replied on WhatsApp, said they "loved the checkout case study", and asked for a 45-minute video call with him and Saoirse (CTO), with the invite sent by email | `[grounded]` WhatsApp message |
| Scope read | One product surface, a small engineering team and direct access to a co-founder. That's a focused mandate, but with no design peers | `[inferred]` from the posting's team size and "first designer" |
| Market calibration | Not run, because the role-family search was blocked. €52–60k isn't checked against Irish market rates here | — |
| Unknowns | Whether the company exists as described; equity terms; what else a first designer owns; design support or mentorship | — |
| Contradictions | None found between the posting and the message | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are within reach. This comes from your own background, not something I've checked | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a travel-booking company | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily" | `[grounded]` your background | none |
| R4 | You have run your own user research | must_have | direct | medium | none | "ran monthly usability sessions with customers" | `[grounded]` your background | Have one session's plan or findings ready to show |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7a | Owning a booking flow | must_have | direct | medium | none | You redesigned the checkout flow of a travel-booking product, the same kind of flow. Ronan says they've already seen this case study | `[grounded]` your background and the WhatsApp message | none |
| R7b | Being the first and only designer | important | unclear | low | discovery | You say you've never been the only designer anywhere. It's not yet clear how much of the checkout work you owned alone inside your squad | `[grounded]` your own statement | G1 |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | What carries over: planning and running sessions yourself, every month. The limit: those were consumers testing a flow, while these are business owners talking about how they run their schools | `[grounded]` your background; `[inferred]` the difference between the two kinds of session | G2 |
| R8 | €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the pay, but you haven't told me your floor, so I can't tell whether it meets it | `[grounded]` posting; your floor not given | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Being the first and only designer (R7b, important) | discovery | Four years in a squad; never the only designer in the company | The posting's core ask is to be the first designer, and the co-founder and CTO will probe this | Being the only designer in your own squad; decisions you made without design review; pieces you took from idea to release with only engineers | The checkout case study, with your own decisions marked | `[grounded]` your statement; `[inferred]` that the interviewers will probe it |
| G2 | Research calls with school owners (R6, important) | transferability | Monthly usability sessions with consumers | Talking to the school owners is how this job learns what to build | Interviews with hotel or tour partners; calls with the business side of your old company; recruiting and scheduling participants yourself | A discussion guide or a findings summary | `[inferred]` from the posting's research duty against your consumer sessions |
| G3 | Pay against your floor (R8, hard_gate) | hard_gate | The posting states €52–60k plus equity; your floor isn't known | It's the only gate I can't settle from what you've given me | — | — | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | Possible reasons, side by side: the company may be too new or small to show up much online, the posting may be stale, or it may not be a real hiring employer. You also said you can't find much about them online | `[generic]` pattern for companies of this size, not a claim about this one | Is Fernquay a registered company I can look up, and is this role on your own website? | unresolved |
| RR2 | Pay and equity stated in the posting | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The company is open about pay from the start | `[grounded]` posting | What decides where an offer lands in that range? | noted |
| RR3 | Named interviewers and a reply that mentions your case study | positive_signal | — | "we loved the checkout case study … with me and Saoirse, our CTO" | They read your application, and the interview is a video call with two named leaders, not a chat | `[grounded]` WhatsApp message | none — interviews are on video | noted |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | The vesting, the cliff and what the percentage is worth are open | `[generic]` early-stage equity varies widely in its terms | Is it options or shares, what's the vesting and cliff, and at what valuation? | unresolved |
| RR5 | How much "first designer" covers beyond the booking flow | unknown | — | "You would be our first designer" | The role may also take in brand, the marketing site or support, with no one to review your design work | `[generic]` common pattern for first design hires at small startups | Beyond the booking flow, what else would I own, and who would critique my design work? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, look Fernquay up on the Companies Registration Office (cro.ie, Ireland's company register) and check the calendar invite came from a Fernquay email address | Clears RR1 quickly; this is advice, not a reason to worry | `[generic]` standard check for small employers | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions, in your own words: "redesigned our checkout flow", "ran monthly usability sessions with customers" | See R7a, R4 | `[grounded]` your background | pending your approval |
| A3 | Say plainly that you've never been the only designer, and pair it with the G1 answer once you have it | See R7b; being candid holds up better than stretching it | `[grounded]` your statement | pending your approval |
| A4 | Bring one messy real artifact, such as a usability session's notes or early checkout sketches | The posting asks for it directly | `[grounded]` posting | pending your approval |
| A5 | Ask the RR1, RR2, RR4 and RR5 questions in the call | The register doubles as your question list | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software kayak surf schools Galway"; the search was refused. It would have tested RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 mid-level startup"; refused. It would have set €52–60k against the market |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have shown Ronan's background and which of your stories to lead with |

I can save all this as a `tuesday-dossier.md` file whenever you want it.

## Upgrade menu

- Allow web search → I run the three checks above: RR1 resolves either way, and €52–60k gets placed against the market.
- Your salary floor → R8 closes.
- An answer to G1 → R7b gets a real fit status.
- A deeper research pass on Fernquay (funding, founders' background, recent news; up to 5 more searches and 2 more fetches) → feeds RR1 and RR4.
- Prep for the call itself is what mock-interview is for.

## Questions

G1 — In your squad, were you the only designer? Which checkout decisions did you make and ship without another designer's sign-off?

G2 — Have you ever interviewed business customers or partners, as opposed to end users, about how they work?

G3 — What's the lowest salary you'd accept for this role, and does equity count toward it for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.