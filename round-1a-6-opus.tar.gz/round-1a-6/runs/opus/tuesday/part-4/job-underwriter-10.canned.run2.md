Lots of references to read. Let me read them in parallel.
Yes, it looks legit, and yes, it's worth pursuing. Fernquay's own website matches the posting and the people named in the WhatsApp message. Messaging you on WhatsApp just to arrange a time for a video call is a normal way to schedule. What's left to check is the invite itself (see P1).

## Decision snapshot

**Yes, it checks out, and it's worth taking the call. Status: `go`.**

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R5 (Research calls with school owners) · unclear: R8 (First designer, no design peers)

R7: checkout is one stage of a booking flow; R5: your research was with travellers, not business owners; R8: you haven't worked as the only designer yet.

**Opportunity ledger.** Clean and open about its terms. The employer and the posting match the company's own site (RR1), and the salary is published and sits inside the market range (RR2). Two things are still open: the equity terms (RR3), and who signs off on design decisions when there's no other designer (RR4).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** a salary or equity answer below your floor, or a sign in the call that you'd own the outcomes without the right to make design decisions (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle and funded by its customers. Its product is called Kelproster and serves sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting and careers page agree |
| Scope read | A normal scope for a first designer at a company this size: broad, but focused on one product and one flow | `[inferred]` from the posting's headcount and mandate |
| Market calibration | Irish product designers with 3–5 years: median base €57,000, middle half €51,500–€62,000. This posting's range sits inside that, so it's a market rate, not a discounted startup rate | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520); `[grounded]` posting figure |
| Unknowns | Equity terms (vesting, type, valuation); who has final say on design; whether the call is a screen or the whole interview process | — |
| Contradictions | None. The posting, careers page and WhatsApp names (Ronan, Saoirse) all agree. The site lists Saoirse as a co-founder without a title, so "CTO" is unconfirmed, not contradicted | `[grounded]` About page, careers page, message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year. That's self-reported and you didn't state it as a constraint | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer, stated and not yet checked against a CV | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | Figma daily; the case study they liked is the artifact that shows it | `[grounded]` your background | none |
| R4 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers; here it would be two | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Close in subject: you redesigned checkout at a travel-booking company. The limit is that checkout is one stage, and "end to end" here likely also covers the school's side (availability, rosters) | `[grounded]` your background; `[inferred]` that the flow includes the operator side, from "booking software for … schools" | see G1 |
| R5 | Research calls with school owners | important | adjacent | medium | transferability | You ran research yourself, but with consumers. Interviewing small-business owners about their operations is a different kind of conversation | `[grounded]` your background; `[generic]` that B2B operator interviews differ from consumer usability tests | see G2 |
| R8 | First designer, no design peers | important | unclear | low | discovery | You say you've never been the only designer. Whether you've owned decisions without design review, set up design practices, or worked solo on a side project isn't established yet | `[grounded]` your own statement; `[inferred]` requirement, from "You would be our first designer" | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own booking flow end to end (R7, must_have) | transferability | A checkout redesign. Nothing yet on search, availability, confirmation, or admin-side screens | It's the core of the job, so the call will likely test how far your ownership went | Search or date-picker work; booking confirmation or cancellation flows; any internal or admin tooling; measuring conversion across the whole funnel | The case study itself, a flow map, before/after metrics | `[grounded]` your background; `[inferred]` that the call tests ownership scope |
| G2 | Research with school owners (R5, important) | transferability | Monthly usability sessions with customers | First-hand operator research is how a first designer here learns the domain | Interviews with hotel, airline or tour-operator partners; stakeholder interviews with internal ops teams; recruiting your own participants | A research plan, discussion guide, or synthesis deck | `[grounded]` your background; `[generic]` small B2B teams rely on direct operator research |
| G3 | Sole designer (R8, important) | discovery | You've stated you've never been the only designer | It's the biggest change between your last job and this one | Leading a project where no other designer reviewed your work; starting a component library or research practice; freelance or side work done alone; making trade-offs with engineers without a design lead | A project you owned end to end, a design-system contribution | `[grounded]` your statement; `[inferred]` that this is the biggest change |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting match the company's own site | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company exists as described and the role is open now | `[grounded]` About page and careers page | Who else would I meet before an offer? | noted |
| RR2 | Salary published, inside the market range | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Open about pay, and the pay is at market rate | `[grounded]` posting; `[generic]` Tillerby band | What decides where in the range an offer lands? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The vesting, the type of equity and how it could ever be cashed out are unknown. A company funded by its customers may have no investor-led exit planned | `[grounded]` posting and About page; `[generic]` that equity in customer-funded firms is often illiquid | What kind of equity is it, what's the vesting schedule, and how could it ever be sold or cashed out? | unresolved |
| RR4 | Design authority with no design peer | unknown | — | "own the booking flow end to end" | Final say on design may sit with you, with Ronan, or be shared case by case | `[inferred]` from "first designer" against silence on decision rights | When you and Ronan disagree on a design call, who decides, and how? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the calendar invite came from a Fernquay email address (the careers page uses jobs@fernquay.example) and that the link opens a standard video meeting. Reply on WhatsApp only to confirm the time | A routine check; nothing in the message asks for anything beyond your time | `[grounded]` careers page and message | pending your approval |
| P2 | Lead with the checkout case study, saying exactly which part was yours, and be ready to talk about the rest of the booking flow | They named it, and R7 is where ownership will come up | `[grounded]` message; R7 | pending your approval |
| P3 | If asked, say plainly that you've never been the only designer, then point to whatever G3 turns up | Being candid on R8 holds up better than stretching it | `[grounded]` your statement | pending your approval |
| P4 | Ask the RR3 and RR4 questions word for word | They're the open items | `[grounded]` register | pending your approval |
| P5 | Expect Ronan to know booking software from the inside: he was product lead at a Galway travel-software company for five years | Your travel-booking background is common ground | `[grounded]` LinkedIn profile snippet; `[inferred]` that his questions will draw on it | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer"; fetched "About Fernquay" (fernquay.example/about); the search returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved the organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 2026 first designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved P5 |

Since you have a call booked, mock-interview can build prep for Ronan and Saoirse whenever you want it.

If it's useful, I can save all of this as a `tuesday-dossier.md` file you can keep and bring back later.

**Upgrade menu**
- Your CV or the case study link: R2–R7 can be checked against it, and R3 and R7 could move to `high`.
- Your salary floor and any non-negotiables: closes the "constraints not given" flag on the hard-gates line.
- Answers to G1–G3: R7, R5 and R8 firm up or change.
- A deeper research pass on Fernquay (customer base, hiring history, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G3: Have you ever owned a project where no other designer reviewed your work, or started a design practice (a component library, a research cadence) yourself? What was it, and what was yours?

G1: In the checkout redesign, which stages of the booking journey did you own beyond the payment step, and did you touch anything on the operator or admin side?

R1: What salary floor and other non-negotiables should I check this against, and are two Galway office days fine for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.