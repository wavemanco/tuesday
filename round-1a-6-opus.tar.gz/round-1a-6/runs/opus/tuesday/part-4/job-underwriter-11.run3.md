I'm checking both employers online before I give you the full assessment of both roles.
**Duinvaart is worth your time. Kroonhaven isn't.** Status for Duinvaart: `conditional_go`. Status for Kroonhaven: `no_go`.

I couldn't check either employer online because the web search wasn't allowed. Everything below comes from the two postings and what you told me, and the IDs (A-R1, B-RR1 and so on) refer to rows in the tables further down.

## Decision snapshot

### A — Operations Analyst, Duinvaart Cold Chain: yes, apply

**Fit ledger.**
- `hard_gate` — unclear: A-R1 (Hybrid, three days a week in our Rotterdam office)
- `must_have` — direct: A-R2, A-R3, A-R4, A-R5 · unclear: A-R6 (Temperature compliance)
- `important` — adjacent: A-R7 (Work with depot managers on route changes)
- `preferred` — direct: A-R8

A-R6 — cold-chain specific, open until AG1 is answered; A-R7 — close, waiting on AG2.

**Opportunity ledger.** The role is clearly scoped (A-RR3). The employer and posting aren't verified yet because my search was blocked (A-RR1). Pay isn't stated (A-RR2), and the "2+ years" bar sits below your four years (A-RR4).

- **Hard gates:** none failed; unconfirmed: A-R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Three days a week in Rotterdam works for you (A-R1).
  2. The posting is live on Duinvaart's own website (A-RR1).
  3. Temperature compliance (A-R6) is described honestly as related work, unless AG1 turns up direct experience.

### B — Supply Planner, Kroonhaven Foods: no, not a good use of your time

B-R3, B-R4 and B-R7, all must-haves, need planning experience you've told me you don't have. B-R1 asks for fluent Dutch.

**Fit ledger.**
- `hard_gate` — unclear: B-R2 (On-site in Utrecht)
- `must_have` — adjacent: B-R1 (Fluent Dutch), B-R5 (Run the weekly S&OP meeting) · unclear: B-R6 (Advanced Excel) · absent: B-R3 (3+ years supply or demand planning in FMCG), B-R4 (Own the 13-week supply plan), B-R7 (SAP IBP or a similar planning system)

B-R3, B-R4, B-R7 — gaps you've confirmed yourself; B-R1 — conversational, not fluent; B-R5 — your route review is a real bridge but can't carry the role alone.

**Opportunity ledger.** The role is clearly defined (B-RR3). The employer isn't verified (B-RR1) and pay isn't stated (B-RR2). None of that drives the decision; fit does.

- **Hard gates:** none failed; unconfirmed: B-R2 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to change:** real supply or demand planning experience (B-R3, B-R4, B-R7) and fluent Dutch (B-R1).

## Role reality

| Element | A — Duinvaart | B — Kroonhaven | Provenance |
|---|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; runs a refrigerated fleet | Kroonhaven Foods, Utrecht; makes a chilled ready-meals range | `[grounded]` posting headers |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | Own the 13-week supply plan; balance production capacity against the forecast; run the weekly S&OP meeting | `[grounded]` postings |
| Working pattern | Hybrid, three office days in Rotterdam | On-site in Utrecht | `[grounded]` postings |
| Scope read | An individual-contributor analyst job very close to the one you just left, with cold chain added | A planning job that owns decisions; sits in a different job family from analysis | `[inferred]` from the stated duties against your stated background |
| Market calibration | Not run, because search was blocked | Not run, because search was blocked | — |
| Unknowns | Salary, team size, who decides route changes | Salary, team size, how much of the S&OP is run in Dutch | `[grounded]` the postings don't say |
| Contradictions | None in the posting | None in the posting | `[grounded]` postings |

## Evidence map

**A — Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A-R1 | Hybrid, three days a week in our Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't said whether the commute works; your last job was in Amsterdam | `[grounded]` posting; your message is silent on location | Closing question 1 |
| A-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. Your own account, nothing inspected yet | `[grounded]` your background | none |
| A-R3 | Strong SQL | must_have | direct | medium | none | "SQL daily", your words. Expect a technical test | `[grounded]` your background; `[generic]` analyst hiring often includes a SQL exercise | none |
| A-R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily | `[grounded]` your background | A sanitized dashboard screenshot would raise this to `high` |
| A-R5 | Track on-time delivery across the fleet | must_have | direct | medium | none | You work on "the on-time delivery dashboard our depot managers use". You didn't say whether you built it, so I haven't assumed you did | `[grounded]` your background | Confirm your part in that dashboard before you describe it |
| A-R6 | Temperature compliance | must_have | unclear | low | discovery | Parcel delivery KPIs are related context. Nothing you've said touches temperature-controlled freight | `[inferred]` from parcel-carrier work; `[generic]` that cold-chain employers probe this | Gap AG1 |
| A-R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review. You didn't say whether it led to route changes | `[grounded]` your background | Gap AG2 |
| A-R8 | Dutch a plus | preferred | direct | medium | none | Conversational Dutch meets "a plus", which sets no level | `[grounded]` posting and your background | none |

**B — Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B-R1 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent, in your own words. Rewording can't close this; only time can | `[grounded]` your background | None for this role |
| B-R2 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't said whether Utrecht five days a week works | `[grounded]` posting | Only matters if you apply anyway |
| B-R3 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | "I've never worked in planning", and logistics isn't FMCG | `[grounded]` your own statement | Carried as a blocking gap |
| B-R4 | Own the 13-week supply plan, capacity vs forecast | must_have | absent | none | capability | Same basis as B-R3. Route analysis isn't capacity planning | `[grounded]` your own statement | Carried as a blocking gap |
| B-R5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Carries over: you ran a recurring weekly review with operations staff. Limit: S&OP balances supply, demand and finance, and your review covered routes | `[grounded]` your background; `[generic]` what S&OP covers | none |
| B-R6 | Advanced Excel | must_have | unclear | low | discovery | You didn't mention Excel. Analysts often use it, but that's an assumption, not evidence | `[inferred]` from your analyst role | Not worth asking about, since it can't change the decision |
| B-R7 | SAP IBP or a similar planning system | must_have | absent | none | capability | You've never worked in planning, so no planning system either | `[grounded]` your own statement | Carried as a blocking gap |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| AG1 | Temperature compliance (A-R6, must_have) | discovery | Delivery-performance work; no temperature data | The one must-have for Duinvaart that isn't direct yet | Pharma, food or other temperature-sensitive parcel lines; any threshold or SLA compliance tracking (delivery windows, damage rates); sensor or telematics data you've queried | A sanitized dashboard page or query showing compliance against a threshold | `[grounded]` your background; `[inferred]` that answering it could move A-R6 |
| AG2 | Route changes with depot managers (A-R7, important) | discovery | You ran the weekly route-performance review | Separates reporting on routes from shaping them | A route or depot change that came out of your review; analysis you gave a depot manager before they changed something | Before/after metrics, a review deck | `[grounded]` your background |
| BG1 | Planning experience (B-R3, B-R4, B-R7, must_have) | capability | Confirmed none | Three must-haves at `absent` | Realistic route: a planning-adjacent analyst job first, such as a demand or supply analyst at a logistics or FMCG firm, then planning | — | `[grounded]` your own statement; `[generic]` common route into planning |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| A-RR1 | Employer not established from attributable sources (search blocked) | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| A-RR2 | Salary not stated | unknown | — | (posting gives no pay) | The figure could be at, above or below your last salary | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| A-RR3 | Clear duties and measures | positive_signal | — | "Track on-time delivery and temperature compliance… weekly dashboards in Power BI" | The job and what counts as success are defined | `[grounded]` posting | Which of these metrics is weakest today? | noted |
| A-RR4 | "2+ years" bar against your four | unknown | — | "2+ years in logistics or operations analysis" | The role may be levelled and paid below your last job | `[inferred]` from the experience bar | What level is this role, and is there room for someone with four years? | unresolved |
| B-RR1 | Employer not established from attributable sources (search blocked) | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site? | unresolved |
| B-RR2 | Salary not stated | unknown | — | (posting gives no pay) | Unknown against your needs | `[inferred]` from the missing figure | What salary range is budgeted? | unresolved |
| B-RR3 | Clear scope | positive_signal | — | "Own the 13-week supply plan… run the weekly S&OP meeting" | Well-defined planning job | `[grounded]` posting | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Apply to Duinvaart first. Lead with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran, said the way you said them | A-R5, A-R7 | `[grounded]` your own words | pending your approval |
| P2 | Before applying, find the role on Duinvaart's own website | A-RR1 | `[grounded]` A-RR1 | pending your approval |
| P3 | Ask about pay and level at the first recruiter contact | A-RR2, A-RR4 | `[grounded]` register | pending your approval |
| P4 | Spend no tailoring effort on Kroonhaven. If you send anything, make it a quick standard application | B-R1, B-R3, B-R4, B-R7 | `[grounded]` evidence map | pending your approval |
| P5 | resume-tailor can tailor your CV to the Duinvaart role once you've decided | — | — | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both were refused because search isn't permitted here. Would have settled A-RR1 and B-RR1 |
| 2. Role-family sweep | unavailable | Not sent because search isn't permitted. Would have given the market calibration row and a pay band for A-RR2 and B-RR2 |
| 3. Hiring manager's public footprint | n/a | Neither posting names one |

If useful, I can save this as a `tuesday-dossier.md` so later work can build on it.

**Upgrade menu**
- **Allow web search:** checks both employers (A-RR1, B-RR1) and adds pay bands for both roles.
- **Your CV:** checks the A-R rows against what you've written.
- **A sanitized dashboard screenshot:** raises A-R4 and A-R5 to `high`.
- **Your home town or commute limits:** settles A-R1 and B-R2.
- **A deeper research pass on Duinvaart** (up to 5 more searches and 2 more fetches, once search is allowed): adds company news and employee reports. Say the word.

**Questions**
1. A-R1: Is three days a week in the Rotterdam office workable for you?
2. AG1: Have you worked with any temperature-sensitive deliveries, such as pharma or food lines, or tracked compliance against a threshold or SLA? What did you track?
3. AG2: Did your weekly route-performance review ever lead to a route or depot change? What was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.