I've loaded the job-check playbook. Next I'll look up Marrowgate Housing's public footprint and typical pay for this role, then write up the answer.
Yes, this is normal. You were told never to hand these over, and that's right before an offer, or to someone you can't place. Your situation is different: you've had a written offer, from the employer's own email domain, after two interviews at their office. I've set out the full check below.

## Decision snapshot

**Yes, at this stage it's normal for them to ask for your bank details, PPS number and passport. They're asking after a written offer that names the role, the pay (€40,000) and your manager. Status: `conditional_go` on accepting.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Two days a week in the Limerick office), R2 (Right to work in Ireland)
- `must_have`: direct: R3, R5, R6, R7 · unclear: R4 (Working knowledge of Irish PAYE, PRSI and USC)
- `important`: direct: R9 · unclear: R10 (Answering staff payroll queries) · absent: R8 (Processing pension changes)

R8: by your own account not yet done hands-on, so it's a learnable gap to raise early; R4 and R10: probably covered by your hotel work but not yet stated; R1 and R2: only you can confirm these.

**Opportunity ledger.** The offer's requests aren't a warning sign. The offer itself and your in-person interviews count in its favour (RR2, RR4). Two things are still open: my web searches were blocked, so I couldn't check Marrowgate online (RR1), and the written contract terms haven't arrived yet (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week in the Limerick office), R2 (Right to work in Ireland); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You're satisfied that marrowgatehousing.ie is the organisation you interviewed with (RR1).
  2. R1 and R2 work for you.
  3. You raise the pension-changes gap with Declan early (R8, A4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick with 240 staff | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` job ad |
| Offer terms | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid with two office days, start date to be agreed after your notice | `[grounded]` offer email |
| Scope read | A standard payroll administrator role. The step up from your current job is scale and frequency: 240 staff monthly instead of 90 fortnightly | `[inferred]` from the ad's figures against your background |
| Market calibration | Not established. Searches were blocked here, so I can't compare €38–42k to the market. The offer is in the middle of their own advertised band | `[grounded]` ad and offer, for the band and the figure |
| Unknowns | Start date; written contract and terms; pension scheme details | — |
| Contradictions | None: the ad's role, location and pay band all match the offer | `[grounded]` ad against offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The ad and offer both state it. You haven't said whether the commute works for you | `[grounded]` ad and offer; your message silent | The R1 question below |
| R2 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | The offer says they'll do a right-to-work check. You haven't stated your status | `[grounded]` offer email | The R2 question below |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years running payroll for 90 staff. Fortnightly to monthly and 90 to 240 staff is a change of scale, not a different skill | `[grounded]` your background; `[inferred]` scale comparison | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say the hotel payroll was run under Irish Revenue rules, though it probably was | `[inferred]` from three years of payroll plus your certificate | See G2 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP. You've stated it but there's nothing to inspect | `[grounded]` your background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R7 | Processing starters and leavers | must_have | direct | medium | none | You do this in your current job | `[grounded]` your background | none |
| R8 | Processing pension changes | important | absent | none | capability | You say you've never done these yourself because your manager handled them. That's your own clear statement, so there's no gap to recover, only one to close | `[grounded]` your statement | Closure path: ask for a handover or training early (A4) |
| R9 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | You do the same monthly reconciliation now | `[grounded]` your background | none |
| R10 | Answering staff payroll queries | important | unclear | low | discovery | Not mentioned. Payroll for 90 staff usually involves queries | `[generic]` that payroll roles field queries | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R8, important) | capability | You've stated you have no hands-on experience | It's part of the job from day one; raising it early stops it surprising you or Declan | Entering pension deductions for starters, processing an opt-out you were told about, checking your manager's pension changes | — | `[grounded]` your statement |
| G2 | Irish PAYE, PRSI, USC (R4, must_have) | discovery | Payroll work with no country stated | It's the ad's core technical requirement | Running payroll submissions to Revenue, handling emergency tax for a starter, applying USC bands | Your certificate syllabus | `[inferred]` that the hotel payroll was Irish |
| G3 | Staff queries (R10, important) | discovery | Not mentioned | It's a stated part of the job | Explaining payslips, sorting tax-credit queries, fixing pay errors | — | `[generic]` role pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (my searches were blocked) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The organisation may be small with little online presence, the listing may be outdated, or it may not be a real employer. None of these is ranked as more likely. Your two interviews at their office and the email from their own domain weigh against the third | `[generic]` pattern, not a claim about Marrowgate | Can you point me to this role on your own careers page? | unresolved |
| RR2 | The written offer names the role, pay, manager and terms, and they match the ad | positive_signal | — | "the permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | The offer is specific and matches the ad | `[grounded]` offer against ad | When will I receive my written contract? | noted |
| RR3 | Written contract terms not yet supplied | unknown | — | "starting on a date we agree once your notice period ends" | Pension scheme, probation and other terms are still to come | `[inferred]` from the offer's silence on them | Could you send the written contract before I give notice? | unresolved |
| RR4 | Two interviews in person at their office | positive_signal | — | your account | The hiring process happened face to face, at the employer's own premises | `[grounded]` your account | — | noted |

Asking for bank details, your PPS number and a passport scan after a written offer like this is routine onboarding, so I've left it out of the register.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept within the five working days if R1 and R2 work for you | see R1, R2, RR2 | `[grounded]` offer | pending your approval |
| A2 | When the onboarding link arrives, go to the portal through the address on marrowgatehousing.ie, or confirm the link with the People team using a phone number from that website. Don't enter your details anywhere else | It's the one check that matters for onboarding | `[generic]` safe-onboarding practice | pending your approval |
| A3 | Know why each item is needed: bank details so they can pay your salary, your PPS number so they can register you with Revenue for PAYE, PRSI and USC, and your passport for the right-to-work check | So you know what you're giving and why | `[generic]` Irish payroll practice; `[grounded]` offer, which gives these reasons | pending your approval |
| A4 | Tell Declan early that you've seen pension changes done but haven't processed them yourself, and ask for a handover | see R8, G1 | `[grounded]` your statement | pending your approval |
| A5 | Get the written contract (RR3) before you hand in notice | see RR3 | `[generic]` job-change practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; the call was refused (permission not granted). It would have tested RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland Limerick 2026"; refused. It would have filled the market calibration row |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. It would have filled in the scope read |

I can save this as a `tuesday-dossier.md` file if you'd like to keep it.

## Upgrade menu

- **Allow web search:** RR1 can be checked and the market calibration row filled in.
- **Tell me where the hotel group's payroll was run:** R4 resolves.
- **A deeper research pass on Marrowgate** (governance, news, staff reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

**R1:** Does two days a week in the Limerick office work for you, commute included?

**R2:** Do you have the right to work in Ireland without needing an employment permit?

**G1:** Have you done any part of a pension change yourself, such as entering a deduction for a new starter, even if your manager signed it off?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.