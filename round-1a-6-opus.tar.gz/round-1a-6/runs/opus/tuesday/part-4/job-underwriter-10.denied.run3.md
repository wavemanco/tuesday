Now the referenced files for Step 1.
## Decision snapshot

**Yes, it's worth pursuing, and the WhatsApp message is a normal scheduling step. I couldn't confirm the company exists, though, because my searches were refused (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R5
- `important`: adjacent: R6 (Own the booking flow end to end), R8 (Research calls with school owners) · unclear: R7 (Being the first and only designer)

R6: a close domain match, though checkout is only one stage of the flow; R7: still open, and G1 asks about it; R8: you've run usability sessions, but it isn't clear any were interviews with business owners.

**Opportunity ledger.** The posting is unusually open about pay and scope (RR3, RR4). The open items are that I couldn't confirm the company exists (RR1), what support a first designer gets (RR2), what the equity terms are (RR5) and how the company is funded (RR6).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company checks out: the invite comes from a Fernquay email address and the company has its own site or a registered company (RR1); (2) you're comfortable with the answers on design support, equity and funding (RR2, RR5, RR6); (3) you describe R7 honestly. You haven't been a sole designer, so don't present yourself as one.

**On the WhatsApp message specifically:** it's routine. It sets up a video call with the co-founder and CTO, with the invite sent by email. It doesn't ask you for money, bank or ID details, and it doesn't try to run the hiring process in chat. It's also specific: it names your checkout case study and the CTO. Nothing about it counts against the company. The check that matters is separate: whether Fernquay itself can be confirmed (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person company in Galway making booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | The first designer: owns the booking flow end to end, runs research calls with school owners, ships with two engineers, works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Process so far | A 45-minute video call with Ronan and the CTO, Saoirse; invite sent by email | `[grounded]` WhatsApp message |
| Scope read | One product surface, one customer type, two engineers. A focused remit, but with no design peers | `[inferred]` from the posting's team size and mandate |
| Market calibration | Not established: the role-family search was refused, and I won't give a salary band from memory | — |
| Unknowns | Company registration and website; funding and runway; equity terms; who reviews design work | — |
| Contradictions | None between the posting and the message | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, and nothing you said conflicts with two office days | `[grounded]` your intake | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer; self-reported, no artifact yet | `[grounded]` your intake | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily"; the checkout case study is the artifact that would show it | `[grounded]` your intake | A portfolio link would raise this to high |
| R4 | Has run their own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your intake | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your intake | none |
| R6 | Own the booking flow end to end | important | adjacent | medium | transferability | Your checkout redesign at a travel-booking company is close to this. Limit: checkout is one stage, and end-to-end ownership isn't established | `[grounded]` your intake; `[inferred]` that travel booking carries over to activity booking | see G3 |
| R7 | Being the first and only designer | important | unclear | low | discovery | You've never been the only designer at a company. Whether you were the only designer in your squad isn't stated | `[grounded]` your intake; requirement `[inferred]` from "You would be our first designer" | see G1 |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | You ran usability sessions with "customers". Whether any were business owners rather than end users isn't stated, so I've assumed not | `[grounded]` your intake; `[inferred]` that small-business owner interviews differ from usability testing | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R7, important) | discovery | You've never been the only designer at a company; what your squad looked like isn't stated | Expect this to be the main probe on the call | Being the only designer in your squad; deciding design calls without a design lead in the room; setting up the usability sessions yourself | The checkout case study's process section | `[grounded]` intake; `[generic]` that first-designer hires get asked about working alone |
| G2 | Research with school owners (R8, important) | transferability | Monthly usability sessions; unclear who the participants were | The posting names this as part of the job | Sessions with suppliers, partners or operators; recruiting participants yourself; turning findings into changes the engineers shipped | Session plans, a findings write-up | `[grounded]` intake |
| G3 | End-to-end booking flow (R6, important) | transferability | Checkout redesign; the wider flow isn't stated | It's the core mandate | Work on search, availability or the stages before and after checkout | The case study | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Company not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to show up much online, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; my searches were refused, and you report finding little online | What's Fernquay's registered company name, and where is the role listed on your own site? | unresolved |
| RR2 | First designer with no design peers | unknown | — | "You would be our first designer" | Design quality may rest on you alone, with feedback coming from the co-founder and engineers | `[inferred]` from the posting's team composition | Who reviews design work, and how are design decisions made between you, Ronan and Saoirse? | unresolved |
| RR3 | Salary range and equity stated up front | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The company is open about pay | `[grounded]` posting | What decides where an offer lands in the range? | noted |
| RR4 | Concrete, realistic scope and a portfolio-friendly process | positive_signal | — | "we would rather see one messy real project than a polished deck" | Clear product, clear customer, and a reasonable ask of applicants | `[grounded]` posting | What would success in the first six months look like? | noted |
| RR5 | Equity terms unstated | unknown | — | "0.5–1% equity" | The value depends on whether it's options or shares, the vesting schedule and the strike price | `[generic]` how startup equity works | Is it options or shares, what's the vesting schedule, and what's the strike price? | unresolved |
| RR6 | Funding and runway unstated | unknown | — | "We are six people" | Job security at a six-person company depends on revenue or funding | `[generic]` early-stage pattern, not a claim about Fernquay | How is Fernquay funded, and how many months of runway do you have? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply on WhatsApp to confirm or move the time. This is fine to do | Scheduling by chat for a call held elsewhere is routine | `[grounded]` the message | pending your approval |
| A2 | Before the call, check that the invite came from a Fernquay email domain, and look the company up on the Irish Companies Registration Office (CRO) | Clears RR1 | `[generic]` standard check for a small Irish company | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions | They said they "loved the checkout case study"; see R4, R6 | `[grounded]` message and intake | pending your approval |
| A4 | Answer R7 plainly: you haven't been the only designer anywhere, followed by what you did own in your squad | Honesty there survives follow-up questions | `[grounded]` intake | pending your approval |
| A5 | Ask the RR2, RR5 and RR6 questions on the call | The register doubles as interview prep | `[grounded]` register | pending your approval |

If you'd like prep for the call with Ronan and Saoirse, the mock-interview module handles that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software Galway"; refused. Would have tested RR1 and the organization row |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 senior mid-level startup"; refused. Would have set the market calibration against €52–60k |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. Would have shaped the scope read and the A3 positioning |

I can save this as a `tuesday-dossier.md` whenever it's useful, with no obligation.

## Upgrade menu

- **Allow web search:** tests RR1 directly, adds a salary band for comparison and fills in Ronan's background.
- **Your portfolio or case-study link:** raises R3 and R6 toward `high`.
- **Your salary floor:** settles the pay check, which is currently unknown.
- **Answers to G1–G3:** R7 could move to `direct` or settle as a named risk.
- **A deeper research pass:** funding, team, news and reviews; up to 5 more searches and 2 more fetches. Say the word and it runs.

**G1:** In your squad of four engineers, were you the only designer? What design calls did you make without a design lead?
**RR1:** What email address did the calendar invite come from, and does it link to a Fernquay website?
**Salary floor:** What's the lowest salary you'd accept? Does €52–60k clear it?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.