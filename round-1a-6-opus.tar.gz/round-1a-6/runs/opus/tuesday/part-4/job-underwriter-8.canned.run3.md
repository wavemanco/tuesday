I'm reading the playbook's last reference files on report layout before I write up the posting assessment.
Ciara, my answer is no. Don't go ahead, and don't send anything. I can't find any trace of Velloway Logistics. Whoever wrote these messages has asked you for money, for a cheque deposit and for your bank, PPS and passport details before any offer, and the whole process runs in chat. Requests like these are very likely a scam. You also shouldn't paste your IBAN into that chat. I didn't need it for this check either, so I've left it out of everything below.

## Decision snapshot

**No, this isn't a job to go ahead with. RR1, RR2, RR3 and RR4 are confirmed severe red flags. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year floor)
- `must_have`: direct: R3, R4 · adjacent: R2 (Strong attention to detail) · unclear: R5 (A quiet place to work)
- `important`: adjacent: R6 (Order processing)

R3, R4 (`medium`): your Excel tracker and written ticket work match, but nothing has been checked yet; R1: the "up to" pay may or may not reach your floor; R2, R6: a credible bridge from courier customer service.

**Opportunity ledger.** The messages ask you to pay €349 for equipment (RR1), to hand over bank, tax and ID details before any offer (RR2), and to lodge a €2,850 cheque and forward most of it (RR3). The whole process happens only in chat (RR4). The employer can't be established (RR5), the pay is stated only as an "up to" figure (RR6) and the contact address isn't on a company domain (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to be different:** Velloway would need to be confirmed through its own website. You'd need a real interview by call or in person, then a written offer that names the role and the pay. No payment and no cheque would be asked of you at any stage.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", named in the posting | `[grounded]` posting header |
| Mandate | Order processing coordinator, home-based, 15–30 hours a week, set your own hours | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission on every order you process" | `[grounded]` posting |
| Pay as a year | About €20,280 at 15 hours a week and about €40,560 at 30 hours, both only if the full €26 an hour applies | `[inferred]` arithmetic on the posting's figures, 52 weeks |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Order-processing and customer-operations coordinators in Ireland: median €31,200 a year, middle half €28,400–€34,100, salaried roles only. This is the usual range for the job, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |
| Unknowns | Whether there is a guaranteed base rate or hours; employment status; who the employer actually is | — |
| Contradictions | The posting says to apply via @VellowayHiring, and a later message switches to a postmail.example email address | `[grounded]` posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year minimum (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because "up to €26 an hour" at 15–30 hours could land below or above it | `[grounded]` your message and the posting; `[inferred]` the annual range | None here, because the decision rests on RR1–RR4 |
| R2 | "Strong attention to detail" | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day for 3 years means steady, careful handling, but nothing shows error rates or accuracy | `[grounded]` your stated background | Carry into other applications as a bridge, with its limit named |
| R3 | "Confident with spreadsheets" | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. That is stated but not yet checked | `[grounded]` your stated background | None |
| R4 | "Good written English" | must_have | direct | medium | none | Three years of written ticket replies, plus training two new starters. That is stated but not yet checked | `[grounded]` your stated background | None |
| R5 | "A quiet place to work" | must_have | unclear | none | discovery | Nothing given about your home setup | `[grounded]` the background is silent on it | None needed for this role |
| R6 | Order processing | important | adjacent | medium | transferability | At a parcel courier, your tickets were about orders and deliveries, which sits next to order processing; actually processing orders isn't stated | `[inferred]` from the title, with nothing listed under duties; `[grounded]` your background | Use as a bridge for genuine coordinator roles |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | An "up to" hourly rate plus commission, with no guaranteed hours | Only matters for a role that verifies, so not this one | — | A written offer with a base rate and contracted hours | `[grounded]` posting wording |
| G2 | Order processing (R6, important) | transferability | Courier customer-service tickets, with no order-entry work stated | For genuine coordinator roles, how strong this bridge is shapes how you position yourself | Fixing delivery or address errors in the courier's system; tracking exceptions in your Excel tracker | A sanitized copy of your tracker's layout | `[inferred]` bridge from your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Money sent by bank transfer is usually hard to get back. Employers don't ask applicants to pay for work equipment, and this request is very likely a scam. Who sent it is unresolved | `[generic]` known pattern for upfront-fee requests; `[grounded]` quote | Ask Velloway, using contact details from its own website and never the chat or the email address: "Did you post this role, and do you ask new hires to pay €349 for equipment?" | confirmed |
| RR2 | Bank, tax and ID details asked before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport…" | A PPS number and a passport photo together allow identity misuse that is hard to undo. Payroll details normally come after a written offer, not before an interview. Who sent it is unresolved | `[generic]` known pattern; `[grounded]` quote | Same route and question as RR1 | confirmed |
| RR3 | Cheque to lodge and forward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | If the cheque bounces after you've forwarded the money, you could owe your bank the €2,500 you sent. This request is very likely a scam, so don't lodge the cheque. Who sent it is unresolved | `[generic]` known pattern for overpayment cheques; `[grounded]` quote | Same route and question as RR1 | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews"; "you passed the interview and the job is yours!" | With no call and no meeting, you can't tell who you're dealing with, and the "offer" came only in chat | `[grounded]` posting and messages | Same route as RR1: "Who would I be interviewing with, and is there a written offer on company letterhead?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale or aggregated, or the posting may not represent a real hiring employer | `[generic]` pattern for firms with no footprint, not a claim about this one | "Can you point me to this role on your own careers site?" | unresolved |
| RR6 | Pay stated as a ceiling plus commission | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | There may be no guaranteed base rate or hours to set against your €30,000 floor (see R1) | `[inferred]` from the "up to" wording and the 15–30 hour range | "What is the guaranteed hourly rate, and how many hours are contracted?" | unresolved |
| RR7 | Contact address not on a company domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example" | The messages may not come from who they name | `[inferred]` from an address that doesn't match any company domain | Covered by RR1's check through the website | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you've checked each request with the employer. Use contact details from the employer's own website, not the chat or the email address these messages came from. Who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: not your IBAN, not your PPS number, not a passport photo, not the €349 | see RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it. Keep it and the envelope | see RR3 | `[grounded]` register | pending your approval |
| A3 | Report the posting to the jobs site where you found it | Jobs sites usually take down postings flagged like this | `[generic]` how job boards handle reports | pending your approval |
| A4 | Put your effort into other order-processing or customer-operations coordinator openings | That role family's usual range sits around your €30,000 floor, and your Excel tracker (R3), ticket writing (R4) and training two new starters match it | `[generic]` Pennoral band; `[grounded]` R3, R4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers", which returned no results. Employer not established, which feeds RR5 |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration and A4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search |

If you'd like, I can write all this up as a tuesday-dossier.md file you can keep.

**Upgrade menu**
- A link to Velloway's own website or careers page, if you find one → I can check RR5 and tell you who to contact for the RR1 check.
- Your CV → firmer rows for genuine coordinator roles (R2, R6).
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) → would add to RR5. Say the word and it runs.

No questions this turn, because nothing you could answer changes the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.