Now the files required for Step 1.
Quick update: I've confirmed Fernquay exists and found a salary benchmark. Next I'm checking their careers page to see if the posting is live.
## Decision snapshot

**Yes, it looks legitimate and it's worth applying for. You're actually already through to the first call. Fernquay matches what its own website says about it (RR2), and nothing in the WhatsApp message asks anything of you beyond scheduling a call (A1). Status: `go`.**

**Fit ledger.**

- `hard_gate`: direct R1
- `must_have`: direct R2, R3, R4, R5, R6
- `important`: adjacent R7 (Research calls with school owners) · unclear R8 (Working as the only designer)

R7: a credible bridge, with its limit named. R8: still open, and the question you should prepare an honest answer for.

**Opportunity ledger.** Sound and fairly open. The pay band is stated (RR1), the company and both people named check out against Fernquay's own site (RR2), the equity terms aren't spelled out (RR3), and being the first designer comes with a wide brief (RR4).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** a calendar invite from outside Fernquay's own domain, or any request for money, bank details or ID before a written offer. Neither is in what you've shared.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle and funded by its customers. Its product is called Kelproster and serves sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` fernquay.example/about, fetched |
| Mandate | First designer. Own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Process so far | Ronan has invited you to a 45-minute video call with Saoirse (CTO). The invite was sent by email; WhatsApp was only used to tell you about it | `[grounded]` the WhatsApp message |
| People | Saoirse, named as CTO, matches co-founder Saoirse Doyle on the about page. Ronan's public profile lists him as co-founder and CEO, and before that five years as product lead at a Galway travel-software company | `[grounded]` about page; `[grounded]` LinkedIn search snippet only, page not opened |
| Scope read | One product area (booking), a small engineering team and a direct line to a founder. A wide brief, but a clear one | `[inferred]` from the posting's mandate and team size |
| Market calibration | Irish product designers with 3–5 years: median base €57,000, middle half €51,500–€62,000. The posting's band sits inside that range | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520); `[grounded]` posting figure |
| Unknowns | Equity form and vesting; what else lands on design beyond the booking flow | — |
| Contradictions | None found. I couldn't find a careers page at fernquay.example/careers, so I couldn't check the posting against their site | `[grounded]` fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | medium | none | You told me you moved back to Galway last year, which meets the office requirement. You haven't stated it as a constraint, so I'm reading it from your background | `[grounded]` your background; posting | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer, from your own account with nothing to inspect yet | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily" | `[grounded]` your background | none |
| R4 | Has run your own user research | must_have | direct | medium | none | "ran monthly usability sessions with customers" | `[grounded]` your background | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | direct | medium | none | Redesigned the checkout flow at a travel-booking company, which is the same kind of flow. Fernquay has already said it "loved the checkout case study". Whether you owned the steps before checkout isn't stated | `[grounded]` your background; WhatsApp message | none |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over. The limit: those were with consumers testing a flow, while this is talking to business owners about how they run their schools | `[grounded]` your background; `[inferred]` the difference, from the posting's "school owners" | see G1 |
| R8 | Working as the only designer | important | unclear | low | discovery | "I've never been the only designer anywhere." Whether you were the only designer inside your squad isn't stated | `[grounded]` your own words; `[inferred]` posting's "our first designer" | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Research calls with school owners (R7, important) | transferability | Monthly usability sessions with customers; nothing yet with business-side users | This is the bridge they're likely to ask about first | Calls with hotel or tour-operator partners or suppliers; interviewing internal ops or support staff about booking problems; recruiting and scripting your own sessions | A discussion guide, a research summary, a session plan | `[grounded]` your background; `[generic]` that first-designer interviews probe research with the actual buyer |
| G2 | Working as the only designer (R8, important) | discovery | You've always had other designers around you | Being alone is the main change in this job, so a concrete answer helps both you and them | Being the only designer in your squad day to day; making design calls without a design lead; setting up your own critique or design QA | A case study showing decisions you made alone | `[grounded]` your own words; `[inferred]` that this is the main change |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary stated, and inside the market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The pay is open and in line with the market for your level | `[grounded]` posting; `[generic]` Tillerby band | Where in the band would this offer sit for someone with four years? | noted |
| RR2 | Employer matches its own site | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The size, location, product and both founders match the about page | `[grounded]` fernquay.example/about | — | noted |
| RR3 | Equity terms not stated | unknown | — | "plus 0.5–1% equity" | The range doesn't say whether it's options or shares, the vesting schedule or the strike price, and those decide what it's worth | `[generic]` early-stage equity varies a lot in these terms | Is it options or shares, what's the vesting and cliff, and what decides 0.5% versus 1%? | unresolved |
| RR4 | Wide brief for a first designer | risk_signal | low | "You would be our first designer: own the booking flow end to end" | Low, because the brief is focused on one product. The role may also pick up brand, marketing site or design-system work with no design peer to review it | `[generic]` common pattern in first-designer roles | Beyond the booking flow, what else would design own in the first year, and how would design work get reviewed? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the call. Before opening the video link, check that the calendar invite came from a Fernquay email address and not a personal one | Arranging an interview over WhatsApp when the call happens elsewhere is a normal step, and checking the sender's address is a quick habit worth keeping | `[generic]` routine scheduling pattern | pending your approval |
| P1 | Lead with the checkout redesign and the monthly usability sessions, in your own words | see R6, R4. Ronan's background is in Galway travel software, so the travel-booking context should land with him | `[grounded]` your background; LinkedIn snippet | pending your approval |
| P2 | Be straightforward that you've always worked alongside other designers, and come with a concrete plan for getting critique on your own | see R8. Don't claim solo experience you don't have | `[grounded]` your own words | pending your approval |
| Q1 | Ask the questions from RR1, RR3 and RR4 on the call | The risk register doubles as your list of questions for them | `[grounded]` register | pending your approval |

If you want to prepare for the 45-minute call itself, mock-interview can build you a prep pack.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway"; fetched "About Fernquay" (fernquay.example/about). A fetch of fernquay.example/careers returned no page. Moved: organization, people and contradictions rows; RR2 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved: market calibration; RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. Moved: people row; P1 |

I can save all of this as a `tuesday-dossier.md` for later, if that's useful.

## Upgrade menu

- **Your portfolio link, or the checkout case study:** would raise R2–R6 from `medium` to `high`.
- **Answers to G1 and G2:** would firm up R7's bridge and settle R8.
- **Your pay floor and any non-negotiables:** would let me check the hard gates against you, not just against the posting.
- **A deeper research pass on Fernquay** (customer reviews of Kelproster, team history, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

**G2:** In your squad, were you the only designer day to day? Can you think of a decision you made and shipped without a design lead signing it off?

**G1:** Have you ever run research with business-side people, such as partners, suppliers or your own ops team, rather than end customers?

**Constraints:** Is there a salary below which you wouldn't move, and anything else you won't compromise on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.