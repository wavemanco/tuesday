Still checking your messages against the job-checking guide. No answer yet, and please don't send anything to them while I finish.
**No, don't go ahead, and don't send your IBAN. I can't confirm the firm exists from here, and the requests in these messages are very likely a scam. RR1, RR2, RR3 and RR4 are confirmed severe red flags. Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (pay of at least €30,000 a year)
- `must_have`: direct: R3, R4 · adjacent: R2 (strong attention to detail)
- `important`: adjacent: R5 (order processing)

R2 and R5: your courier support work is a credible stepping stone, with its limits named in the map. R1: the posting gives a top hourly rate, not a guaranteed base.

**Opportunity ledger.** The messages ask you to pay for equipment (RR1), lodge a cheque and send most of it on (RR2), and send your bank, tax and passport details before any offer (RR3). The whole hiring process runs by chat (RR4), and the HR contact is not on a company domain (RR5). I couldn't find the employer at all (RR6), and the pay terms are a ceiling, not a base (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to be different:** no request for money, a cheque deposit, or bank, tax or ID details before a written offer. Interviews by call or video with an employer you can find through its own website. An offer in writing from that employer's own email domain.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", as named in the posting. Two searches for the name found nothing | `[grounded]` posting; searches returned no results |
| Mandate | Order processing, 15–30 hours a week, you set your own hours | `[grounded]` posting |
| Pay | "Earn up to €26 an hour plus commission on every order you process" | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Order processing and customer operations coordinators in Ireland: median base €31,200 a year, middle half €28,400–€34,100, salaried roles only. This is what to expect from the field, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (n=1,140) |
| Unknowns | The guaranteed base rate, minimum hours, whether you'd be an employee or a contractor, how commission works, and what processing an order actually involves | — |
| Contradictions | Payroll setup is asked for "before your chat interview". The €349 is first to be "refunded with your first wages", then paid out of a cheque instead | `[grounded]` the sender's messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The fit is unclear because "up to €26" is a ceiling. At €26 it comes to about €20,280 a year at 15 hours and €40,560 at 30 hours, and commission is undefined | `[grounded]` posting and your stated floor | Moot given RR1–RR4. On any other posting, check the base rate against €30k |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day, plus the team tracker, is work where accuracy matters. Limit: no error rate or quality score was stated | `[grounded]` your background; `[inferred]` that this volume needs accuracy | A QA score or accuracy figure from your reviews would strengthen it |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. That's stated but nothing has been inspected yet, so expect a probe | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Three years of ticket replies in Zendesk | `[grounded]` your background; `[inferred]` that tickets meant written replies | none |
| R5 | Order processing (from the job title) | important | adjacent | medium | transferability | Courier support handles orders and deliveries from the customer side. Limit: handling queries is not entering or processing orders | `[inferred]` requirement taken from the title; `[grounded]` your courier role | Frame it honestly as adjacent on other applications |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | A top hourly rate and unspecified commission, with no base or minimum hours | Decides whether any version of this role meets €30k | — | A written offer stating the base rate and hours | `[grounded]` posting wording |
| G2 | Attention to detail (R2, must_have) | transferability | High ticket volume, no accuracy measure | Gives you a stronger line on genuine applications | QA scores, low reopen rates, catching address or delivery errors | A performance review excerpt | `[grounded]` your background |
| G3 | Order processing (R5, important) | transferability | Customer-side order work only | It's the core task in roles like this | Correcting orders or addresses in the courier system, raising claims, logging returns | A screenshot of a tracker or log you kept, with personal data removed | `[inferred]` from the title; `[generic]` that this is the core task |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Employers don't ask applicants to pay for their work kit, and a bank transfer is hard to get back once sent. This request is very likely a scam | `[generic]` pattern of requests like this | Ask the employer, through contacts on its own website, never the chat: "Do you charge new staff €349 for equipment through a partner?" | confirmed |
| RR2 | Cheque deposit and forwarding | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show as available and then come back unpaid days later. You would owe the bank everything you transferred. Don't lodge the cheque | `[generic]` pattern of requests like this | See RR1 for the route: "Did you post me a cheque and ask me to forward part of it?" | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Together these details let someone open accounts or claim benefits in your name, and once sent they can't be taken back | `[generic]` pattern of requests like this | See RR1 for the route: "Do you collect payroll details before the interview?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." Later: "you passed the interview and the job is yours!" | This leaves who sent the messages, and whether the named employer is involved, unverified | `[generic]` pattern for chat-only hiring | See RR1 for the route: "Who would I interview with, and how?" | confirmed |
| RR5 | HR contact off any company domain | risk_signal | low | "Any problems, email velloway.hr@postmail.example" | The messages may not come from who they name | `[inferred]` from the address domain | See RR1 for the route: "What is your HR team's email address?" | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The employer may be too new or small to show up, the posting may be stale or copied, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this one | "Can you point me to this role on your own careers site?" | unresolved |
| RR7 | Pay stated only as a ceiling | unknown | — | "Earn up to €26 an hour plus commission" | The guaranteed rate could be below your floor (R1) | `[inferred]` from the "up to" wording | "What is the guaranteed base hourly rate, and the minimum weekly hours?" | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from. Who sent them is not yet confirmed, and I couldn't find a website for the employer at all. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, no PPS number, no passport photo, no €349 | see RR1, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it, and keep it with the envelope | see RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Report the posting to the jobs site where you found it | Jobs sites usually take down listings that get reported | `[generic]` common jobs-site practice | pending your approval |
| A4 | If anything does get sent, contact your bank straight away and report it to the Gardaí | Acting quickly limits the damage | `[generic]` standard advice | pending your approval |
| A5 | Look at salaried order processing and customer operations roles near the €31,200 median, leading with R3 and R4 and framing R2 and R5 honestly as adjacent | Your background fits this field, and the band meets your €30k floor | `[generic]` Pennoral band; `[grounded]` R2–R5 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator". Both returned no results, so the employer is not established. This moved the role reality Organization row and RR6 |
| 2. Role-family sweep | yes | Searched "order processing coordinator Ireland hourly rate remote part-time", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This moved the market calibration row and A5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

I can save this as a `tuesday-dossier.md` file you can reuse later if you'd like.

**Upgrade menu**
- Another posting you're considering → a full fit check against your €30k floor, with R2–R5 carried over.
- A performance review or QA score → R2 rises to a direct match on genuine applications.
- A deeper research pass (up to 5 more searches and 2 more fetches) → it wouldn't change this decision, so I'd only run it for a different employer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.