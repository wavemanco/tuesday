Now the step-1 reference files.
Yes, it's worth taking the call, and Fernquay is a real company. Its own website lists the founders as Ronan Kehoe and Saoirse Doyle, and your posting is live on its careers page. The one condition is that the salary band meets your minimum.

## Decision snapshot

**Yes. It's worth pursuing, and the employer checks out (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct R7 · unclear R8 (Pay €52,000–€60,000)
- `must_have`: direct R1, R2, R3, R4
- `important`: direct R5a · adjacent R5b (Being the first and only designer)

R5b: you can make a credible case from your squad work, with its limit named. R8: depends only on your own salary minimum.

**Opportunity ledger.** The company matches its posting (RR1), and the pay is published and close to the market median (RR2). Two things are unknown: the equity terms (RR3), and who has the final say on design calls (RR4).

- **Hard gates:** none failed (R7 `direct`); unconfirmed: R8 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) €52,000–€60,000 meets your minimum (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` JD and careers page |
| Process so far | Ronan messaged on WhatsApp to book a 45-minute video call with him and Saoirse (CTO), and emailed the invite | `[grounded]` your message. Saoirse as co-founder matches the About page |
| Scope read | Sole designer covering research, flow design and shipping. That's a broad remit, but a normal one for a first design hire at a six-person company | `[inferred]` from the JD's single named flow and team size |
| Market calibration | Tillerby 2026 (Ireland, n=520) puts product designers with 3–5 years at a median base of €57,000, with the middle half between €51,500 and €62,000. The posted €52,000–€60,000 sits inside that range | `[generic]` Tillerby 2026 report; `[grounded]` JD figure |
| Unknowns | Equity terms; who has final say on design; what research access to school owners looks like | — |
| Contradictions | None. The careers page matches the posting you have on title, hybrid pattern and pay | `[grounded]` careers page search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer. That's self-reported with no artifact inspected, so `medium` | `[grounded]` your background | none |
| R2 | Strong Figma | must_have | direct | medium | none | You use it daily. The portfolio is what would show it | `[grounded]` your background | Your case study raises it to `high` |
| R3 | Has run their own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Fernquay's research is calls with business owners, a different audience than consumers, but it's the same practice | `[grounded]` your background; `[inferred]` that the audience differs | Expect to be asked how you'd run research calls with owners |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R5a | Designing a booking flow | important | direct | medium | none | You redesigned the checkout flow at a travel-booking company, and Ronan says he loved that case study | `[grounded]` your background and Ronan's message | none |
| R5b | Working as the first and only designer | important | adjacent | medium | transferability | You've never been the only designer. Squad work with engineers carries over. What it didn't test is setting design direction with no design peer to review your work | `[grounded]` your own statement | see G1 |
| R7 | Two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days look met | `[grounded]` your background | none |
| R8 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't given a salary minimum, so I can't check the band against it | `[grounded]` JD; nothing from you yet | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R5b, important) | transferability | Design work inside a squad; no solo design ownership stated | It's the only row below `direct`, and the obvious thing for a first-designer interview to probe | Driving the checkout redesign when no other designer was assigned to it; setting up the monthly usability sessions yourself; making a design call engineers built from without a design review | The checkout case study, a research plan, session notes | `[grounded]` your statement; `[generic]` that first-design-hire interviews probe working solo |
| G2 | Pay against your floor (R8, hard_gate) | hard_gate | Band €52k–€60k published; your minimum isn't stated | It's the one condition on the decision | — | — | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established, posting live | positive_signal | — | "Open now: Product Designer, our first design hire" | Real six-person company, as the posting describes it | `[grounded]` About page, careers page, Ronan's LinkedIn | How many schools use Kelproster today? | noted |
| RR2 | Pay published and close to the market median | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The band is fair for your level | `[generic]` Tillerby band; `[grounded]` posting | Where in the band would someone with four years land? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage could be options or shares, with or without vesting | `[generic]` a common range of structures at small companies | Is the equity options or shares, what's the vesting schedule, and what decides 0.5% versus 1%? | unresolved |
| RR4 | Who has final say on design | unknown | — | "work most closely with our co-founder, Ronan Kehoe" | Ronan was a product lead for five years, so design ownership may be shared with him | `[inferred]` from his LinkedIn and the JD's "own the booking flow end to end" | When you and the designer disagree on the booking flow, who decides? | unresolved |

Getting a WhatsApp message to schedule a video call, with the invite sent by email, is routine. It doesn't count against the role.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the checkout redesign you did at the Dublin travel-booking company and the monthly usability sessions you ran, in those words | R5a, R3. Ronan has already named that case study, and he spent five years in travel software | `[grounded]` your background, his message and LinkedIn | pending your approval |
| P2 | Bring one real, unpolished project, as the posting asks. The checkout work in raw form would do, if your old employer's confidentiality allows | JD: "one messy real project than a polished deck" | `[grounded]` JD | pending your approval |
| P3 | Prepare an honest answer on R5b: what you drove yourself, and what you'd need without a design peer | G1 | `[grounded]` your statement | pending your approval |
| P4 | Ask the RR3 and RR4 questions on the call, word for word | Unknowns that matter before an offer | `[grounded]` register | pending your approval |
| P5 | Join from the link in the emailed invite, and check it was sent from a fernquay address | Normal care with any invite; scheduling by chat is routine | `[generic]` | pending your approval |

If you'd like rehearsal for the call with Ronan and Saoirse, mock-interview can do that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay careers product designer", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). A fetch of fernquay.example/careers returned no page. Fed: Organization, Contradictions, RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 2026 startup", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Fed: Market calibration, RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Fed: RR4, P1 |

I can also save all of this as a `tuesday-dossier.md` file for later, if that's useful.

## Upgrade menu

- **Your checkout case study or portfolio link:** would raise R2, R3 and R5a to `high`.
- **Your answer to G1:** would strengthen the R5b case or settle it.
- **Your salary minimum:** would close R8, and the status would become `go` or `no_go`.
- **A deeper research pass on Fernquay** (customer base, team changes, public reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

G1: Was there a project, or part of the checkout redesign, where you set the design direction yourself without another designer reviewing it? What did you decide, and what happened?

G2: What's the lowest base salary you'd accept, and does €52,000–€60,000 clear it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.