Checking the employer's public footprint and typical pay before I give you a verdict.
I couldn't run any web checks because all three searches were blocked for lack of permission. So this assessment rests only on the ad, the offer email and your background.

# Job underwriting — Payroll Administrator, Marrowgate Housing

## Decision snapshot

**Yes, it's normal. A written offer that names the job and the salary, following two in-person interviews at their office, is when an employer asks for bank details, PPS number and a passport scan through an onboarding portal. The "never hand those over" rule is about requests made before an offer. On your fit, the offer is worth accepting on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days a week in the Limerick office), R2 (Right to work in Ireland)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC) · absent: R7 (Process pension changes)
- `important`: direct: R8, R9 · unclear: R10 (Answer staff payroll queries)

R7: a gap you've stated yourself, which can be closed with training; R4 (`low`): probably fine, but your background doesn't say it yet.

**Opportunity ledger.** The offer is consistent and open: its terms match the ad (RR2, RR3). I couldn't check the employer from here because my searches were blocked (RR1). The offer doesn't yet cover contract terms beyond pay (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in the Limerick office), R2 (Right to work in Ireland); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: Marrowgate's own website matches the office you interviewed at and the `marrowgatehousing.ie` email domain; (2) R7: you agree with Declan Garvagh how you'll learn pension changes; (3) R1 and R2: you can do two days a week in Limerick and have the right to work in Ireland.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly reconciliation of payroll to the general ledger; staff payroll queries | `[grounded]` job ad |
| Terms offered | Permanent, €40,000, reports to Declan Garvagh (Finance Manager), hybrid with 2 days a week in Limerick, start date agreed after your notice period | `[grounded]` offer email |
| Onboarding steps | Portal link sent after you accept, where you add bank details, PPS number and a passport scan; original passport on day one | `[grounded]` offer email |
| Scope read | About 2.7× your current headcount, but monthly rather than fortnightly runs, so fewer cycles a year | `[inferred]` from 240 vs 90 staff and the two pay frequencies |
| Market calibration | Not established, because the salary search was blocked. €40,000 sits inside the ad's own €38–42k range | `[grounded]` ad and offer |
| Unknowns | Probation, pension scheme, hours, notice terms; whether the employer's own site matches the ad | — |
| Contradictions | None between the ad and the offer | `[grounded]` ad and offer compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You didn't say whether the commute works for you. Attending two interviews there doesn't settle it | `[grounded]` ad and offer state the term; your background is silent | Closing question R1 |
| R2 | Right to work in Ireland (the offer's right-to-work check) | hard_gate | unclear | none | hard_gate | Your status isn't stated, and your passport isn't needed for this assessment | `[inferred]` from the offer's "right-to-work check" | Confirm for yourself; upgrade menu |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, stated but not yet inspected | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say the hotel group's payroll was Irish, or what the Payroll Technician certificate covered | `[grounded]` your background is silent on jurisdiction | Closing question R4 |
| R5 | Process starters and leavers | must_have | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R6 | Monthly reconciliation of payroll to the general ledger | must_have | direct | medium | none | Stated directly: "the monthly payroll-to-ledger reconciliation" | `[grounded]` your background | none |
| R7 | Process pension changes | must_have | absent | none | capability | You said you've never done them yourself; your manager did. The ad lists it among the core duties | `[grounded]` your own words | Closure path: ask for training or a handover; closing question R7 |
| R8 | Strong Excel | important | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your background | none |
| R9 | A payroll qualification, or working towards one | important | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention it | `[grounded]` your background is silent | Upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R7, must_have) | capability | No hands-on processing; your manager handled them | It's a must-have row. Agreeing on training now turns a hidden weakness into a planned one | Asking for a handover from whoever does pension changes now, or a short payroll-pensions course | A training plan in writing, or a course enrolment | `[grounded]` your own words |
| G2 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | Hotel-group payroll and a 2024 certificate; jurisdiction unstated | If confirmed, R4 becomes `direct` | Running Revenue payroll submissions, handling USC or PRSI class changes, certificate modules on Irish payroll taxes | The certificate's module list | `[grounded]` background silent on jurisdiction |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (my searches were blocked) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The organization may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Your two interviews at their office and the offer from their own domain cut against the last of these | `[generic]` pattern, not a claim about this employer | Can you point me to the role on your own careers site, and confirm the office address I interviewed at? | unresolved |
| RR2 | Written offer names the role, salary, manager and terms | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The terms are specific and checkable | `[grounded]` offer email | Can you send the written contract with the start date? | noted |
| RR3 | Offer matches the ad | positive_signal | — | "Salary €38,000–€42,000. Hybrid, two days a week in our Limerick office." | Pay and working pattern are consistent across the ad and the offer | `[grounded]` ad and offer | — | noted |
| RR4 | Contract terms beyond pay not stated | unknown | — | "Please reply to accept within five working days" | Probation, pension and hours may only appear in the contract | `[inferred]` from the offer's silence on them | What are the probation period, pension scheme and contracted hours? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | When the portal link arrives, open it from the address on Marrowgate's own website, or check it matches the `marrowgatehousing.ie` domain. If anything looks off, phone the office number listed on their site | Entering the details only in the employer's own portal is the one check on this step that matters | `[generic]` standard onboarding advice | pending your approval |
| A2 | Ask for the written contract before or when you accept | RR4 | `[grounded]` RR4 | pending your approval |
| A3 | Raise pension changes with Declan Garvagh and ask what training or handover is planned | R7, G1 | `[grounded]` your own words | pending your approval |
| A4 | Hand over the PPS number and passport scan only through the portal, and bring the original on day one as asked | The PPS number is used to register your employment with Revenue, and the passport is the right-to-work check | `[generic]` how Irish onboarding usually works; `[grounded]` the offer states both purposes | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association". The call was refused for lack of permission. It would have settled RR1 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026". The call was refused. It would have filled market calibration |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing". The call was refused. It would have filled in the scope read |

I can save all of this as a dossier file for later interview or CV work if you'd like.

## Upgrade menu

- **Allow web search, or paste Marrowgate's website address:** settles RR1 and adds a market salary band.
- **Your answer on Irish payroll (G2):** R4 moves to `direct` or stays a gap.
- **Your right-to-work status, yes or no only:** settles R2. No document or number is needed.
- **An example of handling staff payroll queries:** settles R10.
- **A deeper research pass** on Marrowgate (leadership changes, staff reviews, news; up to 5 more searches and 2 more fetches). Just say if you want it.

## Questions

**R1:** Does two days a week in the Limerick office work for you, given your commute and your notice period?

**R4:** Was the hotel group's payroll run under Irish PAYE, PRSI and USC, and did your Payroll Technician certificate cover them?

**R7:** Did pension changes come up in either interview, and has anyone said how you'd be trained on them?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.