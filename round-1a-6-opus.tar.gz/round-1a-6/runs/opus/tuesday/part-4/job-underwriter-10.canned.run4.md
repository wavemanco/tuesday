I've read the posting and your background, and I'm now checking whether Fernquay shows up on the web as the posting describes.
Yes, it's worth pursuing, and it checks out. Fernquay's own website matches what you were sent, the job is live on their careers page, and the WhatsApp message only asks to book a video call.

## Decision snapshot

**Yes, worth pursuing, and it looks legitimate: Fernquay and the live posting match what you were sent (RR1). Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4a, R5, R6
- `important` — adjacent: R4b (Research calls with school owners), R7 (Working as the first and only designer)

R7 — a credible bridge with its limit named, the thing to prepare for; R4b — the same research skill, aimed at business owners instead of travellers.

**Opportunity ledger.** The employer and the posting check out (RR1), and the salary is stated and sits inside the market range (RR2). Three things are still open but none is alarming: the equity terms (RR3), working without a design lead (RR4), and what being customer-funded means for runway (RR5).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** your pay floor turning out higher than €60,000; answers on RR3 or RR5 you can't live with; finding out you don't want to be the only designer (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes Kelproster: booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle and funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Who you'd work with | Ronan Kehoe, co-founder and CEO. Before Fernquay he was product lead at a Galway travel-software company for five years | `[grounded]` LinkedIn profile result |
| Scope read | A broad but coherent solo-design role. Research, UX and UI all sit with one person, and nobody senior in design reviews the work | `[inferred]` from "our first designer" plus the listed duties |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting and careers page agree |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting and careers page agree |
| Market calibration | Irish product designers with 3–5 years: median base €57,000, middle half €51,500–€62,000. The posted range sits inside that, with equity on top. This is a market pattern, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520) |
| Unknowns | Equity terms; runway; how design decisions get made with no design lead | — |
| Contradictions | None found. The posting, careers page and About page agree on size, location, pay and hybrid days. The WhatsApp message calls Saoirse the CTO; the About page names her as co-founder without a title. That's consistent, not a conflict | `[grounded]` the pages above |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are workable. Stated by you but not framed as a constraint | `[grounded]` your background; posting | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer. It's your own statement, so expect it to be checked against your CV | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | Figma daily. The portfolio is where they'll see it | `[grounded]` your background | none |
| R4a | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your background | none |
| R4b | Run research calls with school owners | important | adjacent | medium | transferability | Running research is direct. The limit: your sessions were usability tests with travellers, and this role is discovery calls with the business owners who buy the software | `[grounded]` your background; `[inferred]` that operator interviews are different work from usability testing | see G2 |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | direct | medium | none | You redesigned a travel-booking checkout flow, and they've already said they "loved the checkout case study" | `[grounded]` your background; WhatsApp message | none |
| R7 | Working as the first and only designer | important | adjacent | medium | transferability | You've said you've never been the only designer, and that's specific. The pieces carry over: running research yourself, working directly with engineers, shipping a flow. The limit: no experience without design peers, critique or a design lead to set direction | `[grounded]` your statement; `[inferred]` requirement from "You would be our first designer" | see G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working as the first and only designer (R7, important) | transferability | You've always had design colleagues. Nothing yet shows a design decision you made and defended alone | It's the one place your history doesn't match the role, so expect it to come up on the call | A checkout decision you made and argued for with engineers or a PM when no other designer was involved; a research round you planned, ran and synthesised yourself; a time you set priorities without a design lead's input | A section of the checkout case study showing your own decisions; a research plan or synthesis you wrote | `[grounded]` your statement; `[generic]` that founders hiring a first designer probe this |
| G2 | Research calls with school owners (R4b, important) | transferability | You have usability sessions with consumers. Nothing yet on interviewing business owners or operators | Fernquay's paying customers are the schools, so research with owners shapes what gets built | Talking with hotel or tour-operator partners at the travel company; stakeholder interviews with internal ops or support teams; any interview with someone who runs a business | A discussion guide or interview notes | `[grounded]` your background; `[inferred]` that the schools are the buyers, from the About page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The employer and the posting can be checked | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company exists as the posting describes it, and the role is live on its own careers page | `[grounded]` About page and careers page | Who else would I meet before an offer? | noted |
| RR2 | Salary stated and within the market range | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Being open about pay; the range sits inside the market's middle half | `[grounded]` posting; `[generic]` Tillerby band | Where in the range would someone with four years land? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Whether it's options or shares, the vesting schedule and the strike price decide what it's worth | `[generic]` early-stage equity terms vary widely | Is the equity options or shares, what's the vesting schedule, and what happens to it if I leave? | unresolved |
| RR4 | First designer, no design leadership | risk_signal | low | "You would be our first designer … work most closely with our co-founder" | No design critique or mentorship in-house. Scope could grow into brand, marketing and design-system work on top of the booking flow | `[inferred]` from the posting's scope; `[generic]` first-designer roles tend to grow | How will design decisions be made and reviewed, and what's outside this role's scope for the first year? | unresolved |
| RR5 | Customer-funded, no outside investors stated | unknown | — | "funded by its customers" | That could mean steady revenue with less pressure, or a thin runway; it also affects when equity could ever be sold | `[inferred]` from the About page | How many months of runway do you have, and is outside funding planned? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Reply on WhatsApp to confirm the time. Before opening the link, check that the calendar invite comes from a Fernquay address; their careers page uses jobs@fernquay.example. If it doesn't, ask about it at that address | Scheduling over WhatsApp for a call held elsewhere is routine at small companies; checking the sender is basic care, not a sign of trouble | `[generic]` hiring practice; `[grounded]` careers page address | pending your approval |
| P2 | Lead with the checkout redesign and the monthly usability sessions you ran. Ronan was a product lead in travel software for five years, so a booking-flow story will mean something to him | see R6, R4a | `[grounded]` your background and his profile; `[inferred]` that it suits him as a reader | pending your approval |
| P3 | On the solo-designer question, say plainly that you've always worked alongside other designers, then name specific things you did alone. Don't present it as solo experience | see R7, G1 | `[grounded]` your statement | pending your approval |
| P4 | Ask the questions for RR3, RR4 and RR5 word for word on the call | see register | `[grounded]` register | pending your approval |
| P5 | Look at Kelproster's public booking flow before the call, if one is visible | see R6 | `[grounded]` About page names the product | pending your approval |

If you'd like rehearsal for the call with Ronan and Saoirse, mock-interview can build that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay jobs product designer", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Fetched fernquay.example/careers, which returned no page. Moved: the organization and contradictions rows, RR1, RR5 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 2026 mid-level startup", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved: market calibration, RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved: the "who you'd work with" row, P2 |

I can save all of this as a `tuesday-dossier.md` file for later, if that's useful.

**Upgrade menu**
- A link to your checkout case study → R6 and R4a can rise to `high`.
- Your pay floor and any other non-negotiables → the pay check against your own terms, so that clause comes off the hard-gates line.
- Answers to G1 and G2 → R7 and R4b get stronger bridges, and P3 gets concrete examples.
- A deeper look at Fernquay (customer and employee reports, recent news; up to 5 more searches and 2 more fetches) → more detail for RR4 and RR5. Say the word and it runs.

**Questions**

G1 — During the checkout redesign or elsewhere, what's one design decision you made and defended yourself, without a design lead signing off?

R1/pay — Is there a salary you won't go below, or anything else you won't move on, such as office days or start date?

G2 — Have you ever interviewed business owners or operators, like hotel or tour partners or internal ops teams, rather than end customers?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.