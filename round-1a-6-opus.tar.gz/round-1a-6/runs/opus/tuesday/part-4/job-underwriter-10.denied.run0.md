Reading the named references now.
Web search was blocked, so I couldn't check Fernquay online. Here's the assessment from the posting and message you shared.

## Decision snapshot

**Yes, it's worth taking the call. Nothing in the posting or the WhatsApp asks for anything a normal hiring process wouldn't. I couldn't verify the company from here, so check that first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (pay of €52–60k plus equity meets your floor)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (research calls with school owners), R9 (working as the first and only designer)

R9: a real step up, and your squad work is the bridge to it; R8: customer usability sessions carry over to interviewing business owners, with the limit named in the map; R2: unknown until you name your floor.

**Opportunity ledger.** The employer isn't established yet, because my searches couldn't run (RR1). Two things count in its favour: the pay and equity are published (RR2), and the message names your work and both interviewers (RR3). Two things are unknown: who gives you design feedback as the only designer (RR4), and what the equity terms are (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay of €52–60k plus equity meets your floor); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the invite comes from a Fernquay email domain that matches a working company website; (2) R2: the range meets your floor; (3) R9 is presented honestly, as embedded-designer experience and not as solo-designer experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with the two engineers | `[grounded]` posting |
| Reporting line | Works most closely with co-founder Ronan Kehoe; the first call also includes Saoirse, the CTO | `[grounded]` posting and WhatsApp |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Hiring stage | You have applied; you're invited to a 45-minute video call, with the invite sent by email | `[grounded]` WhatsApp |
| Scope read | The booking flow serves two groups: school owners who set it up and their customers who book. Your checkout work covers the customer side | `[inferred]` from "booking software for sea-kayak and surf schools" plus "research calls with school owners" |
| Unknowns | Funding and runway; equity terms; who critiques your design work; whether the first 90 days have set outcomes | — |
| Contradictions | None between the posting and the message | `[grounded]` both inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. That comes from your summary, not a probe, so it's at the intake ceiling | `[grounded]` your background | none |
| R2 | Pay of €52–60k plus 0.5–1% equity meets your floor | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so the gate can't be checked yet | `[grounded]` posting figure; no candidate floor given | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer; self-reported, not probed | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily"; your portfolio is where this shows | `[grounded]` your background | none |
| R5 | Has run their own user research | must_have | direct | medium | none | "ran monthly usability sessions with customers", in your own words | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | direct | medium | none | You redesigned the checkout flow at a travel-booking company, and they say they "loved the checkout case study" | `[grounded]` your background and WhatsApp | none |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | The carry-over is planning, running and synthesising sessions. The limit: usability sessions with customers aren't discovery interviews with business owners about how they run their operations | `[grounded]` your background; `[generic]` that operator interviews are different work from usability testing | G2 |
| R9 | Working as the first and only designer (no design peers or lead) | important | adjacent | medium | transferability | You've never been the only designer anywhere. The carry-over is that, embedded in a squad, you already made design calls alongside engineers. The limit: someone else owned design critique, standards and priorities | `[inferred]` from "you would be our first designer"; `[grounded]` your statement | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R9, important) | transferability | Embedded squad experience; no time as the sole designer | They're likely to probe how you'd work without design peers | Times you were the only designer on a project; setting up the usability programme yourself; making a design call with no design review; building or maintaining components the engineers used | A case study showing decisions you made alone, or a messy project file | `[grounded]` your statement; `[generic]` that founders hiring their first designer probe this |
| G2 | Research with school owners (R8, important) | transferability | Customer usability sessions; no stated research with businesses | Running these calls is a stated part of the job | Interviews with hotel or tour-operator partners; supplier-side research at the travel company; recruiting and scheduling participants yourself | A research plan or a synthesis from one session | `[grounded]` posting and your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (searches couldn't run) | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Could you point me to Fernquay's website and the role on it, and tell me how the company is registered? | unresolved |
| RR2 | Pay and equity published | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Pay terms are transparent from the start | `[grounded]` posting | Where in the range do you expect to land for someone with 4 years' experience? | noted |
| RR3 | Specific, named contact | positive_signal | — | "we loved the checkout case study … me and Saoirse, our CTO" | Someone has actually read your application | `[grounded]` WhatsApp | Which part of the case study stood out? | noted |
| RR4 | Sole-designer support unstated | unknown | — | "You would be our first designer" | There may be no one to critique or back your design decisions | `[inferred]` from the first-designer framing and its silence on design feedback | Who gives design feedback today, and how are design decisions settled when you and the engineers disagree? | unresolved |
| RR5 | Equity terms and runway unstated | unknown | — | "plus 0.5–1% equity" | The equity's value depends on vesting, strike price and funding stage, none of which are stated | `[generic]` that early-stage equity value depends on these terms | What's the vesting schedule, how is the company funded, and how many months of runway do you have? | unresolved |

Contacting you on WhatsApp to arrange a video call that's booked by emailed invite is a routine scheduling step. It gets no entry above.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite came from a Fernquay email domain, that the domain has a working website, and that the video link is a mainstream platform which doesn't ask you to install anything unusual | RR1 | `[generic]` standard checks for an unfamiliar small employer | pending your approval |
| A2 | Look Fernquay up on the Irish Companies Registration Office (CRO) search | RR1 | `[generic]` Irish companies are listed there, though a very new one may still trade under a different registered name | pending your approval |
| P1 | Lead with the checkout redesign and the monthly usability sessions, in your own words ("redesigned our checkout flow", "ran monthly usability sessions with customers"), and say you were embedded in a squad with four engineers | R5, R6, R7 | `[grounded]` your background | pending your approval |
| P2 | Say plainly that you've never been the only designer, and give the G1 examples you can stand behind | R9 | `[grounded]` your statement | pending your approval |
| P3 | Bring one messy real project, since they asked for that over a polished deck | R4, R6 | `[grounded]` posting | pending your approval |
| Q1 | Ask the questions from RR1, RR4 and RR5 on the call | Register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay Galway booking software kayak surf schools"; the search was refused. It would have tested RR1 and role reality's organization row |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland startup Galway 2026"; the search was refused. It would have added a market calibration line and checked the €52–60k range against it |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; the search was refused. It would have shaped role reality's scope read and P1 |

If you'd like a `tuesday-dossier.md` of this assessment to carry into later steps, just say so.

**Upgrade menu**
- Allow web search → RR1 can clear or stand, and a salary benchmark for Galway or Ireland gets checked against R2.
- Your salary floor and any other constraints → R2 closes and the hard-gates line becomes complete.
- The sender address on the invite → evidence for RR1.
- A sole-designer example or a research plan → R9 or R8 gets stronger.
- A deeper research pass on Fernquay (funding, leadership, news; up to 5 more searches and 2 more fetches) → feeds RR1 and RR5. Say the word and it runs.

**Questions**

R2: What's the lowest salary you'd accept, and does equity count toward it for you?

G1: Has there been a project where you were the only design voice, or made a design call with no design review? What did you decide?

RR1: What email address did the calendar invite come from, and does that domain lead to a Fernquay website?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.