Now reading the referenced files.
Web search wasn't permitted, so this assessment is based only on what you pasted.

## Decision snapshot

**Yes, it's worth taking the call. The WhatsApp message is routine scheduling: it asks only for a video call, and the invite went to your email. But I couldn't confirm Fernquay exists, so do a quick check first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus 0.5–1% equity)
- `must_have`: direct: R3, R4, R5, R7, R8a · adjacent: R6 (Research calls with school owners) · unclear: R8b (First designer, owning the flow end to end)
- `important`: direct: R9

R8b: you've never been the only designer, and that's the real open question; R6: customer usability sessions are a good bridge to interviewing business owners, with limits; R2: depends on a pay floor you haven't told me.

**Opportunity ledger.** The terms are clear and published (RR2). The equity details (RR3) and how design decisions get made (RR4) aren't stated. Fernquay isn't confirmed yet because my searches were refused (RR1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given, so I couldn't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay checks out as a real company (RR1, plan rows P1 and P2); (2) the salary range meets your floor (R2); (3) you're happy being the only designer once you've thought about what you actually owned at your last job (R8b, G2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Reporting | Works most closely with co-founder Ronan Kehoe; the interview also includes Saoirse, the CTO | `[grounded]` posting and message |
| Working pattern | Hybrid: two days a week in the Galway office, the rest from wherever suits you | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | A generalist role: design, research and shipping all belong to one person, with no design peer or design lead mentioned | `[inferred]` from "our first designer" and the team size |
| Market calibration | Not checked, because the salary search was refused. I can't tell you how this range compares to the market | — |
| Unknowns | Equity terms (options or shares, vesting); who has final say on design; what success looks like in the first months | — |
| Contradictions | None. The sender's name and role, the CTO and the hiring step all match the posting | `[grounded]` posting against message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the office days look workable. That's your own account, not checked | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity, against your floor | hard_gate | unclear | none | hard_gate | The posting states the pay, but you haven't stated a floor, so I can't tell whether this meets it | `[grounded]` posting; no constraint given | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, by your own account | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily." Your portfolio would be the proof | `[grounded]` your background | none |
| R5 | Has run their own user research | must_have | direct | medium | none | "Ran monthly usability sessions with customers." It isn't clear yet whether you also recruited participants and wrote the scripts yourself | `[grounded]` your background | none |
| R6 | Run research calls with school owners | must_have | adjacent | medium | transferability | You've run usability sessions with consumers. Discovery interviews with small business owners about how they operate are a different kind of research, and nothing you've said covers them yet | `[grounded]` your background; `[inferred]` the difference, drawn from the posting's "school owners" | G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8a | Designing a booking flow | must_have | direct | medium | none | You redesigned checkout at a travel-booking company, which is the same kind of product. The message says they "loved the checkout case study" | `[grounded]` your background and the message | none |
| R8b | First designer: own the flow end to end with no design peers | must_have | unclear | low | discovery | You've never been the only designer anywhere. You may still have owned checkout from start to finish inside your squad, but your background doesn't say | `[grounded]` your own words: "never been the only designer" | G2 |
| R9 | "One messy real project" rather than a polished deck | important | direct | medium | none | You already have a real project they've seen and liked | `[grounded]` posting and message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Research calls with school owners (R6, must_have) | transferability | Usability sessions with consumers; nothing yet with business-side users | It's a core part of the job, and it's likely to come up in the interview | Interviewing hotel, tour or supplier partners at the travel company; talking to customer-support or operations staff about how bookings break; research done in a side project or freelance work | A research plan, a discussion guide or a synthesis board | `[grounded]` your background; `[generic]` that first-designer interviews often probe research range |
| G2 | First designer, no design peers (R8b, must_have) | discovery | Four years always working alongside other designers | It's the biggest difference between this job and your last one, and it affects both whether you'd enjoy it and how you present yourself | Owning checkout from first research to release; making design calls with no design review; setting up your own sessions and acting on the results | The checkout case study, showing which decisions were yours | `[grounded]` your own words |
| G3 | Pay against your floor (R2, hard_gate) | hard_gate | The posting states €52,000–€60,000 plus equity; you haven't said what you need | It's the one term that could rule the job out | — | — | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have much online presence, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Could you send me the link to this role on your own website, and confirm the calendar invite came from your company email? | unresolved |
| RR2 | Pay, equity and working pattern all stated up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week" | The terms are clear and published; you won't have to dig for them | `[grounded]` posting | — | noted |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The equity could be options or shares, and the vesting and valuation could vary a lot; the percentage alone doesn't tell you its value | `[generic]` how early-stage equity is usually structured | Is the equity options or shares, what's the vesting schedule, and what decides where in the 0.5–1% range an offer lands? | unresolved |
| RR4 | Decision rights and success measures for a sole designer | unknown | — | "own the booking flow end to end" | "Own" may mean full say over design, or designing within the co-founder's direction; no measure of success is stated | `[inferred]` from the posting's ownership language and its silence on how success is judged | Who has the final say on design decisions, and what would a great first six months look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before the call, check that the invite email comes from an address on Fernquay's own website domain, and that the video link opens a normal meeting tool without asking you to install anything or enter personal details | Scheduling over WhatsApp is routine; this is just a quick check that the sender is who they say | `[generic]` common-sense check, not a concern about this message | pending your approval |
| P2 | Search Fernquay on the Companies Registration Office (cro.ie), and look for the company's website and Ronan Kehoe's professional profile | This would settle RR1 in a few minutes. A very new company can trade under a different registered name | `[generic]` how Irish companies are registered | pending your approval |
| P3 | Lead with the checkout redesign and the monthly usability sessions | They've already said they liked the checkout case study; see R8a and R5 | `[grounded]` message and your background | pending your approval |
| P4 | Have a straight answer ready on never being the only designer: say so plainly, then explain what in the checkout work was yours | They're likely to ask about R8b; candour works better than spin | `[grounded]` your own words | pending your approval |
| P5 | Ask the questions from RR1, RR3 and RR4 on the call | They test your remaining conditions in person | `[grounded]` register | pending your approval |

If you'd like practice for the call with Ronan and Saoirse, the mock-interview module can run it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Fernquay Galway booking software kayak surf schools" was refused (permission not granted). It would have confirmed or cleared RR1 and the organization row |
| 2. Role-family sweep | unavailable | The search "product designer salary Ireland startup 2026 Galway" was refused. It would have filled in market calibration and put R2's range in context |
| 3. Hiring manager's public footprint | unavailable | Not sent, because search permission wasn't granted in this session. It would have informed the scope read and P3's positioning for Ronan Kehoe |

I can save all of this as a `tuesday-dossier.md` file you can reuse in later prep, if you'd like.

## Upgrade menu

- **Turn on web search:** I'd run targets 1–3 above, which could clear RR1 and show you how the salary compares to the market. A deeper pass after that (funding, team history, news; up to 5 more searches and 2 more fetches) is also available if you want it.
- **The link to the posting on Fernquay's own site, or the sender address on the calendar invite:** RR1 could close and the decision could move to `go`.
- **Your pay floor:** R2 settles as met or failed.
- **Your answer to G2, plus your checkout case study:** R8b gets a real fit status, and R8a and R5 move toward `high`.
- **A research plan or discussion guide you've written:** this would strengthen the bridge in R6.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

1. **G2:** In the checkout redesign, which decisions were yours from start to finish, from research through to what shipped, and where did you rely on another designer?
2. **G3:** What's the lowest salary you'd accept, and does equity count toward it?
3. **G1:** Have you ever interviewed business-side users, such as partners, suppliers or internal ops staff, about how they work rather than how they use a screen?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.