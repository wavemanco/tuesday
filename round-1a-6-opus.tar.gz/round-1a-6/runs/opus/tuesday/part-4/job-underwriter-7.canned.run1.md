Reading the referenced files.
Now the worked report (for shape).
Your CV and the advert are in. I've checked the employer and pay with four web searches. Here's my assessment.

## Decision snapshot

**Yes, this one is worth applying for, with the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5, R7a, R9 · adjacent: R12 (Visiting housebound adults at home), R13 (A small caseload of your own) · unclear: R6 (Leg-ulcer care), R7b (Continence care), R8 (End-of-life visits), R10 (Care planning), R11 (Electronic patient record)
- `preferred`: absent: R14 (Doppler assessment for leg ulcers)

R4: your CV doesn't mention it, but nothing contradicts it, and one answer probably closes it; R12, R13: the discharge-to-assess home visits are a real bridge, with its limit named; R14: say plainly you haven't done it, don't cover it.

**Opportunity ledger.** The role itself looks sound. The pay is stated and sits around the market figure (RR1), the caseload comes with named support (RR3), and the team lead has spoken publicly on Doppler training for nurses new to community work (RR5). Still unknown: whether the post is still open (RR2), and the caseload size and working pattern (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4 is backed by an answer to G1; (2) you check R1 and R2 yourself, on your own NMC register entry and DVLA driving record; (3) R13 and R14 are described honestly in the application: you haven't held your own caseload, and you haven't done a Doppler assessment.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the company's "About" page (search result) |
| Mandate | District nursing for housebound adults: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all recorded on an electronic record | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | A normal Band 5 community post. "Supported" suggests it's built for nurses who haven't held a caseload before | `[inferred]` from the advert's "supported by a senior community nurse" |
| Pay and travel | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Band 5 community staff nurses in England: median basic pay £34,300, middle half £32,400–£36,600. The advertised range spans that whole spread. This is market data, not what this employer will offer you | `[generic]` Wardround 2026 community nursing pay guide (n=1,240); `[grounded]` advert range |
| Unknowns | Whether the posting is live; caseload size; hours, weekends and evenings; which hub; whether Doppler training is offered | n/a |
| Contradictions | None found between the advert and the company's own page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Adult registration, active, revalidation due March 2028. I haven't checked it, and the number went into no search | `[grounded]` CV | You check your own entry on the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Not checked | `[grounded]` CV | You check your DVLA driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical staff nurse, more than five times the minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | Your CV doesn't mention record-keeping, and I won't assume it from your job title | `[grounded]` CV silence | G1 |
| R5 | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds, as stated | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | unclear | low | discovery | Your wound care covers pressure ulcers and surgical wounds; your CV doesn't say whether you've dressed or managed leg ulcers | `[grounded]` CV | G3 |
| R7a | Catheter care | important | direct | medium | none | Stated as written | `[grounded]` CV | none |
| R7b | Continence care (beyond catheters) | important | unclear | low | discovery | Your CV says catheter care, not continence assessment or products | `[grounded]` CV | G6 |
| R8 | End-of-life visits | important | unclear | low | discovery | Not mentioned. An acute medical ward or the D2A secondment may have involved it, but that's a question to ask, not a claim | `[grounded]` CV silence | G2 |
| R9 | Insulin administration | important | direct | medium | none | Stated as written | `[grounded]` CV | none |
| R10 | Care planning | important | unclear | low | discovery | Not mentioned | `[grounded]` CV silence | G5 |
| R11 | Recording on an electronic patient record | important | unclear | low | discovery | Your CV names no record system, paper or electronic | `[grounded]` CV silence | G4 |
| R12 | Visiting housebound adults at home | important | adjacent | medium | transferability | 18 months of home visits in patients' first week after discharge. Limit: short-term visits to people just out of hospital, not ongoing care of housebound patients | `[grounded]` CV | G7 |
| R13 | Holding a small caseload of your own | important | adjacent | medium | transferability | You say you've never held one. The D2A visits are the nearest experience; how much of that work you planned yourself isn't stated | `[grounded]` CV, including your own "never held my own caseload" | G7 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. It's desirable, not essential, so it's a minor risk. Closure path: training on the job or a short course | `[grounded]` your own statement | Ask RR5's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clear, timely written records (R4, must_have) | discovery | Nothing on record-keeping | It's the one must-have not yet shown; closing it would move the decision towards `go` | Nursing notes and handovers on the ward; D2A visit notes written up after home visits; a records or documentation audit you took part in | A sanitized audit result, or a note from a manager or appraisal | `[grounded]` CV silence; `[inferred]` that closing it moves the status |
| G2 | End-of-life visits (R8, important) | discovery | Nothing on end-of-life care | It's a core part of district nursing workload as the advert lists it | Caring for dying patients on the ward; syringe-driver or anticipatory-medicines work; talking with families; D2A patients who deteriorated at home | A palliative care training certificate | `[grounded]` CV silence; `[grounded]` advert lists it |
| G3 | Leg-ulcer care (R6, important) | discovery | Wound care stated, leg ulcers not named | Leg ulcers are where the Doppler gap (R14) comes in | Applying compression bandaging; dressing venous ulcers on ward patients | A tissue-viability or wound-care course certificate | `[grounded]` CV wording |
| G4 | Electronic patient record (R11, important) | discovery | No system named | All the work is recorded on one | Electronic records on the ward or in D2A, such as SystmOne, EMIS or a hospital system | Name of the system | `[grounded]` CV silence |
| G5 | Care planning (R10, important) | discovery | Not mentioned | It's part of holding a caseload | Writing or reviewing care plans on admission or in D2A | n/a | `[grounded]` CV silence |
| G6 | Continence care (R7b, important) | discovery | Catheter care only | It's listed with catheter care in the advert | Continence assessments, product choice, bladder or bowel care | n/a | `[grounded]` CV wording |
| G7 | Home visits and own caseload (R12, R13, important) | transferability | Home visits stated; caseload ownership ruled out by you | This is the main difference between you and a nurse already in community work | Planning your own day of visits; deciding when a patient no longer needed visits; referring on to district nurses; lone working | A D2A visit-planning document or referral template (sanitized) | `[grounded]` CV; `[inferred]` that this is the main difference |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, plus mileage and pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The pay is open and spans the market spread for the role | `[grounded]` advert; `[generic]` Wardround pay guide | Which point on the scale would I start on with five years' post-registration experience? | noted |
| RR2 | Posting not found on the company's careers page | unknown | — | "Current vacancies are listed on our careers page" | The careers page didn't load, and searching found no copy of the post. It may be listed elsewhere (e.g. NHS Jobs), or the page may have moved | `[generic]` pattern for how community providers list vacancies, not a claim about this one | Is this post still open, and where is it advertised? | unresolved |
| RR3 | Caseload comes with named support | positive_signal | — | "supported by a senior community nurse" | Support is designed into the role | `[grounded]` advert | In the first months, what does that support look like: joint visits, a gradual build-up of caseload, a named mentor? | noted |
| RR4 | Caseload size and working pattern not stated | unknown | — | "a small caseload of your own" | "Small" is undefined; nothing on weekends, evenings or which hub | `[inferred]` from the advert's silence | How many patients is a typical Band 5 caseload, and what's the weekend and evening rota? | unresolved |
| RR5 | Team lead has spoken on Doppler training for staff new to community work | positive_signal | — | "spoke … on Doppler training for staff new to community work" | Training may be on offer here, which would close R14 | `[grounded]` community nursing forum speaker page; `[inferred]` that it applies to this team | Is Doppler training provided for nurses new to the team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and DVLA record before applying | See R1, R2. Both are stated but not checked | `[grounded]` R1, R2 | pending your approval |
| A2 | Take up the offer of an informal chat with Rhiannon Mabbott, and ask RR2–RR5's questions | The advert invites it, and the register's questions are written to be asked aloud | `[grounded]` advert; register | pending your approval |
| A3 | Lead with the D2A secondment, described as it was: home visits in patients' first week after discharge, not caseload holding | See R12, R13 | `[grounded]` CV | pending your approval |
| A4 | Say plainly you haven't done a Doppler assessment, and ask about training | See R14, RR5. It's desirable, not essential | `[grounded]` your statement; forum page | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for any of this, so I haven't used it or repeated it. Your NMC PIN went into no search either; checking it is yours (A1).

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse" and "Calderbrook Community Health careers vacancies community staff nurse Band 5"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Tried to fetch calderbrookhealth.example/careers; no page there. Moved role reality's organization row and RR2 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026/27 community staff nurse district nursing"; returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead Calderbrook"; returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved RR5 and A4 |

I can save all of this as a `tuesday-dossier.md` to carry into later steps, if you'd like.

## Upgrade menu

- Your answer to G1 moves R4 up and the status towards `go`.
- Answers to G2–G6 settle R6, R7b, R8, R10 and R11.
- A training certificate (wound care, palliative care, compression) or a sanitized audit result raises the matching row from `medium` towards `high`.
- Your own limits (hours, weekends, how far you'll travel within Calderdale) let me check R-rows against them instead of flagging "candidate constraints not given".
- The live posting link or NHS Jobs reference closes RR2.
- A deeper look at Calderbrook (staff reviews, CQC reports, recent news; up to 5 more searches and 2 more fetches): just say so and it runs.
- Once you decide to apply, resume-tailor can turn these rows into CV edits for this post.

G1: On the ward or in D2A, what did your record-keeping involve: what did you write, on what system, and has it ever been audited or commented on?

G2: Have you cared for patients at the end of life, on the ward or at home, and what did you do yourself?

G7: In the D2A team, did you plan your own visits, write or review care plans, or decide when someone no longer needed visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.