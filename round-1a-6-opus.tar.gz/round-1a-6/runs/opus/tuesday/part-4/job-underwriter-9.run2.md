Checking the employer's public footprint and typical pay for the role. Then I'll give you the full read.
**Yes, this is normal. Once you have a written offer, asking for bank details, your PPS number and a passport scan is routine onboarding: `conditional_go`.** "Never hand those over" is the right rule before an offer, or with someone you can't place. Here you have a written offer from the employer's own domain, after two interviews at its office, naming the role, the pay and your manager. That is the point where these details are normally collected.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R10 (Hybrid, two days a week in the Limerick office), R11 (€40,000 a year), R12 (Right to work in Ireland)
- `must_have`: direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI and USC)
- `important`: direct: R6, R8 · adjacent: R5 (Monthly payroll for 240 staff) · unclear: R9 (Answering staff payroll queries) · absent: R7 (Pension changes)

R2: open until you confirm your hotel payroll ran under Irish PAYE; R5: a step up in size and pay cycle, its limits named; R7: learnable, carried as a minor risk.

**Opportunity ledger.** Mostly positive. The offer matches the ad and came after in-person interviews at the employer's office (RR2), and the pay is stated and inside the advertised range (RR3). Two things are open: my checks on the employer couldn't run (RR1), and you haven't seen the contract yet (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days a week in the Limerick office), R11 (€40,000 a year), R12 (Right to work in Ireland); candidate constraints not given, so checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R10, R11 and R12 work for you; (2) RR1 clears, which you can confirm yourself (see the upgrade menu); (3) you raise R7 honestly with your new manager, Declan, rather than letting it surface in your first month.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` job ad |
| Terms offered | Permanent, €40,000, reporting to Declan Garvagh, Finance Manager; hybrid with two days a week in Limerick; start date agreed after your notice | `[grounded]` offer email |
| Onboarding steps | Accept within five working days. You then get a portal link for bank details, PPS number and a passport scan, and bring the original passport on day one | `[grounded]` offer email |
| Why each detail is asked | Bank details are for paying your salary. Your PPS number is how an Irish employer registers you with Revenue for PAYE, PRSI and USC. The passport is for the right-to-work check | `[grounded]` offer email states each purpose; `[generic]` that Irish employers need a PPS number to register a new employee with Revenue |
| Unknowns | Contract terms beyond pay (probation, pension scheme, hours); how pension changes are handed over | none |
| Contradictions | None found. The offer's pay sits inside the ad's €38,000–€42,000, and its hybrid pattern matches the ad | `[grounded]` ad against offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | You describe 3 years running payroll. It's self-reported, so `medium` is the ceiling at this stage | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say whether the hotel group's payroll was Irish. Your Payroll Technician certificate may have covered Irish payroll, but that isn't stated | `[inferred]` from silence on jurisdiction | G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, with pivot tables and XLOOKUP, stated specifically | `[grounded]` your background | none |
| R4 | Payroll qualification, or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself would raise this to high | `[grounded]` your background | none |
| R5 | Run the monthly payroll for 240 staff | important | adjacent | medium | transferability | Same kind of work, but you ran it fortnightly for 90 staff. Limit: you haven't run a monthly cycle or this headcount | `[grounded]` your background against the ad | G2 |
| R6 | Process starters and leavers | important | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R7 | Process pension changes | important | absent | none | capability | You say you've never done these yourself because your manager handled them | `[grounded]` your own statement | G3 |
| R8 | Reconcile payroll to the general ledger each month | important | direct | medium | none | You've done the same monthly reconciliation | `[grounded]` your background | none |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` your background is silent | G4 |
| R10 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You haven't said whether two office days in Limerick work for you | `[grounded]` offer and ad; no constraint stated | question R10/R11 |
| R11 | €40,000 a year | hard_gate | unclear | none | hard_gate | No pay floor stated, so I can't check the offer against your needs | `[grounded]` offer; no floor stated | question R10/R11 |
| R12 | Right to work in Ireland (the offer's passport check) | hard_gate | unclear | none | hard_gate | You haven't stated your right-to-work status | `[grounded]` offer email | question R12 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R2, must_have) | discovery | Payroll experience and a payroll certificate, but no stated jurisdiction | A must-have row that is still `unclear` | Running hotel payroll under Revenue's PAYE system; handling emergency tax or USC rate changes; payroll submissions to Revenue | The Payroll Technician syllabus or certificate | `[grounded]` silence on jurisdiction |
| G2 | Monthly payroll at 240 staff (R5, important) | transferability | Fortnightly payroll for 90 staff | Carries over: the core cycle. Limit: a monthly cadence and nearly three times the headcount. Strengthener: ask how the current cycle is run and timed | Covering a peak-season headcount; any monthly salaried run alongside the fortnightly one | A run checklist you built | `[grounded]` your background against the ad |
| G3 | Pension changes (R7, important) | capability | You haven't processed these yourself | Closure path: a handover or training in your first weeks, or a short pension-payroll module | Seeing your manager handle them; checking pension deductions during reconciliation | none yet | `[grounded]` your own statement |
| G4 | Staff payroll queries (R9, important) | discovery | Not mentioned | Probably already part of your hotel work | Explaining payslips or tax to hotel staff; fixing pay errors | none needed | `[inferred]` from the role you held |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources: my research searches were refused in this session, so I couldn't check Marrowgate's own site | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Two in-person interviews at its office already count against all three | `[generic]` pattern, not a claim about this employer; `[grounded]` your two in-person interviews | Can you confirm marrowgatehousing.ie is your website, and that the onboarding portal is reached from it? | unresolved |
| RR2 | Written offer from the employer's domain, after in-person interviews, naming the role, pay, manager and terms | positive_signal | — | "we are delighted to offer you the permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | A complete, consistent offer that matches the ad | `[grounded]` offer email and ad | When will the written contract follow? | noted |
| RR3 | Pay stated and inside the advertised range | positive_signal | — | "Salary €38,000–€42,000" / "€40,000 a year" | The terms are transparent | `[grounded]` ad and offer | Is there an annual increment or pay scale for this post? | noted |
| RR4 | Contract terms beyond pay not yet seen | unknown | — | "Please reply to accept within five working days" | Probation, pension scheme and hours aren't stated in what you've shared | `[grounded]` offer email's silence on them | Could you send the contract, or a summary of probation, pension and hours, before I accept? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter your bank details, PPS number and passport scan only in the onboarding portal, reached from the address on Marrowgate's own website. Don't send them by email reply or attachment. If anything asks for them another way, phone the People Team on the number from their website | This is the one check that matters for routine onboarding | `[generic]` standard onboarding safety | pending your approval |
| A2 | When you accept, ask RR4's question about the contract | So you see probation, pension and hours in writing | `[grounded]` RR4 | pending your approval |
| A3 | Tell Declan early that you've seen pension changes done but haven't processed them yourself, and ask how they're handed over | Being honest about R7 at the start costs less than it surfacing at month-end | `[grounded]` your own statement (R7) | pending your approval |
| A4 | Before you start, refresh Irish PAYE, PRSI and USC, and monthly payroll timing | Covers R2 and R5 | `[grounded]` R2, R5 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; the call was refused. It would have cleared RR1 and confirmed the Organization row in role reality |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026 Limerick"; the call was refused. It would have added a market calibration line for the €40,000 offer |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; the call was refused. It would have shown his professional background, to help frame the R7 conversation |

---

If useful, I can save all of this as a `tuesday-dossier.md` file to keep.

**What would sharpen this:**
- You confirming that marrowgatehousing.ie is the website you know them by, or allowing web search → RR1 clears.
- Allowing web search → a market pay check on €40,000, and Declan's professional background.
- Your answers below → R2, R10, R11 and R12 resolve, and the status likely moves to `go`.
- The contract → RR4 closes.

**Questions:**

G1: Was your hotel-group payroll run in Ireland, under Revenue's PAYE, PRSI and USC?

R10/R11: Do €40,000 and two office days a week in Limerick work for you?

R12: Do you have the right to work in Ireland without needing a work permit?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.