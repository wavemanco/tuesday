I'm reading the job-assessment playbook. Next I'll check Fernquay online and compare the salary with the market.
**Yes, it looks legitimate, and it's worth taking the call. Status: `go`.** Fernquay's own site and careers page match the posting, and the co-founder's public profile matches too. A co-founder messaging you on WhatsApp to arrange a video call is a normal step at a six-person company.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R5 · adjacent: R6 (Own the booking flow end to end as first designer)
- `important`: adjacent: R7 (Research calls with school owners)

R6: your checkout work carries over strongly, but you've never been the only designer anywhere. R7: your usability sessions carry over, but discovery interviews with business owners aren't shown yet.

**Opportunity ledger.** The employer checks out and the posting is live and consistent (RR1). The salary is in line with the market (RR2). Three things are still unknown and worth asking on the call: the equity terms (RR3), what design support you'd have as the only designer (RR4), and runway for a company funded by its customers (RR5).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** a salary floor of yours above €60,000; vague or unfavourable answers on RR3 or RR5; or a call that shows you'd have no one to get design feedback from and no say over the booking flow (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers. Its product is Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with Ronan | `[grounded]` posting |
| Working pattern | Hybrid: two days a week at the Galway office | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting and careers page |
| Scope read | A normal remit for a first design hire at a company this size. One core flow plus research is a focused scope, not several roles bundled into one | `[inferred]` from the posting's single named flow and a team of two engineers |
| Market calibration | Irish product designers with 3–5 years: median base €57,000, middle half €51,500–€62,000. The posted range sits inside that band. This is a market pattern, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520) |
| Unknowns | Equity terms; design feedback and decision rights as the only designer; customer count and runway | — |
| Contradictions | None. Posting, careers page and about page agree | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | high | none | You moved back to Galway last year | `[grounded]` your statement | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer. Stated in prose only; no CV seen | `[grounded]` your statement | CV would raise to high |
| R3 | Strong Figma | must_have | direct | medium | none | Daily Figma use, stated. Your case study would show it | `[grounded]` your statement | portfolio link |
| R4 | Has run their own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your statement | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your statement | none |
| R6 | Own the booking flow end to end, as first designer | must_have | adjacent | medium | transferability | Checkout redesign at a travel-booking company is booking-flow work. Limit: you've always had other designers around you for critique, design-system ownership and backup; here there would be none | `[inferred]` from your checkout work and the posting's "first designer" | see G1 |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Usability sessions carry over. Limit: these would be discovery interviews with business owners, not task testing with consumers | `[inferred]` from "usability sessions with customers" against "research calls with school owners" | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working as the only designer (R6, must_have) | transferability | Strong booking-flow work, always inside a design team | This is the role's central difference from your history; the founders are likely to test it | Owning checkout decisions without a design lead signing off; setting up research ops yourself; times you were the only designer in a squad or on a project | The checkout case study's decision log; examples where you made a call alone | `[inferred]` from the posting's "first designer"; `[generic]` that founders probe this |
| G2 | Discovery with business owners (R7, important) | transferability | Monthly usability sessions with consumers | Talking to school owners about their operations is part of the job | Interviews with hotel or tour operators, B2B partners or internal ops staff at the travel company | Interview guide, synthesis notes | `[inferred]` from the posting's "research calls with school owners" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established; posting live and consistent | positive_signal | — | "Open now: Product Designer, our first design hire" | The company exists as described and the role is current | `[grounded]` careers page, about page, Ronan Kehoe's LinkedIn profile | Who else would I meet before an offer? | noted |
| RR2 | Salary stated, and inside the market band | positive_signal | — | "€52,000–€60,000 plus equity" | Pay is transparent and market-normal | `[grounded]` posting; `[generic]` Tillerby band | Where in the range would you place someone with four years? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | It could be options or shares, with unknown vesting, cliff or strike price; that decides what it's worth | `[generic]` how startup equity varies | Is the equity options or shares, and what are the vesting schedule, cliff and strike price? | unresolved |
| RR4 | No design peer or manager | unknown | — | "You would be our first designer" | Design decisions may sit with the founders, and you'd have no one to critique your work | `[inferred]` from "first designer" and "work most closely with our co-founder" | Who has final say on the booking flow, and is there budget for outside design critique or a second hire later? | unresolved |
| RR5 | Customer-funded; scale and runway unknown | unknown | — | "funded by its customers" | No investors means no funding-round risk, but runway and growth decide job security and what the equity is worth | `[grounded]` about page; `[generic]` for the trade-off | Roughly how many schools use Kelproster, and how many months of runway do you have? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the call. Check that the emailed invite came from a fernquay.example address and that the meeting link opens a normal video service. Ronan's WhatsApp message is routine scheduling | The interview itself happens on video, not in the chat | `[grounded]` the WhatsApp message and the careers page's domain | pending your approval |
| P1 | Lead with the checkout redesign, framed as the "one messy real project": constraints, research, trade-offs. Ronan spent five years as a product lead at a Galway travel-software company, so booking-flow detail will land with him | They already said they loved the case study | `[grounded]` LinkedIn profile and the WhatsApp message | pending your approval |
| P2 | Say plainly that you've never been the only designer, and pair that with the decisions you made on your own (G1). Never present yourself as having been sole designer | Honest framing of R6 | `[inferred]` R6 row | pending your approval |
| Q1 | Ask the questions in RR3, RR4 and RR5 word for word on the call. If you'd like rehearsal first, mock-interview can prep you for a call with Ronan and Saoirse | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway" (About Fernquay, fernquay.example/about) and "Fernquay careers product designer"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved the organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3-5 years first design hire startup", which returned the "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Confirmed him as co-founder and CEO with a travel-software product background. Moved RR1 and P1 |

If you'd like, I can write all of this into a `tuesday-dossier.md` you can keep or reuse in later prep.

## Upgrade menu

- Your CV or portfolio link: R2–R5 can move to `high`.
- Answers to G1 and G2: R6 and R7 get stronger or are settled.
- Your salary floor and any other must-haves: the hard-gates line becomes a full check.
- A deeper research pass on Fernquay, covering customer and employee reports, leadership and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **G1:** On the checkout redesign, which design decisions did you make and defend yourself, without a design lead signing off?
2. **G2:** Have you ever interviewed business-side people, such as operators, partners or internal ops staff, rather than end customers?
3. Is there a salary floor or other must-have I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.