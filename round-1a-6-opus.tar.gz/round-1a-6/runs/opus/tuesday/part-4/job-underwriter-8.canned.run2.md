Now the step-1 references.
Checking whether Velloway Logistics can be found anywhere official, then I'll write up the assessment.
I couldn't confirm this employer exists. The posting and messages make the requests that job scams typically make, so I've written it up as a `no_go`.

# Job Underwriting — Remote Order Processing Coordinator, "Velloway Logistics" (posting as given)

## Decision snapshot

**No, don't go ahead. I can't find this firm anywhere, and these messages ask you to send your bank, PPS and passport details, pay €349 and lodge a €2,850 cheque (RR1, RR2, RR3). That makes this job very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay meets your €30,000-a-year floor)
- `must_have`: direct: R3 · adjacent: R2 (Strong attention to detail), R4 (Good written English)
- `important`: adjacent: R5 (Order processing) · unclear: R6 (A quiet place to work)

R2, R4: real bridges from your ticket work, with their limits named; R1: the "up to" rate leaves the floor unsettled.

**Opportunity ledger.** Your fit doesn't change the decision. RR1, RR2, RR3 and RR4 are confirmed severe requests made of you. RR5 and RR6 mean the sender can't be traced to an employer. RR7 leaves your pay floor unsettled.

- **Hard gates:** none failed; unconfirmed: R1 (Pay meets your €30,000-a-year floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to be different:** the messages would ask for no payment and no cheque deposit (RR2, RR3). Bank, PPS and ID details would come only after a written offer that names the role and its pay (RR1). There would be an interview you could place outside the chat (RR4). The employer would be verifiable through its own website (RR5, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Named as "Velloway Logistics"; no official site or careers page found | `[grounded]` posting header; `[grounded]` two searches returned no results |
| Mandate | "Remote Order Processing Coordinator": process orders, 15–30 hours a week, your own hours, from home | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission on every order you process"; no base or guaranteed hours stated | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, middle half €28,400–€34,100 (salaried only; commission-only work excluded). This is a market band, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |
| Pay against band | €26 × 30 h × 52 weeks is about €40,560, above the band's top. 15 h is about €20,280, below its bottom. Your floor needs about 22 hours a week at the full rate | `[inferred]` arithmetic on the posting's own figures |
| Unknowns | Base rate below "up to"; guaranteed hours; contract type; who the employer actually is | — |
| Contradictions | "Full training provided" beside a process with no call or video contact at all | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay meets your €30,000-a-year floor | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because "up to €26" plus commission at 15–30 hours ranges from about €20k to €40k, and nothing guarantees the top | `[grounded]` posting and your stated floor; `[inferred]` annual range by arithmetic | None for this posting (see RR7); use the floor on the other openings you look at |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day for 3 years points to accurate, high-volume handling. Limit: no stated accuracy or error-rate figure | `[grounded]` your background | An accuracy or QA score, if your team tracks one |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly Excel tracker. Stated, not yet shown | `[grounded]` your background | A sanitized screenshot of the tracker would raise it |
| R4 | Good written English | must_have | adjacent | medium | transferability | Ticket replies are usually written. Limit: your background doesn't say whether your channel was email, chat or phone | `[grounded]` your background; `[generic]` that ticket work is mostly written | Say which channels in future applications |
| R5 | Order processing (implied by the title) | important | adjacent | medium | transferability | Parcel-courier customer service sits next to order handling. Limit: you haven't said you processed orders yourself | `[inferred]` requirement from the job title; `[grounded]` your courier role | Name any order or claims processing you did |
| R6 | A quiet place to work | important | unclear | none | discovery | Not covered by anything you've shared | `[grounded]` posting; your background is silent | None needed for this decision |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written English, attention to detail (R4, R2) | transferability | High ticket volume, but no channel or accuracy measure stated | It makes your case stronger for other coordinator roles. It doesn't change this decision | Email and chat replies, macros or templates you wrote, QA scores, notes from training your two new starters | A QA scorecard, a sanitized reply template, the training notes | `[grounded]` your background; `[generic]` that coordinator roles screen on written accuracy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details asked before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Once sent, these can't be taken back, and together they can be used to open accounts or borrow in your name. This request is very likely a scam | `[generic]` employers set up payroll after a written offer, not before an interview | To the employer, through contact details on its own website: "Did you ask me for my IBAN, PPS number and passport before an interview?" | confirmed |
| RR2 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A bank transfer usually can't be recalled once it's sent. This request is very likely a scam | `[generic]` employers don't ask applicants to pay for their work kit | See RR1 (same route) | confirmed |
| RR3 | Cheque to lodge, with the balance passed on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show as available and still bounce days later, after your transfer has gone, leaving you owing the full amount. Don't lodge the cheque | `[generic]` known overpayment pattern | See RR1 (same route) | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." · "you passed the interview and the job is yours!" | Leaves open who you are actually dealing with. The sender's identity is unresolved | `[grounded]` posting and messages | See RR1 (same route) | confirmed |
| RR5 | Contact off the employer's own domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The address isn't on a domain shown to belong to the employer, so the messages may not come from who they name | `[grounded]` message; `[grounded]` no employer site found | See RR1 (same route) | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this one | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR7 | Pay stated only as a ceiling plus commission (see R1) | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process." | Below the top rate, or under about 22 hours a week, annual pay falls under your €30k floor | `[inferred]` arithmetic; `[generic]` band in role reality | "What is the guaranteed base rate, and how many hours are guaranteed each week?" | unresolved |

**Hold off on the €349 payment, the cheque deposit and sending your IBAN, PPS number or passport photo. Go no further in the chat until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from. Who sent them is not yet confirmed. Don't paste the IBAN you have ready. I haven't repeated it, and nothing in this assessment needs it.**

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send no money and no details, and stop replying in the chat | See RR1, RR2, RR3, RR4 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it. If you have already sent or lodged anything, call your bank straight away | Recalls and fraud flags work best early | `[generic]` how bank fraud handling usually works | pending your approval |
| A3 | Report the posting to the jobs site where you found it. You can also report the messages to An Garda Síochána | Helps stop the same requests reaching others | `[generic]` standard reporting routes | pending your approval |
| A4 | Put your effort into other openings: salaried customer-operations or order-processing coordinator roles whose stated pay clears €30k | Your Zendesk volume, Excel tracker and training of two starters map onto R2–R5 | `[grounded]` your background; `[generic]` band €28,400–€34,100 | pending your approval |
| E1 | Lead with your 60-tickets-a-day volume, the Excel tracker and training two new starters on applications for those roles (resume-tailor can do this against a specific posting) | See R2, R3, R4 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator". Both returned no results, so the employer is not established. This fed RR5, RR6 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This fed the market calibration, RR7 and A4 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a chat handle, so there was nothing to search |

I can produce a `tuesday-dossier.md` of this assessment if you'd like a copy to keep.

## Upgrade menu

- Contact details for the employer that you find independently, plus its answer → RR1–RR6 could be re-checked, though the payment and cheque requests (RR2, RR3) would stay red flags whatever it says.
- A real coordinator posting you're considering → a fresh assessment against your €30k floor.
- A QA scorecard or a sanitized screenshot of the tracker → R2 and R3 move up for future applications.
- A deeper research pass (company records, public candidate reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.