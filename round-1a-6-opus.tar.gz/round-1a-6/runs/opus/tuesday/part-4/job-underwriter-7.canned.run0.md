Reading the job-assessment playbook's decision and output rules before writing up the verdict on the Calderbrook role.
I've checked the employer and the role. Here's the assessment.

## Decision snapshot

**Yes, Aoife, it's worth applying for. Most of the advert matches what you already do, and the rest are gaps that can be filled. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R8 · adjacent: R11 (A small caseload of your own) · unclear: R4 (Clear, timely written records), R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R9 (Care planning)
- `important`: direct: R10
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R11: your home-visiting work is a credible bridge, and its limit is named below; R4, R5b, R6b, R7, R9: your CV doesn't mention these yet, and I haven't asked about them; R12: you'd need training, and it is only desirable.

**Opportunity ledger.** The role looks sound and clearly described. The pay sits in line with the market band, mileage and pool cars are provided (RR1), support is stated (RR2), and the team lead has spoken publicly about Doppler training for staff new to community work (RR6). Still open: whether the post is live (RR3), what "small caseload" and the support mean in practice (RR4), and the working pattern (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4, R5b, R7 are confirmed from your own experience before you write the supporting statement; (2) R11 is described honestly as home visiting, not as having held a caseload; (3) the post is confirmed open (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the employer's About page (search result) |
| Mandate | District nursing for housebound adults: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, all recorded on an EPR | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay and travel | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Band 5 community staff nurse in England: median basic pay £34,300, interquartile range £32,400–£36,600; 61% paid mileage, 24% given a pool or lease car. This advert's range brackets that band, and its car provision is better than most | `[generic]` Wardround 2026 UK Community Nursing Pay Guide; `[grounded]` advert for its own figures |
| Hiring contact | Rhiannon Mabbott, Community Nursing Team Lead. She leads the Halifax district nursing team, was a district nurse for eleven years, and spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` community nursing forum speaker page |
| Unknowns | Caseload size and how long you'd be supported; hours, weekends and late shifts; contract type; whether the post is still live | — |
| Contradictions | None found | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Registration is stated as active, with revalidation due March 2028. You stated it and I haven't checked it | `[grounded]` CV | Check your own entry on the NMC register is current |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full licence, category B, stated, not checked | `[grounded]` CV | Check your driving record is clean and current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | The CV doesn't mention documentation or which record systems you've used | `[grounded]` CV silence | G1 |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | unclear | low | discovery | The CV names pressure ulcers and surgical wounds, but not leg ulcers or compression. `[generic]` Leg ulcers are a core part of district nursing wound work | `[grounded]` CV; `[generic]` the clause marked | G2 |
| R6a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | The CV says catheter care, but not continence assessment or management | `[grounded]` CV silence | G4 |
| R7 | End-of-life visits | must_have | unclear | low | discovery | The CV doesn't mention end-of-life care | `[grounded]` CV silence | G3 |
| R8 | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R9 | Care planning | must_have | unclear | low | discovery | The CV doesn't mention writing or owning care plans | `[grounded]` CV silence | G5 |
| R10 | Caring for adults in their own homes | important | direct | medium | none | 18 months on the discharge-to-assess team visiting patients at home | `[grounded]` CV | none |
| R11 | A small caseload of your own, supported | must_have | adjacent | medium | transferability | Bridge: independent home visits. Limit: you state you've never held a caseload, and the visits covered only the first week after discharge, not ongoing care | `[grounded]` CV and your own statement | G6 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You state you've never done one. Only desirable. Closure path: training; the team lead has spoken on Doppler training for staff new to community work | `[grounded]` your statement; `[grounded]` forum speaker page | Ask about training in the informal chat (RR6) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clear, timely written records (R4, must_have) | discovery | No mention of documentation or record systems | It's an essential criterion, so the shortlisting will look for it | Ward or discharge-to-assess notes on an electronic record; assessment forms done during home visits; handover and referral documentation; any audit of your notes | Name of the system; an audit result or a good comment from a supervision note | `[grounded]` CV silence |
| G2 | Leg-ulcer care (R5b, must_have) | discovery | Pressure ulcers and surgical wounds only | It's the first clinical area the advert lists, and the team lead's own specialty | Dressing leg ulcers on the ward; applying or checking compression bandages; ulcers you saw on discharge-to-assess visits; a tissue viability study day | A training certificate; a tissue viability competency sign-off | `[grounded]` CV and advert; `[grounded]` speaker page for the team lead's specialty |
| G3 | End-of-life visits (R7, must_have) | discovery | Not mentioned | It's a named part of the visiting work | Caring for dying patients on the medical ward; syringe drivers; anticipatory medicines; supporting families; fast-track discharges home to die | End-of-life or syringe driver training records | `[grounded]` CV silence |
| G4 | Continence care (R6b, must_have) | discovery | Catheter care only | It's named alongside catheter care | Continence assessments; choosing pads or products; bowel care; trial without catheter | A competency record | `[grounded]` CV silence |
| G5 | Care planning (R9, must_have) | discovery | Not mentioned | You'd own care plans for your caseload | Writing or updating care plans on the ward; setting goals on discharge-to-assess visits | An example with the details removed | `[grounded]` CV silence |
| G6 | Own caseload (R11, must_have) | transferability | Home visits in the first week after discharge; no caseload held | It's the biggest step up in the role | Planning your own visit list for the day; deciding when to discharge or refer on; following one patient across several visits | A description of a typical discharge-to-assess day | `[grounded]` CV and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay, mileage and car stated openly | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | The pay is transparent and in line with the Band 5 community band | `[grounded]` advert; `[generic]` Wardround band | Where on the range would I start with five years' experience? | noted |
| RR2 | Support stated for the caseload | positive_signal | — | "a small caseload of your own, supported by a senior community nurse" | There is a clear support structure for someone growing into a caseload | `[grounded]` advert | How many patients is a "small" caseload, and how long does the supported period last? | noted |
| RR3 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer is established, but its careers page couldn't be opened, so I can't confirm the post is still open | `[grounded]` About page found; careers page fetch returned no page | Is the Community Staff Nurse post in Halifax still open, and what's the closing date? | unresolved |
| RR4 | Caseload size and support period unstated | unknown | — | "a small caseload of your own" | "Small" and "supported" may mean different things in different teams | `[generic]` | What does a typical day look like, how many visits, and who do I call when I'm unsure? | unresolved |
| RR5 | Working pattern and contract unstated | unknown | — | (the advert is silent) | It may include weekends or late shifts, and it may be fixed-term | `[generic]` | What hours and rota does the team work, including weekends, and is the post permanent? | unresolved |
| RR6 | Doppler training likely available | positive_signal | — | "Desirable: Doppler assessment" | The team lead has spoken on Doppler training for staff new to community work, so training is likely offered | `[inferred]` from the forum speaker page against the advert's "desirable" | Is Doppler training offered to new starters, and how soon? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Book the informal chat with Rhiannon Mabbott before you apply, and ask the RR3, RR4, RR5 and RR6 questions | The advert invites it, and those questions close most of the unknowns | `[grounded]` advert, register | pending your approval |
| A2 | Lead the supporting statement with your discharge-to-assess work, in your own words: "18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge" | see R10, R11 | `[grounded]` CV | pending your approval |
| A3 | Name the caseload gap plainly: "I haven't yet held my own caseload; for the last 18 months I've visited patients at home in their first week after discharge" | see R11; it's honest and points to the advert's stated support | `[grounded]` CV and your statement | pending your approval |
| A4 | On Doppler, say you haven't done it yet and would welcome the training | see R12, RR6 | `[grounded]` your statement | pending your approval |
| A5 | Add leg ulcers, end-of-life care, continence, care planning and records to the statement only once you've confirmed them from your own experience | see R4, R5b, R6b, R7, R9 | `[grounded]` gap queue | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this and I haven't used it. I've left out your NMC PIN as well.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about) and established the employer. Fetched calderbrookhealth.example/careers, which returned no page, so the posting isn't confirmed live (RR3) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing caseload responsibilities salary 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Gave the market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Gave the hiring contact row, G2's weight and RR6 |

I can save this as a `tuesday-dossier.md` file so other job-search tools can pick it up later, if you'd like.

**Upgrade menu**
- Answers to G1–G3 → R4, R5b and R7 move off `unclear`, and the conditions for go shrink.
- Training records or competency sign-offs (tissue viability, syringe driver, continence) → the rows they back go from `low` to `medium`, and with the document, `high`.
- What you learn in the informal chat → RR3, RR4 and RR5 close.
- Your own constraints (hours, weekends, part-time, permanent only) → hard-gate checks against them, which currently can't be run.
- A deeper research pass on Calderbrook (inspection reports, staff reviews, recent news; up to 5 more searches and 2 more fetches) → fills out the risk register. Say the word and it runs.

If it's useful, the mock-interview module can prep you for the chat or the interview.

**Questions**

G2: Have you cared for leg ulcers, on the ward or on discharge-to-assess visits? That could be dressings, applying or checking compression, or any tissue viability training.

G3: Have you cared for patients at the end of life? That could be syringe drivers, anticipatory medicines, supporting families, or fast-track discharges home.

G1: Which electronic record systems have you documented on, and has your record-keeping ever been audited or commented on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.