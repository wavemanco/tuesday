Checking the employer's public footprint and the salary band for this kind of role, then I'll give you the full read.
**Yes, this is normal. You're past the stage where that warning applies.** The "never hand those over" advice is about requests made *before* an offer, or by someone you can't place. You have a written offer that names the role, the pay (€40,000) and your manager. It came from the employer's own domain after two interviews at their office. Asking for bank details, your PPS number and a passport scan at that point is routine onboarding. One check is worth doing, and it's in the plan below (A1). My overall read on the offer: **`conditional_go`**.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R4 · unclear: R9 (two days a week in the Limerick office)
- `must_have`: direct: R1, R3, R5, R6 · adjacent: R7 (process pension changes) · unclear: R2 (working knowledge of Irish PAYE, PRSI and USC)
- `important`: unclear: R8 (answer staff payroll queries)

R7: a real gap, because your manager did this work, so you need a handover plan; R2: likely met but not stated; R9: only you know whether the commute works.

**Opportunity ledger.** The offer matches the advertised terms (RR1). I couldn't confirm the employer from here because my searches were refused (RR2). The onboarding request itself is routine and isn't in the register.

- **Hard gates:** none failed (R4 `direct`); unconfirmed: R9 (two days a week in the Limerick office); you didn't give your constraints, so I couldn't check the offer against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) two days a week in Limerick works for you (R9); (2) you agree how you'll learn pension changes (R7, G1, A2); (3) the employer checks out on its own website (RR2). Your in-person interviews at their office already go a long way on this.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff queries | `[grounded]` job ad |
| Offer terms | Permanent, €40,000, reporting to the Finance Manager, hybrid with two days in Limerick, start date agreed after your notice period | `[grounded]` offer email |
| Pay against the advert | €40,000 is inside the advertised €38,000–€42,000 | `[grounded]` ad and offer |
| Scale step | 240 staff paid monthly, against your 90 paid fortnightly | `[grounded]` ad and your background |
| Unknowns | Which pension scheme(s) payroll handles; what handover or training comes with the role | — |
| Contradictions | None between the ad and the offer | `[grounded]` ad and offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years at a hotel group. The scale is smaller and the cycle different (90 fortnightly against 240 monthly), but it's the same job | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say whether the hotel payroll was Irish. If it was, this is met | `[inferred]` from the PPS and Revenue context, not stated | G2 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your background | none |
| R4 | Payroll qualification or working towards one | hard_gate | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R5 | Process starters and leavers | must_have | direct | medium | none | You've done this yourself | `[grounded]` your background | none |
| R6 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Same task, same monthly frequency | `[grounded]` your background | none |
| R7 | Process pension changes | must_have | adjacent | low | transferability | You say you've never done this yourself; your manager did. The overlap is only inferred: payroll you ran would have taken pension deductions | `[grounded]` your own statement; `[inferred]` the deduction overlap | G1 |
| R8 | Answer staff payroll queries | important | unclear | low | discovery | You didn't mention it, though it's a common part of running payroll | `[generic]` role-family pattern | G3 |
| R9 | Two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The offer states it. Whether it works for you hasn't been stated | `[grounded]` offer email | Question on R9 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R7, must_have) | transferability | You haven't processed pension changes yourself | It's a named duty, and there's no stated handover for it | Seeing contribution-rate changes, new joiners or AVCs flow through payroll you ran; checking pension deductions during your reconciliation | Any notes or checklists from your current role | `[grounded]` your own statement |
| G2 | Irish PAYE, PRSI and USC (R2, must_have) | discovery | Where the hotel group's payroll ran isn't stated | It's a must-have, and probably already met | Irish payroll run on Revenue's PAYE system | None needed beyond your answer | `[inferred]` from context |
| G3 | Staff payroll queries (R8, important) | discovery | Not mentioned | Day-to-day part of the role | Handling payslip, tax-credit or overtime queries from staff | None needed | `[generic]` role-family pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer terms match the advert | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year" | The role is what was advertised, at pay inside the stated range | `[grounded]` ad and offer | Is there a probation period, and what does the first month look like? | noted |
| RR2 | Employer not established from attributable sources (my searches were refused) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this employer | Can you confirm the onboarding portal's address, as listed on your own website? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the onboarding portal only if its address matches the employer's own website. You can confirm it by phoning the office number shown on that site. Never enter your details through a link that points somewhere else | This is the one check on onboarding that matters | `[generic]` standard onboarding practice | pending your approval |
| A2 | Before or when you accept, ask Declan Garvagh how pension changes are handled and what handover you'll get | Closes R7 | `[grounded]` R7 | pending your approval |
| A3 | Bring the original passport on day one, as the offer asks | Employers check right to work against the original document | `[generic]` standard practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused. It would have confirmed the employer and its site address (RR2, A1) |
| 2. Role-family sweep | unavailable | Search refused. It would have added a market salary band for this role |
| 3. Hiring manager's public footprint | skipped | You already have the offer, so the positioning this target feeds doesn't apply |

If you'd like, I can save all of this as a dossier file to reuse later.

**Upgrade menu**
- Allow web search: I can confirm the employer and its website address (RR2), and set €40,000 against the market band.
- A deeper research pass (up to 5 more searches and 2 more fetches): employer background and recent news.
- Your answers below: these would settle R2, R7 and R9, and could move the decision to `go`.

**Questions**

G1: When your manager handled pension changes, how much did you see of joiners, rate changes or AVCs as they came through payroll you ran?

G2: Was the hotel group's payroll run in Ireland, through Revenue's PAYE system?

R9: Does two days a week in the Limerick office work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.