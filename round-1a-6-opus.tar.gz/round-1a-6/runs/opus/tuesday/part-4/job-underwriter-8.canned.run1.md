Checking whether Velloway Logistics can be found online, then I'll give you the full assessment.
# Should you go ahead with the Velloway Logistics "Remote Order Processing Coordinator" job?

## Decision snapshot

**No, Ciara, don't go ahead, and don't send anything. Four requests (RR1, RR2, RR3, RR4) are confirmed severe red flags. Status: `no_go`.**

I can't establish the firm from here. The requests in these messages are very likely a scam:
- pay €349 for equipment
- lodge a €2,850 cheque and transfer most of it on
- send your IBAN, PPS number and passport photo before any offer

So pay nothing, lodge nothing and send nothing.

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year minimum)
- `must_have`: direct: R2, R3 · adjacent: R4 (Good written English) · unclear: R5 (A quiet place to work)
- `important`: adjacent: R6 (Processing orders)

R1: not settled by an "up to" hourly rate and 15–30 hours a week. R6: your courier customer-service work is a credible bridge, and its limit is named below.

**Opportunity ledger.** The messages ask for four things that are confirmed severe red flags: paying for equipment (RR1), lodging a cheque and forwarding money (RR2), your bank, tax and ID details before an offer (RR3), and a hiring process run entirely in chat (RR4). I couldn't find the employer in any source I could attribute to it (RR5). Contact moves to an email address that isn't on a company domain (RR6). The pay may not reach your minimum (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to be different:** no payment and no cheque asked of you at any stage. Bank, PPS and ID details asked only after a written offer that names the role and its pay, and entered only on the employer's own portal. Interviews held by phone or video with people at the employer. And an employer you can find on its own website, with this role listed there.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", as named in the posting and by the sender | `[grounded]` posting and messages |
| Mandate | "Remote Order Processing Coordinator": processing orders from home | `[grounded]` posting |
| Hours and pay | "15–30 a week", "up to €26 an hour plus commission on every order you process" | `[grounded]` posting |
| Annual equivalent | €20,280 at 15 hours to €40,560 at 30 hours, if the full €26 is paid for 52 weeks. "Up to" means the actual rate could be lower | `[inferred]` arithmetic on the posting's own figures |
| Market calibration | Order-processing and customer-operations coordinators in Ireland earn a median base of €31,200 a year (middle half: €28,400–€34,100). This counts salaried roles only, and it is not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (search result) |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Unknowns | Employment type (employee or contractor), the guaranteed hourly rate, how commission works, who you would report to | — |
| Contradictions | Says "full training provided" but also asks you to buy your own kit through an "equipment partner" | `[grounded]` posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year minimum (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated minimum. Fit is `unclear` because the posting gives only an "up to" rate across 15–30 hours, with unspecified commission | `[grounded]` your message and the posting; `[inferred]` annual range from its figures | Not worth pursuing given RR1–RR4 |
| R2 | "Strong attention to detail" | must_have | direct | medium | none | About 60 tickets a day for 3 years, and you keep your team's weekly tracker. Self-reported and not yet probed | `[grounded]` your background | none |
| R3 | "Confident with spreadsheets" | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported | `[grounded]` your background | none |
| R4 | "Good written English" | must_have | adjacent | medium | discovery | Zendesk ticket handling points to written customer replies, but you didn't say how much of it was written | `[grounded]` your background; `[inferred]` that the tickets involved written replies | See G1 |
| R5 | "A quiet place to work" | must_have | unclear | low | discovery | Not mentioned in what you shared | `[grounded]` you didn't mention it | See G2 |
| R6 | Processing orders (implied by the title) | important | adjacent | medium | transferability | Courier customer service is close to order handling. Its limit: you didn't describe entering or processing orders yourself | `[inferred]` requirement from the title; `[grounded]` your background | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written English (R4, must_have) | discovery | Zendesk tickets, but the share of written replies isn't stated | Matters for real remote ops roles, not this one | Email or chat replies to customers, templates or macros you wrote, the training notes you gave the two new starters | A sanitized reply template or a training doc | `[grounded]` your background; `[generic]` that remote ops roles weigh written replies |
| G2 | Quiet workspace (R5, must_have) | discovery | Not mentioned | Easy to confirm for any home-working role | A home office or a dedicated room | None needed | `[grounded]` you didn't mention it |
| G3 | Processing orders (R6, important) | transferability | Courier customer service; order entry not described | It's the core task in order-processing titles | Fixing address or delivery errors, rebooking parcels, logging claims | A sanitized tracker screenshot | `[inferred]` bridge from your courier work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Money sent by bank transfer is hard to get back, and employers don't ask applicants to pay for their own work kit. This request is very likely a scam. Who sent it is not established | `[generic]` how requests like this work | Ask the employer, using contact details found on its own website (not the chat or that email): "Did your company ask me to pay €349 for equipment?" | confirmed |
| RR2 | Asked to lodge a cheque and forward most of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show as available and still bounce days later, leaving you owing the money you sent on. This request is very likely a scam. Don't lodge the cheque | `[generic]` how cheque-forwarding requests work | See RR1 for how to check: "Did you send me a cheque?" | confirmed |
| RR3 | Bank, tax and ID details asked before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | These details together can be used to open accounts or commit fraud in your name, and this was asked before any interview or offer | `[generic]` what these details allow | See RR1: "Do you collect payroll details before the interview?" | confirmed |
| RR4 | Hiring run entirely in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews", then "you passed the interview and the job is yours!" | You haven't spoken to or seen anyone, so you can't tell who you're dealing with | `[grounded]` posting and messages | See RR1: "Who would I interview with, and how?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to show up online, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this firm | "Can you point me to this role on your own careers site?" | unresolved |
| RR6 | Contact moves to an address off any company domain | risk_signal | medium | "email velloway.hr@postmail.example" | These messages may not come from who they name | `[generic]` pattern | See RR1: "Is this an address your HR team uses?" | unresolved |
| RR7 | Pay is "up to" a rate, against your €30,000 minimum (see R1) | risk_signal | medium | "Earn up to €26 an hour plus commission" | At 15 hours, or below the top rate, it falls under your minimum | `[inferred]` from the posting's figures against your minimum | "What is the guaranteed hourly rate and the minimum weekly hours?" | unresolved |

Hold off on the payment, lodging the cheque and sending your details, and go no further in the chat, until you have checked each request with the employer. Use contact details from the employer's own website, not the chat or the address these messages came from. Who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your IBAN, PPS number and passport aren't needed for any of this. Don't paste them into the chat, and I haven't used the IBAN you shared here.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing more on Telegram or to that email address: no IBAN, PPS number, passport photo or money | See RR1, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it. Ask your bank about it, and tell them if any details or money have already been sent | See RR2 | `[generic]` banks handle cheque and transfer fraud | pending your approval |
| A3 | Report the listing to the jobs site where you found it | See RR4, RR5 | `[generic]` jobs sites take reports on listings | pending your approval |
| A4 | Put your effort into other openings. Your tracker work and ticket volume match the stated requirements (see R2, R3), and the market median of €31,200 (see role reality) is close to your minimum | See R2, R3, R1 | `[grounded]` map rows; `[generic]` pay guide | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator". Both returned nothing, so the employer is not established (RR5) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This gives the market calibration and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

If you'd like, I can save this as a `tuesday-dossier.md` file to keep with your job search.

**Upgrade menu**
- The jobs-site listing's link: shows whether it's still live and what company details it gives (RR5).
- Velloway's own website or company registration number, if you find one: lets me check it independently, which may reduce RR5 and gives you a safe way to contact the employer for RR1–RR4.
- A deeper research pass (up to 5 more searches and 2 more fetches): only worth running if a real company turns up.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.