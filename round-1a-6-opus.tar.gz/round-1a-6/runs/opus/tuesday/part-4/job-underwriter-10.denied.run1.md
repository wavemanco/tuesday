Quick update: I've read the assessment playbook. Next I'm running a few targeted searches on Fernquay, its co-founder, and typical product designer pay in Ireland.
**Is it worth applying for, and is it legit?** It's worth it: your background covers every stated requirement. I couldn't confirm Fernquay exists, because my web searches were blocked in this session. Nothing in the posting or the WhatsApp message asks you for money, bank or ID details. Arranging a video call over WhatsApp, with the invite sent by email, is a routine way to schedule an interview. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R5 · adjacent: R6 (Own the booking flow end to end)
- `important`: unclear: R7 (Working as the first designer), R8 (Research calls with school owners)

The gaps: R6 is a checkout redesign, which is one part of a booking flow; R7 is not yet clear on whether you were your squad's only designer; R8 needs research with business owners rather than customers.

**Opportunity ledger.** The posting is unusually open: the pay is stated (RR2), and the resources and who you'd report to are named (RR3). What's missing is any check that the company exists (RR1), the equity terms (RR4), what success looks like (RR5) and the runway (RR6).

- **Hard gates:** none failed (R1 `direct`); you haven't given me your constraints, so I couldn't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay checks out (RR1); (2) €52–60k and two days a week in the Galway office fit your own floor and commute (closing question 1); (3) you present R7 honestly as new territory, not as experience you already have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway making booking software for sea-kayak and surf schools | `[grounded]` posting; not checked, searches blocked (RR1) |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Reporting line | Works most closely with co-founder Ronan Kehoe | `[grounded]` posting; his WhatsApp message matches |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` posting |
| Process so far | Ronan says he emailed a calendar invite for a 45-minute video call with him and Saoirse, the CTO | `[grounded]` WhatsApp message |
| Scope read | A normal scope for a first design hire at a startup this size: one flow, research, and close work with engineers | `[inferred]` from the posting's team size and mandate |
| Market calibration | Not established, because the salary search was blocked. The posting's own figure is the only number here | `[grounded]` posting, for the figure |
| Unknowns | Equity terms; runway and funding; how success is measured; whether school owners are already lined up for research | — |
| Contradictions | None. The message says "we loved the checkout case study", which fits the posting's "one messy real project" | `[grounded]` posting and message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. Your commute and any limits aren't stated | `[grounded]` your message | closing question 1 |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, from your own account | `[grounded]` your message | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily." Self-reported, with nothing inspected yet | `[grounded]` your message | none |
| R4 | Has run their own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your message | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | It carries over: you redesigned checkout at a travel-booking company, which is the same domain and part of the same flow. The limit: it isn't established that you owned the whole flow (search, availability, booking, confirmation) or saw it shipped | `[grounded]` your message; `[inferred]` that checkout is one part of a booking flow | G1, closing question 2 |
| R7 | Working as the first and only designer, with no design peers | important | unclear | medium | discovery | You've "never been the only designer anywhere". Whether you were the only designer in your squad isn't clear | `[grounded]` your message; requirement `[inferred]` from "You would be our first designer" | G2, closing question 3 |
| R8 | Research calls with school owners (business customers) | important | unclear | low | discovery | Your sessions were with customers. Whether you've done research with business owners or suppliers isn't stated | `[grounded]` posting and your message | G3; raise it on the call |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R6, must_have) | transferability | A checkout redesign. It isn't clear which steps around checkout were yours | It's the core of the role, and the CTO's likeliest probe | Payment or booking-confirmation steps; availability or date pickers; email confirmations; tracking checkout metrics after launch | The checkout case study they've already seen, with your part marked | `[grounded]` your message; `[generic]` that first-designer interviews probe ownership |
| G2 | First designer (R7, important) | discovery | Never the only designer anywhere; your squad's design makeup isn't stated | This is the real stretch in the role. An honest answer here helps you | Being the squad's sole designer day to day; setting up your own critique; making design calls without a lead | A short note on how you got feedback on your work | `[grounded]` your message |
| G3 | Research with school owners (R8, important) | discovery | Customer usability sessions only | Fernquay's users are business owners | Interviews with hotel or tour-operator partners; supplier-side tooling | Research notes or a session plan | `[grounded]` posting and your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. You found little yourself, and my searches were blocked | `[generic]` a pattern for companies this size, not a claim about this one | What's Fernquay's registered company name, and is this role on your own website? | unresolved |
| RR2 | Pay range stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The terms are open from the start | `[grounded]` posting | Where in the range would this role sit for someone with four years' experience? | noted |
| RR3 | Resources and reporting line named | positive_signal | — | "ship alongside our two engineers… work most closely with our co-founder" | You'd have the engineers you need and a clear decision-maker | `[grounded]` posting | Who makes the final call on design decisions? | noted |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | Options or shares, the vesting schedule and the strike price decide what the equity is worth | `[generic]` startup equity pattern | Is it options or shares, on what vesting schedule, and of which share base? | unresolved |
| RR5 | No success measures for the mandate | unknown | — | "own the booking flow end to end" | Accountability with no stated outcomes | `[inferred]` from the posting's silence on outcomes | What would a great first six months look like? | unresolved |
| RR6 | Runway and funding unknown | unknown | — | "We are six people" | At a six-person company, the job's security depends on its runway | `[generic]` early-stage pattern | Are you funded or running on revenue, and how many months of runway do you have? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite comes from an email address on Fernquay's own domain and opens a standard video link. Look the company up on the Companies Registration Office (CRO) | RR1. These are ordinary checks; the WhatsApp scheduling itself is routine | `[generic]` | pending your approval |
| A2 | Lead with the checkout case study, and say exactly which steps were yours | They already said they liked it; see R6 | `[grounded]` WhatsApp message | pending your approval |
| A3 | Frame R7 honestly, for example: "I've always had design peers. Here's how I'd get critique and keep standards up as your first designer." Never imply you've been a solo designer | R7 | `[grounded]` your own words | pending your approval |
| A4 | Ask the questions from RR4, RR5 and RR6 word for word on the call | The risk register doubles as call prep | `[grounded]` register | pending your approval |

If you'd like to rehearse the call with Ronan and Saoirse, the mock-interview module can do that.

## Evidence status

Verified: none yet.

Research tier: L1, searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Fernquay booking software Galway" was refused. It would have settled RR1 |
| 2. Role-family sweep | unavailable | The search "product designer salary Ireland 2026 mid-level" was refused. It would have set the market calibration and checked RR2's range |
| 3. Hiring manager's public footprint | unavailable | The search "Ronan Kehoe Fernquay co-founder" was refused. It would have shaped A2 for him as the reader |

## Next steps

I can save this as a `tuesday-dossier.md` if you'd like to keep or reuse it.

**What would strengthen this assessment:**
- Fernquay's website link, or the email address the invite came from: this tests RR1.
- Your pay floor and commute limits: these check the role against your constraints.
- A link to your checkout case study: this would raise R3 and R6 to `high`.
- Allowing web search: this would run targets 1–3.
- A deeper research pass on Fernquay (funding, team history, news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions:**

1. What's your salary floor, and is there anything about two days a week in the Galway office that doesn't work for you?
2. G1: In the checkout redesign, which steps did you own, did you see them through to launch, and what changed afterwards?
3. G2: In your squad, were you the only designer day to day? Who reviewed your work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.