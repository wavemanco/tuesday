Quick update: I've read the prep playbook and I'm now running a few targeted web searches on Quillmoor Diagnostics. Once those are back I'll build your prep pack.
I've built your prep pack for Thursday's call with Hannah. I tried to look up Quillmoor Diagnostics and Hannah online, but those searches weren't permitted. So the pack comes only from the advert, her message and what you told me, and the company-knowledge question uses only the advert's facts.

**What matters most for the call:**

- **Her four topics: give your own words, then stop.**
  - Pay: "I'm hoping for £42,000." That's inside the £38,000–£44,000 band. If she asks what you earn now: "I'd rather focus on the range for this role."
  - Hybrid: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."
  - Reason for moving: the office closing and the Reading relocation, in the words you gave me. If she follows up, say the same thing again and add nothing.
  - Notice period: you didn't tell me yours, so check it before Thursday and give the actual figure.
- **The question most likely to test you:** "Your background is wholesale logistics, and this role coordinates production schedules between planning, the warehouse and QA. How would that translate?" This is the gap between your experience and the advert's first duty. Answer with what you actually do (scheduling deliveries for three depots, chasing suppliers when orders slip) and don't claim production or QA scheduling. If your depot scheduling meant agreeing plans with other teams, say who and how. If it didn't, say so and explain how you'd learn the production side.
- **SAP:** say "I haven't used SAP. We run our own in-house stock system." The advert lists it as a plus, so a plain answer costs little.
- **Your stock-count result:** keep "about a third" and "over a year" exactly as you said them. If she asks how it was counted and you don't know, saying so is a fine answer.
- **Excel:** the advert asks for it, and you've said "spreadsheet" but not which program. Know which one it is before the call.

The pack also has 21 practice questions with guidance, six questions to ask Hannah, and a list of claims to avoid making.

If you want to practise, I can play a skeptical recruiter and put the production-scheduling question to you, with follow-ups.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, so you can use it in later sessions.
If you'd like the pack as a Word document, I can convert it.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-5/rooms/case-13-denied-717be435:
- quillmoor-diagnostics_operations-coordinator_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, a 30-minute phone call
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps"

## How to use this pack

- **Personas** are *how* a question gets asked: who is asking and in what tone. **Types** are *what* gets scored.
- Type key:
  - **VAL**: behaviour against the company's published values
  - **EXP**: whether what you've said about your work holds up, and what was actually yours
  - **JD**: the advert's listed duties and requirements, gaps included
  - **CO**: what you know about the company
  - **CASE**: a live problem from the role, worked out loud
- **Answer slot**: where the pack can't know the answer, it tells you what is likely to be asked and gives you two honest ways to answer. Both are fine answers.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

The advert's requirements set against your own words. Everything later in the pack about your past comes from the quotes in this table.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material describes delivery scheduling for three depots. It doesn't describe production scheduling between planning, the warehouse and QA, so your words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a question about working across teams likely. If your scheduling involved agreeing plans with other teams or people, say which ones and how, in your own words. If it didn't, say so plainly and stay with the depot scheduling |
| F2 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap. It is a line from your message with nothing behind it to check yet, so expect a follow-up. Use the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "chase suppliers when orders slip" — your message | low | [inferred] | discovery | Your material shows that you chase late orders. It doesn't show how you keep track of deliveries. Answer slot: if you track supplier deliveries in some way, say how, in your own words. If there is no tracking step, say so plainly and describe how you chase |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | Lead with the whole quote, keeping "about a third" and "over a year". A figure invites four follow-ups, and each is answered in your own words: how it was counted, what could have moved it, the assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material doesn't mention reporting. Answer slot: if you've produced regular reports on deliveries or dispatch, say what they covered, how often and who read them, in your own words. If you haven't, say so plainly and say how you would set up a weekly on-time dispatch report |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | Four years against a two-year ask. Say it in the quote's own terms |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | medium | [grounded] | discovery | Your material says "spreadsheet" but not which program. Answer slot: if the spreadsheet is in Excel, say so and name the parts of Excel you actually used to build it, in your own words. If it's in another program, name that program plainly and stay with the rebuild |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP" — your message | none | [grounded] | capability | You've said this yourself, so the words are yours: "I haven't used SAP." Then say how you would learn it, as a plan and never as something you've done. This is listed as a plus, not a requirement, and nothing should be added to make the gap sound smaller |
| F9 | "ERP experience (SAP or similar) a plus" — advert | "we run our own in-house stock system" — your message | medium | [grounded] | transferability | Words: "We run our own in-house stock system." Answer slot: if asked what you do in it, describe what you actually use it for, in your own words, and let Hannah judge whether that counts as "similar". Don't call it an ERP unless it is one |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is inside the advertised band. Your words are the whole answer: "I'm hoping for £42,000." |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Met as advertised. Your words are the whole answer, said as you said them |

## Persona table

Hannah's own message sets out who runs this call and what it covers, so the weights below follow her agenda plus the usual pattern for a recruiter screen. They don't come from a guessed company process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly, chatty and quick-moving, with logistics asked as asides | High. Recruiter screens lean this way, and four of the five topics she names are logistics | Treat every casual question as scored. Have a 90-second account of your current role ready. Give each logistics answer in your own words, then stop |
| B. Skeptic (light) | "How would that translate?" and quiet checks on the gaps | Medium. Recruiter screens include a few knockout checks, and F1 and F8 are where the advert presses on your material | Rehearse B1 until it's boring. Build bridges only from what you've said, and state the limit plainly |
| C. Data-Driven Prober | Picks up the one number you give and asks how it was counted | Low. Your stock-count figure (F4) is the only number in your material, and a recruiter may ask about it in passing | Know what you can and can't say about how the figure was counted, and say plainly when you don't know |
| D. Case / Strategist | "What would you do if…" about a late delivery or a dispatch dip | Low. It isn't on her agenda, but a short scenario is a common way to check an operations candidate | Clarify first, then work through it out loud: who is affected, what the options are, what you'd record |
| E. Values / Behavioural | "Tell me about a time…" | Low. Nothing points to a values-style round, and the company's values couldn't be researched | Pick specific occasions from your own work. Where none comes to mind, say so |

Pressure and Peer personas are left out. Her message describes a friendly 30-minute call with her alone, so there is neither a stress format nor a peer in the room.

## Question banks

### A. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your current role." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second account built from these three sentences only. First, four years as a logistics coordinator at a building-supplies wholesaler. Then, you schedule deliveries for three depots and chase suppliers when orders slip. Then, you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Stop there and let her pick what to ask about | This is nearly always the opener, and F6, F2 and F4 all sit inside it. JD because she will score it against the advert's experience line |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Your own words: "I'm hoping for £42,000." Give them, then stop. If she asks what you earn now: "I'd rather focus on the range for this role." | First on her agenda. JD because it is the advertised term (F10) |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, and nothing else. The question needs no claim about your past, so the guidance makes none | On her agenda. Your message didn't give it, so check it before Thursday |
| A4 | "How would the hybrid pattern work for you, two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the commute or on more days, give the same words again and add nothing | On her agenda, and it is the advert's stated term (F11) |
| A5 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words, whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Any follow-up on this gets the same words again, with nothing added | On her agenda. EXP because she will check it against the story you've told about your current job |
| A6 | "What drew you to this role?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Name the advert lines that match what you already do, using your own sentences: chasing suppliers when orders slip (the advert says "chase late orders"), and the stock-count spreadsheet rebuild (the advert says "keep stock records accurate"). Then say what interests you about the role, in your own words, because the pack can't supply your reasons. Keep this answer separate from A5 | A standard check that your motivation hangs together, asked in a friendly tone. It draws on F2 and F4 |
| A7 | "What systems do you use day to day?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "We run our own in-house stock system." If SAP comes up: "I haven't used SAP." Answer slot: if she asks what you do in the system, describe what you actually use it for, in your own words. Name other systems only if you've used them | A casual way to ask about the advert's ERP plus (F8, F9). Questions that sound casual are still scored |
| A8 | "How are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Start from the quote: you rebuilt the stock-count spreadsheet. Answer slot: the advert asks for "confident with Excel", so expect a follow-up on which program and what you use in it. If the spreadsheet is in Excel, say so and name the parts of Excel you actually used, in your own words. If it's another program, name it plainly and stay with the rebuild | The Excel line in the advert (F7). Your material doesn't name the program, so rehearse this before the call |
| A9 | "What do you know about Quillmoor?" | CO | [grounded] | Stay with what the advert says: a diagnostic-test manufacturer, about 400 staff, a site at Avonmouth. Add anything you read on their own website before Thursday. Don't fill gaps with guesses | Recruiters often ask this to see whether you've done your homework. The pack's research didn't run, so the only facts to hand are the advert's |

### B. Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is wholesale logistics. This role coordinates production schedules between planning, the warehouse and QA. How would that translate?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | **The highest-ROI prep in this pack.** Hold to what your sentences carry: "For four years I've been a logistics coordinator at a building-supplies wholesaler. I schedule deliveries for our three depots and chase suppliers when orders slip." Be clear with yourself on the limit before she raises it: your material is delivery scheduling, not production scheduling with planning and QA, so don't claim the second. Answer slot: if your depot scheduling meant agreeing plans with other teams or people, say who and how, in your own words. If it didn't, say so plainly and stay with the depot scheduling. If she asks directly whether you've worked in production or manufacturing, answer truthfully either way. Then offer a ramp plan as a plan: what you would want to learn first about how the schedule moves between planning, the warehouse and QA. Through two follow-ups, keep returning to the depot scheduling and never add to it | F1 is the biggest gap between your material and the advert, so some version of this will come up. JD because it scores the advert's first duty |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | You choose; the pack can't choose for you. One honest option your material supports: "I haven't used SAP. We run our own in-house stock system." Then say how you would get up to speed, as a plan. If you'd name a different area, name it plainly and say how you'd close it | A standard Skeptic question. F8 is a gap you've stated yourself, so it is a safe and honest answer |
| B3 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We run our own in-house stock system." Answer slot: if she asks whether that system is similar, describe what you actually do in it, in your own words, and let her judge. Don't call it an ERP unless it is one | The advert names SAP (F8, F9). It is a plus, so a plain answer costs little, and a stretched one costs a lot if it's checked later |
| B4 | "Have you done any regular reporting, something like a weekly on-time dispatch figure?" | JD | [grounded] | Answer slot: if you've produced regular reports on deliveries or dispatch, say what they covered, how often and who read them, in your own words. If you haven't, say so plainly and say how you would approach a weekly on-time dispatch report | F5 has no evidence in your material. It is one of the advert's four duties, so expect it |
| B5 | "So is this mainly about not wanting to move to Reading?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words again, whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Add nothing | A likely follow-up to A5. Rehearse it so you repeat your own words rather than adding new reasons on the spot |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Keep the sentence as you said it, with "about a third" and "over a year". Then answer in your own words: how it was counted, what else could have moved it, the assumption behind it you'd defend least (say this before she asks), and which part was yours. "I don't know exactly how it was counted" is an honest answer | F4's figure is the only number in your material, so if anything gets probed, it will be this |
| C2 | "What did you change when you rebuilt the stock-count spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: say what you changed and why, in your own words, because the pack can't supply it. If others worked on the rebuild with you, say which part was yours | The natural follow-up to F4's figure, and it tests what was actually yours |
| C3 | "How do you know which supplier deliveries are running late?" | JD | [grounded] "chase suppliers when orders slip" | Start from the quote: you chase suppliers when orders slip. Answer slot: if you track supplier deliveries in some way, say how, in your own words. If there is no tracking step, say so plainly and describe how you chase | The advert's "track supplier deliveries" line (F3), where your material is thin |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery due tomorrow will be three days late, and production needs it. What do you do?" | CASE | [generic] | Structure it out loud. First clarify: what the delivery is for and how much slack the schedule has. Then decide who needs to know, from the three teams the advert names: planning, the warehouse and QA. Then options: an earlier part-delivery, another source, or a change to the production order. Then record it and confirm the new plan with everyone affected. The question asks about no past, so the answer needs no claim about your past | Built from the advert's scheduling and chasing duties (F1, F2). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "The weekly on-time dispatch figure has dropped. Where would you look first?" | CASE | [generic] | First clarify how "on time" is defined and over what period. Then split the late dispatches by cause: supply, production, warehouse or carrier. Check whether one product, customer or day accounts for most of them. Then say what you would report and to whom | The advert's reporting duty (F5), asked as a live problem |

### E. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier order slipped and you had to chase it." | EXP | [grounded] "chase suppliers when orders slip" | Pick one real occasion from the chasing you describe. A good story has what slipped, what you did, and how it ended, in your own words. If no single occasion comes to mind, say so plainly, then describe how you chase suppliers when orders slip | The theme comes from the advert's "chase late orders" (F2). One specific occasion lands far better than a general description |
| E2 | "Tell me about a time you had to get different teams lined up on one plan." | EXP | [grounded] | Pick a time you had to get two or more teams or people working to one plan. It needs who was involved, what didn't line up, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material supports (your depot scheduling) or how you would handle it | The theme comes from the advert's "between planning, the warehouse and QA" (F1). It is the behavioural version of B1 |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA (F1) | B1, D1, E2 |
| Track supplier deliveries (F3) | C3 |
| Chase late orders (F2) | A1, D1, E1 |
| Keep stock records accurate (F4) | A1, C1, C2 |
| Report weekly on on-time dispatch (F5) | B4, D2 |
| 2+ years in operations or logistics coordination (F6) | A1 |
| Confident with Excel (F7) | A8 |
| ERP experience, SAP or similar, a plus (F8, F9) | A7, B2, B3 |
| £38,000–£44,000 (F10) | A2 |
| Hybrid, two days at Avonmouth (F11) | A4 |
| Notice period, from Hannah's agenda | A3 |
| What's prompting a move, from Hannah's agenda | A5, B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the coordinator's week split between planning, the warehouse and QA?" | It shows you read the advert's three-team line, and her answer tells you how hard F1 will be pushed in later rounds |
| R2 | "Which ERP or stock system does the team use, and how do new starters learn it?" | It raises the SAP point (F8) yourself, framed as learning, before anyone else raises it |
| R3 | "How is on-time dispatch measured for the weekly report, and who reads it?" | A specific question about a listed duty is a sign of preparation, and her answer prepares you for D2 |
| R4 | "What would a good first three months look like in this role?" | It gets her to describe what success looks like, which you can use in the next round |
| R5 | "Is this a new role or a replacement?" | It tells you what the team is short of, and recruiters can usually answer it |
| R6 | "What's the timeline for the next stage, and who would I meet?" | She has said she'll cover next steps, so asking for timing and names builds on that without repeating it |

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation, not words for you: your material says depots, not production. B1's slot stays inside the depot scheduling |
| Tracks supplier deliveries | Inflated form of F3 | F3's quote at its own scope: "chase suppliers when orders slip". C3's slot asks only how you do it, if you do |
| Cut stock discrepancies by a third, or by 33% | Inflated form of F4: it drops "about" and turns "discrepancies fell" into a claim that you caused the fall | The whole quote: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." |
| Has used SAP | A negative you stated yourself, F8 | "I haven't used SAP." No slot |
| Has ERP experience | Inflated form of F9 | F9's quote: "We run our own in-house stock system." |
| Advanced Excel skills | Inflated form of F7 | F7's quote: "I rebuilt our stock-count spreadsheet." A8's slot asks only which program |
| A salary range, a lower figure, or flexibility on pay | Goes beyond F10's quote | "I'm hoping for £42,000." |
| Open to more office days than you said | Goes beyond F11's quote | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| Any other reason for leaving | Goes beyond A5's quote | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Sources

**Provided documents:** the Operations Coordinator advert (pasted), Hannah Lowther's LinkedIn message (pasted), and your background, figures and planned answers (your message). No dossier was used.

**Searches sent:**

- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics interview process operations`: refused
- `Quillmoor Diagnostics Avonmouth news`: refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. The company's published values would have given themes for E1 and E2 |
| 2. `Quillmoor Diagnostics interview process` | unavailable | The search was refused. It would have described the rounds after this call. Hannah's own message already sets out this call, so the persona weights stand |
| 3. `Quillmoor Diagnostics` strategy / recent news | unavailable | The search was refused. It would have replaced A9's advert-only facts with current context, and added a strategy reverse question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. Her public professional profile would have added a short read on the interviewer and a reverse question tied to her career |
| 5. Representative Operations Coordinator advert | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search, then rerun → targets 1 to 4: themes from the published values for E1 and E2, current company context for A9 and R5, and a read on Hannah from her public professional profile, plus a reverse question tied to her
- A deeper research pass, once search is allowed (up to 6 more searches and 2 more fetches, several more minutes) → a company brief for sharper CO and CASE questions
- Your answers to the answer slots, said outside a drill (how your depot scheduling works with other teams, how you track deliveries, any regular reporting, which spreadsheet program, what the in-house system does) → F1, F3, F5, F7 and F9 gain quoted evidence, and B1, C3, B4, A8 and A7 get guidance built on your own stories
- Your notice period → A3 holds your own words instead of an instruction
- Anything you know about how the stock-count figure was counted → C1 gets your own words for the follow-ups
- Your CV → the fit snapshot draws on more than this message, and confidence can rise where the CV adds detail
- How much prep time you have before Thursday → a prioritised prep schedule
- The schedule for the next round, once Hannah gives it → a separate pack for that round, weighted to its interviewers
- A `tuesday-dossier.md` → a highest-ROI objection derived from verified evidence rather than inferred, and a prohibited list carried in from earlier work
