# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Round:** text-chat interview with the support team lead, as the invite describes it. **Assumed relationship:** future manager (hiring-manager round). The invite doesn't say whether the team lead is your manager or a peer, so the persona weights below rest on that assumption.

## How to use this pack

- **Personas** describe *how* a question arrives: friendly, sceptical, time-pressured. **Types** describe *what* is being scored.
- Type key: **VAL** values and behaviour · **EXP** your experience, checked for what was actually yours · **JD** the listed requirements · **CO** company knowledge · **CASE** a live problem from the job.
- This round is a **text chat**, so your writing is being assessed as you answer. Practise typing your answers: short paragraphs, a clear first line, no walls of text. Aim for answers you could type in two or three minutes.
- Guidance is scaffolding, not a script. Where a row says **Answer slot**, the pack doesn't know the answer, so give your own, honestly, either way.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as given in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. This is your own word with nothing to inspect behind it yet, so expect probes on the details. Lead with the role and its volume as you stated them: three years as a customer service advisor, around 60 calls and emails a day. The figure covers calls *and* emails together, so keep it that way |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as given in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap. The ad says "or a similar ticketing tool", and you use one daily. Say it as you said it: "I use Freshdesk every day." Your material doesn't say whether you've used Zendesk itself. Answer slot: if you have, say where and how much; if you haven't, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as given in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Handling emails is close to written communication but doesn't show how well you write. The text chat itself will be your strongest evidence. Answer slot: if you have habits for writing clear replies (templates you wrote, ways you check tone, feedback you've had on your writing), describe them in your own words; if not, say so plainly and show it in how you write during the chat |
| F4 | "confidence handling escalations" — job ad, as given in your message | none given | none | [grounded] | discovery | Your material says nothing about escalations either way. Strong evidence would be a specific case: what the customer was upset about, what you did, and how it ended. Answer slot: if you've handled escalations (angry customers, complaints, cases you passed up or took over), pick one and tell it in your own words; if you haven't, say so plainly and explain how you would handle one |
| F5 | Familiarity with software products and software support, a usual expectation for support roles at software companies | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap that words won't close, and you've said so. Words: "I've never worked for a software company." Then how you'd learn the product, framed as a plan, not as something you've done. Don't add anything to make the gap seem smaller |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "A customer writes in saying…, what's your reply?" Typed scenarios you answer live | High. A team lead hiring into their own queue wants to see how you'd handle real tickets, and in a text chat they can watch you write | Clarify first, then structure: what you'd check, what you'd say, when you'd escalate. Write the reply as you'd send it |
| Skeptic | Gentle probing on the software gap and the Zendesk line | High. F5 is the clearest gap between your background and the role, and any manager will notice it | Rehearse B1 until it bores you. Say the gap plainly, then give a concrete plan for learning the product |
| Conversational | "Tell me about yourself", "why us?" | Medium. Most first interviews open this way, and a casual tone in chat still gets scored | A ready, short typed arc built only from F1 and F2 |
| Data-Driven Prober | "60 a day: how was that counted?" | Medium-low. Support leads think in queue numbers, and yours is the only number in your material | Know what you can and can't say about how the figure was counted, and say plainly where you don't know |
| Pressure | Time-boxed "why you over someone with SaaS experience?" | Low-medium. Less usual in a chat, but a lead may test composure on the gap | Pause, restate, hold what F1 and F2 carry through two follow-ups, then concede the F5 gap plainly |
| Values / Behavioural | "Tell me about a time you…" stories | Low-medium. No values-style round is documented, and Lumenvale's published values couldn't be researched, so these are generic | Have two real stories chosen in advance. Where none comes to mind, say so |
| Peer Evaluator | How you'd work with engineering and the rest of support | Low. Applies only if the team lead turns out to be a peer, not your manager | Propose working principles; don't pretend to know how their teams split the work |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in furious that they've been charged twice and demands a manager. Type me your first reply." | CASE | [generic] | Actually write the reply. Shape: acknowledge the problem in one line without blaming anyone; say what you're doing now (checking the charge); give a realistic timeline; say how the manager request will be handled. Then, separately, explain what you'd check internally and when you'd pass it up. The question asks nothing about your past, so the guidance claims nothing about it | Tests two requirements at once: escalations (F4's requirement) and written communication (F3's), in exactly the format this round uses. CASE because it's a live problem |
| A2 | "A customer reports a bug you can't reproduce. How do you handle the ticket?" | CASE | [generic] | Structure: thank them, then ask for steps, screenshots, device or browser and timing; check whether it's a known issue; if it still can't be reproduced, pass it on with a clean summary of what you tried; tell the customer what happens next and follow up. Say you'd learn Lumenvale's own process for this | The usual software-support problem, aimed straight at F5's gap. It lets you show method without claiming past software work |
| A3 | "When would you escalate a ticket, and when would you keep hold of it?" | JD | [grounded] | Give principles: keep it when you have the knowledge and authority to fix it; escalate when it needs access, authority or expertise you don't have, when the customer's risk is high, or when a pattern suggests a wider problem. Add that escalating well means a clear summary so nobody has to ask the customer again | Scores the "confidence handling escalations" line directly. JD because it's the stated requirement |
| A4 | "You've got a full queue and two tickets are marked urgent. Walk me through your next hour." | CASE | [generic] | Structure: check that "urgent" really is urgent; deal with true urgencies first; send holding replies so nobody waits in silence; flag to the lead if the queue can't be cleared in time. Keep it practical | Queue triage is everyday work for this role and a natural chat scenario. CASE because it's a live problem with no single right answer |
| A5 | "Explain to a non-technical customer, in writing, how to clear their browser cache." | JD | [generic] | Write it: numbered steps, one action per step, no jargon, a line on what they should see when it's worked, and an offer to help if it doesn't. Keep it short | A direct test of "clear written communication" in a software context. JD content, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we expect you to pick up our product quickly?" | JD | [grounded] "I've never worked for a software company"; "I use Freshdesk every day"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | **The highest-ROI rehearsal in this pack.** Concede first, in your own words: "I've never worked for a software company." Then hold on what you do carry: three years as a customer service advisor, around 60 calls and emails a day, and "I use Freshdesk every day." Then a plan, as a plan: how you'd learn the product in your first weeks (help centre, shadowing tickets, using the product yourself, asking questions). Follow-up 1 ("but software is different"): agree it's different and go back to your plan, without adding to your past. Follow-up 2 ("how long to be useful?"): say honestly that you don't know their product yet, and that you'd like to hear how long new starters usually take. Don't call your experience proof of anything; describe it and let them draw the conclusion | F5 is the most predictable objection to this background and will come up in some form. JD because product knowledge is what the role needs; Skeptic because it targets the gap |
| B2 | "The ad mentions Zendesk. Have you used it?" | JD | [grounded] "I use Freshdesk every day" | Start with what's true: "I use Freshdesk every day." Answer slot: if you've used Zendesk, say where and how much, in your own words; if you haven't, say so plainly and stay with Freshdesk. Don't suggest you know Zendesk if you don't | The ad names the tool, so expect a direct check (F2). JD because it scores a listed requirement |
| B3 | "Tell me about a time you handled an escalation." | JD | [grounded] | Pick a time you dealt with a customer who was angry or whose case had to go higher. A good story names the problem, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest case you do have, or explain how you would handle one (A1 and A3 give you the structure) | The ad asks for "confidence handling escalations" and your material is silent on it (F4). An open prompt, so you choose the story |
| B4 | "Why leave the energy supplier for a software company, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: give your actual reasons, in your own words. The pack doesn't know them and won't supply any. Keep it forward-looking and avoid criticising your current employer | Every move into a new industry gets asked "why the switch?" EXP because it tests whether your story is consistent |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short typed arc with only these beats: three years as a customer service advisor at an energy supplier; around 60 calls and emails a day; Freshdesk every day; last year you trained four new starters on your refunds process. Finish with one line on why this role, in your own words. Four or five sentences at most | The opener in almost every interview, and the first writing sample they'll see. EXP because it sets up everything they'll probe later |
| C2 | "What drew you to Lumenvale?" | CO | [generic] | Answer slot: your own reasons. Before the interview, read what Lumenvale's own website says about its product and customers, so you can name something specific. Research for this pack couldn't run, so there are no company facts here to use | Motivation is always checked. CO because it tests homework; `[generic]` because no company research could run |
| C3 | "How do you make sure your written replies come across the way you mean them?" | JD | [inferred] "answering around 60 calls and emails a day" | Start from what's true: your daily volume includes emails. Answer slot: if you have habits (re-reading for tone, templates, checking the customer's question is fully answered), name the ones you really use; if you don't, say so plainly and describe what you'd do. Show it as you type, too | F3 is thin, so the honest answer needs rehearsing. JD because it scores "clear written communication" |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day. How was that counted, and what was the split?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep the figure as you gave it: around 60 calls and emails a day, together. Answer slot, in your own words: how you know the figure (a system report, your own estimate); what moves it up or down; the part of it you'd defend least; and the split between calls and emails if you know it. If you don't know how it was counted, say so; that's an honest answer. Never turn it into "60 emails a day" | Your only volume figure, and support leads think in queue numbers. EXP because it checks a claim |
| D2 | "You trained four new starters on refunds. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats as stated: four new starters, your refunds process, last year. Tell it in your own words. Answer slot: if asked which parts were yours (planning it, delivering it, checking their work), say which, plainly; if someone else designed the training and you delivered it, say that. Don't upgrade it to running a training programme | The most distinctive line in your material, so a prober will dig. EXP because it's about what was actually yours |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already done support at a software company?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause, then three short lines: three years and around 60 calls and emails a day; Freshdesk every day; and plainly, "I've never worked for a software company", followed by your learning plan from B1. If pushed twice, hold on what you've done, concede the gap again without apologising, and don't add claims to close it | The B1 objection under time pressure. JD because it compares you with the role's needs |
| E2 | "Honestly, how much of your Freshdesk experience transfers?" | JD | [grounded] "I use Freshdesk every day" | Hold: "I use Freshdesk every day." Answer slot: name, in your own words, the parts of how you work in it that you'd expect to carry over, and what you'd still need to learn about their tool and setup. If you don't know how their setup differs, say so | Tests whether you overclaim or underclaim (F2). JD because it scores the tooling requirement |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Pick a time you chose the right outcome for a customer over a target such as handling time. It needs a real stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | A common behavioural question in support interviews. `[generic]` because Lumenvale's published values couldn't be researched |
| V2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Pick a time you raised a problem with a manager or process. It needs a named issue, how you raised it, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would raise one | Support staff often see problems before anyone else does, so leads value people who speak up. VAL because it scores behaviour |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Support and engineering sit side by side here. Where's the seam, and what happens when we disagree about priority?" | CASE | [generic] | Offer principles rather than guessing their setup: support owns the customer conversation, engineering owns the fix; escalations come with a clean summary; disagreements about priority go back to customer impact and get settled by whoever owns priority. Ask how it works at Lumenvale | Relevant only if the team lead is a peer, or if you meet more people later. CASE because it's a working-style problem |
| G2 | "What would you need from the rest of the team in your first month?" | CASE | [generic] | Balance what you'd need (product training, shadowing, someone to ask) with what you'd give back (taking simpler tickets early to free up others). Keep it concrete | A reciprocity check: does this hire reduce the team's load or add to it? |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | C1, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | B2, E2 |
| "clear written communication" | A1, A5, C3 |
| "confidence handling escalations" | A1, A3, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first month look like for a new specialist: product training, shadowing, a lighter queue?" | Takes on your F5 gap head-on and shows you're already planning your ramp-up |
| R2 | "What kinds of tickets make up most of your queue?" | Shows you think about the actual work, and tells you what to brush up on |
| R3 | "How do escalations work between support and engineering here?" | Picks up the ad's escalation requirement and shows you care about the process |
| R4 | "How do you measure good support on your team?" | Shows you expect to be measured and want to know what good looks like |
| R5 | "What separates your strongest specialists from the rest?" | Tells you what this lead values, in their own words |
| R6 | "Is there another stage after this chat, such as a call or video interview?" | Tells you what to prepare for next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in support at a software company | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." Your material shows Freshdesk, not Zendesk; B2's slot is where you answer that, either way |
| Answered 60 emails a day | Inflated form of F1: the figure covers calls and emails together | F1's quote at its own scope: around 60 calls and emails a day. D1's slot asks only about the split, if you know it |
| Ran or designed a training programme | Inflated form of F1's training line | The quote at its own scope: you trained four new starters on your refunds process last year. D2's slot asks only which parts were yours |

## Sources

- Provided: your message (the invite text, the four requirements from the job ad as you gave them, your background).
- Search "Lumenvale Software values": refused.
- Search "Lumenvale Software interview process customer support": refused.
- Search "Lumenvale Software news 2026": refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Refused. Would have supplied published values to theme the V-bank and possibly a values cheat sheet |
| 2. `Lumenvale Software interview process customer support` | unavailable | Refused. Would have checked the round structure against other sources; persona weights rest on the invite's own description |
| 3. `Lumenvale Software` strategy / recent news | unavailable | Refused. Would have supported a company-grounded CO or CASE question; C2 stays generic |
| 4. `{interviewer name} Lumenvale Software` | n/a | The team lead wasn't named, so there was no query to form. No interviewer read |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements in your message fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full job ad text → any requirements beyond the four you listed get fit-snapshot rows and questions, and the requirement coverage becomes complete
- The team lead's name and whether they'd be your manager → an interviewer read, reweighted personas, and a reverse question tied to their path
- Permission to search the web → Lumenvale's published values, interview process and recent news feed the V-bank, persona weights and a company-grounded CO question
- An escalation case and your Zendesk answer, told to me outside a drill → F4, B2, B3 and E2 move from answer slots to story-mapped guidance
- A performance review or quality-score summary from your current role → F1 and F3 could move from medium or low toward high confidence
- A `tuesday-dossier.md` → verified evidence and an agreed list of claims to avoid would sharpen B1 and the prohibited list
