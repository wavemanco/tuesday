# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Round:** one 45-minute panel. **Panel:** Principal Dolores Vantongeren (hiring decision-maker) and two members of the fourth-grade team (future peers, names not given).

## How to use this pack

- **Personas** describe *how* a question is asked: who asks it and in what style. **Types** describe *what is being scored*.
- Type key:
  - **VAL**: whether your past behaviour shows the district's published beliefs
  - **EXP**: whether what you say about your experience holds up when they ask what was actually you
  - **JD**: whether you can do the listed job, including its gaps
  - **CO**: whether you know what the district is doing now
  - **CASE**: a live classroom or team problem, solved out loud
- Provenance labels: `[grounded]` traces to your message, the invite or a district page in Sources; `[inferred]` comes from a representative job description, not Halvering's own posting; `[generic]` is a common pattern for this kind of role.
- **Answer slot** means the pack does not know the answer. You fill it in the interview with what really happened, or you say plainly that it didn't.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

The quotes below are from what you sent. The pack says nothing about your past that isn't in them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met as you state it. Fourth grade is within the grades 1–6 your endorsement names. Say it in the quote's own terms: your license, its endorsement and the date it runs to. Confidence is medium only because nothing has been inspected yet. A printout of your license record answers any check on the spot |
| F2 | "experience in grades 3 to 5 preferred" — representative JD | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Your third-grade years fall inside the range this kind of posting prefers. Lead with them as stated: six years, third grade, a public elementary school |
| F3 | Teaching fourth grade: "the Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message, and "Six years teaching third grade at a public elementary school in Joliet." — your CV | none | [grounded] | capability | You have said this yourself, so the pack gives your words back to you: "I haven't taught fourth grade." Then the third-grade quote at its own scope. Anything about getting ready for fourth grade is said as a plan ("I would…"), never as something you've done. Don't add anything to make the gap seem smaller |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative JD | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material doesn't say which subjects you taught. Answer slot: if you taught all five, say so and how you planned across them, in your own words. If some were taught by someone else, such as a science teacher or a partner teacher, say so plainly and talk about the subjects you did teach |
| F5 | "differentiate instruction using assessment data" — representative JD | none given | none | [inferred] | discovery | Your material doesn't show this either way. Answer slot: if you have used assessment results to group students or change a lesson, describe a real case in your own words. If not, say so plainly and say how you would start |
| F6 | "keep clear classroom routines" — representative JD | none given | none | [inferred] | discovery | Your material doesn't show this. Answer slot: describe the routines you actually run in your room, in your own words. If you don't have a set routine for something they ask about, say so and say what you would set up |
| F7 | "communicate regularly with families" — representative JD | "I write a weekly email to families." — your CV | medium | [inferred] | none | The quote meets the requirement as stated. Lead with it as written: weekly, by email, to families |
| F8 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Email is not the same as speaking with every family, and the pack keeps your words where they are: "I write a weekly email to families." Answer slot: if you also talk with families, say how, for example conferences or calls, in your own words. If email is your main channel, say so plainly and say how you would add a conversation with every family each term |
| F9 | "work with the grade-level team" — representative JD | "I led our grade level's move to a new reading curriculum in 2024" — your CV, and "I've never been a team lead" — your message | medium | [inferred] | none | The quote reaches teamwork at grade level. Keep it at its scope: you led the move to a new curriculum, not the team. If the title comes up, give your own words: "I haven't been a team lead." Then go back to the curriculum move |
| F10 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV, and "I've run the after-school reading club for the last two years" — your CV | low | [grounded] | discovery | Both quotes are about reading, but neither shows individual reading plans. Answer slot: if you have written or used reading plans for individual students, say how, in your own words. If you haven't, say so plainly and talk about the reading work you do have: the curriculum move and the club |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license | R3 |
| F2 grades 3–5 experience | R1, A1 |
| F3 fourth grade | A1, A4, P1 |
| F4 all five subjects | E3 |
| F5 assessment data | E1, B4 |
| F6 classroom routines | B5 |
| F7 family communication | D1, E2 |
| F8 speak with every family | D1 |
| F9 grade-level team | A3, C1, C3, C4 |
| F10 reading plans | B2, D2 |

## Reading the interviewer

Source: one public speaker page (see Sources). Professional footprint only.

- **Career pattern:** principal of Halvering Elementary School since 2022, after nine years as a reading specialist.
- **Published theme:** her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5.
- **What this means for you:**
  1. Expect reading-instruction questions to go deep. A former reading specialist will notice vague reading language right away.
  2. Small groups and reading conferences are likely topics (B3), and a good subject for a reverse question.
  3. Talk about reading precisely: what you did, with which students, in plain words.
- **Shared ground:** reading. Your side of it is "I led our grade level's move to a new reading curriculum in 2024" (F9) and "I've run the after-school reading club for the last two years" (F10). You haven't made a career jump like hers, so the pack doesn't suggest framing it as one.

## Persona table

The district's "How we hire teachers" page gives the format: one 45-minute building panel with the principal and two grade-level teachers, asking about reading instruction, classroom routines and how you work with families. These weights blend a hiring-manager seat with two peer seats.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | "You haven't taught fourth grade…", "What exactly did you lead?" | High. The principal is weighing risk, and F3 is the most visible gap | Rehearse A1 until it's boring. Make the plain admission first, then the third-grade years, then a plan |
| Case / Strategist (bank B) | Live classroom problems: a struggling reader, small groups, routines, the 2027 curriculum | High. The principal's seat, and all three topics on the district page are practical | Clarify, then aim, then approach, then how you'd know it worked. Think out loud |
| Peer Evaluator (bank C) | "What would you bring to our team, and what would you need?" | High. Two of the three panelists would be your teammates | Show what you'd give and what you'd ask for. Stick to what F9's quote carries |
| Values / Behavioral (bank D) | Questions built on the three district beliefs | Medium. The district page says the beliefs "guide every hire", but no separate values round is documented | Match stories to beliefs only where your quotes support them. Otherwise say so honestly |
| Data-Driven Prober (bank E) | "How did you know it was working?", "What data do you use?" | Medium. A likely follow-up from teachers on the assessment-data line | If you don't know how something was measured, say so. Don't make up a figure |
| Rapport Builder (bank R) | The friendly opener and quick checks | Medium-low. Every panel opens this way, and it's still scored | Have a ready 90-second arc built from your quotes |
| Pressure (bank P) | A timed "why you" question, or "how much was actually you" | Low. Not typical for a building panel, but still worth one rehearsal | Pause, hold your position through two follow-ups, then concede specifically |

## Question banks

Banks are lettered by persona: A, B, C, D, E, R and P. The letter F is kept for fit-snapshot rows.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we choose you over someone who has?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | **Highest-ROI prep in this pack.** Concede first, in your own words: "I haven't taught fourth grade." Then hold with only what the quote carries: six years of third grade at a public elementary school. Then a plan, stated as a plan: what you would do before the first day, such as reading the fourth-grade standards and asking the team for their unit plans. Follow-up 1 ("but the content is different") gets the same admission and a more specific plan. Follow-up 2 ("so what's the risk?") gets a specific concession: the first year of fourth-grade content is new to you. Don't fold on the six years. Don't claim you know fourth grade | F3 is the one gap the panel can't miss, so it will come up in some form. JD because it scores the role itself |
| A2 | "You led your grade level's move to a new reading curriculum. What was your role, exactly?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start with the quote: you led the move, in 2024, for your grade level. Answer slot: the team-work line in this kind of posting makes a probe on the steps likely. If specific parts of the move were yours, say which and how you did them, in your own words. If a decision, such as which curriculum, was made elsewhere, say so plainly and stay with what you led. Don't say you chose or designed the curriculum | F9 is your strongest team evidence and the first thing a careful panel will test. EXP because it checks attribution |
| A3 | "Have you been a team lead?" | JD | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Answer directly: "I haven't been a team lead." Then the curriculum move at its own scope. Don't turn leading the move into having led the team | F9's honest limit. JD because it tests the teamwork requirement. A short, calm answer here makes A2 more believable |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name a real one. Fourth-grade content is the one you've stated, so you can say: "I haven't taught fourth grade." Then the plan from A1. If another area feels weaker to you, name it honestly instead. Don't name a fake weakness | A standard Skeptic question. It rewards a candidate whose self-assessment matches their record |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The district is bringing in a new grades 3–5 reading curriculum in fall 2027. How would you help our fourth-grade team get ready?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Structure it: what you'd ask first (timeline, training, materials), what the team needs before launch, how you'd share the work, and how you'd know the first months are going well. You can mention that you led your grade level's move in 2024, in those words. Answer slot: if something from that move would change how you'd do it here, say what, in your own words. If not, keep to the plan | From the district's 2026 literacy plan. It's the one question where F9 is directly relevant. CASE content with CO grounding |
| B2 | "In October, a fourth grader is reading well below grade level. Walk us through your first two weeks." | CASE | [grounded] | Clarify (what the data shows, what third grade passed on, including any reading plan), then assess, then a small-group or one-to-one plan, then involve the family, then check progress at a set point. This question makes no claim about your past, so the guidance makes none | "Every Child a Reader" (F10's requirement) as a live problem. It's also the topic area of a principal who was a reading specialist |
| B3 | "How would you run small-group reading and reading conferences in a fourth-grade room?" | CASE | [grounded] | Structure: how you'd form groups, how often you'd meet each one, what the rest of the class does meanwhile, and how conference notes feed the next lesson. Answer slot: if you run small groups or conferences now, describe how, in your own words. If you don't, say so and give the plan | The principal's own published topic (Reading the interviewer). CASE because it's asked as a design question |
| B4 | "A unit test shows half the class missed one skill. What do you do the next day?" | CASE | [grounded] | Structure: check what the miss means (one item or a pattern), regroup, reteach in a different way, check again. Make clear the test shapes your teaching and doesn't replace it. No claim about your past | "Teach for Tomorrow, Not for the Test" and F5's requirement as a live problem |
| B5 | "It's week two and transitions are eating your instructional time. What do you change?" | CASE | [inferred] | Structure: find where the time goes, choose one or two routines, teach and practise them, then check whether the time comes back. No claim about your past | F6's requirement. Routines are one of the three topics on the district's hiring page |

### C — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What would you bring to our team, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade" | What you'd bring: the curriculum move, at its own scope, and what you'd offer to do for the team as a plan. What you'd need: their fourth-grade unit plans and pacing, since "I haven't taught fourth grade." Asking for this openly shows you know where your gap is | The reciprocity question peers ask. It draws on both F9 and F3 |
| C2 | "Tell us about a time you disagreed with a colleague about instruction." | JD | [generic] | Pick a time with a real disagreement about teaching, a conversation you had and a working relationship that survived. Be specific about your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A Peer Evaluator stem tied to teamwork (F9). JD because it scores working with the team |
| C3 | "When your grade level moved to the new curriculum, how did the team work through it together?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start with the quote. Answer slot: if there were disagreements or problems during the move, say what happened and what your part was, in your own words. If there weren't, say so plainly and describe how the move went | F9 seen from a peer's side. The second branch is there so you don't invent conflict to make the story better |
| C4 | "How do you share planning and credit across a grade-level team?" | JD | [generic] | Pick a real example of shared planning or credit. Use "we" for the team's work and "I" for your part. If no example fits, say so plainly and say how you'd approach it | Teammates want to know whether you'll add to their workload or lighten it |

### D — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "'Families Are Partners' — how do you build that with every family?" | VAL | [grounded] "I write a weekly email to families." | Start with the quote: a weekly email to families. Answer slot: the district expects each teacher to speak with every family each term. If you have conversations with families too, say how, in your own words. If email is your main channel, say so plainly and say how you'd add a conversation with every family each term | F8 is a transferability gap. This is where the panel will test it |
| D2 | "'Every Child a Reader' — tell us about a time a student who struggled with reading made progress." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Pick a time with a specific student (no names), what you did, and what changed. If a story from the reading club fits, use it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Built on the district belief. F10 has no reading-plan evidence, so this is a scaffold rather than a set story |
| D3 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Start with the quote: you've run the club for the last two years. Answer slot: given "Every Child a Reader", expect a probe on who it serves and what happens in it. Answer in your own words. If you don't know something, such as attendance numbers, say so. Don't say you started the club unless you did | F10's reading work, and an easy question to turn into a strength if you stay accurate |

### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How do you use assessment data to group or reteach students?" | JD | [inferred] | Answer slot: if you do this, describe a real case: which assessment, what you saw, what you changed. If you don't do it in a set way, say so plainly and walk through B4's structure as a plan | F5 has no evidence yet. The honest answer should be ready before the question comes |
| E2 | "After the curriculum move, what did you look at to judge how it was going?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you or the team tracked something, such as assessment results or feedback from teachers, say what, in your own words, and name the part you're least sure of. If nothing was formally tracked, say so plainly and say what you'd look at next time. Don't make up results | A Prober follow-up on F9. Saying "we didn't measure it formally" beats inventing a gain |
| E3 | "Tell us how you plan across reading, writing, math, science and social studies." | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: if you've taught all five subjects in third grade, say how you plan across them, in your own words. If some were taught by someone else, say so plainly and focus on the subjects you did teach | F4 is a discovery gap. This kind of posting lists all five subjects |

### R — Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Tell us a bit about yourself and your path to here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc using these four lines in your own words: six years in third grade, the curriculum move, the reading club, the weekly family email. Close on why fourth grade, which is your own reason (R2). The arc already touches all three topics on the district page: reading, the classroom and families | The opener is scored too. A tight arc gets the panel onto the topics you're strongest on |
| R2 | "Why fourth grade, and why Orrinsford?" | VAL | [grounded] | Answer slot: give your real reasons, in your own words. If one of the district's beliefs is part of why, name it by its title and say why it matters to you. Don't give a reason you don't actually have | A motivation question. The beliefs are named on the district page, so referring to one shows you've done your homework |
| R3 | "Quick check: your license covers fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it plainly in the quote's terms: PEL, elementary endorsement for grades 1–6, active through June 30, 2029. Bring a printout of your license record. Don't share your license number unless HR asks for it through official channels | F1, the stated requirement. A ten-second answer |

### P — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal candidate who already knows our fourth-grade team?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | Pause, then three lines: six years of third grade, the curriculum move at its own scope, and your plan from A1. Don't run down the other candidate. If pushed on the fourth-grade gap, give the A1 admission and hold | A time-boxed version of A1. It's worth one spoken run-through |
| P2 | "That curriculum move — how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: you led the move. Then the A2 answer slot: name the parts that were yours, in your own words, and say plainly which parts weren't. Concede specifically. Don't give up the core claim | The attribution check, under pressure. A calm, exact answer is the whole point |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| Q1 | (To the principal) "Your talk *Small Groups, Big Readers* covered weekly reading conferences in grades 3 to 5. How do those run in fourth grade at Halvering?" | It's tied to her own published work and shows you prepared for her specifically |
| Q2 | (To the teachers) "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. It shows you plan to add to the team, not just take from it |
| Q3 | "How is the fourth-grade team getting ready for the new grades 3–5 reading curriculum in fall 2027?" | It uses current district news and leads naturally into F9 |
| Q4 | "How do teachers here meet the goal of speaking with every family each term: conferences, calls, something else?" | It turns your F8 gap into curiosity and shows you know the district's beliefs |
| Q5 | "How does the handoff from third to fourth grade work here, including students' reading plans?" | It's a third-grade teacher's question, and it touches "Every Child a Reader" |
| Q6 | "What does a strong first year look like for a new fourth-grade teacher here?" | It invites them to describe success, which you can then speak to |

## Prohibited claims

The pack won't coach these claims, and you shouldn't make them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F3 | "I haven't taught fourth grade." Then the third-grade quote. No slot |
| Has been a team lead | A negative you stated, F9 | "I haven't been a team lead." Then the curriculum-move quote. No slot |
| Led the grade-level team | An inflated form of the curriculum-move quote, F9 | The quote at its own scope: you led the move, not the team. A2's slot stays inside the move |
| Chose or designed the new reading curriculum | An inflated form of the curriculum-move quote, F9 | The quote at its own scope. Your material says you led the move, not the choice. A2's slot asks only which parts of the move were yours |
| Talks with every family each term | An inflated form of the family-email quote, F8 | "I write a weekly email to families." D1's slot covers any conversations, only if you've had them |
| Started or created the reading club | An inflated form of the reading-club quote, F10 | The quote at its own scope: you've run it for the last two years |

## Sources

**Provided:** your message (resume text and the interview invite). Your SSN and license number were not used anywhere.

**Searches and fetches:**

1. Search `Orrinsford Community School District mission values` → https://orrinsfordschools.example/about/mission-and-beliefs
2. Fetch https://orrinsfordschools.example/about/mission-and-beliefs → three beliefs and their definitions
3. Search `Halvering Elementary School Orrinsford` → no results
4. Search `Dolores Vantongeren principal Halvering Elementary` → https://ilprincipalsforum.example/speakers/dolores-vantongeren (from the search snippet; not fetched)
5. Search `fourth grade teacher job description Illinois elementary school district posting` → https://k12jobsboard.example/listings/fourth-grade-teacher
6. Fetch https://k12jobsboard.example/listings/fourth-grade-teacher → a representative JD
7. Search `Orrinsford Community School District teacher interview process panel` → https://orrinsfordschools.example/careers/how-we-hire-teachers
8. Search `Orrinsford Community School District news 2026` → https://orrinsfordschools.example/news/board-adopts-literacy-plan

Research tier: L1 — searches 6 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. district values | yes | Three beliefs by name. They shaped F8, F10, bank D, B2, B4 and R2. No values cheat sheet, because no separate values round is documented |
| 2. district interview process, teachers | yes | Loop established: one 45-minute building panel with the principal and two grade-level teachers, on reading, routines and families. It set the persona weights and B5 |
| 3. district strategy and recent news | yes | 2026–2029 literacy plan, with a new grades 3–5 reading curriculum from fall 2027. It shaped B1 and Q3 |
| 4. Dolores Vantongeren, Halvering | yes | Career pattern and her 2025 talk topic. They shaped Reading the interviewer, B3 and Q1 |
| 5. representative fourth-grade teacher JD | yes | Requirements for F2, F4–F7 and F9, all labelled `[inferred]` |
| Search for the school name (un-numbered) | yes | A further search outside the declared targets. No results, so the school's own web presence isn't established and nothing was used from it |

## Upgrade menu

- **Halvering's actual job posting** → F2, F4–F7 and F9 change from `[inferred]` to `[grounded]`, and E1, E3 and B5 get retuned to its wording
- **A printout or screenshot of your license record from the state licensure system** → F1 moves from medium to high confidence, and you have it in hand if asked
- **Your answers to the answer slots** (which subjects you taught, how you use assessment data, your routines, your family conversations, any reading plans) → F4, F5, F6, F8 and F10 get real evidence, and A2, C3, D1, E1, E2 and E3 become story-mapped
- **The two fourth-grade teachers' names** → per-panelist persona weights and a reverse question tailored to each
- **Deeper research** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Halvering and the literacy plan's details for fourth grade
- **How much prep time you have before Thursday** → a prioritised prep schedule
- **A `tuesday-dossier.md`** → an objection drawn from verified evidence instead of one inferred here, plus a carried-over list of claims not to coach
