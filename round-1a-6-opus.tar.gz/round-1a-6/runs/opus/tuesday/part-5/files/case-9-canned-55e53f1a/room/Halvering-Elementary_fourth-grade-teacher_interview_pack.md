# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Orrinsford Community School District.** A 45-minute panel on Thursday with Principal Dolores Vantongeren (who would be your principal and is effectively the hiring manager) and two members of the fourth-grade team (who would be your peers).

---

## How to use this pack

Two things organize every question here:

- **Personas** are *how* a question is asked: who is asking and in what style.
- **Types** are *what* is being scored:
  - **VAL**: whether your past behavior matches the district's published beliefs
  - **EXP**: whether what you say about your experience holds up when probed
  - **JD**: whether you can do the job as it is described, including its gaps
  - **CO**: whether you know the district's current direction
  - **CASE**: how you reason through a live classroom problem

Provenance labels show where each row comes from. `[grounded]` means it traces to your own words, the invite, or a district page listed in Sources. `[inferred]` means it comes from a representative posting for this job title, not Halvering's own posting. `[generic]` means it is a common pattern with no claim about this school.

**An answer slot** marks a place where a strong answer needs a detail that you haven't given me. It comes with two honest branches. Fill it from what you actually did, or say plainly that you didn't do it.

The guidance is scaffolding, not a script. Rehearse it in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your message | medium | [grounded] | none | No gap. Your material shows the gate is met, and grades 1–6 includes fourth grade. Say it in its own terms: "I hold an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, active through June 30, 2029." The rating is medium only because nobody has inspected the record. Confirming its current status before Thursday is up to you |
| F2 | "the Fourth Grade Teacher position" — the invite | "Six years teaching third grade at a public elementary school in Joliet" — your message; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | The adjacent grade, at its own scope, and the negative you stated: "I've spent six years teaching third grade at a public elementary school in Joliet. I haven't taught fourth grade." Answer slot: expect a probe on how well you know the fourth-grade year. If any of your work has involved what your third graders go on to in fourth grade, say how, in your own words. If none has, say so plainly. Then give your plan for learning it, stated as a plan and never as something you've already done |
| F3 | "experience in grades 3 to 5 preferred" — representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your message | medium | [inferred] | none | Third grade is inside the 3–5 range this posting prefers. Give the six years in the quote's own terms. Leave it at what the quote says; don't call it fourth-grade experience |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your message | low | [inferred] | discovery | Your material doesn't show which subjects you taught. Answer slot: if you taught all five in third grade, say so, and say where you felt strongest. If someone else taught some of them, say which ones plainly and stay with what you taught |
| F5 | "differentiate instruction using assessment data" — representative posting | none given | none | [inferred] | discovery | Strong evidence here names an assessment, a decision it led to (a group or a change in teaching), and what happened next. Answer slot: if you used assessment results to group students or adjust your teaching, say how, in your own words. If you didn't, say so plainly and say how you would start |
| F6 | "assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Strong evidence is one specific teaching choice an assessment changed, and one thing you kept teaching even though no test measured it. Answer slot: if you have such a choice, name it in your own words. If none comes to mind, say so and describe how you would hold that balance |
| F7 | "keep clear classroom routines" — representative posting | none given | none | [inferred] | discovery | Strong evidence is a named routine, how you taught it, and what you did when it broke down. Answer slot: describe routines you actually ran in your third-grade room, in your own words. If you can't name one, say so and describe how you would set them up |
| F8 | "communicate regularly with families" — representative posting | "I write a weekly email to families" — your message | medium | [inferred] | none | No gap. Lead with the email in the quote's own terms: you write it, weekly, to families. A named, regular practice is more convincing than an adjective. Nothing has been inspected, so expect a probe on what goes in it |
| F9 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families" — your message | medium | [grounded] | transferability | A weekly email is written communication, and this belief asks for speaking with every family. Keep the quote at its own scope: "I write a weekly email to families." Answer slot: if you also talk with families directly, say how and how often, in your own words. If you don't, say so plainly and stay with the email, then give your plan for reaching every family |
| F10 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your message; "I've never been a team lead" — your message | medium | [inferred] | none | Keep both of your sentences together: "In 2024 I led our grade level's move to a new reading curriculum. I haven't been a team lead." The move was yours to lead, but the title wasn't yours. Answer slot: if asked what leading the move involved, say which parts were yours, in your own words. If a part belonged to someone else, say so |
| F11 | "a new grades 3–5 reading curriculum from fall 2027" — district news, 2026–2029 literacy plan | "I led our grade level's move to a new reading curriculum in 2024" — your message; "I've run the after-school reading club for the last two years" — your message | medium | [grounded] | none | No gap, and this is probably what the panel will be most interested in. Say both sentences in their own terms: the 2024 move, which you led, and the reading club, which you've run for two years. Answer slot: the district starts a new grades 3–5 curriculum in fall 2027, so expect a probe on what leading your move involved. If particular steps were yours, say which and how. If they weren't, say so and stay with the move |
| F12 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page | "Six years teaching third grade at a public elementary school in Joliet" — your message | low | [grounded] | discovery | Your material doesn't show whether you wrote or used individual reading plans. Answer slot: if you did, say how, in your own words. If you didn't, say so plainly and say how you would build on the plans fourth graders arrive with |

---

## Reading the interviewer: Principal Dolores Vantongeren

Public professional footprint only (source: Illinois principals' forum speaker page, listed in Sources).

- **Career pattern:** principal of Halvering Elementary since 2022, after nine years as a reading specialist.
- **What she has said in public:** her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5.
- **What this means for you:**
  1. Reading instruction is her field, so reading answers will be judged by a specialist. Be precise, and don't claim more than F11's quotes carry.
  2. Expect a question about small-group reading or reading conferences. Answer slot: if you have run small groups or conferences, say how, in your own words. If you haven't, say so plainly and ask how they work in fourth grade here (reverse question R1).
  3. Fourth grade is inside the grades 3–5 range her talk covered, so questions about the year you'd teach may come from her as well as from the team.
- **Mirror opportunities:** no shared career jump is offered, because nothing in your material matches her path from specialist to principal. The shared professional ground is reading, through F11: "I led our grade level's move to a new reading curriculum in 2024."

The two fourth-grade team members weren't named, so they get no profile.

---

## Persona table

The weights come from the panel's makeup in the invite (a principal and two peers), adjusted for the principal's background and the gaps in the fit snapshot. They are a pattern, not Halvering's documented process.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| A. Skeptic | The principal, and possibly a team member, asking about the grade change and the team-lead question | High. A hiring manager weighs gaps first, and F2 and F10 are the two most visible ones | Rehearse A1 until it's boring. Build bridges only from F2's and F10's quotes, and state the limit plainly |
| B. Peer Evaluator | The two fourth-grade teachers asking what you'd add to their work and what you'd need from them | High. Two of the three panelists are future peers | Frame answers around what you'd contribute as well as what you'd need. Suggest how you'd work together rather than guessing at how they work now |
| C. Case/Strategist | The principal setting live classroom problems | Medium. A typical hiring-manager pattern, and her reading background points toward reading cases | Clarify first, then state the goal, your approach, how you'd know it worked, and the risks. Think out loud |
| D. Data-Driven Prober | A peer or the principal asking how you knew something worked | Medium. The representative posting asks for assessment data (F5), and peers check claims collegially | Know what you can and can't say about any number. Say plainly when nothing was counted |
| E. Values/Behavioral | Any panelist, themed on the district's three beliefs | Medium. The district says the three beliefs "guide every hire", although no round is documented as a values round | One real story per belief where your quotes carry one. Where they don't, use the scaffold and its honest branch |
| G. Conversational | The opener and the closing reverse-question slot | Low weight, but certain to happen. Casual questions are still scored | Have a 90-second arc ready (G1), and never answer "you've covered everything" when they ask for your questions |
| H. Pressure | A time-boxed challenge on the grade change or on how much of the curriculum move was yours | Low. Pressure is uncommon in a three-person school panel, but the gaps invite it | Pause and restate the question. Hold to what your quotes say through two follow-ups, then concede the specific point |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "All of your experience is in third grade. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | **The highest-ROI rehearsal in this pack.** Concede the limit before you're pushed: "I've spent six years teaching third grade at a public elementary school in Joliet. I haven't taught fourth grade." Answer slot: if any of your work has involved what your third graders go on to in fourth grade, say how, in your own words. If none has, say so plainly. Then give your plan, stated as a plan: what you'd learn from the team, and when, before the first day. Hold through two follow-ups by coming back to the six years and the plan. Never stretch the six years into fourth-grade experience | F2 is the most predictable objection to this application, and two of the panelists teach the exact grade you haven't. JD because it scores the role itself |
| A2 | "You led your grade level's curriculum move. Were you the grade-level lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Answer it straight: "No, I haven't been a team lead. In 2024 I led our grade level's move to a new reading curriculum." Answer slot: if asked how you came to lead the move, explain it in your own words. If you don't know why it fell to you, say what you did and stop there | F10 contains a tension a careful reader will notice, so answer it before it becomes a doubt. EXP because it tests what was actually yours |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick something true. Your material states one: the fourth-grade year itself. Say it, then the plan. Answer slot: if a subject from F4 is a real weak point, name it and say how you'd prepare. If none is, don't invent one to seem modest | Covers F2 and F4. A rehearsed honest answer beats a dodge, and this is a stock Skeptic question |
| A4 | "Why this move, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Your reason is yours to give. Give your actual reason for moving in your own words, briefly and looking forward. Nothing here supplies one. For "why Halvering", the district's literacy plan and its three beliefs are published facts you can name. Connect them only to F11's and F8's quotes | Every Skeptic asks this. EXP because it checks that your motive is consistent |
| A5 | "A new grades 3–5 reading curriculum arrives here in fall 2027. You'd be learning a new grade and then a new curriculum. Is that too much change?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: you've been through a curriculum change, and you led your grade level through it in 2024. Say it in those words. Answer slot: if something from that move would shape how you'd handle the next one, say what, in your own words. If nothing comes to mind, say so and stay with the fact that you led it | F11 is your strongest row, and this question turns it against you. CO because it relies on the district's adopted plan |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you bring to our team in your first year, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I've never taught fourth grade" | Give and take. Give: the curriculum move and the reading club, each in its quote's terms. Need: help learning the fourth-grade year, which follows from "I haven't taught fourth grade." Keep the "need" concrete, such as unit plans and a planning partner. Those are requests, not past events | F10 and F11 for what you'd give, and F2 for what you'd need. Peers judge whether a new hire adds to their workload or reduces it |
| B2 | "Tell me about a time you disagreed with a colleague on your grade-level team." | JD | [inferred] | Selection scaffold: choose a real disagreement with a named stake, where you held your view without damaging the relationship and it was resolved. Use "we" for the context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest real example or how you would handle it | The representative posting's team line (F10) in a peer's register. No quote carries a disagreement, so this row is a scaffold |
| B3 | "How do you share planning across a grade-level team?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if planning was shared on your third-grade team, say how, in your own words. If it wasn't, say so plainly and describe how you'd like to work with this team. The 2024 move can stand as the one piece of team work your quote carries, without adding steps the quote doesn't contain | F10. Peers want to know how the planning load would be shared |
| B4 | "You write a weekly email to families. How would that fit with what the rest of the team sends?" | JD | [grounded] "I write a weekly email to families" | Describe the email in its own terms. Then ask what the team sends now, and offer to fit in with it rather than run something separate. The offer is a plan, not a claim about your past. Answer slot: if asked what goes in the email, describe what you actually put in it | F8. A peer wants to know whether your practice will conflict with theirs or add to it |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "In October, a fourth grader is reading about two years below grade level. Walk us through your first month with her." | CASE | [generic] | Structure it: first find out what you already know (assessment results, her reading plan from third grade, her family); set a goal for the month; decide how you'd teach her (small group, one-on-one time, materials); involve the family; decide how you'd know it was working. Think out loud. This question needs no claim about your past, so the guidance makes none | A live problem touching F5 and F12, set by a principal who was a reading specialist. `[generic]` because it is a pattern, not a fact about Halvering |
| C2 | "The district adopts a new grades 3–5 reading curriculum from fall 2027. What would you want the fourth-grade team to do in the year before?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: ask what the district has shared so far. Then give a plan for the year before, such as learning the materials, trying them out, and preparing families. You can mention the 2024 move in its quote's terms as the change you've been through. Answer slot: if a specific step from that move is in your plan, say which step and that it was yours. If it wasn't yours, present the step as a proposal | F11 and the district's published plan. CO and CASE are the questions that separate prepared candidates |
| C3 | "It's the first six weeks of fourth grade. How do you set up your room's routines?" | CASE | [generic] | Structure it: which routines come first, how you'd teach and practice them, how you'd tell they're holding, and what you'd do when one breaks down. Answer slot: if a routine from your third-grade room carries over, name it in your own words. If none comes to mind, describe the plan | F7 has no quote, so this case is where you show the skill directly |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you use assessment results to plan your reading groups?" | JD | [inferred] | Answer slot: if you used assessment results to form or change groups, say which assessment and how, in your own words. If you didn't, say so plainly and say how you would start. Mention the district belief that "assessments inform teaching and never replace it" only if it matches what you actually do | F5 and F6. The question assumes a practice your material doesn't show, so the guidance doesn't assume it either |
| D2 | "Your reading club: how many students come, and how do you know it helps?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Start with the quote: you've run it for two years. Answer slot: if you know how many students come, give the real number. If you don't, say so. On whether it helps: if you've checked in some way, say how. If nothing was measured, say so plainly. "I haven't measured it" is a complete, honest answer | F11. The club is a claim a prober will press, so prepare the honest version of any figure before you're asked |
| D3 | "What did the curriculum move change in your grade level's reading?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you know of a change in results, say what it was and how it was measured. Also say what you'd defend least about that figure, such as how it was counted or what else changed at the same time. If you don't know, or nothing was measured, say so plainly and describe the move itself | F11. A led change invites "did it work?", and an invented result fails the next question |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader. Tell us about a time a student was struggling to read, and what you did." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Selection scaffold from your six years: choose one real student (no names), what you noticed, what you did, and what happened. Include an outcome only if there was one you know of. If no such time comes to mind, say so plainly, then give the nearest real example or how you would handle it | The first of the district's three published beliefs (F12). VAL because it is scored against a belief that is named publicly |
| E2 | "Families Are Partners. Here each teacher speaks with every family each term. How would you do that?" | VAL | [grounded] "I write a weekly email to families" | Start with what's true: "I write a weekly email to families." Then the honest gap, which is the pack's own observation: an email isn't a conversation. Answer slot: if you already talk with families directly, say how. If you don't, say so, and give a plan for reaching every family each term | F9. Covers the second belief, and the weekly email is where it is easiest to say too much |
| E3 | "Teach for Tomorrow, Not for the Test. What does that mean in your classroom?" | VAL | [grounded] | Selection scaffold: one real teaching choice where an assessment shaped what you did, and one thing you kept teaching even though no test measured it. If no such choice comes to mind, say so plainly and describe how you would hold that balance | The third published belief (F6). The label is `[grounded]` on the district page, and no claim about you is made here |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, tell us about yourself." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc built only from these five sentences, told in your own words. Start with the six years of third grade, then the 2024 curriculum move you led, the reading club you've run for two years, and the weekly email. Mention the license briefly. End with why fourth grade at Halvering, in your own reason | F1, F3, F8, F10 and F11 in one breath. It is certain to be asked, and an unprepared opener is the most common avoidable stumble |
| G2 | "What are you reading with your students right now?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: name something you're actually reading with students or the club now, and why you chose it. If nothing is current, say what you last read with them. This is a casual question on the school's top priority, so treat it as scored | F11, asked in a casual register by a principal who was a reading specialist |
| G3 | "Your license: is it current, and does it cover fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | "Yes. It's an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, active through June 30, 2029." Bring a copy of your license record | F1 is the one stated requirement. A gate needs a ready, exact answer |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade"; "I led our grade level's move to a new reading curriculum in 2024" | Pause, then hold: six years of third grade, and in 2024 you led your grade level's move to a new reading curriculum. Concede the specific point without folding: "I haven't taught fourth grade." Then give the plan. Don't compare yourself with the other candidate, whom you don't know | F2 and F11 under a time limit. A1's content, delivered under pressure |
| H2 | "You say you led the curriculum move. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold to the quote: you led the move. Answer slot: say which parts were yours and which belonged to others (the district, a coach, colleagues), in your own words. If you're unsure of the split, say so. Concede "I wasn't the team lead" if they press. Hold through two follow-ups, and don't let "led" grow into chose, designed or trained | F10 and F11. Attribution probes exist to catch inflation, so prepare the precise honest answer |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 license | G3 |
| F2 fourth grade | A1, A3, H1, B1 |
| F3 grades 3–5 experience | A1, G1 |
| F4 all five subjects | A3 (answer slot). Reading dominates the rest because of this panel's reading focus, so no separate subject question was written |
| F5 assessment data | D1, C1 |
| F6 assessments inform teaching | E3, D1 |
| F7 routines | C3 |
| F8 family communication | B4, G1 |
| F9 speaking with every family | E2 |
| F10 grade-level team | A2, B1, B2, B3, H2 |
| F11 reading curriculum | A5, C2, D2, D3, G2, H2 |
| F12 reading plans | E1, C1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To the principal) "Your 2025 talk, *Small Groups, Big Readers*, was about weekly reading conferences in grades 3 to 5. Do those happen in fourth grade here, and how?" | It is tied to her own published work, and it shows you prepared for her specifically, not just for the school |
| R2 | (To the team members) "What could a new person do in their first month that would genuinely help your team?" | Asking about reciprocity tells peers you're thinking about their workload, not only your own landing |
| R3 | "How is the fourth-grade team preparing for the new grades 3–5 reading curriculum in fall 2027, and where would a new teacher fit in?" | It draws on the district's adopted plan and opens a natural place for your 2024 experience to come up |
| R4 | "How does the fourth-grade team plan together day to day?" | You need the answer before you accept, and it invites the team to describe the job in their own words |
| R5 | "The district's beliefs say each teacher speaks with every family each term. How do teachers here usually manage that?" | It shows you read the beliefs, and the answer tells you what the family-contact workload actually is |
| R6 | "What would a strong first year look like for a new fourth-grade teacher, from your point of view?" | It shows you what you'll be measured on, and it leaves the panel picturing you in the role |

---

## Prohibited claims

These are claims this pack will not coach, and the reasons.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated (F2) | "I haven't taught fourth grade." Then the plan |
| Has been a team lead or grade-level lead | A negative you stated (F10) | "I haven't been a team lead." Plus F10's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." |
| Chose, designed, or trained the team on the 2024 curriculum | Inflated form of F10's and F11's quote | That quote at its own scope. The material says you led the move, and it doesn't say which steps were yours. H2's slot stays inside the move |
| Founded or built the reading club | Inflated form of F11's club quote | "I've run the after-school reading club for the last two years." The material says you ran it, not that you started it |
| Speaks with every family, or runs a family-engagement program | Inflated form of F8's and F9's quote | "I write a weekly email to families." E2's slot asks only whether you also talk with families |
| Third-grade experience is fourth-grade experience | Inflated form of F3's quote | Six years of third grade, which sits inside the 3–5 range the posting prefers. It is not experience teaching fourth grade |

---

## Sources

**Provided:** the interview invite from Orrinsford Community School District Human Resources, and the résumé details in your message. Your Social Security number and license number were not used anywhere, including in research.

**Searches sent:**

1. `Orrinsford Community School District mission values`: https://orrinsfordschools.example/about/mission-and-beliefs
2. `Orrinsford Community School District strategic plan news`: https://orrinsfordschools.example/news/board-adopts-literacy-plan
3. `Dolores Vantongeren principal Halvering Elementary`: https://ilprincipalsforum.example/speakers/dolores-vantongeren
4. `fourth grade teacher job description Illinois elementary school district posting`: https://k12jobsboard.example/listings/fourth-grade-teacher

**Pages fetched:** the district's Mission and Beliefs page, and the K12 Jobs Board representative posting.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | The three beliefs by name, behind F6, F9 and F12, bank E, and reverse question R5. No values round is documented, so there is no values cheat sheet |
| 2. `Orrinsford interview process` | skipped | The invite already fixes the format (one 45-minute panel with the principal and two fourth-grade team members), and that sets the persona weights |
| 3. `Orrinsford strategy` / recent news | yes | The August 2026 literacy plan, behind F11, A5, C2 and R3 |
| 4. `Dolores Vantongeren Halvering` | yes | The interviewer read, the principal's tilt toward reading, and R1. The team members weren't named, so there was nothing to search for them |
| 5. Representative `Fourth Grade Teacher` posting | yes | F3, F4, F5, F7, F8 and F10, all labeled `[inferred]` |

---

## Upgrade menu

- **Halvering's actual posting text** → F3, F4, F5, F7, F8 and F10 change from `[inferred]` to `[grounded]`, and the JD-tagged questions are retargeted to the school's own wording
- **The two team members' names** → a persona assigned to each panelist and a reverse question tailored to each
- **Any HR note on focus areas, or a demo lesson or sample plan to bring** → a build section for that deliverable, with options and a recommended structure
- **Your answers to the answer slots in F4, F5, F7, F9 and F12** (subjects taught, use of assessment data, routines, talking with families, reading plans) → story-mapped guidance for A3, B3, C3, D1, E1 and E2 in place of scaffolds
- **A printout of your license record** → F1 rises from medium to high confidence, and you'll have it on hand at G3
- **How much prep time you have before Thursday** → a prioritized prep schedule at the top of the pack
- **A `tuesday-dossier.md`** → verified evidence and limits agreed in advance for each gap, so the A1 objection would rest on confirmed evidence instead of being inferred here
