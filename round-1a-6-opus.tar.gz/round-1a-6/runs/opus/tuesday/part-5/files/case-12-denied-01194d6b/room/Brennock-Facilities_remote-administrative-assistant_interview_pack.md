# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interviewer:** the office manager, per the invite ("a 30-minute video call with our office manager"). Whether they would be your manager is not stated; this pack treats the call as a hiring-manager round.

**Format:** one 30-minute video call, so expect fewer, shorter questions than this pack holds. Rehearse in weight order.

## How to use this pack

- **Personas** describe *how* a question is asked: friendly chat, live problem, quiet probing of gaps.
- **Types** describe *what* is being scored:
  - **JD**: can you do the duties the ad lists
  - **EXP**: does your experience hold up when someone asks for detail
  - **CASE**: how you structure a live problem from the job
  - **VAL**: how you behave, shown through a real story
  - **CO**: what you know about the company. No CO questions here, because no company research ran (see Sources)
- **Provenance**: `[grounded]` rests on what you told me or on the ad, `[inferred]` is derived from your own self-rating, and `[generic]` is a common pattern for admin roles, not a fact about this employer.
- **Answer slots** are instructions for the interview. Each one gives you two honest branches. Pick the branch that's true for you.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as given in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material describes an appointment book for four physios. It does not describe calendars for colleagues or managers, so keep your words to what you did: "I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a probe on clashes and changes likely. If moving or rebooking appointments between the physios was part of running the book, say how you handled it, in your own words. If it wasn't, say so plainly and stay with the book you ran |
| F2 | "booking travel" — the ad, as given in your message | none given | none | [grounded] | discovery | Strong evidence here would be a time you booked trips, transport or accommodation for someone else and kept the details straight. Answer slot: if you have booked travel for other people, at work or elsewhere, say what and how, in your own words. If you haven't, say so plainly and describe how you would handle a first booking, as a plan |
| F3 | "processing supplier invoices" — the ad, as given in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material describes chasing unpaid invoices. It does not describe processing invoices from suppliers, so keep your words to what you did: "I chased unpaid invoices." Answer slot: the ad's supplier-invoice line makes a probe on checking, recording or approving invoices likely. If any of that was part of your work, say what, in your own words. If none of it was, say so plainly and stay with the chasing you did |
| F4 | "preparing documents in Word and Excel" (the Word part) — the ad, as given in your message | "I'm good with Word" — your message | low | [inferred] | discovery | This is a self-rating, not a document you described. The bridge is inferred from that rating. Answer slot: if you prepared letters, forms or other documents in Word at the clinic, say which ones. If you didn't, say so plainly and say what you're comfortable doing in Word |
| F5 | "preparing documents in Word and Excel" (the Excel part) — the ad, as given in your message | "okay with Excel" — your message | low | [inferred] | discovery | Your own rating is "okay", and that is the word to keep. Answer slot: if you have used Excel for lists, totals or tracking, say what for. If you haven't, say so plainly, then say what you are doing to get quicker, as a plan, never as something you have already done |
| F6 | "Remote Administrative Assistant" (role title) — the invite | "two years as a receptionist at a physiotherapy clinic" — your message | medium | [grounded] | transferability | Your title was receptionist, and it stays receptionist: "I spent two years as a receptionist at a physiotherapy clinic." Leave it to the interviewer to connect that to admin work. Don't rename the job |

## Persona table

The invite sets out the loop: one 30-minute video call with the office manager. No fallback pattern was needed. No values round is named, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "What would you do if…" problems taken from the listed duties | High. An office manager hiring for calendars, travel, documents and invoices will probably test the duties directly. These are hiring-manager priors, reweighted if you tell me who they are | Clarify, then structure, then answer. Say the steps out loud. Make no claim about your past that the case doesn't need |
| Skeptic | Quiet probing of the gaps: travel (F2), supplier invoices (F3), Excel (F5) | High. Your material is thinnest on these rows, and they are listed duties | Rehearse B1 until it bores you. Keep to what you stated, and say any plan as a plan |
| Conversational | "Tell me about yourself", "why admin", "why remote" | Medium. A 30-minute call usually opens warm, but the friendly questions are still scored | A pre-built 90-second arc from F6, F1 and F3 |
| Data-Driven Prober | "Walk me through how you ran the book" | Low to medium. Your experience has no numbers to defend, so probes go to how you did things | Know what you did, step by step, and say plainly what you don't remember |
| Pressure | Time-boxed challenges such as "why you over an experienced admin?" | Low. Unlikely in a short admin call, so two questions as insurance | Pause, restate the question, hold on what you did, and concede the title openly |
| Values / Behavioral | "Tell me about a time…" | Low. No values round is named | Selection scaffolds with honest branches |
| Peer Evaluator | "How would you work with the team remotely?" | Low. A peer could still join the call | Reciprocity: say what you'd bring, not only what you'd need |

## Question banks

There is no F bank, so question IDs never clash with the fit-snapshot rows F1 to F6.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people you support both want the same slot tomorrow morning. What do you do?" | CASE | [generic] | Clarify which meeting is fixed and who decides priority. Ask that person, or follow the rule if there is one. Offer the other person alternatives. Confirm the change in writing and update both calendars. The question needs no claim about your past, so don't make one | Tests the calendar duty (F1's requirement) as a live problem. CASE because it scores how you structure, not your history |
| A2 | "A supplier invoice arrives that doesn't match what we ordered. What do you do?" | CASE | [generic] | Hold it rather than pass it for payment. Check it against the order and the delivery. Contact the supplier about the difference. Tell whoever approves payments, and keep a note of what was agreed. Make no claim about having done this before | F3's requirement asked as a decision. CASE because it scores judgment on a problem the ad names |
| A3 | "You need to book a two-day trip for a manager at short notice. What do you need to know first?" | CASE | [generic] | Dates and times, budget or travel policy, preferences, any documents they need. Then book, put the whole itinerary in one place and confirm it with them. Clarifying first is the point of the question | F2 is a gap with no evidence, so the honest way to show ability is structure. CASE delivery for JD content |
| A4 | "We need a simple Excel list of invoices due this month. How would you set it up?" | CASE | [generic] | Columns for supplier, invoice number, amount, due date and status. Sort by due date and total the amount column. If you'd need to look up how to do something, say so, which is better than guessing | Tests F5's requirement without asking you to overstate. CASE because it's a live task |
| A5 | "Working remotely, you spot a double booking in a manager's calendar and can't reach them. What do you do?" | CASE | [generic] | Don't cancel anything on your own. Message them where they'll see it soonest, warn the other parties that the time may move, and offer options. Fix it as soon as they reply | The role title says remote. Tests calendar judgment when you can't simply walk over and ask |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is reception. Have you processed supplier invoices?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic"; "chased unpaid invoices" | **The highest-ROI rehearsal in this pack.** Hold only what your words carry: "I spent two years as a receptionist at a physiotherapy clinic, and I chased unpaid invoices." Answer slot: if checking, recording or approving invoices was any part of your work, say which part, in your own words. If none was, say so plainly. The honest branch is a limit, not a confession. Then add how you'd learn the supplier side, said as a plan. Through two follow-ups, keep coming back to the chasing. Never add processing work | F3 is where a listed duty meets the widest gap in your material, so some version of this is very likely. JD because it scores a stated duty |
| B2 | "Booking travel is part of this job. Have you done it before?" | JD | [grounded] | Answer slot: if you have booked travel for anyone, say what and how. If you haven't, say so plainly and walk through how you'd approach it, using A3's structure. Make no claim beyond that | F2 has no evidence. The answer is ready before the question comes |
| B3 | "How good is your Excel, honestly?" | JD | [inferred] "okay with Excel" | Give your own word: "okay with Excel". Answer slot: if you've used it for lists, totals or tracking, say what for. If you haven't, say so plainly. Then give a plan to get quicker, as a plan. Don't upgrade "okay" under pressure | F5 is a self-rating, and an interviewer may test it live. Saying the honest level first protects you if they do |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "okay with Excel" | Pick the one that's truest. Your own rating, "okay with Excel", is one candidate, and travel booking is another (the pack notes your material is silent there). Name one, then give the plan. Keep it to one, said calmly | Skeptic stem. Tests honest self-assessment. JD because the answer has to be one of the listed duties |
| B5 | "What kinds of documents have you prepared in Word?" | JD | [inferred] "I'm good with Word" | Answer slot: if you prepared letters, forms, notices or other documents at the clinic, name them in your own words. If not, say so plainly and say what you can do in Word. Don't describe any document you didn't make | F4 is a self-rating with no document behind it. This is the probe that tests it |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc in three beats from your own sentences: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices. Close with why you want this role, in your own words | Almost certainly the opener. F6, F1 and F3 are your strongest rows |
| C2 | "Why move from reception into an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot: say your real reason in your own words. Point to the parts of the clinic job you want more of, and keep any reason for leaving short and neutral | Motivation is scored in a friendly tone. F6 is the frame |
| C3 | "What appeals to you about working remotely?" | EXP | [generic] | Selection scaffold: give a real reason it suits how you work. If you haven't worked remotely before, say so plainly and say how you'd keep yourself organised and reachable | The role title says remote. Your material says nothing about remote work, so this is a scaffold, not a story |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Beats from your sentence: the book and the four physios. Answer slot: if you used a booking system, name it. If it was paper, or you don't remember the details, say so. If changes and cancellations were part of it, say how you handled them. If they weren't, stay with the book | F1 is your closest match to calendar work, so it is where detail gets tested |
| D2 | "When you chased unpaid invoices, how did you go about it?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: say how you did it, in your own words. If you kept track of who owed what, say how. If you didn't, say so plainly and describe the chasing itself | F3 needs to survive a "how" question before it can support B1 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty seconds: why you over someone who has already been an admin assistant?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | Pause. Hold on what you did: two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, and chasing unpaid invoices. Concede the title openly ("my title was receptionist") and don't apologise for it | A pressure stem. It checks whether you'll quietly rename your job (see the prohibited list) |
| E2 | "Chasing invoices isn't the same as processing them, is it?" | JD | [grounded] "chased unpaid invoices" | Agree that they're different. Hold on what you did, "I chased unpaid invoices", and go no further. Through a second follow-up, add only the plan for learning the supplier side | B1 again, in a harder tone. Holding on your real words under pressure is the skill being scored |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a patient or customer ahead of getting through your list." | VAL | [generic] | Selection scaffold: pick a real moment with a person, a pressure and a choice you made. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A persona stem, insurance for a values question |
| G2 | "Tell me about a time you had to give someone a message they didn't want to hear." | VAL | [grounded] "chased unpaid invoices" | Selection scaffold: if a time you chased an unpaid invoice fits, use it and tell only what happened. If none fits, pick another real moment. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A persona stem. F3 may carry a story, but only if a real moment fits |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "We'll be working remotely. How would you keep me updated without flooding me?" | CASE | [generic] | Propose a principle: agree a channel and a rhythm up front, batch the routine updates, flag urgent items straight away. Then ask what they prefer | Tests partnership in a remote role. CASE because there's no past to presuppose |
| H2 | "What would you need from the team in your first month?" | CASE | [generic] | Access and a walkthrough of how calendars, travel and invoices are handled now, plus one person to ask. Then add what you'd hand back, such as tidy notes on how things are done | A reciprocity question. Tests whether the hire adds to the team's load or reduces it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "managing calendars" | A1, A5, D1, C1 |
| "booking travel" | A3, B2 |
| "preparing documents in Word and Excel" (Word) | B5 |
| "preparing documents in Word and Excel" (Excel) | A4, B3 |
| "processing supplier invoices" | A2, B1, E2, D2 |
| "Remote Administrative Assistant" | A5, C3, H1 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "Whose calendars would I be managing, and how do they like changes handled?" | Shows you're already thinking about the calendar duty from the other person's side |
| "Which tools do you use for calendars, documents and invoices?" | Tells you what to brush up on before you start, which is especially useful given F5 |
| "How do supplier invoices move from arriving to being paid here, and what part would be mine?" | Turns your biggest gap (F3) into a learning question rather than a weakness |
| "What would a good first three months look like in this role?" | Gives you their success criteria in their own words |
| "How does the team stay in touch day to day when everyone's remote?" | Shows you've thought about the practical side of remote work |
| "What are the next steps in the process after this call?" | Prepares you for what comes next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for managers or a business | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The pack notes that your material describes an appointment book, not managers' calendars. D1's slot stays inside the book |
| Processed supplier invoices, or handled accounts payable | Inflated form of F3 | F3's quote at its own scope: "I chased unpaid invoices." The pack notes that your material describes chasing unpaid invoices, not processing supplier invoices. B1's slot stays inside what you did |
| Strong or advanced Excel | Inflated form of F5 | Your own word: "okay with Excel" |
| Two years as an administrative assistant | Inflated form of F6 (the title) | "two years as a receptionist at a physiotherapy clinic" |

## Sources

- **Provided:** your message, including the invite text, your summary of the ad's duties and your background.
- **Searches sent:** `values "Brennock Facilities Ltd"`, refused. `recent news "Brennock Facilities"`, refused. `remote administrative assistant job description calendar management travel booking supplier invoices Word Excel`, refused.
- **Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The search was refused. A values page would have themed G1 and G2 on the company's own values instead of generic prompts |
| 2. `{company} interview process {role family}` | skipped | The invite sets out the loop (a 30-minute video call with the office manager), which fixes the persona weights |
| 3. `{company} strategy` / recent news | unavailable | The search was refused. Recent news would have supported at least one CO question and one company-specific case |
| 4. `{interviewer name} {company}` | n/a | No name was given. The invite says only "our office manager" |
| 5. representative `{role title}` JD | unavailable | The search was refused. A full representative posting would have checked the requirement list beyond your four-duty summary |

## Upgrade menu

- The full ad text → F1 to F5 quote the posting itself instead of your summary, and any duty or requirement it lists that the summary leaves out gets a row and a question
- Whether the office manager would be your direct manager → persona weights reweighted and one reverse question tailored to them
- The office manager's name → reverse questions tailored to their background
- Search permission for this session → targets 1, 3 and 5 run: company values for G1 and G2, a CO question, and a representative posting for the requirement list. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow on request
- Telling me outside a drill whether you've booked travel, prepared documents in Word, or what you've used Excel for → F2, F4 and F5 and questions B2, B3, B5 and A4 move from answer slots to your own stories
- A tuesday-dossier.md from an earlier assessment → verified evidence and a prohibited list carried in, rather than built here from your message alone
