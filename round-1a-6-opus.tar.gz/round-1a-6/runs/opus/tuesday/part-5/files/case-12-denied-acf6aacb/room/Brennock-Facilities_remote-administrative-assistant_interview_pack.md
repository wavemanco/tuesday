# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** a 30-minute video call with the office manager. The pack treats this as a hiring-manager round, because your material doesn't say whether the office manager would be your manager.

## How to use this pack

- **Personas** describe *how* a question is asked: friendly, sceptical, under time pressure. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: values and behaviour, meaning how you have acted in real situations
  - **EXP**: deep-dive on your work experience, meaning what you actually did
  - **JD**: the listed duties, meaning whether you can do this job, gaps included
  - **CO**: company knowledge (none in this pack, because no company research could run)
  - **CASE**: a live problem from the job, worked through out loud
- The guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as relayed in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios. It doesn't say other people's calendars in an office, and your words should stay at that scope: "I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a probe on how you kept the book likely. If you handled changes, clashes or cancellations, say how, in your own words. If that wasn't part of it, say so plainly and stay with the book you ran |
| F2 | "booking travel" — the ad, as relayed in your message | none given | none | [grounded] | discovery | Strong evidence here would be travel you booked for someone else, with dates, budget and the details sorted. Answer slot: if you've booked travel for anyone, at work or otherwise, say for whom and how, in your own words. If you haven't, say so plainly and walk through how you would approach it (A2) |
| F3 | "preparing documents in Word and Excel" (the Word part) — the ad, as relayed in your message | "I'm good with Word" — your message | low | [inferred] | discovery | A self-rating with no document behind it, so expect a probe. Answer slot: if you prepared documents in Word at the clinic or elsewhere, say what kind, in your own words. If you didn't, say so plainly and say what you can do in Word |
| F4 | "preparing documents in Word and Excel" (the Excel part) — the ad, as relayed in your message | "okay with Excel" — your message | low | [inferred] | discovery | Your own words set the level, and they stay there: "I'm okay with Excel." Answer slot: if you've used Excel for anything, say what you did in it, in your own words. If not much, say so plainly. Any plan to improve is said as a plan, never as something already done |
| F5 | "processing supplier invoices" — the ad, as relayed in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices. Those sit on different sides of the money: one is collecting what is owed, the other is handling what the company owes. Your words stay at their scope: "I chased unpaid invoices." Answer slot: if any of that work involved checking, logging or entering invoices, say what, in your own words. If it didn't, say so plainly and stay with the chasing |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | discovery | Strong evidence would be time spent working on your own without people around you. Answer slot: if you've worked or studied remotely, say how you kept organised, in your own words. If you haven't, say so plainly and describe how you would set up your day (A5) |

Background used across the pack: "two years as a receptionist at a physiotherapy clinic" — your message.

## Requirement coverage

| Requirement | Questions |
|---|---|
| Managing calendars (F1) | A1, D1, E1 |
| Booking travel (F2) | A2, B4 |
| Word documents (F3) | C2 |
| Excel documents (F4) | A4, B2, F2 |
| Supplier invoices (F5) | A3, B1, D2 |
| Remote working (F6) | A5, G1 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "What would you do if…" problems taken from the duties | High. An office manager hiring an assistant wants to see how you'd handle the actual work | Clarify first, then give your steps in order, out loud |
| Skeptic | Quiet probing of the invoice, travel and Excel gaps | High. F2, F4 and F5 are the visible gaps | Rehearse B1 until it's boring. Bridge only from what you stated, and say the limit plainly |
| Conversational | "Tell me about yourself", friendly openers | Medium. In a 30-minute call this is likely to open things | A 90-second arc built from your own sentences (C1) |
| Data-Driven Prober | "How many, how often" on the appointment book | Low to medium. Your material carries one number, the four physios | Know what you can say about that book, and say plainly what you don't know |
| Values / Behavioral | "Tell me about a time…" | Low. Nothing found names a values round | Pick real instances, or say plainly that none comes to mind |
| Pressure | Time-boxed "why you" questions, challenges on Excel | Low. Less common in short admin calls, but cheap to rehearse | Pause, hold your position through two follow-ups, then concede specifically |
| Peer Evaluator | "How would you work with the team remotely?" | Low. A single interviewer, but remote teamwork is part of the role | Talk about what you bring as well as what you need |

These weights come from typical hiring-manager rounds, not from anything documented about this company's process.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people you support both want the same Tuesday morning slot for a meeting that can't move. What do you do?" | CASE | [generic] | Structure: find out which meeting is fixed and why, check who decides priority, offer each person alternatives, confirm the outcome in writing, and update the calendar straight away. The question needs no claim about your past, so the answer makes none | A live problem from the calendar duty (F1's requirement). CASE because it scores reasoning, not record |
| A2 | "You need to book a two-day trip for a manager on a tight budget. Talk me through it." | JD | [generic] | Steps: confirm dates, times and any preferences, check the budget or travel policy, compare a few options, get approval before paying, then send one clear itinerary with everything in it. It makes no claim about your past | Covers booking travel (F2's requirement), where your material is silent. JD content, CASE delivery |
| A3 | "A supplier invoice arrives that doesn't match what was ordered. What do you do?" | CASE | [generic] | Structure: check it against what was ordered and received, don't send it for payment yet, contact the supplier with the specific mismatch, tell whoever approves invoices, and note what happened. It makes no claim about your past | The invoice duty (F5's requirement) asked as a decision. The answer shows care with money even without supplier-side experience |
| A4 | "You're asked to turn a messy list of payments into a summary in Excel by end of day. How would you go about it?" | CASE | [generic] | Structure: ask what the summary is for and who reads it, tidy the list, sort and filter it, add totals, then check the totals against the original. Name only functions you can actually use. If a tool they mention is new to you, say so plainly | Tests the Excel duty (F4's requirement) live. Better rehearsed now than met cold |
| A5 | "It's your first week, you're remote, and three urgent requests land at once from different people. How do you prioritise?" | CASE | [generic] | Structure: acknowledge each request quickly, ask about deadlines where they're unclear, order by deadline and impact, tell people when to expect their piece, and flag early if something can't be done in time | Remote working and juggling requests (F6's requirement) |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role processes supplier invoices. What experience do you have with that?" | JD | [grounded] "chased unpaid invoices" "two years as a receptionist at a physiotherapy clinic" | **Highest-ROI prep in this pack.** Hold only to what your words carry: at the physio clinic, you chased unpaid invoices. Name the limit before they do: chasing what's owed isn't the same as processing what the company owes. Answer slot: if any of your invoice work involved checking, logging or entering invoices, say what, in your own words. If it didn't, say so plainly and stay with the chasing. If they press ("so you haven't processed supplier invoices?"), go back to what you did, then say plainly what you haven't done, and say how you'd learn their process, framed as a plan | F5 is where the role presses hardest on your background, so some form of this question is very likely. JD because it scores a stated duty |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | An honest pick in your own words is stronger than a dodge. If Excel is your answer, your words are "I'm okay with Excel." Then say what you would do to get up to speed, framed as a plan. If another duty is your honest pick, name it instead | The classic Skeptic question. F4 is the gap you named yourself, so the honest answer is ready-made |
| B3 | "You've been a receptionist. Why move into an admin role, and why remote?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Open with the fact: two years as a receptionist at a physiotherapy clinic. Answer slot: give your real reasons for this move and for remote work, in your own words. The pack doesn't supply reasons, because an interviewer can tell borrowed ones | Motivation consistency is the Skeptic's core check. Your reasons aren't in your material, so this is all slot |
| B4 | "I don't see travel booking in your background. How would you handle it?" | JD | [grounded] | Answer slot: if you've booked travel for anyone, say for whom and how. If you haven't, say so plainly, then walk through A2's steps | F2 is silent in your material. Rehearsing it stops a pause on a predictable question |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" | A 90-second arc using only these beats: two years as a receptionist at a physiotherapy clinic, the appointment book you ran for four physios, chasing unpaid invoices, and being good with Word. Answer slot: close with why this role, in your own words | Very likely the opener in a 30-minute call. Scored even though it feels casual |
| C2 | "What do you use Word for, day to day?" | JD | [inferred] "I'm good with Word" | Answer slot: say what you've actually made in Word (letters, forms, anything), in your own words. If it's been light use, say so plainly. Don't name features you don't use | F3's self-rating gets tested by a friendly question. A concrete answer beats an adjective |
| C3 | "What drew you to this role?" | EXP | [generic] | Answer slot: your actual reasons, in your own words, tied to the duties you'd enjoy. Keep it consistent with B3 | Motivation asked warmly. It should match the Skeptic version |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. What did a busy day look like?" | EXP | [grounded] "I ran the appointment book for four physios" | Start from the quote: the book, for four physios. Answer slot: if you know roughly how many appointments a day, say so and how you know. If you don't, say so. Describe a busy day only as it actually was | F1's one number. Probers go a level deeper on any figure |
| D2 | "When you chased unpaid invoices, how did you keep track of who owed what?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you kept a list, a spreadsheet or a system, say which, in your own words. If there was no tracking, or someone else did it, say so plainly and describe how the chasing worked | F5's evidence probed for detail. If any Excel use comes up here, it also feeds F4 |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a scheduling mix-up landed on you. What did you do?" | VAL | [generic] | Selection scaffold: pick a real mix-up with a clear problem, what you did, and how it ended. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Themed on the calendar duty (F1's requirement). Behaviour questions are common even outside named values rounds |
| E2 | "Tell me about a time you had to tell someone something they didn't want to hear." | VAL | [generic] | Selection scaffold: a real moment, what was at stake, how you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behaviour probe on tact and directness, both needed in an admin role |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Thirty seconds: why you over someone with office admin experience?" | JD | [grounded] "I ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" | Pause, then use only these: you ran the appointment book for four physios, you chased unpaid invoices, and you're good with Word. Hold that through a follow-up. Answer slot: if pushed on office experience, say what you've had in your own words. If you've had none, say so plainly, and don't fold on what you did do | Time-boxed "why you" questions test composure. The hold uses only what your material carries |
| F2 | "You said you're only okay with Excel. Isn't that a problem for this job?" | JD | [grounded] "okay with Excel" | Hold calmly: "I'm okay with Excel." Answer slot: say what you've actually done in it. If it's been little, say so plainly. Then concede the specific gap and say how you'd close it, framed as a plan. Don't upgrade "okay" under pressure | F4 is the gap most likely to be pushed. Holding your own word is the whole move |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When you're remote and a colleague isn't replying to something you need, what do you do?" | CASE | [generic] | Structure: check the request was clear, follow up with a specific deadline, try another channel, and flag to the manager if the deadline is at risk. It makes no claim about your past | Remote collaboration (F6's requirement) |
| G2 | "What would you need from the team in your first month?" | CASE | [generic] | Say what would help you learn quickly (access to systems, examples of past documents, who approves what), and pair it with what you'd offer back, like reliability and quick turnaround | Reciprocity framing shows you'd lighten the load, not add to it |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical week look like in this role?" | Shows you're picturing the actual work, and tells you which duties to emphasise |
| "Whose calendars would I be managing, and for how many people?" | Builds on your appointment-book experience and sizes the job |
| "What software do you use for invoices and documents?" | Tells you what to brush up on, and shows you're thinking about getting up to speed quickly |
| "How does the team keep in touch day to day when everyone's remote?" | Signals you've thought about remote working, not just the duties |
| "What would a great first three months look like for this person?" | Gets the real success criteria in the manager's own words |
| "What are the next steps after today's call?" | Helps you plan your preparation for any later stage |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed office calendars or diaries | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says an appointment book, not office calendars |
| Has processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: chasing is the collecting side, not processing |
| Advanced or proficient in Excel | A claim your own quote contradicts, F4 | "okay with Excel" |

## Sources

- Provided: your message, covering the invite text, the ad's duties as you relayed them, and your background.
- Search "Brennock Facilities Ltd values": refused
- Search "Brennock Facilities Ltd interview process administrative assistant": refused
- Search "Brennock Facilities Ltd news": refused
- Loop source: the invite's words "The interview is a 30-minute video call with our office manager." These establish one session and who runs it.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | Refused. Published values would have themed the VAL questions by name |
| 2. Brennock Facilities Ltd interview process | unavailable | Refused. Could have added detail on the process. The invite's words already establish this session |
| 3. Brennock Facilities Ltd strategy and recent news | unavailable | Refused. Would have supported a CO question, so the pack has none |
| 4. Interviewer name | n/a | No name given, only "office manager", so no interviewer read |
| 5. Representative Administrative Assistant JD | skipped | The ad's duties in your message fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1–F5 quote the ad's own wording, and any duties you didn't relay get rows and questions
- Whether the office manager would be your manager → persona weights based on the real relationship rather than an assumption
- The office manager's name → an interviewer read and a reverse question tied to their background
- What you've actually done in Excel and Word, and any travel you've booked → F2, F3 and F4 move from answer slots to story-mapped guidance (C2, D2, B4, F2)
- Permission for web searches → company values, process and news for targets 1–3, and a CO question
- A deeper research pass of up to 6 more searches and 2 more fetches, taking several more minutes → company background and recent context
- How much prep time you have → a prioritised prep schedule
- A tuesday-dossier.md → graded evidence and a prohibited-claims list carried in from earlier work, instead of the locally built one
