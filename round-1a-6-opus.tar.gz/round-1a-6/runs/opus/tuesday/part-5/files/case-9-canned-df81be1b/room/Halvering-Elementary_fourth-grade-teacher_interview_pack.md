# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute panel on Thursday with Principal Dolores Vantongeren (the hiring principal) and two members of the fourth-grade team (your future peers).

## How to use this pack

Two axes. **Personas** describe *how* a question arrives: the principal probing a gap, or a future teammate asking what you'd bring to planning. **Types** describe *what* is being scored:

- **VAL**: whether your past matches the district's *published* beliefs
- **EXP**: whether what your resume says holds up, and what was actually yours
- **JD**: whether you can do the listed job, including its gaps
- **CO**: whether you know the district's current direction
- **CASE**: a live classroom problem, solved out loud

The guidance is scaffolding, not a script. Where it says **answer slot**, the pack doesn't know the answer and won't make one up. Answer it from what actually happened, or say plainly that it didn't happen.

Provenance labels: `[grounded]` traces to your resume, the invite, or a district page listed in Sources. `[inferred]` traces to a typical fourth-grade posting rather than this district's own posting. `[generic]` is a role-family pattern.

## Fit snapshot

Requirements come from the invite, the district's own pages, and a representative posting (`[inferred]`), because no Halvering posting was supplied. The quotes in the Evidence column are the only things this pack says about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met as you stated it, and grades 1–6 covers fourth grade. Say it in its own terms: an Illinois PEL with an Elementary Education endorsement for grades 1–6, active through June 30, 2029. It's medium only because nothing has been inspected yet. HR checks this, not the panel |
| F2 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | The panel will see this from your resume alone. Words: "I haven't taught fourth grade. For six years I've taught third grade, at a public elementary school in Joliet." Then say how you'd get ready, as a plan and never as something you've done. The six years are adjacent, not the same: never "third and fourth are basically the same" |
| F3 | "experience in grades 3 to 5 preferred" — representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade sits inside grades 3 to 5, so the quote meets the typical posting's preference as written. Lead with the six years. It's `[inferred]` because this is a typical posting, not Halvering's |
| F4 | "Panels ask about reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | none | Your strongest row, and the district has just committed to a new grades 3–5 reading curriculum (Sources). Keep both quotes at their own scope: you led the grade level's move, and you ran the club. Answer slot: a probe on what leading the move involved is likely. If you made particular decisions, say which, in your own words. If the curriculum was chosen above you, or parts were others', say so plainly and stay with leading the grade level's move |
| F5 | "plan and teach reading, writing, math, science and social studies" — representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material doesn't say which subjects you taught. Answer slot: if you've taught all of these subjects, say so and name the one you're strongest in. If some weren't yours, for example because of departmentalized teaching, say so plainly and say how you'd prepare |
| F6 | "differentiate instruction using assessment data" — representative posting | none given | none | [inferred] | discovery | Your material doesn't show this. Answer slot: if you've used assessment results to group or adjust teaching, say what you used and what you changed, in your own words. If you haven't, say so and say how you'd start. This district's belief is that "assessments inform teaching and never replace it" (values page), so match your answer to that framing |
| F7 | "classroom routines" — district hiring page | none given | none | [grounded] | discovery | The district says panels ask about this, and your material says nothing about it. Answer slot: describe routines you've actually run, in your own words. If you'd be designing fourth-grade routines fresh, say so and walk through what you'd set up |
| F8 | "how you work with families" — district hiring page | "I write a weekly email to families." — your CV | medium | [grounded] | none | A named, regular practice: "Every week I write an email to families." Keep it at that: an email, weekly, to families |
| F9 | "each teacher speaks with every family each term" — district values page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Writing is not speaking, and the bridge shouldn't be stretched. Words: the weekly email. Answer slot: if you've spoken with families directly, through conferences or calls, say how, in your own words. If your contact has mostly been the email, say so plainly and say how you'd reach every family each term |
| F10 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your CV | medium | [inferred] | none | The quote shows work across a grade level. The limit is yours and stays visible: "I haven't been a team lead." Never let "led the move" become "led the team" |

## Reading the interviewer

Only what was found publicly (Sources: a principals' forum speaker page, read from a search result).

- **Career pattern:** principal of Halvering Elementary since 2022, after nine years as a reading specialist.
- **Published theme:** her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5.
- **Practical implications:**
  1. Expect reading instruction questions to go deeper than usual. A former reading specialist will hear the difference between a described practice and a borrowed term.
  2. Small groups and conferring are likely topics (D2, B1). Talk about them only as far as they were really part of your teaching. Where they weren't, say so and describe what you'd do.
  3. Grades 3 to 5 is her stated focus, which includes your six years. Your third-grade reading work is in her territory, so describe it precisely rather than broadly.
- **Mirror opportunities:** none offered. Your material carries no career move like hers (specialist to principal), and the pack won't invent one.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | The principal, and possibly the teachers, on the one visible gap: no fourth-grade experience | High. A panel blends each member's top personas. The hiring principal's include Skeptic, and F2 is visible from the resume alone | Rehearse A1 until it's boring: the plain acknowledgment, the six years, a plan. No bluffing |
| B. Case / Strategist | The principal sets live classroom problems: a struggling reader in October, the first week's routines | High. It's the principal's other top persona. The district's hiring page says panels ask about reading, routines and families, which all suit live problems | Clarify, then structure, then answer. Think aloud and use the district's own words ("Every Child a Reader") |
| C. Peer Evaluator | The two fourth-grade teachers ask what you'd bring to planning and how you work with colleagues | High. Two of the three panelists are your future peers | Answer with what you'd bring and what you'd need. Keep the curriculum move at its own scope |
| D. Data-Driven Prober | Teachers or the principal ask how you knew something worked and what assessments you used | Mid. It's the peers' second persona, raised by the principal's reading-specialist background | Say what you actually looked at. Where nothing was measured, say so. Supply no figures you didn't count |
| E. Values / Behavioral | Questions themed on the district's three beliefs | Mid. The district says these beliefs "guide every hire", but no source names a separate values round | One honest story per belief where you have one. Where you don't, say so and give the nearest real thing |
| F. Conversational | The warm opener, "tell us about yourself", and "why here?" | Low, but certain to appear once, and still scored | A rehearsed 90-second arc built only from your resume lines |
| G. Pressure | A time-boxed "why you over someone with fourth-grade experience?" | Low. Nothing suggests a stress format, but F2 makes this version possible | Pause, hold your position through two follow-ups, then concede the specific limit |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. Why should we put you in a fourth-grade classroom?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | **The highest-ROI prep in this pack.** State the limit before they press: "I haven't taught fourth grade. For six years I've taught third grade, at a public elementary school in Joliet." Then a plan, said as a plan: how you'd learn the fourth-grade curriculum and pacing before day one. Answer slot: a follow-up on the fourth-grade content is likely. If you've already looked at fourth-grade standards or materials, say what you looked at, in your own words. If you haven't yet, say so plainly and say when you would. Hold through two follow-ups by returning to the six years, never by adding to them. Concede plainly: "There'll be content I'm teaching for the first time." | F2 is the one gap the panel can see from the resume itself, so it will come in some form. JD because it scores the role as titled |
| A2 | "Which part of the fourth-grade job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Answer slot: name the part of fourth grade you'd really be newest to, whether that's a subject, the content, or something else, and say what you'd do first to close it, as a plan. If no single part stands out, say that the fourth-grade content as a whole is new to you, which your own line supports. Don't name a weakness you don't believe | Skeptic stem aimed at F2 and F5. JD because it tests the listed subjects |
| A3 | "Have you led a team of teachers before?" | EXP | [grounded] "I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" | Both of your lines, in order: "I haven't been a team lead. In 2024 I led our grade level's move to a new reading curriculum." Answer slot: if they ask what leading the move meant, say what you did, in your own words. If others decided parts of it, such as an administrator or the district, say so plainly | F10 puts these two lines side by side, so a panel will ask how they fit. EXP because it tests attribution |
| A4 | "You email families every week. Our district expects every teacher to speak with every family each term. Have you done that?" | JD | [grounded] "I write a weekly email to families." | Start with the email in its own words. Answer slot: if you've had direct conversations with families, say how, in your own words. If your contact has mostly been the email, say so plainly and describe how you'd plan to reach every family each term. Never turn the email into conversations | F9's thin bridge, rehearsed so the honest answer is ready. The premise is the district's own values page |
| A5 | "What changes for kids between third and fourth grade, and what will you have to change?" | CASE | [generic] | Structure it: what students bring in, what fourth grade asks more of them, the routines you'd set in week one, and how you'd check in by October. The question needs no claim about your past, so the guidance makes none | A live version of F2 asked as a problem, not a record. `[generic]` because it's a pattern, not a fact about Halvering |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's October. Five of your fourth graders are reading well below grade level. What do you do?" | CASE | [grounded] | Clarify first: what assessment showed it? Then structure it: find out what each child needs, group them, plan the teaching, involve families, and set a date to check again. Use the district's framing: "assessments inform teaching and never replace it." No claim about your past is needed | Ties to "Every Child a Reader" and to the principal's published focus on small groups. `[grounded]` on the values page and the interviewer's talk |
| B2 | "The district is bringing in a new grades 3–5 reading curriculum in fall 2027. You led a curriculum move in 2024. What should we know?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start with your line: you led your grade level's move to a new reading curriculum in 2024. Answer slot: expect "what was hard, and what would you do differently?" If something was hard, say what it was and what part was yours, in your own words. If you don't know how it landed with students, say so plainly and stay with the move itself. Don't describe the district's plan beyond what's public | The differentiator question. It connects F4 to the district's adopted literacy plan (Sources). CO because it tests whether you know where the district is going |
| B3 | "Sketch a fourth-grade literacy block for us: what happens, in what order, and why?" | CASE | [inferred] | Structure it: whole-group teaching, small groups or conferring, independent reading and writing, and a quick check for understanding. Give a reason for the order. This is a plan, not a description of your past classroom | The typical posting lists reading and writing, and the principal's background makes this likely. `[inferred]` from the representative posting |
| B4 | "How would you use assessment data to differentiate a fourth-grade math lesson?" | CASE | [inferred] | Structure it: which check you'd use, how you'd group, what each group does, and when you'd regroup. Close with the district's line that assessments inform teaching. A plan, not a claim | Covers F5 and F6. The math angle makes sure a non-reading subject is rehearsed. `[inferred]` from the representative posting |
| B5 | "What would we see in your classroom in the first week of school?" | CASE | [grounded] | Routines, in order: arrival, transitions, materials, getting help, and dismissal. Say how you'd teach and practise each one. Answer slot: if a routine is one you've actually run, say so in your own words. If you'd be designing it fresh for fourth grade, say that | The district's hiring page says panels ask about classroom routines (F7). CASE because it's set in the future |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us how you brought your grade level through the curriculum change. What happened when someone wasn't on board?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats your line states: the grade level, the new reading curriculum, 2024, and that you led the move. Answer slot: if a colleague disagreed, say what happened and what part you played, in your own words. If nobody pushed back, or handling it wasn't yours, say so plainly and stay with the move | Future teammates will want to know how you work with equals (F4, F10). EXP because it tests what was yours |
| C2 | "We plan together. What would you bring to our planning, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | What you'd bring, at the scope of your lines: experience leading a grade-level curriculum move, and two years running a reading club. What you'd need: fourth-grade pacing, shared materials, and how they assess. Make the second half just as real as the first | F10 from the peers' side. JD because it scores working with the grade-level team |
| C3 | "When you disagree with a colleague about how to teach something, what do you do?" | EXP | [generic] | Selection scaffold: choose a real disagreement with a peer where you held your view and the working relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you'd handle it | Peer persona stem. Nothing in your material speaks to it, so this is a scaffold rather than a story |
| C4 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | The beats: you ran it, after school, for the last two years. Answer slot: if you shaped what the club does, such as who comes or what they read, say how, in your own words. If its format was set before you, say so. Don't commit to starting one here unless you'd want to | F4's second quote. Teachers ask about extras because extras affect their own load. EXP |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you looked at student results or other signs, say what you looked at, and the assumption behind it you'd defend least. If it wasn't measured, or you don't know how it was measured, say so plainly. Never give a figure you didn't count | F4 under a reading specialist's lens. EXP because it tests what you can stand behind |
| D2 | "What do you use to decide who goes in which reading group?" | EXP | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: if you've grouped readers using assessments or conferences, say what you used and how often you regrouped, in your own words. If grouping wasn't part of how you taught, say so plainly and describe what you'd do in fourth grade | The principal's talk on small groups and the typical posting's differentiation line raise this (F6). The premise is theirs, so the slot lets it be false |
| D3 | "How many kids come to the reading club, and what's changed for them?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Answer slot: if you know the numbers, give them as you counted them. If you've seen a change in students, say what you saw and what else could explain it. If you haven't tracked it, say so plainly | F4's club line is a magnet for "how many?" EXP |

### E. Values / Behavioral (the district's three beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader. Tell us about a time you got a struggling reader moving." | VAL | [grounded] | Selection scaffold: a specific child (no names), what you noticed, what you changed, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you'd handle it | District belief 1, from the values page. A scaffold, because none of your lines carries a single-student story |
| E2 | "Families Are Partners. Tell us about a time a family relationship took real work." | VAL | [grounded] "I write a weekly email to families." | You can mention the weekly email as context. For the story itself, choose a real situation where you and a family worked through something. If none comes to mind, say so plainly and describe how you'd approach it | District belief 2 (F8, F9). The email is context, not the story |
| E3 | "Teach for Tomorrow, Not for the Test. How do you keep testing in its place?" | VAL | [grounded] | Selection scaffold: a time an assessment changed what you taught next, rather than how you taught to it. If none comes to mind, say so plainly and say how you'd use assessments in fourth grade | District belief 3, which the values page defines as "assessments inform teaching and never replace it" (F6) |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc made only from these lines: six years of third grade in Joliet, leading the grade level's move to a new reading curriculum in 2024, running the after-school reading club for two years, and a weekly email to families. Close with why fourth grade. Answer slot: give your actual reason, in your own words | Certain to open the panel. Every clause rests on a quote |
| F2 | "Why Orrinsford, and why Halvering?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name one public thing that connects to you, such as the grades 3–5 reading curriculum coming in fall 2027 alongside your 2024 move, or "Every Child a Reader." Answer slot: your real reason for this district, in your own words | Motivation question. CO because the strongest answers show you've read what the district has published |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a teacher who's already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | Pause. Then: "I haven't taught fourth grade. I've taught third grade for six years, and in 2024 I led our grade level's move to a new reading curriculum." Hold through two follow-ups with those lines. Concede only the real limit, the first year of fourth-grade content. Don't attack the hypothetical rival | A time-boxed version of A1 (F2). Hold-then-concede is the skill being scored |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold your line: you led the grade level's move. Answer slot: say which parts were yours and which belonged to others, such as the district, an administrator or colleagues, in your own words. If the choice of curriculum wasn't yours, say so; the honest branch is a limit, not a confession | The stress stem aimed at F4's strongest claim. EXP because it tests attribution directly |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Illinois PEL, elementary endorsement | — none, because it's a met gate that HR verifies. Say it plainly if asked |
| F2 Fourth-grade role | A1, A2, A5, G1 |
| F3 Grades 3 to 5 experience | A1, F1 |
| F4 Reading instruction | B1, B2, B3, C1, C4, D1, G2 |
| F5 All five subjects | A2, B4 |
| F6 Differentiation with assessment data | B4, D2, E3 |
| F7 Classroom routines | B5, A5 |
| F8 Working with families | A4, E2 |
| F9 Speaking with every family each term | A4, E2 |
| F10 Grade-level team | A3, C2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To the principal) "Your talk on weekly reading conferences in grades 3 to 5: how do fourth-grade teachers here run them day to day?" | It's tied to her published work, and it shows you prepared for *her* |
| R2 | "With the new grades 3–5 reading curriculum coming in fall 2027, how will fourth-grade teachers be involved in the move?" | It shows you know the district's adopted plan, and it opens room to talk about F4 |
| R3 | (To the teachers) "What could a new teammate do in the first month that would genuinely help your team?" | Reciprocity. It shows you think about their load, not just your own needs |
| R4 | "How does the fourth-grade team plan together: shared time, common assessments, or something else?" | It's practical, and it shows you expect to plan with them |
| R5 | "What does 'Families Are Partners' look like in fourth grade here? How do teachers reach every family each term?" | It uses the district's own words and asks about the practice behind A4 |
| R6 | "What do students coming up from third grade most often need at the start of fourth?" | It turns your third-grade background into a shared conversation, without claiming anything |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | "I haven't taught fourth grade." No slot |
| Was a grade-level team lead | A negative you stated, F10 | "I haven't been a team lead." No slot |
| Chose or designed the new reading curriculum, or led its adoption beyond the grade level | An inflated form of F4 | F4's quote at its own scope: you led the grade level's move. Your material says the move, not the choice of curriculum. A3 and G2 keep their slots inside the move |
| Speaks with every family each term | An inflated form of F9 (writing became speaking) | F9's quote: the weekly email. A4's slot asks only whether direct conversations happened |
| Founded or created the reading club | An inflated form of F4's club line | "I've run the after-school reading club for the last two years." C4's slot stays inside running it |

## Sources

Provided: the interview invite and your resume, both pasted. You also included a Social Security number. It isn't needed and wasn't used. Your license number was used in no search.

Searches and fetches:

1. Search "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
2. Fetch of that page: the three beliefs and their definitions
3. Search "Halvering Elementary School Orrinsford" returned no results
4. Search "Dolores Vantongeren principal Halvering Elementary" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (search snippet only, page not fetched)
5. Search "Illinois fourth grade teacher job description elementary school district posting" returned https://k12jobsboard.example/listings/fourth-grade-teacher
6. Fetch of that page: a representative posting, which is the source of every `[inferred]` requirement
7. Search "Orrinsford Community School District teacher interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers (search snippet only)
8. Search "Orrinsford Community School District news 2026" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet only)

Research tier: L1 — searches 6 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | The three beliefs by name: rows F6 and F9, bank E, and A4, B1 and R5. No values cheat sheet, because no source names a separate values round |
| 2. `Orrinsford interview process` | yes | Confirmed the loop (one 45-minute panel: the principal and two grade-level teachers). Its topics (reading, routines, families) became rows F4, F7 and F8 |
| 3. `Orrinsford strategy` / recent news | yes | The 2026–2029 literacy plan with a new grades 3–5 curriculum from fall 2027, used in B2, F2 and R2 |
| 4. `Dolores Vantongeren Halvering` | yes | The interviewer read, Prober weighted up for reading, D2 and R1 |
| 5. Representative fourth-grade teacher posting | yes | The `[inferred]` rows F3, F5, F6 and F10, and B3 and B4 |
| School-name search (outside the declared targets) | yes | No results. Moved nothing |

## Upgrade menu

- Halvering's actual posting text → rows F3, F5, F6 and F10 become `[grounded]` on the district's own words, and any requirement it adds gets its own question
- Your Illinois license record (the ELIS printout is the standard proof in this field) → F1 moves from medium to high. Bring a copy in case HR asks
- How much prep time you have before Thursday → a prioritized prep schedule sized to it
- Any HR guidance (a sample lesson, a writing task, or the panel's focus areas) → a build section for each declared task
- Your answers to the answer slots in F4, F5, F6, F7 and F9 → those rows' guidance becomes story-mapped instead of slot-based
- A tuesday-dossier.md, if you have one → evidence already verified with you and a ready-made prohibited list, instead of the ones inferred here
