# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, a 30-minute phone call, Thursday at 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps"

## How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour against the company's published values
  - **EXP**: whether what you say about your past holds up when she asks more
  - **JD**: the advertised duties, requirements and terms
  - **CO**: knowledge of the company and its strategy
  - **CASE**: a live problem from the role, worked out loud
- **Answer slot** means the pack does not know the answer and will not make one up. It tells you what she may ask and gives you two honest ways to answer it.
- **Logistics slot** means the answer is yours alone (pay, notice, location, why you're leaving). Where you've already told me, the pack hands your own words back to you.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material describes delivery schedules for three depots, not production schedules between planning, a warehouse and QA, so the words stay at that level: "I schedule deliveries for our three depots." Answer slot: because the advert mentions planning, the warehouse and QA, expect a question about working with other teams to keep a schedule on track. If scheduling the depots' deliveries meant agreeing timings with other teams, say which teams and what you did, in your own words. If it didn't, say so plainly and stay with the depot scheduling you do |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | presentation | Your sentence already covers this in different words. The advert says "late orders" and you said orders that slip. Say it the way you said it: "I chase suppliers when orders slip" |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Chasing a slipped order is close to tracking deliveries, but your material doesn't show whether you track them. Answer slot: if you keep track of what suppliers are due to deliver and when, say how, in your own words. If you don't, or someone else does, say so plainly and stay with chasing suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but this figure is what she's most likely to ask about. Keep both halves as you said them: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Keep the word "about". Your sentence puts the two side by side without saying one caused the other, so the pack doesn't say that either. C1 and E2 rehearse this |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material doesn't say either way whether you report on dispatch. Answer slot: if you report on dispatch or delivery performance now, say what goes in the report and how often, in your own words. If you don't, say so plainly and say how you would set up a weekly on-time dispatch report |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Lead with it the way you said it: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | A rebuilt spreadsheet is close to this, but your material doesn't say it was in Excel or what you built in it. Answer slot: if the spreadsheet is in Excel, say what you use in it, in your own words. If it's in another tool, name the tool and say plainly how you would rate your Excel |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | You've said yourself that SAP is a gap. The in-house system is related, but your material doesn't show how similar it is to an ERP or what you do in it. Words: "I haven't used SAP; we run our own in-house stock system." Answer slot: if you work in the in-house system day to day, say what you do in it, in your own words. If you use it only a little, say so plainly. Never call it an ERP, and add nothing to make the SAP gap sound smaller. The advert lists this as a plus, not a requirement |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is inside the advertised range. Give it the way you said it |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised pattern fits within what you said. Give both halves as you said them. The limit of three days is part of your answer, not a footnote |

## Persona table

The session itself is established by Hannah's own message ("a 30-minute phone call with me"), so these weights come from that message and her stated agenda, not from a guessed company pattern.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly phone chat working through her agenda: pay, notice, hybrid, the reason for moving | High. A recruiter screen leans this way, and all four topics she named are logistics asked in a friendly tone. The risk is treating the call as unscored | Have a 90-second answer ready for "what do you do now", and give each logistics answer in your own words, once, cleanly |
| Skeptic | Quiet checks on the advert's requirements: production scheduling, SAP, dispatch reporting | Medium-high. A recruiter screen usually includes a light Skeptic, and F1 and F8 are the two rows a recruiter can check against the advert in one question | Rehearse B1 until it's boring. Stay with what you actually said, state the limit plainly, and give a plan for learning, said as a plan |
| Data-Driven Prober | One follow-up on the figure you're likely to mention | Low. It's a recruiter call, but your one figure (F4) is exactly the kind of thing that gets a "how did you measure that?" | Know what you can and can't say about how the third was counted, and say plainly if you don't know |
| Case / Strategist | A quick "what would you do if…" about a late delivery or a stock mismatch | Low. It isn't on her stated agenda, so these are insurance | Clarify, then structure, then act, then record. Think out loud |
| Pressure / Stress | A quick "why you?" | Low. Nothing in her message suggests it. Two questions so the style isn't new to you | Pause, return to what you said, concede the real gap plainly, hold the rest |

Values/Behavioral and Peer are left out: no values round has been identified, and only Hannah is on the call.

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through what you do at the moment." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, each one a sentence you gave me: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for the three depots and chasing suppliers when orders slip; the stock-count spreadsheet you rebuilt and the fall in discrepancies, with "about" and "over a year" kept. Stop there and let her pick what to ask about | The likely opener. F6, F1, F2 and F4 are the rows it draws on. EXP because she will follow whatever you mention |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, in your words: "I'm hoping for £42,000." If she comes back to it, give the same words again. If she asks what you earn now: "I'd rather focus on the range for this role." | She named salary expectations, so this is certain. F9 is the row. JD because pay is one of the advertised terms |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period. Nothing else needs adding | She named notice period. JD because it settles start timing, one of the job's terms |
| A4 | "How would the hybrid pattern work for you? It's two days a week at Avonmouth." | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, in your words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the journey or about more days, your own words were: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | She named the hybrid pattern. F10 is the row. JD because the office pattern is an advertised term |
| A5 | "And what's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, in your words: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, the same words again, with nothing added | She named it. EXP because she's checking your account of why you're leaving is consistent |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. How does your experience fit that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **The highest-ROI rehearsal in this pack.** Hold on what your sentence says: "I schedule deliveries for our three depots, and I chase suppliers when orders slip." Answer slot: if scheduling the depots' deliveries meant agreeing timings with other teams, say which teams and what you did, in your own words. If it didn't, say so plainly and stay with the depot scheduling. Follow-up one, "but production is different from deliveries": go back to your sentence and add nothing to it. Follow-up two, "so what would you need to learn?": say it as a plan, such as meeting planning, the warehouse and QA early to learn how each one's timings feed the schedule | F1 is the widest gap between the advert's main duty and what you've told me, so some form of this question is likely. JD because it scores the first duty listed |
| B2 | "Have you used SAP, or another ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP; we run our own in-house stock system." Answer slot: if you work in that system day to day, say what you do in it, in your own words. If you use it only a little, say so plainly. Then say how you would learn their system, as a plan. Don't call the in-house system an ERP | F8. A recruiter can tick this off in one question. JD because it's a listed plus |
| B3 | "The role reports weekly on on-time dispatch. Have you done that kind of reporting?" | JD | [grounded] | Answer slot: if you report on dispatch or delivery performance now, say what goes in the report and how often, in your own words. If you don't, say so plainly and say how you would set up a weekly on-time dispatch report | F5 is silent in your material, so have an honest answer ready before she asks. JD because it's a listed duty |
| B4 | "Why Quillmoor, and why this role?" | JD | [generic] | Selection scaffold: pick one or two lines from the advert that genuinely draw you and say why, in your own words. Keep this separate from your reason for moving, which stays as you said it in A5. If nothing specific comes to mind, say so plainly, then say which parts of the advert match the work you want to do | It's the "why here" half of checking that your motivation hangs together. JD because the only source for it is the advert |
| B5 | "How do you keep track of supplier deliveries?" | JD | [inferred] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you keep track of what suppliers are due to deliver and when, say how, in your own words. If you don't, or someone else does, say so plainly and come back to chasing suppliers when orders slip, which is what you've told me | F3. The advert pairs tracking with chasing, and you've told me about the chasing. JD because it scores a listed duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How did you count that?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep "about a third" and "over a year". In your own words, cover: how it was counted; what the number is sensitive to; the assumption behind it you would defend least, said before she asks; and which part was yours. If you don't know how it was counted, say so plainly | F4 holds your only figure, so it's the one that gets probed. EXP because it tests whether the number holds up |
| C2 | "What did you change when you rebuilt the stock-count spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The rebuild is yours, by your own sentence. Answer slot: the advert's line on accurate stock records makes this question likely. Say what you changed, in your own words. If it's hard to put simply, say what the spreadsheet does now | F4 and F7 both rest on this sentence. EXP because it checks what was actually you |
| C3 | "How confident are you with Excel? What do you use it for?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet is in Excel, say what you use in it, in your own words. If it's another tool, name it and say plainly how you would rate your Excel. Don't use labels like "advanced" unless you'd stand behind them in a test | F7. Excel confidence is a listed requirement that your material doesn't settle. JD because it's a stated requirement |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier delivery that a production run depends on is late today. What do you do?" | CASE | [generic] | Structure it: what you'd confirm first (what's late, how late, what it holds up); who you'd tell and when (planning, the warehouse); how you'd chase the supplier for a firm time; what you'd do about today's schedule; what you'd record. The question asks about no past, so the guidance claims none | Built from the advert's lines on chasing late orders and coordinating schedules (F2, F1). [generic] because it's a pattern for the problem, not a fact about Quillmoor |
| D2 | "On-time dispatch dropped this week. How would you work out why?" | CASE | [generic] | Clarify how on-time is measured here; split the misses by cause (stock, picking, carrier, paperwork); look for one cause that dominates; say what you'd change and how you'd report it next week | Built from the weekly-reporting duty (F5) |
| D3 | "The stock record says one number and the count says another. How do you handle it?" | CASE | [generic] | Recount before you correct anything; check movements since the last count; find the cause, not just the difference; correct the record with a note; say what you'd watch for next time | Built from the stock-accuracy duty (F4) |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Quick one: why should we pick you over someone who already knows SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause. Concede the real gap plainly: "I haven't used SAP." Then hold on what you said: four years as a logistics coordinator, scheduling deliveries for three depots and chasing suppliers when orders slip. If pushed twice, keep the same facts and add a plan for learning their system. Don't fold, and don't add anything | F8 against F6 and F1. JD because SAP is a listed plus |
| E2 | "That fall in discrepancies: how much of that was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on "I rebuilt the spreadsheet." Your sentence doesn't say what drove the fall. Answer slot: say which part was yours, in your own words. If other people or other changes played a part, or you don't know, say so plainly. That concession makes you more credible, not less | F4. This is a common pressure question when someone mentions a figure. EXP because it's about attribution |

## Requirement coverage

| Advert requirement or recruiter topic | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA (F1) | B1, D1 |
| Track supplier deliveries (F3) | B5 |
| Chase late orders (F2) | A1, D1 |
| Keep stock records accurate (F4) | C1, C2, D3, E2 |
| Report weekly on on-time dispatch (F5) | B3, D2 |
| 2+ years in operations or logistics coordination (F6) | A1, E1 |
| Confident with Excel (F7) | C3 |
| ERP experience, SAP or similar, a plus (F8) | B2, E1 |
| £38,000–£44,000 (F9) | A2 |
| Hybrid, two days at Avonmouth (F10) | A4 |
| Notice period, from Hannah's agenda | A3 |
| What's prompting a move, from Hannah's agenda | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do planning, the warehouse and QA share the scheduling work, and where does this role sit between them?" | It goes straight at F1 and tells you what you'd be learning in the first weeks |
| R2 | "Which system do you run stock and orders on, and how are new starters trained on it?" | It shows you've thought about F8 practically, and you'll find out what learning it involves |
| R3 | "How is on-time dispatch measured at the moment, and who reads the weekly report?" | It ties to F5 and shows you're thinking about what the report is for |
| R4 | "Are the two Avonmouth days fixed, or chosen week to week?" | Practical, and it keeps the hybrid conversation on how the pattern works |
| R5 | "What would a good first three months look like in this role?" | It gets her to describe success in her own terms, which is useful for the next round |
| R6 | "After this call, what are the next steps, and who would I be meeting?" | She said she'd cover next steps. If she hasn't, this closes the call cleanly and tells you what to prepare next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F1 | F1's own words: "I schedule deliveries for our three depots." The limit is the pack's observation, not words for you: your material describes depot deliveries, not production scheduling. B1's slot stays within the depot scheduling |
| Has used SAP | A gap you stated, F8 | "I haven't used SAP; we run our own in-house stock system." No slot |
| Has ERP experience | Inflated form of F8 | F8's own words: "we run our own in-house stock system." The limit is the pack's observation: your material doesn't show that the system is an ERP. B2's slot asks only what you do in it |
| Cut stock discrepancies by a third with the spreadsheet | Inflated form of F4 | F4's sentence whole, "about" and "over a year" included. The limit is the pack's observation: the sentence puts the rebuild and the fall side by side and doesn't say one caused the other. E2's slot asks which part was yours |
| Advanced or expert Excel user | Inflated form of F7 | F7's sentence: "I rebuilt our stock-count spreadsheet." The limit is the pack's observation: your material doesn't name the tool. C3's slot asks what you use |

## Sources

**Provided:** Hannah Lowther's LinkedIn message (pasted); the Operations Coordinator advert (pasted); your own background and logistics answers (your message). No dossier was present.

**Searches sent (all refused, because search permission wasn't granted in this session):**
- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics interview process operations": refused
- "Quillmoor Diagnostics news Avonmouth": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have themed any values-related questions. No values round was identified, so no values cheat sheet would have followed |
| 2. `Quillmoor Diagnostics interview process operations` | unavailable | The search was refused. Hannah's own message already establishes this session as a 30-minute phone call with her, so the persona weights rest on that. It would have shown what later rounds look like |
| 3. `Quillmoor Diagnostics` strategy / recent news | unavailable | The search was refused. It would have supported a CO question and a sharper answer to B4 |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have given an interviewer read and a reverse question tied to her path |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search, then ask me to rerun → targets 1 to 4 run: an interviewer read, a reverse question tied to Hannah's path, and current company context for B4 and a CO question
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a company strategy brief, recent news about the Avonmouth site and reports of how later rounds run
- Your CV → the snapshot can quote your CV lines alongside your message, and the A1 answer gains any roles or detail the CV carries
- Your answers to the answer slots on dispatch reporting, supplier tracking, Excel and the in-house system → F3, F5, F7 and F8 regenerate from your own words, along with B1, B2, B3, B5, C3 and E2
- A tuesday-dossier.md from an earlier underwriting session → the most likely objection would come from evidence you confirmed rather than be inferred, and a confirmed list of prohibited claims would bind every cell
