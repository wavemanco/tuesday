# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Round:** 45-minute panel interview on Thursday
**Panel:** Principal Dolores Vantongeren (likely your future manager) and two members of the fourth-grade team (your future peers)
**Built from:** your invite, your résumé notes, and a short round of public research (see Sources). No job description was supplied, so job-duty rows come from a representative fourth-grade posting and are marked `[inferred]`.

---

## How to use this pack

- **Personas** describe *how* a question will be asked: who is asking and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: whether your past work lines up with the district's *published* beliefs
  - **EXP**: whether what you say about your past holds up when they dig in, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: whether you know the district's current plans and can think at that level
  - **CASE**: a live classroom problem, solved out loud
- Provenance labels: `[grounded]` traces to your materials, the invite, or research listed in Sources. `[inferred]` comes from a representative posting or a reasonable reading of one. `[generic]` is a common pattern for this kind of role and makes no claim about this school.
- **The guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. Where your material doesn't say something, the cell is an **answer slot**: an instruction with two honest branches for the interview. It is not a question for you to answer here.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap. Your license matches the invite's requirement in its own terms, and grades 1–6 includes fourth grade. It is medium only because nothing has been inspected, so have your license record ready in case HR asks for it. Say it as written: an Illinois PEL with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029 |
| F2 | "experience in grades 3 to 5 preferred" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Your six years of third grade fall inside the 3–5 band this posting prefers. Say it plainly: six years teaching third grade at a public elementary school in Joliet |
| F3 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | You stated this gap yourself, and wording can't close it. Words: "I've never taught fourth grade." Then F2's quote at its own scope, six years of third grade. Then how you would get ready for fourth grade, said as a plan and never as past experience. Don't add anything to make the gap seem smaller |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | transferability | Your material says third grade but not which subjects you taught. Answer slot: if you taught all five subjects, say so and give an example in your own words. If some weren't yours, for example because the schedule was split or shared, say so plainly and stay with what you did teach |
| F5 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Strong evidence here is a specific time when what an assessment showed changed what you taught, and to whom. Answer slot: if you have done this, describe one real case in your own words. If no clear case comes to mind, say so plainly and describe how you would do it |
| F6 | "keep clear classroom routines" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Strong evidence is a routine you could describe step by step and why you set it up that way. Answer slot: describe a routine you actually ran, in your own words. If none stands out, say so and describe the routines you would set up in the first weeks of fourth grade |
| F7 | "communicate regularly with families" — representative posting, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | Your quote meets this directly. Lead with it as written: you write a weekly email to families |
| F8 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | A weekly email is written communication, and the district's belief is about speaking with every family. Keep the quote at its own scope. Answer slot: if you speak with every family by phone, at conferences or in person, say how in your own words. If you don't, say so plainly, stay with the weekly email, and say how you would reach every family each term |
| F9 | "work with the grade-level team" — representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | Your quote is work done with your grade level. Say it in its own words: in 2024 you led your grade level's move to a new reading curriculum. Keep "led" tied to that move only, since you also wrote that you have never been a team lead (see the prohibited list) |
| F10 | "a new grades 3–5 reading curriculum from fall 2027" — Orrinsford literacy plan news item | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Related work, not the same work: a different curriculum, at one grade level, in another district. Answer slot: the district's plan makes it likely they will ask what leading the move involved. Say what you actually did, in your own words. If it was smaller than the word "led" suggests, say so plainly and stay with the move itself |
| F11 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | The club is reading work, but the material doesn't show individual reading plans. Answer slot: if you have written or used reading plans for individual students, say how in your own words. If not, say so plainly and stay with the club you have run for two years |
| F12 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Strong evidence is a time when an assessment result shaped your teaching without becoming the teaching. Answer slot: if you have a case like that, describe it in your own words. If not, say so plainly and describe how you would use assessments in fourth grade |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 license | none. The invite treats the license as a screen and your quote meets it, so there's nothing to rehearse beyond stating it as written |
| F2 grades 3–5 experience | F1q, G1 |
| F3 fourth grade | A1, A2, G1 |
| F4 all five subjects | B3, E3 |
| F5 using assessment data to differentiate | B2, E2 |
| F6 classroom routines | B1 |
| F7 regular family communication | D2, E1 |
| F8 speaking with every family | D2 |
| F9 working with the grade-level team | C1, C2, C4 |
| F10 the 2027 curriculum | B4, C3 |
| F11 Every Child a Reader | D1, E1 |
| F12 assessments inform teaching | D3, E2 |

---

## Reading the interviewer: Principal Dolores Vantongeren

| What the public record says | Practical implication |
|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist (Illinois Principals Forum speaker page) | Expect reading instruction to be where she probes deepest. Her background is in reading, so vague reading answers will stand out |
| Gave a 2025 forum talk, *Small Groups, Big Readers*, on weekly reading conferences in grades 3 to 5 (same page) | Grades 3–5 reading is a theme she has spoken about publicly. One reverse question below asks about it directly. Don't claim a conferencing practice your material doesn't show; ask about hers instead |

Mirror opportunity: shared vocabulary, not a shared career path. Your F10 sentence, "I led our grade level's move to a new reading curriculum in 2024", is reading-curriculum work, which is her field. Let her draw the connection; don't say it for her.

The two team members are unnamed, so they fall back to the usual peer pattern (below).

---

## Persona table

The invite sets the format: one panel, one principal, two fourth-grade teachers. For a panel, the playbook blends the top personas for each member's relationship to you.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | "You've taught third, not fourth." Probes on the gap and on motivation | **Highest.** The principal is your likely manager and needs to reduce the risk of F3, the one gap you stated. Fourth-grade teachers will feel it too | Rehearse A1 until it's boring. Give F3's plain acknowledgment, then F2 at its own scope, then a concrete plan |
| B. Case / Strategist | "It's week one. Walk us through your routines." Live classroom problems | **High.** Managers hire for what you can do, and F5 and F6 have no quotes, so they will be tested live | Clarify first, then structure: goal, students, approach, how you'll know it worked, risks. Think out loud |
| C. Peer Evaluator | "How would you plan with us? What do you do when you disagree?" | **High.** Two of the three panelists will share planning with whoever is hired | Say what you'd bring to their team, not only what you need. Suggest principles for working together instead of pretending to know their routines |
| D. Values / Behavioral | Questions themed on the district's three published beliefs | **Medium.** The invite names no values round, but the district's beliefs page says the beliefs "guide every hire" | Map each answer to a quoted sentence where one exists. Where none does, use the scaffold and its honest branch |
| E. Data-Driven Prober | "How many kids in the club? What's in the weekly email? How did you know it worked?" | **Medium.** Teachers who read your materials closely will push on F11, F7 and F5 | Say what you know and plainly what you don't. Supply no numbers you didn't give |
| F. Conversational | "So, tell us about yourself." The friendly opener | **Low, but certain to appear.** Nearly every panel opens this way | Prepare a 90-second answer built only from your quoted sentences |
| G. Pressure | "Sixty seconds: why you over someone who's taught fourth?" | **Low.** Elementary panels rarely go hard on pressure, but a time-boxed version of A1 is plausible | Pause, restate, hold through two follow-ups, then concede the specific thing that's true |

---

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've told us you haven't taught fourth grade. What makes you ready for it?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | **The highest-ROI rehearsal in this pack.** Name the limit before they press: "I've never taught fourth grade." Then hold only what the second quote carries: six years teaching third grade at a public elementary school in Joliet. Then give your plan, stated as a plan: what you would study about the fourth-grade curriculum and how you would learn it from the team before and during the first weeks. Through two follow-ups, return to the six years and the plan. Never hint at fourth-grade experience you don't have, and don't apologize: it's a limit, not a confession | F3 is the one gap you stated, and every panelist will notice it, so some version of this question is close to certain. JD because it scores the role in the invite's title |
| A2 | "Why fourth grade, and why Halvering?" | EXP | [generic] | Your material gives no reason, so this is an answer slot: give your actual reason in your own words. If part of it is the move from third grade to fourth, say that plainly. You can mention something you read about the district (the three beliefs, or the 2026–2029 literacy plan) as what drew you, but only if it really did | Motivation is the Skeptic's second stop after the gap. `[generic]` because no quote of yours carries a reason, so the guidance can't supply one |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick one real limit and name it plainly. F3's words are the honest choice: "I've never taught fourth grade." Then what you would do about it in the first month, as a plan. Don't pick a fake weakness, and don't list several | A standard Skeptic stem. Rehearse it so A1 and A3 don't contradict each other. JD because it scores the listed role |
| A4 | "Have you held a team-lead or grade-level lead role?" | EXP | [grounded] "I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" | Answer the question first: "I've never been a team lead." Then, separately and at its own scope: in 2024 you led your grade level's move to a new reading curriculum. Keep the two apart. The move was one project, not a title, and the answer shouldn't blur them | F9 and F10 put the word "led" on the record, so the panel may test what it means. EXP because it checks attribution against your own words |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's the first week of school with a new fourth-grade class. What routines do you set up, and how?" | CASE | [generic] | Structure it: which routines come first (arrival, transitions, materials, getting help, dismissal), how you would teach and practise each one, how you'd know they've stuck, and what you would adjust in week two. This is a live problem, so it needs no claim about your past. If a third-grade routine you actually ran fits, describe it in your own words | F6 has no quote, so the live problem is where you show it. `[generic]` because it's a common pattern for the role |
| B2 | "A reading screener shows a third of your class reading below grade level. What do you do in the next two weeks?" | CASE | [inferred] | Clarify first: which skills, which students, what else you know about them. Then group by need, choose what each group gets, decide how often you check progress, and plan how you'll involve families. Mention the district's belief that assessments "inform teaching and never replace it" as the principle you're working from. No claim about your past is needed | F5 and F12 have no quotes. The posting's differentiation duty and the district's assessment belief both raise this. `[inferred]` because the duty comes from a representative posting |
| B3 | "Fourth-grade math moves into multi-digit multiplication and fractions. How would you differentiate a math lesson?" | CASE | [generic] | Structure it: a quick check of what students already know, then the same goal reached by different routes (concrete materials, visual models, symbols), flexible groups, and an exit check. Keep it about the plan you would use | F4 lists math among the five subjects, and your material says nothing about math. `[generic]` because the math topics are role-family knowledge, not this school's scope |
| B4 | "The district adopts a new grades 3–5 reading curriculum in fall 2027. What would you want from the first year of rollout?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan (a new grades 3–5 reading curriculum from fall 2027). Then say what you would want: time to learn the materials, shared planning with the team, and a way to see whether it's working. You can mention that in 2024 you led your grade level's move to a new reading curriculum. Answer slot: if you're asked what you learned from that move, say what you actually saw and did, in your own words. If you can't point to a lesson, say so and stay with what the 2027 rollout will need | F10 is the strongest link between your record and the district's current plan. CO because it tests whether you've done your homework on the district |

### C. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We plan together as a team. What would you bring to our planning, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Be reciprocal: say what you bring (reading-curriculum work, F9's quote at its own scope), then what you'd need as someone new to fourth grade: their pacing, assessments and routines. Ask how their planning works rather than guessing | F9 and F3 together. Peers weigh whether a new hire adds work or lightens it. JD because the posting names work with the grade-level team |
| C2 | "Tell us about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | Selection scaffold: pick a real disagreement with an equal, about teaching. It needs what each of you thought, how you talked it through, and how you still worked together afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | A standard Peer stem with no quote behind it. `[generic]` because the theme is the persona's, not yours |
| C3 | "Walk us through how your grade level moved to the new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F9 and F10: the move, the year, and that you led it. Those are the parts your sentence states. Tell them in your own words. Answer slot: the district's 2027 plan makes follow-ups on what leading involved likely. If parts of it were yours to decide, say which and how. If a decision wasn't yours, or there was no such step, say so plainly and stay with the move | Peers will want to know what you'd do in their 2027 rollout, so they will ask about the one you led. EXP because it tests what was actually yours |
| C4 | "What could you do in your first month that would actually help our team?" | JD | [generic] | Keep it modest and concrete: learn their systems before suggesting changes, take a share of shared prep, and offer what you know about reading curriculum when they ask. Make no claims about your past beyond what C1 already used | The reciprocity question peers often ask. `[generic]` because it's a pattern, not a fact about this team |

### D. Values / Behavioral: the district's three beliefs (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our district's first belief is Every Child a Reader. Tell us about a time you helped a reluctant reader." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Story-mapped on F11: the club, which you've run for the last two years. Answer slot: pick one real student or moment from the club, or from your classroom, in your own words. If no single case comes to mind, say so and describe how the club runs. Don't invent a turnaround | The district's beliefs raise this theme. F11 is your closest evidence. VAL because it scores a published belief |
| D2 | "Families Are Partners is one of our beliefs. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Lead with F7: you write a weekly email to families. Answer slot: the belief says each teacher speaks with every family each term. If you speak with every family, say how in your own words. If not, say so plainly and say how you would reach every family each term here | F8 is a transferability gap: writing versus speaking. Rehearse it so the email isn't stretched into conversations |
| D3 | "We believe in teaching for tomorrow, not for the test. What does that mean in your classroom?" | VAL | [generic] | Selection scaffold: pick a real time a test result informed what you taught without taking over the teaching. It needs what the result showed, what you changed, and what stayed the same. If none comes to mind, say so plainly and explain how you would use assessments in fourth grade | F12 has no quote, so this is a scaffold. VAL because it scores the district's third belief |

### E. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about the reading club. Who comes, and how do you know it's helping?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Start with what your sentence says: you've run it for the last two years. Answer slot: give the number of students and how they join, but only if you know them. Say how you judge whether it's helping, in your own words. If you don't track that, say so plainly. Don't give a figure you can't stand behind | F11 is the most specific piece of reading evidence you have, so a careful reader will ask for numbers. EXP because it tests the claim |
| E2 | "How do you know a reading intervention is working for a particular student?" | JD | [inferred] | Answer slot: if you have tracked a student's progress, describe what you looked at and how often, in your own words. If you haven't, say so plainly and describe the checks you would use. Name the least reliable measure you would rely on before they ask | F5 and F12 have no quotes. The posting's data line raises this. `[inferred]` because the duty comes from a representative posting |
| E3 | "Which subjects did you teach in third grade, and which was hardest to plan?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Start from the quote. Answer slot: list the subjects you actually taught. If the schedule was split and some weren't yours, say so plainly. Name the hardest one honestly | F4's gap. Fourth-grade teachers will want to know whether you've taught all five subjects |

### F. Conversational (low weight, certain opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second answer built from these four sentences only, each said at its own scope. Six years of third grade, the 2024 reading-curriculum move you led, the club you've run for two years, and the weekly family email. Close with one honest line on why fourth grade, from A2's slot | Every panel opens this way, and it sets the frame. EXP because everything in it can be followed up |
| F2q | "What are you reading with kids these days?" | CO | [generic] | Answer slot: name a book you're actually using, from the club or your class, and why it works. If nothing comes to mind, say what you'd pick for fourth graders and why | A casual question that matters with a reading-specialist principal. `[generic]` because no quote carries a title |

### G. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | Pause, then: "I've never taught fourth grade." Then the six years of third grade, the plan from A1, and one quoted strength from F1q's list. Hold that through two follow-ups. Concede the true thing (they have the fourth-grade experience) without folding on the rest | The time-boxed version of A1. Rehearse it separately so pressure doesn't knock the structure loose |
| G2 | "A whole grade level moves to a new curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead." | Hold the sentence: you led the move. Answer slot: say what you did yourself and what colleagues did, in your own words. If the word "led" overstates it, say so plainly. Keep the second quote in mind: you've never been a team lead, so don't let "led the move" turn into a title | F9 and F10 rest on the word "led", and an attribution probe is the natural pressure point. EXP because it scores honesty about attribution |

---

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | (To Principal Vantongeren) "I saw your talk on weekly reading conferences in grades 3 to 5. How does that work in Halvering's fourth-grade classrooms now?" | Ties to her public work and asks how it works here, without claiming a practice of yours |
| R2 | (To the teachers) "What could someone new to fourth grade do in the first month that would genuinely help your team?" | The reciprocity question. It shows you're thinking about their workload, which is what peers are scoring |
| R3 | "How is the team getting ready for the new grades 3–5 reading curriculum in fall 2027?" | Shows you know the district's literacy plan and are thinking ahead to work you'd share |
| R4 | "The district says each teacher speaks with every family each term. How do fourth-grade teachers here make that happen?" | Uses the district's own words and gets you a practical answer for the F8 gap |
| R5 | "What does a strong first year look like for a new fourth-grade teacher at Halvering?" | Tells you what you'd be measured on, and signals you're planning to grow into the role |
| R6 | "What's the next step in the process after today?" | A practical process question that helps you plan your follow-up |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F3 | "I've never taught fourth grade." No slot |
| Has been a team lead or grade-level lead | A negative you stated: "I've never been a team lead." | "I've never been a team lead." Plus F9's quote at its own scope |
| Chose or adopted the curriculum for the school or district | Inflated form of F9's and F10's quote | The quote at its own scope: you led your grade level's move. Your material says the grade level's move, not who chose the curriculum. C3's and G2's slots stay inside the move |
| Founded or built the reading club | Inflated form of F11's quote | The quote at its own scope: you've run the club for the last two years. Your material says ran, not started |
| Speaks with every family each term | Inflated form of F7's and F8's quote | The quote at its own scope: a weekly email to families. Your material shows writing, not speaking. D2's slot stays with how you'd do it here |

---

## Sources

**Provided:** the invite from Orrinsford CSD Human Resources, and your résumé notes, both pasted in your message. Your Social Security number wasn't needed and was not used. Your license number was not used in any search.

**Searches and fetches sent:**

1. Search `Orrinsford Community School District mission values`: returned https://orrinsfordschools.example/about/mission-and-beliefs
2. Fetch https://orrinsfordschools.example/about/mission-and-beliefs: three beliefs (Every Child a Reader; Families Are Partners; Teach for Tomorrow, Not for the Test) with definitions
3. Search `Halvering Elementary School Orrinsford`: no results
4. Search `Dolores Vantongeren principal Halvering Elementary`: returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. Search `fourth grade teacher job description Illinois elementary school district posting`: returned https://k12jobsboard.example/listings/fourth-grade-teacher
6. Fetch https://k12jobsboard.example/listings/fourth-grade-teacher: the representative posting's responsibilities and qualifications
7. Search `Orrinsford Community School District 2026 news priorities`: returned https://orrinsfordschools.example/news/board-adopts-literacy-plan

No dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | The three beliefs by name. They supply F8, F11 and F12 and the D bank. No values cheat sheet, because the invite names no values-style round |
| 2. `Orrinsford interview process` | skipped | Your invite already sets the format: one 45-minute panel with the principal and two fourth-grade team members. Persona weights follow from that |
| 3. `Orrinsford strategy` / recent news | yes | The 2026–2029 literacy plan, with a new grades 3–5 reading curriculum from fall 2027. Supplies F10, B4, C3 and R3 |
| 4. `Dolores Vantongeren Halvering` | yes | Her career path and her 2025 talk. Supplies the interviewer read and R1 |
| 5. representative `Fourth Grade Teacher` JD | yes | Job-duty rows F2 and F4–F7 and F9, all marked `[inferred]` |
| A further search outside the declared targets: the school's name | yes | No results. Moved nothing |

---

## Upgrade menu

- **The actual Halvering job posting text** → F2, F4–F7 and F9 become `[grounded]`, and any duty the representative posting missed gets its own row and question
- **Names of the two fourth-grade panelists** → persona weights per person, and a reverse question tied to each one's public work
- **Your license record printout** → F1 rises from medium to high
- **Your answers to the answer slots** (subjects taught, family conversations, reading plans, what leading the 2024 move involved) → F4, F8, F10 and F11 move from slot to story-mapped guidance in A, C, D and E
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district and the literacy plan, and more CO questions
- **A `tuesday-dossier.md`** → a highest-ROI objection taken from evidence you've confirmed rather than inferred here, and a prohibited-claims list carried between sessions
