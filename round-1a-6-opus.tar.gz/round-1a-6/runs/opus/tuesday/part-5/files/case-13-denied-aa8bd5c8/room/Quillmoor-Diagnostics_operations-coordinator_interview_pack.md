# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen. A 30-minute phone call, Thursday at 2pm, with Hannah Lowther, Talent Partner.
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", and then she'll tell you about the team and the next steps.

## How to use this pack

- **Personas** describe *how* a question arrives. **Types** describe *what* is being scored.
- **VAL**: behaviour against published values. **EXP**: what you actually did, and whether it holds up when probed. **JD**: whether you can do the job in the advert, gaps included. **CO**: what you know about the company. **CASE**: a live problem from the role.
- The guidance is scaffolding, not a script. Say it in your own words. Where a cell quotes you, the quote marks the limit: don't say more than it says.
- An **answer slot** is an instruction for the call. It has two honest branches and you pick the one that's true. It isn't a question for you to answer here.
- Question IDs go by persona. F is skipped so they don't clash with the fit-snapshot rows F1 to F10.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material describes deliveries for depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning/warehouse/QA line makes a probe on working across teams likely. If your scheduling depends on other teams' timings, say how in your own words. If it doesn't, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | discovery | The chasing is in your words: "I chase suppliers when orders slip." Tracking isn't. Answer slot: if you keep track of supplier deliveries yourself, say how in your own words. If there's no such step, or it isn't yours, say so plainly and return to the chasing |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap. It's still a figure with nothing inspected behind it, so expect a probe. Say the sentence whole, keeping "about a third" and "over a year". It says you rebuilt the spreadsheet and that discrepancies fell. It doesn't say one caused the other, so you don't say that either |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material doesn't show reporting either way. Answer slot: if you've reported regularly on deliveries or dispatch, say what and how often in your own words. If you haven't, say so plainly and say how you'd approach it |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap: "four years as a logistics coordinator at a building-supplies wholesaler" |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | discovery | A spreadsheet rebuild touches this, but your material doesn't name Excel. Answer slot: if it was Excel, say so and describe what you built, in your own words. If it wasn't, or you're not sure, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert, the SAP part | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap you have stated yourself. Words: "I've never used SAP." Then how you'd learn it, said as a plan and never as a past. The advert lists ERP as a plus, not a requirement. That is the advert's framing, so you don't need to argue it |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" part | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Your words are "we run our own in-house stock system", not an ERP, and they stay that way. Answer slot: expect a probe on what you do in that system. If you use it for stock records or orders, say what you do, in your own words. If not, say so plainly and stay with the sentence |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Met, in your own words. Both halves stay, the two days and the limit of three |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Met: your figure is inside the advertised band. Give it in your own words and add nothing |

## Persona table

The loop for this session comes from Hannah's own message: one 30-minute phone call with her, on the topics she listed. No values-style round was detected, so there's no values cheat sheet.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport (A) | A friendly phone chat working through her four logistics topics plus "tell me about yourself" | **Top.** A recruiter screen leans conversational, and four of her five agenda items are logistics. The risk is treating it as unscored | Have a 90-second arc ready. Give logistics answers in your own words, then stop |
| Skeptic (B) | Gentle knockout checks: SAP, production vs. depots, why this company | **High.** Recruiters screen against the advert's list, and F7 and F1 are the visible gaps | Rehearse B1 until it's boring. Bridge only from what you actually said |
| Data-Driven Prober (C) | "How was that third counted?", "What was the spreadsheet built in?" | **Mid.** F3 has the only figure on your record, and recruiters often pass figures on to hiring managers | Know what you can and can't say about how the figure was counted |
| Pressure (D) | Unlikely in this register, but possible as a quick challenge | **Low.** Nothing in her message points to it | Pause, hold what you said, and concede only what's real |
| Case / Strategist (E) | "What would you do if…" about a late supplier or a stock mismatch | **Low.** Usually hiring-manager territory | Clarify, then structure, then answer, thinking out loud |
| Peer Evaluator (G) | How you'd work across planning, the warehouse and QA | **Low.** The advert's cross-team line makes it plausible | Talk about what you'd bring the other team, not only what you'd need from them |
| Values / Behavioural (H) | "Tell me about a time…" | **Low.** No values round was detected, and Quillmoor's values couldn't be researched | Pick a real story, or say plainly if none comes to mind |

## Question banks

### A. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with three beats, each one of your sentences: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Then stop and let her steer. If she moves on to why you're leaving, that's A5: use those words | Draws on F5, F1 and F3. It's the standard opener and her first read on how clearly you communicate. EXP because it introduces what you actually did |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Your own words: "I'm hoping for £42,000." Then stop. If she follows up on the figure, give your own words again: "I'm hoping for £42,000." If she asks what you earn now: "I'd rather focus on the range for this role." | First item on her agenda, and F10 is the row it reads from. JD because pay is one of the advertised terms |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period | Named on her agenda. JD because it's a term of the job. There's no fit row because neither the advert nor Hannah states a requirement |
| A4 | "How would the hybrid pattern work for you — two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute or more office days, use your own words again: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Named on her agenda. F9 is the row, and it's met. JD because the office pattern is in the advert |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, your own words again, with nothing added | Named on her agenda. EXP because it's about your own situation. Recruiters listen for whether the reason stays the same on a second ask, and repeating the same words is what keeps it the same |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions SAP or a similar ERP. What's your experience there?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **The highest-ROI prep in this pack.** Opening: "I've never used SAP — we run our own in-house stock system." Name the limit before she has to find it. Follow-up 1, "So no ERP at all?": go back to "we run our own in-house stock system". Answer slot: if you know how it compares with an ERP, say so in your own words; if you don't, say you don't know. Never call it an ERP. Follow-up 2, "How would you get up to speed?": answer with a plan for learning it, said as something you would do, never as something you've done. Answer slot: if you use the in-house system for stock records or orders, say what you do in it; if not, say so plainly. Hold through both follow-ups by going back to the sentence, never by adding to it | F7 and F8 are the clearest gaps against the advert, and recruiters screen against its list, so this comes up in some form. JD because it scores a stated plus. It gets the deepest rehearsal because it's where the pull to sound bigger is strongest |
| B2 | "You schedule deliveries for three depots — how would that carry over to coordinating production schedules between planning, the warehouse and QA?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start with your sentence at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if that scheduling depends on other teams' timings or sign-off, say how, in your own words. If it doesn't, say so plainly and stay with the depots. Then say how you'd learn the production side, as a plan. Don't describe production work you haven't done | F1 is the role's headline duty, and your evidence is next to it rather than on it. JD because it scores the first line of the advert |
| B3 | "Why Quillmoor — why diagnostics?" | CO | [generic] | Selection scaffold: name what in the advert itself draws you, in your own words. For example, one duty from its list that you'd want to do. If nothing about diagnostics specifically draws you, don't invent it. Say what about the role does. If she ties it to your move, use A5's words and nothing more | A standard motivation check in a screen. CO because it tests what you know about the company. [generic] because no company research could run, so there's nothing about Quillmoor to build on |
| B4 | "The role reports weekly on on-time dispatch. Have you done regular performance reporting?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you've reported regularly on deliveries or dispatch, say what you reported and how often, in your own words. If you haven't, say so plainly and come back to "I schedule deliveries for our three depots and chase suppliers when orders slip." Then say how you'd approach a weekly report, as a plan | F4 has no evidence either way, so the honest answer needs to be ready. JD because it's a listed duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third — how was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the sentence exact, with "about a third" and "over a year". Four answer slots, each in your own words: how the fall was counted; what the figure depends on; which assumption behind it you'd defend least, named before she asks; and which part was yours. If you don't know exactly how it was counted, say so plainly. That's an honest answer, not a weak one | F3 holds the only figure on your record, and figures attract probes. EXP because it tests attribution |
| C2 | "How confident are you in Excel — what was the stock-count spreadsheet built in?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if it was Excel, say so and describe what you built, in your own words. If it wasn't, or you're not sure, say so plainly and stay with "I rebuilt our stock-count spreadsheet" | F6: Excel is a listed requirement your material touches but doesn't name. JD because it scores that line |
| C3 | "How do you keep track of supplier deliveries day to day?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you track supplier deliveries yourself, say how in your own words. If there's no such step, or it isn't yours, say so plainly and return to "chase suppliers when orders slip" | F2: tracking is the half of that duty your material doesn't show. JD because it's a listed duty |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the sentence says is yours: "I rebuilt our stock-count spreadsheet." Your sentence doesn't say the rebuild caused the fall, so don't claim it did. Answer slot: if other changes also played a part, say so. If you don't know what drove the fall, say you don't know. Hold through two follow-ups on the rebuild, and concede the rest plainly | F3 is the figure a challenger would go for. EXP because it scores attribution under pressure |
| D2 | "Sixty seconds: why you over a candidate who already knows SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause, then give the plain acknowledgment: "I've never used SAP." Then stand on what you said: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Don't fold and don't add to it | F7 under time pressure. It tests whether the acknowledgment from B1 holds up when you're rushed. JD because it scores the stated plus |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery will be three days late, and it's needed for a production run next week. What do you do?" | CASE | [generic] | Structure it: what you'd find out first (exactly what's late and what depends on it), who you'd tell (planning, then the warehouse and QA), what options you'd look for, how you'd keep chasing, and what you'd record. The question asks nothing about your past, so the guidance claims nothing about it | A live problem from F2's "chase late orders" line in a production setting. [generic] because it's a pattern, not a fact about Quillmoor |
| E2 | "The physical count shows 40 fewer units than the stock record. Walk me through what you'd do." | CASE | [generic] | Structure it: recheck before acting, find where the records diverge, decide which figure to trust and correct the record, tell whoever depends on it, and stop it happening again. No claims about your past | A live problem from F3's "keep stock records accurate" line. [generic] for the same reason as E1 |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Planning, the warehouse and QA don't always want the same thing. Tell me about a time you kept teams with different priorities on track." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick a time when two teams or a supplier wanted different things and you kept the work moving. It needs a real conflict, what you did, and how it ended. If your depot or supplier work holds such a time, tell it in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I chase suppliers when orders slip", or how you'd handle it | The theme comes from F1's cross-team line. JD because it scores that duty |
| G2 | "What would you need from the warehouse team to do this well — and what would you give them?" | JD | [generic] | Name what you'd need (timely, accurate information) and what you'd bring them (early warning when things slip). Say it as how you'd work, not as a claim about your past | A reciprocity check from the advert's warehouse line. [generic] because it's a pattern for the problem |

### H. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural opener. [generic] because Quillmoor's values couldn't be researched |
| H2 | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Selection scaffold: a real customer, a real target, and the choice you made. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Included so this style isn't new to you on the day. [generic] for the same reason as H1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 production schedules across planning, warehouse, QA | B2, G1 |
| F2 track supplier deliveries, chase late orders | C3, E1 |
| F3 accurate stock records | C1, D1, E2 |
| F4 weekly on-time dispatch reporting | B4 |
| F5 2+ years ops or logistics coordination | A1 |
| F6 confident with Excel | C2 |
| F7 and F8 ERP, SAP or similar | B1, D2 |
| F9 hybrid, two days at Avonmouth | A4 |
| F10 £38,000–£44,000 | A2 |
| Notice period, from her agenda | A3 |
| Reason for the move, from her agenda | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with most day to day across planning, the warehouse and QA?" | Picks up the team overview she promised, and shows you read the first line of the advert |
| R2 | "Which ERP or stock system does the team use, and how do new starters get trained on it?" | Puts B1's gap on the table as a question about the ramp-up, which reads as preparation rather than worry |
| R3 | "How is on-time dispatch measured at the moment, and what would you want the weekly report to change?" | Ties straight to a listed duty and tells you what the report is for |
| R4 | "Are the two Avonmouth days fixed, or chosen week to week?" | Practical, and useful before any offer |
| R5 | "What would a strong first three months look like in this role?" | Gives you the hiring manager's likely priorities ahead of the next round |
| R6 | "What are the next stages after this call, and roughly when?" | She said she'd cover next steps. Asking for timing shows you're engaged and helps you plan |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot |
| Has ERP experience | An inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material says an in-house stock system, not an ERP. B1's slot stays inside what you do in that system |
| Has coordinated production schedules | An inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries for depots, not production. B2's slot stays inside the depot scheduling |
| Cut stock discrepancies by a third with the new spreadsheet | An inflated form of F3: it drops "about" and "over a year" and adds causation | F3's quote whole: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." C1 and D1 keep it that way |

## Sources

- Provided: the advert text, Hannah Lowther's LinkedIn message, and your background notes, all pasted into the conversation.
- Search "Quillmoor Diagnostics values": refused
- Search "Quillmoor Diagnostics interview process operations": refused
- Search "Quillmoor Diagnostics Avonmouth news": refused
- Search "Hannah Lowther Quillmoor Diagnostics Talent Partner": refused
- No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have themed H1 and H2 with Quillmoor's published values instead of generic stems |
| 2. `Quillmoor Diagnostics interview process operations` | unavailable | The search was refused. Hannah's message still sets this session's structure, but the later rounds remain unknown |
| 3. `Quillmoor Diagnostics` strategy / recent news | unavailable | The search was refused. It would have grounded B3 and a CO question in what the company is doing now |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have added a read on her public professional background and a reverse question tied to her path |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search → the four refused L1 targets run: B3 gets Quillmoor-specific grounding, H1 and H2 are themed by its published values, and there's a public-footprint read on Hannah
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a company strategy brief and recent context for the hiring-manager round
- Your CV → the A1 arc and the F rows checked against your written record, and the next round's pack built on it
- Your answers to the answer slots, for example whether the spreadsheet was Excel, whether you report on deliveries, and what you do in the in-house system → C2, B4, C3, B1 and F4, F6, F8 move from slots to your own sentences
- A `tuesday-dossier.md` → would carry verified evidence, a named objection and prohibited claims into this pack; never needed for it
