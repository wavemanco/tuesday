Quick update: I've loaded the interview-prep playbook. Next I'm running a few searches on Lumenvale's values and interview process before I build your pack.
Before you prep, check one thing about the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well." A hiring process that happens entirely in a chat app is a known scam pattern. A chat alone doesn't show who you're dealing with, and the message may not come from the company it names. Until you know who sent it, don't send money, documents or bank details through Telegram. To check, contact Lumenvale Software using details you find yourself on its website or the careers page where you applied, not through the Telegram chat. Ask whether Marcus Hale works there and whether this invite is theirs. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite looked at more closely, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-5/rooms/case-10-denied-b5e87559/Lumenvale-Software_customer-support-specialist_interview_pack.md`. I built it for a text-chat interview with the support team lead, and assumed they'd be your manager.

**What's in it:**
- **Where you match the ad:**
  - **Experience:** your 3 years as an advisor clearly covers "2+ years in customer support".
  - **Ticketing tool:** using Freshdesk every day meets "Zendesk or a similar ticketing tool". Say "Freshdesk" and don't let it become "Zendesk".
  - **Written communication:** the 60 calls and emails a day show you answer emails, but not how clear your writing is. In a text-chat interview, every answer you type is a writing sample.
  - **Escalations:** nothing you've told me covers these yet, so the pack gives you a way to answer honestly either way.
- **The most valuable thing to practise is A1:** "You haven't worked for a software company. How would you get up to speed?" Admit it plainly, point to your three years and daily Freshdesk use, then give a concrete plan for learning the product.
- **22 practice questions.** Several are live writing tasks, like replying to a customer who was charged twice or explaining a fix to someone who isn't technical. Practise them by typing, not talking.
- **A short list of claims not to make,** like "60 emails a day" (your figure is calls and emails together) or saying you have Zendesk experience.
- **Company-specific parts are generic.** Web search permission wasn't granted, so I couldn't look up Lumenvale's values, product or news.

Say the word and I'll play the Skeptic on A1 in a live practice round.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to bring to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead your future manager, or a peer on the team? The answer changes which question styles the pack focuses on.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale-Software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Round:** text-chat interview with the support team lead (the format given in the invite). **Assumption:** the team lead is treated as your future manager. If they would be a peer, the persona weights change.

## How to use this pack

- **Personas** describe how a question is asked: the style and register. **Types** describe what the answer is scored on.
- Question IDs go by persona: A, B, C, D, E, G, H. There is no F, so IDs don't clash with the fit-snapshot rows F1 to F5.
- The invite says this is a text chat, so rehearse by **typing** your answers in short paragraphs. Don't just say them out loud.
- The guidance is scaffolding, not a script. Write every answer in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your stated experience holds up when probed, and what was actually yours |
| JD | Whether you can do the job as the ad describes it, gaps included |
| CO | Company knowledge: product, customers, recent news |
| CASE | A live problem from the role, worked through in front of them |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as your message gives it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. These are lines from your message with nothing behind them that anyone has inspected, so expect a probe. Lead with them in their own terms: three years as a customer service advisor at an energy supplier, and around 60 calls and emails a day. Keep calls and emails together, because that is how your figure counts them |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as your message gives it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap. The ad accepts a similar tool, and Freshdesk is the one you use every day. Name Freshdesk, and never let it turn into Zendesk. Answer slot: the ad's tool line makes a question about Zendesk itself likely. If you have used Zendesk, say where. If you haven't, say so plainly and stay with Freshdesk every day |
| F3 | "clear written communication" — the job ad, as your message gives it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Your material shows that you answer emails. It doesn't show how clear they are, and the bridge goes no further than that. In a text-chat interview, every answer you type is a writing sample. Answer slot: the ad's writing line makes a probe on your emails likely. If you can describe an email of yours that cleared something up, say what it did, in your own words. If none comes to mind, say so plainly and stay with the emails you answer every day |
| F4 | "confidence handling escalations" — the job ad, as your message gives it | none given | none | [grounded] | discovery | Your material doesn't mention escalations either way. Strong evidence would be a case that went beyond a normal reply: what you did, which part was yours, and how it ended. Answer slot: if you have handled escalations, say how, in your own words. If they went to someone else at your job, or you haven't had one, say so plainly and say how you would handle one |
| F5 | Knowing a software product well (a usual expectation for this kind of role, not in the ad) | "I've never worked for a software company" — your message | none | [grounded] | capability | Words: "I haven't worked for a software company." Then say how you would learn the product, as a plan and never as something you've done. Don't add anything to make the gap sound smaller |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "2+ years in customer support" | C1, A5, E1, E2 |
| F2 "Zendesk or a similar ticketing tool" | A3, C3 |
| F3 "clear written communication" | B1, B5, D3, G2 |
| F4 "confidence handling escalations" | A4, B3, D1 |
| F5 software product knowledge (not in the ad) | A1, A2, B2, G1 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the gap between energy-supplier support and software support | High. A team lead treated as the hiring manager is weighing the risk of hiring you, and F5 is the most visible gap | Rehearse A1 until it's boring. Use only facts you've stated, plus a concrete plan for learning the product |
| Case/Strategist (B) | "A customer writes in with X. Reply here." | High. A hiring manager wants to see the work done, and a text chat makes a live written reply easy to ask for | Clarify, then act, then set expectations. Type it as you would actually send it |
| Conversational (C) | Friendly openers: your background, why Lumenvale | Medium. Every chat starts here, and casual answers are still scored | A 90-second arc built only from F1 and F2 |
| Behavioural (D) | "Tell me about a time…" questions themed on the ad's lines | Medium. The ad's escalation and writing lines turn naturally into story questions. No values round is detected, so these are scored against the ad, not against published values | Choose a story you actually lived. If none fits, say so and say how you would handle it |
| Data-Driven Prober (E) | Picks at "around 60 calls and emails a day" | Low to medium. It's the only figure in your material | Know what you can and can't say about how the figure is counted |
| Pressure (G) | Time-boxed challenges | Low. Unusual from a team lead, but cheap to rehearse | Restate the question, concede the gap you've stated, and hold on F1 and F2 |
| Peer Evaluator (H) | "What do you need from the other teams?" | Low. Only likely if the lead turns out to be a peer | Talk about what you give the team as well as what you need from it |

## Question banks

### A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company. How would you get up to speed supporting our product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | **The highest-ROI prep in this pack.** Concede first, plainly: "I haven't worked for a software company." Then say what you do bring, in exactly these terms: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, and Freshdesk every day. Then give a ramp plan, as a plan: use the product as a customer would, read the help centre, ask to shadow tickets, and keep a list of questions to clear with the team. Hold through two follow-ups by going back to the plan and the stated facts. Never claim the work is "basically the same" | F5 is the gap that is easiest to see from outside, so some version of this question will come. JD because product knowledge comes with any software support role |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the real one, not a modest-sounding fake: "I haven't worked for a software company, so the product itself would be the steepest part." Then one sentence of A1's plan. Don't follow it with a weakness disguised as a strength | This is A1 asked sideways. A rehearsed honest answer keeps the two consistent. Tagged JD |
| A3 | "The ad mentions Zendesk. Have you used it?" | JD | [grounded] "I use Freshdesk every day" | Answer slot: if you have used Zendesk, say where. If you haven't, say so plainly. Either way, go back to the fact: you use Freshdesk every day. Don't describe Zendesk features you haven't used | F2 is a gap with nothing to recover, but the ad names the tool, so a direct question about it is likely. JD because it is a stated requirement |
| A4 | "Escalations are part of this job. How confident are you handling them?" | JD | [grounded] | Answer slot from F4: if you have handled escalations, say how and what part was yours, in your own words. If they went to someone else, or you haven't had one, say so plainly and walk through how you would handle one, using B3's structure | F4 has no evidence either way, which makes it the second-likeliest probe. JD because the ad names it |
| A5 | "Why move from an energy supplier into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I've never worked for a software company" | Give your actual reason, in your own words. It's yours alone, and the pack supplies none. Keep it about moving towards this role, not running from your current one. Close with the fact that carries across: three years as a customer service advisor | F1 and F5 together prompt the "why now" question. EXP because it tests whether your story is consistent |

### B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes: 'I've been charged twice this month and nobody replied to my last email.' Reply to them here." | CASE | [generic] | Actually type the reply. Thank them, apologise specifically for the wait, say what you'll check (both charges, the account), say when they'll hear back, and don't promise a refund before you've checked. Short paragraphs and no jargon | A live writing test on the ad's written-communication line. It asks about no past, so the guidance makes no claim about you |
| B2 | "A customer says the app keeps logging them out and they're losing work. You can't reproduce it. What do you do?" | CASE | [generic] | Clarify: device, browser or app version, when it started, exact steps. Give a workaround if there is one. Log the ticket with everything engineering would need and pass it on through the team's process. Tell the customer what happens next and when you'll update them. Say you'd learn the team's own process rather than guessing it | Tests how you'd approach a software fault, which is F5's territory, without needing software experience. Generic because it describes a pattern, not Lumenvale's actual tooling |
| B3 | "A customer is angry, wants a manager, and says they'll cancel. Walk me through it." | CASE | [generic] | Acknowledge without arguing. Find out what outcome they want. Fix what's within your power. Escalate cleanly when it isn't, with a summary so they don't have to repeat themselves. Confirm the next step in writing | The ad's escalation line, asked as a decision rather than a record. CASE, with JD content |
| B4 | "Two customers both mark their tickets urgent and both say it's critical. You can only take one first. How do you decide?" | CASE | [generic] | Ask what's actually broken for each: blocked from working, money at risk, how many people affected. Send a quick holding reply to the other ticket. Follow the team's priority rules if there are any, and say you'd ask what they are | Prioritisation is a standard live problem for support queues. Generic pattern |
| B5 | "Explain clearing a browser cache to a customer who isn't technical. Write it as you'd send it." | CASE | [generic] | Numbered steps, one action each, plain words, and what they should see when it has worked. Offer a call or a follow-up if they get stuck | The ad's writing line, tested directly. In a text chat, the answer is the evidence |

### C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year"; "I use Freshdesk every day" | A 90-second arc with only these beats: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day, and training four new starters on your refunds process last year. Then a line on why this role, in your own words | It's almost always the opener. F1 and F2 carry it. EXP because the interviewer will pick what to probe from it |
| C2 | "What made you apply to Lumenvale?" | CO | [generic] | Pick something you actually read: the ad, the company website, the product. Before the chat, spend twenty minutes on their site and help pages. If you haven't found anything specific, say plainly what drew you to software support. Don't invent a reason tied to their product | CO is usually where strategy questions go, but no company research could run, so this stays generic |
| C3 | "How do you find working in Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Answer slot: the ad's tool line makes a probe on how you work in the tool likely. If there are features you rely on daily, name them and say what you use them for, in your own words. If you mainly use the basics, say so and stay with using it every day | F2, asked casually. Casual questions about a requirement are still scored |

### D: Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a customer was unhappy with the answer you had to give." | JD | [generic] | Pick a time with a clear stake, something you said or did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it, using B3's structure | The theme comes from the ad's escalation line. It's a story question and nothing in your material carries an escalation, so the guidance is a way of choosing a story, not a story |
| D2 | "Tell me about training those new starters on the refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats your sentence states: four new starters, your refunds process, last year. Tell how it went in your own words. The pack adds no details about how you ran it | The F1 line an interviewer is likeliest to pick up from C1. EXP because it tests what was yours |
| D3 | "Tell me about a time you had to explain something complicated in writing." | JD | [inferred] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot from F3: if one of your emails explained something complicated, say what it was and how it went, in your own words. If none comes to mind, say so plainly, then point to the emails you answer every day and to B5 as how you would write it | F3's thin evidence, rehearsed so the honest answer is ready. JD because it is the written-communication requirement |

### E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Around 60 calls and emails a day. How is that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | In your own words: how the figure is counted, what makes it go up or down, the part of it you would defend least, and what share was yours. If you don't know exactly how it's counted, say so. "Around" is your word, so keep it | The only figure in F1. Prober interviewers test every number. EXP |
| E2 | "What's the split between calls and emails?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: if you know the split, give it. If you don't, say so plainly. Never split the figure by guessing | The role is written, so the email share is the natural follow-up to F1. EXP |

### G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who's already done software support?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | Pause, then hold and concede. Concede: "I haven't worked for a software company." Hold: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day. Then the ramp plan from A1. Don't run down the other candidate | F5 under time pressure. Hold-then-concede is what's being scored. JD |
| G2 | "This job is all writing. How do I know you're good at it?" | JD | [inferred] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Hold: emails are part of what you answer every day. Concede the limit honestly: what you've told them shows the volume, and they can judge the quality from how you write in this chat. Then offer to write a sample reply on the spot | F3's gap, asked aggressively. The concession turns the chat itself into your evidence. JD |

### H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When a ticket needs another team, what do you need from them, and what do you give them?" | CASE | [generic] | Give: a clean summary, the steps to reproduce the problem, what the customer has already been told, and the urgency. Need: a rough timeline, and a clear owner. Say you'd learn how the team works with the others before proposing changes | Relevant if the lead is a peer. It tests whether you'd add to or reduce other people's workload |
| H2 | "How do you handle it when a colleague dealt with a customer differently than you would have?" | EXP | [generic] | Pick a real disagreement with an equal: what you raised, how, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the Peer persona's disagreement stem. It's a story question with nothing in your material behind it, so you get a way of choosing a story |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What do the most common tickets look like in a new starter's first month?" | Shows you're already planning the ramp that A1 promises, and the answer tells you what to study |
| "Which ticketing tool does the team use, and how is it set up for your queues?" | Ties to F2. Shows you'll arrive ready to learn the tool, not just the product |
| "How are escalations handled here? What does an agent own, and what goes to you?" | Ties to F4. You learn the process B3 asks you to describe |
| "What does a strong first three months look like for someone in this role?" | Gives you the scoring sheet for the job itself |
| "How does what customers tell support get back to the product team?" | Shows you see support as part of the product, which partly answers F5 |
| "After this chat, what are the next steps? Is there a call or video stage with the team?" | Tells you what to prepare next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk |
| Has supported a software product or worked at a software company | Negative you stated, F5 | "I haven't worked for a software company." |
| Answers around 60 emails (or written tickets) a day | Inflated form of F1: the figure counts calls and emails together | F1's quote whole: around 60 calls and emails a day |
| Ran onboarding or led a training programme | Inflated form of F1's training line | F1's quote at its own scope: four new starters, your refunds process, last year |

## Sources

**Provided:** your message, which gave the invite text, the ad's four requirements as you listed them, and your background.

**Searches:** "Lumenvale Software company values" (refused); "Lumenvale Software interview process customer support" (refused); "Lumenvale Software news 2026" (refused). No fetches. No dossier was used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Refused. Would have themed values questions with the company's published values |
| 2. Lumenvale Software interview process | unavailable | Refused. Would have shown any later rounds. This session's format comes from the invite's own words |
| 3. Lumenvale Software strategy and recent news | unavailable | Refused. Would have made C2 and the CO questions specific to the company instead of generic |
| 4. Interviewer name | n/a | The support team lead isn't named, so no search could be formed |
| 5. Representative Customer Support Specialist JD | skipped | The ad's four requirements in your message fix the fit snapshot and the JD questions |

## Upgrade menu

- **Full job ad text:** catches any requirement beyond the four you listed, and lets the fit snapshot quote the ad directly.
- **Allowing web search:** the company's values, process and product would make C2 and the CO and VAL questions specific to Lumenvale.
- **The team lead's name and role:** a reverse question tailored to them, and persona weights based on their public profile.
- **An escalation you've handled, or a clear email you've written, told to me outside a drill:** turns F4, A4, D1, F3, D3 and G2 into story-mapped answers.
- **Any written record your employer keeps of your work, such as a quality review of your emails, if one exists:** would raise F1 and F3's confidence.
- **A `tuesday-dossier.md`:** would add verified evidence and a prohibited list checked against your corrections.
