I'm building your interview prep pack now. I've read the guidelines and I'm about to do a quick company research pass. One thing in the invite needs flagging, and I'll cover it at the top.
Before the prep, one thing in the invite. It says the hiring process "is carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with, and the message may not come from who it names. Until you've checked, send no money, ID documents or bank details through that chat. You applied through Lumenvale's careers page, so check the invite with Lumenvale using contact details you find on its own website or careers page. Don't use a number, email or link from the Telegram message, or the sender's own answers. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. I've assumed the support team lead would be your manager, so the questions lean towards live customer scenarios and probing your gaps. My web searches on Lumenvale were blocked, so the company and values questions are general rather than specific to Lumenvale.

Your three years at around 60 calls and emails a day, and using Freshdesk every day, already meet two of the ad's four requirements. The ad accepts a "similar" tool to Zendesk. Clear writing and handling escalations are the two the pack helps you prepare honest answers for. The question most worth practising is B1, "You've never worked for a software company. How would you get up to speed?" The pack's answer starts with a plain acknowledgment and then moves to a learning plan.

Say the word and I'll play the sceptical interviewer on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would the support team lead be your manager, or someone else on the team? The answer reweights every bank.
Can you paste the full job ad? It would let every requirement be quoted from the ad itself.
Would you like me to try the Lumenvale research again if you allow web search?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Round:** a text-chat interview with the support team lead (from the invite: "your interview will be a text chat here with our support team lead"). The team lead's name isn't known. This pack assumes they would be your manager, so it is weighted as a hiring-manager round.

## How to use this pack

Each question has two labels. The **persona** is how it gets asked (who is asking, in what style). The **type** is what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values the company publishes |
| EXP | Whether what you say about your experience holds up under follow-up questions |
| JD | Whether you can do the job as the ad describes it, gaps included |
| CO | How much homework you've done on the company |
| CASE | How you reason through a live problem from the job |

The guidance is scaffolding, not a script. Put it in your own words. Because this round is a typed chat, your answers are also a sample of your writing. Short paragraphs, a clear first sentence and no walls of text will do some of the work the "clear written communication" line asks for.

Provenance labels: `[grounded]` traces to your message or the ad as you gave it. `[inferred]` is this pack's own derivation, which it names. `[generic]` is a common pattern for this kind of role and says nothing specific about Lumenvale.

## Fit snapshot

The requirements below are the job ad's, in the words your message used for them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as given in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day. It is a strong line with nothing inspected behind it, so expect a probe on the volume (C1) |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as given in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap. The ad accepts a similar tool, and your words already meet it: "I use Freshdesk every day." Stay with Freshdesk by name and never let it become Zendesk |
| F3 | "clear written communication" — job ad, as given in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering emails shows you write to customers daily, but not whether the writing is clear, so this bridge shouldn't be stretched. The typed interview is itself the evidence they will see. Answer slot: if you have a way you structure replies or check them before sending, say what it is, in your own words. If you don't, say so plainly and describe how you would write a reply to a confused customer |
| F4 | "confidence handling escalations" — job ad, as given in your message | none given | none | [grounded] | discovery | Strong evidence here would be a specific angry or stuck customer, what you did and how it ended. Answer slot: the ad's escalations line makes a probe certain. If you have handled escalated or angry customers, pick one real case and say what you did, in your own words. If none comes to mind, or escalations always went to someone else, say so plainly and walk through how you would handle one (A1, A5) |
| F5 | Supporting users of a software product (a common pattern for this kind of role, not a line in the ad as you gave it) | "I've never worked for a software company" — your message | none | [grounded] | capability | You've said this gap yourself, and words can't close it. Words: "I haven't worked for a software company." Then say how you would learn the product, as a plan and never as something you've done. Don't add anything to make the gap feel smaller |
| F6 | Helping colleagues get up to speed (a common pattern for this kind of role, not a line in the ad as you gave it) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap. Keep it at its own scope: four new starters, the refunds process, last year. Training them is not managing them |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic lead) because a support team lead is usually assessing capability and gaps. That relationship is an assumption, and the closing questions ask about it. The ad's escalations and writing lines push Case up further. Your stated gap (F5) makes the Skeptic's main objection predictable.

| Persona | How it shows up in a typed chat | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "A customer writes in saying…" scenarios, maybe asking you to draft a reply right there | High. A hiring manager plus the ad's escalations and writing lines | Clarify, then structure, then answer. Ask one clarifying question before solving |
| Skeptic | Quiet probes on fit: no software background, Freshdesk rather than Zendesk, why switch | High. F5 is a gap you've said yourself, and the ad names Zendesk | Rehearse B1 until it bores you. Plain acknowledgment, then a concrete learning plan |
| Data-Driven Prober | Asks how "around 60 a day" was counted and what the training involved | Medium. Your two figures are the obvious things to probe | Know what you can and can't say about how the 60 was counted, and say so plainly where you don't know |
| Conversational | Friendly openers: your background, why this role | Medium. Chat interviews often open casually, and casual questions are still scored | A short, typed background answer prepared ahead of time (D1) |
| Pressure | "Why you over someone with software support experience?" | Low. Possible, but it isn't the team-lead default | Pause, restate the question, hold what your quotes carry for two follow-ups, then concede the specific gap |
| Values / Behavioral | "Tell me about a time…" stories | Low. No values round is known, and Lumenvale's published values weren't available | Pick real stories. Where none comes to mind, say so |
| Peer Evaluator | Hand-offs to other teams, handling a colleague's load | Low. The interviewer may lead the team you'd join | Talk about what you'd bring to the team, not only what you'd need |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer has been charged twice, wants a refund today and says they'll cancel if not. What's your reply?" | CASE | [generic] | Structure it: acknowledge the problem in one line, say what you'd check first (the account, both charges), say what you can commit to now and what needs approval, give a timeframe, and say how you'd follow up. If the chat allows, type the first two sentences of your actual reply. No claim about your past is needed | Tests the ad's escalations line as a live decision. CASE because it scores reasoning, and `[generic]` because it's a common support scenario, not a known Lumenvale one |
| A2 | "A customer says a feature stopped working after our last update, and you can't reproduce it. What do you do?" | CASE | [generic] | Clarify first: what exactly happens, on which device or browser, since when, with screenshots if possible. Then give a workaround if there is one, pass it on with clear reproduction details if not, and tell the customer what happens next and when. No claim about your past is needed | Puts F5's gap in front of you as a problem you can reason through without any software history. `[generic]` because the product is unknown |
| A3 | "Your queue is full and several tickets are marked urgent. How do you decide what to answer first?" | CASE | [generic] | Say your criteria out loud: impact on the customer, deadlines, whether it's blocking them, how long each one will take. Then mention quick holding replies to buy time on the rest. No claim about your past is needed | A common team-lead prioritisation probe. CASE because the reasoning is scored |
| A4 | "Write the first reply you'd send to a customer whose issue you need to pass to another team." | JD | [grounded] | Type it for real: thank them, restate the issue in one line, say who is looking at it, when they'll hear back and what they need to do in the meantime. Keep it short and avoid jargon. No claim about your past is needed | In a typed interview, the ad's writing and escalation lines can be tested directly. JD because it scores both stated requirements (F3, F4) |
| A5 | "When would you escalate a ticket rather than solve it yourself?" | JD | [grounded] | Give criteria: it's outside your permissions, it needs a technical fix, there's a risk to money or data, or the customer explicitly asks for a manager. Add how you'd hand it off so nobody has to ask the customer again. No claim about your past is needed | The ad names escalations (F4). JD content with CASE delivery, so a gap in your material doesn't cost you here |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | **This is the highest-ROI prep in the pack.** Start with the plain acknowledgment: "I haven't worked for a software company." Then stay with what your quotes carry: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, and Freshdesk every day. Then give the plan, framed as a plan: use the product yourself, read the help docs, go through past tickets, shadow colleagues, and keep a list of questions. Hold through two follow-ups by returning to those quotes, never by adding to them. If they press on technical depth, concede plainly that you'd be learning the product from scratch | F5 is the gap you've stated yourself and the most predictable objection. Having a calm answer ready changes the interview. JD because it scores fit against the role |
| B2 | "The ad mentions Zendesk. You use Freshdesk. How big a gap is that?" | JD | [grounded] "I use Freshdesk every day" | Say it in your own words: "I use Freshdesk every day." Answer slot: if they ask which parts of Freshdesk you work in, name the ones you actually use, in your own words. If you only use a few, say so plainly and stay with daily use. Never say or imply you've used Zendesk | F2 meets the ad's "or a similar" wording, but a team lead may still check. JD because it's the tool requirement |
| B3 | "Tell me about a time you handled an escalation." | JD | [grounded] | Pick a real case: a customer who was angry or stuck, what you did and how it ended. Answer slot: if you handled it yourself, say what you did, in your own words. If none comes to mind, or escalations always went to someone else, say so plainly, then give the nearest thing you did do, or how you would handle one (A1) | F4 has no evidence yet and the ad names it, so expect this question in some form. JD because it scores a stated requirement |
| B4 | "Why move from an energy supplier to a software company?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: give your actual reason, in your own words and kept short. Say what draws you to this role, not what pushes you away from the current one. If your reason is simple, say it simply | A team lead weighs motivation alongside F5. EXP because it tests how consistent your story is |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Around 60 calls and emails a day. How is that counted, and how does it split between calls and emails?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep the word "around." Answer slots, in your own words: how the figure is counted (a dashboard, your own estimate, a target), what makes it go up or down, which part of it you'd defend least, and the rough split if you know it. If you don't know how it was counted, say so plainly. "That's my rough daily average" is an honest answer | A headline figure gets probed. EXP because it tests whether the number holds up (F1) |
| C2 | "You trained four new starters on the refunds process. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it at its own scope: four new starters, the refunds process, last year, in your own words. Answer slot: if they ask which part was yours, for example whether you built the training material or used existing material, say which. If the material wasn't yours, say so plainly and stay with the training you did. It was training, not managing | F6 is a strong line and the obvious one to probe. EXP because it tests what was actually you |
| C3 | "How do you keep a written reply clear when the issue is complicated?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | You can say you answer emails as part of that daily volume, in those words. Answer slot: if you have a habit, such as a structure you follow or a check before sending, say what it is. If you don't, say so plainly and describe how you would approach it: answer first, then steps, then what happens next | F3's bridge is thin, so have the honest answer ready before the probe arrives. JD because it's the stated writing requirement |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me a bit about your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | Prepare it as a short typed answer of three or four lines: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day, and training four new starters on the refunds process last year. Then one line on why this role, in your own words (answer slot) | The opener sets the frame for everything after it. Drafting it ahead of time is cheap and you'll almost certainly use it |
| D2 | "What drew you to this role?" | JD | [generic] | Answer slot: your real reason, in your own words. Tie it to something in the ad, like the writing or the escalations work, if that's genuinely what drew you. Avoid generic praise | Casual, but scored for motivation. Pairs with B4 |
| D3 | "What do you know about Lumenvale?" | CO | [generic] | Say only what you've read yourself on their website or careers page, and say where you read it. If you've read little, say so and ask what they'd most want a new starter to know. Never guess at products or customers | This pack couldn't research the company (see Sources), so the only safe answer is your own reading. CO because it scores homework |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Quickly: why you, over someone who already has software support experience?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I've never worked for a software company" | Don't rush, even in chat. Hold with what the quotes carry: three years, around 60 calls and emails a day, Freshdesk every day. Concede specifically and once: "I haven't worked for a software company." Then give the learning plan from B1. Don't fold on the three years just to smooth things over | This is B1 under time pressure. JD because it's the fit question asked sharply |
| E2 | "That training. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the quote: you trained four new starters on the refunds process. Answer slot: if the process or the material was someone else's, say so plainly. Credit given precisely reads as confidence | An attribution probe. EXP because it tests precise honesty (F6) |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real time: a named customer situation, the target or rule that pulled the other way, what you chose and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you did do, or how you would handle it | A common behavioural stem. `[generic]` because Lumenvale's published values weren't available |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a real time you raised a problem with a manager or senior person: what you said, how it was received, what happened. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would do it | Team leads often want support staff who flag recurring problems. `[generic]` pattern |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How do you hand a ticket to another team so they don't come back to you with questions?" | JD | [grounded] | Structure it: a one-line summary, what the customer reported, what you've already tried, what's needed, how urgent it is, and what the customer has been told. No claim about your past is needed | The ad's escalations line, seen from the other team's side (F4). JD content with CASE delivery |
| H2 | "A colleague keeps escalating tickets to you that they could solve themselves. What do you do?" | CASE | [generic] | Talk to them directly and kindly, find out why (confidence, unclear process), offer to walk through one together, and raise it with the lead only if it continues. No claim about your past is needed | Tests how you handle peers. `[generic]` pattern |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | D1, C1, B4 |
| "experience with Zendesk or a similar ticketing tool" | B2 |
| "clear written communication" | A4, C3 |
| "confidence handling escalations" | A1, A5, B3, H1 |
| Software product context (F5, not in the ad as given) | B1, A2, E1 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What kinds of tickets make up most of the queue right now?" | It shows you're already picturing the work, and the answer tells you what to learn first |
| "How do escalations to engineering or other teams work here?" | It ties straight to the ad's escalations line and shows you care about clean hand-offs |
| "How is support quality measured on your team?" | It shows you expect to be held to a standard, and it tells you what good looks like |
| "What does product training look like for a new specialist?" | It turns F5 from a weakness into a practical question about how you'd ramp up |
| "What would a strong first three months look like to you?" | It invites the team lead to describe success, which you can then speak to |
| "Which ticketing tool does the team use day to day?" | It's practical, and it gives you a natural opening to mention Freshdesk |

## Prohibited claims

What this pack will not coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk |
| Managed or led a team | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on the refunds process last year. Your material says training, not managing |
| Designed or owned the refunds process | Inflated form of F6 | F6's quote at its own scope. C2's slot asks only which part of the training was yours |
| Has worked in software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |

## Sources

- Provided: your message (the invite text, the job ad's requirements as you gave them, and your background).
- Search: "Lumenvale Software company values", refused.
- Search: "Lumenvale Software interview process customer support", refused.
- Search: "Lumenvale Software news", refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Refused. It would have themed the VAL bank with published values. G1 and G2 stay `[generic]` |
| 2. `Lumenvale Software interview process customer support` | unavailable | Refused. The invite's own words already describe this session (a text chat with the support team lead), so persona weights rest on that |
| 3. `Lumenvale Software` strategy / recent news | unavailable | Refused. It would have given D3 and a CO question something current to stand on |
| 4. `{interviewer name} Lumenvale Software` | n/a | The team lead wasn't named, so there was no query to form. The interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The ad's requirements, as you gave them, already fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → every requirement quoted from the ad itself, and any mid-list items (tools, hours, metrics) get their own questions
- The support team lead's name → an interviewer read, persona weights tuned from their public profile, and a reverse question tied to their path
- Permission for web searches → Lumenvale's published values for the VAL bank, current company context for D3, and a CO question
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → company context and role-specific loop reports
- A real escalation you handled, told outside a drill → F4 and B3 move from an answer slot to a mapped story
- How you keep written replies clear, if you have a habit → F3 and C3 get your own words
- Your prep time → a prioritised schedule sized to it
- A tuesday-dossier.md → verified evidence and a set of prohibited claims that sharpen every bank; never needed to use this pack
