Still reading the prep-pack rules before I write it — I'll have your pack shortly.
Pack is drafted; fixing one labelling clash before I hand it over.
Before the prep, one thing about the invite. It says the "hiring process is fully remote and is carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run entirely through chat is a known scam pattern. A chat on its own doesn't show who you're actually talking to, and the invite may not come from who it says. Until you've checked it, don't send money, ID documents or bank details through the chat. To check, contact Lumenvale using details from its own website or the careers page you applied through. Don't use the Telegram chat, the number it came from, or any answers given in it. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you'd like the invite looked at more closely, job-underwriter can check it as a separate request.

Your prep pack is saved as `Lumenvale_customer-support-specialist_interview_pack.md`. I built it for a single text-chat interview with someone who would be your manager, because the invite doesn't say how the team lead relates to the role.

- **What matches the ad well:** your 3 years answering around 60 calls and emails a day covers "2+ years in customer support". Using Freshdesk every day covers "Zendesk or a similar ticketing tool".
- **What will probably be asked hardest:** that you haven't worked for a software company. That's question B1, the highest-value thing to rehearse. The answer is built on saying it plainly, standing on what you have done, and then giving a plan for learning the product.
- **What your message doesn't show yet:** written communication and handling escalations. For those I've given you an honest way to answer each likely question rather than writing a story for you.
- **The text format matters:** because the interview is typed, every reply you send counts as a sample of your writing.
- **Research:** my web searches were refused, so nothing in the pack about Lumenvale itself comes from research. Questions that depend on company detail, such as C2, are written as general versions and labelled that way.

Say the word and I'll play the Skeptic on B1 in a typed practice run.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Would the support team lead be your direct manager, or a lead elsewhere on the team? The answer changes which interviewer styles the pack weights most.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Round:** text-chat interview with the support team lead (from the invite: "your interview will be a text chat here with our support team lead").
**Interviewer:** name not given. The pack assumes they would be your manager, so it uses hiring-manager weights. If they wouldn't be, the persona weights change.

## How to use this pack

- **Personas** describe *how* a question arrives: who is asking and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour and values. Does your past behaviour show what the company says it values?
  - **EXP**: experience deep-dive. Do the things you've said hold up, and what was actually yours?
  - **JD**: the job ad's requirements. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on Lumenvale?
  - **CASE**: a live problem from the role, worked through in the moment.
- The interview is a **text chat**, so every answer is a written answer. Keep typed replies to short paragraphs: one point each, with a line break between beats. The "90–120 seconds" length guide means roughly 4–8 short sentences.
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Fit snapshot

Requirements F1–F4 quote the job ad as you summarised it in your message. F5 and F6 are role-family items that aren't in the ad as you listed it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you summarised it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap. This meets the stated bar, but nothing inspected stands behind it, so expect a probe. Lead with the sentence's own terms: three years, customer service advisor, around 60 calls and emails a day. Keep "calls and emails" together as one figure, as your message does |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you summarised it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap. Freshdesk is the "similar ticketing tool" the ad allows for. Say it in your own words: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so you may be asked about it. If you've used Zendesk, say how, in your own words. If you haven't, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as you summarised it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering emails is part of what your message describes, but it doesn't show how your writing was judged. Answer slot: if any of your written replies were reviewed, scored or commented on, say how, in your own words. If they weren't, say so plainly. In a text-chat interview, your replies in the chat will be read as writing samples |
| F4 | "confidence handling escalations" — job ad, as you summarised it | none given | none | [grounded] | discovery | Strong evidence here would be a case where a customer's issue needed more than the first answer and you saw it through, or handed it on cleanly. Answer slot: the ad's escalations line makes a probe likely. If you handled escalations, whether you took them or passed them on, say what you did, in your own words. If escalations weren't part of your role, say so plainly and say how you would handle one |
| F5 | Supporting a software product. Role-family, and implied by the employer being a software company | "I've never worked for a software company" — your message | none | [generic] | capability | A gap you have stated yourself. Words: "I haven't worked for a software company." Then say how you would learn the product, as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Sharing process knowledge with teammates. Role-family, not in the ad as you listed it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap. Use the sentence's own terms: four new starters, the refunds process, last year. Keep the scope at training those four on that process |

## Persona table

The invite is the only source for the round: one text chat with the support team lead. Nothing in it says whether the lead would be your manager, so the starting weights are the hiring-manager defaults (Case/Strategist plus Skeptic). They are adjusted for the text format: interruptions are harder in chat, so Pressure is weighted lower, and every reply is written, so F3 is scored throughout.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | "A customer writes in saying…, what do you reply?" Live ticket scenarios | High. A team lead hiring for the queue is buying capability, and scenarios are easy to run in chat | Clarify, then structure, then answer. Type the reply you'd actually send where asked. Name the next step and who owns it |
| B. Skeptic | Quiet probing of F5 and F4: the move from energy to software, escalations, Zendesk | High. F5 is the most visible gap in your background, and the hiring-manager default includes the Skeptic | Rehearse B1 until it's boring. Bridge only from your quotes, say the limit plainly, and give a ramp plan said as a plan |
| C. Conversational | Friendly openers: "tell me about yourself", "why us" | Medium. A chat usually opens casually, but casual questions are still scored on how economically you write | A pre-written three-to-four-sentence arc from F1. Treat "any questions?" as scored |
| D. Data-Driven Prober | Picks up the figures you've given: around 60 a day, four new starters, three years | Medium. Your figures are the obvious thing to probe | Know what you can and can't say about how each figure was counted. Say plainly when it's an estimate |
| E. Pressure | Time-boxed or devil's-advocate challenges: "in a minute, why you?" | Low. Interrupting in text is awkward, but a short time-box is easy to set in chat | Pause, restate, anchor in what you stated, and hold through two follow-ups before conceding anything real |
| V. Values / Behavioural | "Tell me about a time…" customer-first stories | Low. No values round is named, and Lumenvale's published values weren't read for this pack | STAR shape, using "we" for context and "I" for your part. A selection scaffold where no quote carries the story |
| G. Peer Evaluator | "What would you need from the team?" Seams with other support staff or product | Low. A team lead sometimes asks about how you'd work with the team | Talk about what you'd bring and what you'd need. Propose working principles rather than guessing at the team's setup |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in, angry, saying they've been charged twice and want it fixed today. Type your first reply." | CASE | [generic] | Write the actual message: acknowledge the problem in one line, say what you'll check, say what happens next and when, and close with how they'll hear back. Don't promise a refund you can't confirm. Keep it short, plain and free of jargon. The question needs no claim about your past, so this guidance makes none | Tests F3's requirement live, in the format the chat itself rewards. CASE because it's a problem you solve in the moment, with JD content |
| A2 | "A customer isn't happy with your answer and asks for a manager. What do you do?" | CASE | [generic] | Structure: what you'd check first (is there something you can still resolve?), what you'd tell the customer and when, what you'd pass on in the handover so they don't have to repeat themselves, and how you'd follow up. Don't refer to your own past escalations unless you have one (see B3's slot) | F4's requirement asked as a live decision. CASE because it scores structure, not history |
| A3 | "A customer reports a bug you can't reproduce. How do you handle the ticket?" | CASE | [generic] | Structure: what to ask the customer (steps, device, screenshots, when it started), what to tell them while you look, what goes in the note to whoever investigates, and how you keep the customer updated. It's fine to say you'd follow the team's process for passing bugs on and ask what that is | A software-support scenario aimed at F5. Rehearsing it means the F5 gap meets a structured answer rather than a blank |
| A4 | "You start your shift with 40 open tickets. How do you decide what to answer first?" | CASE | [generic] | Structure: urgency and impact first (anyone blocked, anything time-sensitive), then oldest waiting, then quick wins. Say that you'd check whether the team has its own priority rules before using your own | A routine queue problem for this role. CASE because it scores how you reason. The figure is the question's, not yours |
| A5 | "This customer's question needs the product team. What would your internal note say?" | CASE | [generic] | Write it: what the customer asked, what you've already tried, what you need from them, how urgent it is, and what you've told the customer. Plain, complete, and readable by someone with no context | F3's requirement again, written for a colleague rather than a customer, and a seam F5 makes likely |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company. Why should we think you can support our product?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment: "I haven't worked for a software company." Then stay with what your message carries: three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, and you use Freshdesk every day. Then give a learning plan, said as what you *would* do: work through the help centre, ask how the team wants bugs passed on, note the questions customers ask most. Hold through two follow-ups by returning to the same facts, never by adding to them. Concede plainly that product knowledge is what you'd be learning | F5 is the most predictable objection to this background, and F1 and F2 are what you can stand on. JD because it scores fit for the listed job |
| B2 | "The ad mentions Zendesk. What's your experience with it?" | JD | [grounded] "I use Freshdesk every day" | Lead with what you have: you use Freshdesk every day. Answer slot: if you've used Zendesk, say how, in your own words. If you haven't, say so plainly, stay with Freshdesk, and say how you'd get up to speed. Don't call the two tools the same or list Freshdesk features you don't use | F2's named tool. The ad's "or similar" leaves room for this answer, but the question may still arrive |
| B3 | "Tell me about a time you handled an escalation." | JD | [grounded] | Selection scaffold: pick a time a customer's issue needed more than the first answer. It needs what the problem was, what you did, who else was involved, and how it ended. If no such time comes to mind, or escalations weren't yours to handle, say so plainly, then give the nearest thing your material carries, or how you'd handle one (A2's structure) | F4 is silent in your material and the ad names it. This is where you're most tempted to invent, so rehearse the honest version first |
| B4 | "Why move from energy to software support?" | EXP | [grounded] "I've never worked for a software company" | Answer slot: give your actual reason, in your own words. Don't borrow a reason because it sounds good. If asked what you'd miss or find hard, it's fine to repeat that you haven't worked for a software company and say how you'd learn | F5 makes the motivation probe likely. EXP because it scores whether your story holds together |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A three-to-four-sentence arc: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day, and last year you trained four new starters on the refunds process. End with one line on why this role, in your own words | F1, F2 and F6 in one arc. The usual opener, and it's scored on economy |
| C2 | "What drew you to Lumenvale?" | CO | [generic] | Answer slot: give your actual reason, in your own words. If you mention anything about the company, use only what you read yourself on its careers page or website, and name the page. Don't guess at products or values you haven't seen | No company research could run for this pack, so this stays generic. CO because it scores homework |
| C3 | "What do you enjoy most about support work?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: say what you actually enjoy, in your own words, anchored in the work F1 names. If there's a part you enjoy less, it's fine to say so briefly | A rapport question that still scores motivation. EXP because it draws on F1 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day. Walk me through what that looks like." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep the figure as your message states it: around 60 calls and emails, together, a day. Answer slot: say how you know the figure, in your own words. If it's a rough sense rather than a count, say so plainly. Say what pushes it up or down, the part of it you'd defend least, and which of it was yours. Never split it into 60 emails or 60 calls | F1's headline figure. EXP because figures you give attract a defend-the-number probe |
| D2 | "You trained four new starters on refunds. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats the sentence states: four new starters, the refunds process, last year, and the training was yours. Answer slot: if you prepared the material or decided what the training covered, say how, in your own words. If the material or plan came from someone else, say so plainly and describe how you trained them | F6 is your clearest example of explaining a process to someone, which is what support writing is. EXP because it tests what was actually yours |
| D3 | "How do you use Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Answer slot: describe what you actually do in it, in your own words: the parts you use and how. If there are parts you don't use, say so rather than listing them | F2, checked for depth. EXP because the prober will ask exactly what "every day" means |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "One minute: why you over someone who's already done software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I've never worked for a software company" | Hold: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day. Concede specifically, not defensively: "I haven't worked for a software company." Then state the plan from B1 in one line. Don't run down the other candidate | F5 under time pressure. A shorter version of B1, rehearsed for composure |
| E2 | "Sixty a day sounds like volume, not quality. How do I know your written replies are any good?" | JD | [inferred] "answering around 60 calls and emails a day" | Pause, then hold: you answer around 60 calls and emails a day. That's volume, and you can say so. Answer slot: if your replies were checked or scored in any way, say how, in your own words. If they weren't, say so plainly and point to your replies in this chat. Hold through two follow-ups. Don't claim a quality score you weren't given | F3's thin evidence under challenge. The text format lets your answer show the quality it's asked about |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time when helping a customer properly cost time, a target or a shortcut. It needs the trade-off, what you chose, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A common behavioural stem. Generic because Lumenvale's values weren't read for this pack |
| V2 | "Tell me about a time you raised a problem with your manager that they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs the problem, how you raised it, their reaction, and how it ended, with the working relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | A common behavioural stem, adapted for a team-lead interviewer. Low weight, but rehearse it once so it isn't new on the day |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When you're stuck on a ticket, what do you need from the rest of the team?" | CASE | [generic] | Say what you'd try yourself first, when you'd ask, what you'd include so a colleague can help quickly, and how you'd pass on what you learned so the next person isn't stuck | Scores whether a new hire adds to the team's load or reduces it. CASE because it's about how you'd work, not your history |
| G2 | "A teammate keeps passing you their difficult tickets. What do you do?" | CASE | [generic] | Structure: assume good intent, talk to them directly first, agree a fair way of splitting tickets, and raise it with the lead only if it continues. Firm and polite | A seam question in collegial form. It tests how you disagree with an equal |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1, "2+ years in customer support" | C1, D1, E1 |
| F2, "experience with Zendesk or a similar ticketing tool" | B2, D3 |
| F3, "clear written communication" | A1, A5, E2, and every typed reply |
| F4, "confidence handling escalations" | A2, B3 |
| F5, supporting a software product | B1, E1, A3, B4 |
| F6, sharing process knowledge | D2, C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical day in the queue look like for the team?" | It shows you're thinking about the actual work, and the answer tells you the volume and the channels |
| R2 | "How are escalations handled here, and who picks up what?" | It connects to the ad's escalations line (F4), and the answer shows you what "confidence handling escalations" means on this team |
| R3 | "What do new starters find hardest about learning the product?" | It meets F5 head-on and shows you're already planning how to ramp up |
| R4 | "What would good look like in my first 90 days?" | It signals you're thinking about delivery, and it gives you the bar you'd be measured against |
| R5 | "How is quality measured on the team?" | It speaks to F3 and shows you care how replies are judged, not just how many get sent |
| R6 | "What are the next steps after this chat? Is there a call or video stage?" | It tells you what to prepare for next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in, or supported a product at, a software company | A negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Handles 60 emails a day, or 60 tickets a day | Inflated form of F1: the figure moved to a different noun | F1's quote at its own scope: around 60 calls and emails a day, together |
| Ran, designed or owned the refunds process, or led a training programme | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on the refunds process last year. D2's slot stays within that training |
| Three years of customer support at a tech or software company | Inflated form of F1, contradicted by F5 | F1's quote as stated: customer service advisor at an energy supplier |

## Sources

- **Provided:** your message, including the invite's text, the job ad's requirements as you summarised them, and your background.
- **Searches sent:**
  - "Lumenvale Software company values": refused
  - "Lumenvale Software interview process customer support": refused
  - "Lumenvale Software news 2026": refused
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have themed the VAL questions (V1, V2) with Lumenvale's published values |
| 2. `Lumenvale Software interview process customer support` | unavailable | The search was refused. The invite's own words already set the round, so this would have added only detail on later stages |
| 3. `Lumenvale Software` strategy / recent news | unavailable | The search was refused. It would have grounded C2 and added a CO question on current products or priorities |
| 4. `{interviewer name} Lumenvale Software` | n/a | The support team lead isn't named, so no query could be formed. There's no interviewer read |
| 5. representative `Customer Support Specialist` JD | skipped | The ad's requirements you listed fix the fit snapshot rows F1–F4 and their JD-tagged questions |

## Upgrade menu

- **Whether the support team lead would be your manager** → persona weights recomputed. A peer lead would move Peer and Prober up and bring in a reciprocity reverse question
- **The full job ad text** → rows F1–F4 quoted from the ad itself rather than your summary, and any mid-list requirement (a named tool, hours, a product area) gets its own JD question
- **Allowing web search** → Lumenvale's published values, interview process and recent news, which ground C2, re-theme V1–V2 and add a CO question. A deeper pass after that (up to 6 more searches and 2 more fetches, several more minutes) would add a company brief
- **Your CV** → more sentences to quote, and defend-the-number rows for any other figures it carries
- **Your answers to the slots in F3 and F4** (whether your written replies were ever reviewed, and whether escalations were part of your role) → B3, A2 and E2 move from scaffolds to story-mapped answers
- **The interviewer's name** → an interviewer read and a reverse question tied to their path
- **A `tuesday-dossier.md`** → verified evidence grading and a confirmed prohibited-claims list for this pack to build on
