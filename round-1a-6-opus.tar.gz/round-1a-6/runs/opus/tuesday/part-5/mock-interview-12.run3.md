Quick update: I've read the prep playbook and am now checking for anything public about the company before I write your prep pack.
Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed. It also asks you to "reply with a photo of your passport and your bank details before the interview". And it says successful candidates "deposit the cheque and send the balance on to the vendor". Asking for a fee, your ID and your bank details before any offer, and asking you to deposit a cheque and send money on, is a known scam pattern. These requests are very likely a scam. Hold all three: no payment, no passport photo or bank details, and no cheque deposit. Wait until you've checked the invite with the company, using contact details you find yourself on its own website or careers page, not the email address or account in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

I've saved your prep pack as `/var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-5/rooms/case-12-denied-9e95b35c/Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. I built it for the 30-minute video call with the office manager, assuming they'd be your manager, because the invite doesn't say.

**What to expect:**
- **Plenty of practical "how would you handle…" questions:** a calendar clash, booking a trip, an invoice that doesn't match the order.
- **A friendly "tell me about yourself" opener.** The pack has a 90-second version built from what you told me: the appointment book for four physios and chasing unpaid invoices.
- **Probes on your gaps:** invoices, Excel and travel booking.

The most useful thing to rehearse is question B1, about supplier invoices. Chasing unpaid invoices means getting money owed to the clinic. Processing supplier invoices means handling bills the company pays. Those are different jobs, so be accurate about which one you did. Also keep "okay with Excel" in your own words rather than upgrading it.

My searches for anything public on the company were declined by the permission prompt, so the company-knowledge and values questions are general ones.

Say the word and I'll play the Skeptic on B1 with you.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Will the office manager be your day-to-day manager? The answer reweights every bank. And can you paste the full job ad? The pack would then quote the ad itself instead of your summary, though it works from your summary as it stands.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** one 30-minute video call with the office manager (no name given). Built on the assumption that the office manager would be your manager.

## How to use this pack

**Personas** describe *how* a question is asked: who is asking, in what style. **Types** describe *what* is being scored:

- **JD**: can you do the listed job, gaps included
- **EXP**: does what you say about your past hold up when they dig into it
- **CASE**: a live problem from the job, worked through out loud
- **VAL**: behaviour and values, told as a story
- **CO**: what you know about the company

The answer guidance gives you a structure to work from. It is not a script. Say it in your own words, and say only what you actually did. An **answer slot** tells you how to answer a likely probe honestly whichever way the truth goes. It is not a question for you to answer here.

Provenance labels: `[grounded]` traces to something you or the invite said; `[inferred]` is this pack's own derivation, which is named; `[generic]` is a standard pattern for admin roles with no claim about this employer.

## Fit snapshot

Requirements are the duties of the ad as your message gives them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" from the ad, as your message gives it | "I ran the appointment book for four physios" from your message | medium | [grounded] | transferability | An appointment book for four physios is close to calendar work but is not the same thing, and your words should stay at that scope: "I ran the appointment book for four physios." Answer slot: the ad's calendars line makes a probe on clashes and rescheduling likely. If you handled those in the book, say how, in your own words. If you didn't, or it wasn't your job, say so plainly and stay with the book you ran |
| F2 | "booking travel" from the ad, as your message gives it | none given | none | [grounded] | discovery | Strong evidence here would be a trip you booked for someone: who it was for, and what you arranged. Answer slot: if you have booked travel for anyone, at work or elsewhere, say what you booked, in your own words. If you haven't, say so plainly, then explain how you would approach it (see A2) |
| F3 | "preparing documents in Word" from the ad, as your message gives it | "I'm good with Word" from your message | low | [inferred] | discovery | Your rating of yourself is there, but the documents behind it aren't in your material. Answer slot: if you produced documents in Word at the clinic or elsewhere, name the kinds, in your own words. If you can't name any, say so plainly and stay with "I'm good with Word" |
| F4 | "preparing documents in ... Excel" from the ad, as your message gives it | "okay with Excel" from your message | low | [inferred] | discovery | Your own word is "okay", and that word stands: "I'm okay with Excel." Answer slot: if there are specific things you have done in Excel, name them in your own words. If there aren't many, say so plainly and say what you would learn first |
| F5 | "processing supplier invoices" from the ad, as your message gives it | "chased unpaid invoices" from your message | medium | [grounded] | transferability | Chasing unpaid invoices means getting money owed *to* the clinic. Processing supplier invoices means handling bills the company *pays*. That is the other side of the transaction, so don't present one as the other. Words: "At the clinic I chased unpaid invoices." Answer slot: the ad's supplier-invoices line makes a probe on processing likely. If you ever checked, logged or paid a supplier's invoice, say what you did, in your own words. If not, say so plainly and come back to the invoices you chased |

## Persona table

The loop is set by the invite's own words: one 30-minute video call with the office manager. With only 30 minutes, expect perhaps 6 to 10 questions in total. The weights below show which styles are most likely.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | "How would you handle…" on calendars, travel, invoices, priorities | High. An office manager who would manage you is assessing whether you can do the work, and practical scenarios are the quickest test | Clarify, then structure, then answer out loud: what you'd check first, what you'd do, who you'd tell |
| Skeptic (B) | Quiet probes on the gaps: invoices, Excel, travel, going from front desk to remote | High. F2, F4 and F5 are visible gaps against the ad's duties | Rehearse B1 until it bores you; describe what you did at its true size; give a learning plan, never a bluff |
| Conversational (C) | "Tell me about yourself", "why this job" | Near-certain as the opener of a short call | A prepared 90-second arc (C1); treat the friendly questions as scored |
| Data-Driven Prober (D) | "Tell me more about the appointment book…" | Medium. Your strongest evidence (F1, F5) invites follow-up | Know exactly what was yours; say plainly when something wasn't |
| Pressure (E) | Time-boxed "why you" or a pointed challenge | Low to medium in a 30-minute admin call | Pause, restate, hold what you actually said, then concede the real gap |
| Values / Behavioural (F) | "Tell me about a time…" | Medium. A common admin-interview format, although the invite names no values round | Pick a real moment; "we" for context, "I" for what you did |
| Peer Evaluator (G) | Working together remotely, "what would you need from me" | Low to medium. Remote work makes communication a likely theme | Offer how you would keep people informed, framed around what helps them |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people want the same slot in my calendar on the same afternoon. What do you do?" | CASE | [generic] | Structure: find out which is more urgent or who it matters to; check whether either can move; offer alternatives; confirm in writing; update the calendar. The question needs no claim about your past, so this guidance makes none | Tests the ad's calendar duty (F1's requirement) as a live problem; CASE because it scores reasoning, not history |
| A2 | "I need to be in another city for a 9 a.m. meeting and back the next evening. Talk me through booking it." | CASE | [generic] | Clarify first: budget, preferences, whether to travel the night before. Then transport, accommodation near the venue, timings with buffers, one itinerary sent to them, and a confirmation check the day before | F2 has no evidence, so a structured live answer is your best ground; CASE delivery on JD content |
| A3 | "A supplier invoice comes in that doesn't match what we ordered. What do you do?" | CASE | [generic] | Structure: don't pay it yet; compare it against the order or quote; note the difference; check with whoever placed the order; contact the supplier; record what was agreed. No claim about your past | F5's requirement, set as a live problem so you can show judgement without claiming invoice-processing experience |
| A4 | "You've a document to finish, invoices to process and a calendar clash, all before noon. How do you prioritise?" | CASE | [generic] | Say what you'd do first and why: anything time-critical or that blocks someone else first, a quick message to anyone affected, then the rest in order. Name one question you'd ask the manager | Tests juggling across the ad's duties; CASE because it scores the order you choose and your reasons |
| A5 | "I send you a spreadsheet of supplier invoices. How would you check it for mistakes?" | CASE | [generic] | Structure: totals against the source invoices, duplicates, missing dates or amounts, anything unusual flagged rather than fixed silently. Only mention Excel features you can actually use, and say if you would need to look one up | F4's requirement as a live problem; keeps your answer to what you can genuinely do |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is reception. What experience do you have processing supplier invoices?" | JD | [grounded] "chased unpaid invoices" | **The highest-return prep in this pack.** Hold: "At the clinic I chased unpaid invoices." Keep the sides straight: that was money owed to the clinic, not bills it paid. Answer slot: if you ever checked, logged or paid a supplier's invoice, say what you did, in your own words. If not, say so plainly, come back to the invoices you chased, then say how you'd learn their process. Follow-up 1, "So you haven't done it?": hold the true answer without apologising. Follow-up 2, "Why should that not worry me?": concede the gap specifically, then point to how you'd handle a mismatched invoice (A3) | F5 is the gap the ad presses hardest, and the tempting overstatement is to present chasing as processing; JD because it scores a listed duty |
| B2 | "How strong is your Excel, honestly?" | JD | [grounded] "okay with Excel" | Start with your own word: "I'm okay with Excel." Answer slot: if there are specific things you've done in it, name them, in your own words. If not many, say so plainly and name what you'd learn first. Never upgrade "okay" to strong or advanced | F4: your own rating sits below what a spreadsheet-heavy role may expect, so expect this one |
| B3 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if you have, say for whom and what you booked, in your own words. If you haven't, say so plainly, then walk through how you'd approach it, as in A2 | F2 has no evidence either way, so the honest answer needs to be ready |
| B4 | "You've been at a front desk. Why a remote role, and how will you work without people around?" | EXP | [grounded] | Your reason for wanting remote work is yours to give; give the real one. Selection scaffold: pick something that shows you can keep work moving without someone beside you. It needs a task and what you did to keep it on track. If no such example comes to mind, say so plainly, then explain how you'd structure a remote day | The role is remote, per the invite's own title, and your background is in-person; EXP because it tests motivation and how you'll work |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Name a real one. Your own words give you "I'm okay with Excel", or pick another true gap. Then give one concrete step you'd take in the first weeks. Don't name a fake weakness | Skeptics use this to test honest self-assessment; F4 supplies a true answer |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc in those beats: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices. Close with why this role is the next step for you, in your own words | The near-certain opener; it sets the frame for everything after |
| C2 | "What drew you to this role?" | EXP | [grounded] | Give your real reasons. Selection scaffold: one reason tied to the duties in the ad, one tied to how you like to work. If you can't name a duty-linked reason, say what you're hoping to learn | Motivation is scored even when it's asked casually |
| C3 | "What do you know about us?" | CO | [generic] | Say only what you've actually read, such as the ad's duties. Don't invent facts about the company. Good fallback: "From the ad I understood the role covers X and Y. I'd like to hear more about the team." | No company research came back for this pack, so stay with what you've read |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me more about running the appointment book for four physios. How did it work day to day?" | EXP | [grounded] "I ran the appointment book for four physios" | The beats the sentence gives you: the book, the four physios, and that you ran it. Answer slot: the ad's calendars line makes probes on cancellations and clashes likely. If you handled them, say how, in your own words. If not, say so plainly and describe how you ran the book | F1 is your strongest evidence, so expect follow-ups on it |
| D2 | "When you chased unpaid invoices, how did you go about it?" | EXP | [grounded] "chased unpaid invoices" | Describe the chasing in your own words. Answer slot: if there were steps you followed, describe them; if it was informal, say so plainly. Don't add volumes or amounts you can't stand behind | F5's evidence, probed for what was actually yours |
| D3 | "You say you're good with Word. What kinds of documents have you produced?" | JD | [grounded] "I'm good with Word" | Answer slot: if you produced documents in Word, name the kinds, in your own words. If you can't name specific ones, say so plainly and stay with "I'm good with Word" | F3: your rating of yourself, without the documents behind it, invites exactly this question |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with office admin experience?" | JD | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Pause, then: you ran the appointment book for four physios and chased unpaid invoices. Say what those mean for this job in your own words. If they push, concede that it was a clinic front desk rather than an office, and hold what you did do | Tests composure on the background gap; JD because it scores fit to the listed role |
| E2 | "If I gave you an Excel task right now, would you manage it?" | JD | [grounded] "okay with Excel" | Hold the true answer: "I'm okay with Excel." Answer slot: if there are tasks you know you can do, name them; if you'd need to look things up, say so plainly. Don't bluff under the time pressure | F4 under pressure; a held, honest answer scores better than a confident one that collapses |

### F. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Tell me about a time you had to tell someone something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a real moment. It needs a person, what you told them, how you said it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing from your work or how you would handle it | A common behavioural question; no company values were available to map it to |
| F2q | "When did you put someone's needs ahead of the schedule?" | VAL | [generic] | Selection scaffold: a real moment where you chose between a person's needs and the plan. Say what you weighed and what you did. If none comes to mind, say so plainly and say how you'd decide | Common for front-facing and admin roles; tests judgement |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We're all remote. How would you keep me and the team updated?" | CASE | [generic] | Structure: agree the channel and rhythm, a short daily or weekly update, flag problems early rather than late, and confirm anything important in writing | Remote role, per the invite's title; tests communication without claiming a remote history |
| G2 | "What would you need from me in your first week?" | CASE | [generic] | Name practical things: access to the calendar and systems, how invoices are approved, who the key suppliers and contacts are, and one check-in. Frame them around getting useful quickly | A reciprocity question that shows you're thinking about their workload |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Managing calendars | A1, D1, A4 |
| Booking travel | A2, B3 |
| Preparing documents in Word | D3, A4 |
| Preparing documents in Excel | A5, B2, E2, B5 |
| Processing supplier invoices | B1, A3, D2 |
| Remote working (from the invite's title) | B4, G1 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical week look like in this role?" | Shows you're picturing doing the job, and the answer tells you which of your answers to stress |
| "Whose calendars would I be managing, and how do they like to work?" | Ties directly to the ad's first duty and shows practical thinking |
| "How are supplier invoices handled now, and what system do you use?" | Shows you take the invoice duty seriously, and gives you something concrete to prepare for |
| "How does the team stay in touch day to day, working remotely?" | Signals you've thought about remote work, and its answer prepares you for G1-style follow-ups |
| "What would a great first three months look like for this person?" | Lets the manager describe success in their own words, which you can reflect back |
| "What are the next steps after this call?" | A natural process question, and it tells you what to prepare for next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices, or did accounts payable | Inflated form of F5, with the sides of the transaction swapped | F5's quote at its own scope: "At the clinic I chased unpaid invoices." The pack's own observation: chasing money owed to the clinic is not processing bills it pays |
| Managed the clinic's scheduling or calendars | Inflated form of F1, wider than what you said | F1's quote at its own scope: "I ran the appointment book for four physios." |
| Strong or advanced Excel | Contradicted by your own words, F4 | "I'm okay with Excel." |
| Expert in Word | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word." |

## Sources

- Provided: the invite email, pasted in your message; the ad's duties and your background, as your message gives them.
- Search "Brennock Facilities Ltd values": refused.
- Search "Brennock Facilities Ltd news": refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The search was refused. It would have themed the VAL questions on published values; they stay `[generic]` |
| 2. `{company} interview process {role family}` | skipped | The invite's own words fix the session: one 30-minute video call with the office manager |
| 3. `{company} strategy` / recent news | unavailable | The search was refused. It would have grounded C3 and given you something current to mention; C3 stays `[generic]` |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `{role title}` JD | skipped | The ad's duties in your message fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text: rows F1 to F5 would quote the ad itself, and any duties your summary left out would get their own questions
- The office manager's name: an interviewer read, persona weights tuned to their public career, and a reverse question tied to their path
- Whether the office manager would be your manager: confirms or changes the persona weights
- How much prep time you have: a prioritised schedule for the time you have
- Permission to search: company values and recent news would ground the VAL and CO questions
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes: a fuller company brief for the CO questions
- Your answers on travel booking, Word documents and Excel tasks: rows F2, F3 and F4, and questions B2, B3, D3 and E2, would move from answer slots to answers built on your own story
- A `tuesday-dossier.md`: verified evidence and a set list of claims not to make, carried across sessions
