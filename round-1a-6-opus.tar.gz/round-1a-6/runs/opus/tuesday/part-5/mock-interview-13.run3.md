Reading the prep playbook's rules is done; next I'm running a quick company search, then I'll build your recruiter-screen pack.
I've built your prep pack for Thursday's call with Hannah. Today is Thursday the 26th, so if the call is today at 2pm, rehearse the five A questions and B1 out loud first.

**What the pack covers**
- **Her four topics.** Each has a ready answer in your own words:
  - **Salary:** "I'm hoping for £42,000." That's inside the advertised £38,000–£44,000. If she asks what you earn now, the pack gives you a polite way to decline and steer back to the role's range.
  - **Hybrid:** your two-days-fine, no-more-than-three sentence, kept whole.
  - **Reason for moving:** the office closing and the Reading relocation you don't want. It's a clean reason, so the pack adds nothing to it.
  - **Notice period:** you didn't give me yours, so check your contract and give the actual figure.
- **The question most worth rehearsing** is "Have you used SAP?" (B1). Answer plainly: "I've never used SAP — we run our own in-house stock system." Don't call that system an ERP or "like SAP". The advert lists SAP as a plus, not a requirement.
- **Your strongest material** is the stock-count spreadsheet rebuild. Expect "how was that measured?" and "how much of that was you?" Always say "about a third, over a year", exactly as you put it.
- **Your biggest gap** is that you schedule deliveries for three depots, while the role coordinates production across planning, the warehouse and QA. Describe what you actually do and let her make the comparison.
- **The rest:** 18 practice questions in total, six questions to ask her, and a list of claims to avoid making.

**Limits**
- Web search wasn't permitted, so nothing about Quillmoor or Hannah is researched. The pack works only from the advert, her message and your notes. Turning search on would add a researched "why Quillmoor" answer.
- Some answers are left for you to fill in, because your notes don't cover them: what you do in the in-house system, whether the spreadsheet is in Excel, and whether you do any regular dispatch reporting.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/tuesday/part-5/rooms/case-13-denied-3a3ef8d4:
- Quillmoor-Diagnostics_operations-coordinator_interview_pack.md

If you like, I can play Hannah and ask you the SAP question, with follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep turned up, for you to use in later sessions.
I can convert the pack to a Word document too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor-Diagnostics_operations-coordinator_interview_pack.md -----
# Prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen. A 30-minute phone call, Thursday at 2pm.
**Interviewer:** Hannah Lowther, Talent Partner (the recruiter).
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

## How to use this pack

Two things describe each question. The **persona** is how it's asked: the tone and the pressure. The **type** is what's being scored:

- **VAL**: values or behaviour, tested against the company's published values
- **EXP**: your own experience, and whether it holds up when someone digs into it
- **JD**: the advert's stated duties and terms, and whether you can do the job
- **CO**: what you know about the company and its strategy
- **CASE**: a live problem from the role, solved out loud

The guidance is scaffolding, not a script. Say it in your own words. Wherever a cell gives an **answer slot**, only you can fill it. If the honest answer is "no" or "that wasn't me", that branch is a good answer too.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | What you've told me covers delivery scheduling for three depots. It doesn't cover production schedules across planning, the warehouse and QA, so stick to the depots: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a question about working across teams likely. If your scheduling means agreeing timings with other teams, say which teams and how, in your own words. If it doesn't, say so plainly and stay with the depot scheduling you do |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. This line is close to the advert's own words, but it's only your say-so, so expect a follow-up. Lead with it as you said it: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, and it's your strongest line for this role. Expect questions on the figure (C1, E1). Keep "about a third" and "over a year" exactly as you said them |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Nothing you've told me covers regular reporting. Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and who reads it, in your own words. If you don't, say so plainly and say how you'd approach a weekly on-time figure |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Say it as it stands: four years as a logistics coordinator at a building-supplies wholesaler |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your notes don't say what the spreadsheet was built in, or how much Excel you use. Answer slot: if you built it in Excel, say what you built into it, in your own words. If it was another tool, name it plainly |
| F7 | "ERP experience (SAP or similar) a plus" — the SAP part — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You've said it yourself, and no wording closes it. Words: "I've never used SAP." Then say how you'd learn it, as a plan and never as past experience. Never claim SAP work, and add nothing to make the gap sound smaller. The advert calls it a plus, not a requirement |
| F8 | "ERP experience (SAP or similar) a plus" — the "or similar" part — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | transferability | The in-house stock system is the closest thing you have, so describe it as just that: "we run our own in-house stock system." Your notes don't say what you do in it. Answer slot: if you use it day to day for stock records or orders, say what you do in it. If your use is light, say so plainly. Don't call it an ERP |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Inside the advertised band. Your own words are the whole answer: "I'm hoping for £42,000." |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised two days fit what you said. Your own words, kept whole, are the answer |

## Persona table

Hannah's message sets out this call: one 30-minute phone call with her, on the topics she listed. The weights below come from that message and from the usual pattern for recruiter screens.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly questions about your background and the four logistics topics she named | High. It's a recruiter screen, and her own agenda is logistics plus your reason for moving | Treat the casual questions as scored. Have a 90-second biography ready (A1). Give the logistics answers in your own words, the same way every time. Always have questions ready for her at the end |
| Skeptic | Quick checks against the advert: SAP, production scheduling, why this sector | Medium. A recruiter usually checks the obvious gaps before passing a candidate to the hiring manager. In this advert those are the SAP line and the production-scheduling line (F1, F7) | Rehearse the SAP answer until it's boring (B1). Bridge only from what you actually said, and state the limit plainly |
| Data-Driven Prober | One follow-up on your one figure | Low. Recruiters probe less than hiring managers, but the figure in F3 invites a "how was that measured?" | Know what you can and can't say about how the third was counted, and say "I don't know" where you don't |
| Case / Strategist | A light "what would you do if…" | Low. Unusual in a 30-minute recruiter call. Included so you don't meet the style for the first time later | Clarify, then structure: what's affected, who needs to know, what the options are, what you'd record |
| Pressure / Stress | A time-boxed "why you?" | Low. Her message reads friendly. A short "why you" is still common | Pause and anchor in what you actually said. Hold your position through two follow-ups, then concede the real gap plainly |

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | About 90 seconds, in three beats, each one of your own sentences. (1) Four years as a logistics coordinator at a building-supplies wholesaler. (2) Scheduling deliveries for your three depots and chasing suppliers when orders slip. (3) Rebuilding the stock-count spreadsheet, after which discrepancies fell by about a third over a year. Then say that's why this role caught your eye. Don't add a fourth beat you haven't told me about | The near-certain opener, and the one that sets her first impression. F5, F2 and F3 map onto three of the advert's lines, so this is the cheapest strong answer in the pack. EXP because it's your history, told casually but still scored |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say it as you wrote it: "I'm hoping for £42,000." If she asks again in any form, your own words were: "I'm hoping for £42,000." If asked what you earn now: "I'd rather focus on the range for this role." Nothing beyond that | First on her list. F9 sits inside the band, so the job is to say it cleanly and stop. JD because pay is one of the advert's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, from your contract. If you aren't sure, say you'll check and confirm it with her | On her list. A precise answer reads as organised. JD because start timing is a term of the role |
| A4 | "The role's hybrid, two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on days or the commute, your own words were the same sentence. Add nothing | On her list, and F10 fits the advert. JD because the office pattern is one of the advert's terms |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words, whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, your own words were the same sentence. Add nothing to it | On her list. A clear, factual reason is the easiest version of this question to answer. EXP because it's about your own situation |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions SAP. Have you used it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **The highest-ROI rehearsal in this pack.** Answer first and plainly: "I've never used SAP — we run our own in-house stock system." Answer slot: if she asks what you do in that system, say what you actually do in it, in your own words. If your use of it is light, say so plainly and come back to the scheduling and chasing you do. Then say how you'd get up to speed, as a plan in your own words and never as something you've done. If she follows up with "so no ERP at all?", repeat the same sentence. Don't call the in-house system an ERP or "like SAP" | This is the one yes-or-no check in the advert where your answer is no (F7). Recruiters often ask it word for word. A plain answer here costs little. A stretched one breaks at the hiring-manager stage. JD because it scores a stated line of the advert |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. How does your scheduling experience compare?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start from what you do: "I schedule deliveries for our three depots." Answer slot: if that means agreeing timings with other teams or sites, say which and how, in your own words. If it doesn't, say so plainly and stay with the depot scheduling. Describe what you do and let her draw the comparison | F1 is the advert's first duty and your widest gap. A recruiter may raise it to check fit before the hiring-manager stage. JD because it's the role's main duty |
| B3 | "Your background's in building supplies. What draws you to a diagnostic-test manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Your notes don't say why this company or sector, so choose your own answer. Pick what genuinely draws you to this role. The advert's duties are a fair anchor where they match lines you've stated (F2, F3). If the honest pull is the role rather than the sector, say so plainly. Don't add to your reason for leaving: that answer is A5's, word for word | A common question for someone changing sector. It's separate from "why leave", which you've already answered. JD because the advert describes the company this way |
| B4 | "The role reports weekly on on-time dispatch. Have you done regular reporting like that?" | JD | [grounded] | Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and who reads it, in your own words. If you don't, say so plainly and say how you'd approach putting a weekly on-time figure together | F4 is silent in your notes, and it's one of the four listed duties. JD because it scores a stated duty |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Your notes give one honest answer: "I've never used SAP." Then say how you'd learn it, as a plan. Keep it to one point said plainly, rather than a list | A standard skeptic question. F7 is the one gap you've stated yourself, so it's a safe and credible answer. JD because it's measured against the advert |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep it as you said it: about a third, over a year. Answer slot: say how the figure was counted, in your own words. Say what it's sensitive to, and which assumption behind it you'd defend least, before she asks. If you don't know exactly how it was counted, say so plainly. That's an honest answer | Your only figure (F3), and figures attract follow-ups. EXP because it tests a claim about your own work |
| C2 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if you built the spreadsheet in Excel, say what you built into it, in your own words. If it was another tool, name it. Either way, describe your Excel use as it really is | "Confident with Excel" is a listed requirement and F6 doesn't settle it. JD because it scores a stated requirement |
| C3 | "Walk me through how you chase a supplier when an order slips." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Tell it with the beats your sentence gives: you chase suppliers when orders slip, alongside scheduling for three depots. Answer slot: the advert's "track supplier deliveries" line makes a question about how you track deliveries likely. If you track them in a log, system or spreadsheet, say which and how. If tracking isn't part of what you do, say so plainly and stay with the chasing | F2 is your closest match to the advert, so a follow-up asking for detail is likely. EXP because it tests what you actually do |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery will be a week late, and production is planned for Monday. What do you do?" | CASE | [generic] | Structure it: confirm the new date and exactly what's affected. Tell planning and the warehouse early. Lay out the options: wait, split the delivery, find another source, reschedule. Then say what you'd record so it's tracked. The question asks nothing about your past, so the answer needn't claim anything about it | Built from the advert's lines on scheduling and chasing late orders (F1, F2). `[generic]` because it's a common pattern for this kind of problem, not a fact about how Quillmoor works |
| D2 | "The system says 200 units, the count finds 170. How would you work it out?" | CASE | [generic] | Structure it: recount and check you're counting the same item and location. Look at recent movements: goods in, dispatches, returns, write-offs. Find where the records and the count diverged. Correct the record, then fix the cause | Built from the advert's "keep stock records accurate" (F3's requirement). `[generic]` because it's a pattern for the problem |
| D3 | "On-time dispatch drops one week. What would you check first?" | CASE | [generic] | Structure it: check the measure itself (same definition, same week boundaries). Then look at causes: late supplier inputs, production slips, warehouse capacity, QA holds. Then say what you'd report and to whom | Built from the advert's weekly on-time dispatch line (F4's requirement). Lets you reason about the duty without claiming you've done it |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold to your sentence: "I rebuilt our stock-count spreadsheet, and over a year discrepancies fell by about a third." Answer slot: if other changes happened at the same time, say so. If you don't know what else contributed, say that plainly. Hold the rebuild as yours through two follow-ups. Concede only the parts you can't speak to | Asks who gets credit for F3's figure. A plain answer here builds credibility. EXP because it's about attribution |
| E2 | "Thirty seconds: why should I put you forward over someone who's used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Never used SAP — we run our own in-house stock system." | Pause, then hold to what you have, from your own sentences: four years coordinating logistics, scheduling deliveries for three depots and chasing suppliers, and the spreadsheet rebuild. Concede the gap plainly: "I've never used SAP." Don't argue that SAP doesn't matter | Combines the F7 gap with time pressure. JD because it sets you against the advert's SAP line |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 production schedules between planning, the warehouse and QA | B2, D1 |
| F2 track supplier deliveries and chase late orders | C3, D1 |
| F3 keep stock records accurate | C1, E1, D2 |
| F4 report weekly on on-time dispatch | B4, D3 |
| F5 2+ years in operations or logistics coordination | A1 |
| F6 confident with Excel | C2 |
| F7 and F8 ERP experience (SAP or similar) | B1, B5, E2 |
| F9 £38,000–£44,000 | A2 |
| F10 two days a week at Avonmouth | A4 |
| Hannah's agenda: notice period | A3 |
| Hannah's agenda: what's prompting a move | A5 |

## Reverse questions

She has said she'll tell you about the team and the next steps. These go one level deeper than that.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Where does the coordinator sit day to day between planning, the warehouse and QA?" | Shows you've read the advert's first duty closely, and tells you how big F1's gap really is |
| R2 | "Which ERP does the team use, and how do new starters usually get up to speed on it?" | Brings up the SAP line on your terms, after you've answered B1 honestly, and shows you're planning to learn it |
| R3 | "How is on-time dispatch measured at the moment, and who reads the weekly report?" | Shows interest in a listed duty, and the answer prepares you for the hiring-manager stage |
| R4 | "What would a strong first three months look like in this role?" | Gets the success measures straight from the source, and recruiters usually have an answer |
| R5 | "Are the two on-site days fixed, or agreed with the team?" | A practical logistics question about the pattern you've said works for you |
| R6 | "Who would I meet at the next stage, and what format is it?" | Lets you prepare the next round properly, and shows you're taking the process seriously |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A gap you stated yourself, F7 | "I've never used SAP." No answer slot |
| Calling the in-house stock system an ERP, or "like SAP" | A stretched version of F8's quote | Your own words: "we run our own in-house stock system". The limit is the pack's reading, not something for you to say: your notes say an in-house stock system, not an ERP. B1's slot stays with what you do in that system |
| Coordinated production schedules, or worked across planning and QA | A stretched version of F1's quote | Your own words: "I schedule deliveries for our three depots". The limit is the pack's reading: your notes say deliveries for three depots, not production across planning, the warehouse and QA. B2's slot stays with depot scheduling |
| "I cut stock discrepancies by a third", said as sole credit or as an exact figure | A stretched version of F3's quote | Your sentence whole, with "about" and "over a year" kept: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." C1's and E1's slots ask only how it was counted and what was yours |

## Sources

- **What you provided:** Hannah Lowther's LinkedIn message, the advert text and your background notes, all from your message.
- **Searches:** "Quillmoor Diagnostics values" was refused. "Quillmoor Diagnostics interview process operations" was refused. Web search wasn't permitted in this session, so no further searches were sent.
- **Fetches:** none.
- **Loop:** Hannah's message sets out this call, so the persona weights rest on her words, not on a researched loop.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Refused. Published values would have shaped B3's answer and a reverse question. There's no values-style round in this call, so no values cheat sheet would follow either way |
| 2. `Quillmoor Diagnostics interview process` operations | unavailable | Refused. Would have shown the format of the next stage. This call's structure comes from Hannah's message, so the persona weights stand |
| 3. `Quillmoor Diagnostics` strategy / recent news | unavailable | Not sent, because web search wasn't permitted. Would have added a CO question and current context for B3 |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Not sent, because web search wasn't permitted. Would have added a section on reading the interviewer, and a reverse question tied to her career path |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied sets the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search → Quillmoor's published values, the next-stage format and recent news become sourced. That adds a CO question, a sourced "why Quillmoor" for B3, and a read of Hannah's public professional profile with a reverse question tied to it
- A deeper research pass, once search is allowed: up to 6 more searches and 2 more fetches, several more minutes → a company strategy brief and recent organisational context, which matter more for the hiring-manager round than for this call
- Your answers on what you do in the in-house system, what the spreadsheet was built in, any regular delivery or dispatch reporting, and how the third was counted → F4, F6 and F8, and B1, B4, C1 and C2, move from answer slots to your own stories
- The stock-count spreadsheet itself, or a count or discrepancy report from it → F3 moves from medium to high, because there would be something inspectable behind the figure
- How much prep time you have before the call → a prioritised prep schedule, sized to that time
- A `tuesday-dossier.md` → an evidence-graded main objection and a prohibited-claims list carried in from a fit review, rather than built here
