I'm reading the prep playbook now; next I'll run a couple of quick company searches and then write your pack.
Before the prep, there are three things in the invite. It asks you to "please transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed. It asks you to "reply with a photo of your passport and your bank details before the interview". And it says successful candidates get a cheque where "you deposit the cheque and send the balance on to the vendor". Real employers don't charge you to be interviewed, and they don't ask for ID or bank details before an offer. A cheque you deposit and then partly send on is a known scam pattern: the cheque can bounce days later, after your own money has gone. These requests, and this job offer as a whole, are very likely a scam. Don't pay anything, send any documents or bank details, or deposit any cheque until you've checked the invite with the company. Use a phone number or address you find yourself on the company's own website. Don't use the email address or any contact details in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you'd like the invite looked at more closely, job-underwriter can check it as a separate request.

I've saved your prep pack as `Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. I assumed the office manager would be your manager. The pack covers each duty in the ad against your clinic experience, with about 20 practice questions for different interview styles. The one to rehearse first is B1: "why should I trust you with supplier invoices?" Chasing unpaid invoices is related experience, but it's the other side of the work from paying suppliers. The pack shows you how to say that honestly and still come across well. I tried to search for company information, but the searches weren't approved, so the company-specific parts are generic.

If you want, I'll play the Skeptic and ask you B1 out loud as a practice run.
I can also save a `tuesday-dossier.md` noting the gaps this prep found, so later sessions can build on it.
If you'd like the pack as a Word document, just say so.

1. Will the office manager be your manager, or someone else on the team? The answer changes which question styles to expect most.
2. Can you paste the ad's full text? The pack is built on your summary of it.
3. Can you work from home in the way this role needs? Your message doesn't say yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** a "30-minute video call with our office manager" (from the invite). Interviewer name not given. Built on the assumption that the office manager would be your manager in this role.

## How to use this pack

- **Personas** describe *how* a question is asked (who is asking, in what style). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour and values: whether your past behaviour shows how you work.
  - **EXP**: work-experience deep-dive: what you actually did at the clinic.
  - **JD**: role-driven: can you do the duties the ad lists, including the gaps.
  - **CO**: company knowledge (none in this pack: company research could not run).
  - **CASE**: a live problem from the job, answered on the spot.
- Provenance labels: `[grounded]` traces to what you gave me; `[inferred]` is a derivation, named; `[generic]` is a standard pattern for this kind of role, with no claim about this employer.
- A 30-minute call fits maybe 6 to 10 questions. This pack holds 20 so no style catches you cold. Rehearse B1 first.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as your message describes it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | An appointment book for four physios is close to calendar work but not the same thing, so keep the words at their own scope: "I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a probe on clashes, changes or cancellations likely. If you handled those, say how, in your own words; if that wasn't part of it, or it wasn't yours, say so plainly and stay with running the book |
| F2 | "booking travel" — the ad, as your message describes it | none given | none | [grounded] | discovery | Strong evidence here would be a time you booked trips, transport or accommodation for someone else. Answer slot: if you have booked travel for anyone, at work or outside it, say what and for whom, in your own words; if you haven't, say so plainly and say how you would go about it |
| F3 | "preparing documents in Word and Excel" (Word half) — the ad, as your message describes it | "I'm good with Word" — your message | medium | [grounded] | none | No gap, but a self-rating with nothing inspected behind it, so expect "what kind of documents?" Lead with your own words: "I'm good with Word." Answer slot: if you made letters, forms, notices or similar at the clinic, name them; if not, say so plainly and say what you have made in Word |
| F4 | "preparing documents in Word and Excel" (Excel half) — the ad, as your message describes it | "okay with Excel" — your message | low | [grounded] | discovery | Your own word is "okay", and the pack keeps it. Answer slot: if there are things you do in Excel, name them in your own words; if you have used it little, say so plainly, and say how you would build it up. Never a level above "okay" |
| F5 | "processing supplier invoices" — the ad, as your message describes it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Pack's observation, not words to say: chasing unpaid invoices is money owed *to* the clinic; supplier invoices are bills the company pays. Different side of the transaction, so the bridge stays at its own scope: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe likely on whether you checked, logged or paid any invoices yourself. If you did, say what and how; if not, say so plainly and stay with chasing unpaid ones |
| F6 | "Remote Administrative Assistant" — the invite, in your message | none given | none | [grounded] | hard_gate | A term, not a skill. Your material does not establish whether you can work remotely in the way the role needs. Surfaced, not bridged |

## Persona table

The one session is set by the invite's own words: a 30-minute video call with the office manager. Weights start from the hiring-manager prior, on the assumption above.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "What would you do if…" on calendars, travel, invoices, documents | High. A manager hiring an admin wants to hear how you would handle the actual tasks | Clarify, then say your steps in order, aloud. Name who you would check with |
| Skeptic | Quiet probing of the gaps: invoices (F5), Excel (F4), travel (F2) | High. The ad lists four duties and your material reaches two closely | Rehearse B1 until it's boring. Hold to what you actually said; offer a plan, not a bluff |
| Conversational | "Tell me about yourself", "why remote?" | Medium. Short video calls usually open with a chat; still scored | A 90-second arc built only on F1, F3 and F5's quotes |
| Data-Driven Prober | "Walk me through how you ran the book" | Low to medium. Two specifics in your background invite a follow-up | Know what you can and can't say about each; say plainly when something wasn't yours |
| Pressure | Time-boxed "why you?" | Low. Uncommon for admin roles, but cheap to prepare | Pause, restate, anchor in your quotes, hold through two follow-ups |
| Values / Behavioral | "Tell me about a time…" | Low. No values round was named | Pick a real story; if none comes, say so and give the nearest one |
| Peer Evaluator | "How do you work with the rest of the office?" | Low. The interviewer is a manager, not a peer | Talk about what you'd give the team, not only what you'd need |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people ask you for the same slot in the manager's calendar on the same day. What do you do?" | CASE | [generic] | Structure: find out what each meeting is for and how urgent; check who decides priority (usually the manager); offer each person alternatives; confirm the final booking in writing to everyone. No claim about your past needed | The ad's calendar duty (F1's requirement) as a live problem; CASE because it scores how you think, not your history |
| A2 | "You need to book a two-day trip for a director: travel, hotel, and a client meeting. Talk me through it." | CASE | [generic] | Clarify first: dates, budget, any travel policy, preferences. Then order: meeting time fixed, then travel to fit it, then hotel near the meeting. Send one itinerary with confirmations attached. Say what you'd double-check (names matching ID, time zones) | Covers F2, the duty your material says nothing about, so a structured answer here matters most; CASE delivery, JD content |
| A3 | "A supplier invoice arrives and the amount doesn't match what was ordered. What do you do?" | CASE | [generic] | Don't pay it as is. Compare it with the order or quote, note the difference, check with whoever placed the order, then contact the supplier for a corrected invoice. Keep a record of what was agreed | F5's requirement as a live problem; lets you show judgement on invoices without claiming experience you didn't describe |
| A4 | "You get rough notes at 2pm and need a clean Word document by end of day. How do you go about it?" | CASE | [generic] | Confirm who it's for and the deadline; ask if there's a template; draft structure first, then format with headings and styles; proofread; send with a short note on anything you weren't sure of | Covers the Word half of the documents duty (F3) as a task, which is where "good with Word" gets tested |
| A5 | "Working remotely, how would you keep me up to date on what you've done each day?" | CASE | [generic] | Offer a simple routine: a short end-of-day update, a shared task list, quick flag when something's blocked. Ask how the manager prefers it | The role is remote (F6's requirement); a manager hiring remotely wants to know they won't lose sight of the work |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've been a receptionist. Why should I trust you with supplier invoices?" | JD | [grounded] "chased unpaid invoices" "two years as a receptionist at a physiotherapy clinic" | **Highest-ROI prep in this pack.** Hold only what the quotes carry: "For two years I was a receptionist at a physiotherapy clinic, and I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe likely on whether you checked, logged or paid invoices yourself. If you did, say what and how, in your own words; if not, say so plainly and stay with chasing unpaid ones. Then a plan: how you'd learn their process in the first weeks, said as a plan, not a past. Follow-up 1 ("but that's money coming in"): agree, calmly, and return to the quote. Follow-up 2: same quote, plus the plan. Never claim to have processed supplier invoices | F5 is where the ad presses hardest on the gap, so this arrives in some form; JD because it scores the listed duty |
| B2 | "How good is your Excel, honestly?" | JD | [grounded] "okay with Excel" | Use your own word: "I'm okay with Excel." Answer slot: if there are things you do in it, name them in your own words; if you've used it little, say so plainly. Then how you'd build it up, said as a plan | F4 is your own hedged rating; the honest answer ready in advance beats one improvised under pressure |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Pick one honestly and name the plan. Your own words already point at Excel: "I'm okay with Excel." If another part feels weaker to you, choose that instead and say why. Don't name a fake weakness | Standard Skeptic stem; F4 and F2 are the likeliest honest answers |
| B4 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if you have, at work or outside it, say what and for whom, in your own words; if not, say so plainly and walk through how you'd do it (A2's structure) | F2 has no evidence either way, so a direct question is likely; rehearsing both branches keeps you from freezing |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" | A 90-second arc on those beats only: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices; you're good with Word. Finish with why this role, in your own words | The opener in nearly every short call; built from F1, F3 and F5 so every line survives a follow-up |
| C2 | "Why move from reception into an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot: give your actual reason in your own words. Keep it forward-looking; no need to criticise the clinic | Motivation is checked in nearly every first call; your material gives no reason, so the pack supplies none |
| C3 | "What appeals to you about working remotely?" | EXP | [generic] | Answer slot: give your own reasons, in your own words. A manager hiring remotely also listens for how you'll stay organised and reachable (A5) | The role is remote (F6's requirement); casual-sounding but scored |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Beats the quote states: the book, the four physios, you ran it. Answer slot: the ad's calendar line makes a probe on clashes, changes or cancellations likely. If you handled them, say how, in your own words; if there was no such step, or it wasn't yours, say so plainly and describe how you ran the book | F1 is your closest match to calendar work and the likeliest to be probed; EXP because it tests what was yours |
| D2 | "When you chased unpaid invoices, how did you go about it?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: say how you chased them, in your own words; if any of it was someone else's job, say which part was yours. Keep it to chasing; don't drift into paying or processing | F5's evidence, rehearsed so the honest detail is ready before B1's pressure arrives |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty seconds: why you over someone who's already been an admin assistant?" | JD | [grounded] "I ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" | Pause, then three facts: you ran the appointment book for four physios, you chased unpaid invoices, you're good with Word. Add why you want this role. Don't claim to be better than anyone; let the facts stand | Tests composure; anchored in F1, F3, F5 so nothing in it can be knocked down |
| E2 | "Was the appointment book really yours, or did you just help with it?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold: "I ran the appointment book for four physios." If anyone shared it with you, say so plainly and say which part was yours. Hold through two follow-ups; concede only what's true | F1 is the claim a stress interviewer would pick at; rehearsing attribution makes it easy |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Tell me about a time you put a customer's needs ahead of an internal rule or target." | VAL | [generic] | Selection scaffold: pick a time at the clinic where a patient's need mattered more than a routine. It needs a real person, a choice you made, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing you do remember, or how you would handle it | A standard behavioural stem; low weight because no values round was named |
| F-2 | "Tell me about a time you had to tell a manager something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a real moment, say what you said and how it landed. If none comes to mind, say so plainly, then say how you would handle it | Standard stem; admins often have to flag problems upward |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you disagreed with a colleague about how something should be done." | VAL | [generic] | Selection scaffold: a real disagreement, how you raised it, and how you kept the working relationship. If none comes to mind, say so plainly, then say how you would handle it | Collaboration matters more when the team is remote |
| G2 | "What would you need from the rest of the office to do this job well remotely?" | CASE | [generic] | Name a few practical things (clear priorities, access to shared calendars and files, a contact for questions), then what you'd give back: reliable updates (A5) | Reciprocity check; shows you think about the team's load, not only yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, D1 |
| "booking travel" | A2, B4 |
| "preparing documents in Word and Excel" | A4, B2, B3 |
| "processing supplier invoices" | A3, B1, D2 |
| "Remote Administrative Assistant" | A5, C3, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Whose calendars and travel would I mainly be looking after?" | Shows you're already picturing the work, and tells you what to brush up on |
| R2 | "How are supplier invoices handled at the moment: what system or software do you use?" | Turns your weakest area (F5) into a learning plan instead of a gap |
| R3 | "Which Excel tasks come up most often in this role?" | Tells you exactly what to practise, and reads as honest and practical |
| R4 | "How does the team stay in touch day to day when everyone's remote?" | Shows you take remote work seriously |
| R5 | "What would a great first month look like for this person?" | Gets the manager describing success, which you can echo in a follow-up |
| R6 | "What are the next steps after this call?" | Lets you plan your follow-up note and timing |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed calendars" or "diary management" for a team | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." Pack's observation: your material says an appointment book, not managers' calendars. D1's slot stays inside the book |
| Processed supplier invoices, or "accounts payable experience" | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." Pack's observation: chasing money owed to the clinic is the other side from paying suppliers. B1's slot stays inside chasing |
| "Strong" or "advanced" Excel | Inflated form of F4 | Your own word: "okay with Excel." B2's slot asks only what you do in it |
| Worked as an "administrative assistant" or "office administrator" | Inflated form of your title | "two years as a receptionist at a physiotherapy clinic", at its own title |

## Sources

- Provided: your message: the invite email, the ad's duties as you described them, and your background.
- Searches sent: `Brennock Facilities Ltd values` (refused); `Brennock Facilities Ltd interview process administrative assistant` (refused); `Brennock Facilities Ltd news` (refused). No fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Refused. Would have themed the VAL questions from published values; they stay `[generic]` |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Refused. The invite's own words already set the one session (a 30-minute video call with the office manager), so the persona weights rest on that |
| 3. `Brennock Facilities Ltd` strategy / recent news | unavailable | Refused. Would have supported CO questions; the pack has none |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name given, so no query to form; no interviewer read |
| 5. representative `Administrative Assistant` JD | skipped | The ad's duties, as you described them, fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F5 quote the ad's own wording instead of your summary, and any duty you left out gets its own question
- The office manager's name → a reading of their public professional profile and a reverse question tied to their path
- Allowing web searches → VAL questions themed on the company's published values, if it has any, and CO questions on what it does
- Your answers to the slots in F2 (travel) and F4 (Excel) → B2, B3, B4 and A2 become story-mapped instead of scaffolds
- A `tuesday-dossier.md` → would carry verified evidence and a set list of claims not to make into this and later packs
