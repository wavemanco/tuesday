Quick update: I'm building your prep pack now. There's also something in the invite you need to see before the interview, and I'll put it at the top. I'm doing a couple of quick searches first.
I need to flag something in the invite before the prep. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed. It also asks you to "reply with a photo of your passport and your bank details before the interview". And it says successful candidates get a cheque, where "you deposit the cheque and send the balance on to the vendor". Asking for a fee, ID or bank details before any job offer is a known scam pattern. So is a cheque you deposit and then send part of on to someone else: the cheque often bounces days later, and the money you sent is gone. These requests are very likely a scam, and the job as described may be too. The email may not be from who it says it is. Please don't pay anything, send your passport or bank details, or deposit any cheque until you've checked the invite with the company. Use contact details you find yourself on the company's own website, not the email address or anything else in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed properly, job-underwriter can check it as a separate request.

**What to expect:** a short call of about 6 to 10 questions. They'll mostly be practical "what would you do if…" tasks taken from the ad's four duties: calendars, travel, Word/Excel and supplier invoices. You'll probably also get "tell me about yourself" and a probe on your weakest areas.

**How to prepare:**
- **Rehearse "what experience do you have with supplier invoices?" first.** This is question B1 in the pack. The honest answer is the one you gave me: you chased unpaid invoices at the clinic. Chasing invoices isn't the same as processing a supplier's invoices, so don't claim that. Add a short plan for how you'd learn their process.
- **Keep your own word for Excel.** You said "okay", so say "okay". An honest rating with a plan to improve holds up better than "good" when they ask a follow-up.
- **Use the appointment book as your strongest example.** You ran it for four physios, and it's the closest thing in your background to managing calendars. Describe how you actually ran it. Don't call it managing calendars.

The full prep pack is in `brennock-facilities_remote-administrative-assistant_interview_pack.md`. It has 21 practice questions with answer guidance, a fit table, questions you can ask them, and claims to avoid. I tried two web searches about the company, but search permission wasn't granted. So the pack has no company facts, and for "what do you know about us?" it tells you to use only what you've read on the company's own website. I built it assuming the office manager would be your manager, since the invite doesn't say.

I can play the sceptical interviewer on B1 for a live practice round.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Would the office manager be your line manager? The answer changes which question styles the pack leans on. And can you paste the full ad text? Any duty beyond the four you listed would get its own practice question.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** a 30-minute video call with the office manager (the invite's words). It doesn't say whether the office manager would be your manager, so this pack treats the call as a hiring-manager round.

## How to use this pack

- **Personas** describe how a question is asked, meaning who is asking and in what style. **Types** describe what is being scored.
- Type key:
  - **VAL**: values or behaviour. Does how you've acted at work match how they want people to work?
  - **EXP**: work-experience deep-dive. Does what you said about your past hold up when questioned?
  - **JD**: role-driven. Can you do the duties the ad lists?
  - **CO**: company knowledge. Have you done your homework on them?
  - **CASE**: live problem. Can you think through a task from the job out loud?
- Thirty minutes usually means 6 to 10 questions. Rehearse B1 first, then A1 to A3, then C1. The rest is insurance.
- The guidance is scaffolding, not a script. Say it in your own words.
- Provenance labels show how far each line can be trusted:
  - `[grounded]` rests on your own words or the ad's duties as you gave them.
  - `[inferred]` is this pack's own derivation.
  - `[generic]` is a common pattern for admin roles, not a fact about this employer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as your message gives it | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says the appointment book, not anyone's calendar, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a probe on how you ran the book likely. If you booked, moved or confirmed appointments yourself, say how, in your own words. If a step wasn't yours, say so plainly and stay with running the book |
| F2 | "booking travel" — the ad, as your message gives it | none given | none | [grounded] | discovery | Your material doesn't show travel booking either way. Answer slot: if you have booked travel for work or for anyone else, say what and how, in your own words. If you haven't, say so plainly and say how you would go about a first booking |
| F3 | "preparing documents in Word" — the ad, as your message gives it | "I'm good with Word" — your message | low | [grounded] | discovery | "Good with Word" is a self-rating, and the interviewer will want to know what you've made with it. Answer slot: name the kinds of documents you have actually prepared in Word, in your own words. If you can't think of a specific one, say so plainly and stay with what you use it for |
| F4 | "preparing documents in ... Excel" — the ad, as your message gives it | "okay with Excel" — your message | low | [grounded] | discovery | Keep your own word, "okay", and don't upgrade it. Answer slot: say what you actually use Excel for, in your own words. If it's very little, say so plainly and say how you would build up the rest |
| F5 | "processing supplier invoices" — the ad, as your message gives it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says you chased unpaid invoices. It says nothing about processing a supplier's invoices, and those are different sides of a payment. Words: "I chased unpaid invoices at the clinic." Answer slot: if chasing them meant keeping a record of what was owed and what came in, say how you kept it. If it didn't, say so plainly and describe how you chased them |

## Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "What would you do if…" tasks from the job itself: diary clashes, a trip to book, an invoice that doesn't match | High. Someone hiring for a role tests whether you can do the work, and the ad's four duties are easy to turn into live problems. The 30-minute length favours quick scenarios over long stories | Clarify first, then say your steps in order, then say how you'd confirm the job is done |
| Skeptic | Quiet probing of the gaps between front desk and remote admin, especially invoices and Excel | High. F4 and F5 are where your evidence and the ad's duties sit furthest apart, so an attentive interviewer goes there | Rehearse B1 until it's boring. Hold on your own words, give no more than they carry, and finish with a concrete plan for learning |
| Conversational | A friendly opener such as "tell me about yourself", plus "what do you know about us" | Medium. Most short calls open this way, and it is still scored | A 90-second arc built from C1 |
| Data-Driven Prober | "How exactly did you…" follow-ups on the appointment book and the invoice chasing | Low to medium. There are no figures in your material to probe, but details can still be asked for | Know what you can and can't say. "I don't know the number" is an honest answer |
| Pressure | Time-boxed "why you" questions and a challenge to your background | Low. Uncommon in admin hiring, but one sharp question is possible | Pause, restate the question, hold through two follow-ups, then concede only what's real |
| Values / Behavioural | "Tell me about a time…" questions | Low to medium. There's no values round in a single 30-minute call, but one behavioural question is common | Choose a real time, or say plainly that none comes to mind |
| Peer Evaluator | How you work with people you can't see, since the role is remote | Low. The office manager isn't a peer, but remote teamwork questions often come up anyway | Talk in principles: how you keep people informed and how you hand things over |

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your manager is travelling and has two meetings booked at 10am tomorrow. What do you do?" | CASE | [generic] | Structure it. First find out which meeting matters more, or ask. Then contact the other party with alternative times, update the calendar, and confirm with your manager in one short message. Mention checking time zones and travel time if they're on the move. The question needs no claim about your past, so the guidance makes none | A live problem built on the ad's calendar duty, and the likeliest case in a short call. CASE because it scores how you reason, not your history |
| A2 | "Book a two-day trip to another city for a director who has a 9am meeting on day one. Talk me through it." | CASE | [generic] | Clarify first: budget, preferences, and whether there is a company travel policy. Then the order: transport that arrives in good time, a hotel near the meeting, everything entered in the calendar with confirmations attached, and one summary sent to the director. Close by saying you'd check whether a cheaper or more flexible option fits the policy | Tests the travel duty live, which matters because F2 has no evidence either way. CASE delivery, JD content |
| A3 | "An invoice comes in from a supplier and the amount doesn't match what was ordered. What do you do?" | CASE | [generic] | Structure it: compare the invoice with the order or quote, check whether anything was added or delivered differently, don't pass it for payment yet, contact whoever placed the order, then contact the supplier, and note what you did and what was agreed. Ask who signs off payments in their process. The question needs no claim about your past | The ad's invoice duty, asked as a decision. It lets you show sound judgement on the area where F5 is thinnest without claiming experience you didn't describe |
| A4 | "Here's a messy list of supplier payments. Can you have a tidy Excel summary ready by end of day? How would you go about it?" | CASE | [generic] | Clarify what the summary is for and who will read it. Then: clean up the list, sort or group it, add totals, and check the totals against the source. If one of those steps goes beyond what you do in Excel today, say which one and how you'd find out, rather than skipping it | The ad names Excel, and F4 is a low-confidence row. Rehearsing an honest structure here beats bluffing a function name |
| A5 | "Three people each ask you for something urgent at the same moment. How do you decide the order?" | CASE | [generic] | Structure it: ask each person for the real deadline, sort by impact and deadline, tell everyone when you'll get to their request, and escalate a clash you can't resolve to your manager. Remote twist: write the update down so no one is left guessing | Juggling requests sits underneath every duty in the ad. A common short-call case |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role processes supplier invoices. What experience do you have with that?" | JD | [grounded] "chased unpaid invoices" | **The highest-ROI rehearsal in this pack.** Hold only what your words carry: "At the clinic, I chased unpaid invoices." Answer slot: if chasing them meant keeping a record of what was owed and what came in, say how you kept it, in your own words. If it didn't, say so plainly and describe how you chased them. Then a plan, said as a plan and never as a past: how you'd learn their invoice process in your first weeks. Hold through two follow-ups by coming back to what you did, never by adding to it | F5 is where the ad's duty and your evidence differ most, so this objection is likely in some form. JD because it scores a listed duty |
| B2 | "How would you rate your Excel?" | JD | [grounded] "okay with Excel" | Use your own word: "okay". Answer slot: say what you actually use it for, in your own words. If it's little, say so plainly. Then name one concrete step you'd take to improve, as a plan. Don't name functions you haven't used | F4. A self-rating gets tested on the spot, and an honest "okay" with a plan beats a "good" that falls apart at the first follow-up |
| B3 | "The job includes booking travel. Have you done that before?" | JD | [grounded] | Answer slot: if you have booked travel for work or for anyone else, say what and how, in your own words. If you haven't, say so plainly, then walk through how you'd do it, as in A2 | F2 has nothing in your material either way, so the honest answer has to come from you. Rehearsing both branches keeps you from freezing |
| B4 | "Why do you want to move into remote admin?" | EXP | [generic] | Give your real reason, in your own words. It needs to be something true about what draws you to this kind of work, not only what you're leaving. Keep it to three or four sentences and finish on the role's duties | A standard motivation probe. Nothing in your material states your reason, so the pack doesn't supply one |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word" "okay with Excel" | Your own words already rank these: you're good with Word and okay with Excel. Name Excel, then give one concrete learning step, as a plan. Don't pick a fake weakness | F3 and F4 together give you a truthful answer, and a candid one is what this question rewards |

### C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices; and why this role is the next step for you, in your own words. Stop there and let them ask | The near-certain opener. Its three beats are exactly what F1 and F5 carry and nothing more |
| C2 | "What do you know about us?" | CO | [generic] | Say only what you have read on the company's own website, in your own words. If you found little, say so briefly and talk about what drew you to the role as advertised: the four duties | Company research didn't run for this pack (see Sources), so there are no company facts to give you. Inventing them would be worse than saying little |
| C3 | "What did a normal day look like at the clinic?" | EXP | [grounded] "ran the appointment book for four physios" "chased unpaid invoices" | Build it from what you did: the appointment book for four physios and chasing unpaid invoices. Answer slot: if other tasks filled your day, name them in your own words. If those two were the core, say so | A casual question that is still scored, and a chance to show the routine behind F1 and F5 |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Four physios is a lot of diaries. How did you run the appointment book?" | EXP | [grounded] "ran the appointment book for four physios" | Start from the quote. Answer slot: if you used a booking system, name it. If it was paper or something else, say so. If you handled changes and cancellations, say how, in your own words. If a part of it wasn't yours, say so plainly | F1's probe. The ad's calendar duty raises it, and a concrete "how" is what makes the transfer believable |
| D2 | "How did you chase unpaid invoices, and how often did it work?" | EXP | [grounded] "chased unpaid invoices" | Say how you chased them, in your own words. Answer slot: if you know how many got paid, say so and how you know. If you don't know, say that plainly, because "I don't know the number" is an honest answer. Never estimate one on the spot | F5's detail probe. A figure you can't stand behind costs more than having none |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you?" | JD | [grounded] "ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" | Pause, then three beats in your own words: you ran the appointment book for four physios, you chased unpaid invoices, and you're good with Word. Finish with one sentence on why this role. Don't rush to fill the minute | A time-boxed version of C1. It tests composure, and your three quoted facts are enough to hold it |
| E2 | "Running an appointment book isn't the same as managing someone's calendar, is it?" | EXP | [grounded] "ran the appointment book for four physios" | Hold, then concede. Hold: "I ran the appointment book for four physios." If pushed a second time, hold the same sentence. Concede only the difference, as the pack's limit and your plan: it was an appointment book, and you'd learn how this team runs its calendars. Don't claim calendar work you didn't describe, and don't fold on the book | F1's gap stated as a challenge. The hold uses only F1's quote, so it survives a second follow-up |

### G — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to tell someone something they didn't want to hear." | VAL | [grounded] "chased unpaid invoices" | Choose a real time. Chasing unpaid invoices may give you one, but only if a particular conversation comes to mind. The story needs who it was, what you said, how you kept it polite, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioural stem. F5 is the likeliest place for a true story, but the pack doesn't supply the conversation |
| G2 | "Tell me about a mistake you made at work and what you did about it." | VAL | [generic] | Pick a real, small mistake: what happened, what you did to fix it, and what you changed afterwards. If no such time comes to mind, say so plainly, then say how you would handle one | Almost every admin interview asks some version of this. Your material holds no such story, so this is a way to choose one |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Working remotely, how do you keep people updated when you can't walk over to their desk?" | CASE | [generic] | In principles: a short written update when something changes, one place where tasks are tracked, a quick check-in rather than guessing, and a reply within a set time. The question needs no claim about your past | Every remote role asks this in some form, and nothing in your material shows remote work, so a structured answer is the honest route |
| H2 | "Tell me about a time two people you supported needed the same thing from you at once." | VAL | [grounded] "ran the appointment book for four physios" | If a real time from running the appointment book for four physios comes to mind, tell it: who, what each needed, what you did, how it ended. If none does, say so plainly, then say how you'd handle it, as in A5 | Being shared between colleagues is the core of the role. F1 may hold a true story, but the pack doesn't supply one |

### Requirement coverage

| Requirement (the ad, as your message gives it) | Covered by |
|---|---|
| "managing calendars" | A1, D1, E2, H2 |
| "booking travel" | A2, B3 |
| "preparing documents in Word and Excel" | A4, B2, B5, E1 |
| "processing supplier invoices" | A3, B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like in this role, and how is it split between calendars, travel, documents and invoices?" | It shows you read the ad closely, and the answer tells you which of your rows to stress |
| R2 | "Which calendar, document and invoicing software does the team use day to day?" | It's practical, and it shows you're thinking about being useful quickly |
| R3 | "What would a great first month look like for whoever takes this role?" | It invites the interviewer to describe success, and it signals you're thinking past the interview |
| R4 | "How do people on the team usually stay in touch when everyone's remote?" | It links to H1 and shows you take the remote side seriously |
| R5 | "What's the next step after today's call?" | Knowing the stages ahead tells you what to prepare next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries for four physios | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's own observation: your material says the appointment book, not calendars. D1 and E2 stay inside the book |
| Processed supplier invoices, or accounts-payable experience | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices at the clinic." The limit is the pack's own observation: chasing is not processing. B1's slot stays inside the chasing |
| Good or strong with Excel | Inflated form of F4 | Your own word, "okay with Excel". B2's slot asks only what you use it for |
| Advanced or expert in Word | Inflated form of F3 | Your own words, "I'm good with Word", and nothing stronger |

## Sources

- Provided: the interview invite and your message, which includes the ad's duties as you gave them.
- Search "Brennock Facilities Ltd values": refused (web search permission not granted in this session).
- Search "Brennock Facilities Ltd news": refused (web search permission not granted in this session).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. Published values would have themed G1 and G2 and given C2 something to draw on |
| 2. `Brennock Facilities Ltd interview process` admin | skipped | The invite's own words fix the loop: one 30-minute video call with the office manager |
| 3. `Brennock Facilities Ltd` strategy or recent news | unavailable | The search was refused. Recent company context would have supplied a CO question and grounded C2 |
| 4. Interviewer name | n/a | No name was given, only "our office manager", so there was no query to form. The interviewer read is absent |
| 5. Representative administrative assistant JD | skipped | The ad's four duties, as your message gives them, fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full ad text → rows F1 to F5 checked against the ad's complete list, and any requirement beyond the four duties gets its own question
- Whether the office manager would be your line manager → persona weights recomputed and the Skeptic bank resized
- Your CV → more of your own sentences to quote, so more answers become story-mapped instead of scaffolds
- Your own answers on travel booking, the documents you've made in Word, and what you use Excel for → F2, F3 and F4 regraded, with B2, B3 and D1 story-mapped
- Web search allowed in this session → research targets 1 and 3 can run, giving C2 and a CO question something real to stand on
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company brief for sharper CO and CASE questions
- A `tuesday-dossier.md` → gap strategies and claims to avoid carried in from an earlier evaluation, so the highest-ROI objection is drawn from evidence instead of inferred
