I'm preparing your recruiter-screen pack now. Next I'll run a few quick public searches on Quillmoor Diagnostics and Hannah's professional profile.
I've written your prep pack for Thursday's call with Hannah: **quillmoor_operations-coordinator_interview_pack.md**. It's built only from the advert, Hannah's message and your notes. My web searches on Quillmoor and Hannah were refused, so nothing in it comes from outside research.

Today is Thursday 26 November. If the call is this afternoon, here's what to focus on:

- **B1, the SAP question.** This is the most useful thing to rehearse. Say it plainly and early: "I haven't used SAP. We run our own in-house stock system." Don't call your system an ERP or "similar" to SAP; let Hannah judge that. If she asks how you'd pick up SAP, answer with a plan for learning it. The advert lists ERP as "a plus", not a requirement, and you can point that out.
- **Her four topics.** For pay, the hybrid pattern and your reason for moving, the pack gives you back your own words with nothing added. For example, on pay: "I'm hoping for £42,000." If she asks what you earn now, you can say "I'd rather focus on the range for this role."
- **Notice period.** You haven't told me yours, so check what it actually is before she rings.
- **The "about a third" figure (C1, D1).** Keep it exactly as you said it: discrepancies fell by about a third over a year after you rebuilt the spreadsheet. Don't round it to 33% or say you "cut" it. If you don't know exactly how it was counted, saying so is fine.

If you'd like a practice run, I can play Hannah, gently probing your gaps, on B1. I can also save a `tuesday-dossier.md` that records the gaps this prep found, for later rounds. If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call. **Interviewer:** Hannah Lowther, Talent Partner. She rings your mobile on Thursday at 2pm.
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move". After that she'll tell you about the team and the next steps.

## How to use this pack

Two axes. **Personas** describe how a question is asked: the register, the pace, the follow-ups. **Types** describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words.

| Tag | What it scores |
|---|---|
| VAL | Past behaviour against the company's published values |
| EXP | Whether what you said about your experience holds up, and what was actually yours |
| JD | Whether you can do the job as the advert lists it, gaps included |
| CO | Homework: what you know about the company and why you want it |
| CASE | A live problem from the role, reasoned out loud |

Question IDs go by persona: A, B, C, D, E, G. F is kept for fit-snapshot rows. An **answer slot** is an instruction for the call, not a question for you to answer here. It has two branches, and either one, given honestly, is a good answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material describes delivery scheduling for three depots. It doesn't describe production scheduling, or work across planning, a warehouse and QA, so the words stay at your scope: "I schedule deliveries for our three depots." Answer slot: this line in the advert makes a probe on who you coordinate with likely. If you agree schedules with other teams, say which ones and how, in your own words. If the scheduling is yours alone, or no such coordination happens, say so plainly and describe how you schedule |
| F2 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap. This is a line in your message with nothing behind it to check, so expect a probe (E1). Lead with it in your own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "chase suppliers when orders slip" — your message | low | [inferred] | discovery | Chasing slipped orders touches tracking but doesn't show whether you track inbound deliveries as a routine. Answer slot: if you keep track of supplier deliveries before they slip, say how, in your own words. If you don't, say so plainly and stay with the chasing |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap. The figure is the most quotable thing you have, so expect it to be probed (C1, D1). Keep it exactly as you said it: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. "About" and "over a year" stay attached |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material doesn't show dispatch reporting either way. Answer slot: if you report on deliveries or dispatch performance, say what and how often, in your own words. If you don't, say so plainly and say what you'd want to know first in order to build the report |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it in exactly those terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | A rebuilt spreadsheet touches the requirement, but your material doesn't say what it is built in or which features you use. Answer slot: if it's Excel, name what you actually use in it, in your own words. If it isn't, say what it is built in and stay with the rebuild |
| F8 | "ERP experience (SAP or" — advert | "Never used SAP" — your message | none | [grounded] | capability | You've said this yourself, so the words are yours: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "or similar) a plus" — advert | "we run our own in-house stock system" — your message | low | [inferred] | transferability | The quote says the company runs the system. It doesn't say what you do in it, or whether it is ERP-like, so the words stay there: "We run our own in-house stock system." Answer slot: if you use it day to day, say for what, in your own words. If your use of it is limited, say so plainly. Whether it counts as "similar" is for Hannah to judge, not for you to claim |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advertised range. The words are yours and need nothing added: "I'm hoping for £42,000." |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised pattern is inside your stated limit. Your words, kept whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

## Persona table

The loop for this session comes from Hannah's own message: one 30-minute phone call, run by her, with the topics she listed. The weights below rest on that, not on a guessed pattern.

| Persona | How it shows up on this call | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, chatty, logistics in a light register. This is the call's main mode | High: a recruiter screen, and Hannah named four logistics topics | Treat every casual question as scored. Have the 90-second arc ready (A1). Your logistics answers are your own words, with nothing added |
| Skeptic | Gentle probing of the gaps and of "why leave, why here" | High: recruiter screens check for knockouts, and F8 is the clearest one | Rehearse B1 until it's boring. Say the limit plainly, with no bluffing |
| Data-Driven Prober | "How was that third counted?" | Mid: F4's figure is the one number in your material, and figures get probed | Know what you can and can't say about how it was counted. Saying plainly that you don't know is allowed |
| Pressure | Time-boxed or "how much was you" follow-ups | Low: not a recruiter's usual register, but possible on F4 and F8 | Pause, restate, hold through two follow-ups, then concede only what's real |
| Values / Behavioural | "Tell me about a time…" prompts themed on advert lines | Low: Hannah's message names no values round, and the company's values page couldn't be checked | Pick real instances. If none comes to mind, say so |
| Case / Strategist | "What would you do if…" set in the role | Low: possible as a light screening question | Clarify, then structure, then say who you'd tell |
| Peer Evaluator | — | Very low, so no bank: nobody from the team is on this call | — |

## Question banks

### A. Conversational (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots" "chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc in three beats, all taken from those quotes. (1) Four years as a logistics coordinator at a building-supplies wholesaler. (2) You schedule deliveries for three depots and chase suppliers when orders slip. (3) You rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Then stop and let her steer. Leave the reason for moving to B2, for when she asks | Every recruiter screen opens with this. F6, F1, F2 and F4 are the rows it draws on. EXP because she is checking that the story is consistent |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Your own words: "I'm hoping for £42,000." Nothing else. If asked what you earn now: "I'd rather focus on the range for this role." | Her first named topic (F10). JD because pay is one of the listed job's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period. Your material doesn't state one, so check it before the call | Her second named topic. JD because start timing is one of the job's terms. The label rests on her message, not on anything you said |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about more site days, your own words were: "two days at Avonmouth is fine, but I wouldn't want more than three." Nothing added | Her third named topic (F11). JD because the office pattern is a stated term |
| A5 | "What do you use Excel for day to day?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Lead with the rebuild in your own terms. Answer slot: the advert's "confident with Excel" makes this probe likely. If the spreadsheet is in Excel, name what you actually use, in your own words. If it isn't, say what it's built in plainly and stay with the rebuild | F7 is a stated requirement with only adjacent evidence. A casual question about a listed requirement is still scored |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions ERP, SAP or similar. What's your experience there?" | JD | [grounded] "Never used SAP" "we run our own in-house stock system" | **The highest-ROI prep in this pack.** Say the limit before she has to dig: "I haven't used SAP. We run our own in-house stock system." Answer slot: if you use that system day to day, say for what, in your own words. If your use is limited, say so. Follow-up 1, "So no ERP at all?": repeat both sentences and leave the "similar" call to her. Follow-up 2, "How quickly could you pick it up?": give a plan, not a past, such as asking what training Quillmoor gives and learning alongside someone who uses it. Follow-up 3, "Would that slow you down?": if you expect a learning curve, say so plainly. The advert lists ERP as "a plus", and you can quote that. Never call the in-house system an ERP | F8 is the one stated negative against the advert, and recruiters screen on listed tools, so this comes up in some form. JD because it scores a listed requirement |
| B2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words, kept whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, give those words again. Nothing added, nothing taken away | Her fourth named topic. EXP because the reason for leaving is part of your work history, and she checks that it's consistent |
| B3 | "Why Quillmoor, and why a manufacturer?" | CO | [generic] | Selection scaffold: pick one or two advert lines you genuinely want to do and say why, in your own words. Examples are "coordinate production schedules between planning, the warehouse and QA" or "report weekly on on-time dispatch". Keep it about this role. Your reason for moving is answered in B2 and doesn't need repeating or extending here. If nothing specific draws you beyond the role itself, say what about the role fits and leave it there | A standard screen question. `[generic]` because company research couldn't run, so the guidance can't draw on anything about Quillmoor beyond the advert |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never used SAP" | The honest answer is already in your material: "I haven't used SAP." Then the plan from B1. One weakness, stated plainly, is a complete answer | A common Skeptic opener that F8 answers directly. JD because it asks you to grade yourself against the advert |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Keep the quote's own words: "about a third", "over a year". Answer slots, each in your own words: how the discrepancies were counted; what else could have moved the number; the assumption behind it you'd defend least; which part was yours beyond the rebuild. "I don't know exactly how it was counted" is an honest answer. Never round it to a percentage | F4 holds the only figure in your material, so this is the defend-the-number rehearsal. EXP because it tests attribution |
| C2 | "How do you schedule deliveries across your three depots?" | EXP, JD | [grounded] "I schedule deliveries for our three depots" | Describe how you do it, in your own words. Answer slot: the advert's planning/warehouse/QA line makes a follow-up on who else feeds the schedule likely. If other teams do, say who and how. If no such coordination happens, say so plainly and describe your own process | F1 is the row closest to the role's main duty. EXP first because it's about what you do now, JD second because it maps to "Coordinate production schedules" |
| C3 | "The role reports weekly on on-time dispatch. Have you reported anything like that?" | JD | [generic] | Answer slot: if you report on delivery or dispatch performance, say what and how often, in your own words. If you don't, say so plainly, then say what you'd want to know first: what counts as on time, where the dispatch data lives, and who reads the report | F5 is a listed duty that your material doesn't show. `[generic]` because the plan is a pattern for the problem, not a fact about you |

### D. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That third: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the quote carries: you rebuilt the spreadsheet, and the discrepancies fell over the following year. Answer slot: if other changes also played a part, say what they were, in your own words. If you don't know, say so. Hold through two follow-ups by going back to the rebuild, and never claim you "cut" the figure | F4 again, in a harder register. EXP because it's an attribution check |
| D2 | "Sixty seconds: why should I put you through over someone who's used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" "Never used SAP" | Pause, then: "I haven't used SAP." Then three facts in their own words: four years as a logistics coordinator, chasing suppliers when orders slip, and the spreadsheet rebuild with discrepancies falling by about a third over a year. Close by naming the advert lines those match. Let her draw the conclusion | F8 against F6, F2 and F4. JD because it's a comparison on listed requirements |

### E. Values / Behavioural (2)

No values round was detected, so these are behavioural prompts themed on advert lines, not on published values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier order slipped." | EXP, JD | [grounded] "chase suppliers when orders slip" | Your quote describes a routine, not a specific event, so pick one real instance you remember. The beats it carries: the order slipped and you chased the supplier. Answer slot: what happened next, and what part was yours, in your own words. If no single instance comes to mind, say so plainly and describe how you usually chase | F2. The theme comes from the advert's "chase late orders". EXP first because it tests a real instance |
| E2 | "Tell me about a time different people wanted different things from a schedule." | JD, EXP | [generic] | Selection scaffold: pick a time two parties' needs clashed over timing. It needs a clear clash, a decision, and an outcome you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is scheduling deliveries for three depots, or how you would handle it | The theme comes from the advert's planning/warehouse/QA line (F1). `[generic]` because no quote carries a clash story |

### G. Case (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A supplier says a delivery a production run depends on will be three days late. What do you do?" | CASE, JD | [generic] | Structure: what you'd confirm first (exact date, partial delivery, stock on hand); who you'd tell (the advert names planning, the warehouse and QA); options (reschedule the run, expedite, an alternative source); and what you'd record and follow up. No claim about your past is needed | A live version of "track supplier deliveries and chase late orders" (F2, F3). `[generic]` because it's a problem pattern, not a fact about Quillmoor |
| G2 | "On-time dispatch dropped this week. How would you find out why before the report goes out?" | CASE, JD | [generic] | Structure: check the definition and the data first; split late dispatches by cause (stock, production, QA release, carrier); look for one dominant cause; report what you know and what you're still checking | A live version of "report weekly on on-time dispatch" (F5). CASE because it's reasoned out loud |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | C2, E2 |
| "track supplier deliveries and chase late orders" | E1, G1 |
| "keep stock records accurate" | C1, D1 |
| "report weekly on on-time dispatch" | C3, G2 |
| "2+ years in operations or logistics coordination" | A1, D2 |
| "confident with Excel" | A5 |
| "ERP experience (SAP or similar) a plus" | B1, B4, D2 |
| "£38,000–£44,000" | A2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol." | A4 |
| Notice period, from Hannah's agenda | A3 |
| What's prompting a move, from Hannah's agenda | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Are the two Avonmouth days fixed days, or does it vary week to week?" | It's practical diligence on the pattern you'll actually work, asked before you're committed |
| R2 | "Which ERP or stock system does the team use, and how do new starters usually learn it?" | It shows you take the advert's "a plus" seriously, and the answer tells you what the ramp looks like |
| R3 | "Who would I be working with most day to day: planning, the warehouse or QA?" | It's tied to the advert's own wording, and it tells you where the coordination load sits |
| R4 | "What does a good on-time dispatch week look like at the moment, and what usually gets in the way?" | It shows you read the reporting duty, and it's a question a recruiter can pass to the hiring manager |
| R5 | "What would make someone successful in this role in the first three months?" | It gives you the scoring sheet for the next round |
| R6 | "Is this a new role or a replacement?" | The answer changes what the hiring manager will expect from day one |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F8 | "I haven't used SAP." No slot |
| The in-house system is an ERP, or "similar" to SAP | Inflated form of F9 | "We run our own in-house stock system." It's the pack's observation, not yours, that the quote says the company runs it and nothing more. The "similar" call is Hannah's |
| Has coordinated production schedules with planning, the warehouse and QA | Inflated form of F1 | "I schedule deliveries for our three depots." C2's slot stays inside your scheduling |
| Cut stock discrepancies by 33% | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Keep "about", "fell" and "over a year" |
| Advanced or expert in Excel | Inflated form of F7 | "I rebuilt our stock-count spreadsheet." A5's slot asks only what it's built in and what you use |
| Any pay figure, range or floor other than the one you gave, or your current pay | Your stated figure, F10 | "I'm hoping for £42,000." If asked what you earn now: "I'd rather focus on the range for this role." |
| Open to more than three days on site | Contradicted by your quote, F11 | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

## Sources

- Provided: the advert (pasted); Hannah Lowther's LinkedIn message (pasted); your background notes (pasted).
- Search "Quillmoor Diagnostics values": refused.
- Search "Quillmoor Diagnostics Avonmouth Bristol news": refused.
- Search "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused.
- No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Every call was refused. It would have given value names for theming the E bank, and B3 something specific to say |
| 2. Quillmoor Diagnostics interview process, operations | skipped | Hannah's message already fixes this session: one 30-minute phone call with her, on topics she named |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Every call was refused. It would have grounded B3 and given one company-specific reverse question |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Every call was refused. It would have added a section on reading the interviewer and a reverse question tied to her path |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search → targets 1, 3 and 4 run. B3 and the reverse questions can then draw on Quillmoor's own values and news, plus a short read of Hannah's public professional profile.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the company's direction, recent changes at the Avonmouth site, and sharper "why Quillmoor" material for later rounds.
- Your actual notice period → A3 carries your own words instead of an instruction.
- What your stock-count spreadsheet is built in, what you do in the in-house system, whether you report on dispatch or delivery performance, and how the "about a third" was counted → F3, F5, F7 and F9, and A5, B1, C1 and C3, move from answer slots to your own quoted words.
- Your CV → more evidence lines for the fit snapshot, and possibly a stronger bridge on F1.
- A tuesday-dossier.md → verified evidence and a named objection carried in from earlier work. It isn't needed for this pack.
- If a hiring-manager round is booked after this call → a second pack weighted for that round, with the same fit snapshot.
