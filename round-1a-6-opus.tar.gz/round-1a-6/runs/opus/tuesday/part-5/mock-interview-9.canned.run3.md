No dossier present. Reading the referenced files.
I've finished your prep pack for the Halvering panel. One note first: your resume included your Social Security number. Interview prep doesn't need it, and I haven't used it or repeated it anywhere. Keep it off anything you send the district unless HR asks for it through their official forms.

The pack is saved as `Halvering_fourth-grade-teacher_interview_pack.md`. I built it from your invite, your resume and the district's public pages: its beliefs, its teacher-hiring page, its new literacy plan and the principal's speaker profile. You didn't include the full job posting, so apart from the license, the job requirements come from a typical fourth-grade posting.

- **Practice this one first (A1):** "You've never taught fourth grade — why you?" Say the gap yourself first. Then give your six years of third grade, then a concrete plan for getting up to speed. Don't add anything that makes the gap look smaller.
- **License:** your Illinois license with the grades 1–6 elementary endorsement meets the invite's requirement. Grades 1–6 includes fourth grade.
- **Your best match:** the district plans a new grades 3–5 reading curriculum for fall 2027. Your 2024 curriculum move is your closest experience, and B2 covers it. Keep it to what you said: your grade level's move, not the whole school's.
- **The principal:** her background is nine years as a reading specialist, and in 2025 she gave a talk on weekly reading conferences. Expect detailed questions about how you teach reading. Reverse question R1 asks her about the talk directly.
- **Two lines the pack won't coach:** that you've taught fourth grade, or that you've been a team lead. You told me neither is true, and the pack gives you plain wording for both.

Where the pack doesn't know what you did, it gives you an "answer slot" instead of an answer. Those cover your reading routines, how you use assessment data and how you talk with families beyond the weekly email. Fill them only with what's true.

If you want to practice out loud, I'll play the skeptical interviewer on A1, the most important question in the pack.
I can also save a `tuesday-dossier.md` with the gaps this prep turned up, so you can use it in later sessions.
If you'd like the pack as a Word document, I'll convert it.

Do you have the full posting text for this job? With it, seven of the requirement rows would be based on the actual job instead of a typical one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Format:** 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren (the hiring decision-maker) and two members of the fourth-grade team (your future peers)

---

## How to use this pack

**Personas** describe *how* a question arrives: who is asking and in what style. **Types** describe *what* is being scored. Every question has a persona (its bank letter) and a type tag.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior matches the district's *published* beliefs |
| EXP | Whether your resume lines hold up under questioning, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know what the district is doing now |
| CASE | How you reason through a live classroom problem |

**Provenance labels:** `[grounded]` = traceable to your resume, the invite, or a district page listed in Sources. `[inferred]` = drawn from a representative fourth-grade posting, since the actual posting text wasn't supplied. `[generic]` = a general pattern for teacher interviews, with no claim about this district.

**Answer slots.** Where the pack doesn't know something about your past, it gives you an *answer slot* with two branches: if you did it, say how in your own words; if you didn't, or there was no such thing, say so plainly. Both branches are good answers. Never fill a slot with something you didn't do.

Guidance is scaffolding, not a script.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met as stated: an Illinois PEL with an Elementary Education endorsement covering grades 1–6, which includes fourth grade, active through June 30, 2029. Medium only because nothing has been inspected yet; HR will check the license itself. Say it in those terms if asked: kind, endorsement, grades, expiry |
| F2 | "plan and teach reading" — representative fourth-grade posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [inferred] | discovery | Your material shows reading at the curriculum and club level but doesn't show how you teach reading day to day. Words that hold: "I've taught third grade for six years. In 2024 I led our grade level's move to a new reading curriculum, and I've run the after-school reading club for the last two years." Answer slot: the district hiring page says panels ask about reading instruction, so expect a probe on your reading block. Describe how you run it (groups, conferences, read-alouds, whatever you actually do) in your own words; if some part isn't how you work, say so and describe what you do |
| F3 | "writing, math, science and social studies" — representative fourth-grade posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your material doesn't say which subjects you taught. Answer slot: if you taught all of them, say so and name the one you'd talk about most confidently; if some were taught by someone else (a specials or departmentalized setup), say which and how you'd get ready to teach them |
| F4 | "differentiate instruction using assessment data" — representative fourth-grade posting | none given | none | [inferred] | discovery | Your material doesn't cover this. Answer slot: if you've used assessment results to regroup students or change a lesson, say what the data was and what you changed; if you haven't worked that way, say so plainly and say how you'd start |
| F5 | "keep clear classroom routines" — representative fourth-grade posting | none given | none | [inferred] | discovery | Your material doesn't cover this, and the district hiring page lists routines as a panel topic. Answer slot: name the routines you actually use in your own words; if you'd change them for fourth graders, say how |
| F6 | "communicate regularly with families" — representative fourth-grade posting | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap. Lead with the email in your own terms, weekly and to families, because a named habit beats an adjective. Expect a probe on what goes in it |
| F7 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | discovery | The district's belief is about *speaking* with every family; your quote is a written email, a different kind of contact. Keep the email as what it is. Answer slot: if you also talk with families by phone, in conferences or at pickup, say how and how often; if your contact is mostly the email, say so plainly and say how you'd reach every family each term here |
| F8 | "work with the grade-level team" — representative fourth-grade posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | No gap. Your quote already shows grade-level work, and you'll be asked what it involved. Keep the verb "led" and the scope "our grade level's move". See F10 for the separate line on team-lead roles |
| F9 | "experience in grades 3 to 5 preferred" — representative fourth-grade posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | No gap: third grade sits inside that range. State the six years plainly |
| F10 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your CV; "I've never been a team lead" — your CV | none | [grounded] | capability | You've said both, so the pack gives them back plainly: "I haven't taught fourth grade," and if team roles come up, "I've never been a team lead." Then say how you'd get ready for fourth grade, as a plan and never as past experience. Nothing added to make the gap look smaller. This is the most predictable objection in the room (A1) |
| F11 | "a new grades 3–5 reading curriculum from fall 2027" — Orrinsford news, Board adopts 2026–2029 literacy plan | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Your move was for one grade level; the district's is grades 3–5 across schools. Words that hold: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: expect "what did leading it involve?" Say what your part actually was, in your own words; if parts were done by others or by the district, say so and keep to your own part |
| F12 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material doesn't say whether you wrote or used individual reading plans in third grade. Answer slot: if you did, say how one worked; if your school didn't use them, say so plainly and say how you'd pick up a fourth grader's plan from third grade |
| F13 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material doesn't cover this. Answer slot: if you've used assessments to inform teaching (see F4), give that example; if not, say how you'd keep test prep in its place |

---

## Reading the interviewer

Public professional footprint only, from one search result (Sources, target 4).

| What's public | Provenance | Practical implication |
|---|---|---|
| Principal of Halvering Elementary since 2022 | [grounded] Illinois principals forum speaker page | She has run the building for about four school years; questions about how you fit *this* school's routines are likely |
| Nine years as a reading specialist before becoming principal | [grounded] same page | Expect reading-instruction questions to go deeper with her than with a generalist; vague answers on your reading block (F2) will show |
| 2025 forum talk, "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | [grounded] same page | Small-group reading and conferring are a likely theme. If you use them, describe your real practice; if you don't, don't adopt her vocabulary to sound aligned. Reverse question R1 lets you ask about it directly |

**Mirror opportunity:** none offered. Her path (reading specialist → principal) isn't the move you're making, and none of your quoted lines describes a similar one.

---

## Persona table

The loop is set by two sources: your invite (one 45-minute panel with the principal and two fourth-grade team members) and the district's "How we hire teachers" page (panels ask about reading instruction, classroom routines and working with families). So the weights below rest on this district's stated process, not a guessed pattern.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, steady probing of the fourth-grade gap and the "why leave, why here" questions | High. The principal is the decision-maker, and F10 is the obvious gap. The panel will want to know how you'll handle a new grade | Rehearse A1 until it's boring. Plain acknowledgment first, then six years of third grade in your own words, then a concrete ramp plan |
| B. Case / Strategist | Live classroom problems: a struggling reader, the first week, a parent email, the new curriculum | High. The hiring page names reading, routines and families as topics, and a hiring-manager role usually brings live problems (relationship prior) | Clarify, then structure out loud: what you'd check first, what you'd do, who you'd involve, how you'd know it worked |
| C. Peer Evaluator | The two fourth-grade teachers: "what would you bring us," shared planning, disagreement, credit | Medium. Two of the three panelists are future teammates, so whether you'd make their week easier or harder is what they're scoring | Talk about what you'd bring and what you'd need. Describe how you work with colleagues instead of guessing at how their team runs |
| D. Data-Driven Prober | "How do you know the reading club works?" "What changed after the curriculum move?" | Medium. Peer interviewers usually lean on this persona (relationship prior), and your two programs (D1, D2) invite impact questions | Know what you can and can't say about results. "I don't know how that was measured" is an honest answer |
| E. Values / Behavioral | Questions themed on the district's three beliefs | Low to medium. The beliefs page says they "guide every hire", but the hiring page names no separate values round | Pick real moments for each belief; where none fits, say so and say how you'd act |
| F. Conversational | Friendly opener: "Tell us about yourself" | Low, but nearly certain to open the panel. Casual answers still get scored | A rehearsed 90-second arc from your own resume lines |
| G. Pressure | Time-boxed or "how much was really you" questions | Low. Rare in a school panel, but one pointed follow-up is plausible | Pause, restate, hold what you stated, concede specifically |

---

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years but never fourth. Why should we hire you over someone who has?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" "I've run the after-school reading club for the last two years" | **The highest-ROI prep in this pack.** Say the gap yourself, calmly, before they finish pressing: "I haven't taught fourth grade." Then the fact: "I've taught third grade for six years, at a public elementary school in Joliet." Then a ramp plan, said as what you *will* do, not what you've done, using steps that are really yours: e.g. learning the fourth-grade standards and units before August, asking this team for their pacing, meeting the third-grade teachers about incoming students. Then stop. Follow-up 1, "What's different about fourth grade?": answer with what you expect to learn, framed as a plan, not as experience. Follow-up 2, "So we'd be training you?": concede the specific part (the fourth-grade content and pacing are new to you) and hold the rest (you've been teaching third grade for six years). Answer slot: expect "Have you worked with fourth graders at all?" If any reading-club students were fourth graders, say so in your own words; if not, or you don't know, say so plainly and return to third grade | F10 is the gap the job title itself raises, so this comes up in some form. JD because it scores the grade-level requirement; Skeptic because it tests self-assessment |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Don't invent a safe weakness. Name the real one: "I haven't taught fourth grade, so the content and pacing will be new." Then one or two plan steps (as in A1), not a new set. Short is better | A Skeptic stem that lands on F10; rehearsing it alongside A1 keeps the two answers consistent |
| A3 | "You led your grade level's curriculum change, but you haven't been a team lead. How do those fit together?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Say both plainly: "In 2024 I led our grade level's move to a new reading curriculum. I've never been a team lead." Answer slot: if leading the move came with a specific role (you were asked, you volunteered, it rotated), say how it came about and what your part was, in your own words; if there was no formal role, say so and describe what you did. Don't give the move a bigger title than it had | F8 and F10 sit side by side and a careful reader will notice. EXP because it tests attribution |
| A4 | "You send families a weekly email. Our district expects every teacher to speak with every family each term. How would that work for you?" | VAL | [grounded] "I write a weekly email to families." | Start with the email as it is: weekly, to families. Answer slot: if you also talk with families by phone, in conferences or at pickup, say how and how often; if your contact is mostly the email, say so plainly and then say how you'd plan a conversation with every family each term here (when, how you'd track it, how you'd reach the hard-to-reach). Don't present the email as speaking with families | F7: the district's own belief versus your written habit. VAL because it scores a published belief; Skeptic because it presses on the gap between the two |
| A5 | "You've been at your school for six years. Why leave now, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Give your actual reason in your own words: one sentence on why you're leaving, one or two on why this role. If the reason is personal, a short honest version is enough. Don't criticize your current school. For "why Halvering," you can point to something public, like the district's literacy plan or its three beliefs, only if it really matters to you | A classic Skeptic stem. Your material gives no reason, so this is a selection scaffold, not a story |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's October and one of your fourth graders is reading well below grade level. Walk us through your first two weeks." | CASE | [grounded] | Structure out loud: what you'd check first (the student's third-grade reading plan, if the district's "Every Child a Reader" belief means one exists; recent assessments); how you'd see the child read yourself; what you'd change in class (small group, conferring, texts); when and how you'd contact the family; who you'd bring in (reading specialist, team); and how you'd know it's working by week two. The question asks for a plan, not your history, so the guidance makes no claim about your past | The hiring page names reading instruction as a panel topic, and the district's first belief is reading. CASE because it's a live problem |
| B2 | "The board has adopted a new grades 3–5 reading curriculum for fall 2027. What would you bring to that rollout?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan, then the fact: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: say what your part in that move actually was, in your own words; if parts were done by others or the district, say so and keep to yours. Then, as a plan: what you'd want to see happen in a rollout here, based on what you lived through. Don't claim the move was school-wide | F11: the district's current plan meets your closest experience. CO because it shows you've read their news; it's the differentiator question few candidates can answer |
| B3 | "Walk us through your first week of school. How do you set up routines?" | CASE | [grounded] | Answer slot: name the routines you actually use (arrival, transitions, materials, independent reading, whatever is really yours) and how you teach them in the first days, in your own words. Then say what you'd adjust for fourth graders. If you'd start some routine fresh here, say it's a plan | F5; the hiring page lists routines as a panel topic. CASE because it asks how you'd run a real week |
| B4 | "After a beginning-of-year math assessment, how would you group students for instruction?" | CASE | [inferred] | Structure: what the assessment tells you and doesn't; how you'd form flexible groups; what each group does; how often you'd regroup; how you'd keep it from becoming tracking. Tie it to the district's "assessments inform teaching and never replace it" only if you mean it. Answer slot: if you've grouped this way in third grade, give the real example; if not, say so and keep it as a plan | F4 and F13. `[inferred]` because the data-driven requirement comes from a representative posting, not this one |
| B5 | "A parent emails you upset that their child's grade dropped. What do you do?" | CASE | [generic] | Structure: reply the same day and offer a conversation (phone or in person); look at the work before you talk; listen first; share specifics and a plan; follow up when you said you would. Family communication is a district belief, so stay calm and partnership-minded | A common family scenario. `[generic]` because it's a pattern, not a fact about this school |

### C. Peer Evaluator (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When you led the curriculum move, how did you handle a colleague who wasn't on board?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if a colleague disagreed, say what happened and what you did, in your own words, including what didn't go well; if nobody pushed back, or handling it wasn't your job, say so plainly and describe how the move went for the grade level. Don't invent a conflict to make the story better | F8. Peers test how you treat equals. EXP because it probes what was actually yours |
| C2 | "We plan together every week. What would you bring to our team, and what would you need from us?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." "I've never taught fourth grade" | What you bring, in your own words and at their own size: the curriculum move, the reading club, the weekly family email. Offer to share one thing (e.g. your family email format) as an offer, not a pitch. What you'd need: be honest that fourth-grade pacing and units are new (F10), so you'd ask for their plans and their read on students. Asking for something specific is a strength | F8; give-and-take framing for the two future teammates. JD because teamwork is a listed responsibility in the representative posting |
| C3 | "Say a unit you co-planned goes really well. How do you handle the credit?" | EXP | [generic] | Selection scaffold: pick a real time work you shared with colleagues was recognized. Say who did what, "we" for the team and "I" for your part. If no such time comes to mind, say so plainly and describe how you'd handle it | A Peer stem. Your material has no story for it, so it's a scaffold |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about the after-school reading club. Who comes, and how do you know it's working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | The facts: you've run it for the last two years. Answer slot: who comes and how many, only numbers you actually know; how you know it's working: if you track anything (attendance, reading logs, teacher feedback), say what; if you don't measure it, say so plainly and describe what you see in the students. "I don't have numbers on that" is an honest answer | Your one recurring program; a prober will ask about impact. EXP because it tests the resume line |
| D2 | "What changed for students after the 2024 curriculum move?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you have results, say what they were and how they were measured, and which part was yours; if you don't know, or it was too early to tell, say so plainly. Don't estimate a result you didn't see | F8 and F11. An impact question in the weakest-assumption spirit: know what you can and can't claim |
| D3 | "Tell us about a time assessment data changed what you taught." | JD | [inferred] | Selection scaffold: pick a real time a test result, running record or exit ticket made you regroup or reteach. It needs the data, the decision and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; data-driven differentiation is in the representative posting. Open prompt, no event assumed |

### E. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our first belief is 'Every Child a Reader.' Tell us about a time you made sure a struggling reader didn't fall through the cracks." | VAL | [grounded] | Selection scaffold: pick one real student (no name) and what you did that made a difference. It needs the problem, your action and what changed. "We" for school supports, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F12; themed from the district's published belief. VAL because it scores that belief |
| E2 | "'Teach for Tomorrow, Not for the Test.' How do you keep test prep from taking over your classroom?" | VAL | [grounded] | Answer slot: if you have a real practice for balancing test prep, describe it in your own words; if not, say how you'd approach it here. Keep it concrete: one routine or one decision, not a philosophy | F13; the district's third belief |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, tell us about yourself, and why fourth grade?" | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc in this order: six years of third grade in Joliet; the 2024 curriculum move you led; the reading club you've run for two years; the weekly family email. The license can stay unsaid unless asked. Answer slot for "why fourth grade": give your actual reason in your own words | Nearly certain opener. Rehearse it so it doesn't drift into anything you didn't say |
| F2 | "What do you enjoy most about running the reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Your own answer, briefly: one specific moment beats a general feeling. Casual tone, but it's still scored, so keep it tied to students and reading | Friendly follow-up on a line that matches the district's reading focus |

### G. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate who already knows our curriculum?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | Pause, then: concede what's true ("They'd know your curriculum on day one, and I'd have to learn it"), then hold with your own facts: six years of third grade, and leading your grade level's move to a new reading curriculum in 2024. If pushed again, don't escalate; restate the same two facts and your plan to learn the curriculum. No claims about the other candidate | A Pressure stem. Hold-then-concede: concede the specific point, never fold on what you stated |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold your own verb: "I led our grade level's move." Answer slot: say which parts you did and which were others' or the district's, in your own words. Being exact about what wasn't yours makes the rest more believable. If they press a second time, repeat the split; don't expand it | F8 and F11; the attribution probe. EXP because it tests your claim |

---

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Illinois PEL with elementary endorsement | — no question: it's a met gate and HR checks it; answer in F1's terms if asked |
| F2 Plan and teach reading | B1, B2, D1, E1 |
| F3 Writing, math, science, social studies | B4 — only math directly; writing, science and social studies get no question because no source raises them beyond the posting's list |
| F4 Differentiate using assessment data | B4, D3 |
| F5 Classroom routines | B3 |
| F6 Communicate with families | A4, B5 |
| F7 Speak with every family each term | A4 |
| F8 Work with the grade-level team | A3, C1, C2, C3 |
| F9 Grades 3–5 experience | A1 |
| F10 Fourth grade (gap) | A1, A2, C2 |
| F11 Grades 3–5 curriculum from fall 2027 | B2, D2, G2 |
| F12 Every Child a Reader | B1, E1 |
| F13 Teach for Tomorrow, Not for the Test | B4, E2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To the principal) "I saw your 2025 talk, *Small Groups, Big Readers*, was on weekly reading conferences in grades 3 to 5. How does that look in fourth-grade classrooms here?" | Ties to her own public work, and the answer tells you what your reading block would look like |
| R2 | "With the new grades 3–5 reading curriculum coming in fall 2027, what role will classroom teachers play in the rollout?" | Shows you've read the district's plan, and connects to the one area (F11) where your experience is directly relevant |
| R3 | (To the teachers) "What could a new person do in their first month that would genuinely help your team?" | The give-and-take question for future peers; it tells you what they actually need |
| R4 | "How does the fourth-grade team plan together — weekly meetings, shared units, split subjects?" | Practical, and the answer tells you how much support you'd have in your first fourth-grade year (F10) |
| R5 | "What does speaking with every family each term look like in practice here?" | Takes the district's belief seriously and tells you what's expected beyond your weekly email (F7) |
| R6 | "What support do teachers new to the building get in their first year?" | Shows you're planning for the transition, and the answer matters to your decision |

---

## Prohibited claims

What this pack won't coach, and why. These are the stretches that are easiest to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F10 | "I haven't taught fourth grade." Then a ramp plan, as a plan. No slot |
| Has been a team lead or grade-level lead | A negative you stated, F10 | "I've never been a team lead." No slot |
| Led a school-wide or district-wide curriculum change | Inflated form of F8 and F11 | F8's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Your material says the grade level, not the school. B2's and G2's slots stay inside the move you led |
| Founded or created the reading club | Inflated form of D1's quote (verb drift) | "I've run the after-school reading club for the last two years." Your material says run, not started |
| Presenting the weekly email as speaking with every family | Inflated form of F6 and F7 (written contact becoming spoken) | "I write a weekly email to families." A4's slot asks only about contact you actually have |

Not on this list, and handled as answer slots instead: your reading-block practice, your use of assessment data, your routines, reading plans and any results. Your material is silent on these, so the pack leaves room for whatever is true.

---

## Sources

**Provided:** the interview invite and your resume, both pasted in your message. Your Social Security number was not used. Your license number was used in no research call.

**Searches:**
1. `Orrinsford Community School District mission values` → https://orrinsfordschools.example/about/mission-and-beliefs
2. `Halvering Elementary School Orrinsford teacher interview process` → https://orrinsfordschools.example/careers/how-we-hire-teachers
3. `Dolores Vantongeren Halvering Elementary principal` → https://ilprincipalsforum.example/speakers/dolores-vantongeren
4. `Orrinsford Community School District strategic plan news` → https://orrinsfordschools.example/news/board-adopts-literacy-plan
5. `fourth grade teacher job description Illinois school district elementary endorsement` → https://k12jobsboard.example/listings/fourth-grade-teacher

**Fetches:**
1. https://orrinsfordschools.example/about/mission-and-beliefs — the three beliefs and their definitions in full
2. https://k12jobsboard.example/listings/fourth-grade-teacher — representative posting, responsibilities and qualifications

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | F7, F12, F13, A4, B1, E1, E2. The hiring page names no values round, so no values cheat sheet was built; the beliefs set the theme of the VAL questions |
| 2. Orrinsford interview process, teachers | yes | A loop source: one 45-minute panel, principal plus two grade-level teachers, topics reading, routines, families. Sets the persona weights; feeds B1, B3 |
| 3. Orrinsford strategy / recent news | yes | 2026–2029 literacy plan: F11, B2, R2 |
| 4. Dolores Vantongeren, Halvering | yes | Interviewer read; R1 |
| 5. Representative fourth-grade teacher posting | yes | No posting text was supplied: F2–F6, F8, F9 and their questions rest on it and are labeled `[inferred]` |

---

## Upgrade menu

- **The actual posting text** → F2–F6, F8 and F9 move from `[inferred]` to `[grounded]`, and the coverage table gets checked against the district's real list
- **A printout of your license record from the state's educator licensure system** → F1 goes from medium to high confidence; it's the one document HR will check
- **Your own answers to the slots** → upgrades the rows that draw on them: how you teach reading (F2, B3), which subjects you taught (F3), an assessment-data example (F4, B4, D3), how you talk with families beyond the email (F7, A4), what leading the 2024 move involved (F8, F11, A3, B2, C1, D2, G2), and the reading club's details (D1)
- **Deeper research** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Halvering and the district (recent news, leadership, what the literacy plan means for grade 4) and a closer read of the principal's talk
- **A `tuesday-dossier.md`** → would carry verified evidence and a prohibited-claims list from an earlier underwriting pass into this pack; not needed for it
