I'm checking whether the company can be found publicly, then I'll give you the full assessment.
# Underwriting: Remote Order Processing Coordinator (as advertised)

## Decision snapshot

**No, Ciara, don't go ahead. I can't find the firm anywhere online. Four of the requests in these messages are very likely a scam: paying €349 (RR1), lodging a cheque and passing most of the money on (RR2), sending your IBAN, PPS number and passport before any offer (RR3), and a hiring process that happens only in chat (RR4). Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (At least €30,000 a year)
- `must_have`: direct: R3 · adjacent: R2 (Strong attention to detail), R4 (Good written English)
- `important`: adjacent: R6 (Order processing) · unclear: R5 (A quiet place to work)

R3: your Excel tracker matches directly; R2, R4, R6: your courier customer-service work is close but not an exact match; R1 (`high`): your floor, which "up to €26 an hour" doesn't settle.

**Opportunity ledger.** The messages ask you for money (RR1), a cheque deposit (RR2) and bank, tax and ID details before an offer (RR3), all through a process run wholly in chat (RR4). The "offer" itself is in doubt (RR5), the employer can't be established (RR6), and the pay is stated only as a maximum (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (At least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would have to be different:** an employer you can confirm through its own website, which says it sent these messages; RR1, RR2 and RR3 withdrawn; an interview held outside chat (RR4); and a written offer from the employer's own email domain that states the rate and hours (RR5, R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" | `[grounded]` posting; not established by search, see RR6 |
| Role | Remote order processing coordinator, 15–30 hours a week, you set your own hours | `[grounded]` posting |
| Pay | "up to €26 an hour plus commission on every order you process" | `[grounded]` posting |
| Pay as yearly | €20,280 at 15 h/wk, €40,560 at 30 h/wk, both at the top rate. Commission is unstated. Your €30,000 needs about 22 h/wk every week at the full €26 | `[inferred]` arithmetic on the posting's figures, 52 weeks |
| Process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Order-processing and customer-operations coordinators in Ireland: median base €31,200, middle half €28,400–€34,100. Salaried roles only. This is a market band, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, searched this session |
| Unknowns | Who the employer is; whether "up to" is the usual rate or the ceiling; how commission works; contract type | — |
| Contradictions | The posting says "no calls or video interviews", but a "chat interview" happened | `[grounded]` posting against messages |

## Candidate evidence

| Claim | Source | Provenance |
|---|---|---|
| 3 years as a customer service agent at a parcel courier, about 60 tickets a day in Zendesk | your message | `[grounded]` self-report |
| Trained two new starters | your message | `[grounded]` self-report |
| Keeps the team's weekly tracker in Excel | your message | `[grounded]` self-report |
| Needs at least €30,000 a year | your message | `[grounded]` stated constraint |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | At least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The fit is unclear because "up to €26/h" with variable 15–30 hours covers both sides of €30,000 | `[grounded]` your message; `[inferred]` yearly arithmetic | Q2 below |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 tickets a day for 3 years suggests accurate, high-volume work, but nothing yet shows the accuracy itself | `[inferred]` from ticket volume | An accuracy measure such as QA scores, if you have one |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly Excel tracker. This is self-report with nothing to inspect yet, so `medium` | `[grounded]` your message | none |
| R4 | Good written English | must_have | adjacent | medium | discovery | Zendesk ticket work often means written replies, but your message doesn't say yours did | `[generic]` how ticket work usually runs; `[grounded]` your message | Q3 below |
| R5 | A quiet place to work | important | unclear | none | discovery | Nothing stated | `[grounded]` silence | none, since it doesn't change the decision |
| R6 | Processing orders (the role's core work, from the title) | important | adjacent | medium | transferability | Courier customer service sits next to order handling but isn't order entry | `[inferred]` from the title against your role | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1) | hard_gate | A rate stated only as a maximum, with hours you choose | It decides whether any role like this meets your €30,000 | — | A written offer stating the base rate and guaranteed hours | `[grounded]` posting |
| G2 | Written English (R4) | discovery | Ticket volume, but no mention of writing | It strengthens your applications for other customer-operations roles | Written ticket replies, templates you wrote, notes for the starters you trained | A sanitised reply or template | `[inferred]` from Zendesk work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A bank transfer, once sent, is hard to get back, and the refund depends on wages arriving. Employers don't ask new hires to pay for their equipment. This request is very likely a scam | `[generic]` known pattern for requests like this | To the employer, through contact details on its own website (not the chat or that email): "Did you ask me to pay €349 for equipment, and do you charge new staff for equipment?" | confirmed |
| RR2 | Cheque to lodge, with most of it to be sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | If the cheque bounces after you transfer the €2,500, that money comes out of your own account. This request is very likely a scam. Don't lodge the cheque | `[generic]` known pattern for requests like this | Ask through the RR1 route | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN ..., your PPS number ... and a clear photo of your passport so payroll can set you up." | Once sent, these details can't be taken back and can be used in your name. Payroll needs them only after a real written offer. This request is very likely a scam | `[generic]` known pattern for requests like this | Ask through the RR1 route | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | With no call, no video and no office, you have no way to confirm who you're dealing with | `[generic]` | Ask through the RR1 route: "Is this role real, and do you hire only over Telegram?" | confirmed |
| RR5 | "Offer" given in chat, with contact through an outside address | risk_signal | medium | "the job is yours! ... email velloway.hr@postmail.example" | The offer closes a chat-only process and points to an address not shown to be the employer's own domain, so it may not come from who it names | `[inferred]` from the messages | Ask through the RR1 route: "Is velloway.hr@postmail.example one of your addresses?" | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to have an online footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this firm | "Can you point me to this role on your own careers site?" | unresolved |
| RR7 | Pay stated only as "up to" plus commission (see R1) | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | The real base rate may be lower than €26, which would put a 15–30 hour week under your floor | `[inferred]` from "up to"; `[generic]` against the band in role reality | "What is the guaranteed hourly rate, and how many hours are guaranteed?" | unresolved |

**Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, using contact details on the employer's own website rather than the chat or the address these messages came from. Who sent them is not yet confirmed.** I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

You don't need to paste your IBAN to me or anyone else, and I haven't repeated it here. Your PPS number and passport aren't needed for this assessment either.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS or passport, no €349, and don't lodge any cheque that arrives | RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If you can find a Velloway Logistics website on your own, ask it the RR1 questions | RR1–RR6 | `[grounded]` register | pending your approval |
| A3 | Report the posting to the jobs site you found it on | Jobs sites usually take reports on listings | `[generic]` | pending your approval |
| A4 | Put your effort into other order-processing and customer-operations openings. Salaried roles there sit around your €30,000 | R1; market calibration | `[generic]` Pennoral 2026 guide | pending your approval |
| E1 | Lead future applications with your own words: "3 years as a customer service agent at a parcel courier, about 60 tickets a day in Zendesk; trained two new starters; keep the team's weekly tracker in Excel" | R2, R3, R6 | `[grounded]` your message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers Remote Order Processing Coordinator". Neither returned anything, so the employer is not established (RR6) |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This set the market calibration and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, and a Telegram handle isn't one |

## Closing

If you'd like, I can save all of this as a `tuesday-dossier.md` file you can keep.

**Upgrade menu**
- The jobs site's name and any company link in the listing → RR6 could be checked against something real.
- A written offer from an employer you've confirmed → R1 and RR7 would close.
- A sample of your written ticket replies → R4 could become `direct`.
- A deeper check (up to 5 more searches and 2 more fetches) on the posting and the email domain. Say the word and it runs.

**Questions**
1. (RR6) Which jobs site was the posting on, and did it link to a company website?
2. (R1) Does your €30,000 mean a guaranteed salary, or would variable hourly-plus-commission pay count?
3. (G2, R4) In your Zendesk work, were you writing replies to customers yourself?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.