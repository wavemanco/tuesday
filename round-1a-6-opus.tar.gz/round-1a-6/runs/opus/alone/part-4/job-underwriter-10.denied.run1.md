Reading the assessment rules is done. Next I'll check whether Fernquay shows up online, then write up the assessment.
**Short answer: yes, it's worth applying, and nothing you've shared looks off. I couldn't confirm the company online myself (details below), so check that before the call.** WhatsApp is only being used to arrange the call; the call itself happens over video. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R5 · adjacent: R6 (Own the booking flow end to end as first designer)
- `important`: direct: R7 · adjacent: R8 (Research calls with school owners)

R6: your checkout redesign is a real bridge, but you've never been anyone's only designer. R8: your usability testing carries over, but interviewing school owners about their business is new to you.

**Opportunity ledger.** The posting is unusually open: salary, equity, team, product and working pattern are all stated (RR2, RR4), and the message names something specific from your application (RR6). Two things are still open. The company isn't established from here because my searches were blocked (RR1). And nobody has said who has the final say on design, or how the company is funded (RR3, RR5).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The company checks out: the invite comes from a Fernquay email domain and there is a findable website or company registration (RR1).
  2. The call gives acceptable answers on design decision rights and runway (RR3, RR5).
  3. You present R6 honestly as adjacent: you owned checkout inside a squad, not as the only designer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway making booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer. You own the booking flow end to end, run research calls with school owners, and ship with two engineers | `[grounded]` posting |
| Reporting line | Closest to co-founder Ronan Kehoe. The message adds Saoirse as CTO | `[grounded]` posting and message |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Stage | Applied; invited to a 45-minute video call with the co-founder and the CTO | `[grounded]` message |
| Scope read | A typical first-designer brief: one core flow, research, and close work with engineers. Broad, but coherent for six people | `[inferred]` from team size against the stated mandate |
| Market calibration | Not calibrated, because the salary search was blocked. I won't quote a band from memory | — |
| Unknowns | Funding and runway; who signs off on design; equity terms (vesting, cliff, basis); whether Fernquay has a website or company registration | — |
| Contradictions | None between the posting and the message | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit. You stated this in passing, unprobed | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer, which is over the bar. Self-report only so far | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | Figma daily; the case study they liked is likely evidence of it | `[grounded]` your background | none |
| R4 | Has run their own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Not yet clear whether you also recruited and planned them yourself | `[grounded]` your background | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your background | none |
| R6 | Own the booking flow end to end as first designer | must_have | adjacent | medium | transferability | What carries over: you redesigned a booking checkout, which is very close to their product. The limit: you've never been the only designer, with no design peers, critique or existing system | `[grounded]` your own words: "never been the only designer" | see G1 |
| R7 | Booking-software domain | important | direct | medium | none | Travel booking and the checkout redesign map onto booking for kayak and surf schools | `[inferred]` that requirement comes from the product description | none |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | Usability testing with customers carries over. The limit: owners are business operators, and the call is about their workflows, not testing a screen | `[inferred]` difference drawn from the posting's "school owners" against your "customers" | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole design ownership (R6, must_have) | transferability | Checkout owned inside a squad. Nothing yet on decisions you made with no design lead above you | It's the main fit question for a first-designer hire, and the call will likely probe it | Leading checkout with no senior designer reviewing; setting up components or patterns others reused; defending a design call to product or engineering alone; a side project or freelance work where you were the whole design function | Messy working files, a decision log, a before-and-after with your rationale | `[grounded]` your background; `[generic]` that first-designer interviews test working alone |
| G2 | Research with business operators (R8, important) | transferability | Usability sessions with travellers. Nothing yet on interviewing suppliers, partners or internal operators | It's the research the posting actually describes | Calls with tour operators, hotels or other suppliers on the travel platform; interviews with support or ops staff; discovery interviews rather than testing | A discussion guide, a synthesis board, a research readout | `[inferred]` from the posting's "school owners" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be old or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary and equity both stated | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The pay terms are open from the start | `[grounded]` posting | What are the vesting schedule and cliff, and is the percentage of fully diluted shares? | noted |
| RR3 | First designer: who has the final say on design is unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | You could own the outcome while the co-founder makes the design calls | `[inferred]` from "own" against "work most closely with our co-founder" | Who has the final say on design decisions, and how do research findings reach the roadmap? | unresolved |
| RR4 | Concrete, specific posting | positive_signal | — | "two days a week at our Galway office … two engineers … Ronan Kehoe" | Team, people and terms are named, which leaves little vague | `[grounded]` posting | — | noted |
| RR5 | Funding and runway unstated | unknown | — | "We are six people" | At this size, runway decides how real the equity and the job security are | `[generic]` early-stage pattern | How is Fernquay funded, and how many months of runway do you have? | unresolved |
| RR6 | Message refers to your actual application | positive_signal | — | "we loved the checkout case study" | Whoever sent it has read what you submitted | `[inferred]` from the message naming your case study | — | noted |

## Application plan

Every row below is proposed and needs your approval before you use it. That covers the wording in P2 as well as the actions.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp contact as normal scheduling. Arranging a call by text when the call happens elsewhere is routine. Reply there if the time doesn't suit | Your question about the WhatsApp message | `[generic]` hiring practice | pending your approval |
| A2 | Before the call: check the invite came from a Fernquay email domain and the link opens a standard video platform; look for Fernquay's website and its entry at the Companies Registration Office | RR1 | `[generic]` standard diligence | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3 and RR5 in the call | The register doubles as call prep | `[grounded]` register | pending your approval |
| P1 | Lead with the checkout redesign plus the monthly usability sessions | R4, R6, R7 | `[grounded]` your background | pending your approval |
| P2 | Frame the gap truthfully: "I owned checkout end to end inside a squad; I haven't yet been a team's only designer — here's how I'd work alone" | R6, G1 | `[grounded]` your own words | pending your approval |
| W1 | Bring one messy, real artefact from checkout (raw notes, rejected options) if it's shareable | The posting asks for "one messy real project" | `[grounded]` posting | pending your approval |

If you'd like to rehearse the call itself, that's a separate job for mock-interview.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay Galway booking software kayak surf schools"; the search was refused (permission not granted). It would have tested RR1 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 startup first designer"; refused. It would have filled the market calibration row and checked the €52–60k range |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have informed the scope read and which story P1 leads with |

---

If it's useful, I can save all of this as a `tuesday-dossier.md` file you can keep.

**What more input would unlock:**
- **Web search access:** lets me retry targets 1–3. That would settle RR1, calibrate the salary and inform the scope read.
- **Fernquay's website, or the email domain the invite came from:** RR1 likely closes and the cap on `conditional_go` lifts.
- **Your salary floor and any non-negotiables:** gives the hard-gates line real checks instead of "unknown".
- **A link to the checkout case study:** R3, R4 and R6 could move toward `high`.
- **A deeper research pass on Fernquay** (funding, team history, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions:**
- **Constraints:** Is €52–60k at or above your floor, and is there anything you won't flex on, such as office days or start date?
- **G1:** Has there been a time, at work or outside it, when you made design decisions with no designer above you to sign off? What did you decide, and how did it land?
- **G2:** Have you ever interviewed people who run a business rather than buy from one, such as suppliers, operators or internal ops staff? What did you ask, and what came out of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.