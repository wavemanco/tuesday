Here's the assessment. My web searches weren't permitted, so it rests only on what you pasted.

## Decision snapshot

**Yes, it's worth applying, and worth taking the call. Nothing in the posting or the WhatsApp message asks anything unusual of you. A co-founder arranging a video interview over WhatsApp, with the invite sent by email, is a normal scheduling step. What I couldn't do is confirm the company exists as described (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4a, R5
- `important`: direct: R6 · adjacent: R7 (first and only designer) · unclear: R4b (research calls with school owners)

R7 is the real stretch, and you can make the case for it as long as you state its limit. R4b could be settled by one answer from you.

**Opportunity ledger.** The posting is open about pay and the interview process looks conventional (RR2, RR5). The company itself is unverified, because my research was refused (RR1). Several things are unstated: the equity terms, who makes design decisions, funding, and what success looks like in the role (RR3, RR4, RR6, RR7).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. RR1 clears: you find Fernquay's own website yourself, and the calendar invite comes from an email address on that domain.
  2. R7 is presented honestly as related experience, never as having been the only designer before.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway making booking software for sea-kayak and surf schools. Not checked against any outside source (RR1). | `[grounded]` posting text |
| Mandate | First designer. Owns the booking flow end to end, runs research calls with school owners, and ships with two engineers. | `[grounded]` posting |
| Working relationship | Works most closely with co-founder Ronan Kehoe. The message adds Saoirse, the CTO, to the interview. | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting is silent |
| Scope read | At six people, "first designer" means the design function is you: research, design and delivery, with nobody senior to review your work | `[inferred]` from the team size and the "first designer" wording |
| Market calibration | Not established: my role-family search was refused. I won't quote an Irish salary band from memory. | n/a |
| Unknowns | The company's footprint, equity terms, design decision rights, funding and runway, success measures, interview stages after this call | n/a |
| Contradictions | None between the posting and the message: both name Ronan as co-founder, and the message adds a CTO the posting doesn't mention | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days look met. You haven't said they're one of your limits. | `[grounded]` posting plus your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer, self-reported and not yet backed by anything I've seen | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily", self-reported | `[grounded]` your background | none |
| R4a | Has run their own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your background | none |
| R4b | Research calls with school owners: business operators, not end customers | important | unclear | low | discovery | Usability sessions with customers are evaluative research with consumers. The role asks for discovery-style calls with business owners, and your background doesn't say whether you've done that kind. | `[grounded]` your background is silent on it | see G2 |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | important | direct | medium | none | You redesigned the checkout flow at a travel-booking company, which is the same kind of flow. Expect questions on how much of the flow was yours. | `[grounded]` your background. The phrase "the same kind of flow" is `[inferred]` from the two domains. | none |
| R7 | Be the first and only designer | important | adjacent | low | transferability | Carries over: working directly in a squad of engineers. Limit: you've never been the only designer anywhere, so you haven't worked without design peers or a design lead. What you did on your own in the squad isn't stated. | `[grounded]` your own statement. Treating "first designer" as a requirement is `[inferred]` from the posting. | see G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Being the only designer (R7, important) | transferability | Squad work with four engineers. Nothing yet on decisions you made without design review. | It's the role's defining difference from your past jobs, so it's the likeliest probe | Being the only designer in your squad while the other designers sat elsewhere; making UX calls with engineers and no design lead present; setting up a research cadence nobody asked for; covering when a design lead was away | A case study section on a call you made alone, or a research plan you wrote | `[grounded]` your statement. That it's the likeliest probe is `[generic]`. |
| G2 | Research with business owners (R4b, important) | discovery | Monthly usability sessions with customers. Nothing on interviews with business partners. | School owners are the users and the buyers here | Interviews with hotel, tour or airline partners; calls with internal ops or customer-support staff; discovery interviews before the checkout redesign | Interview guides, a synthesis doc, a research readout | `[grounded]` your background is silent on it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale or copied elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and equity stated up front | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Transparent on pay | `[grounded]` posting | What decides where in that range an offer lands? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on vesting, the type of equity and the company's funding, and none of those is given | `[inferred]` from a percentage stated without terms | Is the equity options or shares, what's the vesting schedule, and on what valuation? | unresolved |
| RR4 | Who makes design decisions | unknown | — | "own the booking flow end to end … work most closely with our co-founder" | "Own" may sit beside a co-founder who makes the final calls | `[inferred]` from the two phrases side by side | When you and I disagree on a booking-flow decision, who makes the call? | unresolved |
| RR5 | Conventional interview step | positive_signal | — | "Could you do a 45-minute video call with me and Saoirse, our CTO? I have emailed you a calendar invite" | A structured call with two named people, and it refers to your actual application | `[grounded]` WhatsApp message | What are the stages after this call? | noted |
| RR6 | Funding and runway | unknown | — | "We are six people" | A six-person company's ability to keep the role going depends on its funding | `[generic]` pattern for early-stage companies | How is Fernquay funded, and how much runway do you have? | unresolved |
| RR7 | No success measures stated | unknown | — | Posting is silent | Success for the role may be undefined | `[grounded]` posting is silent | What would a great first six months look like in this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's website yourself (not through the message). Check that the calendar invite came from an address on that domain, and look the company up on Ireland's companies register (CRO) | Clears RR1 cheaply | `[generic]` standard independent checks | pending your approval |
| E1 | Lead with your checkout redesign and the monthly usability sessions with customers, in exactly those words | They named the checkout case study, and it covers R4a and R6 | `[grounded]` your background and the message | pending your approval |
| E2 | Raise R7 yourself: "I've always worked in a squad with four engineers; I haven't been the only designer." Add the G1 example once you've confirmed it. | Saying the limit first is stronger than having it found | `[grounded]` your own words | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR7 during the call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software Galway". The call was refused. It would have confirmed the company and the live posting, and could have cleared RR1. |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 mid-level startup". The call was refused. It would have given a market-calibration band to set €52–60k against. |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder". The call was refused. It would have informed the scope read and which story to lead with. |

## Upgrade menu

If useful, I can save this as a `tuesday-dossier.md` you can keep and reuse.

- **Allow web search:** I'd retry targets 1–3. RR1 could clear and the €52–60k range would get a market comparison.
- **A link to Fernquay's site or the live posting:** RR1 resolves directly.
- **Your pay floor and non-negotiables:** the hard-gates line gets checked against them instead of being marked unknown.
- **Your portfolio or checkout case study:** R2–R6 can move to `high`. In design, a case study is the inspectable proof.
- **A deeper research pass on Fernquay** (funding, team history, news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

**G1:** In your squad, was there a time you made a design call with no design lead or peer review, for example settling a UX question with the engineers on your own? What was it, and what happened?

**G2:** Before or during the checkout redesign, did you interview anyone other than customers, such as partners, suppliers or support staff? What did you ask, and what changed because of it?

**Constraints:** Is there a pay floor, or anything about the two Galway office days, that you won't trade?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.