Quick update: I've read the assessment method. Next I'm running a few web searches to check that Fernquay exists as described and to get salary norms, then I'll write up the assessment.
Yes, it's worth pursuing, and the WhatsApp message is normal. Fernquay exists as the posting describes it. You've already applied and been invited to interview, so the real question is whether to take the call, and the answer is yes.

## Decision snapshot

**Yes, take the call. The company checks out as described, and chatting on WhatsApp to set up a video interview is routine. Status: `go`.**

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Being the first and only designer) · unclear: R5 (Research calls with school owners)

R7 is very close to your checkout work, but it isn't the whole flow. R8 is your one real stretch, and you named it yourself. R5 is consumer usability testing versus interviews with business owners.

**Opportunity ledger.** The company is real and matches the posting (RR1). The pay is stated and sits inside the market range (RR2). There are three open points: the role isn't on Fernquay's own website (RR3), the equity terms aren't stated (RR4), and "first designer" with no design peers is a lot of scope for one person (RR5).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** a pay floor above €60,000, or not being able to do two office days a week (R1), would make me look again. So would an answer to RR5 showing the role covers far more than the booking flow.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes "Kelproster" booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle and funded by its customers | `[grounded]` fernquay.example/about (search result) |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | Being a team's only designer usually means owning everything design-related: the product, research, and often the website and brand too, even when the posting names only the booking flow | `[generic]` small-startup pattern |
| Market calibration | Irish product designers with 3–5 years: median base €57,000, middle half €51,500–€62,000. The posted €52k–€60k sits inside that range. This is market data, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520); `[grounded]` posting figure |
| Unknowns | Equity type, vesting and strike price; whether design covers more than the product; where the posting is published | none |
| Contradictions | None found. Saoirse appears as a co-founder on the about page and as CTO in Ronan's message, which is consistent but doesn't confirm the title. No careers page exists at fernquay.example/careers (RR3) | `[grounded]` about page; careers fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. You haven't said whether two office days suits you | `[grounded]` your background | Q1 |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer, stated but not yet inspected | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R4 | Has run their own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your background | none |
| R5 | Research calls with school owners (business customers) | important | unclear | low | discovery | Your sessions were with customers of a travel-booking company. School owners are business buyers. Interviewing them to understand their needs is a different kind of research from usability testing | `[grounded]` your background; `[inferred]` the difference in kind, read from the posting | G2 |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout at a travel-booking company, which is the same domain. The limit: checkout is one stage, and you haven't said whether you owned search, availability or post-booking too | `[grounded]` your background; `[inferred]` the bridge | G1 |
| R8 | Being the first and only designer | important | adjacent | medium | transferability | You owned the checkout redesign and ran research yourself. The limit, in your words: never the only designer anywhere | `[grounded]` your background; `[inferred]` from "You would be our first designer" | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow end to end (R7, must_have) | transferability | You own checkout; the other stages aren't mentioned | It's the core of the job, so it's the likeliest probe | Work on search results, date or availability pickers, booking confirmations, changes and cancellations | The checkout case study they already liked, plus any flow map | `[grounded]` your background; `[generic]` that the core mandate gets probed |
| G2 | Research with school owners (R5, important) | discovery | Only consumer usability sessions are mentioned | The posting names it as part of the job | Interviews with partner hotels or operators, internal ops or support staff, or B2B suppliers at the travel company | A discussion guide or research synthesis | `[inferred]` from the posting |
| G3 | Sole designer (R8, important) | transferability | Always worked alongside other designers | Without a design team, you set your own process and priorities | Running the usability programme yourself, setting up components, deciding priorities with engineers without a design lead | A project where you set the plan | `[grounded]` your background; `[generic]` what a solo design role demands |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Company exists as described: size, city, product, founders | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The posting matches what the company says about itself | `[grounded]` fernquay.example/about | How has the team changed since 2023? | noted |
| RR2 | Pay is stated and within the market range | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Being open about pay is a good sign | `[grounded]` posting; `[generic]` Tillerby band | What decides where in the range an offer lands? | noted |
| RR3 | No careers page on Fernquay's site | unknown | — | "Product Designer — Fernquay" | Small companies often post roles only on job boards | `[generic]` small-company pattern | Where is this role advertised officially? | unresolved |
| RR4 | Equity terms not stated | unknown | — | "0.5–1% equity" | The percentage alone doesn't tell you what the equity is worth | `[generic]` startup pattern | Is the equity options or shares, what's the vesting schedule, and is there a cliff? | unresolved |
| RR5 | All design scope sits with one person | unknown | — | "You would be our first designer: own the booking flow end to end" | The role may grow to include the website, brand or support material | `[generic]` small-startup pattern | Apart from the booking flow, what design work would be mine in year one? | unresolved |
| RR6 | The co-founder's background matches your domain | positive_signal | — | "Ronan Kehoe, co-founder and CEO … product lead at a Galway travel-software company for five years" | Your travel-booking checkout work speaks directly to someone with that background | `[grounded]` public LinkedIn profile snippet | What did you learn about booking flows at your last company? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the call, and before it, check that the calendar invite came from a Fernquay email address | Scheduling on WhatsApp for a video interview is routine. Checking the sender domain is just good practice | `[generic]` hiring practice | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions | They already said they liked the case study (R7, R4) | `[grounded]` Ronan's message, your background | pending your approval |
| A3 | Be open that you've never been a team's only designer, and give an example of setting your own plan (R8) | It's a real gap. Being upfront about it comes across better than having it discovered | `[grounded]` your background | pending your approval |
| A4 | Ask the RR3, RR4 and RR5 questions word for word | They're the open terms | `[grounded]` register | pending your approval |

If you want to rehearse for the call, the mock-interview skill handles that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software kayak surf schools", which returned "About Fernquay" (fernquay.example/about). Fetched fernquay.example/careers, which has no page. This gave the organization row, RR1 and RR3 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 2026 startup senior", which returned the "Tillerby 2026 Ireland Design Salary Report" (tillerby.example). This gave the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned his LinkedIn profile snippet (linkedin.example/in/ronan-kehoe). This gave RR6 and A2 |

I can write all this up as a `tuesday-dossier.md` for you to keep, if that's useful.

**Upgrade menu**
- **Your portfolio link or the checkout case study:** would raise R2, R4 and R7 to `high`.
- **Your pay floor and office-day limits:** would let me check R1 and the pay properly.
- **The link where you saw the posting:** would close RR3.
- **A deeper research pass on Fernquay:** customers, team changes, news; up to 5 more searches and 2 more fetches. Just say the word and it runs.

**Questions**
- **Q1 (R1):** Do you have a minimum salary, and are two office days a week in Galway fine for you?
- **G1 (R7):** At the travel company, did you work on any part of booking besides checkout, such as search, availability, or changes and cancellations?
- **G3 (R8):** Have you ever set the design plan and priorities yourself, with no design lead above you?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.