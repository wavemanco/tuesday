I've read the method notes for this assessment. Next I'll run a couple of quick checks on the company and normal pay for this kind of role, then write it up.
**Ciara, no, don't go ahead. I can't find any trace of this company. The messages ask you to pay €349, to lodge a cheque and send most of it on, and to hand over your bank, PPS and passport details before any offer. That makes this job very likely a scam. Status: `no_go`.** Don't paste your IBAN into that chat. I've left the number you gave me out of everything below.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year pay floor)
- `must_have`: direct: R2, R3, R4
- `preferred`: adjacent: R5 (Order-processing experience)

R1: "up to €26 an hour" sets no minimum; R2, R3, R4 (`medium`): your stated background covers them.

**Opportunity ledger.** Four requests in these messages are serious warning signs: your details before an offer (RR1), paying for equipment (RR2), lodging a cheque and passing most of it on (RR3), and a hiring process held only in chat (RR4). Two more things are open: the firm can't be found (RR6) and the contact email isn't on a company domain (RR5). The pay floor is unknown (RR7). Your fit for the work is real, but it doesn't change any of this.

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year pay floor)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would have to be different:** you can confirm the employer exists through its own website (RR6); an interview happens by call or video, not only in chat (RR4); a written offer naming the role and pay comes from the company's own email domain (RR5); and nobody asks for money, a cheque deposit or your details before that offer (RR1, RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". Two searches found nothing for that name or this role | `[grounded]` posting; `[grounded]` searches returned no results |
| Role | Remote order processing coordinator, 15–30 hours a week, own hours, training provided | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission". At that top rate, 15 to 30 hours a week over 52 weeks is about €20,280 to €40,560 a year. No minimum is stated | `[grounded]` posting; `[inferred]` arithmetic on the posting's own figures |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Order processing and customer operations coordinators in Ireland: median base €31,200 a year, middle range €28,400–€34,100 (salaried roles only). This is the market, not an offer from this employer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, found in this month's search |
| Unknowns | Employment type (employee or contractor), guaranteed hours, what the commission is based on, who you would report to | — |
| Contradictions | They asked for payroll details "before your chat interview", which is before any job existed; the offer then came straight after a chat | `[grounded]` messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year pay floor (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because "up to €26 an hour" at 15–30 hours sets a ceiling, not a minimum | `[grounded]` your message and the posting; `[inferred]` the yearly range from its figures | Carry this floor into other roles (see A5) |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for 3 years at a parcel courier. This is your own account, with nothing to inspect yet | `[grounded]` your stated background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Which Excel features you use isn't stated | `[grounded]` your stated background | none |
| R4 | Good written English | must_have | direct | medium | none | Ticket work in Zendesk usually means written replies; worth confirming that yours were | `[grounded]` your stated background; `[generic]` that Zendesk ticket work is largely written | none |
| R5 | Order-processing experience | preferred | adjacent | medium | transferability | What carries over: parcel-courier customer service, so orders, deliveries and exceptions. The limit: nothing stated about entering or processing orders yourself | `[grounded]` your stated background | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | €30,000 pay floor (R1, hard_gate) | hard_gate | A yearly floor, set against hourly, variable-hours postings | It decides which other roles to filter for: salaried only, or hourly that averages out | — | — | `[grounded]` your message |
| G2 | Order-processing experience (R5, preferred) | transferability | Courier customer service; no hands-on order entry stated | It changes how directly you can pitch for order-processing roles elsewhere | Fixing or re-booking orders in a courier system; raising claims or returns; updating delivery records | A redacted screenshot of your Excel tracker's layout | `[grounded]` your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details asked for before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Once sent, a passport photo, PPS number and IBAN can be used to open accounts or borrow in your name, and you can't take them back. This request is very likely a scam. The sender's identity is unresolved | `[generic]` how identity details are misused | Ask the employer, using contact details you find on its own website, not this chat or that email: "Did Velloway Logistics post this role, and is @VellowayHiring your recruiter?" | confirmed |
| RR2 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Money sent by bank transfer is usually very hard to get back. Employers don't ask applicants to buy their own work kit from a named partner. This request is very likely a scam | `[generic]` pattern for requests like this | Same question and same route as RR1 | confirmed |
| RR3 | Asked to lodge a cheque and pass most of it on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can look cleared and then bounce days later. You would then owe your bank the €2,500 you transferred. Don't lodge the cheque | `[generic]` known pattern for overpayment cheques | Same question and same route as RR1 | confirmed |
| RR4 | Hiring run entirely in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." / "you passed the interview and the job is yours!" | Nobody has heard or seen the sender, so who they are and whether they speak for the employer is unconfirmed | `[generic]` what a chat-only process leaves unchecked | Same question and same route as RR1 | confirmed |
| RR5 | Contact email not on a company domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example" | The messages may not come from the firm they name | `[inferred]` from the address not being on any employer's own domain | "What email domain do your recruiters write from?" | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The firm may be too new or small to have a web presence, the posting may be stale or copied, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this firm | "Can you point me at this role on your own careers site?" | unresolved |
| RR7 | No pay floor stated | unknown | — | "Earn up to €26 an hour plus commission" | Guaranteed earnings may be well under the €30,000 floor (R1) | `[inferred]` from "up to" set against R1 | "What hourly rate and minimum hours are guaranteed?" | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer. Use contact details from the employer's own website, not the chat or the address these messages came from. Who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, no PPS number, no passport photo, no €349 | RR1, RR2 | `[grounded]` the messages | pending your approval |
| A2 | If a cheque arrives, don't lodge it. Show it to your bank | RR3 | `[generic]` the overpayment-cheque pattern | pending your approval |
| A3 | Only if you want to check: find Velloway Logistics' contact details yourself, not through the chat, and ask RR1's question. My searches found no site | RR1, RR6 | `[grounded]` the searches found nothing | pending your approval |
| A4 | Report the listing to the jobs site where you found it | RR1–RR4 | `[generic]` jobs sites usually take reports on listings | pending your approval |
| A5 | Put your effort into other openings: order processing or customer operations coordinator roles, salaried, at €30,000 or more. Lead with what you told me, as you said it: 3 years in customer service at a parcel courier, about 60 Zendesk tickets a day, trained two new starters, and keep the team's weekly tracker in Excel | R1–R5; the median in that guide (€31,200) is above your floor | `[grounded]` your background; `[generic]` the Pennoral band | pending your approval |

Every row above, including the wording in A5, is a proposal for you to approve or change.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator". Both returned no results, so the employer is not established. This drives RR6 and the organization row |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This gives the market calibration band and A5's floor check |
| 3. Hiring manager's public footprint | n/a | No person's name was given; "@VellowayHiring" is a handle, so there was nothing to search |

I can save all of this as a `tuesday-dossier.md` file if you'd like to keep it.

## Upgrade menu

- A link to the live posting on the jobs site would let me check it matches what you pasted (RR6).
- If you find the company's own website or a named contact, RR6 and RR5 could be checked properly.
- Another role you're weighing would get a fresh assessment against your €30,000 floor (R1) and your background.
- A deeper research pass on this company (up to 5 more searches and 2 more fetches) would look at public reports and recent news. Say the word and I'll run it.

## Questions

G1: For other roles, does €30,000 need to be a guaranteed base salary, or would hourly part-time work that averages out to it be fine?

RR3: Has the cheque arrived, or have you sent anything at all to the sender so far?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.