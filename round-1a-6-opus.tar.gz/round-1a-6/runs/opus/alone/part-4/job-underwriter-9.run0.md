Quick update: I'm checking your offer against the job-assessment framework. Next I'll look up Marrowgate Housing's public website and typical pay for this kind of role.
# Is this onboarding request normal? Payroll Administrator offer, Marrowgate Housing

## Decision snapshot

**Yes, this is normal. After a written offer that names the role, the pay and your manager, an employer routinely asks for your bank details, PPS number and a passport scan for payroll and right-to-work checks. Status: `conditional_go`.** The advice "never hand those over" is about giving them *before* an offer. This request comes after one.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days a week in our Limerick office), R2 (Right to work in Ireland)
- `must_have`: direct: R3, R5, R6, R8 · unclear: R4 (Working knowledge of Irish PAYE, PRSI and USC)
- `important`: adjacent: R9 (Monthly payroll for 240 staff) · absent: R7 (Process pension changes)
- `preferred`: direct: R10

R4 is the one must-have still unconfirmed. R7 is a real gap but a learnable one. R9 is the same work at a larger scale on a different cycle.

**Opportunity ledger.** The offer is concrete and matches the ad (RR2). I couldn't run research, so the employer isn't confirmed from public sources (RR1). That's a standing check, not a doubt about you or the offer.

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in our Limerick office), R2 (Right to work in Ireland); you haven't told me your constraints, so I can't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) when the portal link arrives, open Marrowgate's own website and check that the link goes to an address on it (RR1, A1); (2) you're fine with two Limerick days a week (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff: starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` job ad |
| Offer terms | Permanent post at €40,000, reporting to Declan Garvagh, Finance Manager. Hybrid, two days a week in Limerick. Start date agreed after your notice period | `[grounded]` offer email |
| Onboarding steps | After you accept: a portal link for bank details, PPS number and a passport scan, plus the original passport on day one | `[grounded]` offer email |
| Market calibration | Not established, because the salary search couldn't run. The offer's €40,000 sits inside the ad's own €38,000–€42,000 range | `[grounded]` ad and offer |
| Unknowns | Payroll software in use; who handles pension changes today; how much training you'd get | — |
| Contradictions | None between the ad and the offer | `[grounded]` ad and offer compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in our Limerick office | hard_gate | unclear | none | hard_gate | You haven't said whether two days a week in Limerick works for you | `[grounded]` ad and offer; no constraint given | Question 1 |
| R2 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | Inferred from the offer's "right-to-work check". Your eligibility isn't stated | `[inferred]` from the offer's wording | Question 2 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff. This is self-reported and you were hired on it | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You don't say which country the hotel group's payroll was in | `[grounded]` your background is silent on it | Question 3 |
| R5 | Process starters and leavers | must_have | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R6 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | You did exactly this, monthly | `[grounded]` your background | none |
| R7 | Process pension changes | important | absent | none | capability | Your manager handled these, so you haven't done them yourself | `[grounded]` your own words | G1 |
| R8 | Strong Excel | must_have | direct | medium | none | Daily use, including pivot tables and XLOOKUP | `[grounded]` your background | none |
| R9 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | Same tasks at about 2.7 times the headcount, on a monthly cycle instead of fortnightly | `[inferred]` from your 90 fortnightly against their 240 monthly | none |
| R10 | Payroll qualification or working towards one | preferred | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R7, important) | capability | You've never processed them yourself | It's a named duty, and it's something to plan for in your first months, not a reason to turn the job down | Pension deductions you checked in reconciliations; changes you passed to your manager | Ask for training on it in your first weeks | `[grounded]` your own words |
| G2 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | Not stated | It's the core of the job if the hotel payroll was outside Ireland | Revenue payroll submissions, USC bands, PRSI classes | Confirmation of where you ran payroll | `[grounded]` your background is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from public sources (research couldn't run) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The organization may be small with a thin online footprint, the ad may be old or copied from elsewhere, or it may not be a real hiring employer. Your two in-person interviews at its office are your own first-hand check | `[generic]` pattern, not a claim about this employer | Can you confirm the onboarding portal's address, so I can match it to your website before I enter my details? | unresolved |
| RR2 | Concrete written offer that matches the ad | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | Role, pay, manager and working pattern are all named and agree with the ad | `[grounded]` ad and offer compared | Who will train me on pension changes? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | When the portal link arrives, find Marrowgate's own website yourself (search for it, don't click through from the email) and check that the link goes to an address on it. Enter your details only there, never by email reply | RR1. This is the one check that matters for onboarding steps | `[grounded]` the offer email's own process | pending your approval |
| A2 | Accept within the five working days if R1 and R2 are fine for you | Offer terms | `[grounded]` offer email | pending your approval |
| A3 | When you accept, ask for training on pension changes | G1, R7 | `[grounded]` your own words | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association", but permission was refused. It would have confirmed the organization and its web address (RR1) |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland Limerick 2026", but permission was refused. It would have set €40,000 against the market (market calibration) |
| 3. Hiring manager's public footprint | unavailable | Not sent, because search permission was refused. It would have filled in the scope read for Declan Garvagh's team |

---

If you'd like, I can save all of this as a `tuesday-dossier.md` file.

**Upgrade menu**
- Turn on web search → RR1 checked against Marrowgate's own site, and the salary checked against the market.
- Answers to the questions below → R1, R2 and R4 settle, and the decision can move to `go`.
- A deeper research pass on Marrowgate Housing (governance, recent news, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions.** You don't need to send me your PPS or passport numbers for any of these.
1. (R1) Does two days a week in the Limerick office work for you?
2. (R2) Do you have the right to work in Ireland without needing a permit?
3. (G2, R4) Was your hotel group payroll run in Ireland, under PAYE, PRSI and USC?

You can answer in text, paste a voice transcript, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.