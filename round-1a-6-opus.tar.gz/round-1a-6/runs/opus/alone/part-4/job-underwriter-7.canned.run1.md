Reading the advert and your CV against each other now; next I'm checking that the employer is real and what Band 5 community roles usually pay.
I'd apply. **Yes, worth applying for, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R8, R9 · adjacent: R6 (Catheter and continence care) · unclear: R4 (Clear, timely written records), R5b (Leg-ulcer care), R7 (End-of-life visits)
- `important`: adjacent: R10 (Hold a small caseload of your own)
- `preferred`: absent: R11 (Doppler assessment for leg ulcers)

R9: your discharge-to-assess home visits are the closest match to the job; R4, R5b, R7: experience that probably exists but your CV doesn't show yet, one question each below; R10: a real bridge with a named limit; R11: a gap you can close with training.

**Opportunity ledger.** The advert is clear and open. The pay is published and sits in the market range, with mileage and pool cars (RR1). Support for nurses new to community work is stated, and the team lead has spoken publicly about it (RR2). Three things are still open: whether the post is still live (RR3), the working pattern (RR4) and how big the caseload is (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can give a specific example for R4 (record keeping), since it's an essential criterion (G1); (2) R10 and R11 are described honestly as things you'll learn, never as caseload or Doppler experience; (3) the informal chat confirms the post is still open (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company founded in 2015. It runs adult community nursing, therapy and rehab across Calderdale under an NHS contract, with 410 staff in four locality hubs | `[grounded]` the employer's own About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, all recorded on an electronic patient record | `[grounded]` advert |
| Support | "a small caseload of your own, supported by a senior community nurse" | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Scope read | A normal Band 5 community role built for someone moving into community work. The caseload is small and supported, and Doppler is only desirable | `[inferred]` from the advert's "small" and "supported" wording and Doppler being listed as desirable |
| Market calibration | Band 5 community staff nurses in England: median basic pay £34,300, middle half £32,400–£36,600. The advert's range covers that band at both ends. This is a market pattern, not this employer's offer | `[generic]` Wardround 2026 UK Community Nursing Pay Guide; `[grounded]` advert, for the stated range |
| Unknowns | Whether the post is still open and its closing date; shifts, weekends and bank holidays; caseload size and how soon it starts; which EPR system is used | — |
| Contradictions | None between the advert and the About page. I couldn't find this post on the careers page (RR3) | `[grounded]` About page search; careers-page fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV says Registered Nurse (Adult), registration active, revalidation due March 2028. You stated it and I haven't checked it. I haven't used your PIN in any search | `[grounded]` CV | Check your own entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV says full UK licence, category B. Stated, not checked | `[grounded]` CV | Check your own driving record with DVLA (points, expiry) |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse is well over the one-year minimum. This is a length of experience, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records (on an EPR) | must_have | unclear | low | discovery | The CV doesn't mention documentation or any electronic record system. I'm not assuming practice you haven't stated | `[grounded]` CV says nothing on it | G1 |
| R5a | Wound care | must_have | direct | medium | none | CV: "Wound care including pressure ulcers and surgical wounds" | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | unclear | low | discovery | Leg ulcers aren't named in the CV; you've only said you haven't done Doppler, which is a separate thing (R11) | `[grounded]` CV says nothing on it | G3 |
| R6 | Catheter and continence care | must_have | adjacent | medium | discovery | Catheter care is stated. Wider continence work (assessment, products, bowel care) isn't | `[grounded]` CV | G4 |
| R7 | End-of-life visits | must_have | unclear | low | discovery | The CV doesn't mention end-of-life care | `[grounded]` CV says nothing on it; `[generic]` acute medical wards often care for dying patients, which is why it's worth asking | G2 |
| R8 | Insulin administration | must_have | direct | medium | none | CV: "insulin administration" | `[grounded]` CV | none |
| R9 | Caring for housebound adults in their own homes | must_have | direct | medium | none | 18 months seconded to discharge-to-assess, "visiting patients at home in their first week after discharge" | `[grounded]` CV | Lead with it (E1) |
| R10 | Hold a small caseload of your own | important | adjacent | medium | transferability | You've made home visits but say you've never held a caseload. The advert says the caseload is supported, which narrows the gap without closing it | `[grounded]` CV and your own statement | G5 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've said you've never done one. It's only desirable | `[grounded]` your own statement | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | Nothing on documentation or electronic records | It's an essential criterion, and essential criteria are usually scored against your supporting statement | Writing up discharge-to-assess visit notes the same day; documenting wound measurements or photos; care plans and risk assessments (Waterlow, MUST); taking part in a documentation audit; any EPR system you've used | An appraisal comment, documentation audit feedback, a revalidation reflective account | `[grounded]` the CV doesn't mention it; `[generic]` that shortlisting scores essential criteria |
| G2 | End-of-life visits (R7, must_have) | discovery | Not in the CV | It's a core part of district nursing as the advert describes it | Caring for dying patients on the ward; syringe drivers; anticipatory medicines; supporting families; verification of expected death; discharge-to-assess patients on an end-of-life pathway | Syringe driver competency, verification of expected death training, an end-of-life care course certificate | `[grounded]` the CV doesn't mention it |
| G3 | Leg-ulcer care (R5b, must_have) | discovery | Wound care is stated, leg ulcers aren't | It's named first in the advert's list of duties | Dressing venous or mixed leg ulcers on the ward or at home; compression bandaging; referring to tissue viability | Tissue viability or compression training record | `[grounded]` the CV doesn't mention it |
| G4 | Continence care (R6, must_have) | discovery | Catheter care only | Wider continence work would turn this row from adjacent into direct | Continence assessments, bladder scanning, trial without catheter, bowel care, choosing products | Catheterisation or continence competencies | `[grounded]` CV |
| G5 | Own caseload (R10, important) | transferability | Discharge-to-assess home visits; no caseload of your own (your own statement) | What carries over: assessing people at home on your own. The limit: you haven't been accountable over time for a list of your own patients. What strengthens it: say both plainly and ask about the support (RR5) | — | — | `[grounded]` CV and your own statement |
| G6 | Doppler (R11, preferred) | capability | Never done (your own statement) | It's only desirable, so a small risk. The way to close it is Doppler/ABPI training, which the team lead has spoken about providing for staff new to community work (RR2) | — | A Doppler/ABPI course certificate, once you have one | `[grounded]` your own statement; forum speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay published and in the market range, mileage and pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay terms are clear and competitive | `[grounded]` advert; `[generic]` the Wardround band | Where in the range would someone with five years post-registration start? | noted |
| RR2 | Support for staff new to community work | positive_signal | — | "supported by a senior community nurse" | The role is set up for people moving from hospitals into community work; the team lead has spoken on Doppler training for staff new to community | `[grounded]` advert and forum speaker page | What do Doppler training and caseload support look like in the first three months? | noted |
| RR3 | Post not found on the careers page | unknown | — | "Current vacancies are listed on our careers page" | The careers page may be at a different address, or the post may have closed | `[inferred]` from a fetch that returned no page | Is the Band 5 community staff nurse post in Halifax still open, and what's the closing date? | unresolved |
| RR4 | Working pattern not stated | unknown | — | (the advert says nothing on hours) | The role may include weekends or bank holidays | `[generic]` district nursing services often run seven days | What's the shift pattern, including weekends, bank holidays and late visits? | unresolved |
| RR5 | Caseload size and timing undefined | unknown | — | "a small caseload of your own" | "Small" may mean different things to different teams | `[inferred]` from the advert's undefined word | How many patients would I hold, and how soon after starting? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Book the informal chat with Rhiannon Mabbott. Confirm the post is open and ask the RR3, RR4 and RR5 questions | The advert invites it, and it clears condition (3) | `[grounded]` advert | pending your approval |
| E1 | Open your supporting statement with: "For the last 18 months I have been seconded to my hospital's discharge-to-assess team, visiting patients at home in their first week after discharge." | See R9. It's your own CV sentence, not widened into "community nursing experience" | `[grounded]` CV | pending your approval |
| E2 | Name the gaps plainly: "I haven't yet held my own caseload or carried out Doppler assessments, and I'd want to build both with the support your advert describes." | See R10, R11. Saying it first beats being caught on it | `[grounded]` your own statements; advert | pending your approval |
| A2 | Ask about Doppler training in the chat and in the interview | See RR2, G6 | `[grounded]` forum speaker page | pending your approval |
| A3 | Write one specific example each for R4, R5b and R7 once you've answered below | Essential criteria are scored on what's written | `[generic]` how shortlisting usually works | pending your approval |

## Evidence status

Verified: none yet. You don't need your National Insurance number for this; I haven't used or repeated it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers community staff nurse band 5". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. This gave the Organization row, the Contradictions row and RR3 |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing salary 2026 Agenda for Change", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). This gave the Market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). This gave RR2, G6 and A2 |

If you'd like, I can save all of this as a `tuesday-dossier.md` file to keep or reuse later.

## Upgrade menu

- Your answers to G1–G3 would move R4, R5b and R7 from `unclear` and give your supporting statement its examples. An answer to G4 would do the same for R6.
- A competency record, training certificate, appraisal comment or revalidation reflective account would raise the matching row from `medium` towards `high`. In nursing, those are what count as checkable proof.
- A link to the live posting, or its closing date, would close RR3.
- The shift pattern and caseload size from the informal chat would close RR4 and RR5.
- Your own non-negotiables (minimum pay, hours, weekends) would let me check the role against them; right now that check is marked unknown.
- I can also look deeper into Calderbrook: inspection ratings, staff reviews and recent news. That's up to 5 more searches and 2 more fetches; just say if you want it.

## Questions

**G1:** When you write up a patient's care, on the ward or after a discharge-to-assess visit, what do you record, when, and on what system? Has anyone ever commented on your notes, for example in an audit or appraisal?

**G2:** Have you cared for patients at the end of life, on the ward or at home? For example syringe drivers, anticipatory medicines, supporting families, or verifying an expected death.

**G3:** Have you dressed or bandaged leg ulcers, on the ward or on home visits? Did you do any compression bandaging or refer patients to tissue viability?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.