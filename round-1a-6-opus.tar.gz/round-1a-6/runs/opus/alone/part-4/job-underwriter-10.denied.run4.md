Reading the assessment rules, then I'll check Fernquay online.
Now checking whether Fernquay can be found online.
**Yes, it's worth taking the call. Nothing in the posting or the WhatsApp message asks you for anything unusual, but I couldn't check the company from here (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (Be the first and only designer), R8 (Run research calls with school owners)

R7: you've never been the only designer, but your past work gets you partway there; R8: your customer usability sessions get you partway to interviewing school owners.

**Opportunity ledger.** I couldn't confirm the company exists, because both of my searches were blocked (RR1). They state the salary and equity openly (RR2). Who makes the final call on design is unknown (RR3).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given, so I couldn't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm the company exists before the call (RR1, plan row A1); (2) you describe R7 honestly as something you haven't done yet, not as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, making booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Hiring process | A 45-minute video call with Ronan and Saoirse (CTO). The invite and link came by email; WhatsApp was only used to schedule it | `[grounded]` WhatsApp message |
| Scope read | One product area, one designer, two engineers, sitting right next to a founder. The scope is coherent, not several jobs bundled into one | `[inferred]` from the team size and mandate in the posting |
| Market calibration | Not run, because search was blocked. The upgrade menu says what it would add | — |
| Unknowns | Whether the company is registered; equity terms (vesting, options or shares); contract type; who has final say on design; funding and runway | — |
| Contradictions | None in the posting. Nothing to compare it with, since no company pages could be read | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days work | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company. Self-reported and not yet probed, so `medium` for now | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily" | `[grounded]` your background | A Figma file or portfolio piece would raise this to `high` |
| R4 | Has run their own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers | `[grounded]` your background | A session plan or a findings write-up would raise this to `high` |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R6 | Design the booking flow | must_have | direct | medium | none | You redesigned a checkout flow at a travel-booking company, which is the same kind of problem | `[grounded]` your background | The checkout case study the message mentions is the artifact that would raise this to `high` |
| R7 | Be the first and only designer, owning the flow end to end | important | adjacent | medium | transferability | You say you've never been the only designer. Owning the checkout redesign inside a squad still carries over. The limit: you haven't set up design practice alone, with no design peers to critique or review your work. `[generic]`: first-designer roles usually also mean setting up your own tools and review habits | `[grounded]` your own statement; `[generic]` the role-family pattern | See G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over. The limit: interviewing business owners about how they run their operations is a different kind of session from testing a consumer flow. Your background doesn't say whether you've done that | `[grounded]` your background; `[inferred]` the difference between the two kinds of session | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R7, important) | transferability | Four years in a squad. You've stated you've never been a sole designer | It's the core of the role, and the gap you named yourself | Times you were the only designer on a project or workstream; setting up a research cadence nobody asked for; making design calls without a design lead; mentoring or onboarding someone | A project where you made the calls, and what you'd set up in your first month | `[grounded]` your statement; `[inferred]` that it matters most for this role |
| G2 | Research with school owners (R8, important) | transferability | Monthly usability sessions with customers. No mention of supplier, partner or operator interviews | The posting names this as a core duty | Interviews with hotel or tour operators selling through your platform; calls with customer-support or partner teams; discovery interviews rather than usability tests | A discussion guide, a synthesis board, a research readout | `[grounded]` your background is silent on this; `[inferred]` that it's a different kind of research |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Company not confirmed from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have much online, the posting may be stale, or it may not be a real hiring employer. All three are open possibilities and none is ranked above the others | `[generic]` a pattern for companies this size, not a claim about this one | Is this role listed on Fernquay's own website, and what name is the company registered under? | unresolved |
| RR2 | Salary and equity stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | They are open about pay, but the equity's real value depends on terms they haven't given | `[grounded]` posting; `[inferred]` that the value depends on terms | Is the equity options or shares, what's the vesting schedule, and what valuation is it based on? | noted |
| RR3 | Who decides on design is unstated | unknown | — | "You will work most closely with our co-founder, Ronan Kehoe" | You may own the flow while the founder keeps the final say on design | `[generic]` a common pattern for a founder working closely with a first designer | When you and the first designer disagree on a design decision, how does it get settled? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from an email address on a Fernquay website domain, and look the company up in the Companies Registration Office (CRO) register | Clears RR1 cheaply | `[generic]` the CRO is Ireland's public company register | pending your approval |
| A2 | Treat the WhatsApp contact as normal: it was only used to schedule a video call held elsewhere. Join the call through the link in the emailed invite | Small teams often arrange calls this way | `[generic]` common practice at small companies | pending your approval |
| A3 | Lead with the checkout work in your own words: "I redesigned our checkout flow at a travel-booking company and ran monthly usability sessions with customers." Claim end-to-end ownership only if that's how it actually went | R6, R4 | `[grounded]` your background | pending your approval |
| A4 | Name R7 yourself: "I've always worked in a squad with engineers; I haven't been the only designer yet." Follow it with what you'd do about that, once G1 is answered | R7, so they don't find it out from you later | `[grounded]` your own statement | pending your approval |
| A5 | Ask the RR1, RR2 and RR3 questions on the call, word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay Galway booking software surf kayak schools". The call was refused because search permission wasn't granted. It would have settled RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 startup". The call was refused because search permission wasn't granted. It would have given the market calibration row and a comparison for the €52–60k range |
| 3. Hiring manager's public footprint (Ronan Kehoe) | unavailable | No search sent, since search permission wasn't granted. It would have filled in role reality's scope read and told me which story A3 should lead with for him |

I can write all of this up as a `tuesday-dossier.md` file you can keep, if that's useful.

**Upgrade menu**
- **Allow web search:** I can check RR1 against Fernquay's own site and set €52–60k against Irish product-design pay.
- **The sender address on the calendar invite:** RR1 may clear straight away, which would move the decision to `go`.
- **Your pay floor and any non-negotiables:** I can check the role against your own terms.
- **The checkout case study or a Figma link:** R3, R4 and R6 could move to `high`.
- **Answers to G1 and G2:** R7 and R8 get bridges you can actually say out loud on the call.
- **A deeper research pass:** this covers funding, leadership changes and any public employee reports, and costs up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

G1: Was there a project or stretch of time where you made the design calls without a design lead? What did you set up yourself?

G2: Have you ever interviewed operators, partners or suppliers about how they work, rather than testing a flow with customers?

R1: Do €52–60k and two Galway office days a week both work for you, or is there a pay floor I should check against?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.