I'm working through the job-assessment checklist for both roles. Next I'm reading the research and evidence rules, then I'll check both employers online.
I've read the rules. Now I'm checking both employers online.
I couldn't run any web searches (search permission wasn't granted), so these verdicts rest only on the two postings and your background.

# 1 · Operations Analyst — Duinvaart Cold Chain, Rotterdam

## Decision snapshot

**Yes, this one is worth your time. It's close to the job you just did. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days a week in our Rotterdam office)
- `must_have` — direct: R2, R3, R4, R5
- `important` — adjacent: R7 (Work with depot managers on route changes) · unclear: R6 (Temperature compliance across our refrigerated fleet)
- `preferred` — adjacent: R8 (Dutch a plus)

R2, R3, R4, R5 — your daily work restated; R6 — the one real knowledge gap, possibly smaller than it looks; R1 — the only thing that could stop it.

**Opportunity ledger.** The scope is concrete and measurable (DR3). The employer and live posting are unverified because research couldn't run (DR1), and pay isn't stated (DR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) three days a week in Rotterdam works for you (R1); (2) the role appears on Duinvaart's own careers site (DR1); (3) R6 is framed honestly as cold-chain knowledge you'd be learning, never as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, runs a refrigerated fleet | `[grounded]` JD header and text; existence not checked (DR1) |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in Rotterdam | `[grounded]` JD |
| Scope read | A mid-level analyst role: 2+ years asked, reporting and analysis rather than team leadership | `[inferred]` from the JD's experience bar and the absence of any people or budget language |
| Market calibration | Not established, because the role-family search couldn't run | — |
| Unknowns | Pay; contract type; who the role reports to; size of the fleet | — |
| Contradictions | None within the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't said whether this commute works. Your last job was in Amsterdam | `[grounded]` JD; your background is silent on location | Closing question 1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, which is over the bar. Self-reported, so expect a probe | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | "SQL daily." Specific, but nothing to inspect yet | `[grounded]` your background | Be ready for a live SQL exercise |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including a dashboard depot managers rely on | `[grounded]` your background | A sanitized screenshot of the dashboard would raise this to high |
| R5 | Track on-time delivery; weekly dashboards | must_have | direct | medium | none | You built the on-time delivery dashboard your depot managers use. That's this responsibility | `[grounded]` your background | none |
| R6 | Temperature compliance, refrigerated fleet | important | unclear | low | discovery | Parcel work may not have included temperature monitoring, but you haven't said either way. `[generic]` cold-chain analysis adds sensor data, temperature excursions and compliance reporting to normal delivery metrics | `[grounded]` your background is silent; `[generic]` cold-chain pattern | G1 |
| R7 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review. What's still open is whether that review led to route changes you proposed or drove | `[grounded]` your background | G2 |
| R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, by your own account. The posting only calls it "a plus" | `[grounded]` your background and JD | Say "conversational Dutch" exactly, never more |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | discovery | No mention of temperature-controlled or time-critical shipments | It's half of the role's stated mandate. Even partial evidence shrinks the one real gap | Pharma, food or medical parcels with handling rules; SLA or exception tracking on time-critical deliveries; any sensor or telematics data you queried | A dashboard page, an exception report, a SQL snippet (sanitized) | `[grounded]` your background is silent; `[inferred]` that it's the gap most likely to be raised |
| G2 | Route changes with depot managers (R7, important) | transferability | You ran route-performance reviews. Whether they changed routes isn't stated | Turns "I reported on routes" into "my analysis changed routes", which is what the JD describes | A route re-cut after your review; a depot that moved stops or time windows on your numbers; a before/after on-time figure | Review deck, before/after metric | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to show up online, the posting may be stale or copied from another site, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; research couldn't run | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| DR2 | Pay not stated | unknown | — | (the posting has no pay line) | The figure may be below or above what you'd accept; many Dutch postings leave pay for the first call | `[generic]` posting pattern | What's the salary range budgeted for this role, and is it a permanent contract? | unresolved |
| DR3 | Concrete, measurable scope | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Success is measurable, and the scope is defined | `[grounded]` JD | Which metrics would define success in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open your CV with: "4 years as operations analyst at a parcel carrier; built the on-time delivery dashboard (Power BI, SQL) used by depot managers; ran the weekly route-performance review." Leave out "cold chain" and "led route changes" | R2, R4, R5, R7. It's your own words, and nothing is widened | `[grounded]` your background | pending your approval |
| A1 | Before applying, find this role on Duinvaart's own careers site | DR1 | `[grounded]` DR1 | pending your approval |
| A2 | In a cover note, name temperature compliance as the part you'd ramp up on, unless G1 turns up real evidence | R6 | `[grounded]` R6 row | pending your approval |
| Q1 | Ask the DR1, DR2 and DR3 questions in the first call | Settles pay and the employer early | `[grounded]` register | pending your approval |

---

# 2 · Supply Planner — Kroonhaven Foods, Utrecht

## Decision snapshot

**No, probably not worth your time right now. K2, K3 and K5 are must-haves you've said yourself you don't have. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: K1 (On-site in Utrecht)
- `must_have` — adjacent: K4 (Run the weekly S&OP meeting) · unclear: K6 (Advanced Excel), K7 (SAP IBP or a similar planning system) · absent: K2 (3+ years of supply or demand planning in FMCG), K3 (Own the 13-week supply plan), K5 (Fluent Dutch)

K2, K3, K5 — gaps stated by you, none closable before applying; K4 — a real bridge, not enough on its own.

**Opportunity ledger.** The role is clearly owned and well defined (KR3). The employer is unverified (KR1) and pay isn't stated (KR2). Neither changes the decision; the fit does.

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would have to be different:** 3+ years of hands-on supply or demand planning (K2, K3) and fluent Dutch (K5). A junior planner role run in English would be the realistic way into planning.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, a chilled ready-meals range | `[grounded]` JD; existence not checked (KR1) |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | An experienced-planner role: it owns the plan and chairs S&OP, so it's not an entry point into planning | `[inferred]` from "own", "run" and the 3+ years bar |
| Market calibration | Not established, because the role-family search couldn't run | — |
| Unknowns | Pay; team size; whether English is workable day to day | — |
| Contradictions | None within the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't stated a location limit | `[grounded]` JD; your background is silent | Matters only if the K2, K3 and K5 gaps change |
| K2 | 3+ years supply or demand planning, FMCG | must_have | absent | medium | capability | "I've never worked in planning": your own specific statement | `[grounded]` your background | Closure path: a junior or associate planner role |
| K3 | Own the 13-week supply plan | must_have | absent | medium | capability | Same basis as K2. Owning a plan is core planning work | `[grounded]` your background | As K2 |
| K4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review: a recurring cross-team performance forum. Limit: S&OP trades off sales, production and inventory decisions, which you haven't done | `[grounded]` your background; `[generic]` what S&OP covers | none |
| K5 | Fluent Dutch | must_have | absent | medium | capability | Conversational, not fluent, by your account. The posting says "fluent" | `[grounded]` your background and JD | Closure path: language study; not closable for this application |
| K6 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned. Likely present for an analyst, but not stated | `[inferred]` from the analyst role | Not asked; it can't move the decision |
| K7 | SAP IBP or a similar planning system | must_have | unclear | low | discovery | Not mentioned; planning systems usually come with planning work | `[inferred]` from K2 | Not asked; it can't move the decision |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning experience (K2, K3, must_have) | capability | No planning roles, by your own statement | It's the role's core; the status is `no_go` on it | Only if you did capacity or volume forecasting for depots, such as peak-season staffing or parcel-volume projections. Mention it if so; it would make a junior planner move more credible | Forecast workbook, peak plan | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KR1 | Employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The company may be too new or small to show up online, the posting may be stale or copied from another site, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; research couldn't run | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| KR2 | Pay not stated | unknown | — | (the posting has no pay line) | The figure is unknown either way | `[generic]` posting pattern | What's the salary range budgeted for this role? | unresolved |
| KR3 | Clearly owned scope | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | Accountability is defined | `[grounded]` JD | Who owns the forecast that this plan balances against? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| K-A1 | Skip this one. Put the time into Duinvaart and similar operations-analyst roles | K2, K3, K5 | `[grounded]` evidence map | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page — Duinvaart | unavailable | Searched "Duinvaart Cold Chain Rotterdam"; refused (no search permission). Would have confirmed the company and live posting, clearing DR1 |
| 1. Official site and careers page — Kroonhaven | unavailable | Searched "Kroonhaven Foods Utrecht"; refused. Would have addressed KR1 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands Rotterdam" and "supply planner FMCG salary Netherlands"; both refused. Would have filled market calibration and given DR2 and KR2 a pay band |
| 3. Hiring manager's public footprint | n/a | No name was given for either role |

I can save all of this as a `tuesday-dossier.md` file you can keep or reuse, if that's useful.

**Upgrade menu**
- Allow web search → checks that both employers and postings are real and live (DR1, KR1), plus a Dutch pay band for each role (DR2, KR2).
- Your pay floor, commute limits and contract preferences → R1 and K1 resolve, and the hard-gates lines become real checks.
- A sanitized screenshot of your on-time delivery dashboard → R4 and R5 rise to `high`.
- Answers to G1 and G2 → R6 and R7 firm up, and the Duinvaart CV line can say more.
- A deeper research pass on Duinvaart (funding, leadership, employee reviews, recent news; up to 5 more searches and 2 more fetches) → say the word, once search is allowed.

**Questions**

1. R1 — Can you do three days a week in Rotterdam? Do you have a minimum salary or other dealbreakers I should check these roles against?
2. G1 — In your parcel work, did you handle any temperature-sensitive, pharma or time-critical shipments, or query any sensor or exception data?
3. G2 — Did your weekly route-performance review ever lead to a route change? What changed, and what happened to on-time delivery afterwards?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.