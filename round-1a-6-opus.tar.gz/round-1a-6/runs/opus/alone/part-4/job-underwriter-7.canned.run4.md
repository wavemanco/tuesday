Reading the skill's last two rule files, then I'll run the research and write up the assessment.
**Yes, it's worth applying for. R1 and R2 (both hard gates) are met, and R4 is still to be evidenced. Status: `conditional_go`.**

Your National Insurance number isn't needed to assess this role, so I haven't used it. Leave it out of anything you send until you're given a written offer.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5a, R6a, R8, R11 · adjacent: R10 (A small caseload of your own) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R9 (Care planning)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R4: a must-have your CV doesn't show yet; R10: a credible bridge from discharge-to-assess visits, with its limit named; R12: you haven't done it, but there's a likely route to training.

**Opportunity ledger.** The pay sits in line with the market and mileage is paid (RR2). A new caseload holder gets senior support (RR3), and the team lead talks publicly about Doppler training for staff new to community work (RR5). Two things are open: whether the posting is still live (RR1) and how big the caseload is (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can point to concrete examples of your record-keeping (R4, G1); (2) the post is confirmed still open (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` the company's About page (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, all recorded on an electronic patient record (EPR) | `[grounded]` advert |
| Scope signals | "a small caseload of your own, supported by a senior community nurse"; pool cars provided | `[grounded]` advert |
| First-90-days outcome | Probably supported practice while your own small caseload builds up | `[inferred]` from "small caseload… supported by a senior community nurse". The advert states no timeline |
| Market calibration | Band 5 community staff nurse in England: median basic pay £34,300, interquartile range £32,400–£36,600. The advert's £31,050–£37,800 spans that range. This is a market band, not this employer's offer for you | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (n=1,240); `[grounded]` advert for the posted range |
| Unknowns | Caseload size; length of the supported period; shift pattern; whether the post is still open | — |
| Contradictions | None found. The careers page couldn't be retrieved, so the posting hasn't been compared against it | `[grounded]` fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Adult registration, active, revalidation due March 2028. Stated, not checked | `[grounded]` CV | Check your own entry on the NMC register is current before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK category B licence. Stated, not checked | `[grounded]` CV | Check your own driving record is clean and current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical staff nurse is well past the one-year minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records (EPR) | must_have | unclear | low | discovery | The CV doesn't mention documentation or electronic record systems. Five years on a ward makes records likely, but that's an inference, not evidence | `[grounded]` CV silence; `[inferred]` from ward role | G1 |
| R5a | Wound care | important | direct | medium | none | You've done pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Your CV names pressure and surgical wounds only. Leg ulcers aren't mentioned either way | `[grounded]` CV | G2 |
| R6a | Catheter care | important | direct | medium | none | On your CV as stated | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Your CV names catheter care, not wider continence assessment or care | `[grounded]` CV | G2 |
| R7 | End-of-life visits | important | unclear | low | discovery | Your CV doesn't mention end-of-life care | `[grounded]` CV silence | G2 |
| R8 | Insulin administration | important | direct | medium | none | On your CV as stated | `[grounded]` CV | none |
| R9 | Care planning | important | unclear | low | discovery | Your CV doesn't mention writing care plans | `[grounded]` CV silence | G1 |
| R10 | Holding a small caseload of your own | important | adjacent | medium | transferability | 18 months of discharge-to-assess home visits is close to this. Limit: you've never held a caseload of your own, as you say yourself. The advert pairs the caseload with senior support | `[grounded]` CV and your statement | G3 |
| R11 | Caring for housebound adults in their own homes | important | direct | medium | none | 18 months visiting patients at home in their first week after discharge | `[grounded]` CV | Lead with it (A1) |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. It's desirable, not essential, so this isn't a blocker | `[grounded]` your statement | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and care planning (R4 must_have, R9 important) | discovery | Your CV doesn't mention documentation, record systems or care plans | R4 is the must-have the conditions rest on | Writing up discharge-to-assess visits; the ward's electronic record or nursing documentation system; risk assessments such as Waterlow, MUST or falls; care plans you started or updated; a documentation audit you were part of | Names of the systems you've used; any documentation training or audit role (never patient records) | `[grounded]` CV silence; `[inferred]` that this is the condition to clear |
| G2 | Leg ulcers, continence, end of life (R5b, R6b, R7) | discovery | Only pressure and surgical wounds and catheter care are named | Three core parts of the job's daily work | Venous or mixed ulcers on medical patients; compression bandaging; continence assessments or pad and product reviews; caring for dying patients on the ward or in their first week home; syringe-driver checks; anticipatory medicines | Training certificates, such as compression, end-of-life care or syringe-driver training | `[grounded]` CV silence |
| G3 | Own caseload (R10) | transferability | Discharge-to-assess home visits; no caseload of your own | The role gives you a caseload from the start | What carries over: assessing patients and planning around them in their own homes, working alone on visits. Limit: you haven't held a continuing caseload of your own. What would strengthen it: an example of running your own visit list or prioritising your day on the discharge-to-assess team | A reference from your discharge-to-assess lead | `[grounded]` CV; `[inferred]` bridge |
| G4 | Doppler (R12) | capability | Never done | It's a desirable skill only | Closure path: training. The team lead has spoken publicly about Doppler training for staff new to community work | A Doppler or leg-ulcer course certificate, if you complete one | `[grounded]` your statement; `[grounded]` community nursing forum speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not found on the company's own careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The post may have closed, or the careers page may be at a different address | `[inferred]` from the careers fetch returning no page while the About page points to one | Is the Band 5 community staff nurse post in Halifax still open, and where do I apply? | unresolved |
| RR2 | Pay in line with the market, plus mileage and pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage… pool cars are provided" | The posted range spans the market's middle range | `[grounded]` advert; `[generic]` Wardround survey | Where on the range would five years' post-registration experience start? | noted |
| RR3 | Senior support for a new caseload holder | positive_signal | — | "supported by a senior community nurse" | You won't be carrying a caseload alone from the start | `[grounded]` advert | How long does the supported period last, and how does the caseload grow? | noted |
| RR4 | Caseload size not stated | unknown | — | "a small caseload of your own" | "Small" isn't defined | `[inferred]` from advert wording | How many patients and visits a day would I hold at first? | unresolved |
| RR5 | Team lead talks publicly about Doppler training for new community staff | positive_signal | — | Forum page: "Doppler training for staff new to community work" | Training for R12 is plausibly available | `[grounded]` community nursing forum speaker page | Is Doppler training offered to new starters, and when? | noted |

## Application plan

Everything here is proposed, the CV wording and the positioning advice alike. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the discharge-to-assess secondment: home visits, working alone, patients in their first week after discharge | Supports R11 and R10. It's your closest match to the role | `[grounded]` CV | pending your approval |
| E1 | CV line, stated exactly as true: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge." Don't describe it as holding a caseload | R10's limit | `[grounded]` CV | pending your approval |
| A2 | Take up the informal chat with Rhiannon Mabbott and ask the questions from RR1, RR3, RR4 and RR5 | The advert invites the chat. Her public talks are on leg-ulcer clinics and Doppler training, so be upfront about R12 and ask about training | `[grounded]` advert; `[grounded]` forum speaker page | pending your approval |
| A3 | Add your G1 and G2 answers to the CV once confirmed | Closes R4, R5b, R6b, R7 and R9 | `[grounded]` gap queue | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse" and "Calderbrook Community Health careers vacancies Band 5 community staff nurse Halifax". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about), which confirms the organization. Fetching calderbrookhealth.example/careers returned no page, which gave RR1 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026/27 community staff nurse district nursing", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). This gave the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). This gave RR5, G4 and A2 |

I can turn this into a `tuesday-dossier.md` file you can keep or reuse later, if you'd like one.

**Upgrade menu**
- Your answer to G1 → R4 moves off `unclear`, which clears condition (1).
- Your answer to G2 → R5b, R6b and R7 update.
- A live link to the posting, or confirmation from the informal chat → RR1 closes, which clears condition (2).
- Your non-negotiables (pay floor, shifts, hours) → the hard-gates check runs against them.
- Training certificates (compression, end-of-life, syringe driver) → the matching rows can rise to `high`.
- A deeper research pass on Calderbrook (staff reports, recent news, service changes; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1: On the ward or on discharge-to-assess visits, what records did you keep and on which system, and did you write or update care plans yourself?

G2: Have you cared for patients with leg ulcers, done continence assessments, or nursed patients at the end of life? If so, what was your part?

Constraints: Do you have any non-negotiables, such as a pay floor, hours, shift pattern or weekend working, that this role would have to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.