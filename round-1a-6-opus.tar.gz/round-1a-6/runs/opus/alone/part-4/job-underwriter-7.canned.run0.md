I've read the skill's rules. Next I'm checking the employer and the market pay band with a few web searches.
**Yes, it's worth applying for, as long as two things check out (listed below). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5a, R6a, R8, R11 · adjacent: R10 (Hold a small caseload of your own) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits), R9 (Care planning)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R4: unclear only because your CV doesn't mention record-keeping; R10: your home visits make a credible bridge, but you haven't held a caseload; R12: a training gap, and the advert only lists it as desirable.

**Opportunity ledger.** The employer exists as described (RR1). The pay is stated and sits across the market range (RR3), and support for someone new is stated (RR4). Still open: whether the post is still live (RR2), and caseload size and hours (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4: you confirm your record-keeping experience and it goes on your CV (G1); (2) RR2: you confirm the post is still open, in the informal chat or on their own site.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the company's About page (search result) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all recorded on an electronic patient record | `[grounded]` advert |
| Support | Your own small caseload, "supported by a senior community nurse" | `[grounded]` advert |
| Working pattern | Driving between visits; pool cars provided, mileage paid. Hours and shift pattern not stated | `[grounded]` advert |
| Pay | £31,050 to £37,800 a year plus mileage | `[grounded]` advert |
| Scope read | A starter post into district nursing: a small caseload with senior support, and Doppler only desirable | `[inferred]` from the advert's caseload, support and essential/desirable wording |
| Market calibration | Wardround 2026 survey, community staff nurse Band 5 in England (n=1,240): median £34,300, middle half £32,400 to £36,600; 61% paid mileage, 24% had a pool or lease car. The advert's range covers that whole middle band, and it offers both mileage and pool cars. This is a market band, not Calderbrook's offer to you | `[generic]` role-family survey, 2026 edition; `[grounded]` advert, for the posted range |
| Unknowns | Whether the post is still open; caseload size; hours, evenings and weekends; which hub you'd work from | — |
| Contradictions | None found. The About page says vacancies are on the careers page, but no page loaded at the careers address I tried, so I couldn't confirm the post there (RR2) | `[grounded]` About page and the failed page fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Your CV says active registration (Adult), revalidation due March 2028. This is your statement and I haven't checked it | `[grounded]` CV | Check your entry on the NMC register says what your CV says |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV says full UK licence, category B. Your statement, not checked | `[grounded]` CV | Check your driving record says the same (no points issues you haven't mentioned) |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse. Self-reported, nothing to inspect yet | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | Your CV says nothing about record-keeping or which EPR you've used. Five years on a ward is a thread to follow, not evidence | `[grounded]` CV silence | G1 |
| R5a | Wound care | important | direct | medium | none | Your CV covers pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | No leg ulcers or compression in your CV. Your general wound care is a thread, not evidence for this | `[grounded]` CV silence | G2 |
| R6a | Catheter care | important | direct | medium | none | Your CV lists catheter care | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Your CV lists catheter care only, not continence assessment or management | `[grounded]` CV silence | G4 |
| R7 | End-of-life visits | important | unclear | low | discovery | Your CV is silent on it | `[grounded]` CV silence | G3 |
| R8 | Insulin administration | important | direct | medium | none | Your CV lists insulin administration | `[grounded]` CV | none |
| R9 | Care planning | important | unclear | low | discovery | Your CV is silent on writing or reviewing care plans | `[grounded]` CV silence | G5 |
| R10 | Hold a small caseload of your own | important | adjacent | medium | transferability | 18 months of home visits on the discharge-to-assess team is real community work. Limit: you say you've never held your own caseload, and visits in someone's first week after discharge aren't ongoing accountability for patients | `[grounded]` CV and your own statement | G6 |
| R11 | Caring for housebound adults in their own homes | important | direct | medium | none | 18 months seconded to discharge-to-assess, visiting patients at home | `[grounded]` CV; `[grounded]` advert, for the requirement | none |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. Closure path: training. The team lead has spoken publicly on Doppler training for staff new to community work | `[grounded]` your statement; `[grounded]` forum speaker page | Raise it in the informal chat (A3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records on an EPR (R4, must_have) | discovery | Nothing on documentation or which systems you've used | This is the only `must_have` row not yet direct; confirming it is a condition for go | Daily notes and assessments on the ward's electronic system (named); visit notes written up during or after discharge-to-assess visits; wound charts; handover or discharge documentation | Training record for the EPR system; any documentation audit you took part in | `[grounded]` CV silence; `[inferred]` that confirming it clears the condition |
| G2 | Leg-ulcer care (R5b, important) | discovery | Pressure and surgical wounds, no leg ulcers | Named first among the duties, and the desirable skill (R12) is about leg ulcers | Dressing venous or mixed leg ulcers on the ward; applying compression bandaging or hosiery; seeing leg-ulcer patients on home visits; referring to tissue viability | Wound-care or compression training certificate | `[grounded]` advert and CV |
| G3 | End-of-life visits (R7, important) | discovery | Nothing stated | A named duty | Caring for dying patients on the ward; syringe drivers; anticipatory medicines; fast-track discharges home that you then visited | End-of-life or syringe-driver training record | `[grounded]` CV silence |
| G4 | Continence care (R6b, important) | discovery | Catheter care only | A named duty | Continence assessments; bowel care; choosing and ordering products | Training record | `[grounded]` CV silence |
| G5 | Care planning (R9, important) | discovery | Nothing stated | A named duty | Writing and reviewing care plans on the ward or for discharge-to-assess patients | — | `[grounded]` CV silence |
| G6 | Own caseload (R10, important) | transferability | Bridge: 18 months of home visits. Limit: no caseload of your own. Strengthener: describe how your visits were planned and handed on | Shows the panel you understand the step up | Planning your own visit list; deciding visit priority; handing patients on to district nurses | A reference from the discharge-to-assess lead | `[grounded]` CV and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The employer exists as described | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | A CIC running adult community nursing in Calderdale under an NHS contract, which matches the advert | `[grounded]` About page | Which locality hub would this post work from? | noted |
| RR2 | Not confirmed that the post is live | unknown | — | "Current vacancies are listed on our careers page" | The careers page may just live at another address; the post may also have closed | `[grounded]` About page and the failed fetch | Is the Halifax Band 5 community staff nurse post still open, and what's the closing date? | unresolved |
| RR3 | Pay stated, plus mileage and pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay that covers the market's middle band | `[grounded]` advert; `[generic]` survey band | Where on the range would someone with five years post-registration start? | noted |
| RR4 | Support for newcomers stated | positive_signal | — | "supported by a senior community nurse" | Built for someone stepping into community nursing; the team lead has spoken on Doppler training for staff new to community | `[grounded]` advert and forum speaker page | What does support look like in the first months, and is Doppler training offered? | noted |
| RR5 | Caseload size and hours unstated | unknown | — | "a small caseload of your own" | "Small" and the shift pattern are undefined | `[inferred]` from the advert's silence | Roughly how many patients would I hold, and are there evenings or weekends? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead your supporting statement with the discharge-to-assess secondment, in your own words: "visiting patients at home in their first week after discharge" | see R11, R10 | `[grounded]` CV | pending your approval |
| A2 | Say plainly that you haven't held your own caseload or done Doppler, and that you want the training | see R10, R12; overclaiming either would come up quickly in your first weeks | `[grounded]` your statement | pending your approval |
| A3 | Take up the informal chat with Rhiannon Mabbott before applying, and ask the questions from RR2, RR4, RR5 | The advert offers the chat; the register doubles as your question list | `[grounded]` advert, register | pending your approval |
| A4 | Check your NMC register entry and driving record before applying | see R1, R2 | `[grounded]` CV | pending your approval |
| E1 | Add a records line to your CV, naming the EPR you've used, only once G1 is confirmed | see R4 | `[grounded]` CV silence | resume_edits_pending_approval |

Don't claim any of these: Doppler competence, holding a caseload, leg-ulcer or compression experience (until G2 confirms it), or "district nursing experience". Every row in this plan is pending your approval.

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this. I haven't repeated or used it, and you don't need to share it with me. Your NMC PIN went into no search.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved the Organization and Contradictions rows, RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing salary 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved Market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved R12's closure path, RR4 and A3 |

I can save all of this as `tuesday-dossier.md` for you to keep or bring to later sessions. Just say if you'd like it.

**Upgrade menu**
- Answers to G1 to G5 → those rows move off `unclear`, and the CV edits follow from them.
- A wound-care, compression or end-of-life training certificate → R5b or R7 gets evidence I can look at.
- The live advert link or closing date → RR2 closes.
- The caseload size and hours from the informal chat → RR5 closes.
- Your own non-negotiables (minimum pay, hours, how far you'd travel) → the hard gates get checked against you, not just the advert.
- A deeper research pass on Calderbrook (leadership changes, staff reviews, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G1: On your ward or the discharge-to-assess team, what records did you write yourself, and on which electronic system?

G2: Have you dressed leg ulcers or applied compression bandaging or hosiery, on the ward or on home visits?

G3: Have you cared for patients at the end of life, for example syringe drivers, anticipatory medicines, or visiting someone discharged home to die?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.