## Decision snapshot

**Yes, this is normal. Asking for bank details, your PPS number and a passport scan after a written offer that names the role and the pay is routine onboarding. Accepting is worth doing, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Hybrid, two days a week in the Limerick office), R11 (Right to work in Ireland)
- `must_have` — direct: R1, R3, R5, R8, R9 · adjacent: R2 (Monthly payroll for 240 staff) · unclear: R7 (Irish PAYE, PRSI and USC)
- `important` — unclear: R6 (Answer staff payroll queries) · absent: R4 (Pension changes)

R2: a step up in size, from fortnightly payroll for 90 staff to monthly for 240. R4: the one real skills gap, and it can be learned. R7: probably fine, but you haven't said so.

**Opportunity ledger.** The offer matches the ad (RR2) and came after two interviews at their office (RR3), so the process looks sound. I couldn't check their website because web search was blocked here, which leaves RR1 open. The written contract is still to come (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days a week in the Limerick office), R11 (Right to work in Ireland); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears. Their own website should match the office you visited and the people@marrowgatehousing.ie address. (2) R10 and R11 work for you. (3) You go in open about R4: you've seen pension changes done but haven't done them yourself.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` the ad |
| Mandate | Run monthly payroll for 240 staff, handle starters, leavers and pension changes, reconcile payroll to the general ledger each month, answer staff queries | `[grounded]` the ad |
| Offer terms | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid with two days a week in Limerick, start date agreed once your notice ends | `[grounded]` the offer email |
| Onboarding | After you accept: a link to an onboarding portal for bank details, PPS number and a passport scan, then the original passport on day one | `[grounded]` the offer email |
| Scope read | A normal-sized payroll administrator job: one payroll and one reconciliation, with no team to manage | `[inferred]` from the listed duties |
| Market calibration | Not checked, because the salary search was blocked. €40,000 sits in the middle of their own advertised €38,000–€42,000 range | `[grounded]` the ad and the offer, for the figure |
| Unknowns | Contract terms beyond the email, pension scheme, probation period | — |
| Contradictions | None between the ad and the offer | `[grounded]` the ad and the offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years. You stated it, but there's no document to check it against | `[grounded]` your background | none |
| R2 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | The same work at about 2.7 times the headcount, on a monthly cycle instead of fortnightly | `[inferred]` from 90 staff fortnightly against 240 monthly | G4 |
| R3 | Starters and leavers | must_have | direct | medium | none | You've done this directly | `[grounded]` your background | none |
| R4 | Pension changes | important | absent | high | capability | You said your manager handled them, so you haven't done them yourself. You can learn this on the job | `[grounded]` your own words | G1 |
| R5 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | An exact match | `[grounded]` your background | none |
| R6 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention queries, though this work usually comes with them | `[inferred]` from silence | G3 |
| R7 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You haven't said whether the hotel payroll was Irish | `[grounded]` not stated | G2 |
| R8 | Strong Excel | must_have | direct | medium | none | Daily use, including pivot tables and XLOOKUP | `[grounded]` your background | none |
| R9 | Payroll qualification | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R10 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | This is their term. You haven't said whether the commute works for you | `[grounded]` the ad and the offer | Question 1 |
| R11 | Right to work in Ireland | hard_gate | unclear | low | hard_gate | Implied by their right-to-work check. You haven't stated your status | `[inferred]` from the offer's right-to-work check | Question 1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R4) | capability | You saw your manager do them but didn't do them yourself | It's a named duty, so you'll do it from month one | Preparing the data for your manager, checking deductions after a change, answering staff questions about pensions | Training notes or a checklist you kept | `[grounded]` your words |
| G2 | Irish PAYE, PRSI and USC (R7) | discovery | Not stated | It's a core must-have | Running an Irish payroll, handling Revenue payroll notifications, the certificate syllabus | The certificate's syllabus | `[grounded]` not stated |
| G3 | Staff queries (R6) | discovery | Not stated | It's a named duty | Handling payslip questions at the hotel group | — | `[inferred]` |
| G4 | Scale and monthly cycle (R2) | transferability | 90 staff, fortnightly | A bigger, monthly run | Peak-season headcount, covering other payrolls | — | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked against attributable sources (web search blocked) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | Several explanations are possible, none ranked: the organization may be too small to show up much online, the ad may be stale, or it may not be a real hiring employer. Your two interviews at their office weigh strongly against the last one | `[generic]` pattern, not a claim about this employer | Can you confirm the onboarding portal address, as listed on your own website? | unresolved |
| RR2 | Offer matches the ad on title, pay range, hybrid terms and a named manager | positive_signal | — | "permanent post of Payroll Administrator at €40,000" | The offer looks consistent and open | `[grounded]` the ad and the offer | — | noted |
| RR3 | Two in-person interviews at their office | positive_signal | — | "two interviews in person at their office" | The process has a real setting you can point to | `[grounded]` your account | — | noted |
| RR4 | Written contract not yet seen | unknown | — | "Please reply to accept within five working days" | Pension, probation and leave terms aren't in the email yet | `[inferred]` from what the email leaves out | Could you send the contract of employment, or a summary of its terms, before I accept? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept, then enter bank details, PPS number and the passport scan only in the portal reached from Marrowgate Housing's own website, or one you confirm with them | Payroll needs your PPS number to get your tax details from Revenue and your bank details to pay you. Right-to-work checks normally use a passport. The advice never to hand these over is aimed at requests before an offer, or from people you can't place | `[generic]` how Irish payroll onboarding works | pending your approval |
| A2 | Ask for the contract or its terms before or when you accept | RR4 | `[grounded]` RR4 | pending your approval |
| A3 | In your first weeks, ask Declan for a walkthrough of how they process pension changes | R4, G1 | `[grounded]` R4 | pending your approval |
| A4 | Keep in mind you'll collect these same details from every new starter yourself | This is the starters part of the job | `[grounded]` the ad | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association", refused. It would have confirmed the organization and its web address, which resolves RR1 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026 Limerick", refused. It would have set the €40,000 against the market |
| 3. Hiring manager's public footprint | unavailable | No search sent because web search was refused. It would have shown Declan Garvagh's professional background |

If you'd like, I can write all of this up as a `tuesday-dossier.md` file you can keep.

**Upgrade menu**
- Allow web search → targets 1–2 run, and RR1 likely closes, along with the salary check.
- The contract terms → RR4 closes.
- Answers to G1 and G2 → R4 and R7 firm up.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) → adds to the risk register. Just say if you want it.

**Questions**
1. (R10, R11) Does two days a week in Limerick work for you, and do you have the right to work in Ireland?
2. (G2, R7) Was the hotel group's payroll Irish PAYE, PRSI and USC?
3. (G1, R4) How close were you to the pension changes: did you prepare the data, or just see the results?

Answer any of these in a word, a sentence or a story, or say "skip".

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.