Still working through the job-check method — next I'm running a few quick web searches to confirm the employer exists and see what this kind of role usually pays.
I couldn't check Marrowgate online because web search wasn't permitted, so this rests only on what you've shared. The direct answer is below.

## Decision snapshot

**Yes, this is normal. A credible written offer has named the role, the pay and your manager. Asking you after that for bank details, your PPS number and a passport scan is routine onboarding. Status: `conditional_go`: accept, on the conditions below.**

**Fit ledger.**

- `hard_gate`: direct: R4 · unclear: R1 (hybrid, two days a week in our Limerick office), R2 (€40,000 a year), R3 (our right-to-work check)
- `must_have`: direct: R5, R7, R9 · adjacent: R6 (run the monthly payroll for our 240 staff), R8 (pension changes) · unclear: R10 (Irish PAYE, PRSI and USC)
- `important`: direct: R11 · unclear: R12 (answer staff payroll queries)

R8 (`low`): pension changes, which you haven't done yourself; R6: a step up from fortnightly for 90 staff to monthly for 240; R10, R12: likely yours, not yet stated.

**Opportunity ledger.** Sound. There's a written offer with role, pay, manager and terms (RR2), and two interviews at their office (RR3). One open question is who trains you on pension changes (RR4). RR1 only records that my own check couldn't run.

- **Hard gates:** none failed (R4 `direct`); unconfirmed: R1 (hybrid, two days a week in our Limerick office), R2 (€40,000 a year), R3 (our right-to-work check); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1, R2 and R3 work for you: the Limerick days, the €40,000 and your right to work; (2) RR1 clears. A look at Marrowgate's own website does that, and your interviews at their office already go most of the way; (3) R8 is handled openly: you take up pension changes as something to learn (RR4), not as something you claim to have done.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` the job ad |
| Mandate | Monthly payroll; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` the job ad |
| Terms | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid with two office days, start after your notice period | `[grounded]` the offer email |
| Onboarding | After you accept: a portal link for bank details, PPS number and a passport scan; original passport on day one | `[grounded]` the offer email |
| Scope read | A normal single-person payroll remit for this size of organisation; the step up from your current job is the monthly cycle and the headcount | `[inferred]` from the ad's duties set against your background |
| Market calibration | Not established: the salary search didn't run. €40,000 sits mid-way in the ad's own €38,000–€42,000 range | `[grounded]` the job ad and the offer |
| Unknowns | Pension scheme(s) and who trains you on them; payroll software; probation terms | — |
| Contradictions | None between the ad and the offer | `[grounded]` the job ad and the offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You haven't said whether the commute works for you | `[grounded]` the offer; your background is silent on it | Closing question |
| R2 | €40,000 a year | hard_gate | unclear | none | hard_gate | No salary floor stated | `[grounded]` the offer | Closing question |
| R3 | Right to work in Ireland (their right-to-work check) | hard_gate | unclear | none | hard_gate | The offer names the check; your status isn't stated | `[grounded]` the offer | Confirm for yourself before day one |
| R4 | A payroll qualification or working towards one | hard_gate | direct | medium | none | Payroll Technician certificate, 2024. Stated, not yet inspected | `[grounded]` your background | none |
| R5 | 2+ years running payroll | must_have | direct | medium | none | 3 years at a hotel group | `[grounded]` your background | none |
| R6 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Carries over: running the full payroll cycle yourself. Limit: fortnightly rather than monthly, and 90 staff rather than 240 | `[grounded]` your background and the ad | see G3 |
| R7 | Process starters and leavers | must_have | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R8 | Process pension changes | must_have | adjacent | low | transferability | Carries over: running the payroll that pension deductions go through. Limit: you've never made a pension change yourself; your manager did those | `[grounded]` your own words; `[inferred]` that the deductions sat in payroll you ran | see G1 |
| R9 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | The same task, already monthly | `[grounded]` your background | none |
| R10 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You haven't said whether the hotel group's payroll was Irish | `[grounded]` your background is silent on it | see G2 |
| R11 | Strong Excel | important | direct | medium | none | Daily use, pivot tables, XLOOKUP | `[grounded]` your background | none |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Not mentioned, though it's likely part of a job like yours | `[grounded]` your background is silent on it; `[inferred]` likely | Upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R8, must_have) | transferability | Your manager did these; you ran the payroll around them | It's the one listed duty you haven't done yourself, so it's what you'll most need help with early on | Checking that deduction changes showed up correctly on payslips; keying new joiners' pension deductions; answering staff questions about deductions | Notes from your current job's process, with personal data removed | `[grounded]` your own words |
| G2 | Irish PAYE, PRSI, USC (R10, must_have) | discovery | Hotel-group payroll, country not stated | If it was Irish, R10 becomes `direct` | Revenue payroll submissions, handling Revenue's tax-credit and rate notices for staff (RPNs), PRSI classes, USC bands | Your certificate's syllabus | `[grounded]` your background is silent on it |
| G3 | Monthly cycle at 240 staff (R6, must_have) | transferability | Fortnightly, 90 staff | Monthly runs bunch more work into each cycle, at a larger scale | Any cover you did for other payrolls, or busy periods | — | `[inferred]` from the scale difference |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources: my searches were refused | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The organisation may be too new or small to show up online, the ad may be old or copied from elsewhere, or it may not be a real hiring employer. These are listed side by side; none is ranked as likely. Your two interviews at their office count heavily against the third | `[generic]` pattern, not a claim about this employer | Can you point me to this role on your own careers page? | unresolved |
| RR2 | Written offer naming role, pay, manager and terms | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | The terms are specific and match the ad | `[grounded]` the offer email | Will the contract also set out probation and the pension scheme? | noted |
| RR3 | Hiring process held in person at their office | positive_signal | — | "two interviews in person at their office" | A real process you can place | `[grounded]` your account | — | noted |
| RR4 | Support for pension changes not stated | unknown | — | "process starters, leavers and pension changes" | Pension work may come with or without training or a written procedure | `[inferred]` from the ad's silence | Which pension schemes do you run, and how will I be trained on making changes to them? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply to accept within the five working days, once R1–R3 work for you | The offer's deadline | `[grounded]` the offer | pending your approval |
| A2 | When the portal link arrives, check it's on Marrowgate's own domain (the one on their website and in people@marrowgatehousing.ie) before you enter anything. Enter details only in that portal, never by email reply | Advice for a routine step, not a condition of the decision | `[grounded]` the offer email's domain | pending your approval |
| A3 | Read "never hand those over" as being about requests that come before an offer or from unknown senders. After an accepted offer, the employer needs your bank details to pay you, your PPS number for Revenue, and your passport for the right-to-work check | Answers your worry directly | `[generic]` how onboarding usually works | pending your approval |
| A4 | Raise RR4's question with Declan Garvagh in your first weeks. Say plainly that pension changes were your manager's at the hotel group | Being open about R8 now avoids pension errors later | `[grounded]` R8, RR4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; refused. It would have cleared RR1 and filled role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026 Limerick"; refused. It would have set €40,000 against the market rate |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but no search was sent because searching was refused. It would have informed the scope read and positioning |

---

I can save this as a dossier file (`tuesday-dossier.md`) you can keep or reuse later.

**Upgrade menu**
- Allow web search → RR1 clears, and €40,000 gets a market comparison.
- Your hard limits on commute and pay → R1 and R2 close.
- An answer to G2 → R10 likely becomes `direct`.
- A deeper research pass (Marrowgate's news, leadership and staff reports; up to 5 more searches and 2 more fetches), if search is allowed. Say the word and it runs.

**Questions**

G1: When pension changes came up at the hotel group, what part did you see or touch: keying deductions, checking payslips, answering staff?

G2: Was the hotel group's payroll Irish, so PAYE, PRSI, USC and Revenue submissions?

R1/R2: Is there anything about the two Limerick office days or the €40,000 that doesn't work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.