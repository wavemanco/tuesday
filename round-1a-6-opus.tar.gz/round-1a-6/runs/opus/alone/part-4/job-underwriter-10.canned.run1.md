I'm reading the underwriting rules, then I'll do a quick public check on Fernquay.
I checked Fernquay's public footprint and underwrote the role against your background.

## Decision snapshot

**Yes, it looks legit and it's worth your time. You've already applied and they've asked you to interview, so take the call. Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4, R5
- `important` — adjacent: R6 (Own the booking flow end to end), R7 (Research calls with school owners) · unclear: R8 (Working as the first and only designer)

R6, R7 — credible bridges from your checkout and usability work, limits named in the map; R8 — new to you by your own account, and how much of it you've already done is still open.

**Opportunity ledger.** The employer checks out. Fernquay exists as the posting describes, the posting is live, and the people in the WhatsApp message match the company's own pages (RR1). The pay is stated and sits inside the market band (RR2). The open items are about how the job works: design feedback with no other designer (RR3), scope beyond the booking flow (RR4), and the equity terms (RR5). The WhatsApp message only schedules a video call through an emailed invite (see the Hiring process row in Role reality).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** a salary floor above €60,000, or another non-negotiable the role's terms conflict with (R1, RR2); answers to RR4 showing the job is much wider than the booking flow.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle and "funded by its customers". Makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` JD; fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Reporting line | Works most closely with Ronan Kehoe, co-founder and CEO, who was previously product lead at a Galway travel-software company for five years | `[grounded]` JD; Ronan Kehoe's public LinkedIn profile |
| Working pattern | Hybrid: two days a week at the Galway office | `[grounded]` JD; careers posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD; careers posting agrees |
| Scope read | A focused mandate: one flow, one research audience, two engineers. Normal scope for a first design hire at six people, not several roles folded into one | `[inferred]` from the JD's three named responsibilities and team size |
| First 90 days | Probably research calls with school owners plus a first pass at the booking flow | `[inferred]` from the JD's order of responsibilities; not stated |
| Market calibration | Irish product designers with 3–5 years: median base €57,000, middle half €51,500–€62,000. The posting's €52,000–€60,000 sits inside that range | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520), found this session; `[grounded]` JD for the posted figure |
| Hiring process | You applied, they praised your checkout case study, and they asked by WhatsApp for a 45-minute video call with Ronan and Saoirse (CTO), sent as an emailed calendar invite. Scheduling by chat for an interview held elsewhere is a routine step | `[grounded]` the WhatsApp message; `[generic]` that scheduling by chat is routine |
| Unknowns | How design gets reviewed; what sits outside the booking flow; equity terms (vesting, valuation basis) | — |
| Contradictions | None. The posting, the About page and the WhatsApp message agree on the people, the location and the pay | `[grounded]` About page and careers posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are local. Medium because this is your intake statement and you haven't confirmed the two days suit you | `[grounded]` your background | Confirm as part of the constraints question |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company. Self-reported at intake, with no artifact inspected | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily". A portfolio would make this inspectable | `[grounded]` your background | A portfolio link would raise it to high |
| R4 | Has run their own user research | must_have | direct | medium | none | "Ran monthly usability sessions with customers": recurring sessions you ran yourself | `[grounded]` your background | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers, and Fernquay has two | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | important | adjacent | medium | transferability | Checkout redesign at a travel-booking company is the same domain and part of the same flow. Limit: checkout is one stage, and it isn't established that you owned the earlier steps (availability, choosing a session, confirmation) or anything on the operator side. Fernquay's flow probably has a school-owner side too | `[grounded]` your background; `[inferred]` that the flow includes an operator side, from the product being sold to schools | See G1 |
| R7 | Run research calls with school owners | important | adjacent | medium | transferability | You ran usability sessions with customers, meaning end users. Limit: interviewing business owners about how they work is a different kind of research from task-based usability testing | `[grounded]` your background; `[generic]` that owner discovery interviews differ from usability testing | See G2 |
| R8 | Working as the first and only designer, with no design team around you | important | unclear | low | discovery | Inferred from "You would be our first designer". You say you've never been the only designer. What's unknown is whether you've done parts of it already: making design calls with no design lead, setting up your own process, getting critique without peers | `[grounded]` your statement; `[inferred]` requirement from the JD's "first designer" | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the booking flow end to end (R6, important) | transferability | A checkout redesign, but not which parts were yours, whether it shipped, or what it changed | This is the core of the job, and your checkout case study is what got you the call | Search and availability screens; booking changes and cancellations; payment and confirmation emails; a result you measured after launch | The checkout case study itself, a before/after flow, a launch note | `[grounded]` your background; `[inferred]` that this is the story the call will centre on, from their praise of it |
| G2 | Research with business owners (R7, important) | transferability | Monthly usability sessions with customers; nothing with suppliers, partners or operators | Owner calls are named in the JD; bridging them honestly helps your positioning | Talking to hotels, tour operators or other suppliers on the booking platform; stakeholder interviews; sitting in on sales or support calls | A discussion guide, a research synthesis | `[grounded]` your background |
| G3 | Being the only designer (R8, important) | discovery | Your statement that you've never been the only designer | The biggest change from your current job; an honest answer with real examples is stronger than none | A project you designed alone; a research cadence you set up yourself; a design decision you defended to engineers or a PM with no design lead backing you | Any project you led solo | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists as described; posting live; people match the message | positive_signal | — | "Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company, the role and the people who contacted you line up | `[grounded]` About page, careers posting, the WhatsApp message | Who else would I meet before an offer? | noted |
| RR2 | Pay stated and inside the market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The range is transparent and in line with the market for your experience | `[grounded]` JD; `[generic]` Tillerby band | Where in the range would someone with four years sit? | noted |
| RR3 | No other designer to give feedback | risk_signal | low | "You would be our first designer" | Your work may get product and engineering review but no design critique | `[generic]` first-design-hire pattern | How will design work be reviewed, and is there budget for outside critique, mentoring or conferences? | unresolved |
| RR4 | Scope beyond the booking flow unstated | unknown | — | "own the booking flow end to end" | A first designer often also picks up the marketing site, brand or the schools' admin screens | `[generic]` small-company pattern | Beyond the booking flow, what else would land on my desk in the first year? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on vesting, cliff, option type and valuation, none of which are given | `[generic]` how startup equity works | What decides 0.5% versus 1%, and what are the vesting, cliff and option terms? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the calendar invite came from a fernquay.example address (the careers posting uses jobs@fernquay.example), and join through that invite | A sensible habit for any call arranged by chat | `[grounded]` careers posting gives the domain | pending your approval |
| P2 | Lead with the checkout redesign and your monthly usability sessions, described exactly as you did them: travel booking, customers, a squad with four engineers | See R4, R6; Ronan has five years in travel software, so the domain will be familiar to him | `[grounded]` your background; Ronan Kehoe's public LinkedIn profile | pending your approval |
| P3 | When asked about being the first designer, say plainly that you haven't been the only designer before, then give whatever G3 turns up | See R8 | `[grounded]` your statement | pending your approval |
| P4 | Ask the RR2–RR5 verification questions in the call; Saoirse is the right person for how design and the two engineers hand off work | The register doubles as call prep | `[grounded]` register; JD | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer job", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Fetched fernquay.example/careers, which returned no page; the posting itself is live at the address above. Moved the Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 3-5 years 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the Reporting line row and P2 |

I can save all of this as `tuesday-dossier.md` so you can carry it into later sessions, if you'd like.

**Upgrade menu**
- Your salary floor and any other non-negotiables → the hard-gates check runs against you, not just the posting.
- A portfolio link or the checkout case study → R3 and R6 can rise to `high`.
- Answers to G1–G3 → R6, R7 and R8 firm up, and P2 and P3 get concrete wording.
- A deeper research pass on Fernquay (customer and funding history, recent news, any public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.
- Practising the 45-minute call is a job for the mock-interview skill, if you want that.

**Questions**

Constraints — Is there a salary floor, a start date or anything else you won't move on (including whether two office days suit you) that I should check this against?

G1 — In the checkout redesign, which parts were yours (research, flows, UI, testing), did it ship, and did you see a result afterwards?

G3 — Have you ever made and defended design decisions with no design lead behind you, for example a solo project, a research routine you set up yourself, or a call you argued through with engineers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.