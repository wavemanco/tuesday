I'm checking Marrowgate Housing's public footprint and typical pay for this role before I write up the answer.
**Yes, this is normal. You're being asked after a written offer, so this is standard onboarding.** The "never hand those over" rule is about requests that come *before* an offer, or out of the blue. Status for accepting: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R10 (right to work in Ireland), R11 (hybrid, two days a week in the Limerick office), R12 (€40,000 a year)
- `must_have`: direct: R1, R3, R5, R7, R8 · adjacent: R2 (monthly payroll for 240 staff) · unclear: R6 (Irish PAYE, PRSI and USC) · absent: R4 (pension changes)
- `important`: unclear: R9 (answering staff payroll queries)

R4: your one real gap, and it can be learned; R6: probably fine, but you haven't said; R2: a step up in headcount, at a simpler pay frequency.

**Opportunity ledger.** The offer looks sound. It names the role, pay, manager and terms, comes from the employer's own domain after two in-person interviews (RR2), and the pay sits inside the advertised band (RR3). I couldn't check Marrowgate online from here (RR1), but your in-person interviews already weaken that concern. RR4 is about pension training.

- **Hard gates:** none failed; unconfirmed: R10 (right to work in Ireland), R11 (hybrid, two days a week in the Limerick office), R12 (€40,000 a year); you haven't told me your own constraints, so I can't check against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate's own website uses the same domain the offer came from (RR1); (2) the salary, the two office days and your right to work all suit you (R10, R11, R12); (3) you're upfront about pensions and ask what training you'll get (R4, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` JD |
| Mandate | Monthly payroll; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` JD |
| Terms offered | Permanent, €40,000, reports to Declan Garvagh (Finance Manager), hybrid with two days a week in Limerick, start date agreed after your notice period | `[grounded]` offer email |
| Scope read | A standard single-administrator payroll post: one payroll run a month, with the ledger reconciliation included | `[inferred]` from the JD's duty list |
| Market calibration | Not available: the salary search was refused. €40,000 sits inside the posting's own €38,000–€42,000 band | `[grounded]` JD and offer |
| Unknowns | Pension scheme and how much support you'd get on it; who covers payroll when you're off | — |
| Contradictions | None between the JD and the offer | `[grounded]` JD and offer compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years running payroll at a hotel group. You've stated it but there's nothing to inspect | `[grounded]` your background | none |
| R2 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Fortnightly for 90 staff is the same work at a smaller headcount. Monthly means fewer runs, but each one is bigger | `[inferred]` from your 90-staff fortnightly payroll against the JD's 240 monthly | none: you already have the offer |
| R3 | Process starters and leavers | must_have | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R4 | Process pension changes | must_have | absent | medium | capability | You've said you've never done them; your manager handled them | `[grounded]` your background | RR4's question; G1 |
| R5 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | You already do the monthly payroll-to-ledger reconciliation | `[grounded]` your background | none |
| R6 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say whether the hotel group's payroll was Irish | `[grounded]` your background is silent | G2 |
| R7 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your background | none |
| R8 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Probably part of a hotel payroll job, but not stated | `[inferred]` from the role's usual duties, unconfirmed | none needed for accepting |
| R10 | Right to work in Ireland | hard_gate | unclear | low | hard_gate | The offer includes a right-to-work check, and you haven't said where you stand. I don't need your documents, only a yes or no | `[grounded]` offer email | Q3 |
| R11 | Hybrid, two days a week in Limerick | hard_gate | unclear | low | hard_gate | You can get to the office (you interviewed there twice), but you haven't said whether two days a week suits you | `[grounded]` offer email | Q3 |
| R12 | €40,000 a year | hard_gate | unclear | low | hard_gate | You haven't given me a salary floor | `[grounded]` offer email | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R4, must_have) | capability | No hands-on pension changes | It's a named duty from day one | Entering pension deductions your manager set up; seeing enrolment or opt-out changes go through; any pension module in your certificate | Your course syllabus | `[inferred]` from the ordinary overlap between running payroll and processing pension deductions |
| G2 | Irish PAYE, PRSI and USC (R6, must_have) | discovery | Unclear whether your hotel payroll was Irish | It's core to every pay run | Revenue payroll submissions, handling revenue payroll notifications, USC bands | Your certificate, if it covered Irish payroll | `[inferred]` from your background's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (my searches were refused) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The organization may be too new or small to have much online presence, the posting may be stale, or it may not be a real hiring employer. Two interviews at its office reduce this | `[generic]` standing check, not a claim about this employer | Is the onboarding portal at an address listed on marrowgatehousing.ie? | reduced |
| RR2 | Credible written offer after two in-person interviews, from the employer's own domain | positive_signal | — | "we are delighted to offer you the permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | The process looks like an ordinary hiring process | `[grounded]` offer email and your account of the interviews | What date do you need for the start? | noted |
| RR3 | Offered salary within the advertised band | positive_signal | — | "Salary €38,000–€42,000" / "€40,000 a year" | The terms are consistent from ad to offer | `[grounded]` JD and offer | Is there an increment scale above €40,000? | noted |
| RR4 | Pension-change support not stated | unknown | — | "process starters, leavers and pension changes" | You'd handle pension changes without having done them before | `[inferred]` from the JD's duty against your background | What training or handover would I get on pension changes, and who would I go to with questions? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter your bank details, PPS number and passport scan only in the portal, and only after confirming the portal sits at an address Marrowgate's own website gives | The one check worth doing on onboarding, see RR1 | `[generic]` standard onboarding advice | pending your approval |
| A2 | Expect your bank details (to pay your salary), PPS number (so Revenue taxes you correctly) and passport (right-to-work check) from any Irish employer after an offer | Why this request is routine | `[generic]` how Irish onboarding works | pending your approval |
| A3 | When you accept, ask RR4's question | Raises the pension gap openly before you start | `[grounded]` R4, RR4 | pending your approval |
| A4 | Do a short pension-payroll refresher before your start date | Narrows G1 | `[inferred]` from R4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association". The search was refused. It would have checked that the organization and the posting exist as described (RR1) |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026 Limerick". The search was refused. It would have filled in the market calibration |
| 3. Hiring manager's public footprint | unavailable | Not sent because search was refused. It would have shown Declan Garvagh's professional background, for the scope read |

I can also save all of this as a dossier file (`tuesday-dossier.md`) if you want to keep it.

**Upgrade menu**
- Allow web search → targets 1–3 run: RR1 can clear, and the salary gets a market check.
- Answers to G1 and G2 → R4 and R6 firm up.
- Your constraints → R10–R12 resolve, and so does the hard-gates line.
- A deeper research pass on Marrowgate (up to 5 more searches and 2 more fetches) → if you want it, say so.

**Questions**
1. (G2, R6) Was your hotel-group payroll run under Irish PAYE, PRSI and USC?
2. (G1, R4) Did you have any contact with pension deductions at all, even entering changes your manager set up?
3. (R10–R12) Do €40,000, two days a week in Limerick and your right to work in Ireland all suit you? A yes or no is enough, and don't send me any ID or numbers.

You can answer in text, paste a voice transcript, or say skip to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.