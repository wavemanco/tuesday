I've read the assessment framework; now I'm doing a few quick web checks on Fernquay before writing it up.
I'd say yes on both counts: it's worth pursuing, and everything I could check matches.

## Decision snapshot

**Yes, worth pursuing (you've already applied and they want to talk), and the company and posting match what Fernquay publishes about itself (RR1) · `go`**

**Fit ledger.**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R8 (Run research calls with school owners) · unclear: R7 (First and only designer)

R7 (`low`): the real unknown, since you've never been the only designer; R8 (`medium`): your usability sessions carry over to talking with school owners, with a limit.

**Opportunity ledger.** The company and the live posting are on Fernquay's own site and match what you were sent (RR1). The salary is stated and sits inside the market range (RR2). Being the first designer under a co-founder carries a scope risk (RR3), and the equity terms aren't stated (RR4).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** a pay floor of yours above €60,000, office days you can't do, or interview answers on RR3 showing design decisions sit with the co-founder rather than with you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway making booking software for sea-kayak, surf and sailing schools. Founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` "About Fernquay" (fernquay.example/about), from a search snippet |
| Mandate | First designer: "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | `[grounded]` JD |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` JD and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD, matched on the careers page |
| Scope read | One flow, two engineers, close work with a co-founder: focused rather than sprawling for a first design hire | `[inferred]` from the JD's named mandate and team size |
| Market calibration | Product designers in Ireland with 3–5 years: median base €57,000, middle half €51,500–€62,000. The posting's range sits inside that, so it's a fair band, not this employer's offer to you | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520); `[grounded]` JD for the posted range |
| Unknowns | Equity type and vesting; who has the final say on design; how research access to schools is arranged | — |
| Contradictions | None between the posting you have and the careers page. The about page calls Saoirse Doyle a co-founder; the "CTO" title comes only from the WhatsApp message, which is consistent with that, not a conflict | `[grounded]` search snippets |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days look workable. You didn't say outright that two days suits you, so I've set it at `medium` | `[grounded]` your background | Confirm it suits you (see the upgrade menu) |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, self-reported and not yet inspected | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily"; the case study they liked would show it | `[grounded]` your background | none |
| R4 | Has run their own user research | must_have | direct | medium | none | "ran monthly usability sessions with customers": your own word "ran", a recurring practice | `[grounded]` your background | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | direct | medium | none | You redesigned the checkout flow at a travel-booking company, which is the same kind of flow. Ronan says they "loved the checkout case study" | `[grounded]` your background and the WhatsApp message | none |
| R7 | First designer: the only design voice on the team | important | unclear | low | discovery | You've never been the only designer. What's not known yet is how much of the checkout work was your call versus a lead's or a design team's | `[grounded]` your own statement; `[generic]` that first-designer interviews test whether you can work without design peers | G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over: recruiting people, running sessions, turning findings into design changes. The limit is that school owners are business customers, and talking with them about how they run bookings is a different kind of conversation from testing a checkout with travellers | `[grounded]` your background; `[inferred]` the limit, from customers versus operators | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R7, important) | discovery | You redesigned checkout inside a squad. Nothing yet shows which decisions were yours, or whether a design lead or design system shaped them | This is the one row that could change how you position yourself | Decisions you made without a design review; times you set scope or priorities with a product manager; stretches where you were the only designer on the squad; setting up the monthly sessions yourself | The checkout case study, a decision log, a research plan you wrote | `[grounded]` your statement; `[generic]` that this is what founders probe in a first designer |
| G2 | Research calls with school owners (R8, important) | transferability | The usability sessions carry over; business-customer interviews aren't evidenced yet | It frames how you talk about research with Ronan | Any interviews with partners, suppliers or internal operations staff at the travel company; recruiting and scripting the sessions yourself | A discussion guide or a findings summary | `[inferred]` from customers versus operators |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The company and the live posting can be traced to Fernquay's own site | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle"; careers: "Open now: Product Designer, our first design hire" | The posting is current and the people messaging you are the people Fernquay's site names | `[grounded]` fernquay.example/about and /careers/product-designer, from search snippets | Who else would I meet after this call, and what are the remaining steps? | noted |
| RR2 | Salary stated and in line with the market | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The range is fair for 3–5 years in Ireland | `[generic]` Tillerby 2026 report; `[grounded]` JD | Where in the range would someone with four years land? | noted |
| RR3 | First designer working "most closely" with a co-founder | risk_signal | low | "You would be our first designer … work most closely with our co-founder" | You might own the flow on paper while a founder has the final say on design | `[generic]` pattern for first design hires at founder-led startups | When you and Ronan disagree on a design decision, how does it get settled? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The type (options or shares), the vesting and what it's worth all depend on terms not yet given; the company is customer-funded rather than investor-funded | `[grounded]` JD and about page; `[generic]` that equity value depends on those terms | Is the equity options or shares, what's the vesting schedule, and what decides 0.5% versus 1%? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the call. Scheduling by WhatsApp for a video interview held elsewhere is routine. As a basic check, make sure the emailed invite comes from a fernquay.example address | Your "felt odd" question | `[generic]` hiring practice at small companies; `[grounded]` the careers page's jobs@fernquay.example | pending your approval |
| P1 | Lead with the checkout redesign, in your own words: "I redesigned our checkout flow." Ronan's public profile shows five years as product lead at a Galway travel-software company, so a travel-booking case study is familiar ground for him | see R6 | `[grounded]` the LinkedIn search snippet | pending your approval |
| P2 | Have a plain answer ready for never having been the only designer: what you did on your own and what you'd want support with. Don't stretch it | see R7, G1 | `[grounded]` your statement | pending your approval |
| Q1 | Ask the questions in RR3 and RR4 on the call, word for word | They're the open risks | `[grounded]` the register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway" (found "About Fernquay", fernquay.example/about) and "Fernquay careers product designer" (found "Product Designer — Fernquay careers", fernquay.example/careers/product-designer). Fetched fernquay.example/careers: no page there. Moved the organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup 2026" (found "Tillerby 2026 Ireland Design Salary Report", tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" (found "Ronan Kehoe — Co-founder, Fernquay", linkedin.example/in/ronan-kehoe). Moved P1 |

I can save all of this as a `tuesday-dossier.md` file whenever you'd like it.

**Upgrade menu**
- **A link to your checkout case study:** would raise R2–R6 to `high`, and partly answer G1.
- **Your pay floor and whether two office days suit you:** settles the hard-gates line and R1.
- **An answer to G1:** settles R7 and sharpens P2.
- **The equity terms once Fernquay shares them:** closes RR4.
- **A deeper research pass on Fernquay** (customer reviews of its booking product, recent news, hiring history; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: On the checkout redesign, which decisions were yours alone, and was there a design lead or other designer whose sign-off you needed?

G2: Have you ever interviewed people on the business side, such as partners, suppliers or ops staff, rather than end customers?

Constraints: what's your salary floor, and does two days a week in the Galway office work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.