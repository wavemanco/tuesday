I've read the evaluation framework. Next I'll run a few quick web checks on Fernquay and on salaries for this role, then write up the assessment.
**Yes, it's worth taking the call. Nothing in what you've shared asks anything of you that a hiring process shouldn't. I couldn't confirm Fernquay exists, though, because my web searches were blocked. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R7 (Being the first and only designer) · unclear: R8 (Research calls with school owners)

R7 — a real stretch, and its limit needs naming; R8 — depends on how your research was run.

**Opportunity ledger.** Unverified, but transparent so far. I couldn't establish the employer from here (RR1). The posting states pay, equity and working pattern (RR2) and a clear mandate (RR3). Equity terms (RR4) and runway (RR5) are unknown. Being the first designer brings ordinary early-startup exposure (RR6).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real company before or on the call — RR1, A1; (2) the first-designer stretch is framed honestly as a step up, never as experience you already have — R7, P2; (3) equity terms and runway are clear before you accept anything — RR4, RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers; works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` posting |
| Stage | Invited to a 45-minute video call with Ronan and Saoirse (CTO); invite sent by email, scheduling offered on WhatsApp | `[grounded]` WhatsApp message |
| Scope read | One product surface (booking), a small and named team, and clear research duties make this a focused first-designer role, not several jobs folded into one | `[inferred]` from the posting's single named flow and named collaborators |
| Market calibration | Not established. The role-family search was blocked, and I don't use memory for salary figures | — |
| Unknowns | Funding and runway; equity type and vesting; who gives design feedback; what "end to end" includes (research through to launch metrics?) | — |
| Contradictions | None in the material you pasted. Not checked against a careers page, because the searches were blocked | `[grounded]` posting and message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days look workable. It's your own statement of where you live, not stated as a constraint | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer is above the bar. Self-reported, nothing inspected | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily." The checkout case study they mention is the artifact that would raise this | `[grounded]` your background; their message | none |
| R4 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. What "ran" covered (recruiting, scripting, synthesis) isn't yet stated, so expect a probe | `[grounded]` your background | covered by G2 |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. Fernquay has two | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | important | direct | medium | none | Checkout redesign at a travel-booking company is the same problem, and they've seen the case study. What was yours versus the squad's isn't stated, so don't claim "end to end" until you've checked it against what you did | `[grounded]` your background; their message | P1 |
| R7 | Being the first and only designer ("You would be our first designer") | important | adjacent | medium | transferability | You've never been the only designer anywhere. Squad work with engineers carries over, but you've never been without design peers to give feedback and keep standards. `[generic]` Interviewers for first-designer roles commonly probe how you work without design peers | `[grounded]` your own statement; `[generic]` the probe | see G1 |
| R8 | Research calls with school owners | important | unclear | low | discovery | Your usability sessions were with customers, which is evaluative testing. Interviewing business owners about their operations is a different kind of research, and nothing yet says whether you've done it | `[grounded]` your background; `[inferred]` the distinction, from "school owners" against "customers" | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R7, important) | transferability | **Carries over:** you shipped with engineers, and you redesigned checkout. **Limit:** you've never worked without design peers. **Would help:** a concrete example of setting your own direction | It's the stretch in this role, and an honest answer to it helps you more than a polished one | Being the only designer on your squad even with other designers in the company; setting up the monthly usability sessions yourself; making design calls with no lead in the room | A research plan you wrote; a decision log; the checkout case study's process section | `[grounded]` your statement; `[generic]` that this is where first-designer interviews press |
| G2 | Research with school owners (R8, important) | discovery | Monthly usability sessions with customers; no sign yet of interviews with business partners or suppliers | It decides whether R8 is `direct` or a learning curve, and it's likely the call's research question | Talking to hotels, tour operators or other suppliers on the booking platform; interviews before the checkout redesign rather than testing after it; recruiting and scripting the sessions yourself | A discussion guide, a synthesis board, a research readout | `[grounded]` your background; `[inferred]` that it is likely to come up, from the posting's "run research calls with school owners" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at Fernquay's website, and is the role listed there? | unresolved |
| RR2 | Pay, equity range and working pattern all stated | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week" | Terms are transparent before the first call | `[grounded]` posting | What decides where in the range an offer lands? | noted |
| RR3 | Clear mandate and named collaborators | positive_signal | — | "own the booking flow end to end … You will work most closely with our co-founder, Ronan Kehoe" | Scope and reporting line are defined | `[grounded]` posting | What would a great first six months on the booking flow look like? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage means little without the instrument, vesting and the company's valuation | `[generic]` how startup equity works | Is it options or shares, what's the vesting schedule, and what's the current valuation or strike price? | unresolved |
| RR5 | Funding and runway unstated | unknown | — | "We are six people" | A six-person company's stability depends on funding or revenue that the posting doesn't mention | `[generic]` early-stage pattern | Is Fernquay funded or revenue-backed, and how many months of runway do you have? | unresolved |
| RR6 | First designer, no design peers | risk_signal | low | "You would be our first designer" | No one in-house to review or mentor design work; how much this matters depends on R7 | `[generic]` first-designer pattern | Who gives design feedback, and how are design decisions made between you, Ronan and the engineers? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the email invite came from an address on Fernquay's own domain, and that the domain has a working website for the company. Also check that the video link is on a mainstream platform. If any of these doesn't hold, ask Ronan for the company's website before joining | RR1. Arranging an interview over WhatsApp, when the interview itself happens on a video call with an emailed invite, is a routine step. This check is just sensible care | `[generic]` how small companies often schedule | pending your approval |
| P1 | Lead with the checkout redesign and the monthly usability sessions, in your own words: "I redesigned our checkout flow" and "ran monthly usability sessions with customers." Don't say "owned the booking flow end to end" or "led a research programme" until you've checked that against what you did | R6, R4 | `[grounded]` your background | pending your approval |
| P2 | On being the first designer, say it straight: you've worked in a squad with four engineers but have never been the only designer, then give your G1 example | R7 | `[grounded]` your own statement | pending your approval |
| Q1 | Ask the verification questions from RR1 and RR4–RR6 on the call | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A2 | If an offer comes, get the equity terms in writing before you accept | RR4 | `[generic]` startup offer practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software Galway"; the call was refused (web search permission not granted). It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 startup"; refused. It would have given the market calibration row a band to set the €52–60k against |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have shaped the scope read and which story P1 leads with |

I can save all of this as a `tuesday-dossier.md` file to carry between sessions if you'd like.

**Upgrade menu**
- Allow web search → targets 1–3 run, which could clear RR1 and fill in the market calibration. A deeper pass (funding, team history, news; up to 5 more searches and 2 more fetches) is available on request after that.
- The sender address on the calendar invite, or Fernquay's website link → RR1 can resolve without any search.
- Your pay floor and any non-negotiables → the hard-gates line can actually check them, and the salary range gets set against your floor.
- The checkout case study, or a research readout → R3, R4 and R6 can move from `medium` towards `high`.

**Questions**

G2 — Besides the customer usability sessions, have you ever interviewed business partners or suppliers, or done interviews before designing rather than testing after? What did you personally run?

G1 — When did you last make a significant design call with no design lead or peer to check it with, and how did you decide?

Constraints — Do you have a salary floor, or anything else this job has to meet (office days, start date)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.