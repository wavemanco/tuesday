Quick update: I've checked whether the company can be found and what this kind of role usually pays in Ireland. One more search for a careers page, then the full assessment.
# Should you go ahead with this Velloway Logistics job?

## Decision snapshot

**No, don't go ahead and don't send anything. This job is very likely a scam. I couldn't find the company anywhere, and the messages ask you to pay a fee, lodge a cheque and hand over your bank, tax and passport details before any offer. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year minimum), R6 (A quiet place to work)
- `must_have`: direct: R3 · adjacent: R2 (Strong attention to detail), R4 (Good written English)
- `important`: adjacent: R5 (Processing orders)

R1: "up to" and 15–30 hours don't settle your floor; R2, R4, R5: credible bridges from your courier work.

**Opportunity ledger.** RR1, RR2, RR3 and RR4 are confirmed requests of a kind that can cost you money or your identity. RR5: the company couldn't be found. RR6: the pay is high for a no-experience role. RR7: the offer contact is a non-company email address.

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum), R6 (A quiet place to work)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would have to be different:** the company can be found and reached through its own website; there's a real interview, not just chat; no fee or cheque at any stage; your bank and ID details are asked for only after a written offer, through the company's own portal.

I've left out the IBAN you pasted. It isn't needed here, and I haven't repeated or used it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", as the posting names it; no results came up when I searched for it | `[grounded]` posting; `[grounded]` two searches with no results |
| Stated role | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Order processing and customer operations coordinators in Ireland earn a median of €31,200 a year (middle half: €28,400–€34,100), for salaried roles only. That's a pattern for the role, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (search result) |
| Pay against your floor | €26 × 15 h × 52 = €20,280; €26 × 30 h × 52 = €40,560. "Up to" means even the hourly rate isn't promised | `[inferred]` arithmetic on the posting's figures |
| Unknowns | Whether the company exists; the real hours; what the commission is based on; the contract type | — |
| Contradictions | "No experience needed", but pay at the top of what the role gets elsewhere (RR6) | `[inferred]` posting against the `[generic]` band |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year minimum (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because "up to €26" at 15–30 hours covers €20,280 to €40,560 | `[grounded]` your message; `[inferred]` arithmetic | none: this role is `no_go` on the risk register alone |
| R2 | "Strong attention to detail" | must_have | adjacent | medium | transferability | About 60 tickets a day is volume, but you haven't said anything about accuracy. Limit: no stated error rate or quality score. Self-stated, not yet checked | `[grounded]` your background | For other roles, a QA score or accuracy figure would strengthen it |
| R3 | "Confident with spreadsheets" | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Specific, but self-stated with nothing to look at yet | `[grounded]` your background | A sample of the tracker with sensitive data removed would raise it |
| R4 | "Good written English" | must_have | adjacent | medium | transferability | Zendesk tickets are mostly written replies, but you didn't say yours were written. Limit: no writing sample | `[grounded]` your background; `[inferred]` that ticket work is written | none for this role |
| R5 | Processing orders (the job's core task) | important | adjacent | medium | transferability | Parcel-courier customer service handles order and delivery problems, not order entry itself. Limit: the processing step itself isn't shown | `[grounded]` your background; `[inferred]` overlap | Useful when you apply to other order-processing roles |
| R6 | "A quiet place to work" from home | hard_gate | unclear | none | hard_gate | You haven't said anything about your home setup | `[grounded]` posting; silent in your background | Only matters for other remote roles |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Processing orders (R5, important) | transferability | Courier customer service with ticket volume; order entry itself isn't shown | It doesn't matter for this role, but it's the bridge into genuine order-processing jobs | Fixing addresses or rebooking deliveries in a system; raising claims; checking orders against manifests | A screenshot of your tracker or a QA review, with sensitive details removed | `[grounded]` your background; `[generic]` that order-processing roles screen on system-entry accuracy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring run entirely by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No interview or offer can be checked against a real employer; who sent the messages hasn't been confirmed | `[generic]` how chat-only hiring leaves identity unchecked | Ask the employer, using contact details from its own website (not the chat or the email address in these messages): "Is the Remote Order Processing Coordinator role yours, and is @VellowayHiring your recruiter?" | confirmed |
| RR2 | Bank, tax and ID details asked for before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Once sent, a PPS number and passport photo can't be taken back and can be used in your name; who sent the request hasn't been confirmed | `[generic]` how identity details are misused | See RR1: same question, same route | confirmed |
| RR3 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Money sent by bank transfer is hard to get back. Employers don't usually charge new staff for equipment | `[generic]` how equipment fees work in hiring | See RR1: same question, same route | confirmed |
| RR4 | Lodging a cheque and passing the money on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show as available and then bounce days later. You'd then owe your bank the €2,500 you sent on. This request is very likely a scam. Don't lodge the cheque | `[generic]` how cheque overpayment schemes work | See RR1: same question, same route | confirmed |
| RR5 | Employer not found | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The company may be too new or small to show up online, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company | "Can you point me to this role on your own careers site?" | unresolved |
| RR6 | High pay for a no-experience role | risk_signal | low | "Earn up to €26 an hour plus commission… No experience needed" | At 30 hours this is above the salaried band in role reality, but "up to" promises nothing. I've rated it low because the figure alone proves nothing | `[inferred]` posting figure against the `[generic]` band | "What's the guaranteed hourly rate, and how is commission worked out?" | unresolved |
| RR7 | Offer contact on a non-company email address | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The offer may not come from the company it names. Check whether the address matches a domain on the company's own website | `[generic]` how offers are usually sent | "Which email domain do your HR team use?" | unresolved |

Don't make the payment, don't lodge the cheque, don't send your details, and go no further in the chat until you've checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from. Who sent them hasn't been confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or €349 | see RR2, RR3 | `[grounded]` the messages | pending your approval |
| A2 | If a cheque arrives, don't lodge it. Keep it and ask your bank for advice | see RR4 | `[generic]` how banks handle these | pending your approval |
| A3 | Tell the jobs site where you found the posting so they can review it | see RR1, RR5 | `[generic]` that jobs sites review postings they're told about | pending your approval |
| A4 | If you've already shared anything with anyone, contact your bank, and the Gardaí if needed | see RR2 | `[generic]` standard steps after sharing details | pending your approval |
| A5 | Spend your time on other order-processing and customer-operations openings. Your background fits roles where the median is €31,200, above your floor | see R3, R5; role reality, market calibration | `[generic]` Pennoral 2026 band | pending your approval |
| E1 | A CV line in your own words: "Customer service agent, parcel courier (3 years): handled about 60 tickets a day in Zendesk; trained two new starters; kept the team's weekly tracker in Excel" | see R2, R3, R5 | `[grounded]` your background, nothing added | pending your approval |

All the actions and the CV wording above are suggestions only. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator"; both returned nothing. The company isn't established, which is RR5 |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This gave the market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle |

---

I can save all of this as a dossier file if that's useful.

**Upgrade menu**
- A link to the original posting on the jobs site, or the company's own careers page, would let me check RR5 and see whether it changes RR7.
- Your CV would let me check R2, R4 and R5 and turn E1 into a full CV edit for other roles.
- A deeper research pass on the company name (up to 5 more searches and 2 more fetches) would look for company registration and public reports. Say the word and I'll run it.

**Questions**

RR5: Can you send me the link to the original posting on the jobs site?

G1: In your courier job, did you ever enter, amend or check orders or bookings in a system, not just answer tickets? If so, what did that involve?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.