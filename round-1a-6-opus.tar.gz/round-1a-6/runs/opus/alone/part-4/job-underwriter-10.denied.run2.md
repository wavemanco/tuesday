Reading the skill's rules, then checking Fernquay online before I write up the assessment.
## Decision snapshot

**Yes, worth applying, and worth taking the call. A co-founder using WhatsApp to set up a video call that happens somewhere else is routine, and the message asks you for nothing else. My web searches were blocked, so I couldn't confirm Fernquay from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R9 (Salary €52,000–€60,000 against your floor)
- `must_have` — direct: R2, R3, R4, R6, R7
- `important` — adjacent: R5 (Research calls with school owners), R8 (Being the first and only designer)

R8 — the real stretch, a bridge to describe honestly; R5 — consumer usability sessions carried over to business-owner interviews, a short step; R9 — a gate only you can settle.

**Opportunity ledger.** The posting is open and the role is realistically scoped (RR2, RR3). The equity terms (RR4) are unknown, and so is who gives you design feedback (RR5). The employer is not established from here (RR1), and that is what caps the decision.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R9 (Salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay is established: its own site or careers page shows the role, and the calendar invite comes from its domain (RR1). (2) The salary range meets your floor (R9). (3) R8 is described as adjacent experience, never as having been a solo designer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, making booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer. Own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| First-90-days outcomes | Not stated. Most likely a research round with school owners and a first pass at the booking flow | `[inferred]` from the two named responsibilities; the posting states no outcomes |
| Working pattern | Hybrid: two days a week in the Galway office, the rest wherever suits | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | One product area, two engineers and a named counterpart is a bounded remit for a first designer. It is not a whole design function | `[inferred]` from the posting's team size and single named flow |
| Market calibration | Not run: the role-family search was blocked, and I won't quote a salary band from memory. The upgrade menu covers it | — |
| Stage | You've applied and been invited to a 45-minute video call with Ronan and Saoirse (CTO) | `[grounded]` WhatsApp message |
| Unknowns | Equity terms; whether anyone reviews design work; success measures; whether the company exists as described | — |
| Contradictions | None between the posting and the message | `[grounded]` both inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | high | none | You moved back to Galway last year. Commuting there is your own stated fact | `[grounded]` your message | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer, stated. Nothing inspected yet | `[grounded]` your message | Portfolio raises it |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use, stated. Your files would show it | `[grounded]` your message | none |
| R4 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is a recurring research practice you ran yourself | `[grounded]` your message | none |
| R5 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with end customers. These calls are with small-business owners: what they need operationally and why they'd buy. Same method, different subject. Limit: no B2B or owner interviews stated | `[inferred]` from consumer usability sessions set against a B2B research brief | G2 |
| R6 | Own the booking flow end to end | must_have | direct | medium | none | You redesigned the checkout at a travel-booking company, the same kind of flow. "End to end" may also cover availability and scheduling, which is still to be confirmed | `[grounded]` your message | Lead with it in the call |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R8 | Being the first and only designer | important | adjacent | medium | transferability | You've owned a flow and run your own research, which is what a solo designer does day to day. Limit: you've always had design colleagues for critique, standards and backup. Don't claim otherwise | `[grounded]` your message ("never been the only designer") | G1 |
| R9 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | The posting states the range. You haven't stated your floor, so I can't check it | `[grounded]` posting; floor not given | Question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R8, important) | transferability | Strong ownership within a design team; no solo stint | The likeliest probe in a call with a founder and a CTO | Decisions you made without design review; setting up the usability programme yourself; freelance or side projects where you were the only designer; times you were the only designer in your squad | One example, told with the decision you made and what came of it | `[inferred]` from "never been the only designer" set against "first designer" |
| G2 | Research with school owners (R5, important) | transferability | Consumer usability sessions | Owner interviews are about operations and buying, not only usability | Any interviews with hotel or tour-operator partners, suppliers or internal ops staff at the travel company | A research plan or a sanitized discussion guide | `[inferred]` from the B2B shape of the role |
| G3 | Salary floor (R9, hard_gate) | hard_gate | Range stated, floor unknown | Only you can settle it | — | Your number | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have much online presence, the posting may be stale or aggregated, or it may not be a real hiring employer. My searches were blocked and you found little yourself, so it stays open | `[generic]` pattern for companies this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Bounded scope with named collaborators | positive_signal | — | "own the booking flow end to end… ship alongside our two engineers" | One flow, two engineers and a named counterpart is a realistic first-designer remit | `[inferred]` from the posting's team size and scope | What would a great first six months look like for this role? | noted |
| RR3 | Terms stated openly | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week" | Pay, equity range and office days are all published, so less is left to negotiate blind | `[grounded]` posting | — | noted |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | A percentage tells you little without the vesting schedule, cliff, option or share type, and the latest valuation | `[generic]` how early-stage equity is usually structured | What decides 0.5% versus 1%, and what are the vesting, cliff and exercise terms? | unresolved |
| RR5 | No design peer | risk_signal | low | "You would be our first designer" | Design work may be reviewed only by founders and engineers. That's fine for some designers and draining for others | `[generic]` pattern for first-designer roles | Who reviews design work today, and is there budget for outside critique or a design community? | unresolved |

The WhatsApp message asks only to schedule a call held over video, and it says the invite came by email. That is routine and gets no register entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from an address on Fernquay's own domain, and that the domain has a website showing the product. It's routine hygiene and settles RR1 quickly | RR1 | `[generic]` standard verification step | pending your approval |
| P1 | Lead with the checkout redesign: the problem, your research, the decisions, the outcome | R6, R4; the message names that case study | `[grounded]` your message and theirs | pending your approval |
| P2 | Bring one messy real project, with process, dead ends and trade-offs, rather than a polished deck | The posting asks for exactly that | `[grounded]` posting | pending your approval |
| P3 | Answer R8 truthfully: "I've always had design peers. Here's where I made calls on my own." Use an example only once G1 confirms it | R8 | `[grounded]` your message | pending your approval |
| P4 | Present owner interviews as an extension of your usability practice, and name the difference | R5 | `[inferred]` from R5 row | pending your approval |
| Q1 | Ask the RR1, RR2, RR4 and RR5 questions verbatim in the call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay Galway booking software kayak surf schools"; the call was refused (search permission not granted). It would have confirmed the company and the live posting, and could have cleared RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 startup first designer"; refused. It would have set €52–60k against an Irish market band for the market calibration row |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have shaped which story P1 leads with for him |

## Closing

I can put all of this into a `tuesday-dossier.md` file you can keep and update, whenever you'd like.

**Upgrade menu**
- Allow web search → targets 1–3 re-run. RR1 may clear, which would lift the cap, and the pay range gets set against the market.
- A deeper research pass on Fernquay (company registration, funding, founders' track record, recent news; up to 5 more searches and 2 more fetches) → feeds the register. Say the word and it runs.
- Your portfolio or the checkout case study → R2, R3, R4 and R6 move to `high`.
- The sender domain of the calendar invite → RR1 can resolve on the spot.
- For rehearsing the 45-minute call itself, the mock-interview skill does that.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):
1. G3 — What's the lowest salary you'd accept, and does equity change that for you?
2. G1 — Can you think of a time you made a design call with no design colleague to check it against, such as a decision in your squad, setting up the usability sessions, or freelance work?
3. Would you like me to re-run the three searches if you allow web search?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.