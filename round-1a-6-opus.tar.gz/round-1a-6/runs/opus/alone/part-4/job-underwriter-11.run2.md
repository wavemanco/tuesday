Reading through the skill's rules is done. Next I'm checking whether both employers exist and what these roles usually pay, then I'll write up both assessments.
The web searches were refused, so I checked neither employer nor market pay. Both assessments below go only on the two postings and what you told me.

# Posting A: Operations Analyst at Duinvaart Cold Chain, Rotterdam

## Decision snapshot

**Yes, this one is worth your time, if two conditions hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: A-R1 (three days a week in our Rotterdam office)
- `must_have`: direct: A-R2, A-R3, A-R4, A-R5 · adjacent: A-R7 (work with depot managers on route changes)
- `important`: unclear: A-R6 (temperature compliance across our refrigerated fleet)
- `preferred`: direct: A-R8

A-R7: one answer away from `direct`; A-R6: the cold-chain part, not yet explored.

**Opportunity ledger.** The role is clearly scoped and concrete (A-RR3). I couldn't confirm the employer exists (A-RR1), and the pay isn't stated (A-RR2).

- **Hard gates:** none failed; unconfirmed: A-R1 (three days a week in our Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting checks out on Duinvaart's own careers page (A-RR1); (2) three office days in Rotterdam work for you (A-R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator in Rotterdam | `[grounded]` JD header; not checked, see A-RR1 |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | A standard mid-level analyst role: three duties and a 2-year bar, with no team-lead or ownership language | `[inferred]` from the JD's duty list and experience bar |
| Unknowns | Pay; who the role reports to; data stack beyond Power BI | — |
| Contradictions | None inside the JD; not checked against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A-R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't said where you live or what you can commute to | `[grounded]` JD; your background is silent | Closing question on A-R1 |
| A-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an ops analyst at a parcel carrier is double the bar. You told me this but nothing is checked yet, so `medium` | `[grounded]` your background | none |
| A-R3 | Strong SQL | must_have | direct | medium | none | "SQL and Power BI daily" | `[grounded]` your background | none |
| A-R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background | none |
| A-R5 | Track on-time delivery; weekly dashboards | must_have | direct | medium | none | You work on an on-time delivery dashboard depot managers use, which is close to the same job. Which part of it was yours isn't stated yet | `[grounded]` your background | Say in the CV which part was yours (A-P1) |
| A-R6 | Temperature compliance across a refrigerated fleet | important | unclear | none | discovery | Nothing yet about cold chain or temperature data. Parcel work may still have included some | `[grounded]` your background is silent | Gap queue A-G2 |
| A-R7 | Work with depot managers on route changes | must_have | adjacent | medium | transferability | You ran the weekly route-performance review, and that review is what route changes are decided from. It's not yet clear whether you agreed changes with depot managers yourself | `[grounded]` your background; `[inferred]` that the review feeds route decisions | Gap queue A-G1 |
| A-R8 | Dutch a plus | preferred | direct | medium | none | The posting sets no level, and conversational Dutch is a real plus here | `[grounded]` JD and your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| A-G1 | Route changes with depot managers (A-R7, must_have) | transferability | You ran the route-performance review; outcomes not stated | This is the one `must_have` row below `direct` | A route or slot you got moved; a depot you persuaded with data; a change you tracked before and after | A review deck, a before/after chart, an email summarizing an agreed change | `[grounded]` your background; `[inferred]` that this turns adjacent into direct |
| A-G2 | Temperature compliance (A-R6, important) | discovery | No cold-chain mention | It's the one part of the job that's new to you | Pharma or food parcels with temperature handling; any sensor or exception data you reported on; any compliance or SLA breach metric | A dashboard page or metric definition | `[grounded]` your background is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| A-RR1 | Employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to show up online, the posting may be old or copied from elsewhere, or it may not be a real hiring employer. The searches were refused, so none of this was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| A-RR2 | Pay not stated | unknown | — | (JD silent on pay) | The figure may sit below what you need, or the company may just not publish salaries | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| A-RR3 | Concrete duties, realistic requirements | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards in Power BI" | The scope is defined and the requirements are proportionate | `[grounded]` JD | Which dashboards exist today, and which would I build first? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A-P1 | Lead your CV with your own words: "SQL and Power BI daily, including the on-time delivery dashboard our depot managers use" and "ran our weekly route-performance review." Add "built" or "owned" only if that is true | see A-R5, A-R7 | `[grounded]` your background | pending your approval |
| A-P2 | Check the posting is on Duinvaart's own careers site before you write a cover letter | see A-RR1 | `[grounded]` A-RR1 | pending your approval |
| A-P3 | Ask A-RR2's pay question at the first screen | see A-RR2 | `[grounded]` A-RR2 | pending your approval |

# Posting B: Supply Planner at Kroonhaven Foods, Utrecht

## Decision snapshot

**No, this one isn't worth your time. B-R3, B-R4 and B-R7 (the planning core) are absent. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: B-R1 (On-site in Utrecht)
- `must_have`: adjacent: B-R2 (fluent Dutch), B-R5 (run the weekly S&OP meeting) · unclear: B-R6 (advanced Excel) · absent: B-R3 (3+ years of supply or demand planning in FMCG), B-R4 (own the 13-week supply plan), B-R7 (SAP IBP or a similar planning system)

B-R3, B-R4, B-R7: absent by your own account ("never worked in planning"); B-R2: fluent is asked, conversational is what you have.

**Opportunity ledger.** The mandate is clearly defined (B-RR3). I couldn't confirm the employer (B-RR1), and the pay isn't stated (B-RR2). The decision doesn't depend on any of these.

- **Hard gates:** none failed; unconfirmed: B-R1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would have to differ:** real planning experience behind B-R3, B-R4 and B-R7, or the employer saying it would train someone into the role. Even then, B-R2's fluency bar would remain.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals producer in Utrecht | `[grounded]` JD header; not checked, see B-RR1 |
| Mandate | Own the 13-week supply plan, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | An experienced-hire planner who owns a plan and chairs a meeting, not a junior role with training | `[inferred]` from "own", "run" and the 3-year bar |
| Unknowns | Pay; team size | — |
| Contradictions | None inside the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B-R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't said where you live | `[grounded]` JD; your background is silent | none (the decision doesn't depend on it) |
| B-R2 | Fluent Dutch | must_have | adjacent | medium | transferability | You describe your Dutch as conversational, not fluent. Chairing S&OP likely means running the meeting in Dutch | `[grounded]` your words; `[inferred]` that the meeting runs in Dutch | Gap queue B-G2 |
| B-R3 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning, and your background is parcel delivery, not FMCG | `[grounded]` your words | Gap queue B-G1 |
| B-R4 | Own the 13-week supply plan; balance capacity against the forecast | must_have | absent | none | capability | Planning ownership is the core of the job; there's no planning history behind it | `[grounded]` your words | Gap queue B-G1 |
| B-R5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Running a weekly performance review carries over. The limit: S&OP makes decisions that trade supply against demand across departments, and your review looked back at performance | `[grounded]` your background; `[inferred]` the difference between the two kinds of meeting | none |
| B-R6 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned. Daily SQL and Power BI work is indirect evidence | `[grounded]` your background is silent | none (the decision doesn't depend on it) |
| B-R7 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system mentioned, which fits having no planning history | `[inferred]` from "never worked in planning" | Gap queue B-G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| B-G1 | Planning core (B-R3, B-R4, B-R7, must_have) | capability | No planning experience, by your own account | These three rows are what decide the `no_go` | Closure path if you ever want planning: junior planner or planning-analyst roles, where your SQL and Power BI work is the entry point, plus planning-system training | — | `[grounded]` your words; `[generic]` that planning-analyst roles are the usual way in |
| B-G2 | Fluent Dutch (B-R2, must_have) | transferability | Conversational Dutch | Hard to close quickly | — | A certified Dutch language exam result | `[grounded]` your words |
| B-G3 | Advanced Excel (B-R6, must_have) | discovery | Silent | It doesn't change the decision | — | — | `[grounded]` your background is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| B-RR1 | Employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The company may be too new or small to show up online, the posting may be old or copied from elsewhere, or it may not be a real hiring employer. The searches were refused, so none of this was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| B-RR2 | Pay not stated | unknown | — | (JD silent on pay) | The company may simply not publish salaries | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| B-RR3 | Clear, measurable mandate | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | The scope is defined | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| B-P1 | Don't spend a tailored application here; put the effort into A and similar operations-analyst roles | see B-R3, B-R4, B-R7 | `[grounded]` the map | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both refused. Would have settled A-RR1 and B-RR1 and the contradictions rows |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands 2026" and "supply planner FMCG salary Netherlands 2026"; both refused. Would have added a market pay band to set A-RR2 and B-RR2 against |
| 3. Hiring manager's public footprint | n/a | No name was given for either role |

---

I can save this as `tuesday-dossier.md` for you to keep and reuse.

**What would sharpen this:**
- **Allow web search:** checks both employers (A-RR1, B-RR1) and gives a Dutch market pay band for both roles.
- **Your pay floor:** lets me set A-RR2 against what you need.
- **Your CV:** shows whether it already presents A-R5 and A-R7 well, and lets me draft A-P1's lines.
- **A deeper research pass on Duinvaart** (hiring patterns, news, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions:**

1. **A-R1:** Are three office days a week in Rotterdam workable for you?
2. **A-G1:** Did your route-performance review end in route or depot changes you agreed with depot managers, and can you name one?
3. **A-G2:** At the parcel carrier, did you ever report on temperature-sensitive shipments, sensor data or compliance breaches?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.