I've read the skill's rules. Next I'll do a quick check on whether Velloway Logistics exists, then write up the assessment.
# Velloway Logistics: Remote Order Processing Coordinator

## Decision snapshot

**No, I wouldn't go ahead. I can't find any trace of the firm, and this job is very likely a scam. RR1, RR2, RR3 and RR4 are confirmed severe red flags. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (pay of at least €30,000 a year), R2 (a quiet place to work from home)
- `must_have`: direct: R3, R4, R5
- `important`: adjacent: R6 (processing orders)

R1: the posting's "up to" rate over 15–30 hours doesn't show whether you'd reach your floor. R6: courier customer service is close to order processing, and the posting offers training.

**Opportunity ledger.** These messages ask you to pay for equipment (RR1), lodge a cheque and send most of it on (RR2), and send your IBAN, PPS number and passport before any offer (RR3). The whole process happens only in chat (RR4). I can't confirm the employer exists (RR5). The contact email isn't on a company domain (RR6), and the pay is open-ended (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (pay of at least €30,000 a year), R2 (a quiet place to work from home)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would have to be different:** the employer's own website lists this role. An interview happens by call or video with someone you can identify. A written offer arrives from the employer's own email domain. Nobody asks you for money, a cheque deposit, or your bank, PPS or passport details before that offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", as named in the posting. Two searches found nothing for it (RR5) | `[grounded]` posting; searches below |
| Mandate | Order processing from home, 15–30 hours a week, your own hours | `[grounded]` posting |
| Pay | "up to €26 an hour plus commission on every order you process" | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | In Ireland, order-processing and customer-operations coordinators are typically salaried, with a median of €31,200 and a middle range of €28,400–€34,100. That's a market band, not this employer's offer (RR7) | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, salaried roles only |
| Unknowns | Who the employer is; contract type; guaranteed hours; what commission depends on; what "processing" an order involves | — |
| Contradictions | First you're asked to pay €349 by bank transfer for the kit. Later you're told to send the kit money out of a €2,850 cheque instead, which is two different payment routes for the same thing. And "full training provided" sits next to a hire decided by chat answers alone | `[grounded]` the messages you quoted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The fit is unclear because "up to €26 an hour" over 15–30 hours works out to about €20,300–€40,600 a year even at the top rate, and the commission is undefined | `[grounded]` posting and your message; the arithmetic is mine | For any real role, get the rate, guaranteed hours and commission basis in a written offer |
| R2 | A quiet place to work from home | hard_gate | unclear | none | hard_gate | The posting requires it and you haven't said either way | `[grounded]` posting; your message is silent on it | Check for yourself before taking on any remote role |
| R3 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for 3 years, plus keeping the team's weekly tracker. Specific, but nothing to inspect yet | `[grounded]` your background | none |
| R4 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. What the tracker does isn't stated | `[grounded]` your background | For real applications, say what the tracker covers |
| R5 | Good written English | must_have | direct | medium | none | Your message is clear and well structured. Ticket handling in Zendesk is mostly written replies | `[grounded]` your message; `[generic]` that Zendesk ticket work is mostly written | none |
| R6 | Processing orders, the role's core task | important | adjacent | medium | transferability | Courier customer service sits right next to order handling. Limit: you haven't said you entered or processed orders in a system yourself | `[inferred]` requirement from the title and "commission on every order you process"; `[grounded]` your courier role | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | An "up to" rate, variable hours and undefined commission | Whether a role meets €30,000 can't be read from this posting | — | A written offer stating hourly rate, guaranteed hours and how commission is earned | `[grounded]` posting; your floor |
| G2 | Processing orders (R6, important) | transferability | Three years of parcel-courier customer service. No order-entry work stated | Matters for genuine order-processing roles you apply to next | Fixing addresses or delivery details on bookings; raising claims or reshipments; updating parcel records in the courier's system | The names of the systems you used, or one example ticket flow written up without customer details | `[grounded]` your background; `[inferred]` the bridge |
| G3 | Quiet place to work (R2, hard_gate) | hard_gate | Not stated | Matters for any remote role | — | — | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Money sent by bank transfer usually can't be recalled once it lands. Employers don't ask applicants to pay for their work kit. This request is very likely a scam. Who sent it is unresolved | `[generic]` how transfers and hiring work | Ask the employer, using contact details you find yourself on its own website (never the Telegram chat or the email in these messages): "Is the Remote Order Processing Coordinator role yours, and do you ask new hires to pay for equipment, lodge a cheque, or send bank, PPS and passport details before an offer?" I couldn't find such a website (RR5). | confirmed |
| RR2 | Asked to lodge a cheque and send most of it on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can bounce or be reversed days after the money shows in your account. You'd then owe your bank the €2,500 you transferred out. This request is very likely a scam. Who sent it is unresolved | `[generic]` how cheque clearing works | As RR1 | confirmed |
| RR3 | Asked for bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | This came before even the chat interview. An IBAN, PPS number and passport photo together are enough for someone to open accounts or claim benefits in your name. This request is very likely a scam. Who sent it is unresolved | `[generic]` identity misuse; `[grounded]` the order of the messages | As RR1 | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | With no voice, face or company address involved, you have nothing to tie the process to a named employer | `[grounded]` posting | "Who would I speak to by phone or video before an offer, and from which company email address?" Ask this through contact details on the employer's own site, as in RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to show up, the posting may be stale or copied, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this firm | "Can you point me to this role on your own careers page, and who would I be interviewing with?" | unresolved |
| RR6 | Contact address off a company domain | risk_signal | low | "email velloway.hr@postmail.example" | An address on a general mail service doesn't link the messages to any company's own domain | `[inferred]` from the address you quoted | "What is your company's own email domain?" Ask this through contacts on the employer's own site | unresolved |
| RR7 | Open-ended pay against your floor (see R1) | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | "Up to", unfixed hours and undefined commission could land well below the €28,400–€34,100 salaried band | `[grounded]` posting; `[generic]` Pennoral band | "What is the guaranteed hourly rate and minimum weekly hours, and how is commission calculated?" | unresolved |

Don't make the payment, don't lodge the cheque, don't send your details (IBAN, PPS number, passport photo), and go no further in the chat until you've checked each request with the employer. Use contact details from the employer's own website, not the chat or the email address in these messages. Who sent them isn't confirmed yet. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste your IBAN into the chat, and don't send your PPS number, passport photo or the €349 | See RR1, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it. Keep it and its envelope | See RR2 | `[generic]` cheque reversal risk | pending your approval |
| A3 | Report the posting to the jobs site where you found it | Jobs sites usually review postings that users flag | `[generic]` how jobs sites handle reports | pending your approval |
| A4 | If anything ever does get sent or lodged, call your bank straight away | Fast contact gives the bank the best chance to stop or recall a payment | `[generic]` how banks handle disputed payments | pending your approval |
| A5 | Put your effort into other openings: order-processing or customer-operations coordinator roles | The salaried band's middle range of €28,400–€34,100 is around your floor | `[generic]` Pennoral band | pending your approval |
| E1 | Lead applications with your own lines: "3 years as a customer service agent at a parcel courier, about 60 tickets a day in Zendesk; trained two new starters; keep the team's weekly tracker in Excel" | Covers R3, R4, R5 in your own words, with nothing added | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway careers order processing coordinator". Both returned no results, so the employer isn't established. This produced RR5 and the Organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This set the market calibration and RR7 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a chat handle, so there was nothing to search |

If you want, I can save all of this as `tuesday-dossier.md` for you to carry into a later session.

**Upgrade menu**
- **Link to the original posting on the jobs site:** lets me check whether it's still live and what employer details it shows (RR5).
- **Any website, address or company number the sender gave:** a specific lead for target 1, so RR5 could be confirmed or cleared.
- **What your Excel tracker covers, and which systems you used at the courier:** R4 and G2 get stronger for your next applications.
- **A deeper research pass:** company records and recent news, up to 5 more searches and 2 more fetches. Say the word and it runs.

RR5: Could you paste the link to the original posting on the jobs site, or its exact wording there? You can answer in text, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.