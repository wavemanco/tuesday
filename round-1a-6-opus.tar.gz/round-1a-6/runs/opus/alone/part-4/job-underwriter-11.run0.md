I've read the assessment method. Next I'll run a few quick checks on both employers and on typical pay, then write up the assessment.
Neither web search went through: all four calls were refused permission. So I couldn't confirm either employer or check typical pay, and that's flagged below. I go through each posting in turn.

# Posting 1 — Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Yes, worth your time. It's close to the job you just did. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days a week in our Rotterdam office)
- `must_have` — direct: R2, R3, R4, R5 · adjacent: R6 (temperature compliance across our refrigerated fleet)
- `important` — adjacent: R7 (work with depot managers on route changes)
- `preferred` — direct: R8

R6 — the new domain, its limit named; R7 — whether your reviews led to route changes; R1 — only you can settle it.

**Opportunity ledger.** The responsibilities and tools are concrete (RR3). The employer couldn't be confirmed because research was refused (RR1), and the salary isn't stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) three days a week in Rotterdam works for you (R1); (2) the posting is live on Duinvaart's own site (RR1); (3) R6 is presented as adjacent work, never as cold-chain experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet | `[grounded]` JD |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | A standard analyst role: reporting plus advising depot managers, with no team or budget mentioned | `[inferred]` from the JD's responsibilities and its silence on reports or budget |
| Market calibration | Not established: the role-family sweep couldn't run | — |
| Unknowns | Salary; whether the employer and posting are live; contract type | — |
| Contradictions | None in the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't said whether this commute and schedule work for you; your last job was in Amsterdam | `[grounded]` JD; your message is silent on it | Question 1 below |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, against 2+ asked. Self-reported, nothing to inspect yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | You use it daily, but there's no work sample yet | `[grounded]` your background | Offer a sanitized query or a portfolio piece if asked |
| R4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily, including a dashboard depot managers rely on | `[grounded]` your background | Upgrade menu: a sanitized dashboard screenshot |
| R5 | Track on-time delivery | must_have | direct | medium | none | The on-time delivery dashboard your depot managers use is the same metric | `[grounded]` your background | none |
| R6 | Temperature compliance across a refrigerated fleet | must_have | adjacent | medium | transferability | What carries over: tracking a compliance metric across a fleet, the way you track on-time delivery. Limit: nothing you mentioned involves temperature data or cold-chain rules | `[inferred]` bridge from your on-time work | G1 |
| R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. You haven't said whether the reviews led to route changes, or what your part was | `[grounded]` your background | G2 |
| R8 | Dutch a plus | preferred | direct | medium | none | The posting names no level, and conversational Dutch counts as a plus | `[grounded]` JD and your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, must_have) | transferability | Fleet-wide on-time tracking; no temperature or cold-chain work | It's the one part of the job that's new to you | Pharma, food or other temperature-sensitive parcels; any SLA, damage or claims compliance metric you tracked; sensor or scan-event data you queried | A sanitized dashboard page or a metric definition you wrote | `[inferred]` bridge from your on-time work |
| G2 | Route changes with depot managers (R7, important) | discovery | You ran the review; it's unclear what came out of it | One concrete route change you drove would turn this row `direct` | A route re-sequenced or a stop moved after your analysis; a depot that changed its departure times; a proposal of yours that was turned down | A before/after on-time figure, or review notes | `[grounded]` your background is silent on outcomes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to have much online presence, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company; research was refused, not run | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no pay information in the posting) | The pay may fall below what you need, or they may simply not publish salaries | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete scope and tools | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The job is clearly defined | `[grounded]` JD | How do route recommendations get approved today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Duinvaart's own careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Put two lines at the top of your CV, in your own words: "SQL and Power BI daily, including the on-time delivery dashboard our depot managers use" and "Ran the weekly route-performance review". Write "built" only if you built the dashboard | R4, R5, R7 | `[grounded]` your background | resume_edits_pending_approval |
| Q1 | Ask the questions from RR1, RR2 and RR3 in the interview | They are your checks on the role | `[grounded]` register | pending your approval |

# Posting 2 — Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**Probably not worth your time. This is a planning job, and the core requirements are missing. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: P1 (On-site in Utrecht)
- `must_have` — absent: P2 (fluent Dutch), P3 (3+ years of supply or demand planning in FMCG), P4 (own the 13-week supply plan … balance production capacity against the forecast), P6 (SAP IBP or a similar planning system) · unclear: P5 (advanced Excel)
- `important` — adjacent: P7 (run the weekly S&OP meeting)

P2, P3, P4, P6 — capability gaps with no quick fix; P7 — a real but partial bridge.

**Opportunity ledger.** The role is clearly scoped (RR6). The employer is unconfirmed (RR4) and the salary is unstated (RR5). The posting itself looks reasonable; the problem is the fit.

- **Hard gates:** none failed; unconfirmed: P1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would have to differ:** planning experience you haven't mentioned (P3, P4, P6), or fluent Dutch (P2). Without at least one, a screener is likely to reject on P3 and P2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` JD |
| Mandate | Own the 13-week supply plan, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A planner who owns the plan from day one, not a junior or trainee role | `[inferred]` from "own" plus 3+ years required |
| Market calibration | Not established: the role-family sweep couldn't run | — |
| Unknowns | Salary; whether the employer and posting are live | — |
| Contradictions | None in the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| P1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't said whether a daily Utrecht commute works for you | `[grounded]` JD; your message is silent on it | Settle it only if you pursue this role |
| P2 | Fluent Dutch | must_have | absent | medium | capability | You describe your Dutch as "conversational, not fluent". Conversational Dutch helps, but it doesn't meet "fluent" | `[grounded]` your own words | Closure path: formal Dutch study over months, not weeks |
| P3 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | "I've never worked in planning." Your 4 years of analyst work are real experience, but they aren't planning | `[grounded]` your own words | Carried as a material risk |
| P4 | Own the 13-week plan; balance capacity against the forecast | must_have | absent | none | capability | No planning ownership stated | `[grounded]` your own words | Carried as a material risk |
| P5 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned; I won't assume it from SQL and Power BI | `[grounded]` your background is silent | Not asked: it wouldn't change the decision |
| P6 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system mentioned, which fits with never having worked in planning | `[grounded]` your own words | Carried as a material risk |
| P7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | What carries over: you ran a weekly operational review. Limit: S&OP means trading off supply against demand across functions, which that review didn't cover | `[inferred]` bridge from your route review | none while the decision is `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning experience (P3, P4, P6, must_have) | capability | You confirmed you've never worked in planning | Three must-haves rest on it | Only if you've under-described something: capacity or volume forecasting for depots, peak-season staffing plans | A forecast model or peak plan you owned | `[grounded]` your own words |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The company may be too new or small to have much online presence, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company; research was refused, not run | Can you point me to this role on your own careers site? | unresolved |
| RR5 | Salary not stated | unknown | — | (no pay information in the posting) | They may simply not publish salaries | `[inferred]` from the posting's silence | What salary range is budgeted? | unresolved |
| RR6 | Clearly defined planning scope | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The role is well scoped | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A2 | Skip this one and spend the time on Posting 1 and similar analyst roles | P2, P3, P4, P6 | `[grounded]` the map | pending your approval |
| A3 | If you want to move into planning later, look for supply-chain analyst or junior planner roles, which usually ask for less planning experience | P3 | `[generic]` pattern for this field, not a claim about Kroonhaven | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both refused permission. These would have confirmed the employers and the live postings, and settled RR1 and RR4 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary 2026" and "supply planner FMCG Netherlands salary 2026"; both refused permission. These would have filled in market calibration and RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named, so there was nothing to search |

I can save this as a `tuesday-dossier.md` file you can reuse later, if you'd like.

**What would improve this:**
- Allowing web search: targets 1 and 2 would run, which would confirm both employers (RR1, RR4) and give pay bands to compare against.
- Your pay floor and how far you'll commute: P1 and R1 would settle, and the hard-gates lines would stop reading "unknown".
- A sanitized screenshot of your on-time dashboard: R4 and R5 would rise to `high`.
- Once search works, a deeper check on Duinvaart (leadership, hiring patterns, news), up to 5 more searches and 2 more fetches. Say the word and it runs.

**R1:** Can you do three days a week in the Rotterdam office? And is there a salary floor or other must-have I should check these roles against?

**G1:** Did any of your parcel work involve temperature-sensitive goods, or a compliance metric other than on-time delivery, such as SLA breaches, damage or claims? What did you track?

**G2:** Did your weekly route-performance review lead to any actual route changes? What changed, and what was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.