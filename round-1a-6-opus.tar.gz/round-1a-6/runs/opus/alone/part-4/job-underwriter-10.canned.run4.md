Reading the assessment rules is done. Next I'm checking whether Fernquay exists as described, then I'll write up the assessment.
Short answer: yes, it looks legit and it's worth applying for. You've also already applied and been invited to interview, so the real question is how to handle the call.

## Decision snapshot

**Yes, it's worth it and the company checks out: Fernquay's own site confirms what the posting says (RR2), pay sits inside the market band (RR1), and the WhatsApp message is an ordinary scheduling note (P1). Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4, R5 · adjacent: R6 (Own the booking flow end to end), R7 (Research calls with school owners)
- `important` — direct: R9 · unclear: R8 (Being the first, and only, designer)

R8 — the real stretch, and the first question below; R6, R7 — credible bridges whose limits you should name yourself.

**Opportunity ledger.** The employer exists as described (RR2) and the pay is published and in line with the market (RR1). Three things are open: how design decisions get made with no design lead (RR4), what the equity actually is (RR5), and how success is measured (RR6). The posting isn't on Fernquay's own careers page (RR3), but they replied to your application, so the hiring process is clearly real.

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** RR4 turning out to mean the co-founder makes every design call; a pay floor above €60k or two office days not working for you (neither was stated); or the G1 answer showing you'd want a design peer more than this role can offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with Ronan | `[grounded]` JD |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` JD |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Scope read | You'd design for two sides: the school owner (operator) and the person booking. The JD names research with owners and the booking flow, but no admin or back-office design | `[inferred]` from the JD naming both school owners and the booking flow |
| Market calibration | Ireland, 3–5 years' product design: median base €57,000, middle half of salaries €51,500–€62,000. The posting's range sits inside that band, and with 4 years you're near the median. Being a company's first designer is usually broader than a squad role: research, UI and design process all fall to you | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520); `[grounded]` JD figure; `[generic]` first-designer scope pattern |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Who has final say on design; equity terms; success measures; whether design covers the operator admin side | — |
| Contradictions | None. The site adds sailing schools to the JD's sea-kayak and surf, which widens the market rather than conflicting with it. Saoirse Doyle appears as co-founder on the site and as CTO in the WhatsApp message | `[grounded]` about page against JD and WhatsApp |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so commuting is plausible. You didn't say whether two fixed office days suit you | `[grounded]` your background | Constraints question below |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer. Self-reported at intake, nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | Figma daily. A portfolio file is the artifact that would prove it | `[grounded]` your background | Portfolio link would raise this to high |
| R4 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your background | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; Fernquay has two | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Carries over: you redesigned checkout in a travel-booking product, the same kind of flow. Limit: checkout is one stage, and nothing you've said covers availability, the steps before checkout, or what happens after booking | `[grounded]` your background; `[inferred]` that checkout is one stage of an end-to-end flow | Gap queue G2 |
| R7 | Run research calls with school owners | must_have | adjacent | medium | transferability | Carries over: you run research yourself and regularly. Limit: your sessions were usability tests with customers (people booking), while these calls are interviews with business owners, a different side of the transaction | `[grounded]` your background; `[inferred]` from the JD naming school owners as participants | Gap queue G3 |
| R8 | Being the first, and only, designer | important | unclear | low | discovery | You've never been the only designer anywhere. Still open: whether you were the only designer inside your squad, and how much you set your own process there | `[inferred]` from "You would be our first designer"; `[grounded]` your statement | Gap queue G1 |
| R9 | Booking-domain product experience | important | direct | medium | none | 4 years at a travel-booking company, including the checkout redesign | `[inferred]` requirement, from the product being booking software; `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Being the first designer (R8, important) | discovery | You've never been the only designer at a company. It's unknown whether you were the only designer in your squad | The one row not established as a fit, and the role's defining feature | Being the only designer in your four-engineer squad; setting up the monthly usability sessions yourself; making design calls without a design lead signing off | A case study showing your own decisions; a research plan you wrote | `[grounded]` your statement; `[inferred]` that squad-level solo work is the closest bridge |
| G2 | End-to-end booking flow (R6, must_have) | transferability | Checkout redesign confirmed; other stages of the flow unknown | Strengthens the bridge for the core responsibility | Search or availability screens, the booking confirmation, changes and cancellations, anything on the supplier or admin side | Flow diagrams, a before-and-after of the checkout | `[grounded]` your background |
| G3 | Research with business owners (R7, must_have) | transferability | Usability sessions with customers; no business-owner interviews mentioned | Owner interviews are a named, recurring part of the job | Interviews with hotel or tour-operator partners, supplier-side feedback sessions | A discussion guide or research synthesis, sanitized | `[grounded]` your background; `[inferred]` that operator interviews differ from consumer usability tests |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay published and in line with the market | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The range covers the middle of the Irish band for 3–5 years | `[grounded]` JD; `[generic]` Tillerby band | Where in the range does someone with 4 years' booking-product experience land? | noted |
| RR2 | Employer established, and it matches the posting and the message | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The site confirms the size, location, product and both people named in the WhatsApp message | `[grounded]` fernquay.example/about | none | noted |
| RR3 | Posting not found on Fernquay's own site | unknown | — | "Product Designer — Fernquay" | There may be no careers page, or the role may only be listed where you found it. The reply to your application shows the process is live | `[grounded]` careers fetch returned no page; `[generic]` small companies often post only on job boards | Is the role listed anywhere on your own site? | unresolved |
| RR4 | First designer with no design lead | risk_signal | low | "You would be our first designer… work most closely with our co-founder" | You may be accountable for design quality with nobody to critique your work, and final design calls may sit with the co-founder | `[inferred]` from the JD's first-designer framing beside its silence on decision rights | When you and Ronan disagree on a design, who makes the call, and how? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "0.5–1% equity" | Options or shares, vesting and valuation are all unknown. A customer-funded company has no investor exit timetable, so the equity's value is less predictable | `[grounded]` JD silence; `[generic]` liquidity pattern for customer-funded companies | Is it options or shares, on what vesting schedule, and at what valuation? | unresolved |
| RR6 | No success measures stated | unknown | — | "own the booking flow end to end" | What a good first year looks like is undefined | `[inferred]` from the JD's silence on outcomes | What would make this hire a success at six and twelve months? | unresolved |

## Application plan

You're at the interview stage, so this is call preparation.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Reply on WhatsApp to confirm or move the time, and join through the emailed invite. Scheduling over chat or text is routine, especially at a six-person company; a quick check that the invite comes from a Fernquay address is plenty | Answers why the WhatsApp message felt odd | `[generic]` hiring-practice pattern; `[grounded]` Ronan and Saoirse named on the about page | pending your approval |
| P2 | Lead with the checkout case study they said they loved, and describe it in your own words: "I redesigned our checkout flow." Don't say you owned the whole booking flow unless G2 confirms you did | See R6; truthful framing | `[grounded]` the WhatsApp quote "we loved the checkout case study" | pending your approval |
| P3 | On being the only designer, say it straight: you haven't been the only designer at a company, then describe how you'd get critique and structure on your own. Build the answer from G1, not from assumptions | See R8, RR4 | `[grounded]` your statement | pending your approval |
| P4 | When research comes up, say your sessions were usability tests with customers, and that interviews with school owners would be new ground you'd plan for | See R7; keeps the customer-versus-owner difference visible | `[grounded]` your background | pending your approval |
| P5 | Ask the questions from RR4, RR5 and RR6 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |
| P6 | Have one messy real project ready, such as raw usability notes or early checkout sketches, sanitized if they're confidential | The posting asks for exactly this | `[grounded]` JD: "we would rather see one messy real project than a polished deck" | pending your approval |
| P7 | Ronan spent five years as product lead at a Galway travel-software company, so your travel-booking background is likely to make sense to him quickly | Who you'll be talking to | `[grounded]` Ronan's public LinkedIn profile; `[inferred]` that the overlap will register | pending your approval |
| P8 | If you want to rehearse the call itself, mock-interview does that | Rehearsal is outside this assessment | `[grounded]` the scope of this skill | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway", which returned "About Fernquay" (fernquay.example/about). Fetched fernquay.example/careers, which returned no page. Moved the organization and contradictions rows, RR2 and RR3 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved P7 |

I can save all of this as a `tuesday-dossier.md` file you can carry to later sessions, if that's useful.

**Upgrade menu**
- **A portfolio link or the checkout case study:** R3, R4 and R6 could move to `high`.
- **Your pay floor and whether two office days suit you:** the hard-gates line becomes a full check.
- **Answers to G1 and G2:** R8 resolves and the R6 bridge strengthens.
- **A deeper research pass on Fernquay** (customer reviews of Kelproster, hiring history, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1 — In your squad of four engineers, were you the only designer, and which design decisions did you make without a design lead's sign-off?

G2 — Apart from checkout, which parts of the booking journey did you design: search, availability, confirmation, changes and cancellations, or anything on the supplier side?

R1 — Do two fixed office days a week in Galway work for you, and is there a salary below which you wouldn't move?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.