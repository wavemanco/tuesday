Your two searches to check Marrowgate Housing's website and typical payroll salaries were blocked by permissions, so this is based only on what you pasted. The full assessment follows.

## Decision snapshot

**Yes, this is normal. After a written offer like this one (RR2), asking for your bank details, PPS number and passport is a routine onboarding step, not a warning sign. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R10 (Hybrid, two days a week in our Limerick office), R11 (right-to-work check)
- `must_have`: direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI and USC) · absent: R5 (pension changes)
- `important`: direct: R6, R7 · adjacent: R8 (240 staff, monthly) · unclear: R9 (answer staff payroll queries)

R5: a gap to raise and plan training for, not a reason to turn the job down; R2: probably settled by one answer; R8: a bigger payroll of the same kind of work.

**Opportunity ledger.** The offer is specific and matches the ad (RR2, RR3). I couldn't check the employer myself because the searches didn't run (RR1). The contract terms beyond pay aren't in the email yet (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days a week in our Limerick office), R11 (right-to-work check); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: marrowgatehousing.ie is the association's own website; (2) R10 and R11 work for you; (3) RR4: the written contract matches the offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` job ad |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` job ad |
| Terms | Permanent, €40,000, reporting to Declan Garvagh, Finance Manager; hybrid with two office days in Limerick; start date agreed after your notice | `[grounded]` offer email |
| Process so far | Two in-person interviews at their office, then a written offer from people@marrowgatehousing.ie | `[grounded]` your account |
| Onboarding asks | Bank details, PPS number and a passport scan through an onboarding portal sent after you accept; the original passport on day one | `[grounded]` offer email |
| Scope read | A normal mid-level payroll role. The listed duties match the salary band and the requirement of 2+ years | `[inferred]` from the ad's duties set against its requirements |
| Unknowns | Pension scheme and how pension changes are handled; probation; the contract's details | — |
| Contradictions | None. The offer's salary, hybrid pattern and title all match the ad | `[grounded]` ad and offer compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years running fortnightly payroll for 90 staff. Stated but not yet checked against anything, which caps it at `medium` | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say whether the hotel group's payroll was Irish | `[grounded]` your background is silent on it | see G1 |
| R3 | Process starters and leavers | must_have | direct | medium | none | You've done starters and leavers yourself | `[grounded]` your background | none |
| R4 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | You do this monthly in your current job, so it carries over directly | `[grounded]` your background | none |
| R5 | Process pension changes | must_have | absent | none | discovery | You haven't processed them yourself because your manager did. What you saw of them hasn't been explored yet, so this is not yet a capability call | `[grounded]` your own statement | see G2 |
| R6 | Strong Excel | important | direct | medium | none | Daily use, including pivot tables and XLOOKUP | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards one | important | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |
| R8 | Scale: 240 staff paid monthly | important | adjacent | medium | transferability | 90 staff paid fortnightly is the same work at under half the headcount, run twice as often. Limit: you haven't yet run a payroll of 240 | `[inferred]` from comparing the two payrolls | see G3 |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention handling queries | `[grounded]` your background is silent on it | see G4 |
| R10 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The job's terms are clear, but you haven't said whether they work for you | `[grounded]` offer email; your constraints not given | confirm for yourself before accepting |
| R11 | Pass the right-to-work check | hard_gate | unclear | none | hard_gate | The offer requires the check. Your work status isn't stated, and I don't need to know it | `[grounded]` offer email | confirm for yourself; no need to share any details here |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R2, must_have) | discovery | Your background doesn't say which country the hotel payroll was in | If it was Irish, R2 becomes `direct` | Processing Revenue payroll submissions; handling emergency tax; applying USC rates and PRSI classes | None needed; your own account is enough at this stage | `[grounded]` your background is silent on it |
| G2 | Pension changes (R5, must_have) | discovery | Your manager handled them | It's the one listed duty you haven't done yourself | Setting up pension deductions in payroll runs; checking contribution amounts on payslips; passing change forms to your manager; reconciling pension deductions to the ledger | None needed | `[grounded]` your own statement |
| G3 | Scale (R8, important) | transferability | 90 staff, fortnightly | A bigger headcount on a monthly cycle | Peak periods with seasonal staff; covering for colleagues | None needed | `[inferred]` from comparing the two payrolls |
| G4 | Staff queries (R9, important) | discovery | Not mentioned | It's a stated part of the job | Payslip queries, tax questions, leaver final pay | None needed | `[grounded]` your background is silent on it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (the searches didn't run) | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The association may be too new or small to show up online, the posting may be out of date, or it may not be a real hiring employer. Your in-person interviews at their office already weigh against the last of these | `[generic]` pattern applied whenever research can't run; not a claim about this employer | Is marrowgatehousing.ie your main website, and is the onboarding portal linked from it? | unresolved |
| RR2 | Specific written offer from the employer's own domain, after in-person interviews | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | The offer names the role, the pay, your manager and the contract type, and matches the ad | `[grounded]` offer email and your account | none | noted |
| RR3 | Salary published, and the offer sits within it | positive_signal | — | "Salary €38,000–€42,000" / "€40,000 a year" | Pay was open from the start and the offer kept to it | `[grounded]` ad and offer | none | noted |
| RR4 | Contract terms beyond pay not yet in writing | unknown | — | "Please reply to accept within five working days" | Probation, pension scheme, hours and leave aren't in the email. A written contract usually follows acceptance | `[generic]` how offers usually proceed | Could you send the written contract, or a summary of probation, pension and hours, before or with the onboarding link? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the requests for bank details, PPS number and passport as routine. Your payroll needs bank details to pay you, and they need your PPS number to register your job with Revenue so you're taxed correctly. The passport scan and the original on day one are for the right-to-work check | This answers your question. "Never hand these over" is good advice for unsolicited requests and for anything before an offer. It doesn't apply to an employer who has interviewed you and made a written offer | `[generic]` standard Irish onboarding practice | pending your approval |
| A2 | When the portal link arrives, enter your details only if the link's address belongs to Marrowgate's own site, or reach the portal from marrowgatehousing.ie. If the link looks different, phone the People Team on a number from their website before you enter anything | This is the one check that matters at onboarding | `[generic]` good practice | pending your approval |
| A3 | Accept by email, and ask RR4's question in the same reply | It gets the contract terms before you hand in your notice | `[grounded]` RR4 | pending your approval |
| A4 | Before you start, tell Declan that you've seen pension changes handled but haven't processed them yourself, and ask how they're done there | Closing R5 openly costs you nothing now and avoids a surprise later. It is honest framing, not a confession | `[grounded]` R5, your own statement | pending your approval |
| A5 | Ask your current manager to walk you through a pension change before you leave | This could turn R5 into your own experience before you start | `[inferred]` from your manager having handled them | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association" and the permission was refused. It would have checked RR1 and the organization row |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland 2026 Limerick" and the permission was refused. It would have added a market calibration line placing the €40,000 offer against typical pay |
| 3. Hiring manager's public footprint | unavailable | Not run because search permission was refused. It would have shown Declan Garvagh's professional background, for A4 |

---

I can save all of this as a `tuesday-dossier.md` file to keep with your offer if that's useful.

**Upgrade menu**
- Allow web search → RR1 checked against Marrowgate's own website, and a salary benchmark for the €40,000.
- An answer to G1 → R2 likely becomes `direct`.
- An answer to G2 → shows how much of R5 you've already seen, and sharpens A4.
- The written contract → RR4 closes.

**Questions**
1. (G1, R2) Was the hotel group's payroll run in Ireland, under PAYE, PRSI and USC?
2. (G2, R5) When your manager handled pension changes, what part did you see or touch: deductions in the run, the forms, or reconciling them?
3. (R10) Does two days a week in the Limerick office work for you?

You can answer in text, paste a voice note transcript, attach a document, or say skip to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.