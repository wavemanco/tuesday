I'm checking whether Velloway Logistics shows up anywhere public, then I'll write up the full assessment.
# Velloway Logistics: Order Processing Coordinator

## Decision snapshot

**No, don't go ahead. This job is very likely a scam. Don't send your IBAN, PPS number or passport, don't pay anything and don't lodge any cheque. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R6 (At least €30,000 a year)
- `must_have`: direct: R2 · adjacent: R1 (Strong attention to detail), R5 (Order processing) · unclear: R3 (Good written English)
- `important`: unclear: R4 (A quiet place to work)

R2: your Excel tracker covers it; R1, R5: real bridges from your courier work, with their limits named; R3, R4: not yet shown.

**Opportunity ledger.** The messages ask for four things that sink this on their own: paying for equipment (RR1), lodging a cheque and passing most of it on (RR2), your bank, tax and passport details before any offer (RR3), and hiring done entirely by chat (RR4). I also couldn't find the employer anywhere (RR5). The reply address is a free-mail one (RR6), and the "up to" pay rate is vague (RR7).

- **Hard gates:** none failed; unconfirmed: R6 (At least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to be different:** RR1–RR4 would all need to be absent. That means no payment, no cheque, no ID or bank details before a written offer, and a real interview outside chat. RR5 would also need the employer confirmed on its own website.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", as named in the posting. I found no public trace of it. | `[grounded]` posting; `[grounded]` searches, see Evidence status |
| Mandate | Processing orders remotely, with commission per order | `[grounded]` posting |
| Working pattern | Work from home, 15–30 hours a week, you set your own hours | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission". No guaranteed rate is stated. | `[grounded]` posting |
| Pay against your floor | At €26/hr: 15 hrs/week comes to about €20,280 a year and 30 hrs/week to about €40,560. Reaching €30,000 takes about 22 hrs every week of the year at the top rate, and "up to" means the top rate isn't promised. | `[inferred]` arithmetic on the posting's figures |
| Hiring process | Everything on Telegram, "no calls or video interviews". The "interview" was answering questions in the chat. | `[grounded]` posting and messages |
| Market calibration | Order-processing and customer-operations coordinators in Ireland: median €31,200 salaried, middle range €28,400–€34,100 (2026). That is the market, not this employer's offer. | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |
| Unknowns | Who the employer is; whether this is employment or freelance; the guaranteed hourly rate; how commission works | — |
| Contradictions | The kit costs €349, but the cheque instructions send €2,500 (€2,850 minus €350) to the same "equipment partner". The posting says nothing about equipment costs. | `[grounded]` messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day plus keeping the team tracker shows sustained accuracy. You haven't stated an error rate or QA score. | `[grounded]` your background; `[inferred]` that ticket volume shows detail work | Keep a QA score or accuracy figure ready for real applications |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly Excel tracker. That's stated by you and specific, but I haven't seen it, so it stays below `high`. | `[grounded]` your background | none |
| R3 | Good written English | must_have | unclear | low | discovery | You haven't said whether your tickets were written replies or calls | `[grounded]` your background is silent on it | See G1 |
| R4 | A quiet place to work | important | unclear | low | discovery | Not covered in what you shared | `[grounded]` your background is silent on it | Only matters for genuine remote roles |
| R5 | Order processing (implied by the title) | must_have | adjacent | medium | transferability | Parcel-courier customer service sits right next to order work, since orders and deliveries are the subject of your tickets. Limit: you haven't said you entered or processed orders yourself. | `[inferred]` from the title against your courier role | See G2 |
| R6 | At least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own clearly stated floor. Fit is unclear because "up to €26/hr" for 15–30 hours could land anywhere from about €20k to about €40k. | `[grounded]` your statement; `[inferred]` pay arithmetic | Moot here. In real applications, ask for the guaranteed rate or salary. |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written English (R3, must_have) | discovery | Ticket handling, but not whether it was written | Written communication is a common screening point for remote operations roles | Email or chat replies to customers; writing guides for the two starters you trained; tracker notes your team reads | An anonymised ticket reply or a training note you wrote | `[grounded]` your background is silent; `[generic]` that remote operations roles screen for writing |
| G2 | Order processing (R5, must_have) | transferability | Delivery and parcel queries, not order entry | Your strongest bridge into genuine coordinator roles | Fixing addresses or rebooking deliveries in a courier system; processing refunds or claims; updating shipment records | Descriptions of the systems you used, or anonymised screenshots | `[inferred]` from your courier role |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Money sent by bank transfer is very hard to get back. Employers don't charge applicants for work kit. This request is very likely a scam. | `[generic]` how bank transfers and hiring work | Ask the employer, using contact details from its own website: "Did you ask me to pay €349 for equipment, and who is your equipment partner?" | confirmed |
| RR2 | Lodge a cheque and transfer most of it on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can bounce days after the money shows in your account. By then the €2,500 you sent on is gone, and you owe it back to your bank. Don't lodge the cheque. | `[generic]` how cheque clearing works | Same route as RR1: "Did you send me a cheque, and why?" | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | With these three together, someone can open accounts or take out credit in your name. This was asked before any interview or offer. | `[generic]` identity-theft risk | Same route as RR1 | confirmed |
| RR4 | Hiring done entirely by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | You never speak to anyone, so you can't tell who you're dealing with. The "offer" also came through chat. | `[generic]` | "Can I have a call with the hiring manager on a number listed on your website?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The firm may be too new or small to show up online, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company | "Can you point me at this role on your own careers site?" | unresolved |
| RR6 | Contact address not on a company domain | risk_signal | low | "email velloway.hr@postmail.example" | The messages may not come from who they name. Low on its own, given RR5. | `[generic]` | "What is your company email domain?" | unresolved |
| RR7 | Pay stated only as a maximum | unknown | — | "Earn up to €26 an hour plus commission" | The guaranteed rate may be well below €26 | `[inferred]` from the "up to" wording | "What is the guaranteed hourly rate, and is this employment or freelance?" | unresolved |

Hold off on the payment, the cheque and sending your details, and go no further in the chat, until you have checked each request with the employer. Use contact details from the employer's own website, not the chat or the email address these messages came from. Who sent these messages is not yet confirmed, and I couldn't find a website for the employer at all. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste your IBAN into the chat. Send no PPS number, passport photo or money. | see RR1, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it. Show it to your bank instead. | see RR2 | `[generic]` how cheque clearing works | pending your approval |
| A3 | Report the posting to the jobs site you found it on | Lets the site review it | `[generic]` jobs sites take reports on listings | pending your approval |
| A4 | Put your effort into other openings: customer-operations or order-processing coordinator roles fit your background, and €28.4–34.1k is the market range against your €30k floor | see R1, R2, R5; Role reality, market calibration | `[generic]` Pennoral 2026 guide | pending your approval |
| E1 | CV line: "Customer service agent, parcel courier (3 years): handled about 60 Zendesk tickets a day; trained two new starters; maintained the team's weekly Excel tracker" | see R1, R2, R5 | `[grounded]` your background, restated without widening | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway careers order processing coordinator". Both returned no results, so the employer is not established. This feeds RR5. |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned the "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This feeds the market calibration and A4. |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle, so there was nothing to search for |

## Upgrade menu

- A link to the posting on the jobs site, or to the employer's own website → RR5 can be checked against a real page.
- Your CV → R1, R3 and R5 can be tightened for genuine coordinator applications.
- A deeper research pass (up to 5 more searches and 2 more fetches) → it only helps if a website for the employer turns up. Say the word and it runs.

I can save all of this as a `tuesday-dossier.md` file if you'd like a copy to keep.

G1: When you handled tickets, were you writing replies to customers (email or chat), and roughly what share of your day was written?
RR5: Do you still have the link to the original posting on the jobs site?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.