Reading the skill's rules is done. Next I'm checking that both employers exist and looking up typical pay for each role, then I'll write up both assessments.
I couldn't run any research: all four web searches were declined by permissions. So I can't confirm either company exists or say what these roles usually pay, and both assessments rest only on what you gave me.

## Decision snapshot — Duinvaart Cold Chain, Operations Analyst

**Yes, this one is worth your time, as long as the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: D-R1 (Hybrid, three days a week in our Rotterdam office)
- `must_have`: direct: D-R2, D-R3, D-R4, D-R5 · adjacent: D-R6 (temperature compliance across our refrigerated fleet)
- `important`: unclear: D-R7 (work with depot managers on route changes)
- `preferred`: direct: D-R8

D-R5 (`medium`): the closest match to your own work, but your exact part in it still needs saying; D-R6: a credible bridge, but you haven't done cold-chain work; D-R7: one answer away from `direct`.

**Opportunity ledger.** I couldn't confirm the employer (D-RR1). Pay and contract type aren't stated (D-RR2, D-RR4). On the plus side, the duties and tools are specific (D-RR3).

- **Hard gates:** none failed; unconfirmed: D-R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting check out (D-RR1); (2) three office days a week in Rotterdam work for you (D-R1); (3) cold chain is presented as adjacent experience, never as experience you have (D-R6).

## Decision snapshot — Kroonhaven Foods, Supply Planner

**No, this one probably isn't worth your time. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: K-R1 (On-site in Utrecht)
- `must_have`: adjacent: K-R3 (fluent Dutch), K-R7 (run the weekly S&OP meeting) · unclear: K-R4 (advanced Excel), K-R5 (SAP IBP or a similar planning system) · absent: K-R2 (3+ years of supply or demand planning in FMCG), K-R6 (own the 13-week supply plan)

K-R2, K-R6: you said you've never worked in planning, and planning is the whole job; K-R3: the posting asks for fluent Dutch and you describe yours as conversational.

**Opportunity ledger.** I couldn't confirm the employer (K-RR1). Pay isn't stated (K-RR2). The job itself is clearly defined (K-RR3). Nothing on the employer's side rules it out; the problem is the fit.

- **Hard gates:** none failed; unconfirmed: K-R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to be different:** real supply or demand planning experience (K-R2, K-R6) and fluent Dutch (K-R3). No rewording of your CV fixes either one.

## Role reality

| Element | Duinvaart: what it is | Kroonhaven: what it is | Provenance |
|---|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, runs a refrigerated fleet | Kroonhaven Foods, Utrecht, has a chilled ready-meals range | `[grounded]` posting headers; I couldn't confirm either company exists (searches declined) |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | Own the 13-week supply plan; balance production capacity against the forecast; run the weekly S&OP meeting | `[grounded]` postings |
| Working pattern | Hybrid, three days a week in the Rotterdam office | On-site in Utrecht | `[grounded]` postings |
| Scope read | An individual analyst job, not a team lead. It sits close to your current one, plus a temperature metric | A planner who owns the plan and runs the meeting. That's a decision-making job, not an analysis job | `[inferred]` from the duties listed, with no team or reports mentioned |
| Market calibration | Not established: the pay search was declined, and I won't quote a pay range from memory | Not established, same reason | — |
| Unknowns | Pay, contract type, team size | Pay, contract type, whether the S&OP meeting is run in Dutch | — |
| Contradictions | None in the posting | None in the posting | `[grounded]` postings |

## Evidence map — Duinvaart

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D-R1 | Hybrid, three days a week in our Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't said where you live or what commute you'll accept | `[grounded]` posting; your message doesn't cover it | Closing question on location |
| D-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier: specific, but nothing to inspect yet | `[grounded]` your background | none |
| D-R3 | Strong SQL | must_have | direct | medium | none | "SQL … daily": specific, nothing to inspect, expect a technical probe | `[grounded]` your background | Have a sanitized query or a past test ready |
| D-R4 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | none | "Power BI daily": specific, nothing to inspect | `[grounded]` your background | Screenshot of a dashboard with the data hidden → `high` |
| D-R5 | Track on-time delivery | must_have | direct | medium | none | The on-time delivery dashboard your depot managers use is the same metric. Your message doesn't say whether you built it or maintained it, so the wording waits on D-G2 | `[grounded]` your background | Closing question D-G2 |
| D-R6 | Temperature compliance across a refrigerated fleet | must_have | adjacent | medium | transferability | Carries over: tracking compliance-style metrics, SQL, Power BI. Missing: no temperature data or cold chain mentioned at the parcel carrier | `[inferred]` from parcel on-time tracking to temperature compliance | Closing question D-G1 |
| D-R7 | Work with depot managers on route changes | important | unclear | medium | discovery | You ran the weekly route-performance review, but you don't say whether it led to route changes | `[grounded]` your background | Closing question D-G2 |
| D-R8 | Dutch a plus | preferred | direct | medium | none | The posting sets no level; conversational Dutch is Dutch | `[grounded]` posting and your background | none |

## Evidence map — Kroonhaven

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K-R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't said where you live or what commute you'll accept | `[grounded]` posting | Closing question on location |
| K-R2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said "I've never worked in planning," and parcel delivery isn't FMCG | `[grounded]` your own statement | Not fixable by rewording; it's the main reason for `no_go` |
| K-R3 | Fluent Dutch | must_have | adjacent | medium | transferability | You have some Dutch; the limit is that you call it "conversational, not fluent" and the posting requires fluent | `[grounded]` your statement; `[inferred]` that the S&OP meeting would be in Dutch | none |
| K-R4 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned | `[grounded]` your message doesn't cover it | Not asked: the answer wouldn't change the decision |
| K-R5 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | Not mentioned | `[grounded]` your message doesn't cover it | Not asked: the answer wouldn't change the decision |
| K-R6 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning work, by your own account | `[grounded]` your own statement | none |
| K-R7 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Carries over: running a recurring weekly review with operations people. Missing: S&OP is where planning trade-offs get decided, and you haven't run that kind of meeting | `[inferred]` from your route-performance review | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| D-G1 | Temperature compliance (D-R6, must_have) | transferability | On-time tracking at a parcel carrier; no temperature-controlled work mentioned | The only must-have that isn't `direct` | Pharma or food parcels with temperature limits; any SLA or breach metric you flagged and others acted on; sensor or exception data you put into a report | A dashboard page with the data hidden; a metric definition you wrote | `[inferred]` bridge from parcel on-time tracking |
| D-G2 | Route changes, and your part in the on-time dashboard (D-R7, D-R5) | discovery | You ran the review, and depot managers use the dashboard; whether you built it and whether routes changed isn't stated | Decides how strongly you can describe your strongest experience | You built or redesigned the dashboard; a finding from the review that changed a route, a cut-off time or how a depot was staffed | Before-and-after numbers, a review deck with the data hidden | `[grounded]` your background; what's missing is unstated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| D-RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to have a web presence, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| D-RR2 | Pay not stated | unknown | — | (no pay in the posting) | The company may just not publish pay, or the figure may be below what a 4-year analyst expects | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| D-RR3 | Specific duties and tools | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The job is clearly defined and you can measure how you're doing | `[grounded]` posting | Which routes or depots would I start on? | noted |
| D-RR4 | Contract type not stated | unknown | — | (posting silent) | Could be permanent, fixed-term or through an agency | `[inferred]` from the posting's silence | Is this a permanent contract? | unresolved |
| K-RR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The company may be too new or small to have a web presence, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| K-RR2 | Pay not stated | unknown | — | (no pay in the posting) | The company may just not publish pay | `[inferred]` from the missing figure | What salary range is budgeted for this role? | unresolved |
| K-RR3 | Clearly defined planning job | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | Clear ownership and a fixed planning horizon | `[grounded]` posting | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| D-P1 | Lead your CV and cover note with the on-time delivery dashboard depot managers use and the weekly route-performance review. Use your own verbs ("built", "maintained", "ran") once D-G2 is answered | see D-R5, D-R7 | `[grounded]` your background | pending your approval |
| D-P2 | Present cold chain honestly: "on-time delivery tracking at a parcel carrier, in SQL and Power BI"; temperature compliance is a new metric for you, not one you've tracked | see D-R6 | `[grounded]` D-R6 row | pending your approval |
| D-P3 | Find the job on Duinvaart's own careers site before you put time into a tailored application | see D-RR1 | `[grounded]` D-RR1 | pending your approval |
| D-P4 | Ask the D-RR2 and D-RR4 questions at the first recruiter call | see D-RR2, D-RR4 | `[grounded]` register | pending your approval |
| K-P1 | Skip Kroonhaven. If you apply anyway, never describe the route review as S&OP or as planning work | see K-R2, K-R6, K-R7 | `[grounded]` your own statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both calls were declined. They would have confirmed each company and posting, closing D-RR1 and K-RR1 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands Rotterdam" and "supply planner FMCG salary Netherlands"; both calls were declined. They would have filled in the market calibration rows and given D-RR2 and K-RR2 a pay range to compare against |
| 3. Hiring manager's public footprint | n/a | Neither posting names a hiring manager |

---

If you'd like, I can save the Duinvaart assessment as `tuesday-dossier.md` to bring to later sessions.

**What more input would unlock:**
- Web search permission → targets 1 and 2 run: the companies get verified (D-RR1, K-RR1) and the pay calibration gets a range.
- Your location and any pay floor → D-R1 and K-R1 move from unconfirmed to met or failed.
- A dashboard screenshot or sanitized SQL sample → D-R3 and D-R4 go from `medium` to `high`.
- The hiring manager's name → which story to lead with.
- A deeper research pass on Duinvaart (leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions:**

D-R1 / K-R1 — Where are you based, and are there any terms you won't move on, such as commute, office days or a pay floor?

D-G1 — At the parcel carrier, did any of your work involve temperature-controlled or time-critical shipments, or tracking breaches that had to be flagged?

D-G2 — What was your part in the on-time delivery dashboard and the weekly route-performance review: did you build them, run them or contribute to them? And did any route change come out of the review?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.