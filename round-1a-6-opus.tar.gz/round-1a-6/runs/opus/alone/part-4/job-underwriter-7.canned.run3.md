I'm going through the assessment framework now, then I'll do a quick check on the employer and pay before writing up whether this one is worth applying for.
**Yes, this one is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5, R7, R10, R12 · adjacent: R13 (Hold a small caseload of your own) · unclear: R6 (Leg-ulcer care), R8 (Continence care), R9 (End-of-life visits), R11 (Care planning)
- `preferred`: absent: R14 (Doppler assessment for leg ulcers)

R4: essential, and your CV doesn't show it yet; R13: a real bridge from your discharge-to-assess home visits, with its limit named; R6, R8, R9, R11: the CV is silent on these, which isn't the same as you lacking them; R14: desirable only, with a way to close it.

**Opportunity ledger.** The advert is clear and open about its terms. The pay is stated and spans the market range (RR2), support for your first caseload is named (RR3), and the team lead has spoken publicly on Doppler training for staff new to community work (RR4). Two things are unknown: I couldn't find the vacancy on the employer's own careers page (RR1), and the advert doesn't give hours or rota (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can describe your record-keeping in concrete terms (R4, see G1); (2) the vacancy is confirmed live, through the informal chat or the employer's own site (RR1); (3) R13 is described as home visiting under discharge-to-assess, never as holding a caseload.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page (search result) |
| Role | Community Staff Nurse, Band 5, district nursing team, Halifax. Care for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, records on an electronic patient record | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | A normal Band 5 community post: you hold a caseload with senior support. It isn't a stretch role or a caseload-lead role | `[inferred]` from "small caseload" plus "supported by a senior community nurse" |
| Terms | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Community staff nurse Band 5 in England: median £34,300, middle half £32,400–£36,600. 61% get mileage, 24% have a pool or lease car. The advert's range covers that whole middle band. With five years' experience, which pay point you start on is the real question (RR2) | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (n=1,240); `[grounded]` advert for the range |
| Hiring contact | Rhiannon Mabbott, Community Nursing Team Lead. Leads the Halifax district nursing team after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` advert; `[grounded]` community nursing forum speaker page (search result) |
| Unknowns | Hours and rota (weekends, lates); full- or part-time; starting pay point; closing date; whether the vacancy is on the employer's own site | n/a |
| Contradictions | None between the advert and the employer's About page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV says Registered Nurse (Adult), active, revalidation due March 2028. That's stated, not checked | `[grounded]` CV | Check your own entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV says full UK licence, category B. Stated, not checked. Pool cars are provided | `[grounded]` CV; advert | Check your own driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical staff nurse, well over the one-year minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | The CV says nothing about documentation or which record systems you've used | `[grounded]` CV silence | G1 |
| R5 | Wound care | important | direct | medium | none | Wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | unclear | low | discovery | Your wound care lists pressure ulcers and surgical wounds. Leg ulcers aren't mentioned either way | `[grounded]` CV | G2 |
| R7 | Catheter care | important | direct | medium | none | Catheter care is stated | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | Catheter care is stated; wider continence care isn't | `[grounded]` CV | G2 |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care, on the ward or at home | `[grounded]` CV silence | G2 |
| R10 | Insulin administration | important | direct | medium | none | Insulin administration is stated | `[grounded]` CV | none |
| R11 | Care planning | important | unclear | low | discovery | The CV doesn't mention writing or reviewing care plans | `[grounded]` CV silence | G1 |
| R12 | Caring for housebound adults in their own homes | important | direct | medium | none | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge | `[grounded]` CV | none |
| R13 | Hold a small caseload of your own | important | adjacent | medium | transferability | What carries over: 18 months of home visits, working alone in patients' homes. The limit: you've never held your own caseload, and you say so yourself. Discharge-to-assess visits cover a short window, not ongoing ownership. The advert's senior support covers that step | `[grounded]` CV and your own statement; `[inferred]` that short-window visits differ from ongoing caseload ownership | Frame it as in E1 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. It's desirable, not essential | `[grounded]` your own statement | Closure path: ask about Doppler training for new starters (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and care planning (R4 must_have, R11 important) | discovery | The CV is silent on documentation, care plans and record systems | R4 is the only essential not yet shown; filling it moves the status toward `go` | Writing discharge-to-assess visit notes and handover records; using the hospital's electronic record or a community system; writing or updating care plans, risk assessments (Waterlow, MUST, falls), wound charts; any audit of record-keeping you passed or ran | Description only; never share real records. A documentation audit result or training certificate if you have one | `[grounded]` CV silence; `[inferred]` that it moves the status |
| G2 | Leg ulcers, continence, end of life (R6, R8, R9, important) | discovery | Wound and catheter care are stated; leg ulcers, wider continence care and end-of-life care aren't | These are the advert's core daily work, and concrete examples strengthen your application | Compression bandaging or leg-ulcer dressings on the ward; continence assessments, pad reviews, bowel care; caring for dying patients on a medical ward; syringe drivers; anticipatory medications; end-of-life care training | Training certificates (e.g. syringe driver, tissue viability) | `[grounded]` CV |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not found on the employer's own site | unknown | n/a | "Current vacancies are listed on our careers page" | The careers page may be at a different address, or the vacancy may only be listed on a jobs board | `[inferred]` from the careers-page fetch returning no page, set against the About page saying vacancies are listed there | Where is this vacancy advertised, and what's the closing date? | unresolved |
| RR2 | Pay stated, in line with the market | positive_signal | n/a | "£31,050–£37,800 a year plus mileage" | The range covers the market middle band. Your five years may put you toward the top | `[grounded]` advert; `[generic]` Wardround band | Where in the range would someone with five years' post-registration experience start? | noted |
| RR3 | First caseload comes with named support | positive_signal | n/a | "You will hold a small caseload of your own, supported by a senior community nurse" | There's a real structure for someone new to caseload holding | `[grounded]` advert | What does that support look like in the first three months: joint visits, caseload size, supervision? | noted |
| RR4 | Team lead has spoken publicly on Doppler training for new staff | positive_signal | n/a | "Doppler training for staff new to community work" (forum speaker page) | R14 may be closable once you're in post | `[grounded]` forum speaker page; `[inferred]` that it applies to this post | Is Doppler training offered to new starters, and how soon? | noted |
| RR5 | Hours and rota unstated | unknown | n/a | "Community Staff Nurse, Band 5" (no hours given) | The post may include weekends, lates or a rota | `[generic]` district nursing services often run seven-day rotas | What hours and rota does the post work, and is it full-time? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott and ask the RR1, RR2, RR3, RR4 and RR5 questions | The advert invites it, and the register doubles as your question list | `[grounded]` advert; register | pending your approval |
| E1 | Lead your CV and statement with the discharge-to-assess work, worded as: "18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge." Don't say "managed a caseload" | Supports R12 and R13 truthfully | `[grounded]` CV | pending your approval |
| E2 | Add records, care planning, leg-ulcer, continence and end-of-life examples only after you confirm them (G1, G2) | Supports R4, R6, R8, R9, R11 | `[grounded]` gap queue | pending your approval |
| E3 | Doppler: say plainly you haven't done one yet and want the training | R14, RR4 | `[grounded]` your own statement; forum speaker page | pending your approval |
| A2 | Mention you live in Halifax | Local knowledge for home visits | `[grounded]` CV | pending your approval |

All wording above, including the advice in this plan, is a proposal for you to approve before it goes into anything you send.

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this, and I haven't used or repeated it. Leave it off applications until you have a written offer.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers Community Staff Nurse Band 5 vacancy". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about), which established the employer. Fetched calderbrookhealth.example/careers, which returned no page. Moved: role reality's organisation row, RR1 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026/27 community staff nurse district nursing", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the hiring contact row, RR4, E3 |

## Closing

If it's useful, I can save all of this as `tuesday-dossier.md` to keep or carry into later steps.

**Upgrade menu**
- Your answer to G1 → R4 and R11 resolve; this condition likely clears and the status moves toward `go`.
- Your answer to G2 → R6, R8 and R9 resolve, and give E2 concrete lines.
- Your constraints (hours, pay floor, rota limits) → proper hard-gate checks against RR2 and RR5.
- A record-keeping or tissue-viability training certificate → R4 or R6 confidence rises.
- A deeper research pass on Calderbrook (CQC or contract reports, staff reviews, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1: On the ward or in discharge-to-assess, what did your record-keeping involve (electronic system, care plans, risk assessments), and did you write care plans yourself?

G2: Which of these have you done: leg-ulcer dressings or compression, continence assessments beyond catheters, end-of-life care such as syringe drivers or anticipatory medications?

Constraints: Is there anything that would rule a job out for you, such as hours, weekends, part-time only, or a minimum salary?

For any of these, answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.