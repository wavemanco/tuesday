Still reading the assessment framework's rules; next I'll check both employers online, then give you a verdict on each.
## Posting 1 — Operations Analyst, Duinvaart Cold Chain

### Decision snapshot

**Yes, worth your time. This is close to the job you just did. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: R2, R3, R4, R5
- `important` — adjacent: R7 (work with depot managers on route changes) · unclear: R6 (temperature compliance across our refrigerated fleet)
- `preferred` — direct: R8

R7: you ran route reviews, but you haven't said you drove route changes. R6: no cold-chain evidence yet, a discovery gap.

**Opportunity ledger.** I couldn't confirm the employer or the posting from here because my web searches were refused (RR1), and pay isn't stated (RR2). On the positive side, the responsibilities are concrete and measurable (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam commute works for you (R1); (2) the posting is live on Duinvaart's own careers page (RR1); (3) describe R7 as running route reviews, not as making route changes, unless G2 confirms you made them.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam. Runs a refrigerated fleet | `[grounded]` JD |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | A standard individual-contributor analyst role. "2+ years" sets the bar below your four | `[inferred]` from the JD's experience floor and its lack of people-management language |
| Unknowns | Pay; team size; who you report to; whether the company exists as described (not checked) | — |
| Contradictions | None in the posting text | `[grounded]` JD |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether this commute works | `[grounded]` JD term; you're silent on it | Closing question on R1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier. Self-reported and specific, so the ceiling at intake is medium | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | "SQL … daily" | `[grounded]` your background | Upgrade menu: a sanitized query sample |
| R4 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | none | "Power BI daily" | `[grounded]` your background | Upgrade menu: a dashboard screenshot |
| R5 | Track on-time delivery | must_have | direct | medium | none | "the on-time delivery dashboard our depot managers use". You haven't said whether you built it or maintained it | `[grounded]` your background | Check ownership wording before E1 |
| R6 | Temperature compliance across a refrigerated fleet | important | unclear | none | discovery | Parcel work as described has no temperature element. An SLA or compliance metric you tracked might bridge it | `[grounded]` your background is silent | See G1 |
| R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review, and depot managers use your dashboard. Route changes you proposed or drove aren't stated | `[grounded]` your background | See G2 |
| R8 | Dutch a plus | preferred | direct | medium | none | Conversational Dutch. The posting names no level | `[grounded]` your background and JD | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | discovery | No cold-chain or condition-monitoring work stated | It's half the tracking mandate, and the one area that isn't parcel-native | Tracking any compliance or exception metric such as SLA breaches, damage or failed deliveries; any pharma, food or "keep cool" parcel stream; sensor or telematics data you've queried | A dashboard page or metric definition | `[grounded]` your background is silent; `[inferred]` that this is the area least covered by parcel experience |
| G2 | Route changes with depot managers (R7, important) | discovery | You ran route reviews; outcomes aren't stated | Turns R7 from adjacent to direct | A route or delivery-window change that came out of your review; a depot that changed sequencing because of your data | A review deck or before/after on-time figures | `[grounded]` your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for unverified postings, not a claim about this one. Searches were refused, so nothing was checked | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | Posting has no salary line | The figure may simply not be published | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete, measurable responsibilities | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards" | Clear scope; success is visible | `[grounded]` JD | Which metrics would define success in the first six months? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with: "Ran the weekly route-performance review; SQL and Power BI daily, including the on-time delivery dashboard depot managers use." Say "built" only if you built it | R5, R7; uses your own words | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Find the posting on Duinvaart's own website before you spend time tailoring | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1–RR3's verification questions in your first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

---

## Posting 2 — Supply Planner, Kroonhaven Foods

### Decision snapshot

**No, probably not worth your time. R2, R3 and R6, all must-haves, are absent. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (On-site in Utrecht)
- `must_have` — adjacent: R4 (run the weekly S&OP meeting), R7 (fluent Dutch) · unclear: R5 (advanced Excel) · absent: R2 (3+ years of supply or demand planning in FMCG), R3 (own the 13-week supply plan), R6 (SAP IBP or a similar planning system)

R2, R3, R6: these are the core of the job, and you've said you've never done planning. R4: running a weekly review is a real bridge, but it isn't S&OP. R7: conversational Dutch against a fluency requirement.

**Opportunity ledger.** I couldn't confirm the employer (RR1), and pay isn't stated (RR2). The planning horizon is clearly defined (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to be different:** real planning experience behind R2 and R3, or Kroonhaven opening the role to a trainee with an analyst background. The decision is yours: if you apply anyway, keep the register questions handy.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; a chilled ready-meals range | `[grounded]` JD |
| Mandate | Own the 13-week supply plan; balance production capacity against the forecast; run the weekly S&OP | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A role for an experienced planner. It asks you to own the plan from day one, which leaves little room to learn planning on the job | `[inferred]` from "own" plus "3+ years" |
| Unknowns | Pay; team size; whether the company exists as described (not checked) | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't said whether a daily Utrecht commute works | `[grounded]` JD term; you're silent on it | Only if you pursue this |
| R2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said: "I've never worked in planning" | `[grounded]` your statement | Closure path: a junior planning role (A1) |
| R3 | Own the 13-week supply plan; capacity vs forecast | must_have | absent | none | capability | Same basis as R2 | `[grounded]` your statement | As R2 |
| R4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Carries over: you ran a weekly cross-functional performance review. Limit: no demand, supply or capacity trade-offs were decided there | `[grounded]` your background | none |
| R5 | Advanced Excel | must_have | unclear | none | discovery | Not mentioned. Daily SQL and Power BI work suggests you know data tools, but that doesn't prove advanced Excel | `[grounded]` your background is silent | Not asked, since it can't change this decision |
| R6 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system stated, which fits "never worked in planning" | `[grounded]` your statement | As R2 |
| R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, by your own description. Limit: chairing S&OP in Dutch | `[grounded]` your statement | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning experience (R2, R3, R6, must_have) | capability | Confirmed absent by you | These rows decide the `no_go` | Not a discovery gap. Closing it means a junior or assistant planner role, or a planning course | — | `[grounded]` your statement |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for unverified postings, not a claim about this one. Searches were refused | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | Posting has no salary line | The figure may simply not be published | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Defined planning horizon and forum | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | Clear scope | `[grounded]` JD | Who attends S&OP, and who has final say on the plan? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Spend this time on analyst roles like Posting 1. If planning interests you, look for junior planner or demand-analyst roles | R2, R3, R6 | `[generic]` how people commonly move from analyst into planning; `[grounded]` the map rows | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page: Duinvaart | unavailable | Searched "Duinvaart Cold Chain Rotterdam". The call was refused (search permission not granted). It would have confirmed or cleared RR1 for Posting 1 |
| 1. Official site and careers page: Kroonhaven | unavailable | Searched "Kroonhaven Foods Utrecht". Refused. It would have confirmed or cleared RR1 for Posting 2 |
| 2. Role-family sweep: Duinvaart | unavailable | Searched "operations analyst logistics salary Netherlands Rotterdam 2026". Refused. It would have added a market pay band and a scope comparison |
| 2. Role-family sweep: Kroonhaven | unavailable | Not sent, because search was refused. It would have added a pay band, though that can't change the `no_go` |
| 3. Hiring manager's public footprint (both) | n/a | No name was given |

If you want, I can save all of this as a `tuesday-dossier.md` you can reuse later.

**Upgrade menu**
- Allow web search → I can confirm each employer and live posting (clears or confirms RR1 in both), and add market pay bands for both roles.
- A deeper research pass on Duinvaart (company news, hiring patterns, employee reports; up to 5 more searches and 2 more fetches) → fuller risk register. Just say so.
- A sanitized screenshot of your on-time dashboard, or a sample SQL query → R4 and R5 on Posting 1 rise to `high`.
- The links to the live postings → RR1 can be checked directly.
- A hiring manager's name → a sharper read on scope, and on which story to lead with.

**Questions**

R1 (Posting 1): Can you realistically be in Rotterdam three days a week from where you live?

G1: Have you tracked any compliance or exception metric, such as SLA breaches, damaged or failed deliveries, or a temperature-sensitive parcel stream? What did you measure?

G2: Did any route or delivery-window change come out of the route-performance reviews you ran? What was your part in it, and what happened to on-time performance?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.