I'm reading the assessment framework's worked examples; then I'll build your assessment.
**Yes, it's worth applying for, on the conditions below. Status: `conditional_go`.**

You included your National Insurance number. I don't need it for this, and I haven't used or repeated it.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R7a, R9 · unclear: R4 (clear, timely written records), R5b (leg-ulcer care), R6b (continence care), R7b (care planning), R8 (end-of-life visits)
- `important`: adjacent: R10 (a small caseload of your own)
- `preferred`: absent: R11 (Doppler assessment)

R4, R5b, R6b, R7b, R8: your CV doesn't mention these, which isn't the same as you not having done them; R10: your discharge-to-assess home visits are a real bridge, with a stated limit; R11: preferred only.

**Opportunity ledger.** The advert is clear and open: pay is stated and sits within the market band (RR2), and support for someone new to community work is built in (RR3). Still open: whether the post is still live (RR1), how big the caseload is (RR4) and what the hours are (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your answers to G1–G3 let a supporting statement show R4, R5b, R7b and R8 truthfully; (2) the post is confirmed still open (RR1); (3) R10 and R11 are stated plainly as not done yet, with no gloss.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015; 410 staff across four locality hubs | `[grounded]` the company's About page (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, all recorded on an electronic patient record | `[grounded]` advert |
| Scope read | An entry-level community post. A small caseload of your own with a senior nurse behind you is a supported first step, not sole responsibility | `[inferred]` from "a small caseload of your own, supported by a senior community nurse" |
| Working pattern | Driving between patients' homes; pool cars provided; mileage paid. Hours, weekends and on-call are not stated | `[grounded]` advert, and its silence on hours |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` advert |
| Market calibration | Band 5 community staff nurses in England: median £34,300, middle half £32,400–£36,600. The advert's range covers that whole middle band. This is a market pattern, not this employer's offer | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (n=1,240) |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) |
| Unknowns | Whether the post is still open; caseload size; hours and rota; induction for nurses new to community | — |
| Contradictions | None between the advert and the About page. The careers page address returned no page | `[grounded]` search and fetch results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state Registered Nurse (Adult), active, revalidation due March 2028. That's stated, not checked | `[grounded]` CV | Check your own entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full UK licence, category B, stated, not checked | `[grounded]` CV | Check your DVLA driving record before applying |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse, well over the minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | The CV says nothing about record-keeping or which systems you've used | `[grounded]` CV silence | G3 |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, stated | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | unclear | low | discovery | Your wound list doesn't name leg ulcers. The advert names them, and so does the team lead's published talk | `[grounded]` CV silence; advert; speaker page | G1 |
| R6a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not mentioned beyond catheter care | `[grounded]` CV silence | G5 (upgrade menu) |
| R7a | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R7b | Care planning | must_have | unclear | low | discovery | Not mentioned. Whether your discharge-to-assess work included writing care plans isn't established | `[grounded]` CV silence | G3 |
| R8 | End-of-life visits | must_have | unclear | low | discovery | Not mentioned. Not assumed from ward experience | `[grounded]` CV silence | G2 |
| R9 | Caring for housebound adults in their own homes | must_have | direct | medium | none | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge | `[grounded]` CV | none |
| R10 | A small caseload of your own | important | adjacent | medium | transferability | Bridge: real home visiting (R9). Limit: you say you've never held your own caseload, and a first week after discharge isn't ongoing responsibility for a patient. The advert adds a senior nurse's support | `[grounded]` your statement; advert | Name the limit plainly; see P2 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you've never done one. Only preferred | `[grounded]` your statement | Closure: training. Ask about it at the informal chat (RR3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | discovery | Pressure-ulcer and surgical-wound care; leg ulcers not named | The advert lists it first, and the team lead has spoken on leg-ulcer clinics | Dressing or bandaging venous leg ulcers on the ward; compression care during discharge-to-assess visits; working with tissue viability nurses on a leg wound | A competency record, a tissue-viability training certificate | `[grounded]` CV silence; advert; speaker page |
| G2 | End-of-life visits (R8, must_have) | discovery | Not mentioned | A core part of district nursing in this advert | Caring for dying patients on the medical ward; syringe drivers; supporting families; discharge-to-assess patients going home to die | An end-of-life training certificate, a syringe driver competency | `[grounded]` CV silence |
| G3 | Records and care planning (R4, R7b, must_have) | discovery | Not mentioned | Clear, timely records are an essential criterion | Visit notes and care plans written for discharge-to-assess patients; ward documentation on an electronic system; named systems (e.g. SystmOne, EMIS) if you've used one | Any training record for an electronic patient record system | `[grounded]` CV silence; advert |
| G5 | Continence care (R6b, must_have) | discovery | Catheter care only | Named in the advert beside catheter care | Continence assessments, pad assessments, bladder or bowel care plans | A continence training record | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not confirmed as still open | unknown | — | "For an informal chat about the role, contact Rhiannon Mabbott" | The careers page address returned nothing, so whether the advert is still live isn't established. The employer itself is established | `[grounded]` About page found; careers address returned no page | Is the Community Staff Nurse post still open, and what's the closing date? | unresolved |
| RR2 | Pay stated, in line with market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The stated range covers the market's middle band | `[grounded]` advert; `[generic]` Wardround band | Where in the range would someone with five years' post-registration experience start? | noted |
| RR3 | Support for staff new to community | positive_signal | — | "supported by a senior community nurse" | The role is built for someone growing into a caseload; the team lead has spoken on Doppler training for staff new to community | `[grounded]` advert; speaker page | What does induction look like for a nurse new to community, and is Doppler training included? | noted |
| RR4 | Caseload size unstated | unknown | — | "a small caseload of your own" | "Small" isn't defined: no patient numbers, visits per day or timescale | `[inferred]` from the advert's wording | How many patients and visits a day would I start with, and how quickly does that build? | unresolved |
| RR5 | Hours and rota unstated | unknown | — | "Community Staff Nurse, Band 5" (no hours given) | Weekend, evening or late-shift cover may be part of the rota; community nursing services often run beyond weekday hours | `[generic]` role-family pattern, not a claim about this employer | What are the hours, and how often are weekends or evenings? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Book the informal chat with Rhiannon Mabbott that the advert offers, and ask the RR1, RR3, RR4 and RR5 questions | Closes the open register entries before you write the application | `[grounded]` advert; register | pending your approval |
| P1 | Open the supporting statement with this sentence, in your own words: "For the last 18 months I have been seconded to the hospital's discharge-to-assess team, visiting patients at home in their first week after discharge." Then wound care (pressure ulcers and surgical wounds), catheter care and insulin | R9 is your strongest match. Each clause traces to your CV | `[grounded]` CV | pending your approval |
| P2 | Say plainly that you haven't held your own caseload or done a Doppler assessment, and that you want the training | R10, R11. The team lead's published talk covers Doppler training for staff new to community | `[grounded]` your statement; speaker page | pending your approval |
| C1 | Check your NMC register entry and your DVLA driving record | R1 and R2 are stated, not checked | `[grounded]` R1, R2 | pending your approval |
| E1 | Once G1–G3 are answered, add lines for leg ulcers, end-of-life care and records or care plans, only as you confirm them | R4, R5b, R7b, R8 | `[grounded]` gap queue | pending your approval |

Every line above is a proposal until you approve it, including the positioning advice in P1 and P2.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page. Moved: the organization row; RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing salary 2026 Agenda for Change", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott community nursing team lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: hiring manager row; RR3; P2 |

If you'd like, I can put all of this into a `tuesday-dossier.md` file you can keep.

## Upgrade menu

- Answers to G1–G3 → R4, R5b, R7b and R8 move off `unclear`, and E1 gets drafted.
- Continence experience (G5) → R6b resolves.
- Any training certificate or competency record (tissue viability, syringe driver, an electronic record system) → the matching row's confidence rises.
- The live advert link or closing date → RR1 closes.
- Your own constraints (pay floor, hours, weekend availability) → the hard-gates check runs against them, and RR5 is weighed against you.
- A deeper research pass on Calderbrook (staff reviews, recent news, hiring patterns; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

G1: Have you cared for patients with leg ulcers, on the ward or on discharge-to-assess visits, and what did you do yourself (dressings, compression bandaging, working with tissue viability)?

G2: What end-of-life care have you given, for example syringe drivers, symptom control or supporting families, on the ward or at home?

G3: On the discharge-to-assess team, what did you write up after a home visit, such as visit notes or care plans, and on what system?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.