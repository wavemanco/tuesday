I'm reading the prep skill's rules now. Next I'll do a little research on the school, then build your prep pack.
I've built your prep pack for Thursday's panel. A quick note first: you don't need to share your Social Security number for interview prep, so I haven't used or repeated it. Your license number isn't needed either.

The pack covers a 45-minute panel with Principal Vantongeren and two teachers who would be your teammates. I didn't have the actual job posting, so where the pack refers to posting requirements, it uses a sample fourth-grade posting and marks those parts as inferred.

**Your license fits the job.** The invite requires an Illinois Professional Educator License with an elementary endorsement. Yours covers grades 1–6, which includes fourth grade, and it's active through 2029.

**The question to practice most** is "You've taught third grade for six years but never fourth. What changes for you?" The pack's suggested answer:
- Say the gap plainly first: "I haven't taught fourth grade. I've taught third grade for six years."
- Then describe how you'd get ready, as a plan ("I would…"), not as something you've already done.
- Hold that answer through two follow-ups, then concede the specific thing that's true.

**Keep two things separate.** You led your grade level's move to a new reading curriculum in 2024, and you've never been a team lead. Both are true. The pack keeps them apart so the curriculum work doesn't turn into a team-lead title under pressure.

**From a quick look at the district's website and the principal's public profile:**
- **The panel's topics:** the district's hiring page says panels ask about reading instruction, classroom routines and how you work with families.
- **The district's three beliefs:** Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. The families belief includes speaking with every family each term. Your weekly email is a strong start, but expect a follow-up on talking with families directly.
- **A plan that matches your experience:** the district starts a new grades 3–5 reading curriculum in fall 2027, which lines up with your 2024 curriculum experience.
- **The principal:** she was a reading specialist for nine years, and her 2025 talk was about small-group reading conferences in grades 3–5. Expect detailed reading questions.

The pack also has about two dozen practice questions with answer guidance, six questions for you to ask the panel, and a list of claims to avoid. Some answers are marked as slots for you to fill with what you actually did.

If you'd like to practice out loud, I can play the skeptical interviewer on that fourth-grade question. I can also save a `tuesday-dossier.md` recording the gaps this prep turned up, for future sessions. If you want the pack as a Word document, say so and I'll convert it.

Can you paste the actual job posting? Four of the pack's requirements come from a sample posting, and the real one would replace them and might add requirements the sample missed.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/alone/part-5/rooms/case-9-canned-d1d112fd:
- halvering-elementary_fourth-grade-teacher_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Round:** one 45-minute panel on Thursday, with Principal Dolores Vantongeren (who would be your principal) and two members of the fourth-grade team (who would be your teammates)
**Built from:** your invite and résumé text, plus the district's own pages and a sample fourth-grade posting. No actual posting for this job was supplied, so the posting rows are marked `[inferred]`.

---

## How to use this pack

Two things describe each question. The **persona** is how it's asked: who is asking and in what tone. The **type** is what's being scored:

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior matches the district's published beliefs |
| EXP | Whether what you say about your past holds up when they dig into it |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district: its plans and recent moves |
| CASE | How you reason through a live classroom problem |

The answer guidance is scaffolding, not a script. Say it in your own words. An **answer slot** means the pack doesn't know the answer. Fill it with what actually happened. If the thing it names never happened, or wasn't yours, say so plainly. That is always an acceptable answer.

Labels: `[grounded]` means it traces to your material or a cited source. `[inferred]` means it's derived from a sample posting or reasoned from your material. `[generic]` means it's a common pattern for this kind of interview, not a fact about Halvering.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material shows the requirement met. Say it in the quote's own terms: an Illinois PEL with an Elementary Education endorsement for grades 1–6, active through June 30, 2029. Grades 1–6 include fourth grade. Confirming the record before Thursday is up to you. The license number isn't needed for prep and doesn't appear in this pack |
| F2 | "experience in grades 3 to 5 preferred" — sample posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade falls inside the preferred range. Words: "I've taught third grade for six years, at a public elementary school in Joliet." Expect the panel to move straight on to fourth grade itself (F3) |
| F3 | "Fourth Grade Teacher position" — the invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so yourself. Words: "I haven't taught fourth grade. I've taught third grade for six years." Say how you'd get ready as a plan ("I would…"), never as something you've done. Add nothing to make the gap feel smaller |
| F4 | "plan and teach reading, writing, math, science and social studies" — sample posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material says third grade but not which subjects. Answer slot: the posting's list of subjects makes a question about them likely. Name the subjects you taught in third grade, in your own words. If any weren't yours to teach, say so plainly and stay with the ones that were |
| F5 | "Panels ask about reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your material shows the curriculum move and the club, not how you teach reading in your own classroom day to day. Words: the two quotes, at their own scope. Answer slot: the district's beliefs page leads with "Every Child a Reader", so expect a question about your classroom reading block. Describe how you teach reading in your own words. If part of the block isn't yours to shape, say so plainly |
| F6 | "differentiate instruction using assessment data" — sample posting | none given | none | [inferred] | discovery | Your material doesn't show this either way. Answer slot: if you use assessment results to group or adjust teaching, say how, in your own words. If you don't, say so plainly and say how you would |
| F7 | "classroom routines" — district hiring page | none given | none | [grounded] | discovery | The district names routines as a panel topic, and your material says nothing about them. Answer slot: describe the routines you actually run, in your own words. If you'd be building new ones for fourth grade, say that plainly and describe them as a plan |
| F8 | "how you work with families" — district hiring page | "I write a weekly email to families." — your CV | medium | [grounded] | none | Lead with the email in the quote's own terms: weekly, to families. A specific habit you keep up is more convincing than a general claim about valuing families. There's nothing inspectable behind it yet, so expect a follow-up question |
| F9 | "each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families." — your CV | low | [grounded] | discovery | An email isn't a conversation, so don't stretch it into one. Answer slot: if you speak with families yourself (calls, conferences), say how often and how, in your own words. If you don't currently, say so plainly and say how you'd meet the district's standard |
| F10 | "work with the grade-level team" — sample posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your message | medium | [inferred] | transferability | Both sentences are true, and they sit together without contradiction. Words: "I led our grade level's move to a new reading curriculum in 2024. I haven't been a team lead." Answer slot: the posting's team line makes a question about how the move worked with colleagues likely. Say what part of it you did with the team and what part you did yourself, in your own words. If you don't know where that line fell, say so and stay with the move |

---

## Reading the interviewer

**Principal Dolores Vantongeren** `[grounded]` (Illinois principals' forum speaker page, see Sources)

- She has been principal of Halvering since 2022, after nine years as a reading specialist.
- Her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5.

What this means for Thursday:

1. Expect reading questions from someone who knows reading instruction in depth. Vague answers about "loving literacy" won't land. Concrete descriptions of what you actually do will (A5, D1–D3).
2. Small groups and reading conferences are likely to come up. Describe only what you actually do. If you don't run conferences, say so and talk about how you'd approach them (A5).
3. Her talk gives you a strong, researched reverse question (R1).

Shared-jump opportunity: none offered. None of your quoted sentences matches her move from reading specialist to principal.

**The two fourth-grade teachers:** unnamed, so no read. They are your would-be peers, and they'll be judging what you'd add to their workload and what you'd contribute.

---

## Persona table

Where the weights come from: the invite and the district's "How we hire teachers" page together describe this session. It's one 45-minute panel with the principal and two grade-level teachers, covering "reading instruction, classroom routines and how you work with families." For a panel, the pack blends each member's typical personas. The principal, as your future manager, brings Case and Skeptic. The teachers, as peers, bring Peer Evaluator and Prober. Her reading-specialist background raises the Prober weight on reading.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | "A student is… what do you do?" Planning your first weeks, routines, small groups | High. The principal is buying classroom capability, and the district page names routines and reading as topics | Clarify, set the goal, lay out the steps, say how you'd check, name a risk. Think out loud |
| Skeptic (bank B) | Quiet pressing on third grade versus fourth grade, and "why move" | High. F3 is the one gap you've stated yourself, so it's the obvious thing to probe | Say the gap plainly, give a concrete ramp-up plan, and don't bluff fourth-grade experience |
| Peer Evaluator (bank C) | "How would you work with us?", disagreements, team leadership | High. Two of the three panelists would be your teammates | Lead with what you'd bring them, not only what you'd need. Keep the curriculum move and "team lead" separate (F10) |
| Data-Driven Prober (bank D) | "Walk me through exactly what changed…", "How do you know?" | Medium. Her reading-specialist background makes depth questions on reading likely | Know what you can and can't say about results, and say "I don't know" where that's the truth |
| Values / Behavioral (bank E) | Questions themed on the district's three beliefs | Medium. The beliefs page says they "guide every hire", but neither the invite nor the hiring page names a separate values round | Match each belief to something you actually do. Where your material shows nothing, say so |
| Conversational (bank G) | The warm opener, quick logistics checks | Low, but these questions are still scored | Have a 90-second version of your background ready |
| Pressure (bank H) | "Sixty seconds: why you?", "How much was actually you?" | Low. Nothing in the material suggests a stress style, but one sharp question is common in panels `[generic]` | Pause, hold your position through two follow-ups, then concede the specific thing that's true |

(The banks skip the letter F so their question IDs don't clash with the fit-snapshot rows F1–F10.)

---

## Question banks

**The highest-ROI prep in this pack is B1**: third grade versus fourth grade. It will come up in some form. A calm, rehearsed, non-defensive answer to it changes the interview.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's October, and one of your fourth graders is reading well below grade level. Walk us through your next three weeks with them." | CASE | [grounded] | Structure it: what you'd check first and how, who you'd talk to (the family, the reading specialist, last year's teacher), what you'd change in class this week, how you'd know it's working, and when you'd escalate. The question asks nothing about your past, so the guidance claims nothing | The district's "Every Child a Reader" belief and the panel's reading focus make this close to certain. CASE because it's a live decision, not a record |
| A2 | "It's the first week of school. What routines do you set up in a fourth-grade room, and how?" | CASE | [grounded] | Go in order: arrival, transitions, materials, independent work time, getting help, dismissal. For each, say how you'd teach it, practice it and check it in week one. Give fourth-grade reasons (more independence, longer work blocks) without claiming fourth-grade experience | The district hiring page names classroom routines (F7). CASE because it's planning, not a story |
| A3 | "You've got reading assessment results back. How do you use them to plan next week?" | CASE | [inferred] | Structure: what the results show and what they don't, how you'd group or adjust, what you'd still watch for that the results miss, and when you'd reassess. Connect it to the district's own words: assessments "inform teaching and never replace it". Answer slot: if you already plan from assessment results, give your real example in your own words. If you don't, say so plainly and stay with the plan | From the sample posting's assessment-data line (F6), plus the district belief. Marked `[inferred]` because the posting is a sample |
| A4 | "The district adopts a new grades 3–5 reading curriculum in fall 2027. What should a fourth-grade team do in the year before it arrives?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show that you know the plan: the board adopted it in August 2026, and the new 3–5 curriculum starts fall 2027. You can say, in the quote's terms, that you led your grade level's move to a new reading curriculum in 2024. Answer slot: the posting's grade-level-team line makes a question about how that move went likely. Say what you did with the team and what was yours, in your own words. If you can't separate the two, say so and stay with the move. Then give a plan for Halvering. Don't offer to lead it there | This is where your strongest sentence (F5, F10) meets the district's biggest current plan. CO because it tests whether you've done your homework |
| A5 | "How would you run small-group reading in a full fourth-grade class while the rest of the room works on its own?" | CASE | [generic] | Structure: how groups are formed and changed, what the other students are doing and how it's kept purposeful, how often each group meets, what you track. If you have a real example of doing this, use it in your own words. If not, say so and stay with the plan | The principal's talk covered weekly reading conferences in grades 3 to 5, so this is her own topic. Marked `[generic]` because the question is a common pattern, not a known Halvering practice |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've taught third grade for six years but never fourth. What changes for you, and how do you get ready?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade" | **The highest-ROI rehearsal in this pack.** Start by stating the limit before they push: "I haven't taught fourth grade. I've taught third grade for six years, at a public elementary school in Joliet." Then the ramp-up plan, as a plan: "Before the year starts I would learn the fourth-grade standards, ask the team how they plan each subject, and…" (finish it with steps you'd really take). First follow-up ("Isn't that a big jump?"): hold on the six years, don't add to them. Second follow-up: concede the specific thing, for example "I'd be learning the fourth-grade content as I go, and I'd lean on the team for it." Never imply you've taught fourth grade, and don't list a handful of fourth-grade topics to sound experienced | F3 is a gap you stated yourself, and the job title is fourth grade, so this question is close to certain. JD because it tests the listed role directly |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead." | Pick one real answer, not a disguised strength. Your own material offers two: "I haven't taught fourth grade" or "I haven't been a team lead." Choose the one you'd actually expect to feel, then give the plan for it. Say plainly that it's one area, without apologizing | Skeptics use this to test honest self-assessment (F3, F10). JD because it's about the role's demands |
| B3 | "Why leave a school after six years, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: give your actual reason for moving, in your own words. Keep it forward-looking and never critical of your current school. For "why Halvering," use what's published: the three beliefs and the 2026–2029 literacy plan. Name the one that genuinely matters to you, and why | The six years (F2) make "why now" predictable. EXP because it tests whether your motivation holds together |
| B4 | "Why fourth grade rather than staying in third?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: give your real reason in your own words. If you're applying because this is the opening and not specifically because it's fourth grade, it's fine to say so and then say what interests you about the age | Follows naturally from F3. EXP because it's about your own choices |

### C. Peer Evaluator (the two fourth-grade teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about leading your grade level's move to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are what the quote says: you led it, it was your grade level's move, it was a new reading curriculum, and it was 2024. Tell it in your own words. Answer slot: the posting's team line makes a question about how colleagues were part of it likely. Say what the team did together and what was yours. If there was disagreement, say how it went. If there wasn't, say so and stay with the move | F10 is the evidence for team work and the likeliest thing peers will dig into. EXP because it tests what was actually yours |
| C2 | "Have you been a grade-level team lead?" | EXP | [grounded] "I've never been a team lead."; "I led our grade level's move to a new reading curriculum in 2024" | Plain answer first: "No, I haven't been a team lead." Then, only if it fits: "I did lead our grade level's move to a new reading curriculum in 2024." Don't let the second sentence turn into a team-lead title | F10's two sentences are easy to blur under pressure. EXP because it's a direct check of your history |
| C3 | "Tell us about a time you and a colleague disagreed about how to teach something. What happened?" | EXP | [generic] | Pick a real time that has a clear disagreement, your view, how you raised it, and where it ended with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you'd handle it | The posting's grade-level-team line, asked the way peers usually ask. `[generic]` because no quoted sentence of yours carries a disagreement story |
| C4 | "What would you bring our team in your first month, and what would you need from us?" | CASE | [grounded] "I write a weekly email to families."; "I've run the after-school reading club for the last two years." | Lead with what you'd give, not take. You can name what you do now: "I write a weekly email to families" and "I've run the after-school reading club for the last two years." Offer them as things you'd share, without promising to start them at Halvering. Then what you'd need: their planning rhythm, and how they handle fourth-grade content you haven't taught (F3) | Peers judge whether a hire adds to or eases their load. CASE because it's a forward plan |

### D. Data-Driven Prober (likely the principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through what actually changed in your classroom with the 2024 curriculum move." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Stay inside the quote and describe the changes in your own words. Answer slot: "Every Child a Reader" makes a question about student reading results likely. If you saw a change in students' reading, say what you saw and how you know. If you didn't measure it or don't know, say so plainly. Don't give a figure you can't explain | A reading specialist will dig into F5's strongest line. EXP because it tests the claim behind it |
| D2 | "Tell me about the after-school reading club. Who comes, and what happens in a session?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | The beats from the quote: you run it, and you have for the last two years. Answer slot: describe who comes and what a session looks like, in your own words. Don't add numbers or outcomes you can't stand behind | F5's second piece of evidence, and an easy place to inflate (for example, saying you started it). EXP because it tests details |
| D3 | "How do you know a student's reading is improving?" | JD | [inferred] | Answer slot: name what you actually look at, in your own words. If you rely mostly on one source, say so, and say what else you'd add. Connect it to the district's view that assessments "inform teaching and never replace it" | From the sample posting's assessment-data line (F6). `[inferred]` because the posting is a sample |

### E. Values / Behavioral (the district's three beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about a time a student wasn't reading where they should be. What did you do?" | VAL | [generic] | Every Child a Reader. Pick a real student (no names): where they started, what you did, what changed, and what you'd do differently. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you'd handle it | Themed on the district's first belief. `[generic]` because none of your quoted sentences carries this story |
| E2 | "How do you keep families involved?" | VAL | [grounded] "I write a weekly email to families." | Families Are Partners. Lead with the quote: a weekly email to families. Answer slot: the district expects each teacher to speak with every family each term. If you speak with families yourself, say how and how often. If you don't, say so plainly and describe how you'd meet that standard | F8 and F9: the email is strong, and the speaking standard is where the follow-up will go. VAL because it maps directly onto a named belief |
| E3 | "How do you balance test preparation with the rest of your teaching?" | VAL | [generic] | Teach for Tomorrow, Not for the Test. Pick a real decision where you chose teaching over test prep, or where you used a test result to shape teaching. If none comes to mind, say so plainly and give your approach | Themed on the third belief. `[generic]` because no quote carries the story |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | 90 seconds, built only from these four sentences: six years in third grade in Joliet, leading the 2024 move, the reading club, the weekly family email. Then one line on why this role. Practice it out loud until it's easy | The opener is still scored. Every beat here maps to F2, F5, F8 or F10. EXP because it's your history |
| G2 | "Quick check: your license covers fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | "Yes. Illinois PEL, Elementary Education endorsement for grades 1–6, active through June 30, 2029." Then stop | The invite names the license as a requirement (F1), so it gets a rehearsed answer. JD because it's the stated qualification |
| G3 | "What are your students reading right now?" | EXP | [generic] | Answer slot: name real books and one thing a student said or did with one. Keep it short and specific | A casual question on the panel's main topic. `[generic]` because no quote covers it |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I write a weekly email to families." | Pause. Concede first: "They've taught fourth grade, and I haven't." Then hold on what you have, in the quotes' terms: six years in third grade, leading your grade level's move to a new reading curriculum in 2024, and a weekly email to families. Connect each to Halvering's reading plan and beliefs. Don't claim to be "better". Let the panel make the comparison | F3 under time pressure. JD content, delivered under pressure |
| H2 | "You say you led the curriculum move. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead." | Hold: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which parts were yours and which were shared or decided elsewhere (for example, the choice of curriculum), in your own words. If you don't know where that line fell, say so. If pushed on titles: "I haven't been a team lead." | The attribution test on F10's key sentence. EXP because it tests what was yours |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 License | G2 |
| F2 Grades 3–5 experience | G1, B3 |
| F3 Fourth grade itself | B1, B2, B4, H1 |
| F4 All subjects | none as a separate question. It's likely to come up inside B1 or A2, and F4's answer slot covers it |
| F5 Reading instruction | A1, A5, D1, D2, G3 |
| F6 Assessment data | A3, D3, E3 |
| F7 Classroom routines | A2 |
| F8 / F9 Families | E2, C4 |
| F10 Grade-level team | C1, C2, C3, A4, H2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To the principal: "I read that your 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5. How do those look in Halvering's fourth-grade rooms now?" | It ties to her own work and her nine years as a reading specialist, and it turns her topic into a conversation |
| R2 | "How is the fourth-grade team getting ready for the new grades 3–5 reading curriculum in fall 2027?" | It shows you know the district's current plan, and it opens a natural place to talk about your 2024 experience (F5) |
| R3 | To the teachers: "What could a new teammate do in the first month that would genuinely help your team?" | The reciprocity question: it shows you're thinking about their load, not just yours |
| R4 | "What does Families Are Partners look like for a fourth-grade teacher here? How do the conversations each term usually happen?" | It shows you read the beliefs, and it gets you the practical detail F9 depends on |
| R5 | "How does the team plan together? Shared planning time, splitting subjects?" | A peer-level question that shows you expect to work as part of the team |
| R6 | "What do students find hardest coming up from third grade into fourth here?" | It uses your third-grade background as a question, without claiming fourth-grade knowledge |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F3 | "I haven't taught fourth grade." Then the six years in third grade, at their own scope |
| Has been a grade-level team lead, or led the grade-level team | A negative you stated, and contradicted by the same sentence, F10 | "I haven't been a team lead." Then F10's curriculum quote, at its own scope |
| Chose or designed the new reading curriculum | Inflated form of F5/F10's quote | The quote at its own scope: you led your grade level's move to it. This is the pack's observation, not words for you: the material says you led the move, not that you chose the curriculum. H2's slot stays inside the move |
| Founded or started the after-school reading club | Inflated form of F5's quote | The quote at its own scope: you've run it for the last two years |
| Speaks with every family each term | Inflated form of F8's quote, in the district's own terms | The quote at its own scope: a weekly email to families. E2's slot asks only how you talk with families |
| Taught across grades 3 to 5 | Inflated form of F2's quote | The quote at its own scope: six years teaching third grade |

---

## Sources

**Provided:** your interview invite (Human Resources, Orrinsford Community School District) and your résumé text. Your Social Security number and license number were not used or sent anywhere.

**Searches sent:**

1. `Orrinsford Community School District mission values` → https://orrinsfordschools.example/about/mission-and-beliefs
2. `Halvering Elementary School Orrinsford teacher interview process` → https://orrinsfordschools.example/careers/how-we-hire-teachers
3. `Orrinsford Community School District news 2026` → https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. `Dolores Vantongeren principal Halvering Elementary` → https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. `fourth grade teacher job description Illinois elementary school district posting` → https://k12jobsboard.example/listings/fourth-grade-teacher

**Pages fetched:** the district Mission and Beliefs page; the K12 Jobs Board fourth-grade posting.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. district values | yes | The three beliefs by name. They theme bank E and set F9's family standard. No separate values round was found, so there's no values cheat sheet |
| 2. district interview process | yes | Confirms the one-panel format and the three panel topics (reading, routines, families), which set the persona weights and F5, F7, F8 |
| 3. district strategy / recent news | yes | The 2026–2029 literacy plan, with the new grades 3–5 curriculum in fall 2027. Feeds A4 and R2 |
| 4. Dolores Vantongeren, Halvering | yes | The interviewer read, plus A5 and R1 |
| 5. representative fourth-grade posting | yes | Rows F2, F4, F6 and F10, all `[inferred]` |

---

## Upgrade menu

- **The actual posting for this job** → rows F2, F4, F6 and F10 change from `[inferred]` to `[grounded]`, and any requirement the sample missed gets its own question
- **The names of the two fourth-grade teachers** → a short read on each and a reverse question tailored to them
- **How much prep time you have before Thursday** → a prioritized schedule instead of the full pack
- **Your own answers to the answer slots in F4, F5, F6, F7 and F9** → those rows, and the questions that draw on them, become story-mapped answers
- **A printout of your license record from the state's educator licensing system** → F1 moves from `medium` to `high`
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → Halvering's own school plan and recent news, for sharper CO questions
- **A `tuesday-dossier.md`** → a list of claims checked against your evidence, so the pack's honesty guardrails come from that list rather than being built here
