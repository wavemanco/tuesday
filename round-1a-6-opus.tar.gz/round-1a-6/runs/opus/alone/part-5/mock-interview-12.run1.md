Quick update: I'm reading up on the role and company before building your prep pack.
Before the prep, one thing in the invite. It asks you to "please transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says "you deposit the cheque and send the balance on to the vendor". Asking for a fee, ID and bank details before any offer is a known scam pattern. So is the cheque, where you pay in a cheque and send part of the money on. These requests, and this job offer, are very likely a scam. Don't pay anything, send your passport or bank details, or deposit any cheque until you've checked the invite with the company. Use a phone number or email you find on the company's own website, not the ones in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed properly, job-underwriter can check it as a separate request.

I've saved your prep pack as `Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. I built it for a 30-minute video call with an office manager you'd report to. My web searches were blocked, so it has nothing about the company itself.

**What to expect:** a friendly opener, then "what would you do if…" questions about diaries, travel and invoices. Then some quiet probing on the duties your background doesn't show yet.

- **Your strongest material:** running the appointment book for four physios, and chasing unpaid invoices.
- **Practise first:** B1, "Have you processed supplier invoices before?" Chasing unpaid invoices isn't the same work as processing supplier invoices. A calm, exact answer plus a plan to learn will serve you better than stretching it.
- **Travel and Excel:** be honest here as well. Keep your own word, "okay", for Excel, and talk through how you'd book a trip step by step.
- **Prohibited claims:** the pack lists the claims not to make, such as calling yourself an administrator or saying your Excel is strong.

I can play the Skeptic and run you through B1 live, with follow-up questions.
I can also save a tuesday-dossier.md that records the gaps this prep found, so you can bring it to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to? If so, the pack stands as it is. If they're a colleague or a screener, the question mix changes. Could you also paste the full ad text? Then the requirements would use the ad's own words, not your summary of them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** a 30-minute video call with the office manager (from the invite). Built on the assumption that the office manager is the person this role would report to.

## How to use this pack

Two axes run through it. **Personas** describe *how* a question arrives: friendly chat, a quiet probe, a live problem. **Types** describe *what* is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the way you work, through a real story |
| EXP | Whether what you say about your experience holds up when they dig in |
| JD | Whether you can do the listed duties, gaps included |
| CO | How much you know about the company and what it is doing |
| CASE | How you think through a live problem from the job |

Guidance is scaffolding, not a script. Say it in your own words. Where a cell says **Answer slot**, it marks a likely follow-up and gives you two honest ways to answer: one if you did the thing, one if you didn't. Both are good answers.

## Fit snapshot

Requirements come from the ad as you described it in your message, and the title from the invite.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, from the ad | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, not calendars for office staff, and the words stay there: "For two years I was a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a probe on changes and clashes likely. If running the book meant juggling changes between the four physios, say how you did it, in your own words; if it didn't, or that part wasn't yours, say so plainly and stay with running the book |
| F2 | "booking travel" — your message, from the ad | none given | none | [grounded] | discovery | Strong evidence would be trips you have booked for other people at work. Answer slot: the ad's travel line makes a direct question likely. If you have booked travel for anyone at work, say what and for whom, in your own words; if you haven't, say so plainly and say how you would learn the company's way of booking |
| F3 | "preparing documents in Word and Excel" — your message, from the ad | "I'm good with Word" — your message | low | [inferred] | discovery | "Good with" is a self-rating, and the ad asks for documents, so what you made is the bridge. Answer slot: if you prepared documents in Word at the clinic or anywhere else, say which ones, in your own words; if your Word use has been more everyday than that, say so plainly |
| F4 | "preparing documents in Word and Excel" — your message, from the ad | "okay with Excel" — your message | low | [inferred] | discovery | Keep your own word, "okay", and don't upgrade it under pressure. Answer slot: if you've used Excel for anything specific, say what, in your own words; if your use has been light, say so plainly, then say what you'd learn first, as a plan and not as a past |
| F5 | "processing supplier invoices" — your message, from the ad | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier ones. Those are usually different sides of the job: one collects money owed, the other checks and pays bills that come in. The words stay at the quote's scope: "At the clinic I chased unpaid invoices." Answer slot: if your invoice work at the clinic included other tasks besides chasing, say which, in your own words; if it didn't, say so plainly and stay with the chasing |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | discovery | Strong evidence would be work you've done from home, or work run mostly by email, phone or video. Answer slot: if you have worked remotely, say how, in your own words; if you haven't, say so plainly and say how you'd organise your working day |

## Persona table

Loop source: the invite says one 30-minute video call with the office manager. So this pack prepares for one session. No values round is named, so there is no values cheat sheet.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "What would you do if…" problems about diaries, travel, invoices | High. An office manager hiring an assistant is buying someone who can handle the day-to-day, and the quickest test in 30 minutes is a live scenario | Clarify first, then say your steps in order: check, decide, tell people, confirm in writing |
| Skeptic | Quiet questions on the duties your background doesn't show: invoices, travel, Excel | High. F2, F4 and F5 are the visible gaps, and a hiring manager will want to de-risk them | Rehearse B1 until it's boring; hold to what you actually did; give a plan to learn, said as a plan |
| Conversational | Friendly opener, "tell me about yourself", "why remote?" | Medium. A short video call almost always opens this way, and it is still scored | A 90-second background arc built only from your own sentences (C1) |
| Data-Driven Prober | "How exactly did you keep the book running?" | Medium. Your background has two concrete claims, F1 and F5, and the follow-up on them comes naturally | Know what you can say about each, and say plainly what you don't know |
| Pressure | Time-boxed "why you?", a push on Excel | Low. 30 minutes leaves little room for stress tactics, but one pointed question is common | Pause, restate, hold to your own words, concede only what is real |
| Values / Behavioural | "Tell me about a time…" | Low. No values round is named, but one behavioural question is common | Pick a real story; if none comes to mind, say so and give the nearest one |
| Peer Evaluator | How you'd work with others in a remote team | Low. The interviewer is a manager, not a peer, but remote teamwork will come up | Talk about what you'd give the team, not only what you'd need |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people you support both want the same 10am slot tomorrow, and one of them is travelling. How do you handle it?" | CASE | [generic] | Structure it: find out what each meeting is for and how urgent it is; check whether either can move or join by video; ask the person who sets priorities if it's unclear; confirm the new times in writing and update both calendars. The question needs no claim about your past, so the guidance makes none | Tests F1's requirement live; CASE because it scores how you reason, not what you've done |
| A2 | "You need to book a two-day trip for a manager on a tight budget. Talk me through it." | CASE | [generic] | Clarify first: dates, where, budget, any preferences or policy. Then compare options, check with the manager before paying, keep confirmations in one place, and put the trip in their calendar. Say each step out loud | F2's requirement with no evidence behind it, so a live problem is the fairest place to show you can think it through; CASE delivery |
| A3 | "A supplier invoice arrives and the amount doesn't match what was agreed. What do you do?" | CASE | [generic] | Don't pay or approve it yet; check it against whatever was agreed, such as an order or quote; ask whoever approved the purchase; contact the supplier politely if it's their error; note what happened. The question needs no claim about your past | F5's requirement, asked as a decision rather than a record; `generic` because it is a pattern for the problem, not this employer's process |
| A4 | "I need a tidy one-page summary from a messy spreadsheet by end of day. How do you approach it?" | CASE | [generic] | Ask what the summary is for and who reads it; clean or sort only what's needed; check your figures once before sending; say what you'd ask for help with if you got stuck. Don't claim Excel features you haven't used | F4's requirement tested live; CASE because it scores approach, and an honest approach scores well even at an "okay" level |
| A5 | "It's your first week working remotely and you're unsure how to do a task. What do you do?" | CASE | [generic] | Try the obvious sources first, such as notes or past examples; then ask a clear, short question with what you've already tried; write down the answer so you don't ask twice | F6's requirement; remote roles care a lot about asking well, and this is the usual way they test it |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you processed supplier invoices before?" | JD | [grounded] "chased unpaid invoices" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "At the clinic I chased unpaid invoices." Answer slot: if your invoice work there included other tasks besides chasing, say which, in your own words; if it didn't, say so plainly and stay with the chasing. A limit is not a confession. Then a plan, said as a plan: how you'd learn their invoice process in your first weeks. Follow-up 1, "So that's a no?": stay calm, give the same honest answer again, and don't add anything to make it sound bigger. Follow-up 2, "Why should I trust you with it?": go back to what you did and the plan; concede the real gap once, clearly | F5 is the duty your background most visibly doesn't reach, so this objection will come in some form; JD because it scores a listed duty. A calm, exact answer here changes the interview |
| B2 | "I don't see travel booking in your background. How would you handle that part?" | JD | [grounded] | Answer slot: if you have booked travel for anyone at work, say what and for whom, in your own words; if you haven't, say so plainly. Then walk through how you'd do it, as in A2, and how you'd learn the company's preferences | F2 has no evidence either way, so the honest answer needs to be ready before the question arrives; JD because it scores a listed duty |
| B3 | "How strong is your Excel, honestly?" | JD | [inferred] "okay with Excel" | Use your own word: "I'm okay with Excel." Answer slot: if you've used it for something specific, say what, in your own words; if your use has been light, say so plainly. Then name what you'd learn first, as a plan. Never upgrade "okay" to "good" because the question feels like a test | F4 is a self-rating the interviewer will want to size; JD because the ad lists Excel documents |
| B4 | "Why move from reception into an admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" | Your material doesn't give your reason, so give your real one, in your own words. Pick it with care: it should be about what you want to do more of, not what you're leaving. If you aren't sure how to put it, say what you enjoyed most at the clinic and why this role has more of it | F1 places you in a receptionist role, so "why the move" is a natural probe; EXP because it tests motivation against your history |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" "okay with Excel" | A 90-second arc using only these beats: two years as a receptionist at a physiotherapy clinic; ran the appointment book for four physios; chased unpaid invoices; good with Word, okay with Excel. Then why this role, in your own words. Answer slot: if you want to say what you enjoyed or did well there, use something true from your own memory, in your own words | Almost every short call opens here, and it sets the tone; EXP because it scores how clearly you tell your own history (F1, F3, F4, F5) |
| C2 | "What draws you to a remote role?" | JD | [grounded] | Your real reasons, in your own words. Keep them about the work: focus, being organised, managing your own day. Answer slot: if you have worked remotely before, say how; if you haven't, say so plainly and say how you'd set up your day | F6 has no evidence yet, so a friendly question here is really a soft check of it; JD because the title names the remote setup |
| C3 | "What did a normal day at the clinic look like?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" "chased unpaid invoices" | The beats you stated: the appointment book for four physios, and chasing unpaid invoices. Fill the day in from your own memory, in your own words, and keep it to what you actually did | A casual question that is still scored on F1 and F5; EXP because it checks your experience in a relaxed register |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Four physios' appointments: how did you keep the book running?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" | Start from the quote: you ran the appointment book for four physios. Answer slot: if you had a routine or tool for it, describe it in your own words; if you didn't have a set method, say so plainly and describe how you ran it day to day | F1 is your closest match to calendar work, so it's where the detail will be asked for; EXP because it tests what was actually yours |
| D2 | "When you chased unpaid invoices, how did you go about it?" | EXP | [grounded] "chased unpaid invoices" | Start from the quote. Answer slot: if you had a way of doing it, such as calls, emails or a list, describe it in your own words; if it was case by case, say so plainly. Don't add numbers or results you can't stand behind | F5's evidence, probed for detail; EXP because it tests the claim you made |
| D3 | "What kind of documents have you made in Word?" | JD | [inferred] "I'm good with Word" | Answer slot: if you prepared documents at the clinic or elsewhere, name the kinds, in your own words; if your use has been more everyday, say so plainly and say what you're comfortable doing | F3 is a self-rating; the ad asks for documents, so the prober will ask what you made; JD because it scores a listed duty |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty seconds: why you over someone who's already done office admin?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" "chased unpaid invoices" | Pause, then hold to what you did: two years as a receptionist, running the appointment book for four physios, chasing unpaid invoices. Add why you want this work, in your own words. If pushed, don't stretch your job title; stay calm and return to what you did and why you want this work | Tests composure on F1 and F5 in a time box; JD because it scores fit for the listed job |
| E2 | "You said you're only okay with Excel. Isn't that a problem for this job?" | JD | [inferred] "okay with Excel" | Hold: "I'm okay with Excel." Don't backtrack and don't inflate. Concede the specific limit, then give your plan to improve, said as a plan. Through two follow-ups, return to the same answer | F4 is the easiest gap for a pushy interviewer to press; JD because the ad lists Excel documents |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put a patient's or customer's needs ahead of a rule or routine." | VAL | [generic] | Pick a real time: it needs a person, the routine you bent or worked around, and how it turned out. If no such time comes to mind, say so plainly, then give the nearest thing your work at the clinic does carry, or how you would handle it | A common behavioural opener; the theme comes from the standard customer-first prompt, not from this company's values, which weren't available |
| V2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Pick a real time: who, what you had to say, how you said it, and where things stood after. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | Assistants often have to flag clashes or mistakes upward; VAL because it scores how you behave, through a story |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "If you and another assistant both need the manager's time on the same day, how do you work it out?" | CASE | [generic] | Talk to the other assistant first; agree what's most urgent; go to the manager together if you can't agree; keep it friendly. No claim about your past is needed | Tests how you'd share with equals; CASE because it's a live problem |
| P2 | "What would you need from the team in your first month working remotely?" | CASE | [generic] | Name a few practical things, such as who to ask, where files live and how they like updates; then say what you'd give back, such as quick replies and clear notes | F6's requirement from the team's side; CASE because it asks for a plan |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" (F1) | A1, D1, C3, E1 |
| "booking travel" (F2) | A2, B2 |
| "preparing documents in Word and Excel" (F3, F4) | D3, A4, B3, E2 |
| "processing supplier invoices" (F5) | B1, A3, D2 |
| "Remote Administrative Assistant" (F6) | A5, C2, P2 |
| Company knowledge (CO) | none: research could not run, so a company question would have been invented |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical week look like in this role?" | Shows real interest and tells you which duties matter most |
| "Whose calendars would I be managing, and how do they like changes handled?" | Links directly to your appointment-book work (F1) and shows you think about the people, not just the diary |
| "Which system do you use for supplier invoices, and how would I learn it?" | Shows you know it's a gap and plan to close it (F5) |
| "What would good look like after three months?" | Shows you care about being useful, and gives you a target |
| "How does the team keep in touch day to day when everyone's remote?" | Shows you've thought about how remote work actually runs (F6) |
| "What are the next steps after this call?" | Lets you plan your preparation for whatever comes next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices, or handled accounts payable | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The pack's observation: the material says chasing unpaid invoices, not processing supplier ones. B1's slot stays inside your invoice work at the clinic |
| Managed calendars or diaries for managers | Inflated form of F1 | F1's quote at its own scope: "ran the appointment book for four physios". The pack's observation: the material says an appointment book, not managers' calendars |
| Worked as an administrator or office assistant | Inflated form of F1 | F1's quote: "two years as a receptionist at a physiotherapy clinic" |
| Strong or advanced Excel | A claim your own quote contradicts, F4 | "okay with Excel" |

## Sources

- **Provided:** the invite, as pasted in your message; your message's description of the ad's duties and of your background.
- **Searches sent:** "Brennock Facilities Ltd company values" — refused. "Brennock Facilities Ltd interview process administrative assistant" — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Search refused; would have decided whether a values cheat sheet and value-themed VAL questions belong in the pack |
| 2. interview process, admin roles | unavailable | Search refused; would have confirmed the round's format and could have reweighted personas |
| 3. strategy / recent news | unavailable | Not sent once searches were refused; would have added a CO question |
| 4. interviewer name | n/a | No name was given, only "office manager", so there was no query to form |
| 5. representative Remote Administrative Assistant JD | skipped | The ad's duties as given in your message set the fit snapshot rows and JD questions |

## Upgrade menu

- The full ad text → F1 to F5 quote the ad's own words rather than your summary of them, and any requirement your summary left out gets a row and a question
- The office manager's name → a short read of their public professional background and a reverse question tied to it
- Permission to search → company values, interview format and recent news, which could add a values cheat sheet and a company question
- Your answers to the slots in F2 (travel), F3 and F4 (Word and Excel) and F5 (invoices) → those rows move from guesswork to grounded stories, and B1, B2, B3 and D3 get story-mapped guidance
- Your CV → more of your experience in the fit snapshot, and fewer scaffolds
- How much time you have to prepare → a prioritised prep schedule
- A tuesday-dossier.md from an earlier session → verified evidence and agreed limits to build on
