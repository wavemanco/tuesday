Reading the prep-skill guidance done; now running a quick company lookup, then I'll build your pack.
Before the prep, a few things in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed. It asks you to "reply with a photo of your passport and your bank details before the interview". And it describes a cheque where "you deposit the cheque and send the balance on to the vendor". Asking for a fee, ID and bank details before any offer, and asking you to deposit a cheque and forward part of it, is a known scam pattern. These requests are very likely a scam. Don't pay, deposit a cheque, or send your passport or bank details until you've checked the invite with the employer. Use contact details you find yourself, such as a phone number from the company's own website, and not the email address or any other contact in the invite. A real employer won't charge you to interview. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you'd like the invite's requests weighed in more detail, job-underwriter can check it as a separate request.

I've saved your prep pack as `/var/tmp/tuesday-measure/1a6/runs/opus/alone/part-5/rooms/case-12-denied-cde80041/brennock-facilities_remote-administrative-assistant_interview_pack.md`. I built it for the 30-minute video call with the office manager, treating it as a hiring-manager round, using the duties and background from your message. My web searches for the company were refused, so nothing in the pack comes from company research.

**What to expect:**
- Most questions will be practical "what would you do if…" problems on calendars, travel, Word/Excel and invoices (A1–A5).
- Expect gentle probing on the gaps (B1–B4).
- The call will probably open with "tell me about yourself" (C1).

**The most important thing to prepare is B1, on supplier invoices.** Chasing unpaid invoices is money coming *in* to the clinic. Supplier invoices are money going *out*. Say that honestly in your own words, then explain how you'd learn their process.

I can play the Skeptic on B1 for a live practice round if you'd like.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to use in later sessions.
If you'd like the pack as a Word document, I can convert it.

Could you paste the full ad text and your CV? That would let me tie more answers to your actual experience. The pack works without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack — Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager (no name given). Treated as a hiring-manager round.
**Built from:** the duties and background in your message. No CV or full ad text was supplied.

---

## How to use this pack

- **Personas** = how a question is asked (the interviewer's style). **Types** = what the answer is scored on.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Answer slot** = the honest form where your material doesn't say something yet. If it applies to you, say how in your own words. If it doesn't, say so plainly and go back to what you did do.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values they care about |
| EXP | Whether your experience holds up under questions, and what was actually yours |
| JD | Whether you can do the listed duties, including the gaps |
| CO | How well you know the company and its situation |
| CASE | How you structure a live problem from the job |

Provenance labels: `[grounded]` = rests on your own words or the ad as you relayed it. `[inferred]` = this pack's own derivation. `[generic]` = a standard pattern for this kind of role, not specific to this employer.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as relayed in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | An appointment book for four physios is close to managing calendars, and your words stay at their own scope: "I ran the appointment book for four physios." Answer slot: the calendar duty makes a probe on clashes, cancellations or rescheduling likely. If you handled those, say how, in your own words. If that wasn't part of it, say so plainly and stay with the book you ran |
| F2 | "booking travel" — the ad, as relayed in your message | none given | none | [grounded] | discovery | Your material doesn't show travel booking. Answer slot: if you have booked travel for someone, say what and how, in your own words. If you haven't, say so plainly and walk through how you would handle a first booking (A2) |
| F3 | "preparing documents in Word" — the ad, as relayed in your message | "I'm good with Word" — your message | medium | [grounded] | none | No gap, but it's a self-rating with no examples behind it yet, so expect a probe. Lead with your own words: "I'm good with Word." Answer slot: if you have produced documents in Word (letters, forms, notices), name them. If you can't think of specific ones, say so plainly and stay with what you can do |
| F4 | "preparing documents in ... Excel" — the ad, as relayed in your message | "okay with Excel" — your message | low | [grounded] | discovery | "Okay" is your word, so keep it. Answer slot: say which things you have actually done in Excel. If it's been basic, say so plainly, then say what you would learn first, as a plan. Never name a function you haven't used |
| F5 | "processing supplier invoices" — the ad, as relayed in your message | "chased unpaid invoices" — your message | low | [inferred] | transferability | Chasing unpaid invoices is about money owed *to* the clinic. Supplier invoices are money the company owes *out*. That's the other side of the transaction, so the bridge can't stretch far. Words: "I chased unpaid invoices." Answer slot: the invoice duty makes a probe on checking, recording or approving invoices likely. If any of that was yours at the clinic, say what, in your own words. If none was, say so plainly and stay with the chasing you did |
| F6 | "Remote Administrative Assistant" — the job title in the invite | none given | none | [grounded] | discovery | Your material doesn't show remote or solo working. Answer slot: if you have worked on your own or from home, say how you organised it. If you haven't, say so plainly and describe how you would structure a remote day (A5) |

---

## Persona table

The session is set by your message: one 30-minute video call with the office manager. The weights below are a judgement, so adjust them if you know more.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "What would you do if…" problems taken from the duties | High. An office manager is probably the person you'd report to, and managers test whether you can do the actual tasks | Clarify, then prioritise, then act, then confirm in writing. Think aloud |
| Skeptic | Quiet probing of F2, F4 and F5 | High. The gaps sit exactly on listed duties | Rehearse B1 until it's boring. Hold your own words and give a learning plan, not a bluff |
| Conversational | Friendly opener: "tell me about yourself" | Medium. A 30-minute call usually opens this way, and it's still scored | A ready 90-second version built only from your quoted lines |
| Data-Driven Prober | "Walk me through how the appointment book worked" | Low to medium. There are few numbers to probe, but the four physios will draw questions | Know what you can and can't say about how things were done. Say plainly when something wasn't yours |
| Pressure | Time-boxed "why you?" | Low. Unusual for this level, but cheap to rehearse | Pause, restate, anchor in what you did. Hold through two follow-ups |
| Values / Behavioural | "Tell me about a time…" | Low. No values round is indicated, but one or two are common | Pick real moments. If nothing fits, say so and give the nearest real example |

---

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three people want the same slot in your manager's diary. What do you do?" | CASE | [generic] | Clarify whose calendar it is and what their priorities are. Check urgency with each requester. Hold the slot tentatively, then confirm with the calendar owner. Offer alternatives to the others and confirm everything in writing. This question makes no claim about your past | Tests F1's requirement live. CASE because it's a decision, not a record |
| A2 | "Book a two-day trip to a client site for a colleague. What do you need to know first?" | CASE | [generic] | Clarify dates, purpose, budget or travel policy, the traveller's preferences, and who approves. Then compare options, book, send one itinerary with confirmations, and keep the receipts for expenses. Say it as a plan | F2 has no evidence, so this lets you show method instead. CASE because it's a live problem |
| A3 | "A supplier invoice arrives that doesn't match what was ordered. What do you do?" | CASE | [generic] | Don't process it. Check it against the order and the delivery note. Note the difference, query the supplier in writing, flag it to whoever approves, and record what's pending. This shows care without any claim about your past | F5's requirement asked as a live decision, so you can be strong here even with thin evidence |
| A4 | "Your manager needs a two-page letter and a simple spreadsheet by end of day. Talk me through it." | CASE | [generic] | Clarify the audience, deadline and format. Draft the Word document, then build the sheet. Check the figures and formatting, then send early with a short note. Mention only Excel tasks you can actually do (see F4) | Covers F3 and F4 together. CASE delivery, JD content |
| A5 | "Working remotely, how would you organise your first week?" | CASE | [generic] | Learn whose calendars and which systems you'll handle. Agree check-in times. Keep a running task list, confirm priorities daily, and ask questions early. Say it as a plan, not as past practice | F6's requirement. CASE because it's about how you would work |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role processes supplier invoices. What experience do you have with that?" | JD | [inferred] "chased unpaid invoices" | **Highest-ROI rehearsal in this pack.** Say the limit before they find it. What you did: "I chased unpaid invoices." Be clear that this was money owed to the clinic. Answer slot: if any checking, logging or matching of invoices was yours, say what, in your own words. If none was, say so plainly. Then give your plan for learning their process, as a plan (A3 shows your method). If they push twice, go back to the chasing and don't add to it | F5 is the widest gap on a listed duty, so this objection will come up in some form. JD because it scores the stated requirement |
| B2 | "How comfortable are you in Excel, really?" | JD | [grounded] "okay with Excel" | Keep your own word, "okay." Answer slot: name the things you have actually done in Excel. If it's basic, say so plainly. Then say what you would learn first and how. Don't upgrade "okay" under pressure | F4 is a listed duty with a modest self-rating. Overclaiming here fails the first follow-up |
| B3 | "I don't see travel booking in your background. How would you handle that part of the role?" | JD | [grounded] | Answer slot: if you have booked travel for anyone, say what and how. If not, say so plainly and use A2's method. Calm candour beats bluffing | F2 is silent, so expect the question. JD because it's a listed duty |
| B4 | "This is a remote role. How do I know you'll work well unsupervised?" | JD | [grounded] | Answer slot: if you have worked alone or from home, say how you kept yourself organised. If not, say so plainly and give A5's plan. Don't claim habits you haven't practised | F6, driven by the job title |

### C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | 90 seconds in three beats, each one a line you gave: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, and chasing unpaid invoices. Close with why this role, in your own words (C2) | The near-certain opener. Draws on F1 and F5 at their own scope |
| C2 | "Why this role, and why remote admin?" | EXP | [generic] | Answer slot: give your actual reasons in your own words. Link them to the duties in the ad. Don't invent a career plan you don't hold | Motivation consistency is scored even in a friendly register |
| C3 | "What did a typical day on reception look like?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot: describe what you actually did on a normal day, in your own words. Mention the appointment book and invoice chasing only as you stated them. Add nothing you didn't do | Casual question, scored for clear communication |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Start from the quote. Answer slot: if you used a system, handled clashes or managed cancellations, say how, in your own words. If something wasn't yours (for example, the physios set their own hours), say so plainly | F1 is your strongest evidence for the calendar duty, so it will be probed |
| D2 | "Tell me how chasing unpaid invoices worked at the clinic." | EXP | [inferred] "chased unpaid invoices" | Start from the quote. Answer slot: if you tracked who owed what or decided when to follow up, say how. If someone else decided, or there was no system, say so plainly | F5 is thin, and this is the probe that tests what was yours |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with office admin experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" | Pause, then give two lines you stated: two years on reception at a physiotherapy clinic, and running the appointment book for four physios. Add one reason you want the role, in your own words. Don't claim office admin experience you don't have | Tests composure. The hold rests on your quoted lines |
| E2 | "Chasing unpaid invoices isn't the same as supplier invoices. Isn't this a stretch?" | JD | [inferred] "chased unpaid invoices" | Hold, then concede. Concede what's true: it's the other side of the process. Hold what you did: "I chased unpaid invoices." Then give your learning plan, as a plan. Don't fold into apology, and don't inflate | F5 delivered with pressure. Rehearse it with B1 |

### F — Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Pick a real moment with a named person, the choice you made, and what happened. If no such time comes to mind, say so plainly, then give the nearest real example or say how you would handle it | Common behavioural stem. No published values were in hand |
| F-2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Pick a real moment. It needs a stake, what you said, and how the relationship stood afterwards. If none comes to mind, say so plainly and give the nearest real example | Tests honesty and tact. Generic stem |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Managing calendars (F1) | A1, D1, C1 |
| Booking travel (F2) | A2, B3 |
| Word documents (F3) | A4 |
| Excel documents (F4) | A4, B2 |
| Supplier invoices (F5) | A3, B1, E2, D2 |
| Remote working (F6) | A5, B4 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "How is a typical week split between calendars, travel and invoices?" | Shows you read the duties, and tells you which to emphasise next |
| "Whose calendars would I be looking after, and roughly how many people?" | Concrete and practical, and it ties to F1 |
| "What system do you use for invoices, and what does the approval step look like?" | Shows you take the invoice side seriously, the area where you're thinnest (F5) |
| "How does the team stay in touch day to day when everyone's remote?" | Shows you're thinking about how remote work actually functions |
| "What would someone great in this role have done by the end of the first three months?" | Gives you the real success criteria to answer against |
| "What are the next steps after this call?" | Lets you plan your follow-up and your prep for any next round |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has processed supplier invoices / accounts-payable experience | Inflated form of F5 (other side of the transaction) | F5's quote at its own scope: "I chased unpaid invoices." The limit is this pack's observation: your material shows chasing money owed in, not processing invoices owed out. B1's slot stays inside the chasing |
| Has managed executives' or a team's calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." D1's slot stays inside the book |
| Strong or advanced Excel | Contradicted by your own words, F4 | "okay with Excel" — nothing more |

---

## Sources

- **Provided:** your message. It contained the duties as relayed from the ad, your background, and the invite text, from which only the job title, the company name and the round format were used here.
- **Searches sent:** "Brennock Facilities Ltd values" — refused. "Brennock Facilities interview process administrative assistant" — refused. "Brennock Facilities Ltd news" — refused.
- **Fetches:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Refused. It would have themed the VAL questions with published values instead of generic stems |
| 2. interview process, admin roles | unavailable | Refused. It could have confirmed what the video call covers. Your message's description of the call set the persona weights instead |
| 3. strategy / recent news | unavailable | Refused. It would have supplied a CO question. There is none in this pack |
| 4. interviewer name | n/a | No name was given, so the interviewer read is absent |
| 5. representative JD | skipped | The duties in your message fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Full ad text → requirements quoted from the posting itself, plus questions for any duties or skills your summary left out
- Your CV → more of your own written lines in the evidence column, so more answers can be mapped to specific experience instead of answer slots
- The office manager's name → an interviewer read and a tailored reverse question
- Your answers on travel booking, what you've done in Excel, and any invoice checking or logging at the clinic → F2, F4 and F5 move from answer slots to mapped guidance in A2, B1, B2, B3 and D2
- How much prep time you have → a prioritised schedule for it
- Allowing web search (refused this time) → company values and interview process researched. A deeper pass is also available on request: up to 6 more searches and 2 more fetches, several more minutes
- A tuesday-dossier.md → objections and a prohibited-claims list drawn from an evidence review, instead of inferred here
