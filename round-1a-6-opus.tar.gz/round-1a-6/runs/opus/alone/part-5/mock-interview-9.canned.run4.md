Grace, I'm putting your prep pack together now. First I'm running a few quick searches on the district, the school and the principal. I won't use your SSN for anything; you don't need it to prepare.
Grace, your prep pack is ready. I left your SSN and educator ID number out of it. Neither is needed to prepare, and HR will ask for your ID number through official channels when they need it.

Your license meets the posting's requirement as you've described it: an Illinois PEL with an Elementary Education (grades 1–6) endorsement, active through June 30, 2029, and fourth grade falls inside that range. Still, check its current status yourself and bring your license record.

**What the research found** (the details and sources are in the pack):
- **The district's three published beliefs:** Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test.
- **The panel:** the district's hiring page says it covers reading instruction, classroom routines and how you work with families.
- **The principal:** Dolores Vantongeren was a reading specialist for nine years and gave a 2025 talk on weekly reading conferences in grades 3 to 5. Expect detailed questions on reading, which is your strongest area.
- **The district's literacy plan:** a new grades 3–5 reading curriculum starts in fall 2027. Your 2024 experience leading your grade level's move to a new reading curriculum fits that directly (question B1).

**What to practice most:** question A1, "You've never taught fourth grade. Why should we hire you over someone who has?" Admit the gap in your own words first. Then talk about your six years teaching third grade, the grade their students come from. Finish with a concrete plan for learning fourth grade.

**Two places to stay careful:**
- You wrote that you led your grade level's curriculum move and that you've never been a team lead. Say both together; don't let the first turn into a team-lead title.
- A weekly email to families isn't the same as the district's belief that each teacher talks with every family each term. Have an honest answer ready for that one.

Halvering's own job posting wasn't included, so six rows in the pack use a typical fourth-grade posting instead and are marked [inferred].

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/alone/part-5/rooms/case-9-canned-1e7c5532:
- Orrinsford_fourth-grade-teacher_interview_pack.md

If you'd like to practice, I can play the skeptical interviewer on A1 and push back with follow-ups.
I can also save a tuesday-dossier.md listing the gaps this prep exposed, for you to bring to later sessions.
If you want the pack as a Word document, I can convert it.

Do you have the actual Halvering posting? If you paste it, I'll check the six [inferred] rows against it and adjust the questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Format:** a 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren (your likely future supervisor) and two members of the fourth-grade team (your likely peers)

---

## How to use this pack

Each question has two labels:

- **Persona** is how the question gets asked: who is asking and in what style.
- **Type** is what the question is scoring.

| Type | What it's really testing |
|---|---|
| VAL | Whether your past behavior shows the district's *published* beliefs, not general virtue |
| EXP | Whether your experience holds up under follow-up questions, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district's current direction and can think at its level |
| CASE | How you structure and reason through a live classroom or team problem |

Every Provenance cell starts with one label:

- **[grounded]** means it traces to something you wrote, the invite, or a source listed in Sources.
- **[inferred]** means it comes from a representative posting or is a reasoned step from a grounded fact.
- **[generic]** means it's a common pattern for this kind of role, with no claim about Orrinsford.

**Answer slots** are instructions for what to say in the interview, not questions for you to answer here. Each one has two honest branches.

The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

The Halvering posting wasn't supplied. Rows F3 to F7 and F10 quote a representative fourth-grade posting instead, so they're marked [inferred].

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the district's invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Met as you stated it: an Illinois PEL with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. If asked, say it in those terms. Fourth grade falls inside the grades 1–6 range on your own line. Nobody has inspected the license here, and confirming its current status is your job. Bring your license record. |
| F2 | "Fourth Grade Teacher position" — the district's invite | "I've never taught fourth grade and I've never been a team lead." — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | This is the adjacent grade, not the same one, and you've said so yourself. Words: "I've never taught fourth grade." Then what you have, kept at its own scope: six years teaching third grade at a public elementary school in Joliet. Then how you would get ready for fourth grade, said as a plan and never as something you've already done. Don't argue that third and fourth grade are the same job. |
| F3 | "experience in grades 3 to 5 preferred" — representative JD, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade falls inside the 3-to-5 range this typical posting prefers. Six years is your own number. Lead with it plainly. |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative JD, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material says you taught third grade, not which subjects you planned and taught. Answer slot: if you taught all five subjects, say so, and name the one you're strongest in and the one you'd study most before starting. If your school split subjects between teachers, say plainly which ones were yours and how you'd pick up the others. |
| F5 | "differentiate instruction using assessment data" — representative JD, K12 Jobs Board | none given | none | [inferred] | discovery | Answer slot: if you've used assessment results to group students or change a lesson, say what the assessment was and what you changed, in your own words. If you haven't, say so plainly and say how you would. |
| F6 | "keep clear classroom routines" — representative JD, K12 Jobs Board | none given | none | [inferred] | discovery | Answer slot: if there's a routine you run now, describe it, how you taught it to students, and what you do when it breaks down. If nothing specific comes to mind, say so plainly and describe how you'd set up routines in a new fourth-grade room. |
| F7 | "communicate regularly with families" — representative JD, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | The quote meets the requirement: a weekly email to families. Expect a question about what goes in it. Bring one you've sent, with student names removed. |
| F8 | "each teacher speaks with every family each term" — district Mission and Beliefs, Families Are Partners | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | An email isn't a conversation, so keep to what you wrote: "I write a weekly email to families." Answer slot: this belief is about speaking with every family each term, so expect a question about conversations. If you've held conferences or calls with families, say how often and with whom, in your own words. If you haven't reached every family that way, say so plainly and say how you'd reach all of them each term at Halvering. |
| F9 | "no student leaves third grade without a reading plan" — district Mission and Beliefs, Every Child a Reader | "Six years teaching third grade at a public elementary school in Joliet."; "I've run the after-school reading club for the last two years." — your CV | low | [inferred] | discovery | Your material shows reading work and third-grade teaching. It doesn't show whether you've written individual reading plans. Answer slot: this belief is tied to the grade you've taught, so expect it to come up. If you've written reading plans for students, say what one contained, in your own words. If you haven't, say so plainly and say how you'd use the plans your fourth graders arrive with. |
| F10 | "work with the grade-level team" — representative JD, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never taught fourth grade and I've never been a team lead." — your CV | medium | [inferred] | none | The quote meets the requirement: you led your grade level's move to a new reading curriculum. Keep both sentences together, because neither cancels the other: "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Answer slot: the posting's team line makes a question about working with colleagues likely. If leading the move meant running meetings, sharing materials or helping colleagues with the new curriculum, say which of those, in your own words. If it didn't, say plainly what leading the move did involve. |

---

## Reading the interviewer

**Principal Dolores Vantongeren** (public professional footprint only, Sources S4):

- She has been principal of Halvering Elementary since 2022.
- Before that, she spent nine years as a reading specialist.
- In 2025 she gave a forum talk, *Small Groups, Big Readers*, on weekly reading conferences in grades 3 to 5.

What this means for you:

- **Expect reading to come up in depth.** A former reading specialist will probably follow up on how you teach reading, especially small groups and conferences. B2 and E1 rehearse this.
- **Reading is your strongest ground.** Two of your own sentences are about reading: "I led our grade level's move to a new reading curriculum in 2024" (F10) and "I've run the after-school reading club for the last two years." (F9). Describe what you did and let her draw her own conclusions.
- **Her talk gives you a reverse question.** R1 asks about her published topic. It shows you researched her, not just the school.

The two fourth-grade teachers aren't named, so there's nothing to read about them. Their panel role is covered by the Peer Evaluator persona below.

---

## Persona table

The district's hiring page describes one 45-minute panel with the principal and two grade-level teachers. It says panels ask about reading instruction, classroom routines and how you work with families (Sources S2). The weights below follow that panel, not a general pattern.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | "You've never taught fourth grade." Asked quietly, probably by the principal | Highest. Your biggest gap is the one you named yourself (F2), and in a single panel someone will raise it | Concede in your own words first, then the six years, then a plan. Rehearse A1 until it's boring |
| B. Case / Strategist | Live classroom problems: struggling readers, the first week, an upset parent, the 2027 curriculum | High. The principal has hired before, and the hiring page names reading, routines and families as panel topics | Clarify, set the goal, describe the approach, explain how you'd know it worked. Think out loud |
| C. Peer Evaluator | "What would you bring to our planning?" and questions about disagreement with colleagues | High. Two of the three panelists would be your teammates | Frame it both ways: what you bring them and what you'd need from them. Disagreement stories should show both spine and tact |
| D. Data-Driven Prober | Follow-ups on the curriculum move and the reading club: what exactly, who, how | Medium. These are your two most specific lines (F9, F10), so they'll attract follow-ups | Stay at the scope of your sentences. Where you don't know a detail, say so |
| E. Values / Behavioral | Questions themed on the district's three published beliefs | Medium. The beliefs are published as guiding every hire (S1), but the hiring page names no separate values round | One honest story per belief where you have one. Where you don't, say so and say how you'd handle it |
| F. Conversational | "Tell us about yourself" and "What are you looking forward to?" | Medium-low. These open and close most panels and still count | Prepare a 90-second arc built only from your own sentences |
| G. Pressure | Quick challenges on your email-versus-conversation habit and on how much of the curriculum move was yours | Low. Panels like this one are rarely adversarial, but one sharp follow-up is likely | Pause, restate the question, hold what your sentences carry through two follow-ups, then concede the real limit |

---

## Question banks

**Highest-value prep in this pack: A1.** It will be asked in some form. A calm answer that concedes first is the single thing most likely to change how this panel goes.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. Why should we hire you over someone who has?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "Six years teaching third grade at a public elementary school in Joliet." | **Concede first, in your own words:** "I've never taught fourth grade." Say the limit before they push on it. **Then the hold, only what your sentences carry:** six years teaching third grade at a public elementary school in Joliet, the grade your fourth graders come from. **Then a plan, said as a plan:** what you'd learn before the first day and who on the team you'd learn it from. **Follow-up 1** ("but fourth is different"): agree that it is, and return to the six years and the plan. **Follow-up 2** ("so you'd be learning on the job"): "For the grade, yes. Not for teaching." Never add experience you haven't described | F2 is the clearest gap, and you stated it yourself, so the panel can ask it directly. JD because it scores the role itself. This is the deepest rehearsal because a defensive answer here costs more than any other single answer |
| A2 | "Which part of teaching fourth grade would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Pick one real thing, name it plainly and give a plan. Answer slot: if a subject or area from F4 to F6 feels thinnest to you, name that one and say how you'd prepare. If nothing stands out, say so honestly and name the fourth-grade content you'd study first. Avoid humble-brags like "I care too much" | A standard Skeptic stem. F2 makes it pointed for you. JD because it tests self-assessment against the listed job |
| A3 | "You led your grade level's curriculum move, but you've never been a team lead. How should we read that?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade and I've never been a team lead." | Say both sentences and let them stand: "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Answer slot: if leading the move meant specific work with colleagues, say what it was, in your own words. If it didn't, say plainly what leading it involved. Don't turn the curriculum move into a team-lead title | F10 holds two sentences a reader might think conflict, so a careful panelist will ask. EXP because it tests what was yours |
| A4 | "Why Orrinsford, and why leave Joliet?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: give your actual reason for moving, in your own words, without criticizing your current school. For "why Orrinsford," name one published district belief that genuinely matches something you do (see E1 to E3), and say only what your sentences carry | A motivation check that comes up in every panel. EXP because your reason for leaving is part of your story |
| A5 | "Our belief is that each teacher speaks with every family each term. You write emails. How would that change here?" | VAL | [grounded] "I write a weekly email to families." | Start with what you do: "I write a weekly email to families." Answer slot: if you also hold conferences or calls, say which ones, in your own words. If you don't reach every family that way, say so plainly and give a concrete plan for reaching all of them each term | F8 is a gap on the kind of communication, not the amount, and the district publishes this belief. VAL because it scores Families Are Partners |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The district brings in a new grades 3–5 reading curriculum in fall 2027. You led a curriculum move before. What would you want our fourth-grade team doing this year to get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | **Structure:** what you'd ask first (what's known about the curriculum, the timeline, the training planned), the goal (a smooth first year for students), then two or three steps, then how you'd know it was working. **Your one beat:** you led your grade level's move to a new reading curriculum in 2024. Answer slot: if part of that move taught you something you'd repeat or avoid here, say what, in your own words. If not, keep the plan forward-looking. Offer ideas as a teammate, not as the person who'd run it | The district's 2026–2029 literacy plan schedules this curriculum (S3), and F10 is your closest experience. CO because it tests district knowledge. CASE delivery |
| B2 | "It's October and four of your students are reading well below grade level. What do you do in the next two weeks?" | CASE | [generic] | **Clarify:** what the data shows, and whether there's a reading plan from third grade. **Approach:** assess, group, plan small-group time, involve families, set a check-in date. **Measure:** what you'd look at in two weeks. Answer slot: if you've handled this before, say how, in your own words. If not, give the plan as a plan | A likely question from a former reading specialist, touching F5 and F9. CASE because it's a live problem with no assumption about your past |
| B3 | "Walk us through the first week of school in your fourth-grade room." | CASE | [generic] | Day by day: relationships, routines taught and practiced, a first look at where students are, and first contact with families. Answer slot: if you have routines you already use, name one and say how you teach it. If not, describe the routines you'd set up | The hiring page names classroom routines as a panel topic (S2). F6 has no evidence yet. CASE because it's a plan for the role |
| B4 | "A parent emails, angry about a grade on a writing assignment. What do you do?" | CASE | [generic] | Acknowledge, move to a call or meeting, look at the work together, explain how the grade was reached, agree on a next step, follow up. This needs no claim about your past, so don't invent one | Families are a named panel topic and a district belief (F7, F8). CASE because it's a live problem |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We plan together as a team. What would you bring to our planning, and what would you need from us?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | **Bring:** six years of teaching third grade, which is where their students come from, and the experience of your grade level's curriculum move. **Need:** their fourth-grade units, pacing and anything that's grade-specific, asked for plainly, since you've never taught fourth grade. Two sides, both concrete | Teammates are working out what you'd add to their workload and what you'd contribute (F10). JD because it scores the team requirement |
| C2 | "Tell us about a time you disagreed with a colleague about teaching." | EXP | [generic] | Selection scaffold: pick a real disagreement where you said what you thought, listened, and the working relationship survived. Tell the outcome as it actually happened. If no such time comes to mind, say so plainly, then describe how you'd raise a disagreement with a new teammate | A standard peer probe on how you disagree. EXP because it asks for a real instance |
| C3 | "Say one of us wants to keep a unit the old way and you think it should change. What happens?" | CASE | [generic] | Ask why they'd keep it, look at student work together, suggest a small trial and agree on what you'd both look at. Remember you're new to fourth grade, so lead with curiosity | Teammates want to see where you'd draw lines with equals. CASE because it's a live scenario |
| C4 | "Would you want to help with after-school or family reading events here?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Yes if it's true, with your sentence as the reason: you've run the after-school reading club for the last two years. Answer slot: if asked what the club does, describe it in your own words. Offer, but don't overcommit in your first year | The district's literacy plan adds a family reading night at every school each term (S3), and F9 holds your reading-club line. EXP because it touches your experience |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through how you led your grade level's move to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Beats your sentence states: your grade level, a new reading curriculum, 2024, led by you. Answer slot: the posting's team line makes it likely they'll ask what you did with colleagues. If you ran meetings, shared materials or helped colleagues, say which and how, in your own words. If not, say plainly what leading the move involved. Don't claim you chose the curriculum unless you did | F10 is your most specific line and the one most likely to get follow-ups. EXP because it tests what was actually yours |
| D2 | "Tell us about the after-school reading club. What happens in a session?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Beats your sentence states: you've run it for the last two years. Answer slot: describe a typical session and who comes, in your own words. If you don't know a count, say so rather than guessing a number | F9's other quote, and the kind of specific line a careful panelist digs into. EXP because it asks for detail behind the sentence |
| D3 | "How do you decide a student needs something different from the rest of the class?" | JD | [inferred] | Answer slot: if you use particular assessments or observations, name them and say what you changed for one student, in your own words. If you don't have a set method, say so plainly and describe the one you'd use | F5 has no evidence yet. The representative posting lists differentiation by assessment data. JD because it scores that line |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader is one of our beliefs. Tell us about a time a student was struggling to read and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Selection scaffold: choose one real student (no names) where you noticed the struggle, did something specific and saw what happened, and tell the outcome honestly even if it was modest. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the reading club, F9) or how you'd handle it | Every Child a Reader is published (S1), and the principal's background is in reading. VAL because it scores that belief |
| E2 | "Families Are Partners. Tell us about a hard conversation with a family." | VAL | [grounded] | Selection scaffold: pick a real conversation where you listened, said something difficult and the relationship held. If no such time comes to mind, say so plainly, then describe how you'd approach one | A published belief (S1) and a named panel topic (S2). F8 shows it's your thinner side. VAL because it scores that belief |
| E3 | "Teach for Tomorrow, Not for the Test. Assessments inform teaching and never replace it. What does that look like in your classroom?" | VAL | [grounded] | Answer slot: if you've changed your teaching because of an assessment, give one example in your own words. If you haven't, say so and describe how you'd use assessments without teaching to them | A published belief (S1) that overlaps F5. VAL because it scores that belief, with JD content |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, tell us about yourself. How did you get here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc using only these lines: six years in third grade in Joliet, leading your grade level's curriculum move in 2024, two years running the reading club, a weekly email to families. Then one sentence on why fourth grade at Halvering, in your own words | The usual opener, and still scored. EXP because it previews your experience |
| F2 | "What are you most looking forward to about fourth grade?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Answer slot: say what genuinely appeals to you about fourth grade, in your own words. It's also a natural place to show enthusiasm about the grade change rather than apologize for it | Sounds casual but is still scored, and it's a gentler version of F2's gap. JD because it's about the role |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A weekly email is the easy option, isn't it? Our families want to talk to their teacher." | VAL | [grounded] "I write a weekly email to families." | **Pause, then hold:** you write a weekly email to families, and that's real, regular contact. **Concede the real limit:** an email isn't a conversation, and the district asks for conversations each term. **Then the plan.** Don't fold into apology, and don't claim calls you haven't described | F8 under pressure. VAL because it scores Families Are Partners. Hold-then-concede structure |
| G2 | "That curriculum move. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | **Hold:** "I led our grade level's move." **Answer slot:** say exactly which parts were yours and which were your colleagues' or the district's, in your own words. Concede anything that wasn't yours, plainly. Use "we" for the context and "I" for what you did | F10 is the line most likely to get an attribution challenge. EXP because it tests what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Illinois PEL with elementary endorsement | — none, because the license is stated as met and a panel rarely asks about it. Bring your license record anyway |
| F2 Fourth grade | A1, A2, F2 |
| F3 Grades 3 to 5 experience | A1, C1, F1 |
| F4 Teach all subjects | A2, B3 |
| F5 Differentiate using assessment data | B2, D3, E3 |
| F6 Classroom routines | B3 |
| F7 Communicate with families | A5, B4, G1 |
| F8 Speak with every family each term | A5, E2, G1 |
| F9 Reading plans | B2, E1, C4 |
| F10 Work with the grade-level team | A3, C1, C3, D1, G2, B1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | For Principal Vantongeren: "Your talk *Small Groups, Big Readers* covered weekly reading conferences in grades 3 to 5. How do fourth-grade teachers here run them?" | It's her own published topic. It shows you researched her, and it moves the conversation onto reading, your strongest ground |
| R2 | "How is the fourth-grade team getting ready for the new grades 3–5 reading curriculum in fall 2027?" | It shows you know the district's literacy plan, and it opens the door to your own curriculum-move experience without bragging |
| R3 | For the two teachers: "What could a new person on your team do in the first month that would genuinely help you?" | It shows you're thinking about their workload, not only your own needs |
| R4 | "What do students' reading plans from third grade look like when they reach fourth grade?" | It connects the district's Every Child a Reader belief to the grade you've taught |
| R5 | "How do teachers here reach every family each term: conferences, calls, the family reading nights?" | It takes Families Are Partners seriously and lets you learn what's expected before you're asked to do it |
| R6 | "What would a strong first year look like for whoever takes this role?" | It tells you what they'll judge you on, and it sounds confident rather than anxious |

---

## Prohibited claims

These are claims this pack won't help you make, with the reason and what to say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | "I've never taught fourth grade." No slot |
| Has been a team lead or grade-level lead | A negative you stated, F10 | "I've never been a team lead." No slot. Your curriculum-move sentence stays at its own scope |
| Chose or adopted the reading curriculum, or trained the staff on it | An inflated form of F10's quote | F10's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Your material describes the move, not the choice or any training. D1's slot stays inside the move |
| Speaks with every family each term | An inflated form of F8's quote | F8's quote at its own scope: "I write a weekly email to families." Your material describes an email, not conversations. A5's slot stays with what you do |
| Founded or created the reading club | An inflated form of F9's quote | "I've run the after-school reading club for the last two years." Your material says you ran it, not that you started it |

---

## Sources

- **Provided:** your interview invite and your resume. Your SSN and educator ID number were not used.
- **S1:** search "Orrinsford Community School District mission values" → orrinsfordschools.example/about/mission-and-beliefs, then fetched
- **S2:** search "Orrinsford Community School District teacher interview process" → orrinsfordschools.example/careers/how-we-hire-teachers
- **S3:** search "Halvering Elementary School Orrinsford news" → orrinsfordschools.example/news/board-adopts-literacy-plan
- **S4:** search "Dolores Vantongeren principal Halvering Elementary" → ilprincipalsforum.example/speakers/dolores-vantongeren
- **S5:** search "Fourth Grade Teacher job description Illinois elementary school district posting" → k12jobsboard.example/listings/fourth-grade-teacher, then fetched

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | Three published beliefs by name. These drive F8, F9 and the E bank. There's no values cheat sheet, because the hiring page names no values-style round |
| 2. District interview process, teachers | yes | One 45-minute panel, principal plus two grade-level teachers, with reading, routines and families named as topics. Persona weights follow this |
| 3. District strategy / recent news | yes | The 2026–2029 literacy plan: a new grades 3–5 curriculum in fall 2027 and family reading nights each term. Drives B1, C4 and R2 |
| 4. Dolores Vantongeren, Halvering | yes | Principal since 2022, previously a reading specialist, 2025 talk on reading conferences. Drives the interviewer read and R1 |
| 5. Representative Fourth Grade Teacher JD | yes | No Halvering posting was supplied. A representative posting supplies F3 to F7 and F10, all [inferred] |

---

## Upgrade menu

- **The actual Halvering job posting:** F3 to F7 and F10 become [grounded], and coverage gets checked against the real list.
- **The two fourth-grade teachers' names:** a short read on each from their public professional footprint, plus a tailored reverse question for each.
- **How much prep time you have before Thursday:** a prioritized prep schedule sized to it.
- **Your answers to the answer slots in F4, F5, F6, F8, F9 and F10:** those rows get your own words, and A2, B2, B3, D1, D3, E1 to E3 and G2 become story-mapped instead of scaffolds.
- **Your license record as the state shows it:** F1's confidence rises from medium to high.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It adds a district briefing, more of Principal Vantongeren's published talks, candidate reports of past Orrinsford panels, and recent district changes.
- **A tuesday-dossier.md from a job-underwriter evaluation:** a highest-value objection drawn from verified evidence, and a binding list of claims to avoid. This pack doesn't need one.
