Using Edit instead.
Before the prep, one thing about the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", and that "your offer and onboarding will be completed in this chat as well". A hiring process run entirely by chat is a known scam pattern. A chat on its own doesn't show who you're dealing with, and the message may not come from Lumenvale at all. Until you know, don't send money, ID documents or bank details through Telegram. Check the invite with Lumenvale directly, using contact details you find yourself on their website or the careers page you applied through, not anything the sender gives you. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite looked at more closely, job-underwriter can check it as a separate request.

I've built your prep pack: lumenvale_customer-support-specialist_interview_pack.md. I assumed the support team lead would be your manager, so it's set up as a hiring-manager round.

- **Your biggest gap:** you've never worked for a software company. That's the objection most likely to come up, so the pack gives it the most practice (A1). It also covers escalations, which nothing you've told me mentions yet.
- **Your strongest points:**
  - Three years in support, at around 60 calls and emails a day.
  - Freshdesk every day, which the ad's "or a similar ticketing tool" covers.
  - Training four new starters on refunds.
- **Text-chat format:** because the interview is by text, your typed answers will also count as evidence of clear writing. Several practice questions ask you to write a customer reply on the spot.
- **No company research:** the web searches were refused, so the questions about Lumenvale and its values are general ones. Before the interview, read Lumenvale's own website yourself.

If you'd like, I'll play the skeptical interviewer on A1 (the software-company question) in a live practice round.
I can also save a tuesday-dossier.md recording the gaps this prep found, for you to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Is the support team lead going to be your manager, or a colleague? The answer changes which interviewer styles the pack weights most heavily. Could you also paste the full job ad? The pack is currently built on your summary of it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

**Round:** interview with the support team lead, by text chat, as the invite in your message describes it. No name given.
**Relationship:** assumed to be your future manager (hiring-manager round), because a support team lead usually runs the team you would join. If that's wrong, the persona weights below change.

---

## How to use this pack

- **Personas** describe *how* a question gets asked: the style, the pressure, the register. **Types** describe *what* is being scored:
  - **VAL**: behaviour and values. Do your past actions show what they care about?
  - **EXP**: experience deep-dive. Do the things you said about your work hold up, and what was actually you?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Have you done your homework on Lumenvale?
  - **CASE**: live problem. How do you structure and reason through a situation from the actual job?
- **Provenance labels:** `[grounded]` traces to something you told me. `[inferred]` is a derivation, and the row names it. `[generic]` is a common pattern for this kind of role and makes no claim about Lumenvale.
- **The guidance is scaffolding, not a script.** Answer in your own words, and say only what you actually did.
- **A text-chat interview changes the delivery, not the content.** Your answers will be written, so each guidance cell works out to one to three short paragraphs. Your typing is also evidence for the "clear written communication" requirement (F3). Write as you would to a customer: short paragraphs, the answer first, then the detail. Don't send walls of text.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as given in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap. Nothing inspected stands behind it, though, so expect a probe. Lead with it in its own terms: "Three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day." Keep "around", and keep calls and emails together: the 60 covers both, not emails alone |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as given in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap: the ad's "or a similar" covers it. Name the tool plainly: "I use Freshdesk every day." Your material does not show Zendesk use, so don't say Zendesk |
| F3 | "clear written communication" — the job ad, as given in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering emails is not the same as showing that they were clear, so don't stretch this bridge. The derivation: your quote includes emails, and that is all it shows about writing. In a text-chat interview, each typed answer is a writing sample. Answer slot: if there's an email you wrote that you can describe (what the customer needed and how you put it), describe it in your own words. If none comes to mind, say so plainly and stay with the emails you answered each day |
| F4 | "confidence handling escalations" — the job ad, as given in your message | none given | none | [grounded] | discovery | Your material doesn't mention escalations either way. Strong evidence would be a customer whose issue went beyond the first answer: what you did, and how it ended. Answer slot: if you have handled an escalated or upset customer, or passed one on, say what happened and what part was yours, in your own words. If there was no such case, or it wasn't yours, say so plainly and say how you would handle one |
| F5 | Supporting customers of a software product (role-family; not in the ad as you gave it) | "I've never worked for a software company" — your message | none | [grounded] | capability | Wording can't close this gap, and you have said so yourself. Words: "I've never worked for a software company." Then say how you would learn the product, as a plan and never as something you've done. Add nothing to make the gap feel smaller |
| F6 | Explaining processes to colleagues (role-family; not in the ad as you gave it) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap. Keep it at its own scope: "Last year I trained four new starters on our refunds process." Four people, one process. Not a training programme, and not a team you led |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: 2+ years in customer support | A1, C1, D1, E1 |
| F2: Zendesk or a similar ticketing tool | A3, C3 |
| F3: clear written communication | B1, B5, V2 |
| F4: confidence handling escalations | A5, B2, G1 |
| F5: software product context (not in the ad) | A1, A2, B4, E1 |
| F6: explaining processes (not in the ad) | C2, E2, G2 |

---

## Persona table

The loop source is the invite's own words: one session, a text chat with the support team lead. Weights start from the hiring-manager prior (Case/Strategist plus Skeptic) and move with the fit snapshot.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F5 (no software company) and F4 (escalations not shown) | High. A team lead hiring into a software company will want to know how you'd learn the product, and F5 is the widest gap in the snapshot | Rehearse A1 until it's boring. Give the plain acknowledgment, then what you do carry, then a concrete learning plan |
| Case/Strategist | "A customer writes in with…, what do you do?" scenarios, possibly a reply you write live in the chat | High. Hiring-manager prior. A text chat also makes it easy to ask for a written reply on the spot | Clarify first, then structure: acknowledge, confirm details, act, say what happens next. Think in short written steps |
| Data-Driven Prober | Follow-ups on "around 60 calls and emails a day" and the four new starters | Medium. These are the only figures in your material, and figures attract probes | Know what you can and can't say about how the 60 was counted; say plainly where you don't know |
| Conversational | Chatty opener, "tell me about yourself", "why Lumenvale" | Medium. Most text chats open this way, and casual questions are still scored | Have a short written arc ready (D1); treat "why us" as scored |
| Pressure | Time-boxed "why you over…", "how much was actually you" | Low. It's less natural in a text chat, but a short answer window is easy to impose | Pause, restate, hold the position the quotes carry, concede only what's real |
| Values/Behavioral | "Tell me about a time…" prompts on customers and bad news | Low. No values round is named in the invite, and Lumenvale's values weren't retrieved | Choose your own true instance. If none comes to mind, say so and give the nearest one |
| Peer Evaluator | Hand-offs to other teams, what you'd bring the team | Low. A team lead is also a colleague of whoever takes your escalations | Reciprocity framing: what you'd bring, not only what you'd need |

---

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. How would you handle supporting a software product?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment: "I've never worked for a software company." Then what you carry, in the quotes' own terms: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, and Freshdesk every day. Then a learning plan, said as a plan: how you'd learn the product, its common issues and when to pass something on. **Follow-up 1** ("software customers are different"): don't claim they're the same. Say what you'd need to learn and how. **Follow-up 2** ("so what would you struggle with?"): concede specifically ("the product itself, at first") and return to the three years. Don't fold on the three years to restore harmony, and don't add anything to them | F5 is the one gap you stated outright, and a team lead at a software company will raise it in some form. JD because it scores fit to the listed job; the premise is your own sentence, so the question may name it |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the real one, which F5 already names: "I've never worked for a software company," so the product will be new. Then one line on how you'd close it, said as a plan. Pick a real gap, not a disguised strength. If another part of the ad worries you more, name that instead, in your own words | A standard skeptic stem. F5 makes the honest answer easy to find, and having it ready stops you reaching for a weaker, vaguer one |
| A3 | "We use Zendesk. You've used Freshdesk. What's the gap?" | JD | [grounded] "I use Freshdesk every day" | "I use Freshdesk every day." Leave it there. Don't claim Zendesk, and don't claim the two tools are the same. Say how you'd get up to speed on a new ticketing tool, as a plan. If they name a Zendesk feature you don't know, say so | F2's tool-name difference. The ad says "or a similar", so this is a light probe. JD because the tool is a listed requirement |
| A4 | "Why move from an energy supplier to a software company?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Give your actual reason, in your own words. The pack doesn't supply one, because you haven't given me one. Keep it forward-looking: what draws you to this role, not what's wrong with the current one | A motivation probe that comes with the move F1 and F5 describe. EXP because it scores consistency of your own story |
| A5 | "I don't see escalations in what you've told us. How do you handle them?" | JD | [grounded] | Answer slot (F4): if you've handled an escalated or upset customer, or passed one on, describe one case in your own words: what the customer needed, what you did, how it ended and which part was yours. If there was no such case, or it wasn't yours, say so plainly, then walk through how you would handle one: listen, acknowledge, check what you can fix, pass it on with full notes if you can't, and tell the customer what happens next | F4 is a named requirement with nothing in your material on it, so it's the second most likely probe. The label stands alone because the guidance asserts nothing about your past |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry: they've been charged twice and want a refund today. Write me your reply." | CASE | [grounded] "I trained four new starters on our refunds process last year" | Structure: acknowledge the problem in one line; confirm what you need to check (account, dates); say what you'll do and when they'll hear back. Don't promise "today" unless you know you can deliver it. You may mention that refunds are familiar ground: last year you trained four new starters on your refunds process. Keep the reply short and plain | JD content, CASE delivery: a live written reply tests F3 directly, and refunds touch F6. Plausible in a text chat because you can be asked to write the reply on the spot |
| B2 | "A customer demands to speak to a manager. What do you do?" | CASE | [generic] | Clarify first: what they're upset about and whether you can fix it now. Then: acknowledge, try to resolve within what you're allowed to do, and if it needs to go up, pass it on with a full summary so the customer doesn't have to repeat themselves. Tell them who will contact them and roughly when. No claim about your past is needed here | F4 as a live problem rather than a record. `[generic]`: a common pattern, not Lumenvale's process |
| B3 | "There are forty tickets in the queue and two are marked urgent. How do you decide the order?" | CASE | [generic] | Check that the urgent ones really are urgent (what's broken, how many people it affects), handle those first, then work by age and by any promised response times. Ask the team lead how Lumenvale defines urgent, because a team's own rules beat your guess. Say the steps in order | A standard queue-triage case for support roles. It tests structure, not history |
| B4 | "A customer reports a bug you can't reproduce. What's your next step?" | CASE | [generic] | Ask for exact steps, device and browser or app version, screenshots and when it started. Check for known issues. If it's still unclear, pass it on to the right team with everything gathered, and tell the customer what happens next. It's fine to say you'd learn Lumenvale's own process for this | The software-specific case that tests F5 without asking about it directly. `[generic]` because the steps are a common support pattern |
| B5 | "Here in the chat, write a reply to a customer who says the app keeps logging them out." | CASE | [generic] | Short, warm, specific: thank them, say you'll help, ask the two or three details you need (device, app version, when it happens), and offer one simple thing to try if you know one. Don't invent a fix. End with what happens next. Re-read it before sending | F3 tested live. In a text chat, this is the most direct way to see your writing |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Around 60 calls and emails a day. How is that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say what you can: around 60, calls and emails together. Answer slots, each in your own words: how the figure is counted (a system report, your own estimate, or something else); what makes it go up or down; the part of it you'd defend least; and that the 60 is yours. If you don't know how it's counted, say "it's my own estimate" or "I don't know exactly" plainly. That's an honest answer, not a weak one. Don't split it into emails versus calls unless you know the split | Your one headline figure, so it gets a defend-the-number question. EXP because it tests whether the claim holds up under follow-up |
| C2 | "You trained four new starters on refunds. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats your sentence states: four new starters, the refunds process, last year. Describe what you actually did, in your own words. The pack adds nothing to it. Don't call it a training programme or say you led a team | F6 is your strongest "beyond the queue" line and an obvious follow-up target. Its scope is the thing to protect |
| C3 | "How do you use Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | "Every day" is what your sentence carries. Name the parts of Freshdesk you actually use, in your own words. If there's a part you don't use, don't claim it. If they name a feature you haven't used, say so and say you'd learn it | F2's tool requirement makes a "show me you really know it" probe likely. EXP because it checks the claim, not the tool |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me a bit about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" "I've never worked for a software company" | A short written arc: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day; Freshdesk every day; last year you trained four new starters on your refunds process. Then the move: you've never worked for a software company, and why you want this role (your own reason, in your own words). Three or four sentences, not a CV recital | The likely opener. Pre-writing it frees your attention for the harder questions |
| D2 | "What drew you to Lumenvale?" | CO | [generic] | Your own reason, in your own words. Before the interview, read Lumenvale's own website and careers page so you can name one specific thing about the product or customers that interests you. This pack couldn't retrieve anything about the company, so it supplies no company facts | Casual register, scored content. CO and `[generic]` because research didn't run (see Sources) |
| D3 | "This role is fully remote. How do you work best remotely?" | JD | [generic] | Answer slot: if you've worked remotely before, say how you set yourself up, in your own words. If you haven't, say so plainly and say how you would: a set workspace, set hours, and staying in touch with the team in writing | You said the role is remote, so a remote-readiness check is likely. Your material doesn't say whether you've worked remotely, so this is a slot |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Quickly: why you over someone who's already done support at a software company?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I've never worked for a software company" | Hold: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day. Concede the real point plainly: "I've never worked for a software company, so the product is what I'd be learning." Hold through a second push by returning to the three years, not by adding to them | A time-boxed version of A1. Hold-then-concede on F1 and F5 |
| E2 | "The refunds training: how much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: you trained four new starters on your refunds process last year. Answer slot: if anyone shared the training with you, say who did what. If it was yours alone, say so plainly | The classic attribution stem, aimed at F6. Rehearsing the precise answer stops you overstating it under pressure |

### V. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Pick a time with a clear customer need, a pull the other way (speed, a target, a rule), and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A standard customer-first stem. `[generic]` because Lumenvale's values weren't retrieved |
| V2 | "Tell me about a time you had to give a customer bad news in writing." | VAL | [generic] | Pick a time with real bad news, written to a customer, and how you worded it so they understood what happens next. If no such time comes to mind, say so plainly, then give the nearest thing you can describe, or how you would write it | Themed on the ad's "clear written communication" (F3). It tests whether you can be clear and kind at once |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When a customer's problem needs another team, say engineering, how do you hand it over?" | CASE | [generic] | A summary the other team can act on without asking again: what the customer reported, steps to reproduce, what you've already tried, how urgent it is, and what you've told the customer. Then follow up so the customer isn't left waiting. Ask how Lumenvale's teams prefer hand-offs | F4's escalation requirement seen from the receiving side. `[generic]` because it's a pattern, not Lumenvale's process |
| G2 | "What would you bring the team in your first month?" | JD | [grounded] "I trained four new starters on our refunds process last year" "I use Freshdesk every day" | Say it as a plan: learn the product quickly and take a full share of the queue. You can mention what you've done, at its own scope: Freshdesk every day, and last year you trained four new starters on your refunds process. Don't promise to train anyone at Lumenvale before you know the product | Reciprocity: what the hire adds rather than costs. Draws on F2 and F6 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical day's queue look like: volume, channels, and the most common issues?" | Shows you're thinking about the work itself, and the answer tells you what to learn first about the product |
| "How do escalations work here: who picks them up, and when does a ticket go to another team?" | Ties to the ad's escalation requirement and shows you know there's a process to learn rather than guessing one |
| "How do new starters learn the product, and how long until they're working the queue fully?" | Speaks directly to F5 without dwelling on it, and shows you plan to ramp deliberately |
| "How is quality measured on the team?" | Signals you care about doing the work well, not just fast, and tells you what you'll be judged on |
| "What separates someone who's good in this role from someone who's great?" | Invites the team lead to describe the bar in their own words, and gives you something concrete to aim at |
| "What happens after this chat: is there a call or video stage?" | A practical process question. The answer tells you what to prepare next and whether a spoken round follows |

---

## Prohibited claims

These are claims this pack won't coach, with the reason for each:

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk / is experienced in Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's own observation: your material shows Freshdesk, not Zendesk |
| Has worked in software support | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Handles 60 emails / tickets a day | Inflated form of F1 | F1's quote at its own scope: "around 60 calls and emails a day", calls and emails together, "around" kept |
| Ran a training programme / led a team | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." Four people, one process |
| A specialist in written or email support | Inflated form of F1 | F1's quote at its own scope: emails are part of the 60, alongside calls. F3's slot is the place to describe a real email |

---

## Sources

**Provided documents:** your message (the job ad's requirements as you summarised them, and your background) and the invite text quoted in it.

**Searches sent:**
- "Lumenvale Software values": refused
- "Lumenvale Software interview process customer support": refused
- "Lumenvale Software news 2026": refused

No pages were fetched.

### Target accounting

Research tier: L1 — searches 3 of 6 sent, all refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have supplied official value names for the Values bank, which stays `[generic]` |
| 2. `Lumenvale Software interview process customer support` | unavailable | The search was refused. It would have checked loop structure against the invite's description; persona weights rest on the invite's words plus the hiring-manager prior |
| 3. `Lumenvale Software strategy` / recent news | unavailable | The search was refused. It would have grounded D2 and a CO question in the company's current products and moves |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given ("our support team lead"), so there was no query to form. The interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The requirements you quoted from the ad already fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **The full job ad text** → F1 to F4 quote the ad itself rather than your summary of it, and any requirement your summary left out gets its own row and question
- **Allowing web search** → targets 1 to 3 run: official values in the Values bank, a checked loop structure, and a CO question grounded in Lumenvale's current product
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a short company brief so D2 and the CASE questions use Lumenvale's own product vocabulary
- **The team lead's name** → an interviewer read, persona weights based on their public profile, and a reverse question tied to their career path
- **An escalation case or a written reply you're proud of, told outside a drill** → F3 and F4 move from `discovery` to quoted evidence, and A5, B1, B5 and V2 become story-mapped instead of slots
- **Whether you've worked remotely before** → D3 becomes story-mapped
- **A `tuesday-dossier.md`** → a verified evidence map and a prohibited-claims list from a fuller review, which would sharpen the highest-ROI objection and every guidance cell
