I'm checking the prep guidance; the pack will follow shortly.
Before the prep, one thing about the message. It says "Our hiring process is fully remote and is carried out entirely on Telegram", that "your interview will be a text chat here", and that "your offer and onboarding will be completed in this chat as well". A hiring process run entirely by chat is a known scam pattern. A chat on its own doesn't show who you're actually talking to, and the message may not come from Lumenvale Software at all. Until you've checked, don't send any money, documents or bank details through the chat. To check, contact Lumenvale using details you find yourself on its own website or the careers page where you applied, not through this chat or anything Marcus sends. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite looked at more closely, I can run job-underwriter on it as a separate request.

I've saved your prep pack as `/var/tmp/tuesday-measure/1a6/runs/opus/alone/part-5/rooms/case-10-denied-bc44e4a7/Lumenvale-Software_customer-support-specialist_interview_pack.md`. It assumes the support team lead running the chat would be your manager.

- **What's in it:** a table matching each job requirement to what you've told me, 22 practice questions with answer guidance, six questions for you to ask them, and a list of claims to avoid. That list includes saying you've used Zendesk (you use Freshdesk) and saying you handle 60 emails a day (your 60 is calls and emails together).
- **The question most worth practising is B1:** "You've never worked for a software company…" Start by saying it plainly, then stick to your three years, your daily Freshdesk use and a plan for learning their product.
- **Your biggest gap is escalations.** You haven't mentioned handling one, so A3, B4 and G1 give you a structure for answering. If you have a real escalation story, tell me and I'll rebuild those answers around it.
- **Since the interview is a text chat, your typed answers are your writing sample.** Practise typing short, well-structured replies; A1 and E2 test this directly.
- **I couldn't research the company.** Permission for web searches wasn't granted, so I found nothing on Lumenvale's values or recent news. "Why Lumenvale?" (C2) is general guidance, and there's no values section.

If you'd like a practice run, I'll play the sceptical interviewer on B1 and follow up based on what you say.
I can also save a `tuesday-dossier.md` file recording the gaps this prep found, so you can bring it to later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would the support team lead be your manager, or a peer on the team? The answer changes which questions matter most.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale-Software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

**Round:** a text-chat interview with the support team lead, as the invite describes it ("your interview will be a text chat here with our support team lead"). The interviewer's name was not given. This pack assumes the support team lead would be your manager; if they would be a peer, the persona weights change (see the upgrade menu).

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour and values. Does what you have done show the values the company says it holds?
  - **EXP**: your work history in depth. Do your claims hold up, and what part was actually you?
  - **JD**: the job ad's requirements. Can you do the job as listed, gaps included?
  - **CO**: company knowledge. Have you done your homework on the company and what it is doing?
  - **CASE**: a live problem from the role, worked through on the spot.
- Provenance labels: `[grounded]` means traceable to what you gave me. `[inferred]` means derived by this pack, with the derivation named. `[generic]` means a pattern for the role family, not a fact about Lumenvale.
- **Guidance is scaffolding, not a script.** Answer in your own words. Because this round is a text chat, your written answers *are* the writing sample. Practise typing your answers, not only saying them.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (the job ad, as your message gives it) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | medium | [grounded] | none | No gap. Your quote already covers the requirement. Lead with it in its own terms: three years, customer service advisor, energy supplier, around 60 calls and emails a day. Keep the 60 attached to "calls and emails" together, because the figure counts both. Expect a probe on it, because nothing behind it has been inspected (see D1) |
| F2 | "experience with Zendesk or a similar ticketing tool" (the job ad, as your message gives it) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | No gap: the job ad accepts a similar tool, and your quote names one you use daily. Name it: "I use Freshdesk every day." Answer slot: the ticketing line makes a probe on what you do in the tool likely. Describe what you actually do in Freshdesk day to day, in your own words. If a feature comes up that you have not used, say so plainly. Never present Freshdesk use as Zendesk use |
| F3 | "clear written communication" (the job ad, as your message gives it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your quote shows you answer emails as part of the 60. It does not show how clear they are, and the bridge stops there. Answer slot: if you have habits that keep your written replies clear (structure, tone, checks before sending), describe them in your own words. If you have no set habit, say so and describe how you would write a clear reply. In this round the chat itself will show your writing, so short, well-structured messages are evidence in themselves |
| F4 | "confidence handling escalations" (the job ad, as your message gives it) | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: if you have handled escalated customers, or escalated cases yourself, pick one and say what happened and what part was yours, in your own words. If none comes to mind, say so plainly and walk through how you would handle one (A3 rehearses this) |
| F5 | Software-product context: the "Customer Support Specialist position" at "Lumenvale Software" (the invite) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A gap that wording cannot close, and you have said so yourself. Words: "I haven't worked for a software company." Then F1's quote at its own scope, then how you would learn the product, said as a plan and never as past experience. Add nothing that makes the gap sound smaller |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: 2+ years in customer support | C1, D1, E1 |
| F2: Zendesk or a similar ticketing tool | A5, B5 |
| F3: Clear written communication | A1, D3, E2 |
| F4: Confidence handling escalations | A3, B4, F2, G1 |
| F5: Software-product context | B1, B2, B3, E1 |

---

## Persona table

The session is fixed by the invite's own words: one text chat with the support team lead. Those words do not say whether the team lead would be your manager, so the weights below assume they would be, using the hiring-manager pattern. No values-style round is detected, because nothing you have names one.

| Persona | How it shows up in a text chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | "A customer writes in saying…, how would you reply?" Possibly asking you to type the reply itself | High. A team lead hiring for the queue they run will test how you handle real tickets, and a chat makes it easy to ask for a live written reply | Clarify, then structure, then answer. Type in short paragraphs. Say what you would check before promising anything |
| B. Skeptic | Quiet probes on the gap: no software company, Freshdesk rather than Zendesk, why switch sectors | High. F5 is the plainest gap in the snapshot, and a manager hiring will want to know you can close it | Rehearse B1 until it is boring. Concede plainly, use only what F1 and F2 say, and give a concrete learning plan |
| C. Conversational | Friendly openers: "Tell me about yourself", "Why us?" | Medium. Most interviews open this way, and in text these answers are still read and scored | A prepared short arc built only from F1, F2 and the training sentence. Keep it to a few lines |
| D. Data-Driven Prober | "How does the 60 a day break down?", "How did you know the training worked?" | Medium. Your one figure and your one training claim are the obvious things to dig into | Know what you can and cannot say about how the 60 was counted. Say plainly when you do not know |
| E. Pressure | Time-boxed or devil's-advocate prompts: "In two lines…" | Low. Less common from a team lead, but a text format makes a brevity test easy to set | Hold the position your quotes support through two follow-ups, then concede specifically |
| F. Values / Behavioral | "Tell me about a time you…" | Low. No values round is detected, but behavioural prompts often show up in a single-round interview | Pick real instances. If none comes to mind, say so and give the nearest real thing |
| G. Peer Evaluator | "How would you hand a case to another team?" | Low, unless the team lead turns out to be a peer, which would raise it | Talk about principles for handovers. Do not pretend to know how Lumenvale's teams are set up |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in, angry: they've been charged twice and want a refund today. Reply to them here, as you would in a ticket." | CASE | [generic] | Type the reply. Acknowledge the problem and how it feels, in one line. Say what you will check. Say what happens next and when, without promising a refund or a timeline you cannot guarantee. Close with what they need to do, if anything. Then, outside the reply, tell the interviewer in a sentence what you would check internally. The question makes no claim about your past, so the guidance makes none | A chat interview is a natural place to ask for a live written reply, and this tests F3's requirement directly. CASE because it is a live problem from the role; `[generic]` because Lumenvale's refund policy is not known |
| A2 | "A customer reports a bug you can't reproduce, and they're getting frustrated. What do you do?" | CASE | [generic] | Structure it: gather details (what they did, what they saw, when, on what device, screenshots); try to reproduce it; tell the customer what you are doing and when they will hear back; if you still cannot reproduce it, escalate through the team's process with everything you gathered, so nobody has to ask the customer again. Say you would learn Lumenvale's escalation path rather than guessing at it | Bug reports are a pattern of software support and sit right on F5's gap; a structured answer shows you can work without product history. `[generic]` because it is a role-family pattern |
| A3 | "A customer demands to speak to a manager. Walk me through how you'd handle it." | CASE | [grounded] | Structure it: stay calm and acknowledge it; ask what outcome they want; check whether you can solve it yourself within policy; if not, or if they still want a manager, escalate properly with a full summary, and tell them what will happen and when. Escalating is not failing; doing it cleanly is the skill. The question asks about no past, so the guidance claims none | The job ad's "confidence handling escalations" (F4) is the requirement with no evidence behind it, so a strong hypothetical answer matters more here. `[grounded]` on the job ad's line |
| A4 | "You come back from a day off to a full queue. How do you decide what to answer first?" | CASE | [generic] | Structure it: urgency (customers who are blocked or losing money), anything close to a deadline the team has set, oldest unanswered, then quick wins you can clear quickly. Say you would follow the team's priority rules where they exist and ask your lead where they do not | Queue triage is a standard live problem for support roles. `[generic]` because Lumenvale's queue rules are not known, which is why the guidance defers to them |
| A5 | "Our ticketing tool may be new to you. How would you get productive in it quickly?" | JD | [grounded] "I use Freshdesk every day" | Start from the quote: "I use Freshdesk every day." Then a plan: learn how the team's views, tags and macros are set up, shadow a colleague, and ask what good looks like in the first week. Answer slot: if the interviewer asks what carries over from Freshdesk, name what you actually do in it day to day, in your own words. If something they mention is not something you have used, say so plainly | Covers F2's requirement. JD because it scores the stated tool requirement; the plan is phrased as future, not past |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we believe you can support a software product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Concede first and plainly: "I haven't worked for a software company." Then only what your quotes carry: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day. Then a learning plan, as a plan: learn the product as a user first, read the help docs and past tickets, shadow, and know when to escalate rather than guess. Answer slot: the invite's "Lumenvale Software" makes a probe on supporting software likely. If any of your energy-supplier work involved helping customers with an online account or app, say what, in your own words. If none did, say so plainly and stay with the three years. Follow-up 1 ("But what about technical questions?"): hold, saying you would learn the product and escalate cleanly what you cannot answer. Follow-up 2 ("Others have done this already"): concede that they have the product background, and hold on what your quotes carry. Never claim technical knowledge you have not stated | F5 is the one gap you stated yourself, and it is the most predictable objection to your background for this role. It will come in some form. JD because it scores fit to the role as advertised |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name it yourself before they do: product knowledge, because "I haven't worked for a software company." Then the plan from B1, briefly. Do not pick a fake weakness; this one is real, and naming it calmly is the strength | Skeptic stem pointed at F5. Answering it honestly in advance lowers the impact of B1 |
| B3 | "Why move from energy into software?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: give your actual reason for the move, in your own words. Your material does not say why, so this pack will not supply one. Keep it forward-looking (what you want to do next) rather than about your current employer. Keep your three years in the quote's own terms | Sector change is the obvious motivation probe for F5. EXP because it tests the consistency of your story |
| B4 | "This role needs confidence handling escalations. Tell me about a time you handled one." | JD | [grounded] | Selection scaffold: pick a time a customer was escalated to you or by you, or was unhappy enough that it nearly came to that. It needs what the customer wanted, what you did, and how it ended. Use "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or walk through how you would handle one (A3) | F4 has no evidence behind it, so this is where a story is most needed and none is supplied. JD because the requirement is stated in the job ad |
| B5 | "Freshdesk isn't Zendesk. How much of your experience will actually carry over?" | JD | [grounded] "I use Freshdesk every day" | Hold: "I use Freshdesk every day." The job ad asks for Zendesk "or a similar ticketing tool". Answer slot: name what you do in Freshdesk day to day, in your own words, and say plainly if you have not used Zendesk. Concede only that the specific screens will be new | Covers F2. The pushback is small, but answering it calmly matters. JD because it scores the tool line |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself and how you got here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short written arc using only these beats: three years as a customer service advisor at an energy supplier; around 60 calls and emails a day; Freshdesk every day; last year you trained four new starters on your refunds process. Close with one line on why this role, in your own words. Four or five lines in total | Almost always the opener. In a text chat a wall of text reads badly, so length matters. EXP because it is your history |
| C2 | "What drew you to Lumenvale?" | CO | [generic] | Answer slot: say what you actually know from the job ad and the careers page you applied through, and what appealed to you, in your own words. Do not state facts about Lumenvale's product or customers that you have not read yourself | Usually asked early. `[generic]` because no company research ran (see Sources), so the pack cannot supply facts |
| C3 | "What do you enjoy most about customer support?" | VAL | [generic] | Selection scaffold: one real thing you enjoy, plus a short example of it. If nothing specific comes to mind, say what keeps you in the work, honestly | A casual question that is still scored for genuine interest. VAL because it tests motivation rather than skill |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day: how does that break down?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the 60 as calls and emails together. Answer slot: say how the figure is counted (your own count, a team report, an estimate), what it changes with (busy seasons, the type of contact), and which part of it you would defend least, all in your own words. If you do not know the split or how it was counted, say so plainly: "It's around 60 calls and emails combined; I don't have the exact split." | Your only figure, so the likeliest one to be probed (F1). EXP because it tests whether the claim holds up |
| D2 | "You trained four new starters on the refunds process. How did that go?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it in the quote's own terms: last year, four new starters, the refunds process, trained by you. Answer slot: if asked how you ran the training, describe it in your own words. If asked how you knew it worked, and you checked how they got on afterwards, say how. If you did not, say so plainly and stay with the training itself. Do not turn it into running a training programme | The training sentence is the strongest detail in your background and a natural probe. EXP because it tests what was actually yours |
| D3 | "How do you keep your written replies clear when you're handling that volume?" | JD | [inferred] "answering around 60 calls and emails a day" | Answer slot: the job ad's "clear written communication" makes a probe on your writing habits likely. If you have habits (structure, plain words, re-reading before sending, saved replies), describe the ones you actually use, in your own words. If you have none set, say so and describe how you would make a reply clear. Make your chat answers themselves short and well structured | F3 is the thin row: the quote shows email volume, not clarity. `[inferred]` because the link from volume to clarity is the pack's derivation |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Quickly: why you over someone who's already done support at a software company?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause, then hold on what the quotes carry: three years, around 60 calls and emails a day, Freshdesk every day. Concede specifically: "I haven't worked for a software company, so the product is what I'd be learning." Hold through two follow-ups by coming back to the three years and your learning plan; never by adding experience you have not stated | B1 under time pressure. JD because it scores fit; Pressure because it tests composure |
| E2 | "In two lines: how would you calm down a customer who's threatening to cancel?" | CASE | [generic] | Two lines, really: acknowledge, then the concrete next step and when it will happen. Keeping to the limit *is* the answer | A text chat makes a brevity test easy to set, and it scores F3's requirement live. `[generic]` because it is a role-family pattern |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time you spent longer on a customer, or did something extra, because it was right for them, even though it cost you on a target. It needs the stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest real example | Persona stem. `[generic]` because Lumenvale's published values were not retrieved, so this cannot be mapped to them |
| F2 | "Tell me about a time you had to tell a customer something they didn't want to hear." | VAL | [generic] | Selection scaffold: a real instance where the answer was no or not yet. It needs what they wanted, how you told them, and what you offered instead. If none comes to mind, say so plainly and say how you would do it | Adapted from the "unpopular truth" stem. It sits close to F4's escalation requirement, where no story has been provided |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "If a customer's problem needs another team to fix it, how would you hand it over so nobody has to ask the customer again?" | CASE | [grounded] | Principles: a full summary (what the customer reported, what you tried, what they expect), the right channel, a clear owner, and a promised update to the customer, which you keep. Say you would learn how Lumenvale's teams hand work over rather than assume. The question claims nothing about your past | Escalation from the team's side (the job ad's "confidence handling escalations"). `[grounded]` on that line |
| G2 | "What would you do in your first month to make life easier for the rest of the support team?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | As a plan: learn the product fast so you are not adding to their load, ask before guessing, and pick up your share of the queue. If it fits, mention in your own words that "I trained four new starters on our refunds process last year", as something you could offer once you know the product, never as a promise about Lumenvale's processes | A reciprocity question a team lead may ask. CASE because it is forward-looking |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical day look like in this role? Mostly chat, email or phone?" | It shows you are thinking about the actual work, and the answer tells you which parts of F1 to lead with later |
| R2 | "What tends to get escalated most often, and how does the escalation path work here?" | It goes straight at F4's requirement and shows you treat escalations as a process, not a crisis |
| R3 | "How do new specialists usually learn the product in their first few weeks?" | It answers B1's objection from your side and signals you have already thought about the ramp-up |
| R4 | "Which ticketing tool does the team use day to day, and how is it set up?" | It connects to F2 and invites the interviewer to talk about their own setup |
| R5 | "What would a strong first 90 days look like for this role?" | It gives you the success criteria directly, and team leads usually have a clear answer |
| R6 | "Is there a call or video conversation at any stage, so I can prepare for spoken questions as well?" | Purely for prep: spoken and written answers need different practice, and this pack is tuned for text |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for a software company, or in software-company support | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk |
| Handles around 60 emails a day | Inflated form of F1: the figure slid from "calls and emails" onto emails | F1's quote at its own scope: "answering around 60 calls and emails a day" |
| Ran or designed a training programme | Inflated form of "I trained four new starters on our refunds process last year" | The quote at its own scope: four new starters, the refunds process, last year. D2's slot stays inside the training |

---

## Sources

- **Provided:** your message (the invite's text, the job ad's requirements as you summarised them, and your background).
- **Searches sent:**
  - "Lumenvale Software company values": refused
  - "Lumenvale Software interview process customer support": refused
  - "Lumenvale Software news 2026": refused
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. Published values would have themed or mapped F1 and F2 to Lumenvale's own value names |
| 2. `Lumenvale Software interview process customer support` | unavailable | The search was refused. The invite's own words already describe the session, so this would mainly have added any documented later stages |
| 3. `Lumenvale Software` strategy and recent news | unavailable | The search was refused. It would have given C2 and the CO coverage real company facts instead of a `[generic]` slot |
| 4. Interviewer name + company | n/a | No name was given for the support team lead, so there was no query to form |
| 5. Representative Customer Support Specialist JD | skipped | The job ad's requirements in your message already fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **The full job ad text** → requirement wording quoted straight from the ad, and any mid-list requirements your summary left out get their own questions
- **The support team lead's name** → a short read of their public professional background, persona weights based on it, and a reverse question tied to their path
- **Whether the team lead would be your manager or a peer** → persona weights recomputed; a peer round raises the Peer and Prober banks
- **Allowing the three searches to run** → Lumenvale's published values (F1 and F2 mapped to them by name) and current company context for C2. Beyond that, a deeper research pass is available: up to 6 more searches and 2 more fetches, taking several more minutes
- **An escalation story you can tell** → F4, B4, F2 and A3 move from scaffolds to your own story
- **How you keep emails clear, in your own words** → F3 and D3 move from answer slots to grounded guidance
- **A performance review or similar document from your current role** → F1 and F2 could move from `medium` towards `high` confidence
- **How much prep time you have** → a prioritised prep schedule
- **A `tuesday-dossier.md`** → the highest-ROI objection derived from checked evidence rather than inferred, and a confirmed list of claims to avoid
