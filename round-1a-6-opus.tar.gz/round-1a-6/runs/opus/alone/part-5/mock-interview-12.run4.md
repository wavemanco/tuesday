Quick update: I've read the prep method's rules and I'm checking a few more before I look up the company and write your pack.
Before the prep, there's a problem with the invite. It asks you to "please transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says that if you get the job, "you deposit the cheque and send the balance on to the vendor". Real employers don't charge you to be interviewed, and they don't ask for your passport or bank details before an offer. The cheque arrangement is a known pattern: the cheque bounces days later, after you've already sent "the balance" from your own money. Requests like these are a known scam pattern, and this job is very likely a scam. Don't pay anything, send any documents or bank details, or deposit any cheque until you've checked the invite with the company. Use contact details you find yourself on the company's own website, not the email address or anything else in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed properly, job-underwriter can check it as a separate request.

Your prep pack is saved as `Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. I built it for the 30-minute video call with the office manager, treating them as the person you'd work for. It's based on the ad's duties as you described them, since I don't have the ad itself. My web searches were refused, so it has no company research.

**What to expect:**
- **Questions on the gaps:** supplier invoices, travel booking, Excel, and working on your own from home.
- **"What would you do if…" problems:** for example, a clash between two meetings, or an invoice that doesn't match what was ordered.
- **Opening and closing:** a friendly "tell me about yourself" at the start and "any questions for me?" at the end.

**How to prepare:**
- **Practise A1 most: "Have you processed supplier invoices before?"** This is where you're most likely to oversell by accident. You chased invoices owed *to* the clinic, which is the opposite side from paying suppliers. Say exactly that, then say how you'd learn their process.
- **Keep your own words.** You "ran the appointment book for four physios". You're "good with Word" and "okay with Excel". Don't round them up.
- **Practise the "what would you do" questions (B1–B5) out loud.** They let you show judgement in areas where you have no track record yet.
- **Have your 90-second background answer (C1) and two or three questions for them ready.**

If you'd like, I'll play the sceptical interviewer on A1 and push back the way a real one would.
I can also save a `tuesday-dossier.md` recording the gaps this prep turned up, for you to use in later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full ad text? It would let me check the duties against the ad's exact wording.
2. Would the office manager be your manager, or someone else? That changes which kinds of questions to expect most.
3. Is working from home for this role settled for you?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** one 30-minute video call with the office manager (no name given; the relationship to the role isn't stated, so this pack treats them as the person you'd work for).
**Built from:** the ad's duties as your message describes them, and the background in your message. No full ad text, no CV.

## How to use this pack

- **Personas** describe *how* a question comes at you: friendly, sceptical, a live problem, under pressure.
- **Types** describe *what is being scored*:
  - **JD**: can you do the listed duties, including the gaps.
  - **EXP**: does what you've said about your past hold up, and was it really yours.
  - **CASE**: a live problem from the job. They're scoring your structure, not a "right" answer.
  - **VAL**: whether your past behaviour matches how they want people to work.
  - **CO**: whether you've done your homework on the company.
- **Provenance** shows where each line comes from. `[grounded]` means it traces to something you gave me. `[inferred]` means I derived it, and the derivation is named. `[generic]` means a common pattern for this kind of role, with no claim about this employer.
- **Answer slot** marks a place where only you know the true answer. It gives two honest branches. Both are good answers.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as your message describes it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | The closest thing in your background, and you should say it in its own words: "I ran the appointment book for four physios." Your material describes an appointment book, not the calendars of office staff, so don't swap in the ad's wording for your own past. Answer slot: the ad's calendar duty makes a question about clashes and changes likely. If you dealt with double bookings or rescheduling, say how, in your own words. If you didn't, or it wasn't your job, say so plainly and stay with running the book |
| F2 | "booking travel" — the ad, as your message describes it | none given | none | [grounded] | discovery | Your material doesn't show any travel booking. Answer slot: if you've booked travel for anyone, at work or outside it, say what you booked and how. If you haven't, say so plainly and walk through how you would do it (B2 rehearses this) |
| F3 | "preparing documents in Word and Excel" (the Word half) — the ad, as your message describes it | "I'm good with Word" — your message | low | [inferred] | discovery | A self-rating with nothing behind it yet, so expect to be asked what you've made. Answer slot: if you produced documents in Word at the clinic or elsewhere, name what they were, in your own words. If you didn't, say so plainly and say what "good with Word" means for you |
| F4 | "preparing documents in Word and Excel" (the Excel half) — the ad, as your message describes it | "okay with Excel" — your message | low | [inferred] | discovery | Keep your own level, "okay with Excel", and don't round it up. Answer slot: if you've used Excel for a real task, say what it was. If you haven't, say so plainly. Either way, add how you'd build your skills, said as a plan and never as something you've already done |
| F5 | "processing supplier invoices" — the ad, as your message describes it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your words: "I chased unpaid invoices." The pack's observation: your material describes chasing money owed *to* the clinic, while the ad describes invoices the company receives *from* suppliers. These are opposite sides of the same paperwork, so don't present one as the other. Answer slot: if you ever handled bills the clinic received from suppliers, say what you did, in your own words. If you didn't, or it wasn't yours, say so plainly and stay with chasing unpaid invoices |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Remote working is a condition of the job. Your material doesn't establish whether you can work from home for this role |

## Persona table

The loop comes from the invite's own words: "The interview is a 30-minute video call with our office manager." That is one session, run by one person.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Calm questions about the gaps: invoices, travel, Excel, working alone | High. An office manager hiring for admin is checking you can do the listed duties, and F2, F4 and F5 are where your material is thinnest | Rehearse A1 until it bores you. Build bridges only from what you've actually said, state the limit plainly, then give a concrete plan for learning |
| Case / Strategist | "What would you do if…" problems taken from the duties | High. In a hiring-manager-style round these are the cheapest way to test someone without admin history | Clarify first, then structure, then answer. Think out loud. Close by confirming in writing |
| Conversational | Friendly opener, "tell me about yourself", tools chat | Medium. A 30-minute call usually opens and closes in this register, and it's still scored | Have a 90-second arc ready (C1). Treat casual questions about Word and Excel as scored |
| Data-Driven Prober | Asks for numbers behind your lines | Low to medium. "Four physios" invites a "how many a day?" | Give only figures you know. "I don't know the exact number" is allowed |
| Values / Behavioural | "Tell me about a time…" | Low to medium. No values round is named, but one or two behavioural questions are common in a single call | Pick true stories. Use "I" for your part. Where no story fits, say so |
| Pressure | Time-boxed "why you?" and "how much was really you?" | Low. Nothing points to a stress format, but one sharp question can happen | Pause, anchor in what you did, hold, then concede what's real |
| Peer Evaluator | Working with colleagues, disagreements | Low. You're meeting one manager, not a peer | A reciprocity answer, plus one honest disagreement story or scaffold |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Have you processed supplier invoices before?" | JD | [grounded] "receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | **The highest-ROI prep in this pack.** Hold only what your sentence carries: "At the clinic I chased unpaid invoices." Answer slot: if you ever handled supplier bills there, say what you did, in your own words. If you didn't, say so plainly. That's a limit, not a confession. Then give a plan, said as a plan: how you'd learn their process and who you'd check approvals with. Through two follow-ups, keep returning to the invoices you chased. Never add to them | F5 is the one gap that could be talked up by accident, because "invoices" appears on both sides. JD because it scores a listed duty directly |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Name it honestly, in your own level: "okay with Excel." Answer slot: if there's an Excel task you've done, name it. If not, say so plainly. Then give a short, concrete plan for getting up to speed, said as a plan | F4 is a candid answer you can actually give. Interviewers trust people who name a real weakness more than people who name a fake one |
| A3 | "I don't see travel booking in your background. How would you handle it here?" | JD | [grounded] | Answer slot: if you've booked travel for anyone, say what and how. If you haven't, say so plainly. Then walk through how you'd do it: what you'd ask first, how you'd compare options, how you'd confirm. B2 is the full rehearsal | F2 is silence in your material, so the probe is likely. JD content with a CASE-style recovery |
| A4 | "Your background is a clinic front desk. Why move into remote admin work?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Start from your two years at the clinic, in your own words. Answer slot: give your actual reason for wanting this kind of role, in your own words. The pack supplies no reason for you | A motivation check that comes up almost every time someone changes setting. EXP because it tests whether your story holds together |
| A5 | "You'd be working on your own from home. How do we know you'll stay on top of things?" | JD | [grounded] "I ran the appointment book for four physios" | Anchor in your sentence: you ran the appointment book for four physios. Answer slot: if you regularly handled work at the clinic without someone checking it, say how. If you didn't, say so plainly and describe how you'd structure a remote day: lists, check-ins, confirming tasks in writing | The role is remote (F6), so working unsupervised is the natural probe. F1 is the evidence nearest to it |

### B. Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people want the same slot in a manager's diary and both say it's urgent. What do you do?" | CASE | [generic] | Clarify what each meeting is for and how long it needs. Check the manager's priorities, or ask them. Offer the other person the nearest alternative. Confirm both in writing and update the calendar. This makes no claim about your past | A live version of the calendar duty (F1's requirement). Tests judgement, not history |
| B2 | "Book a two-day trip for a manager. What do you need to know first?" | CASE | [generic] | Ask about dates and times, budget or travel policy, who approves, and their preferences. Compare a few options, get approval, book, then send one itinerary with all the confirmations in it. Mention a backup for delays | F2 has no evidence, so a clear method is your best answer. Asking first scores well |
| B3 | "A supplier invoice arrives that doesn't match what was ordered. What do you do?" | CASE | [generic] | Don't pay or approve it yet. Check it against what was ordered or agreed. Flag it to whoever approves payments. Contact the supplier with the specific difference. Keep a note of what was raised and when | Tests the invoice duty (F5's requirement) as a decision rather than a record, so it needs no claim you can't back |
| B4 | "We want a spreadsheet showing which invoices are paid. How would you set it up?" | CASE | [generic] | Talk through the columns: supplier, invoice number, date, amount, due date, status, paid date. Explain how you'd sort or filter it. If you'd need to look up a function, say so plainly. That's honest and fine | The Excel half of the documents duty (F4), done live. CASE because they're scoring your structure |
| B5 | "Your manager sends rough notes and needs a tidy letter in Word within the hour. Talk me through it." | CASE | [generic] | Clarify who it's for and the deadline. Draft from a template or a clean layout. Ask about anything missing rather than guessing. Proofread and spellcheck, then send it back for a final look | The Word half of the documents duty (F3), done live with no claim about your past |

### C. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | 90 seconds: two years as a receptionist at a physiotherapy clinic, the appointment book you ran for four physios, and the unpaid invoices you chased. Then, as an answer slot: why this role, in your own words | The opener in nearly every call. Your one sentence already carries three beats, so tell those and nothing more |
| C2 | "What do you know about us?" | CO | [generic] | Read the company's own website beforehand. Say in a sentence or two what it does, in your words. If something isn't clear to you, ask about it rather than guessing | Research for this pack couldn't run, so no company facts are supplied. CO because it scores your homework |
| C3 | "Which tools are you comfortable with?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say it exactly at its own level: good with Word, okay with Excel. Don't round "okay" up. If they ask for more, use your A2 plan | F3 and F4 in a casual register. This is still scored, and the risk is overstating it in a relaxed moment |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Four physios: how many appointments a day did that mean?" | EXP | [grounded] "I ran the appointment book for four physios" | Answer slot: if you know the real figure, give it. If you don't, say so plainly rather than estimating a number you can't stand behind. "Four physios" is the figure you gave, so keep it attached to physios | The one number in your material (F1) invites a follow-up. EXP because it tests whether your claim holds up |
| D2 | "When you chased unpaid invoices, what did you actually do?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: describe the steps you actually took, in your own words. If you know how it turned out, say so. If you don't, say that plainly. Don't describe a process you weren't part of | F5 under a closer look. Rehearse it so A1's honest limit and this answer match |

### E. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell someone something they didn't want to hear." | VAL | [generic] | Pick a true moment. It needs a clear stake, what you said, and how the relationship held up afterwards. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your experience does have, or how you'd handle it | An unpopular-truth question is a standard behavioural stem. No values were researched, so this is a generic theme |
| E2 | "When did you put a customer ahead of a rule or a target?" | VAL | [generic] | Pick a true case with a real trade-off and say what you weighed. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you'd handle it | A common behavioural stem. A clinic front desk may give you material, but only you know whether it does |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Sixty seconds: why you over someone who's done this exact job before?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Pause, then hold on what you did: two years, an appointment book for four physios, unpaid invoices chased. Concede what's real when pushed: Excel is "okay", and supplier invoices would be new. Don't fold on the work you did. Don't add superlatives | Tests composure against the gaps in F4 and F5. The hold-then-concede structure is the skill being scored |
| F2q | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold: you ran it. Answer slot: if others also worked on it, say plainly how it was shared. If not, say so. Either way, use "I" only for your part | An attribution probe on F1, the core of your story |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "If you and a colleague disagree about how something should be done, what happens?" | VAL | [generic] | Pick a true disagreement. It needs what you each wanted, how you raised it, and where it landed. If none comes to mind, say so plainly and describe how you'd handle one: raise it privately, focus on the task, agree a next step | A standard collaboration stem. Lower weight because you're meeting one manager |
| G2 | "What would you need from the rest of us in your first month?" | CASE | [generic] | Ask for access to calendars and systems, a walkthrough of how invoices and approvals work, examples of documents they like, and a regular check-in. Add what you'd give back: quick turnaround and written confirmations | A reciprocity question that shows you're thinking about their workload. No claim about your past |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Managing calendars (F1) | A5, B1, D1, F2q |
| Booking travel (F2) | A3, B2 |
| Documents in Word (F3) | B5, C3 |
| Documents in Excel (F4) | A2, B4, C3 |
| Processing supplier invoices (F5) | A1, B3, D2 |
| Remote working (F6) | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Whose calendars and travel would I be looking after, and what does a typical week look like?" | Shows you're picturing the actual work, and tells you which of F1 or F2 to prep harder for next time |
| R2 | "How do supplier invoices move through the team now? Is there an approval step before anything is paid?" | Shows you understand controls matter in this duty, and it fits the honest answer you gave on A1 |
| R3 | "Which Excel tasks come up most often in this role?" | Follows naturally from being honest about Excel, and gives you a concrete thing to practise |
| R4 | "How does the team keep in touch day to day when everyone's working remotely?" | Shows you've thought about working remotely, which is the A5 concern |
| R5 | "What would good look like at the end of my first three months?" | A strong closing question that shows you want to be judged on results |
| R6 | "What happens after this call, and when should I expect to hear?" | A practical process question that helps you plan your follow-up |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices / accounts payable experience | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The pack's observation: your material describes the money owed to the clinic, not bills from suppliers. A1's slot stays inside what you did |
| Managed calendars or diaries for office staff | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." Don't swap in the ad's wording |
| Strong or advanced in Excel | A claim your own quote contradicts, F4 | Your words: "okay with Excel" |
| Expert in Word | Inflated form of F3 | Your words: "I'm good with Word" |

## Sources

- **Provided:** your message, which contains the invite text, the ad's duties as you described them, and your background.
- **Searches sent:**
  - `Brennock Facilities Ltd values`: refused (search permission not granted)
  - `Brennock Facilities interview process administrative assistant`: refused (search permission not granted)
- **Fetches:** none.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Refused. Would have supplied published values for VAL questions (E1 and E2 are generic instead) |
| 2. `Brennock Facilities interview process` | unavailable | Refused. The invite's own words set the loop (one video call with the office manager), so the persona weights didn't depend on it |
| 3. `Brennock Facilities` strategy / recent news | unavailable | Not sent after searches were refused. Would have grounded C2 and a CO question in real company facts |
| 4. Interviewer name | n/a | No name given, so there was no query to form |
| 5. Representative administrative assistant JD | unavailable | Not sent after searches were refused. Would have added `[inferred]` rows for duties the ad may list beyond the four you described |

## Upgrade menu

- **The full ad text** → F1 to F5 rest on the ad's exact wording instead of your summary, and any extra duties get their own rows and questions.
- **The office manager's name, and whether they'd be your manager** → persona weights recalibrated, and a reverse question tailored to them.
- **Allowing web searches** → company facts for C2 and a CO question, plus published values for E1 and E2.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a company grounding section and strategy-based questions.
- **Your answers to the answer slots in F2, F3 and F4** (travel booked, documents made, Excel tasks done) → those rows can be graded on real evidence, and A2, A3, B4 and C3 become story-mapped.
- **A `tuesday-dossier.md`** → verified evidence and a list of off-limits claims to sharpen the prep. Useful, not required.
