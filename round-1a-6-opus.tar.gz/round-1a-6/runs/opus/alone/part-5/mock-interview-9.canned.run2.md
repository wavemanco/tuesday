Quick update: I've read the prep method I use. Next I'm checking what's published about Halvering Elementary and the Orrinsford district, then I'll build your pack.
I've saved your prep pack as `/var/tmp/tuesday-measure/1a6/runs/opus/alone/part-5/rooms/case-9-canned-044e8fa6/halvering-elementary_fourth-grade-teacher_interview_pack.md`. There was no job posting, so I based it on the invite, the district's own pages and a typical fourth-grade posting. One note first: interview prep doesn't need your Social Security number, so I've left it out entirely. Your license number stayed out of every search too.

**What the pack contains:**
- **Fit snapshot:** each requirement next to your own words. Your license meets the invite's one stated requirement: an Elementary Education endorsement for grades 1–6, active through June 30, 2029.
- **23 practice questions** across seven interviewer styles, weighted for the principal plus two future teammates.
- **Reverse questions** for you to ask the panel.
- **A list of claims the pack won't coach.**

**What the research turned up:**
- **The panel's topics.** The district's hiring page says panels ask about reading instruction, classroom routines and working with families.
- **The principal's background.** Principal Vantongeren was a reading specialist for nine years. Her 2025 talk was on weekly reading conferences in grades 3–5. Expect the deepest follow-up questions on reading.
- **The district's plans.** In August 2026 the board adopted a literacy plan that brings a new grades 3–5 reading curriculum in fall 2027. Your 2024 curriculum move is directly relevant, and question C4 shows how to bring it up without overstating it.

**The most important rehearsal is A1: "You haven't taught fourth grade."** Say it plainly, follow with your six years of third grade, then give a concrete first-year plan.

**Where only you know the answer:** many questions have an "answer slot." Your material doesn't show which subjects you've taught, how you use assessment data, your routines, or what leading the curriculum move involved. The pack doesn't fill these in for you. Each slot gives you two honest ways to answer.

If you'd like, I can play the principal on A1 and react to your answers.
I can also save a `tuesday-dossier.md` file recording the gaps this prep found, to carry into later sessions.
If you want the pack as a Word document, I can convert it.

Can you paste Halvering's actual job posting? I'll re-ground the five rows currently based on a typical posting. And how much prep time do you have before Thursday? I'll add a prioritized schedule.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack — Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Format:** 45-minute panel interview, Thursday
**Panel:** Principal Dolores Vantongeren (your likely future principal, so a hiring-manager role) and two members of the fourth-grade team (your future peers)

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL** — behavioral and values alignment, here meaning the district's published beliefs
  - **EXP** — work-experience deep-dive: what you actually did
  - **JD** — the role's stated duties and qualifications, gaps included
  - **CO** — district and school knowledge: current plans and recent moves
  - **CASE** — a live problem from the job, worked through out loud
- Provenance labels: **[grounded]** means it traces to your words, the invite or research listed in Sources. **[inferred]** means it comes from a typical fourth-grade posting, not Halvering's own. **[generic]** means a common pattern for this kind of interview, with no claim about Halvering.
- An **answer slot** is where only you know the answer. It tells you what the panel is likely to probe and gives you two honest ways to answer it.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

No job posting was supplied. Requirements come from the HR invite and the district's own pages ([grounded]), or from a typical fourth-grade posting on a jobs board ([inferred]).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | As you describe it, you meet this gate: an Illinois PEL with an Elementary Education endorsement for grades 1–6, registered and active, expiring June 30, 2029. Grades 1–6 includes fourth grade. Nothing on file has been inspected, so check your own license record before Thursday. If it comes up, one sentence settles it. Don't give your license number in the room unless HR asks for it |
| F2 | "Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | No wording closes this gap, and you have said so yourself. Words: "I haven't taught fourth grade." Then the nearest fact, at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then a plan for your first fourth-grade year, said as a plan and never as something you've done. Add nothing to make the gap feel smaller |
| F3 | "experience in grades 3 to 5 preferred" — typical posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Third grade falls inside the 3–5 range this typical posting prefers. Say it plainly: six years teaching third grade at a public elementary school in Joliet. Labeled [inferred] because the preference comes from a typical posting, not from Halvering |
| F4 | "plan and teach reading, writing, math, science and social studies" — typical posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your material doesn't say which subjects you taught. Answer slot: if you taught all five in your own classroom, say so in your own words. If some were taught by someone else, or not at all, say so plainly and stay with the subjects you did teach |
| F5 | "Panels ask about reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Both quotes are reading work, and they stay at their own scope: you led your grade level's move to a new reading curriculum in 2024, and you've run the after-school reading club for two years. Your material doesn't describe how you teach reading in your own classroom. Answer slot: because the panel says it asks about reading instruction, expect a probe on your daily reading teaching. Describe what you actually do, in your own words. If they ask about a practice you don't use, say so plainly and describe what you do instead |
| F6 | "differentiate instruction using assessment data" — typical posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material doesn't show how you use assessment data. Answer slot: if you group students or change your teaching based on assessment results, say how, in your own words. If you haven't, say so plainly, then say how you would start |
| F7 | "assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Your material doesn't show how assessments shape your teaching. Answer slot: if you've changed what you taught because of what an assessment showed, say what changed and why. If no such time comes to mind, say so plainly and say how you would want assessments to work in your room |
| F8 | "Panels ask about … classroom routines" — district hiring page | none given | none | [grounded] | discovery | Your material doesn't describe your routines. Answer slot: describe the routines you actually run, in your own words. If you have no set routine for something they ask about, say so plainly and say what you would set up |
| F9 | "communicate regularly with families" — typical posting, K12 Jobs Board | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap, but nothing sits behind this CV line yet, so expect a probe. Lead with it in the quote's own terms: every week, you write an email to families. A specific habit is stronger than an adjective |
| F10 | "each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | An email is not a conversation, so don't stretch this. Your words stay with the quote: "I write a weekly email to families." Answer slot: the district's stated belief makes a question about talking with families likely. If you speak with every family, say how and when, in your own words. If you don't, or not with every family, say so plainly and say how you would build it in alongside the weekly email |
| F11 | "work with the grade-level team" — typical posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | none | The curriculum move is grade-level teamwork, in the quote's own terms: you led your grade level's move to a new reading curriculum in 2024. Keep it as a project you led, not a title. If they ask about formal roles: "I haven't been a team lead." Answer slot: if they ask what leading the move involved, say which parts were yours, in your own words. If others did parts of it, say so plainly |

---

## Reading the interviewer

All of this comes from one public speaker page found in a search (see Sources). The two fourth-grade teachers aren't named, so there is nothing to read on them.

- **Principal Dolores Vantongeren.** Principal of Halvering Elementary since 2022. Before that, nine years as a reading specialist. Her 2025 forum talk, *Small Groups, Big Readers*, covered weekly reading conferences in grades 3 to 5.
- **What follows:**
  1. Reading instruction is her own field, so expect the deepest follow-up questions there (C1, B1, D2). Be exact about what you do, because she will know the details.
  2. Her published topic covers grades 3 to 5, which includes both your grade and the one you're applying for. Asking about it (reverse question 2) is a natural, researched question, not flattery.
  3. Don't claim a practice from her talk as your own unless you actually use it. The F5 answer slot covers this.
- **Mirror opportunities:** none offered. Nothing in your fit-snapshot evidence matches her move from reading specialist to principal.

---

## Persona weights

Loop: the district's "How we hire teachers" page and the HR invite both describe one 45-minute building panel with the principal and two grade-level teachers. The page says panels ask about reading instruction, classroom routines and how you work with families. References are taken up after the panel. Weights below are for a panel that blends a hiring-manager role (the principal) with peers (the teachers).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet questions about fourth grade, and about the team-lead question | High. A principal tends to test gaps, and F2 is the biggest gap in your material | Rehearse A1 until it bores you. Open with the plain acknowledgment, follow with the quoted fact, finish with a plan |
| Peer Evaluator | The two teachers: "What would you need from us?", planning together, disagreements | High. Two of the three panelists are your future grade-level peers | Frame it both ways: what you bring them, not only what you need. Talk about how you'd want to work together, not how their team works today |
| Case / Strategist | "A student is two years behind — what do you do?", setting up routines, a family that doesn't respond | High. The district's hiring page names reading instruction, routines and families, and each one turns naturally into a scenario | Clarify, then say the goal, what you'd find out first, what you'd do, how you'd know it worked, and who you'd tell. Think out loud |
| Data-Driven Prober | "How do you group students?", "How do you know the club works?" | Medium. Peers tend to probe this way, but your CV has no figures to dig into | Know what you can and can't say about how you track progress, and say plainly when you don't track something |
| Values / Behavioral | Questions built on "Every Child a Reader", "Families Are Partners", "Teach for Tomorrow, Not for the Test" | Medium. The district says these three beliefs "guide every hire", but its hiring page names no separate values round | Pick real moments from your teaching for each belief. Where none comes to mind, say so |
| Conversational | "Tell us about yourself", friendly openers | Medium. Almost every panel opens this way, and the opener is still scored | Prepare a 90-second arc (G1) built only from your own lines |
| Pressure | Time limits, "how much of that was you?" | Low. Nothing suggests a stress-style panel, but school panels can still press on a gap | Pause, restate the question, hold your quoted fact through two follow-ups, then concede something specific |

---

## Question banks

### A — Skeptic (principal, possibly a teacher)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we believe you're ready for it?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" | **This is the highest-ROI rehearsal in the pack.** Start with the acknowledgment: "I haven't taught fourth grade." Then the fact, at its own scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan: before the first day, learn the fourth-grade standards, ask this team how the year is laid out, and look at where your incoming class finished third grade. Follow-up 1, "Fourth grade is a different year": hold by returning to the six years and the plan, adding nothing. Follow-up 2, "So what exactly carries over?": answer slot. Say in your own words what from your third-grade teaching you'd bring, and if you're unsure whether something carries over, say so. Then concede something specific: you'd be teaching the fourth-grade curriculum for the first time | F2 is the gap a fourth-grade panel can't miss, so some version of this will come up. JD because it scores the position you're applying for |
| A2 | "Why fourth grade, and why leave your current school now?" | EXP | [generic] | Answer slot: give your actual reason, in your own words. If part of it is personal, a short honest version is enough. Don't borrow a reason from this pack. Then move to what draws you to this role, kept to things you can say truthfully | Your material doesn't state a reason for moving, and a Skeptic checks that your motivation hangs together. EXP because it's about your own history |
| A3 | "You haven't been a team lead. How do you see your role on a grade-level team?" | JD | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Acknowledge it: "I haven't been a team lead." Then the quote, at its own scope: you led your grade level's move to a new reading curriculum in 2024, a project and not a title. Then how you'd want to work with this team, as a plan: as someone new to fourth grade, you'd be learning from them first. Answer slot: if they ask what leading the move involved, say which parts were yours. If others did parts, say so plainly | F11 holds both quotes, and a panel with two future teammates will want them reconciled. JD because it scores the grade-level-team duty |
| A4 | "Which part of a fourth-grade teacher's job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Answer slot: name the area you'd honestly pick, in your own words, and say what you'd do about it in your first months. Fourth grade itself is one you've already named. Don't offer a fake weakness dressed up as a strength | A standard Skeptic stem, aimed at F2. The honest version is safer than a rehearsed dodge. JD because it scores readiness for the listed job |
| A5 | "This role teaches reading, writing, math, science and social studies. Which of those have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot, per F4: if you taught all five in your own classroom, say so in your own words. If some were taught by someone else, or not at all, say so plainly and stay with the subjects you did teach. Then, for anything you haven't taught, give a plan to prepare | F4's subject list comes from a typical posting, so the real Halvering job may differ. JD content, labeled [inferred] |

### B — Peer Evaluator (the two fourth-grade teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about leading your grade level's move to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F5 and F11. The beats are what the quote states: your grade level, a new reading curriculum, 2024, and you led the move. Tell them in your own words. Answer slot: say which parts of the move were yours to do, in your own words. If others did parts of it, say so plainly. If they ask how other teachers experienced it and you don't know, say so | The most relevant thing on your CV for a district changing its grades 3–5 reading curriculum, and for a principal who was a reading specialist. EXP because they're testing what was actually you |
| B2 | "What would you need from us in your first month, and what would you bring us?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" | Answer both halves. Need: their fourth-grade knowledge, since you haven't taught fourth grade. Bring: six years of third-grade teaching, so you know where their students are coming from, and the experience of leading your grade level's move to a new reading curriculum in 2024. State what you did and let them draw the conclusion. Don't call it proof of anything | The classic peer reciprocity question. F2 and F11 are what they're weighing. JD because it scores the team duty |
| B3 | "Tell us about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | Selection scaffold: pick a time with a real disagreement, how you raised it, what happened, and a working relationship still intact afterward. If no such time comes to mind, say so plainly, then say how you would handle one | Peers want to know how you disagree with equals. Nothing in your material covers this, so it's a scaffold. EXP because it asks about your past |
| B4 | "When the team plans something together, how do you handle credit and the ideas that don't get picked?" | CASE | [generic] | Answer as an approach, not a past story: share the work openly, credit the team in public and individuals by name, and when your idea isn't chosen, commit to the plan and raise any concerns once, early. The question needs no claim about your past, so the guidance makes none | A Peer Evaluator stem about seams and credit. CASE because it's asked as a judgment call |

### C — Case / Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's September. One of your fourth graders reads about two years below grade level. Walk us through your first month with them." | CASE | [generic] | Structure it: what you'd find out first (assessment results, last year's teacher, the family), what you'd change in class, who in the building you'd bring in, how you'd know it was working, and how you'd keep the family informed. Tie it to the district's "Every Child a Reader" belief by name. Think out loud, and stop to ask one clarifying question | Reading instruction is the district's first named panel topic and the principal's own field. CASE because it's a live problem, with JD content (differentiation, F6) |
| C2 | "Walk us through your first two weeks of routines with a new fourth-grade class." | CASE | [generic] | Structure: which routines come first and why, how you teach and practice them, how you hand responsibility to students, and how you'd adjust for fourth graders. Answer slot, per F8: if you run routines like these in third grade, describe the ones you actually use. If you don't have one for something they ask about, say what you would set up | Routines are named on the district's hiring page. CASE delivery, JD content |
| C3 | "A family hasn't answered your emails or come to conferences. What do you do?" | CASE | [grounded] "I write a weekly email to families" | You can mention your weekly email to families as your starting point. Then structure: try another channel, ask the family what works for them, check whether language or timing is the barrier, keep every contact about the child, and record what you tried. Name "Families Are Partners", and the district's goal of speaking with every family each term, as what you'd be working toward | F10's district belief makes this a likely scenario. CASE because it's a live problem |
| C4 | "The district is bringing in a new grades 3–5 reading curriculum in fall 2027. How would you help this team get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan: the board adopted a three-year literacy plan in August 2026, with a new grades 3–5 reading curriculum from fall 2027. Then mention, at its own scope, that you led your grade level's move to a new reading curriculum in 2024. Answer slot: say what you'd do differently next time, in your own words. If you're unsure, say so. Then give an approach for this team, as a plan. If they don't raise it, a reverse question (4) lets you bring it up | The one strategy question research makes possible, and it sits right next to F11. CO content, CASE delivery |

### D — Data-Driven Prober (the teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you use assessment data to decide who needs what?" | JD | [inferred] | Answer slot, per F6: if you group students or change your teaching based on assessment results, say how, in your own words: what you look at, how often, what changes. If you haven't, say so plainly, then say how you would start. Name no tool or method you haven't used | F6 comes from a typical posting, and peers probe this way. JD content, labeled [inferred] |
| D2 | "What do you look at to tell whether your reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Start in the quote's terms: an after-school reading club you've run for two years. Answer slot: if you keep any record of how the club is going, say what it shows and how you counted it. If you don't, say so plainly, then say how you'd tell. Don't quote a figure you can't back up | The club is one of your reading lines (F5). A prober will ask how you know it helps. EXP because it tests a CV claim |
| D3 | "What goes in your weekly family email, and how do you know families read it?" | EXP | [grounded] "I write a weekly email to families" | Answer slot: say what goes in it, in your own words. If you know how many families read it, say how you know. If you don't know, say so plainly and say what you'd like to learn about it | F9 is a CV line with nothing behind it yet, and "Families Are Partners" makes it likely to come up. EXP because it tests the claim |

### E — Values / Behavioral (any panelist)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We say every child a reader. Tell us about a student who struggled with reading and what you did." | VAL | [generic] | Selection scaffold: pick one student, what you noticed, what you changed, what happened, and what you'd do again. Use "I" for what you did. If no such student comes to mind, say so plainly, then give the nearest thing your experience carries, or how you would handle it | Themed on the district's published belief "Every Child a Reader". VAL because it scores past behavior against that belief |
| E2 | "Families Are Partners is one of our beliefs. When has a family changed how you taught their child?" | VAL | [generic] | Selection scaffold: pick a time a family told you something that changed what you did in class. Give what they said, what you changed, and the result. If no such time comes to mind, say so plainly, then say how you'd invite that kind of input | Themed on the published belief "Families Are Partners", which F10 also draws on. VAL |
| E3 | "We say teach for tomorrow, not for the test. When have you put real learning ahead of test prep?" | VAL | [generic] | Selection scaffold: pick a decision where you chose deeper teaching over test drill, what you weighed, and how it went. If no such time comes to mind, say so plainly, then say how you'd balance the two. This also covers F7's answer slot | Themed on the published belief "Teach for Tomorrow, Not for the Test". VAL |

### G — Conversational (usually the opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, tell us a bit about yourself and how you got here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families" | A 90-second arc built only from your lines: six years teaching third grade at a public elementary school in Joliet; you led your grade level's move to a new reading curriculum in 2024; you've run the after-school reading club for two years; you write a weekly email to families. Close with why this role: answer slot, your actual reason, in your own words | Every panel opens somewhere. A tight opener sets up reading and families, the panel's named topics. EXP because it's your history |
| G2 | "Quick one: your license covers fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | One sentence: yes. An Illinois PEL with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. Check your license record yourself before Thursday so you're certain | F1 is the only stated requirement in the invite. JD because it's the gate |

### H — Pressure (low likelihood, rehearse anyway)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" "I write a weekly email to families" | Pause. Don't argue the comparison. If they push on the gap, concede it plainly: "I haven't taught fourth grade." Then three facts at their own scope: six years teaching third grade, leading your grade level's move to a new reading curriculum in 2024, and a weekly email to families. Close with your first-year plan from A1. If they push twice, hold on those facts and concede only the specific point: you'd be new to the fourth-grade curriculum | The time-boxed version of A1, aimed at F2. JD because it scores fit for the position |
| H2 | "You say you led the curriculum move. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which parts were yours and which were other people's, in your own words. If others did much of it, say so. The honest answer is a limit, not a confession. Through two follow-ups, keep returning to what you actually did and never add to it. Concede the specific parts that belonged to others | F11 is your strongest team-related line, so it's where attribution gets tested. EXP because it probes what was really you |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 license with elementary endorsement | G2 |
| F2 fourth-grade position | A1, A4, H1 |
| F3 grades 3–5 experience | A1, G1 |
| F4 five subjects | A5 |
| F5 reading instruction | B1, C1, D2, E1 |
| F6 differentiate using assessment data | C1, D1 |
| F7 assessments inform teaching | D1, E3 |
| F8 classroom routines | C2 |
| F9 regular family communication | D3, G1 |
| F10 speak with every family each term | C3, E2 |
| F11 work with the grade-level team | A3, B1, B2, B3, B4, H2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | For Principal Vantongeren: "You came to the principal's role after years as a reading specialist. What do you most want to see in a fourth-grade reading block?" | It's tied to her own career. It shows you researched her, and it gets you her standard for the panel's main topic |
| R2 | "I saw your 2025 talk on weekly reading conferences in grades 3 to 5. How do conferences work in fourth grade here?" | It turns her published topic into a conversation about practice, and her answer tells you what she'll expect in your room |
| R3 | For the two teachers: "What could a new teammate do in the first month that would actually help your team?" | A reciprocity question for peers. It shows you're thinking about their workload, not only your own needs |
| R4 | "With the new grades 3–5 reading curriculum coming in fall 2027, how is the fourth-grade team planning to get ready?" | It shows you know the board's literacy plan, and it gives you a natural opening to mention the 2024 move you led |
| R5 | "How do fourth-grade teachers here make the goal of speaking with every family each term work alongside the family reading night?" | It connects two published district commitments and shows you've thought about the workload behind them |
| R6 | "What does planning together look like on this team from week to week?" | It's practical, it's peer-facing, and it tells you how the job really runs |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | "I haven't taught fourth grade." No slot |
| Has been a team lead or grade-level lead | A negative you stated, F11 | "I haven't been a team lead." No slot |
| Chose the new reading curriculum, or ran the whole adoption | Inflated form of F11's quote | F11's quote at its own scope. Your material says you led your grade level's move, not who chose the curriculum or what the move involved. B1 and H2 only ask which parts of the move were yours |
| Speaks with every family each term | Inflated form of F10's quote | F10's quote at its own scope: a weekly email to families. C3's slot asks only how you would build conversations in |
| The reading club raised students' reading levels or scores | Inflated form of F5's club quote | F5's quote at its own scope: an after-school reading club you've run for two years. D2's slot asks only what records you keep |

---

## Sources

**Provided:** your HR invite and resume text (pasted).

**Searches and fetches sent:**
- "Orrinsford Community School District mission values" → https://orrinsfordschools.example/about/mission-and-beliefs (fetched)
- "Halvering Elementary School Orrinsford teacher interview" → https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Dolores Vantongeren principal Halvering Elementary" → https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Orrinsford Community School District news 2026" → https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Illinois fourth grade teacher job description elementary school district posting" → https://k12jobsboard.example/listings/fourth-grade-teacher (fetched)

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three beliefs by name, fetched: they shape the E bank, F7, F10, C1 and C3. No values cheat sheet, because no values-style round was documented |
| 2. Interview process | yes | The district hiring page sets the loop: one 45-minute panel, principal plus two grade-level teachers, on reading, routines and families. Persona weights, F5 and F8 |
| 3. District strategy and news | yes | The August 2026 literacy plan: C4, R4 and R5 |
| 4. Dolores Vantongeren | yes | Speaker page: reading-specialist background and 2025 talk. The interviewer read, R1 and R2 |
| 5. Representative fourth-grade JD | yes | No posting was supplied. A typical posting supplies F3, F4, F6, F9 and F11, all labeled [inferred] |

---

## Upgrade menu

- **Halvering's actual job posting** → F3, F4, F6, F9 and F11, and questions A5 and D1, change from [inferred] to [grounded], and any duty the real posting adds gets its own question
- **Names of the two fourth-grade teachers** → persona weights per panelist, and a reverse question for each
- **How much prep time you have before Thursday** → a prioritized prep schedule, so the few things that matter most get done first
- **Your own answers to the answer slots** (your reason for moving, which subjects you've taught, how you use assessment data, your routines, family conversations, what leading the 2024 move involved) → F4 through F8, F10 and F11, plus A2, A5, B1, C2, D1 and H2, become story-mapped from your words instead of slots
- **Your own check of your license record** → F1's confidence rises from medium to high
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → the content of Principal Vantongeren's talk, more on the 2027 curriculum, and wider district context for C4
- **A tuesday-dossier.md** → verified evidence and a prohibited-claims list from an evaluation of this role. It would sharpen A1's objection, but this pack doesn't need it
