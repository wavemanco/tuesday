Quick update: I'm going through the prep framework's rules before building your pack. There's also something in the Telegram invite I'll flag first.
Before the prep, one thing in the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", and that "if you are successful your offer and onboarding will be completed in this chat as well." Hiring that runs wholly through a chat app is a known scam pattern. A Telegram chat on its own doesn't show who you're dealing with, and the invite may not come from who it names. Until you've confirmed it, don't send any money, ID documents or bank details through that chat. To check, contact Lumenvale Software using contact details you find yourself on its own website or careers page, not through the Telegram chat or anything Marcus sends you, and ask whether this invite came from them. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you'd like the invite checked more closely, job-underwriter can do that as a separate request.

I've saved your prep pack as `lumenvale-software_customer-support-specialist_interview_pack.md`. I treated it as a round with the lead of the team you'd join, held as a text chat. I couldn't do any web research on Lumenvale because the searches weren't approved, so the company-specific questions are general ones.

- **What to practise most:** question A1, "you haven't worked for a software company." Start by saying that plainly. Then point to what you do have: 3 years as a customer service advisor and daily Freshdesk use. Then explain how you'd learn their product, as a plan. The pack walks through two follow-ups.
- **The format:** a text chat means every message you send is a sample of the "clear written communication" the ad asks for. Practise typing your answers. In B1 you write a real reply to an angry customer.
- **Escalations:** nothing you've told me shows escalation work yet. E1 and B3 help you either pick a real example or say plainly how you'd handle one.
- **Freshdesk:** the ad accepts "a similar ticketing tool", so say Freshdesk confidently. Never suggest you've used Zendesk.

If you want to practise, I can play the Skeptic and run A1 with you live in chat.
I can also save a `tuesday-dossier.md` that records the gaps this prep found, so you can bring it to later sessions.
If you'd like the pack as a Word document, I can convert it.

Is the support team lead the person you'd report to, or a separate lead? The answer changes how the question sets are weighted. And can you paste the full text of the job ad? It may list requirements your summary left out.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Round:** text-chat interview with the support team lead (as the invite describes it). Interviewer name not known. Relationship assumed: the lead of the team you'd join, treated as a hiring-manager round.

---

## How to use this pack

- **Personas** describe *how* a question is asked (who's asking, in what style). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioural or values. Does your past behaviour show how you work?
  - **EXP**: work-experience deep-dive. Does what you said about your experience hold up under questions?
  - **JD**: role-driven. Can you do the job the ad describes, including its gaps?
  - **CO**: company knowledge. Have you done your homework on Lumenvale?
  - **CASE**: live problem. How do you reason through a support situation on the spot?
- Provenance labels: `[grounded]` traces to what you told me. `[inferred]` is this pack's own derivation, and the derivation is named. `[generic]` is a common pattern for support roles, with no claim about Lumenvale.
- **The guidance is scaffolding, not a script.** Where a cell says "answer slot", only you know the true answer. Give it in your own words, and if the honest answer is "no" or "I don't know", say that.
- **The format matters.** The invite says the interview is a text chat. Every message you send in it doubles as a sample of your "clear written communication", which the ad asks for. Practise typing your answers, not just saying them: short paragraphs, no walls of text, and check before you hit send.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (the job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | This meets the requirement, but nothing has been inspected behind it, so expect a probe. Lead with the quote's own terms: three years, customer service advisor, energy supplier. Don't rename it as technical support or as anything it wasn't |
| F2 | "experience with Zendesk or a similar ticketing tool" (the job ad, as you summarised it) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | The ad accepts a similar tool, and you use one every day. Say "Freshdesk, every day", plainly. Your material says Freshdesk, not Zendesk, and the words stay there |
| F3 | "clear written communication" (the job ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Emails are in the quote, but the material doesn't show how clear they are, and the quote doesn't split calls from emails. Answer slot: the ad's written-communication line makes a probe on your writing likely. If asked, describe the emails you actually write, in your own words. If you don't know how your day splits between calls and emails, say so rather than estimating. In a text-chat interview, the chat itself is the strongest evidence you'll give |
| F4 | "confidence handling escalations" (the job ad, as you summarised it) | none given | none | [grounded] | discovery | Strong evidence here is one specific case: what made it an escalation, what you did, how it ended and which part was yours. Answer slot: the ad's escalation line makes this probe close to certain. If you have handled one, tell it in your own words. If none comes to mind, or it wasn't yours to handle, say so plainly and say how you would handle one |
| F5 | Supporting a software product. This is the role's setting, not a requirement in the ad as you summarised it | "I've never worked for a software company" (your message) | none | [grounded] | capability | No wording closes this gap, and you have said so yourself. Words: "I haven't worked for a software company." Then describe how you would learn the product, as a plan, never as something you've done. Add nothing to make the gap feel smaller |
| F6 | Sharing knowledge with teammates. This is common in support teams, not in the ad as you summarised it | "I trained four new starters on our refunds process last year" (your message) | medium | [generic] | none | Lead with the quote's own terms: four new starters, the refunds process, last year. Nothing has been inspected behind it, so expect a probe on what it involved |

---

## Persona table

The weights rest on one source, the invite's own words: one session, "a text chat here with our support team lead". A team lead usually weighs capability and the risk in your gaps, so Case/Strategist and Skeptic lead. No values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up in a text chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "I see you haven't worked in software…", "why us, why now" | Highest. F5 is the clearest gap between your background and a software company, and a team lead buying capability will probe it | Rehearse A1 until it's boring. Plain acknowledgment, then what F1, F2 and F6 actually carry, then a ramp plan said as a plan |
| Case/Strategist | "A customer writes in saying…", "reply to them here", "what would you do first" | High. A support lead can test the real job live, and a text chat makes "draft the reply" easy to ask | Clarify, then structure, then answer. Type the actual reply when asked to draft one. Name what you'd check before you act |
| Conversational | Friendly opener: "tell me about yourself" | Medium. Most chats open this way, and casual answers are still scored, here on your writing too | A pre-written arc (C1) of three or four short lines. Treat "what made you apply" as scored |
| Data-Driven Prober | "How is that 60 counted?", "how much of it is written?" | Medium. F1's figure is the one number in your background, and the written split matters for this role | Know what you can and can't say about how the figure was counted. Say plainly when you don't know |
| Values/Behavioral | "Tell me about a time…" questions on escalations or hard answers | Low to medium. There's no values round, but the ad's escalation line invites a story question | One real story where you have one. Where you don't, say so and say how you would handle it |
| Pressure | "In two lines, why you?" or a challenge to your motives | Low. A text chat blunts interruption, but a deadline or a blunt challenge still works in writing | Pause before typing. Hold what your quotes carry through two follow-ups, then concede the specific gap (F5), never the whole case |
| Peer Evaluator | "What would you hand engineering?", teammate scenarios | Low. The lead is weighing what you add to the team's load | Talk about what you'd give the team, not only what you'd need from it |

---

## Question banks

**Highest-ROI prep in this pack: A1.** Some form of "you haven't worked in software" is the objection most likely to be raised with you. A calm, rehearsed answer to it changes the interview.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see you haven't worked for a software company. How would you get up to speed supporting our product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | **Deepest rehearsal.** Open with the limit before they press: "I haven't worked for a software company." Then what you have, in the quotes' own terms: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then a ramp plan, said as a plan: use the product yourself, read the help centre, ask the team for the most common ticket types, and shadow tickets before you take them alone. **Follow-up 1:** "So have you ever troubleshot a technical problem?" Answer slot: if you have, say what it was and how you did it, in your own words. If not, say so plainly and come back to the customer work you did. **Follow-up 2:** "Why not hire someone with SaaS support experience?" Hold: don't claim your background beats theirs. Concede the specific thing ("product knowledge is what I'd be learning") and keep the rest of the case: the years, the tool, the plan | F5 is the gap a software company's team lead will notice first. It is JD-typed because it scores whether you can do the listed job, gap included. Three levels deep because the second follow-up is where candidates either fold or bluff |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the real one, which matches A1: knowing the product. "I haven't worked for a software company, so the product itself is what I'd be learning first." Then one line of the plan. Don't offer a disguised strength, because a team lead will read it as dodging | Follows from F5, and from how common this stem is. JD because it asks you to grade yourself against the role |
| A3 | "The ad mentions Zendesk. What have you used?" | JD | [grounded] "I use Freshdesk every day" | "I use Freshdesk every day." Answer slot: if asked what you do in it day to day, describe your actual routine, in your own words. If there are parts of the tool you don't use, say so. You can add how you'd learn Zendesk, as a plan. Never say or suggest you've used Zendesk | F2 meets the "or similar" clause. The risk is stretching it under pressure, which is why "Has used Zendesk" is on the prohibited list |
| A4 | "Why move into a software company, and why now?" | EXP | [generic] | Give your actual reason, in your own words. This pack holds none, so it supplies none. Keep it forward-looking (what draws you to this work) rather than about what you're leaving. If part of the honest answer is that you want a change of sector, say that plainly | A standard Skeptic probe for anyone changing sector, sharpened by F5. EXP because it scores whether your story holds together |
| A5 | "Our customers can be technical. What do you do when you don't know the answer?" | CASE | [generic] | Structure it: say so honestly to the customer, tell them what happens next and when, find the answer (internal docs, a colleague, escalation), then follow up. Answer slot: if you have a real time you didn't know the answer, tell it in your own words. If none comes to mind, say so and walk through how you would handle it | Comes from F4 and F5 together: escalation is the ad's line, and not knowing the answer is the honest scenario for anyone new to a product |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes: 'I've been charged twice and I want it fixed NOW.' Reply to them here as if I'm the customer." | CASE | [generic] | Type the actual reply. Acknowledge the problem in one line, say what you're doing now, ask for the one detail you need (account email or invoice number), and give a timeline only if you could really commit to it. Keep it short, warm and without jargon. Then, outside the reply, tell the interviewer what you'd check before sending | A text chat makes this question cheap to ask, and it tests F3 directly. CASE because it's a live problem from the role |
| B2 | "A customer reports a bug you can't reproduce, and says it's blocking their whole team. Walk me through what you do." | CASE | [generic] | Clarify: exact steps, device or browser, screenshots, when it started, who is affected. Check for known issues. Try to reproduce it. If you can't, escalate with a clean summary. Set expectations with the customer and follow up. Say each step out loud before you go deeper | This is the core of software support, and the place F5 shows if you haven't thought it through. `[generic]` because nothing here describes Lumenvale's own process |
| B3 | "When would you escalate a ticket, and when would you keep it?" | JD | [grounded] | Give criteria, not a feeling: outside your access or knowledge, a risk to money, data or security, a customer asking for someone more senior, or no progress within a set time. Then say what you'd hand over so the customer doesn't repeat themselves. This is a "how would you" question, so it needs no story. Keep any example for E1 | Scores the ad's "confidence handling escalations" (F4). JD-typed because it maps straight onto that requirement |
| B4 | "You log in to 40 open tickets, and three are marked urgent. How do you decide what to do first?" | CASE | [generic] | Check the three urgent ones are really urgent (what's broken, how many people it affects), reply to the urgent ones first even if only to acknowledge them, then work the rest by age and impact. Say how you'd flag it if the queue is beyond one person | Tests prioritisation, which every support lead cares about. `[generic]` because nothing here claims your current queue works this way |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about yourself and what you do now." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Write three or four short lines, using the quotes' own terms: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day, and training four new starters on the refunds process last year. Close with why this role, in your own words. Answer slot: the reason is yours to give, and this pack supplies none. Keep the whole answer short enough to read in one go | The opener in almost any chat, and your first writing sample. Every beat sits on F1, F2 or F6 |
| C2 | "What do you enjoy most about support work?" | EXP | [generic] | Your own answer, in your own words. Make it concrete: one moment or kind of ticket you actually like, not "helping people". If you can't name one easily, say what draws you to the work instead | Casual on the surface but scored on genuine interest. EXP because it asks about your own working life |
| C3 | "What do you know about Lumenvale, and what made you apply?" | CO | [generic] | Before the interview, read Lumenvale's own website yourself: what the product does, who uses it and what its help centre looks like. Mention one specific thing you noticed. This pack holds no research on the company, so it gives you nothing to say about them, and guessing at the product would be worse than saying less | A predictable homework check. CO because it scores preparation. `[generic]` because research couldn't run (see Sources) |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You mention around 60 calls and emails a day. How is that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the figure exactly as you gave it: "around", and calls and emails together. Answer slot: how it was counted, what makes it go up or down, and the part of it you'd defend least, all in your own words. If you don't know how it was counted, say so. Don't firm up "around" into an exact number | F1's figure is the one number in your background, and figures attract probes. EXP because it checks what you've said |
| D2 | "How much of that is written, versus phone?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, give it in your own words. If you don't, say so plainly ("I haven't measured the split") rather than estimating. Then point to the chat itself, since this interview is in writing | This is where F3's gap would surface. EXP because it tests the figure's make-up, not your capability |
| D3 | "You trained four new starters on refunds. What did that involve, and how did you know it had worked?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats your sentence carries: four new starters, the refunds process, last year. Answer slot: how you trained them and how you knew it worked. If there was a check, say what it was. If there wasn't one, say so plainly and stay with what you did. Don't describe it as designing a course or running a programme unless that's what happened | F6 is a concrete line, and concrete lines get probed. Being precise here earns trust you'll need for A1 |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you handled an escalation." | JD | [grounded] | Selection scaffold: pick a real case with a named stake (an upset customer, someone asking for a manager, a refund outside policy), what you did, how it ended and exactly which part was yours. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The story form of F4, close to certain given the ad's line. JD-typed because it scores a stated requirement in story form |
| E2 | "Tell me about a time you had to give a customer an answer they didn't want to hear." | VAL | [generic] | Selection scaffold: a real moment where the answer was no, what you said, how you kept the customer on side, and how it ended. If no such time comes to mind, say so plainly and walk through how you would do it | A common support values probe. VAL because it scores how you behave, not what you know |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Two lines: why you over someone who has already done SaaS support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Stick to two lines. Line one: the quotes' terms (three years as a customer service advisor, Freshdesk every day). Line two: the plan for the product. If pushed, concede the specific gap ("I haven't worked for a software company") and keep the rest. Don't claim to be better than them, only clear about what you bring | The time-boxed version of A1, built on F1, F2 and F5. Tests whether you can stay concise under a deadline |
| F2 | "You trained four people. Aren't you really after a team lead job?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold your actual interest, in your own words. If it's this role, say so plainly. Keep the training at its own size: four new starters, the refunds process, last year. Answer slot: if you do want to lead a team one day, you can say so honestly without making the training sound bigger | Tests whether F6 gets inflated under a challenge to your motives, which is why it's on the prohibited list |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When you escalate to engineering, what would you put in the ticket so they don't have to come back to you?" | CASE | [generic] | A clean handover: what the customer reported in their words, steps to reproduce, what you already tried, account and environment details, screenshots, how many customers are affected and how urgent it is. Say you'd keep the customer updated so engineering doesn't have to | The peer-load question at a software company. Covers F4's escalation from the team's side |
| G2 | "A teammate keeps closing tickets that customers then reopen. What do you do?" | CASE | [generic] | Check the pattern first (is it really them, which ticket types). Raise it with them directly and privately, without blame. Suggest something practical, like a shared checklist. Only take it to the lead if it continues. Show both spine and tact | Tests how you handle disagreement with an equal, which peers and leads both watch for |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: 2+ years in customer support | A1, C1, F1 |
| F2: Zendesk or a similar ticketing tool | A3 |
| F3: clear written communication | B1, D2, and every message in the chat |
| F4: confidence handling escalations | B3, E1, A5, G1 |
| F5: supporting a software product | A1, A2, F1, B2 |
| F6: knowledge sharing | D3, F2 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What kinds of tickets does the team see most, and which are the hardest?" | It shows you're already picturing the work, and the answer tells you what to learn first (A1's plan) |
| "How does escalation to engineering or product work here?" | It ties straight to the ad's escalation line and shows you think about handovers |
| "Which ticketing tool does the team use, and how is the queue organised?" | A practical question that links to F2 and shows you expect to ramp up quickly |
| "How do new support hires learn the product in their first few weeks?" | It turns F5 into a conversation about onboarding rather than a weakness |
| "What does a strong first 90 days look like for this role?" | It shows you're thinking about delivery, and the answer gives you something to come back to in your closing message |
| "Are there further steps after this chat, such as a call or video interview?" | It tells you whether to prepare spoken answers as well as written ones |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for a software company or supported a software product | A negative you stated (F5) | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope. The material says Freshdesk, not Zendesk. A3's slot stays with your actual routine in Freshdesk |
| Has technical support or troubleshooting experience | Inflated form of F1 (a change in the kind of work) | F1's quote at its own scope: customer service advisor at an energy supplier. A1's first follow-up slot stays with what you actually did |
| Handles 60 written tickets or emails a day | Inflated form of F1's figure (the number sliding onto a different noun) | Keep it whole: "around 60 calls and emails a day". D2's slot stays with the split as you know it |
| Designed or ran the refunds training programme, or held a trainer or lead role | Inflated form of F6 | F6's quote at its own scope: four new starters, the refunds process, last year. D3's and F2's slots stay inside that |

---

## Sources

- **Provided:** your message (the invite text, your summary of the job ad's requirements and your background).
- **Searches sent:** "Lumenvale Software company values" (refused); "Lumenvale Software interview process customer support" (refused); "Lumenvale Software news" (refused). No fetches.
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Search refused. It would have themed VAL questions with Lumenvale's own values. No values cheat sheet either way, since no values-style round is detected |
| 2. `Lumenvale Software interview process customer support` | unavailable | Search refused. It would have confirmed or added rounds beyond the one session the invite names |
| 3. `Lumenvale Software` recent news | unavailable | Search refused. It would have given C3 and B2 something specific about Lumenvale's product and moved them off `[generic]` |
| 4. `{interviewer name} Lumenvale Software` | n/a | The support team lead isn't named, so there was no query to form. No interviewer read |
| 5. representative Customer Support Specialist JD | skipped | Your summary of the ad supplied the four requirements the fit snapshot and JD questions rest on |

---

## Upgrade menu

- **The full job ad text:** F1 to F4 get quoted from the ad itself rather than your summary, and any requirement the summary left out gets its own question.
- **Whether the support team lead would be your manager or a peer lead:** the persona weights are recomputed. A peer lead moves Peer Evaluator and Prober up.
- **The team lead's name:** an interviewer read from their public professional footprint, plus a reverse question tied to their own path.
- **Permission to search (targets 1 to 3):** Lumenvale's values, process and recent news. C3 and B2 become specific to Lumenvale, and VAL questions get themed on its values.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It adds a strategy brief, so the CO and CASE questions become Lumenvale-specific.
- **Your answers to the slots in F3 and F4** (your written versus phone split, and an escalation you handled, if there is one): F3, F4, D2 and E1 move from slots to story-mapped guidance.
- **Your reason for moving into software:** A4 and the close of C1 become story-mapped rather than scaffolds.
- **A `tuesday-dossier.md`:** it carries verified evidence and the prohibited-claims list into later sessions, and gives an evidence-derived objection for the highest-ROI drill.
