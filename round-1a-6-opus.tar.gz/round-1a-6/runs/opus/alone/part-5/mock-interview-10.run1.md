Quick update: I'm running a few searches on Lumenvale Software's values and interview process, then I'll build your prep pack.
Before the prep, one thing in the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run entirely through chat is a known scam pattern. A chat on its own doesn't show who you're talking to, and the message may not come from Lumenvale Software. Until you've checked, don't send any money, documents or bank details through the chat. To check, find Lumenvale's contact details yourself on its own website or the careers page you applied through. Don't use anything from the Telegram chat. Then ask them whether this interview and Marcus Hale are really theirs. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite looked at properly, job-underwriter can check it as a separate request.

I've saved your prep pack as `Lumenvale_customer-support-specialist_interview_pack.md`. I built it assuming the support team lead would be your manager, because the invite doesn't say. I tried three web searches on Lumenvale's values, interview process and recent news, but search permission wasn't granted. So the values and scenario questions are general patterns for this kind of role, not taken from Lumenvale itself.

The pack covers:
- **Fit snapshot:** your 3 years of experience and daily Freshdesk use meet the ad's first two requirements. Clear writing and handling escalations are where your background doesn't say much yet.
- **Highest-ROI prep:** A1, "You haven't worked for a software company before…". It's a plain admission of the gap, then the experience you actually have, then a plan for learning the product.
- **22 practice questions** across seven interviewer styles. Several ask you to type a reply on the spot, which fits a text interview.
- **Six questions for you to ask them**, and a list of claims the pack deliberately won't coach (for example, "60 emails a day" when you said "around 60 calls and emails a day").

Say the word and I'll play the skeptical interviewer on A1, so you can practise it live.
I can also save a `tuesday-dossier.md` file recording the gaps this prep turned up, to carry into later sessions.
If you'd like the pack as a Word document, I can convert it.

Would the support team lead be your manager, or more of a peer on the team? The answer changes how the question banks are weighted. And if you can paste the full job ad, any requirements your summary left out will get their own rows and questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Round:** one interview with the support team lead, held as a text chat (from the invite's wording). Your relationship to the lead isn't stated, so this pack assumes they would be your manager.
**Interviewer:** not named.

## How to use this pack

- **Personas** describe *how* a question gets asked (who asks it, and in what style). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behavioural and values. Does your past behaviour show what the company says it values?
  - **EXP**: deep-dive into your experience. Do your claims hold up, and which part was actually yours?
  - **JD**: the job ad's stated requirements. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Strategy, product and recent news.
  - **CASE**: a live problem from the role, worked through in front of them.
- Provenance labels: **[grounded]** means it traces to something you gave me. **[inferred]** means it's derived, and the derivation is named. **[generic]** means it's a common pattern for this kind of role, with no claim about Lumenvale.
- The invite describes a text chat, so you will type every answer. Short paragraphs of 3 to 5 lines read better than one long block. Your typing is also a live sample of the "clear written communication" the ad asks for.
- The guidance is scaffolding, not a script. Answer in your own words, and use only what you actually did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you summarised it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: three years, customer service advisor, an energy supplier, around 60 calls and emails a day. It's medium only because nothing behind it has been inspected, so expect a probe on the figure. Keep "around", and keep calls and emails together. The 60 is not 60 emails |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you summarised it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap in the ad's own terms, because the ad accepts a similar tool. Your words: "I use Freshdesk every day." Never call it Zendesk experience. Answer slot: the ad's ticketing line makes a question about what you do in the tool likely. Describe what you actually use it for day to day, in your own words. If there's a part of it you don't use, say so plainly and stay with your daily use |
| F3 | "clear written communication" — the job ad, as you summarised it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows that emails were part of your daily contacts. It doesn't show how clear they were, and that is the pack's observation, not words for you. Answer slot: the ad asks for clear writing, so expect a question on how you write replies. If you have a way you structure a reply, describe it in your own words. If you don't have a set approach, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the job ad, as you summarised it | none given | none | [grounded] | discovery | Your material doesn't say either way whether you've handled escalations. Strong evidence would be one specific case: what made it need more than a standard answer, what you did, and how it ended. Answer slot: the ad names escalations, so expect "tell me about one". If you have handled one, tell it in your own words. If not, say so plainly and walk through how you would handle one (B2) |
| F5 | Familiarity with supporting a software product. This is a common expectation for the role type and isn't in the ad | "I've never worked for a software company" — your message | none | [grounded] | capability | Your words: "I haven't worked for a software company." Then say how you would learn the product, framed as a plan and never as something you've done. Don't add anything to make the gap look smaller. Never suggest your energy-supplier work was software work |

## Persona table

| Persona | How it shows up in a text chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Calm typed questions about the gap: no software background, Freshdesk rather than Zendesk | High. A team lead hiring for their own team is reducing risk, and F5 is the visible gap | Practise A1 until it feels boring. Give the plain acknowledgment first, then only what your quotes carry, then a ramp plan |
| Case / Strategist | "A customer writes in saying… what's your reply?" | High. Hiring-manager rounds lean on live problems, and a text chat makes "write me the reply" an easy test | Clarify, then structure, then answer. Type the reply as you would actually send it |
| Conversational | "So, tell me about yourself", in a friendly tone | Medium. Almost every chat opens this way, and it is still scored | Prepare a short arc built only from F1's quotes |
| Data-Driven Prober | "How is that 60 a day counted?" | Medium. The only figure in your background is the first thing a careful reader picks up | Know what you can and can't say about the figure, and say "around" |
| Pressure | "In two lines: why you over someone with software experience?" | Low. Interrupting is hard in a typed chat, but setting a tight limit isn't | Take a breath, anchor on your quotes, hold your position, then concede the specific gap |
| Values / Behavioural | "Tell me about a time you…" | Low. The invite names no values round, and Lumenvale's values couldn't be researched (Sources) | Use selection scaffolds with an honest way out. Don't invent a story |
| Peer Evaluator | "What do you put in a ticket before handing it on?" | Low. The lead may also act as a future peer on the queue | Talk about principles for handoffs, not invented history |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company before. Why should we expect you to pick up our product quickly?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Start with the plain acknowledgment: "I haven't worked for a software company." Then hold with only what your quotes carry: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, and Freshdesk every day. Then give a ramp plan, framed as what you *would* do, in your own words (for example, how you'd learn the product in your first weeks). Follow-up 1, "our tickets are more technical": don't claim technical troubleshooting you haven't said you did. Concede that product knowledge is the thing you'd be learning, and go back to the plan. Follow-up 2, "so why take the risk?": hold on the same quotes without folding or adding to them. Don't say your experience "proves" anything. Describe it and let them draw the conclusion | F5 is the gap a software employer sees first, so this objection will come up in some form. It's tagged JD because it scores readiness for the listed job. It gets three levels of rehearsal because it's where the pull to overstate is strongest |
| A2 | "Which part of this job would you be weakest at on day one?" | EXP | [grounded] "I've never worked for a software company" | Give the real answer, not a disguised strength: "I haven't worked for a software company, so the product itself is what I'd be learning." Then add one line on how you'd close that gap, framed as a plan. Don't give a second, invented weakness as well | It's the same objection as A1 asked as an open question, and candidates often dodge it. F5 gives you an honest answer already, so use it. It's tagged EXP because it tests honest self-assessment |
| A3 | "Tell me about a time you handled an escalation." | JD | [grounded] | Choose a case that has a clear stake (an upset customer or an issue beyond a standard answer), what *you* did, and how it ended. If no such time comes to mind, say so plainly, then describe how you would handle one. B2 gives you the structure. Don't build a story out of pieces | F4 has no evidence either way, and the ad names escalations, so expect this question. The guidance makes no claim about your past because your material makes none |
| A4 | "The ad mentions Zendesk, and your background is Freshdesk. How would you get up to speed?" | JD | [grounded] "I use Freshdesk every day" | Start with "I use Freshdesk every day." Never suggest you've used Zendesk. Answer slot: if they ask what you do in Freshdesk, describe what you actually use it for day to day, in your own words. If there's a part you don't use, say so plainly. Then explain how you'd learn a new tool, framed as a plan | It covers F2. The ad's wording accepts a similar tool, so this is a mild question, but a careless answer can turn it into a problem |
| A5 | "Why move from energy into software support, and why now?" | EXP | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Give your actual reason, in your own words. The pack doesn't supply one. Keep it forward-looking, and don't criticise your current employer. If your reason is about the kind of work rather than the industry, say that plainly | Questions about motivation consistency belong to the Skeptic. F1 and F5 together make the "why the switch" question likely |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes: 'You've charged me twice and I want my money back today.' Type your first reply." | CASE | [generic] | Type the actual reply. Acknowledge the problem in one line, say what you'll check, ask only for what you need, and give a timeline you can actually keep. Don't promise "today" unless you know you can deliver it. Keep it to 4 or 5 lines in plain words | It's a live writing test, which fits a text-chat round, and it scores both writing (F3's requirement) and judgement. It's [generic] because it's a pattern, not Lumenvale's process |
| B2 | "A customer says our product lost their work and demands a manager. Walk me through what you do." | CASE | [generic] | Structure it: calm the customer and acknowledge the impact, collect the facts (what happened, when, what they see now), check whether it's a known issue, escalate through the team's process with full notes so nobody has to ask again, tell the customer what happens next and when, then follow up. Say that you'd check the team's escalation route rather than assume one | It covers F4's requirement as a decision rather than as a record, so it needs no claim about your past |
| B3 | "You can't reproduce the problem a customer describes. What do you do with the ticket?" | CASE | [generic] | Ask for the details that matter (steps, device or browser, screenshots, when it started). Tell the customer what you've tried. Pass it on with everything you collected, and don't close it silently. Say plainly that you'd learn the team's handoff route | Software support often turns on bugs you can't reproduce, and it's where F5's gap will be tested live. A structured answer works without product knowledge |
| B4 | "The queue has 40 tickets and two are marked urgent. How do you prioritise?" | CASE | [generic] | Clarify what "urgent" means on this team. Triage by impact and time sensitivity, send a quick acknowledgment where a full answer will take longer, and flag the situation if the queue can't be cleared in time | It tests judgement under volume. The guidance claims nothing about your queue at work |
| B5 | "Explain to a non-technical customer how to reset their password, in three lines or fewer." | CASE | [generic] | Use numbered steps in plain words, one action per line, and end with what to do if it doesn't work. Don't use jargon | It's a direct test of the ad's "clear written communication", and it's easy to set in a chat. Practise typing it once |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself and your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year"; "I use Freshdesk every day" | Keep it short and use only what the quotes state: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day, and training four new starters on the refunds process last year. Close with why this role, in your own words. Keep it to about 5 typed lines | It's the near-certain opener, and the friendly tone hides that it's scored. Its content comes from F1 and F2 |
| C2 | "What do you enjoy most about support work?" | EXP | [generic] | Give one real thing, briefly, with a reason. If an example comes to mind, use one you actually lived. If none does, give the reason on its own and don't make one up | It's a common rapport question that checks genuine interest. The pack claims nothing about your experience here |
| C3 | "How do you make sure your written replies are clear?" | JD | [inferred] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say that emails were part of your daily contacts, which the quote states. Answer slot: if you have a way you structure a reply, describe it in your own words. If you don't have a set approach, say so plainly and describe how you'd make a reply clear | F3 is thin, so the honest answer should be ready before the question arrives. It's tagged JD because it scores a stated requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day. How is that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep "around", and keep calls and emails as one combined figure. Answer slot: say how the figure is counted, what makes it go up or down, and the part of it you'd defend least, in your own words. If you don't know how it's counted, say so plainly. "It's my rough daily average" is only an honest answer if that's what it actually is | It's the only figure in F1, and careful readers ask about figures. Coming prepared to be precise builds credibility |
| D2 | "You trained four new starters on your refunds process. Walk me through that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it in your own words: four new starters, the refunds process, last year. The pack adds no detail about how you trained them, so don't let it grow into "designed the training" or "ran onboarding" | It's F1's strongest extra signal, and it's the easiest line to inflate under friendly questioning |
| D3 | "What do you actually do in Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Answer slot: describe the parts you really use, in your own words. If you don't use a part, say so plainly and stay with what you do use. Don't list features from memory of the product | The ad's ticketing line (F2) makes a tool-depth question likely. The answer has to be yours |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That training, how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold on the quote: you trained four new starters on the refunds process. If someone else wrote the materials or set the process, say so plainly, because that is the honest limit and not a confession. Don't fold on the part that was yours | Attribution questions exist to catch inflation, and the hold-then-concede structure is the rehearsal. It draws on F1 |
| E2 | "In two lines: why you over someone who's already supported software?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Line 1: your quotes (three years, around 60 calls and emails a day, Freshdesk every day). Line 2: plainly, that you haven't worked for a software company, followed by your plan to learn the product. Hold through one push and then concede only the product-knowledge gap | It's F5 delivered under a time limit. It checks whether A1 holds up when you have less room |

### F. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Choose a time with a real trade-off, a decision you made, and an outcome. If no such time comes to mind, say so plainly, then say how you would handle that trade-off | It's a common values question. Lumenvale's own values couldn't be fetched (Sources), so it's [generic] |
| F2q | "Tell me about a time you had to tell a customer something they didn't want to hear." | VAL | [generic] | Choose a case where you said the hard thing clearly and kindly, and say how it landed. If no such time comes to mind, say so plainly and describe how you'd word it | It's a common question for support roles and connects to escalations (F4's requirement). The pack makes no claim about your past here |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When you pass a ticket to engineering or a senior colleague, what would you include?" | CASE | [generic] | Include the customer's words, the steps to reproduce, what you've already tried, the impact and urgency, and what you've told the customer. The test is whether they need to ask you anything before acting | It's the peer question about handoffs, and it supports F4's requirement. It's asked as a hypothetical, so it claims nothing about your past |
| G2 | "A colleague closes a ticket you think isn't really resolved. What do you do?" | CASE | [generic] | Check with the customer or the ticket history first, raise it with the colleague directly and without blame, and agree what happens next. Show that you can disagree and still keep the working relationship | It tests disagreement with equals. The answer is about principles, not history |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 "2+ years in customer support" | C1, D1, D2, E1, A5 |
| F2 "experience with Zendesk or a similar ticketing tool" | A4, D3 |
| F3 "clear written communication" | C3, B1, B5 |
| F4 "confidence handling escalations" | A3, B2, G1, F2q |
| F5 software-product familiarity (not in the ad) | A1, A2, E2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do new starters on the team learn the product in their first few weeks?" | It follows on from the ramp plan in A1 and shows you're planning around the gap you named |
| R2 | "What kinds of tickets make up most of the queue?" | It tells you what the job really is, and it shows you're thinking about the work, not the title |
| R3 | "How do escalations move from support to engineering or senior staff here?" | It connects to the ad's escalation line and to B2, so you can adjust your structure to their actual route |
| R4 | "How does the team measure good support: speed, quality checks, customer ratings?" | It shows you expect to be measured and want to know what success means on this team |
| R5 | "What separates someone who does well in this role in their first three months?" | It gives you a direct answer to plan your first months around |
| R6 | "What does the next stage of the process look like after this conversation?" | It helps you plan what to prepare next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked at or supported a software company | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No answer slot |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." Your material names Freshdesk, not Zendesk |
| Answers 60 emails a day | Inflated form of F1, where the number has slid onto one noun | F1's quote as written: around 60 calls and emails a day, combined and approximate |
| Designed the training or ran onboarding | Inflated form of F1's second quote | "I trained four new starters on our refunds process last year", as said. Your material says you trained them, not that you designed a programme |

## Sources

- Provided: your message, which included your summary of the job ad's requirements, your background, and the invite's text.
- Searches sent:
  1. `Lumenvale Software values`: refused (web search permission not granted)
  2. `Lumenvale Software interview process customer support`: refused
  3. `Lumenvale Software news 2026`: refused
- Fetches: none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The call was refused. It would have given the F bank Lumenvale's own values by name, instead of [generic] themes |
| 2. `Lumenvale Software interview process customer support` | unavailable | The call was refused. It would have checked whether more rounds follow this one. Persona weights rest on the invite's description and a hiring-manager assumption |
| 3. `Lumenvale Software` strategy or recent news | unavailable | The call was refused. It would have supported one or two CO questions about the product and recent moves. The pack has none, and the B bank stays [generic] |
| 4. Interviewer name | n/a | The support team lead isn't named, so no query could be formed |
| 5. Representative Customer Support Specialist JD | skipped | The requirements you listed from the ad already fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text: any mid-list requirements become new fit rows and JD questions, and F1 to F4 can quote the ad directly instead of your summary.
- Whether the support team lead would be your manager or a peer: persona weights get recalculated, and the A and G banks get reweighted.
- Permission to search: targets 1 to 3 rerun, which gives a Lumenvale values bank by name, product context for B3, and one or two CO questions. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent company context.
- Whether you've handled an escalation, in your own words: F4 and A3 change from a scaffold to a story built from your answer.
- How you approach writing a reply, if you have a way: F3 and C3 get stronger.
- How much prep time you have: adds a prioritised prep schedule.
- A `tuesday-dossier.md`: would carry verified evidence and an evidence-based objection into this pack.
