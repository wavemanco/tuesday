I'm reading the prep skill's rules; next I'll do a little research on Quillmoor and then write your pack.
I've written your prep pack for Thursday's call with Hannah: `quillmoor_operations-coordinator_interview_pack.md`. I built it from the advert, her message and your notes. I tried to look up Quillmoor and Hannah online, but those searches weren't permitted. So the pack has nothing on the company's values or news, and no background on her.

**The four things she said she'll ask about**
- **Salary:** say "I'm hoping for £42,000." It's inside their £38,000–£44,000 range, so it needs no explaining. If she asks what you earn now, you can say "I'd rather focus on the range for this role."
- **Notice period:** your notes don't give one. Check your contract before Thursday so you can answer in one sentence.
- **Hybrid:** give your full answer: two days at Avonmouth is fine, but you wouldn't want more than three. Don't make the limit sound firmer or looser than that.
- **Why you're moving:** your Bristol office closes next year and the only offer is relocating to Reading, which you don't want. That's clear and believable, so don't add other reasons.

**The question most worth rehearsing (B1 in the pack):** SAP. The advert lists it as a plus, and it's the one item you've said you don't have. Say it first, before she has to dig: "I haven't used SAP. We run our own in-house stock system." Then describe what you actually use that system for. Don't call it "like SAP," since you can't compare the two. Finish with how you'd get up to speed.

**The pack also covers:**
- a 90-second answer for "tell me about your background"
- the likely follow-ups on your stock-count figure, Excel and weekly dispatch reporting
- two quick "what would you do if…" problems
- six questions to ask her at the end
- a short list of claims to avoid, such as "I cut discrepancies by a third" (you said they *fell by about* a third)

If you'd like to practise, I can play Hannah and put the SAP question to you, with follow-ups.
I can also save a `tuesday-dossier.md` file noting the gaps this prep turned up, for you to use in later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call with Hannah Lowther, Talent Partner. Thursday at 2pm. She will ring the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move. Then she will tell you about the team and the next steps.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key:
  - **VAL**: behaviour against the company's published values
  - **EXP**: your work history, and what was actually yours
  - **JD**: the advert's stated duties and terms, including the gaps
  - **CO**: knowledge of the company and its strategy
  - **CASE**: a live problem from the role, worked through out loud
- Provenance labels: `[grounded]` traces to something you or the advert said. `[inferred]` is this pack's own derivation, and the derivation is named. `[generic]` is a common pattern for this kind of role and claims nothing about Quillmoor.
- An **answer slot** is an instruction for the call itself. If you did the thing, say how in your own words. If you didn't, or there was no such step, say so plainly.
- The guidance is scaffolding, not a script. Say it in your own words.

## The fit snapshot

Requirements are quoted from the advert. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material describes delivery scheduling for three depots. It does not describe production scheduling between planning, a warehouse and QA, so the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on working across teams likely. If your scheduling meant agreeing timings with other teams, say which teams and how, in your own words. If it didn't, say so plainly and stay with the depot scheduling |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. This is a line from your own description with nothing behind it yet, so expect a probe. Lead with the quote's own terms: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap. Keep both halves as you said them, "about" and "over a year" included. The figure invites defend-the-number questions (C1) |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show dispatch reporting either way. Answer slot: if you report on deliveries now, say what you report, how often and to whom, in your own words. If you don't, say so plainly and say how you would approach a weekly report, as a plan |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Say it as it stands: four years as a logistics coordinator at a building-supplies wholesaler |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says spreadsheet. It doesn't say Excel, or what the rebuild involved. Answer slot: if the spreadsheet is in Excel, say what you built into it, in your own words. If it's another tool, say so plainly and name it |
| F7 | "ERP experience (SAP or similar) a plus" — advert (SAP) | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap you have stated, and wording can't close it. Words: "I haven't used SAP." After that, how you would learn it, said as a plan and never as a past. It's listed as "a plus", not a requirement. Nothing added to make the gap feel smaller |
| F8 | "ERP experience (SAP or similar) a plus" — advert ("or similar") | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your sentence says the company runs an in-house stock system. It doesn't say what you do in it, or whether it is ERP-like. Answer slot: say what you actually use the system for, in your own words. Let Hannah decide whether that counts as "similar". If you aren't sure how it compares to an ERP, say so plainly |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is inside the advertised band. Words: "I'm hoping for £42,000." Nothing added |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised pattern is within what you stated. Words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Don't firm up or soften the limit |

## Persona table

Hannah's own message sets out what this call covers, so the weights below follow her agenda rather than a guessed pattern.

| Persona | How it shows up on Thursday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly phone chat: your background, then her four logistics topics | Dominant. A recruiter screen leans this way, and the four topics she named are all logistics | Have a 90-second background answer ready (A1). Treat casual questions as scored. Give each logistics answer in your own stated words |
| Skeptic (light) | "The advert mentions SAP", "why us", "different industry" | Mid. A recruiter checks the advert's listed items, and F7 is the one you stated you lack | Rehearse B1 until it bores you. Bridge only from what you said, plus a plan to learn |
| Data-Driven Prober | One question on the stock-count figure, or on Excel | Low to mid. Your one figure (F3) and the Excel line (F6) are the easy prompts | Know what you can and can't say about how the figure was counted, and say plainly when you don't know |
| Case / Strategist | A quick "what would you do if…" on a late supplier or a stock mismatch | Low. More typical of the hiring-manager round, but recruiters sometimes test with one | Clarify, then structure out loud: who to ask, who to tell, what to record |
| Values / Behavioral | "Tell me about a time…" | Low. Her agenda names no values questions, and Quillmoor's published values could not be looked up | Story-map from your own sentences, with an honest branch |
| Pressure / Stress | A time-boxed "why you" or a push on SAP | Low. Her message reads collaborative. Rehearsed briefly so it can't surprise you | Pause, hold your stated position through two follow-ups, then concede the real gap plainly |
| Peer Evaluator | — | Not plausible in a recruiter screen, so no bank | — |

## Question banks

### A — Conversational (Hannah's agenda)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with three beats, in this order. First, the role and the four years. Second, the day to day: scheduling deliveries for three depots and chasing suppliers when orders slip. Third, the stock-count spreadsheet you rebuilt, with discrepancies falling by about a third over a year. Keep "about". Close with what drew you to this role, in your own words. Leave your reason for leaving for A5 unless she asks for it | Almost certainly how the call opens, and casual openers are still scored. EXP because it sets the story every later answer has to match (F1, F2, F3, F5) |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say it as you said it: "I'm hoping for £42,000." It's inside the advertised band, so no justification is needed. If she follows up on the figure, give your own words again: "I'm hoping for £42,000." If asked what you earn now: "I'd rather focus on the range for this role." | First on her agenda. JD because it's the advert's stated terms (F9) |
| A3 | "What's your notice period?" | JD | [generic] | Give your actual notice period, as your contract states it. Check the contract before Thursday so you can say it in one sentence | On her agenda and not in your notes. JD because start timing is a term of the job |
| A4 | "How would the hybrid pattern work for you, two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute or about more days, your own words were: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | On her agenda. JD because it's the advert's office pattern (F10) |
| A5 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Give the reason as you said it, all of it: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. Add nothing. Any follow-up gets your own words again: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | On her agenda. EXP because it's about your current job, and a clear, factual reason is the easiest kind to believe |

### B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions SAP. Have you used it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **The highest-ROI rehearsal in this pack.** Say the limit first, before you're pushed: "I haven't used SAP. We run our own in-house stock system." Answer slot: expect a follow-up on what you do in that system. Describe what you actually use it for, in your own words. If asked how it compares to SAP, say plainly that you haven't used SAP, so you can't compare. Then say how you would get up to speed, as a plan and never as a past. Hold through two follow-ups by returning to the in-house system, never by adding to it | F7 is the one advert item you have stated you lack. It is also the easiest box for a recruiter to tick, so it will come up in some form. JD because it scores a listed item, and the item is "a plus", not a requirement |
| B2 | "Why Quillmoor, and why this role?" | JD | [generic] | Pick one or two lines from the advert that match work you want to do, and say why in your own words. Keep this separate from your reason for leaving, which stays as you said it. Don't claim knowledge of Quillmoor's products or plans that you haven't read. If nothing about Quillmoor in particular draws you yet, say so plainly and name the advert lines that do | Asked in almost every screen. JD because a good answer ties to the listed duties |
| B3 | "You've been in building supplies. This is diagnostic-test manufacturing, with QA in the loop. How would you find that?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Stay with what your sentences carry: four years at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Answer slot: the advert's planning, warehouse and QA line makes a probe on working across teams likely. If your scheduling meant agreeing timings with other teams, say which and how. If not, say so plainly and stay with the depot scheduling. Then say how you would learn the production and QA side, as a plan. Don't claim any manufacturing or QA experience | F1 is the widest stretch between the advert and your material. JD because it tests the coordination duty |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How did you measure that?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the sentence's own shape: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot, in your own words: how the fall was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer. Don't say the rebuild caused the whole fall unless you can say how you know | F3 is your one figure, and figures attract follow-ups even in friendly calls. EXP because it tests attribution |
| C2 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet is in Excel, say what you built into it, in your own words. If it's another tool, say so plainly and name it. Don't list features you don't use | A listed requirement (F6) that your material only touches. The derivation is spreadsheet to Excel, which your sentence doesn't state |
| C3 | "The role reports weekly on on-time dispatch. Have you done reporting like that?" | JD | [inferred] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you report on deliveries now, say what you report, how often and to whom. If you don't, say so plainly, return to scheduling deliveries for three depots, and say how you'd set up a weekly report, as a plan | F4 has no evidence either way. Rehearsing both branches means the honest answer is ready |

### D — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a key delivery will be a week late, and production is planned around it. What do you do?" | CASE | [generic] | Structure it out loud. What you'd ask the supplier first. Who needs to know: planning, the warehouse and QA, as the advert names them. What options you'd put to them. How you'd record it and follow it up. The question needs no claim about your past, so the guidance makes none | A live version of the advert's chasing duty (F2) and its coordination duty (F1). Generic because it's a pattern for the problem, not a fact about Quillmoor |
| D2 | "Our stock count doesn't match the system. Where do you start?" | CASE | [generic] | Structure it: confirm the size and scope of the mismatch, check for recent movements not yet booked, recount where needed, find the cause, then fix the record and the process, and say who you'd tell. No claim about your past | The advert's stock-accuracy line (F3), asked as a decision rather than a record |

### E — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time an order slipped and you had to chase it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F2. You chase suppliers when orders slip, which is the beat your sentence states. Pick one real occasion and tell what happened and how it ended, in your own words. If no single occasion comes to mind, say so plainly and describe how you usually chase a slipped order | The advert's chasing line raises this theme. A specific occasion beats a general description |
| E2 | "Tell me about a time you had to juggle competing priorities across sites or teams." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pick a time when scheduling for the three depots meant choosing what came first. It needs a real clash, what you decided, and how it landed. If no such time comes to mind, say so plainly, then describe how you schedule across the three depots, or how you would handle a clash | The advert's coordination line (F1) raises this theme. The story is yours to choose, so the pack supplies none |

### F — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Thirty seconds: why should I put you through to the hiring manager?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause, then give the three facts in the quotes' own words: four years as a logistics coordinator; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Don't call them proof of anything. Let her make the link to the advert | Rehearsed so a time-box can't throw you. JD because it asks for fit to the listed duties |
| F2q | "You've never used SAP. Wouldn't someone who has be a safer bet?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold, then concede. Hold: "I haven't used SAP. We run our own in-house stock system", then what you actually use it for, in your own words. If she pushes twice, concede the real point plainly: someone with SAP wouldn't need to learn it. Then give your plan to learn it. Don't fold into apology, and don't claim anything about SAP | B1 again, under pressure (F7). JD because it scores the listed plus |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, D1, E2 |
| Track supplier deliveries and chase late orders | A1, D1, E1 |
| Keep stock records accurate | A1, C1, D2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1, F1q |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, F2q |
| £38,000–£44,000 | A2 |
| Hybrid: two days a week at Avonmouth | A4 |
| Notice period and reason for move (Hannah's agenda) | A3, A5 |

## Reverse questions

Hannah said she'll tell you about the team and next steps. Have these ready for the gap that leaves.

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the work split between planning, the warehouse and QA, and who would this role sit with day to day?" | It picks up the advert's own coordination line and shows you've read past the title |
| R2 | "Which ERP or stock system does the Avonmouth site use, and how are new starters trained on it?" | It meets the F7 gap head-on, as a question about ramp-up rather than a defence |
| R3 | "How is on-time dispatch reported now, and who reads the weekly report?" | It ties to a listed duty (F4) and tells you what the role is measured on |
| R4 | "Are the two office days fixed, or chosen week to week?" | A practical logistics question that fits her hybrid topic |
| R5 | "What would a good first three months look like in this role?" | It invites her to describe success, which you can use in the next round |
| R6 | "What are the next steps after today, and who would I meet next?" | She said she'd cover this. Confirming the next round tells you what to prepare for |

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP, or knows it | Negative you stated, F7 | The plain acknowledgment: "I haven't used SAP." No slot |
| The in-house system is an ERP, or similar to SAP | Inflated form of F8 | F8's quote at its own scope. The pack's observation is that your material says an in-house stock system, nothing about how it compares. B1's slot stays with what you use it for |
| Coordinated production schedules between planning, warehouse and QA | Inflated form of F1 | F1's quote at its own scope. Your material says deliveries for three depots, not production schedules. B3's slot stays inside the depot scheduling |
| "I cut stock discrepancies by a third" | Inflated form of F3: the verb, and the dropped "about" | F3's quote as said: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." |

## Sources

Provided documents: the advert text, Hannah Lowther's LinkedIn message, and your own notes, all pasted into the conversation.

Searches sent:
- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics Avonmouth Bristol news`: refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have themed bank E on Quillmoor's published values, and the reverse questions with them |
| 2. `Quillmoor Diagnostics interview process` operations | skipped | Hannah's own message fixes this session: one 30-minute phone call with her, and its topics. The persona weights follow it |
| 3. `Quillmoor Diagnostics` strategy / recent news | unavailable | The search was refused. It would have added a CO question and a sharper B2 |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have supplied an interviewer read from her public professional profile, and a reverse question tied to her path |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or Quillmoor's values or careers page pasted in → bank E themed on its published values, a CO question on current news, and an interviewer read with a tailored reverse question
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a strategy brief for the hiring-manager round
- Your answers to the slots in C1, C2, C3 and B3 → F3, F4, F6 and F1 move from slots to quoted evidence
- Something inspectable behind the stock-count figure, such as before-and-after count variance records → F3 can rise from `medium` to `high`
- Your CV → more stories for E1 and E2, and the background in A1 checked against it
- The schedule for later rounds, once Hannah gives it → a mini-pack for each round
- A `tuesday-dossier.md` from an evaluation of this role → evidence-verified bridges and a prohibited-claims list from that evaluation, carried into this pack
