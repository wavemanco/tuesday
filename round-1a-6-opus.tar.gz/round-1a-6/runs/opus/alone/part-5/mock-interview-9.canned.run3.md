Quick update: I've read the prep-skill guidelines. Next I'm doing a short research pass on the school and district, then I'll build your pack.
I've done the research: five searches and two page reads. Now I'm writing the pack.
I've saved your prep pack as `Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. It's built around the panel your invite describes: Principal Vantongeren plus two fourth-grade teachers. The district's own hiring page describes the same format, and says panels ask about reading instruction, classroom routines and how you work with families.

You don't need your Social Security number to prepare for an interview, so I didn't use it anywhere.

**Your license:** it meets the requirement. A Professional Educator License (PEL) with an Elementary Education endorsement for grades 1–6, active through 2029, covers fourth grade. It's worth bringing a copy of your license record on Thursday.

**What I found about the district:**
- **Its three stated beliefs:** Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test.
- **A literacy plan adopted in August 2026:** it brings a new grades 3–5 reading curriculum in fall 2027.
- **The principal:** she spent nine years as a reading specialist before becoming principal in 2022. Her 2025 talk was on small reading groups and weekly reading conferences.

**Your strongest point:** you led your grade level's move to a new reading curriculum in 2024, and the district is about to do the same thing. Question C1 builds on that.

**The objection to rehearse most:** "You've never taught fourth grade" (question A1). Say it plainly first ("I haven't taught fourth grade"), then mention your six years of third grade, then give a concrete plan for getting up to speed.

**Leading vs. team lead:** keep "I led our grade level's move" separate from any team-lead title. Both of your statements are true, and the pack shows how to say them together without sounding defensive.

Some next steps, if you want them:
- I can play the Skeptic and run question A1 with you live, with follow-ups.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

Two questions that would sharpen the pack:
1. Do you have the actual Halvering job posting? If you paste it, four rows that currently rely on a typical fourth-grade posting would be based on the real one, and any extra requirements would get their own questions.
2. Do you want a deeper research pass? That's up to 6 more searches and 2 more page reads, taking several more minutes, on things like the school's improvement plan, more of the principal's talks, and recent district news.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
**Format:** 45-minute panel interview on Thursday
**Panel:** Principal Dolores Vantongeren (your future principal, so effectively the hiring manager) and two members of the fourth-grade team (your future peers, names not given)

---

## How to use this pack

- **Personas** describe *how* a question is asked: the Skeptic, the Peer Evaluator, the Case/Strategist, and so on. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: whether your past actions show the district's published beliefs
  - **EXP**: whether what your CV says holds up when someone asks follow-up questions
  - **JD**: whether you can do the job as posted, gaps included
  - **CO**: whether you know the school and district: their plans and priorities
  - **CASE**: a live "what would you do" problem from the job
- **Provenance labels:** `[grounded]` means it traces to your CV, the invite, or a source listed under Sources. `[inferred]` means it's derived from something nearby, usually a representative fourth-grade job posting, because no Halvering posting was supplied. `[generic]` means it's a common pattern for this kind of role, with no claim about this school.
- **Answer slots** are places where your material doesn't say what happened. Each one gives you two honest options. Answer from what you actually did, or say plainly that it wasn't yours or didn't happen.
- Question IDs use letters by persona: A, B, C, D, E, G, H. **F** is left out so it can't be confused with the fit-snapshot rows F1–F12.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

Requirements come from the invite, the district's own pages, and a representative fourth-grade posting. No Halvering posting was supplied, so the representative posting stands in for one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The license requirement is met as you stated it. Say it in those terms: PEL, Elementary Education endorsement for grades 1–6, active through June 30, 2029. Fourth grade falls inside grades 1–6. It's a CV line with nothing inspected behind it, so confirm your record is current before Thursday and bring a copy. Verifying it is up to you and the district |
| F2 | "experience in grades 3 to 5 preferred" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Third grade is inside the 3–5 range this posting names. Say it at its own scope: "I've taught third grade for six years." Don't widen it to "upper elementary" or "grades 3 to 5" |
| F3 | "the Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | No wording can close this gap, and you've said so yourself. Words: "I haven't taught fourth grade." Then F2's quote at its own scope, then how you'd get up to speed, said as a plan and never as something you've done. Never imply fourth-grade experience, and add nothing to make the gap sound smaller. **This is the objection to rehearse most (A1)** |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The quote says third grade, not which subjects. Answer slot: if you taught all five subjects, say so and have one example ready for each; if some subjects weren't yours, say which, plainly |
| F5 | "Panels ask about reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | Both quotes are about reading, but neither shows how you teach reading in your own classroom. That's the panel's stated focus, so it's where your preparation matters most. Keep the quotes at their own scope. Answer slot: describe how you teach reading in your room, in your own words |
| F6 | "differentiate instruction using assessment data" — representative posting | none given | none | [inferred] | discovery | Strong evidence would name a specific assessment, what it showed, and what you changed because of it. Answer slot: if you've done this, say what the assessment was and what you changed, in your own words; if you haven't, say so plainly and describe how you would |
| F7 | "classroom routines" — district hiring page | none given | none | [grounded] | discovery | Strong evidence would name the routines you set up, how you taught them, and how you knew they'd stuck. Answer slot: describe your own routines in your own words; if you'd rather answer as a plan for this room, say so |
| F8 | "how you work with families" — district hiring page; "communicate regularly with families" — representative posting | "I write a weekly email to families." — your CV | medium | [grounded] | none | Your quote reaches the requirement as written. Lead with it in its own terms: weekly, an email, to families. It's a CV line with nothing inspected behind it, so expect a follow-up on what the email covers |
| F9 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families." — your CV | low | [grounded] | transferability | Your material says you email families. The belief is about speaking with each family, and your material doesn't show that. Words: "I write a weekly email to families." Answer slot: if you talk with families directly as well, say how and how often; if the email is how you mainly reach them, say so plainly and say how you'd speak with every family here |
| F10 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | none | The curriculum quote reaches the requirement. Keep its verb and its scope: you led your grade level's move. If asked about a title, the honest answer is "I've never been a team lead." Both statements are true, so keep them separate. Expect a follow-up on what "led" involved (A2) |
| F11 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "I've run the after-school reading club for the last two years" — your CV | low | [grounded] | discovery | The club touches the belief, but your material doesn't mention reading plans. Keep the club at its own scope. Answer slot: if you wrote or used reading plans for your third graders, say how; if you didn't, say so plainly |
| F12 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Strong evidence would show a time an assessment result changed what you taught, without the test becoming the goal. Answer slot as in F6 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 license | G1. It also needs no rehearsal beyond stating it accurately |
| F2 grades 3–5 experience | A1, H1, G1 |
| F3 fourth grade | A1, A3, H1 |
| F4 all five subjects | G1 slot, A1 plan. No question of its own: the district hiring page names reading, routines and families as panel topics, not each subject. If you send the Halvering posting and it stresses math or science, a question gets added |
| F5 reading instruction | A2, C1, C3, E2, E3 |
| F6 assessment data | C3, D3, E3 |
| F7 classroom routines | C2 |
| F8 families | B4, C4, D2 |
| F9 speaking with every family | D2 |
| F10 grade-level team | A2, B1, B2, B3, H2 |
| F11 reading plans | D1, E1 |
| F12 assessments inform teaching | D3 |

---

## Reading the interviewer

This section covers Principal Dolores Vantongeren only. The two team members weren't named. It draws on her public professional footprint, from one speaker-page search result (see Sources).

- **Career pattern:** Principal of Halvering Elementary since 2022, after nine years as a reading specialist.
- **Published talk:** "Small Groups, Big Readers," a 2025 forum talk on weekly reading conferences in grades 3 to 5.
- **Implications:**
  1. Expect reading instruction to be probed in depth. Her background and the district's hiring page point the same way. `[inferred]`
  2. Know the vocabulary of her talk: small groups and weekly reading conferences. Use those terms only for what you'd do at Halvering, or for what you actually do now (C3, E3). `[inferred]`
  3. A reverse question about her talk shows you looked at her work, not just the school (reverse question 1).
- **Shared ground:** Reading leadership. The one sentence you can bring to it is from F10: "I led our grade level's move to a new reading curriculum in 2024." Don't stretch it toward her specialist work.

---

## Persona table

The district's hiring page says each teacher hire is a single 45-minute panel with the principal and two grade-level teachers. That matches your invite, so these weights rest on the documented format rather than on a general pattern. For a panel, the method is to blend the main personas for each member: the principal plays the hiring-manager role, and the two teachers play the peer role.

| Persona | How it shows up here | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the fourth-grade gap and of "why move now" | **High.** A hiring manager's typical lean is Case/Strategist plus Skeptic, and F3 is the one gap anyone can see on your CV | Rehearse A1 until it's boring. Concede plainly, hold on your stated third-grade years, then give the plan |
| B. Peer Evaluator | The two fourth-grade teachers weighing whether you'd lighten or add to their load | **High.** Two of the three panelists are your future peers | Frame it as reciprocity: what you'd ask of them and what you could offer. Ask about how they work; don't assume it |
| C. Case/Strategist | "What would you do" scenarios on reading, routines and families | **High.** The hiring page names these three topics, and the district's new curriculum plan makes a readiness question likely | Clarify, then structure (plan, check, adjust), then think out loud. Use the district's own terms |
| D. Values/Behavioral | Questions framed around the district's three beliefs | **Mid.** The district says "Three beliefs guide every hire." No separate values round is named, so expect these inside the panel rather than as their own round | Use a story where one of your sentences carries it. Where none does, use a selection scaffold, and say so plainly if nothing fits |
| E. Data-Driven Prober | Follow-ups on your reading club and the curriculum move: who, how, how do you know | **Mid.** Peers tend to probe this way, and the principal has a reading-specialist background | Know what your material does and doesn't show. Say plainly when you haven't measured something |
| G. Conversational | A "tell us about yourself" opener | **Low-mid.** Most panels open this way. `[generic]` | Prepare a 90-second arc built only from your own sentences (G1) |
| H. Pressure | Time-boxed or "how much was actually you" questions | **Low.** No signal points to it. It's included so it isn't a surprise | Pause, restate the question, hold through two follow-ups, and concede only what's real |

---

## Question banks

### A. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What will be new for you, and how will you get up to speed?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" | **The highest-value rehearsal in this pack.** First, concede in one plain sentence: "I haven't taught fourth grade." Second, hold what you have, at its own scope: "I've taught third grade for six years." Don't describe it as proof of anything; let the panel draw that conclusion. Third, give a plan, said as future steps: what you'd study before day one (fourth-grade standards, the team's unit sequence), who you'd ask, and what you'd want to see in the first weeks. Answer slot: the posting's "grades 3 to 5" line makes a probe on what carries over likely. If something specific from your third-grade teaching would carry into fourth, name it yourself; if you can't name one, stay with the plan. Likely follow-up 1: "So our students would be your learning curve?" Hold: return to the six years and the plan, and add no experience. Likely follow-up 2: "What do you know about fourth-grade content right now?" Say what you know, plainly, and what you'll learn | F3 is the gap anyone can see on your CV, so some form of this question is close to certain. Typed JD because it scores fit to the posted role. It gets the deepest rehearsal for that reason |
| A2 | "Tell us about leading your grade level's move to the new reading curriculum. What was your part, exactly?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Tell it with only the details your sentence gives: you led the move, it was your grade level, it was a new reading curriculum, and it was in 2024. Use your own words. Answer slot: the district's plan for a new grades 3–5 curriculum in fall 2027 makes a probe on the steps likely. Say which steps of the move were yours and what you did in each; where a step wasn't yours or didn't happen, say so plainly and stay with what you led. If asked whether you were the team lead: "I've never been a team lead." Leading the move and holding the title are separate facts, and both are true | F10 and F5 both rest on this line, and it's the closest thing in your material to the district's plan, so it will be probed. Typed EXP because it tests what was actually yours |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick a real one. The one your material states is F3: "I haven't taught fourth grade." Say it in one sentence, then give A1's plan. If you'd name a different weakness, choose it from your own experience and pair it with a plan. Don't name a fake weakness | This is a common Skeptic opener, and F3 makes the honest answer easy to find. Typed JD because it checks your self-assessment against the role |
| A4 | "You've taught third grade at your school for six years. Why move now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: your reason isn't in your material, so give your actual reason, in your own words, in a few sentences. If part of it is about this district or about fourth grade, say which part. Don't criticize your current school | Skeptics check whether your motivation holds together. F2 gives the premise. Typed EXP because it tests your own account of your path |
| A5 | "Why Halvering, and why fourth grade?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Why here: name one thing from the district's published material and say why it matters to you. Options are the three beliefs (Every Child a Reader; Families Are Partners; Teach for Tomorrow, Not for the Test) or the literacy plan adopted in August 2026, which brings a new grades 3–5 reading curriculum from fall 2027 and a family reading night at every school each term. If you connect it to your own work, use your sentence's own words: "I led our grade level's move to a new reading curriculum in 2024." Answer slot for why fourth grade: give your real reason, in your own words | This tests whether you did your homework. Typed CO because the strong answer uses the district's own plan and wording |

### B. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about a time you disagreed with a colleague about how to teach something. What happened?" | JD | [inferred] | Choosing a story: you need a real disagreement, what each of you wanted, what you did, and how the working relationship ended up. If the curriculum move included one, it can be that story, but only if it actually did. If no such time comes to mind, say so plainly, then describe how you'd handle a disagreement with this team | The theme comes from the posting's "work with the grade-level team" line (F10). Your future peers will want to know how you disagree with equals |
| B2 | "What would you need from us in your first month, and what would you bring to the team?" | JD | [grounded] "I've run the after-school reading club for the last two years" "I write a weekly email to families." "I led our grade level's move to a new reading curriculum in 2024" | What you'd need: ask, don't assume. For example: the team's unit sequence, how they plan together, where shared materials live. What you'd bring: offer, don't sell. Name the three things your CV states, in its own words, as things you'd be glad to share if they'd help. Then let the team say what would be useful | Peers are weighing how a new hire affects their own workload. Reciprocity answers that. F8 and F10 supply the items you can offer |
| B3 | "When your grade level moved to the new curriculum, how did you bring your colleagues along?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The idea that bringing colleagues along was part of it comes from the panel's question, not from your CV. Answer slot: the posting's team line makes this probe likely. If there were colleagues to bring along and you did, say how, in your own words; if it wasn't needed, or that part wasn't yours, say so plainly and return to the move you led | A2 seen from the peers' side. Typed EXP because it tests your role in the move |
| B4 | "Say our team sends families one shared fourth-grade update. How would your weekly email fit with that?" | CASE | [grounded] "I write a weekly email to families." | This is a hypothetical, so don't assume it's how they actually work. Ask first: what goes in the shared update, and who writes it? Then give options: fold your class news into it, or keep a short class note alongside it. Make clear you'd follow the team's lead. Your one past fact here is the quote | F8 in team terms. Typed CASE because it's a live coordination problem |

### C. Case/Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our district is bringing in a new grades 3–5 reading curriculum in fall 2027. How would you help our fourth-grade team get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: which curriculum, what training is planned, and what the timeline is. Then a plan: learn the materials, try one unit early, share what works with the team, and tell families what's changing. Mention your past once, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if something from that move would change how you'd approach this one, say what, in your own words; if nothing comes to mind, stay with the plan. Don't claim to know the new curriculum | Grounded in the district's August 2026 literacy plan. This is the strongest question in the pack for you, because F5's quote meets the district's plan directly. CO content, delivered as a CASE |
| C2 | "It's the first week of school. Walk us through how you'd set up routines in a fourth-grade room." | CASE | [grounded] | Structure it: which routines come first (arrival, transitions, materials, independent reading time), how you'd teach and practice them, how you'd know they'd stuck, and what you'd do when they slip. The pack doesn't know your third-grade routines. If you'd carry some over, name them yourself. This is a planning question, so it doesn't need a claim about your past | The hiring page names routines as a panel topic. F7 has no evidence, so rehearse this one. Typed CASE because it's a live plan |
| C3 | "In September you find that several students are reading well below grade level and a few are well above. What do you do in the first month?" | CASE | [inferred] | Structure it: assess (how you'd find out where each student is), group (small groups by need), plan (what each group does), check (how often you'd re-assess), and tell families. The principal's 2025 talk was on small groups and weekly reading conferences in grades 3–5, so know those terms. Answer slot: if you've run small groups or reading conferences yourself, say how, in your own words; if you haven't, say so plainly and describe how you'd start | This draws on the posting's differentiation line (F6) and the principal's published theme. Inferred because the scenario is typical, not taken from Halvering |
| C4 | "A parent emails you, upset that their child's reading grade dropped. What do you do?" | CASE | [grounded] "I write a weekly email to families." | Structure it: reply promptly and offer to talk, gather what you know (work samples, what changed), listen before explaining, agree on a plan, and follow up. If your weekly email comes up as how families already hear from you, keep it to the quote | The hiring page names families as a panel topic (F8). Typed CASE because it's a live problem |

### D. Values/Behavioral (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "One of our beliefs is Every Child a Reader. Tell us about a time you helped a student who was struggling to read." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Choosing a story: pick one student (no name). You need where they started, what you tried, what changed, and what you'd do differently. If the story comes from the reading club, keep the club at its own scope. If no such time comes to mind, say so plainly, then describe how you'd approach it here. Answer slot: the belief says no student leaves third grade without a reading plan, and you teach third grade, so expect a probe on reading plans. If you wrote or used them, say how; if you didn't, say so plainly | The district's first belief (F11). Typed VAL because it scores the belief through what you've done |
| D2 | "Families Are Partners: our teachers speak with every family each term. How do you build partnership with families?" | VAL | [grounded] "I write a weekly email to families." | Lead with what you do, in your own words: the weekly email. Answer slot: the belief is about speaking with families. If you talk with families directly as well as writing, say how and how often, in your own words; if the email is your main way of reaching them, say so plainly and say how you'd make sure you speak with every family here. Never describe the email as conversations | F9's gap between writing and speaking is exactly what this belief tests. Typed VAL |
| D3 | "Teach for Tomorrow, Not for the Test. How do you use assessment results without teaching to the test?" | VAL | [grounded] | Choosing a story: pick a time an assessment result changed what you taught. You need the assessment, what it showed, what you changed, and how you kept teaching beyond the test. If no such time comes to mind, say so plainly, then describe how you'd do it. Your material has nothing on assessment (F6, F12), so choose this story before Thursday | The district's third belief. Typed VAL with JD content (differentiation) |

### E. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about your after-school reading club. Who comes, and how do you know it's helping?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Use only the details your sentence gives: you've run it, it's after school, it's a reading club, and it's been two years. Answer slot: the Every Child a Reader belief makes "is it helping" likely. Say who comes and what you do, in your own words. If you've tracked anything about students' reading, say what and how; if you haven't, say so plainly and describe what you've seen. Keep calling it a club; don't rename it | F11 rests on this line. Typed EXP because it tests what's behind it |
| E2 | "What did the new reading curriculum change in your own classroom?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: say what changed in your teaching, in your own words. If less changed than people might expect, say that plainly. Speak only for your own room, unless you actually know about others' | This is the principal's reading-specialist angle on F5. Typed EXP |
| E3 | "How do you know a student is making progress in reading?" | JD | [inferred] | Choosing your answer: name the checks you actually use, how often, and what you do with the results. Your material doesn't show these (F6), so prepare them in your own words. If you'd rather describe a plan than a current practice, say so plainly. Given the principal's talk, expect a follow-up on reading conferences | Draws on the posting's assessment line and the principal's published theme |

### G. Conversational (low-mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc built only from these sentences: six years teaching third grade in Joliet; licensed, with the elementary endorsement for grades 1–6; you led your grade level's move to a new reading curriculum in 2024; you've run the after-school reading club for two years; you write a weekly email to families. Close with why this role (A5's slot). If the subject question from F4 comes up, answer it from your own experience | Panels usually open this way, and casual questions still count. Typed EXP because it's your CV, spoken aloud |
| G2 | "What's something you're working on as a teacher right now?" | EXP | [generic] | Choosing your answer: pick something real and current, say why you're working on it and what you've tried. If nothing specific comes to mind, say so plainly and name something you'd like to work on | A common rapport question that still gets scored. Generic, because no Halvering source raises it |

### H. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over someone who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate the question. Concede in one clause: "I haven't taught fourth grade." Then hold on two things you stated: six years teaching third grade, and leading your grade level's move to the new curriculum, which matters given the district's 2027 plan. Don't comment on the other candidate. If pushed twice, hold. If anything, concede only that fourth-grade content is new to you | A1 under time pressure (F3). Typed JD |
| H2 | "You say you led the curriculum move, but you've never been a team lead. How much of that move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Hold calmly: both are true. "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Then use A2's slot: which steps were yours. Hold through two follow-ups, and concede only the specific steps that weren't yours | F10 under pressure. Your own two sentences sit side by side here, so make them sound consistent rather than defensive. Typed EXP |

---

## Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| 1 | "Your 2025 talk was on weekly reading conferences in grades 3 to 5. How, if at all, do conferences show up in fourth grade here?" | Principal Vantongeren | It's tied to her own published work and shows you looked at her, not only the school |
| 2 | "Coming from your years as a reading specialist, what do you look for when you walk into a fourth-grade reading block?" | Principal Vantongeren | It invites her expertise and tells you what she'll judge you on |
| 3 | "What could a new teammate do in the first month that would genuinely help your team?" | The two teachers | Reciprocity: it shows you're thinking about their workload, not just your own needs |
| 4 | "How is the fourth-grade team preparing for the new grades 3–5 reading curriculum in fall 2027?" | Any of them | Grounded in the district's plan, and it connects to F5 without you having to sell it |
| 5 | "With a family reading night at every school each term, how does fourth grade take part?" | Any of them | It's from the literacy plan, and it touches both reading and families, two of the panel's topics |
| 6 | "What surprises new teachers most about fourth graders here?" | The two teachers | It's honest about F3 and gets practical knowledge from the people who have it |
| 7 | "The district's hiring page says references come after the panel. What's the timeline from here?" | Principal Vantongeren | It shows you read the process and gets you a concrete next step |

---

## Prohibited claims

These are claims the pack won't help you make, with the reason for each and the honest version.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Something you said you haven't done (F3) | "I haven't taught fourth grade." No answer slot |
| Has been a team lead or grade-level chair | Something you said you haven't done (F10) | "I've never been a team lead." Plus the quote that limits it, at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the school's or district's curriculum adoption, or chose or wrote the curriculum | An inflated version of F10 | Keep the quote at its own scope: your material says your grade level's move, and says you led the move, not that you chose or wrote the curriculum. A2's answer slot stays within the move |
| Experience across grades 3 to 5, or "upper elementary" | An inflated version of F2 | "I've taught third grade for six years." |
| Describing the weekly email as conversations, calls or conferences with families | An inflated version of F8/F9, a change in kind: writing becomes speaking | "I write a weekly email to families." D2's answer slot covers any direct contact you really have |
| Describing the reading club as an intervention program or a tracked reading program | An inflated version of F11, a change in kind | "I've run the after-school reading club for the last two years." E1's slot covers anything you actually track |

---

## Sources

**Provided:** the HR invite and the CV text in your message. Your Social Security number and license ID number weren't used anywhere, including in any search.

**Searches sent:**

1. `Orrinsford Community School District mission values` → https://orrinsfordschools.example/about/mission-and-beliefs
2. `Halvering Elementary School Orrinsford teacher interview process` → https://orrinsfordschools.example/careers/how-we-hire-teachers
3. `Dolores Vantongeren principal Halvering Elementary` → https://ilprincipalsforum.example/speakers/dolores-vantongeren
4. `Orrinsford Community School District news strategic plan` → https://orrinsfordschools.example/news/board-adopts-literacy-plan
5. `fourth grade teacher job description Illinois elementary school district` → https://k12jobsboard.example/listings/fourth-grade-teacher

**Pages read:** https://orrinsfordschools.example/about/mission-and-beliefs and https://k12jobsboard.example/listings/fourth-grade-teacher. The hiring page, the principal's speaker page and the literacy-plan news item were used from their search-result text only.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | The three beliefs by name: F9, F11 and F12, the D bank, and A5 |
| 2. Interview process | yes | Established the format (one 45-minute panel: the principal and two grade-level teachers) and its topics (reading instruction, classroom routines, families). These drive the persona weights, F5, F7, F8 and the C bank. No values round is named, so the values cheat sheet is left out |
| 3. District strategy and news | yes | The August 2026 literacy plan: C1, A5, and reverse questions 4 and 5 |
| 4. Dolores Vantongeren, Halvering | yes | The interviewer section, C3, E3, and reverse questions 1 and 2 |
| 5. Representative Fourth Grade Teacher posting | yes | F2, F4, F6 and F10, all labeled `[inferred]` |

---

## Upgrade menu

- **The actual Halvering posting text** → F2, F4, F6 and F10 move from `[inferred]` to `[grounded]`, and any requirement it adds (math, science, a specific program) gets its own question.
- **The names of the two fourth-grade teachers** → a persona assigned to each member, and a reverse question tailored to each.
- **Your own answers to the answer slots** (the subjects you taught for F4, your reading instruction for F5, assessments for F6 and F12, routines for F7, direct contact with families for F9, your steps in the curriculum move for F10, reading plans for F11) → those rows and A2, B3, C2, C3, D1, D2, D3, E1, E2 and E3 move from scaffolds to answers built on what you actually did.
- **A copy of your license record showing the endorsement and expiry date** → F1 moves from `medium` to `high` confidence.
- **Any guidance from HR** (a sample lesson, a writing task, or focus areas) → a build section for any task they've asked you to prepare. Usually one email to HR gets this.
- **A `tuesday-dossier.md`** → the top objection would come from verified evidence rather than inference, and its list of prohibited claims would bind every cell of this pack.
