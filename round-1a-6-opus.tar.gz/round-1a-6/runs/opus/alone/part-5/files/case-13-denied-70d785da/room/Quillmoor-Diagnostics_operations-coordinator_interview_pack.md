# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, a 30-minute phone call on Thursday at 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Her stated agenda, in her words:** "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

---

## How to use this pack

- **Personas** describe *how* a question is asked (friendly chat, quiet probing, pressure). **Types** describe *what* is being scored.
- Type key:
  - **JD**: the advertised job and its terms. Can you do the listed work, and do the pay, hours and location fit?
  - **EXP**: your work history. What you actually did, and whether it holds up when someone asks for more.
  - **CASE**: a live problem from the role, answered on the spot. Structure matters more than a "right" answer.
  - **VAL**: behaviour and values. Past behaviour that shows how you work.
  - **CO**: company knowledge. How much homework you've done.
- Provenance labels: `[grounded]` means it traces to the advert, Hannah's message or your own words. `[inferred]` means it is derived from them. `[generic]` means a common pattern for this kind of role, with no claim about Quillmoor.
- The guidance gives you scaffolding, not a script. Say it in your own words.
- **Where to start:** Hannah has named four logistics topics (A2 to A5). Your answers to three of them are already in your own words below. A3, your notice period, needs your actual figure. The highest-ROI question to rehearse is **B1** (SAP).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material shows delivery scheduling across depots, not production scheduling between planning, warehouse and QA. Keep the words at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's coordination line makes a probe likely on whether your scheduling involves other teams. If it does, name the teams and say how you agree the schedule with them, in your own words. If it doesn't, say so plainly and stay with the depot deliveries you schedule |
| F2 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | This matches the advert directly. It's self-reported with nothing to inspect behind it, so expect "tell me about one". Lead with the quote's own words: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | This reaches the requirement in its own terms. Keep the figure exactly as you said it: "about a third", "over a year". Keep the sentence's structure too. You rebuilt the spreadsheet, and discrepancies fell. A figure invites a probe on how it was counted (see C1) |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material doesn't show any dispatch or on-time reporting either way. Answer slot: if you report on deliveries or dispatch now, say what you report, how often and to whom, in your own words. If you don't, say so plainly and say how you would set up a weekly on-time figure, as a plan |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | This meets the requirement directly. Say it as given: four years as a logistics coordinator at a building-supplies wholesaler |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | medium | [grounded] | discovery | Your sentence says "spreadsheet". It doesn't say which tool or which features. Answer slot: if it was built in Excel, say so and describe what you built into it, in your own words. If it was another tool, name that tool plainly and say what you did in it |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | This is a nice-to-have, not a requirement, and you have stated the SAP part plainly. Words: "I've never used SAP — we run our own in-house stock system." Answer slot: if asked what the in-house system does, describe what you use it for day to day, in your own words. Don't call it an ERP or "like SAP" unless you know it is. If you don't know how it compares, say so. Then say how you would learn SAP, as a plan and never as a past |
| F8 | Pay: "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | A gate, and your figure is inside the advertised range. Words: "I'm hoping for £42,000." Add nothing to it |
| F9 | Location: "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | A gate, and the advertised pattern is within what you stated. Words, kept whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Coordinate production schedules | B3, E1, F1 |
| F2 Track supplier deliveries, chase late orders | E1, F2 |
| F3 Keep stock records accurate | A1, C1 |
| F4 Weekly on-time dispatch reporting | C2, E2 |
| F5 2+ years in operations or logistics | A1 |
| F6 Confident with Excel | C3 |
| F7 ERP (SAP or similar) a plus | B1 |
| F8 Pay | A2, D2 |
| F9 Hybrid, two days at Avonmouth | A4, D1 |
| Hannah's topics: notice period, reason for move | A3, A5 |

---

## Persona table

The loop here is set by Hannah's own message: a single 30-minute phone call with her, covering the four topics she named and then the team and next steps. No archetype was assumed.

| Persona | How it shows up on Thursday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, then her four named topics | High. A recruiter screen starts here, and she listed her topics in advance | Have a 90-second background ready, and treat every casual question as scored. Give your logistics answers in your own words (A2 to A5) |
| Skeptic | Light checks against the advert: SAP, the move from building supplies, why this role | Medium. Recruiters screen against the advert's named requirements, and F1 and F7 are the gaps | Rehearse B1 until it's boring. Bridge only from what you actually do, and say limits plainly |
| Data-Driven Prober | "How did you measure that?" on the figure you're likely to mention | Low to medium. She may not dig deep, but she may pass notes on to the hiring manager | Know what you can say about how the "about a third" was counted, and say so plainly where you don't know |
| Pressure | Small follow-ups that test whether your terms hold | Low. Recruiters sometimes push on office days or ask what you earn now | Give your own words again. If asked what you earn now, decline politely |
| Case / Strategist | "What would you do if…" on supplier slips or dispatch | Low. These are more typical of a hiring-manager round, but quick ones do turn up | Clarify, then prioritise, act, communicate and record |
| Values / Behavioral | "Tell me about a time…" | Low. No values-style round is documented for this call | Use the selection scaffolds, and if no example comes to mind, say so |

---

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about yourself and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with only the beats your sentences carry: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Then one line on why this role, in your own words (see B2). Stop at 90 seconds and let her steer | It almost always opens a screen. F5, F2 and F3 sit right on the advert's lines, so this is your best chance to map yourself onto it unprompted. EXP because it's your own history |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Your words: "I'm hoping for £42,000." Say it and stop. If she comes back to it later in the call, give the same words again | She named this topic. F8 is inside the advertised range. JD because pay is one of the listed job's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, as your current contract states it. Check the contract before Thursday so you aren't guessing | She named this topic, and you haven't given a notice period yet. JD because it's a term of the listed job |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Your words, kept whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute, your own words were: "I live in north Bristol, so two days at Avonmouth is fine." | She named this topic. F9 is the advert's pattern. JD because the location pattern is a term of the listed job |
| A5 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Your words: "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Then stop, or move to why this role in your own words (B2). If she follows up on the move, give the same words again | She named this topic. EXP because it's about your own situation. The reason you gave is the answer, kept at its own scope |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions SAP or similar. Have you used an ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | **The highest-ROI rehearsal in this pack.** Hold: "I've never used SAP. We run our own in-house stock system." Answer slot: if she asks what the in-house system does, describe what you use it for day to day, in your own words. If you don't know how it compares to an ERP, say so plainly. Then say how you would learn SAP, as a plan and never as a past. Hold through two follow-ups by repeating what the system is. Don't stretch it to "ERP-like" or "similar to SAP" | F7 is the one advert line where you've stated a gap. It's the likeliest objection, and it's where the pull to make the in-house system sound bigger is strongest. JD because it scores a named plus-skill |
| B2 | "Why Quillmoor, and what do you know about us?" | CO | [grounded] | Use only what the advert says: a diagnostic-test manufacturer with about 400 staff and an Avonmouth site in Bristol. Answer slot: say what draws you to this role, in your own words. If the answer is the work itself (scheduling, suppliers, stock records), say which part and why. Don't claim research you haven't done | Rapport-style recruiters treat this as a homework check. Without research it stays at the advert's facts. CO because it scores company knowledge |
| B3 | "This role coordinates production with planning, the warehouse and QA. Your background is deliveries. How does that translate?" | JD | [grounded] "I schedule deliveries for our three depots" | Words: "I schedule deliveries for our three depots." Answer slot: if your scheduling involves agreeing plans with other teams, name them and say how you do it, in your own words. If it doesn't, say so plainly and say how you would get to know planning and QA in the first weeks, as a plan | F1 is the advert's lead responsibility and your closest adjacent evidence. JD because it scores the stated duty |
| B4 | "Diagnostics is regulated manufacturing. Building supplies is quite different. How would you handle that?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Words: four years as a logistics coordinator at a building-supplies wholesaler. Answer slot: if you've worked to quality checks or documented procedures, say what they were, in your own words. If you haven't, say so plainly and say how you would learn the QA side, as a plan | The advert's QA line and the change of sector raise this probe. JD because it scores the role's QA coordination. The premise about sector is the advert's |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Keep it at "about a third, over a year". Answer slot: say how the discrepancies were counted, in your own words, or say plainly that you don't know how it was counted. Say what the figure could be sensitive to, if you know. Name the assumption behind it you'd defend least before she does. Say which part was yours. Your sentence says you rebuilt the spreadsheet. If others were involved in the fall, say so | F3 is your one headline figure, and figures attract probes. EXP because it tests attribution |
| C2 | "Do you report on delivery performance at the moment?" | JD | [grounded] | Answer slot: if you report on deliveries or dispatch now, say what you report, how often and to whom, in your own words. If you don't, say so plainly and say how you would build a weekly on-time figure, as a plan. Never describe a report you don't produce | F4 is silent in your material, and the advert names weekly reporting. JD because it's a listed duty |
| C3 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Words: "I rebuilt our stock-count spreadsheet." Answer slot: if it was Excel, say so and name what you built into it, in your own words. If it was another tool, name it plainly. Don't list functions you don't use | F6 is a listed requirement, and your sentence doesn't name the tool. JD because it scores a stated skill |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sometimes the team needs more days on site. Would that work?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Your own words again, kept whole: "Two days at Avonmouth is fine, but I wouldn't want more than three." Nothing added | A likely follow-up on F9. JD because it's a term of the job |
| D2 | "What are you earning at the moment?" | JD | [grounded] "I'm hoping for £42,000" | If asked what you earn now: "I'd rather focus on the range for this role. I'm hoping for £42,000." No current figure | A common recruiter follow-up to A2. JD because it concerns the job's pay |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a key delivery will be a week late and production is planned around it. What do you do?" | CASE | [generic] | Structure: confirm the new date and what's affected; tell planning, the warehouse and QA early; look for options (part delivery, another source, re-sequencing); agree the change and record it. This asks about no past, so the guidance makes no claim about yours | A live version of the advert's chasing and coordination lines (F2, F1). `[generic]` because it's a pattern, not Quillmoor's process |
| E2 | "On-time dispatch drops one week. How would you find out why?" | CASE | [generic] | Structure: check the figure is right; split it by cause (stock, supplier, production, picking, carrier); find the biggest bucket; fix it and report what changed. No claim about your past | The advert's weekly reporting line (F4), asked as a problem. `[generic]` because it's a pattern |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to get different teams to agree on a schedule." | VAL | [generic] | Selection scaffold: pick a time when two or more teams needed different things from one schedule. It needs the conflict, what you did, and how it was agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (scheduling deliveries for three depots), or how you would handle it | The advert's coordination line (F1) raises the theme. VAL because it scores how you work with others |
| F2 | "Tell me about a supplier who let you down and what you did." | VAL | [grounded] "chase suppliers when orders slip" | Selection scaffold: your sentence carries the routine (you chase suppliers when orders slip), not a particular occasion. Pick one real occasion: what slipped, what you did and what happened. If no single one stands out, say so plainly and describe how you chase in general, in your own words | The advert's chasing line (F2) raises it. VAL because it scores behaviour under friction |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which ERP or stock system does the team use, and how do new starters get trained on it?" | It turns B1's gap into a practical question and shows you're thinking about getting up to speed |
| R2 | "How is the Operations Coordinator's time split between planning, the warehouse and QA?" | It shows you read the advert's core duty, and the answer tells you which F1 story matters most |
| R3 | "How is weekly on-time dispatch reported today, and who reads it?" | It's specific to the advert and helps you prepare for the hiring-manager round |
| R4 | "Who would I report to, and how big is the team?" | She said she'd cover the team, so this gives her the opening |
| R5 | "Are the two Avonmouth days fixed, or chosen week to week?" | It's practical, and it follows on from her hybrid topic without reopening your own answer |
| R6 | "What are the next steps after this call, and what's the timeline?" | She said she'd cover next steps, and the answer helps you plan around your notice period |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, in F7 | Plain acknowledgment: "I've never used SAP." No slot |
| Has ERP experience, or uses a system "similar to SAP" | Inflated form of F7's "in-house stock system" | F7's quote at its own scope. The pack's own note on the limit: your material says an in-house stock system, not an ERP. B1's slot stays with what the system does |
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope. The pack's note on the limit: your material says delivery scheduling for three depots. B3's slot stays inside that |
| "Cut stock discrepancies by 33%", or caused the fall single-handedly | Inflated form of F3 | F3's quote at its own scope: "about a third", "over a year", and "rebuilt … and discrepancies fell" |
| Open to more than three office days | Contradicted by your quote in F9 | F9's quote, kept whole |

---

## Sources

- Provided: the advert text, Hannah Lowther's LinkedIn message, and your background, all from your message.
- Searches sent:
  - "Quillmoor Diagnostics values": refused
  - "Quillmoor Diagnostics Avonmouth Bristol news": refused
  - "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have given published values to theme the F bank and a reverse question. No values-style round is documented for this call, so no cheat sheet would render either way |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message fixes this session's format and the persona weights: a 30-minute phone call with her, on topics she named |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The search was refused. It would have moved B2 and added a CO question grounded in current strategy |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. A public professional profile would have added an interviewer read and a reverse question tied to her path |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Your notice period → fills A3 with your own words instead of an instruction
- Web search allowed → Quillmoor's published values (F bank), current company news (B2 and a strategy-based CO question) and Hannah's public professional profile (a reverse question tied to her path)
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for a later hiring-manager round
- What you use the in-house stock system for → B1 and F7 get your own description instead of an answer slot
- Whether the stock-count spreadsheet was built in Excel → F6 and C3 move from discovery to a direct match
- How the "about a third" was counted → C1 gets your own explanation
- Whether you report on deliveries or dispatch now → F4 and C2 get evidence, or a plain acknowledgment
- Prep time available → a prioritised schedule sized to it
- A `tuesday-dossier.md` → verified evidence and agreed limits to sharpen B1 and the prohibited list in later rounds
