# Recruiter screen prep pack: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday 2pm, 30-minute phone call with Hannah Lowther (Talent Partner). She is the recruiter, and she will ring your mobile.
**Her agenda, in her own words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then "the team and the next steps".

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key:
  - **VAL**: values alignment with the company's published values
  - **EXP**: what you actually did, checked
  - **JD**: can you do the advertised job, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, reasoned out loud
- Fit-snapshot rows are F1 to F10. Question IDs go by persona (A, B, C, D, E, G). F is left out so question IDs don't clash with fit-snapshot rows.
- The guidance gives you structure, not a script. Every line you say should be something you actually did, in your own words. An **answer slot** is a point where your material doesn't say, so the honest answer is yours to give either way.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material covers delivery scheduling for three depots. It doesn't cover production schedules, or working with planning and QA, and the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on cross-team scheduling likely. If your scheduling means agreeing timings with other people or teams, say who and how, in your own words. If it doesn't, say so plainly and stay with the deliveries you schedule |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. Your own words already say it: you "chase suppliers when orders slip". It's a statement with nothing behind it to inspect, so expect a "give me an example" follow-up (G1) |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, and this is your strongest line. Keep it exactly as worded: "about a third", "over a year", and "discrepancies fell", not "I cut discrepancies". It is a figure, so rehearse defending it (C1, E2) |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Strong evidence would be a regular report you produced on delivery or dispatch performance. Answer slot: the advert's weekly-reporting line makes this question likely. If you have reported on on-time delivery or anything similar, say what, how often and to whom, in your own words. If you haven't, say so plainly and return to the deliveries you schedule for the three depots |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. You have four years against a two-year requirement, in the same job family. Say it as it is: four years as a logistics coordinator at a building-supplies wholesaler |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | A rebuilt spreadsheet points towards Excel, but your sentence doesn't name the tool or what you built. Answer slot: if the spreadsheet was in Excel, say so and describe what you built in it, in your own words. If it was another tool, name it plainly |
| F7 | "ERP experience (SAP or similar) a plus" — advert, SAP part | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You stated this gap yourself, and wording can't close it. Words: "I've never used SAP. We run our own in-house stock system." If you add anything, make it how you would learn SAP, said as a plan and never as past experience. The advert calls ERP "a plus", and this pack treats it as a plus, not a knockout |
| F8 | "ERP experience (SAP or similar) a plus" — advert, "or similar" part | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | An in-house stock system is related to an ERP but isn't the same thing, and the words stay at that scope: "We run our own in-house stock system." Answer slot: if asked what you do in it, describe the tasks you actually do in it, in your own words. If your use of it is limited, say so plainly |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is inside the advertised band. It's your own number, so it is the whole answer (A2) |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised pattern fits what you said. Your own sentence is the whole answer (A4) |

## Persona table

The weights come from Hannah's own message. It describes this session: one 30-minute recruiter call, with her topics listed. They don't rest on a guess about how Quillmoor interviews.

| Persona | How it shows up on Thursday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly phone chat working through her list | High. Her message sets the agenda, and three of her four topics are logistics | Answer each logistics question in your own sentence, then stop. A casual question is still being scored |
| Skeptic | "What's prompting a move?", plus checks on whether wholesale experience transfers | Medium. "What's prompting a move" is on her list, and recruiters screen against the advert's requirements, F1 and F7 most of all | Rehearse B2 until it bores you. Use only what F1's quote carries, and name its limit before she does |
| Data-Driven Prober | One follow-up on "about a third" | Low. It's your only figure, and a recruiter may just note it | Know what you can and can't say about how it was counted |
| Case / Strategist | A quick "what would you do if…" on late orders | Low. Uncommon in a 30-minute screen, but possible | Clarify, then who to tell, then the options, then follow-up |
| Pressure | "Why you over someone with SAP?" | Low. Her message gives a friendly register | Pause, use your own sentences, concede SAP plainly |
| Values / Behavioral | "Tell me about a time…" from the advert's duties | Low. Quillmoor's published values couldn't be fetched, so these questions are themed on the advert | Pick a real occasion, or say plainly that none comes to mind |
| Peer Evaluator | Not this call | Not plausible. Hannah is the recruiter, not a future teammate | No bank |

## Question banks

### A. Conversational / Rapport (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Aim for about 60–90 seconds, in your own words, using only these beats: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Stop there and let her ask. Leave the reason for moving for when she asks (B1) | Almost every recruiter call opens this way, and it sets how she hears everything after. EXP because it's your history, told in the terms of F5, F2 and F3 |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Your words: "I'm hoping for £42,000." Then stop. If she follows up on the figure, give the same words again. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is first on her list. JD because it's the listed term. F9 shows your figure is inside the advertised band |
| A3 | "What's your notice period?" | JD | [generic] | Give your actual notice period as it stands in your current contract. If you're not sure of it, check before Thursday rather than estimating on the call | Notice is second on her list. Your material doesn't give it, so the only safe answer is the real one |
| A4 | "How would the hybrid pattern work for you? It's two days a week at Avonmouth." | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the pattern or the journey, your own words again, with nothing added | Third on her list. JD because it's the listed term, and F10 shows the advertised pattern fits |
| A5 | "What interests you about this role?" | JD | [generic] | Your material doesn't say what draws you to Quillmoor, so this answer is yours to choose. Point to parts of the advert that match work you already do, such as chasing late orders or keeping stock records accurate (F2, F3), and say in your own words what appeals. This is a separate question from why you're leaving, so don't repeat or add to B1 here. If nothing specific comes to mind beyond the work itself, say that plainly | Recruiters often ask "why here" alongside "why leave", to check the two answers fit together. JD because the best answer ties to the advert |

### B. Skeptic (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your words, kept whole: "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Then stop. If she asks a follow-up on it, give the same words again, with nothing added | Fourth on her list. EXP because it's your own situation. Your stated reason is the whole answer |
| B2 | "Your background is delivery scheduling at a wholesaler. This role coordinates production schedules between planning, the warehouse and QA. How does that translate?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **The highest-ROI prep in this pack.** Hold on what your sentence carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Name the limit before she asks, using the slot. Answer slot: if your scheduling involves agreeing timings with other people or teams, say who and how, in your own words. If it doesn't, or if you haven't worked with production schedules, planning or QA, say so plainly in your own words. That's a limit, not a confession. Then, if you like, say how you would get up to speed, as a plan. Possible follow-ups: (1) "Have you worked in manufacturing?" — say yes if you have, otherwise say so plainly; (2) "What about QA?" — the same slot. Each time, return to the deliveries you schedule and the suppliers you chase, and don't add to them | F1 is the widest gap between the advert and your material, and the advert's first duty sits on it, so some version of this will come up. JD because it scores the first stated requirement |
| B3 | "Have you used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Your words: "I've never used SAP. We run our own in-house stock system." Answer slot: if she asks what you do in that system, describe the tasks you actually do in it, in your own words. If you add anything about SAP, make it how you'd learn it, said as a plan | F7 is a gap you stated, and F8 is what's next to it. The advert calls ERP "a plus". JD because it's a listed requirement |
| B4 | "Which part of this role would you find hardest on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The gap you've already named is the honest pick: "I've never used SAP." Then say how you'd learn it, as a plan. If something else in the advert feels harder to you, say that instead, in your own words | A common screen question. Picking F7, a gap you stated yourself, is honest and stays off anything the pack can't support. JD because it's measured against the advert |

### C. Data-Driven Prober (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How did you count that?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the figure as you gave it: about a third, over a year. Answer slot, in your own words: how the fall was counted, what it's sensitive to, the assumption behind it you'd defend least (name that one before she does), and which part was yours. "I don't know exactly how it was counted" is an honest answer if it's true. Don't round it to a percentage | F3 has your only figure, and figures attract follow-ups. EXP because it tests the claim |
| C2 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say so and describe what you built in it, in your own words. If it was another tool, name it plainly and say what you use Excel for, if anything. Don't name functions or features you didn't use | F6 is the closest your material comes to Excel, and the advert asks for confidence with it. `[inferred]` because the link to Excel is the pack's reading |
| C3 | "Have you done any regular reporting, say on on-time delivery?" | JD | [generic] | Answer slot: the advert's weekly on-time dispatch line raises this. If you've reported on delivery performance, say what, how often and to whom, in your own words. If you haven't, say so plainly and return to the deliveries you schedule for the three depots | F4 has no evidence either way, so the honest answer needs to be ready before she asks. JD because it's a listed duty |

### D. Case / Strategist (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you an order is going to be a week late, and production is scheduled against it. What do you do?" | CASE | [generic] | Structure it out loud: confirm what's late and the new date; tell planning straight away; check what's already in stock and whether there's another source; agree a revised plan with planning, the warehouse and QA; then keep chasing and record what happened. It's a hypothetical, so it needs no claim about your past | Built on the advert's supplier-chasing and cross-team scheduling duties. `[generic]` because it's a standard pattern, not a fact about Quillmoor |
| D2 | "Weekly on-time dispatch dropped this week. How would you find out why?" | CASE | [generic] | Structure: check the number is right first; split the late orders by cause (supplier, stock record, production, warehouse); look for one cause behind several; then raise it with the team that owns it. There's no past to claim here | Built on the advert's weekly-reporting and stock-accuracy duties. `[generic]` for the same reason as D1 |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Quick one: why you over someone who's already used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause. Concede plainly: "I haven't used SAP." Then give what you have, at its own scope: four years as a logistics coordinator, scheduling deliveries for three depots and chasing suppliers when orders slip. Describe the work and let her draw the conclusion. Don't claim it makes up for SAP | It puts F7 under time pressure. JD because it scores against a listed requirement |
| E2 | "How much of that fall in discrepancies was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on what your sentence carries: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Your sentence doesn't say the spreadsheet caused the whole fall, so neither should you. Answer slot: if other things also changed that year, say so. If you can't separate them, say that plainly | It tests the attribution in F3. EXP because it's about what was yours |

### G. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time an order slipped and you had to chase a supplier." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence describes what you do in general, not one occasion. Pick a real one: it needs the order, what you did to chase it, and how it ended. If no particular time comes to mind, say so plainly, then describe how you chase suppliers when orders slip | The theme comes from the advert's "chase late orders" line, and F2 is the evidence. JD content, delivered as a behavioral question |
| G2 | "Tell me about a time you had to keep different teams working to one plan." | JD | [generic] | Your material doesn't cover this. Pick a time you kept people or teams working to one plan: it needs who was involved, what was at stake, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the deliveries you schedule for three depots), or how you would handle it | The theme comes from the advert's "between planning, the warehouse and QA" line, which is F1's gap. Selection scaffold, because none of your sentences carries this story |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, G2, D1 |
| Track supplier deliveries and chase late orders | G1, D1, A1 |
| Keep stock records accurate | C1, E2, D2, A1 |
| Report weekly on on-time dispatch | C3, D2 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B3, B4, E1 |
| £38,000–£44,000 | A2 |
| Hybrid, two days a week at Avonmouth | A4 |
| Hannah's topics: notice period, what's prompting a move | A3, B1 |

## Reverse questions

Hannah has said she'll cover the team and next steps, so only ask the ones she hasn't already answered.

| # | Question for Hannah | Why it lands |
|---|---|---|
| R1 | "How is on-time dispatch measured at the moment, and is there a target the team works to?" | It ties to the weekly reporting duty (F4) and shows you're already thinking about the job itself |
| R2 | "Which ERP or stock system does the team use, and how do new starters usually learn it?" | It raises the SAP point (F7) on your terms, as a question about getting up to speed |
| R3 | "Where do late supplier orders tend to come from at the moment?" | It's about the core of the job (F2), and the answer is useful prep for a hiring-manager round |
| R4 | "What would a good first three months look like for this role?" | It shows you're thinking past the offer, and the answer tells you what the next round will test |
| R5 | "Is this a new role or a replacement?" | The answer tells you whether you'd be building the processes or inheriting them, which shapes your next-round prep |
| R6 | "What does the next stage involve, and who would I meet?" | Ask only if she hasn't covered it. It tells you which persona to prepare for next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has coordinated production schedules, or worked across planning and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." Your material covers delivery scheduling, not production scheduling. B2's slot stays inside the scheduling you do |
| Managed three depots | Inflated form of F1 | "I schedule deliveries for our three depots." You schedule deliveries for the depots. Your sentence doesn't say you run them |
| "My spreadsheet cut discrepancies by a third" or "by 33%" | Inflated form of F3 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Keep "about", keep "over a year", and keep "fell" rather than "I cut" |
| Advanced Excel skills | Inflated form of F6 | F6's quote at its own scope. Your material mentions a rebuilt spreadsheet, not a level of Excel skill. C2's slot stays with what you built |
| Has used SAP | Negative you stated, F7 | "I've never used SAP. We run our own in-house stock system." No slot |
| Has ERP experience | Inflated form of F8 | "We run our own in-house stock system." Call it your in-house stock system, never an ERP |

## Sources

- **Provided:** Hannah Lowther's LinkedIn message (pasted), the job advert (pasted), and your own background notes (pasted).
- **Searches sent:** `Quillmoor Diagnostics values` (refused); `Quillmoor Diagnostics Avonmouth Bristol news` (refused); `Hannah Lowther Talent Partner Quillmoor Diagnostics` (refused). Web search permission wasn't granted in this session, so nothing came back. No pages were fetched.
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Search refused. It would have supplied value names to theme G1 and G2 and a reverse question. No values cheat sheet either way, since Hannah's message describes a recruiter call, not a values round |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message already fixes this session (one 30-minute recruiter phone call, topics listed), and with it the persona weights |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Search refused. It would have supplied a CO question and a sharper reverse question on recent company context, so the pack has no CO question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Search refused. Her public professional profile would have given a reverse question tied to her path, and the "Reading the interviewer" section is absent |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Your CV** → rows F1–F8 checked against your CV's own wording, and possibly new evidence for F4 (reporting) and F6 (Excel)
- **Web search permission** → Quillmoor's values (G1, G2, R-list), recent company news (a CO question and a sharper reverse question), and Hannah's public professional profile (a reverse question tied to her path)
- **A deeper research pass, once search is allowed** → up to 6 more searches and 2 more fetches, several more minutes; it adds a company context brief for the hiring-manager round
- **Your notice period, if you want it in the pack** → A3 written with your actual figure
- **Your answers to the slots in B2, C1, C2, C3 and B3** → rows F1, F3, F6, F4 and F8 rebuilt with your own words as quoted evidence
- **A `tuesday-dossier.md` from an earlier evaluation of this role** → verified evidence and a ready-made prohibited-claims list; this pack is complete without one
