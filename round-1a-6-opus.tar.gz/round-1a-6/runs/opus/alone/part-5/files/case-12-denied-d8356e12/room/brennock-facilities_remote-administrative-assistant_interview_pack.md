# Interview prep pack: Remote Administrative Assistant

**Company named in the invite:** Brennock Facilities Ltd
**Round:** one 30-minute video call with the office manager (relationship to you not stated; built as your likely future manager)
**Built from:** your message: the invite text, your description of the ad, and your background. No full ad text or CV yet.

## How to use this pack

- **Personas** describe *how* a question arrives (friendly chat, quiet probing, a live problem). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: values and behaviour, shown through a real past example
  - **EXP**: your work history, and whether it holds up under follow-ups
  - **JD**: the listed duties, and whether you can do them, gaps included
  - **CO**: company knowledge (none in this pack: research could not run)
  - **CASE**: a live problem from the job, talked through on the spot
- Provenance labels: **`[grounded]`** traces to your message; **`[inferred]`** is this pack's own derivation; **`[generic]`** is a common pattern for this kind of role, not a fact about this employer.
- An **answer slot** is an instruction for your answer in the interview, with two honest branches. Pick the one that's true.
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as described in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book, not someone's own calendar, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendar line makes a probe on handling a person's own diary (meetings, clashes, reminders) likely. If you managed anything in the physios' own diaries beyond the appointment book, say what, in your own words. If you didn't, say so plainly and stay with the book you ran |
| F2 | "booking travel" — the ad, as described in your message | none given | none | [grounded] | discovery | Strong evidence here would be any trip you have booked or arranged for someone, with what it involved. Answer slot: if you have booked travel for anyone, at work or otherwise, say what you booked and how. If you haven't, say so plainly, then say how you would go about it (C2 rehearses that) |
| F3 | "preparing documents in Word and Excel" — the ad, as described in your message | "I'm good with Word" — your message | medium | [inferred] | discovery | Your quote gives a level, not what you made with it. Words: "I'm good with Word." Answer slot: if you made letters, forms, notices or other documents in Word at the clinic or elsewhere, name them, in your own words. If not, say plainly where your Word skill comes from |
| F4 | "preparing documents in Word and Excel" — the ad, as described in your message | "okay with Excel" — your message | low | [inferred] | discovery | Your own level is the hold, so keep it: "I'm okay with Excel." Answer slot: if you have used Excel for anything (a list, a tracker, totals), say what, in your own words. If you've used it very little, say so plainly and say what you would learn first. Never round "okay" up |
| F5 | "processing supplier invoices" — the ad, as described in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, and supplier invoices are the paying side. Your quote doesn't say whether you worked on that side. Words: "I chased unpaid invoices." Answer slot: if any of the invoices you handled were bills the clinic had to pay a supplier, say what you did with them. If none were, say so plainly and stay with the chasing |

## Persona table

The invite's own words set the round: "The interview is a 30-minute video call with our office manager." That is one session with one person. The relationship isn't stated, so this pack treats the office manager as your likely future manager.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly opener, "tell me about yourself", motivation | High. A 30-minute call leaves little room for formal rounds, so much of it will be conversation, and it is still scored | A rehearsed 90-second arc built only from what you've said about your background (A1). Treat casual questions about the duties as scored |
| Skeptic | Quiet probing of the gaps between your background and the duties | High. A manager hiring for these duties will test the rows where your evidence is thin: F2, F4, F5 | Rehearse B1 until it's boring. Hold your own words, say limits plainly, give a learning plan stated as a plan |
| Case / Strategist | "What would you do if…" problems from the job | Medium. Hiring-manager prior: they want to see how you'd handle their actual tasks | Clarify first, then structure out loud: what you'd check, who you'd ask, what you'd do, how you'd confirm |
| Values / Behavioral | "Tell me about a time…" | Low to medium. No values round is documented, but short admin interviews often include one or two behaviour questions | Pick real examples. Use "we" for context and "I" for your part. If nothing fits, say so and give the nearest real thing |
| Data-Driven Prober | Digging into the specifics behind "four physios" and the invoice chasing | Low. Your background has few figures to probe | Keep each number attached to what it counts. Say plainly what you don't know |
| Pressure | A time-boxed "why you" or a "how much was really you" | Low. Unusual for this kind of call, but cheap to rehearse | Pause, restate, hold your own words through two follow-ups |
| Peer Evaluator | — | Dropped: this is a one-to-one with the office manager, not a peer panel | — |

## Question banks

IDs: A, B, C, D, E, G by persona (F is kept for fit-snapshot rows).

### A. Conversational / Rapport (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | 90 seconds, using only the beats your sentence states: two years, receptionist, a physiotherapy clinic, the appointment book for four physios, chasing unpaid invoices. Then a line on why this role, in your own words (A2). Don't add duties you haven't named. If asked for more, use the answer slots in B and E | The near-certain opener, and the one that sets the interviewer's picture of you; EXP because it frames your history from F1 and F5 |
| A2 | "What made you apply for this role?" | EXP | [generic] | Answer slot: give your real reason, in your own words, and link it to the duties the ad listed (calendars, travel, Word and Excel documents, supplier invoices). Don't claim experience with any of them here; that comes later | A motivation question in almost every admin interview; EXP because it checks your story hangs together. `[generic]` because it's a common pattern, not this employer's |
| A3 | "What did a normal day on the front desk look like?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Describe the day in your own words, built around the two parts your sentence carries: the appointment book and chasing invoices. Anything else you mention should be something you actually did, said plainly | A friendly question that is really an EXP probe on F1 and F5. Rehearse it so you don't inflate it while relaxed |
| A4 | "Have you worked remotely before?" | JD | [grounded] | Answer slot: the job title in the invite is "Remote Administrative Assistant". If you've worked remotely, say where and how you kept in touch. If you haven't, say so plainly and describe how you'd set up your working day | Remote is in the job title, so it's a likely casual check. JD because it's a term of the role |

### B. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role involves a fair bit of Excel. How comfortable are you with it, honestly?" | JD | [grounded] "okay with Excel" | **The highest-ROI rehearsal in this pack.** Start with your own level: "I'm okay with Excel." Answer slot: if you have used it for anything, say what, in your own words. If you've used it very little, say so plainly. Name the limit before you're asked: say what you haven't done yet. Then give a plan: what you'd learn first and how, said as a plan, not a past. Follow-up 1 ("what does okay mean?"): go back to your slot answer and add nothing. Follow-up 2 ("could you build X for me?"): if you haven't done X, say so, and say how you'd learn it. Never upgrade to "good" or "strong" to smooth the moment | F4 is your weakest stated area against a listed duty, and the most likely objection to you specifically. JD because it scores the Excel line directly |
| B2 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if you have, at work or otherwise, say what you booked and how. If you haven't, say so plainly, then move to how you would do it (C2 rehearses the structure). Don't call personal trips work experience | F2 has no evidence yet, and the ad lists the duty. JD because it's a stated requirement |
| B3 | "Supplier invoices are part of this job. What experience do you have with that?" | JD | [grounded] "chased unpaid invoices" | Stay with your quote: "I chased unpaid invoices." Answer slot: if any invoices you handled were bills the clinic had to pay a supplier, say what you did. If none were, say so plainly. Then be clear that chasing is a different side from paying, and say how you'd learn their process. Never describe it as "accounts payable" or "processing invoices" | F5 is a real but adjacent match, so it's the next most likely probe. JD because it targets a named duty |
| B4 | "I don't see managing a manager's diary in your background. How would you handle mine?" | JD | [grounded] "I ran the appointment book for four physios" | Start with the book, in your own words: "I ran the appointment book for four physios." Answer slot: if you also moved or booked things in the physios' own diaries, say what. If you didn't, say so plainly. Then a plan for their diary: ask how they like it run, confirm priorities, and check in before moving anything. Say it as what you would do | F1 is the bridge from an appointment book to a person's calendar. The Skeptic will press on where it stops. JD for the calendar duty |

### C. Case / Strategist (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two people want the same slot in my calendar. What do you do?" | CASE | [generic] | Clarify first: whose call is it, and does either meeting have a deadline? Then: check with the manager or use their stated priorities, offer each person alternatives, confirm the final times in writing, update the calendar. The question asks nothing about your past, so the guidance claims nothing | A live calendar problem from the F1 requirement; CASE because it scores reasoning, not history |
| C2 | "I need to be in another city for a 9am meeting next Tuesday. Talk me through booking it." | CASE | [generic] | Clarify: travel the night before or that morning? Budget or company policy? Train or flight, any preferences? Then: compare two or three options, get approval before paying, book, put times, references and addresses in the calendar, send the itinerary. Say out loud anything you'd need to check | The F2 duty with no evidence yet, so a structured plan is your strongest honest answer |
| C3 | "A supplier invoice arrives and it doesn't match what we ordered. What do you do?" | CASE | [generic] | Don't pay yet. Check it against the order and what was delivered, contact the supplier about the difference, tell your manager, and note what happened and the outcome. Ask how they normally approve invoices | The F5 requirement asked as a live problem; CASE because it's about judgement, not experience |
| C4 | "Say I need a simple tracker of this month's supplier invoices. How would you set it up?" | CASE | [generic] | Talk through the columns: supplier, invoice number, date, amount, due date, paid or not. Mention sorting by due date and a total. Say honestly which parts you'd need to look up, in line with your B1 answer | Tests the F4 Excel line in a practical way. Your answer here has to match what you said in B1 |

### D. Values / Behavioral (low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a schedule fell apart and you had to sort it out." | VAL | [generic] | Selection scaffold: pick a real time when bookings clashed, someone cancelled, or a day had to be rearranged. It needs what went wrong, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the ad's calendar duty (F1). VAL because it scores behaviour shown in a real example |
| D2 | "Tell me about a time you had to tell someone something they didn't want to hear." | VAL | [generic] | Selection scaffold: a real time you raised a problem or said no to someone, ideally someone senior. It needs what was at stake, how you said it, and where things ended up. If no such time comes to mind, say so plainly, then give the nearest real thing, or how you would handle it | A common behaviour stem, and admin roles often require saying no to a diary request. `[generic]` because no published values were available |
| D3 | "When did you put a customer ahead of the usual way of doing things?" | VAL | [generic] | Selection scaffold: a real time you bent a routine for someone you were serving, with what you changed and why. If no such time comes to mind, say so plainly, then give the nearest real thing, or how you would handle it | A common behaviour stem; VAL because it scores judgement shown in a past example |

### E. Data-Driven Prober (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Four physios: how busy was the book on a typical day?" | EXP | [grounded] "I ran the appointment book for four physios" | Keep "four" attached to physios, not appointments. Answer slot: if you know roughly how many appointments a day, say it as an estimate and how you know. If you don't, say plainly that you don't have a figure and describe the book instead | The one number in F1, and probers ask what a number counts. EXP because it tests a stated detail |
| E2 | "When you chased unpaid invoices, how did you keep track of who owed what?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you used a list, a system or a routine, describe it in your own words. If there wasn't one, or someone else kept it, say so plainly and describe how the chasing worked | F5's quote gives the activity, not the method. Probers ask for the method. EXP because it tests what was yours |

### G. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you for this role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Pause, then three beats from your sentence: two years on reception, the appointment book for four physios, chasing unpaid invoices. Add your A2 reason, then stop. No new claims to fill the time | A time-boxed version of A1 and A2. Rehearsed, it becomes easy marks. EXP because it summarises F1 and F5 |
| G2 | "The invoice chasing: how much of that was actually you?" | EXP | [grounded] "chased unpaid invoices" | Hold your own words: "I chased unpaid invoices." Answer slot: if others shared the chasing, say which part was yours. If it was all yours, say so. Hold through two follow-ups by repeating what you did, not adding to it | An attribution probe on F5. EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 managing calendars | A1, A3, B4, C1, D1, E1, G1 |
| F2 booking travel | B2, C2 |
| F3 Word documents | — none directly: rated "good" by you and lower risk than F4. Add one if the full ad stresses document work |
| F4 Excel | B1 (highest ROI), C4 |
| F5 supplier invoices | A3, B3, C3, C4, E2, G2 |
| Remote working (job title) | A4 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a typical week in this role look like?" | It shows you're picturing the actual work, and the answer tells you which rows to emphasise for the rest of the call |
| "Which tasks would you most want me to take off your plate first?" | It invites the office manager to describe their priorities, which you can answer with your F1 and F5 strengths |
| "Which tools do you use for calendars and invoices?" | It signals you're thinking about ramping up, and it gives your B1 learning plan something concrete to point at |
| "How does the team stay in touch day to day when everyone's remote?" | Remote is in the job title, and this shows you've thought about how remote work actually runs |
| "What would a great first three months look like?" | It moves the conversation to outcomes and gives you a clear target if you're hired |
| "Is the whole call on video, and is there anything you'd like me to have ready?" | Practical prep: you'll know whether to have notes or examples to hand |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries for four physios | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The pack's observation: your material says an appointment book, not anyone's own calendar. B4's slot stays inside the book |
| Processed supplier invoices, or handled accounts payable | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The pack's observation: your material says chasing, not paying. B3's slot stays inside the invoices you handled |
| Strong, good or advanced at Excel | Contradicted by your own words, F4 | The contradicting quote, and nothing more: "okay with Excel" |

## Sources

- **Provided:** your message, including the invite text as pasted, your description of the ad, and your background.
- **Searches sent:**
  - `Brennock Facilities Ltd values`: refused
  - `Brennock Facilities Ltd interview process administrative assistant`: refused
  - `Brennock Facilities Ltd news`: refused
- **Fetches:** none.
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The search was refused. It would have supplied any published values to theme the D bank; without them, D is `[generic]` |
| 2. `{company} interview process {role family}` | unavailable | The search was refused. The invite's own words already set the round: one 30-minute video call with the office manager |
| 3. `{company} strategy` / recent news | unavailable | The search was refused. It would have supplied CO questions; there are none in this pack |
| 4. `{interviewer name} {company}` | n/a | No name was given, only the title "office manager", so there was no query to form |
| 5. representative `{role title}` JD | unavailable | No call was sent: search was refused in this session. It would have filled out the requirement list beyond your summary of the ad, labelled `[inferred]` |

## Upgrade menu

- The full ad text → F1 to F5 quoted from the ad itself rather than your summary, plus any duties your summary left out, each with its own question
- Your CV → more of your own sentences to build answers on, and stronger Provenance across A, B, E and G
- Whether the office manager would be your manager → persona weights recomputed from a known relationship rather than an assumption
- Your answers to the slots in F2, F3, F4 and F5 (travel, Word documents, Excel use, which side of invoicing you were on) → those rows upgraded, and B1 to B3 rebuilt on your own words
- Allowing web search → targets 1, 2, 3 and 5 rerun; and, if you want it, a deeper pass (up to 6 more searches and 2 more fetches, several more minutes)
- A `tuesday-dossier.md` → evidence-checked guardrails and the main objection taken from verified evidence rather than inferred
