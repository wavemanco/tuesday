# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Who you're talking to:** Hannah Lowther, Talent Partner (recruiter)
**Format:** 30-minute phone call, Thursday at 2pm. She will ring the mobile number on your application.
**What she said she will cover:** salary expectations, notice period, how the hybrid pattern would work for you, and what's prompting a move. Then she'll tell you about the team and the next steps.

## How to use this pack

Two things organise every question:

- **Personas** describe *how* a question gets asked: a friendly chat, a quiet probe, a time-boxed challenge.
- **Types** describe *what* is being scored:
  - **VAL**: behaviour and values. Does a real past example show how you work?
  - **EXP**: your experience. Does what you've said hold up, and which part was yours?
  - **JD**: the job description. Can you do the listed job, gaps included?
  - **CO**: the company. How much homework have you done on the employer?
  - **CASE**: a live problem from the role, worked through out loud.

The guidance is scaffolding, not a script. Say it in your own words. Each row's Provenance cell shows which of your own sentences the guidance rests on. If a cell gives you a sentence to say, it is one you wrote to me.

**Answer slots.** Where your material doesn't say something the interviewer may ask about, the pack gives you two honest options instead of words: if you did it, say how in your own words; if you didn't, or it wasn't yours, say so plainly. These are instructions for the call. They are not questions for me.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material describes delivery scheduling for three depots, not production schedules across planning, the warehouse and QA. Keep your words at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe likely on who else your schedules depended on. If your depot scheduling meant agreeing timings with other teams, say which teams and what was yours to agree, in your own words. If it didn't, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Your sentence covers chasing slipped orders, but it doesn't show how deliveries get tracked. Answer slot: if you keep a record of what's due from suppliers and when, say how, in your own words. If tracking sits with someone else, or there's no such record, say so plainly and stay with the chasing |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. This is a statement with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but the figure will draw questions. Keep it exactly as you said it: "about a third", "over a year". The sentence states two facts, that you rebuilt the spreadsheet and that discrepancies fell. It doesn't say one caused the other, so let the interviewer ask (C1, C2) |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Strong evidence here would be a regular report you produced: what it measured and who read it. Answer slot: if you have produced a regular report on deliveries or dispatch, say what it covered and who used it, in your own words. If you haven't, say so plainly, then describe how you would set one up, as a plan |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Use the line as it stands: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your material says "spreadsheet" but doesn't name the tool. Answer slot: if the stock-count spreadsheet was in Excel, say so and describe what you built in it, in your own words. If it was another tool, name it plainly and say how you'd get confident in Excel |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the SAP part | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | No wording can close this gap, and you've said so yourself. Words: "I haven't used SAP." Then explain how you would learn it, as a plan and never as past experience. Note that the advert calls ERP a plus, not a requirement |
| F9 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" part | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Keep your words at their own scope: "we run our own in-house stock system." Your material doesn't say what you do in it. Answer slot: if asked, describe your own use of the system in your own words. If your use is narrow, say so plainly |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Gate met, in your own words. Say them whole and add nothing: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| F11 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Gate met: your figure sits inside the advertised band. Your words: "I'm hoping for £42,000." |

## Persona table

The session is set by Hannah's own message: one 30-minute call with her, covering the four topics she named, then the team and next steps. Her public profile couldn't be checked because web search wasn't permitted, so the weights rest on what usually happens in recruiter screens, not on anything about her.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | A friendly walk through your background, then her four topics | Highest. A recruiter screen is mostly this, and her message lists the topics. The risk is treating it as unscored | Have a 90-second background answer built only from F6, F1 and F4's sentences. Answer each logistics question in your own words, then stop |
| B. Skeptic | Quiet checks on the gaps: production versus depot scheduling, SAP, why this role | High. A light Skeptic is normal in screens, and F1 and F8 are the obvious places to press | Rehearse B1 until it's boring. Concede SAP plainly. Never stretch F1's sentence to cover more |
| C. Data-Driven Prober | Asks how the one-third figure was counted, and about Excel and reporting | Medium. A recruiter may not dig deep, but the figure is the one number you gave and the advert asks about Excel and reporting | Know what you can and can't say about how the figure was counted. Say plainly when you don't know |
| D. Pressure | A quick "why you" against a candidate who has used SAP, and a time-boxed first-month question | Low-medium. Rare in a recruiter's register, but cheap to rehearse | Pause, concede the real gap, hold on what your sentences carry |
| E. Case / Strategist | A short "what would you do if…" about a late supplier or a dispatch dip | Low. More typical of a hiring-manager round, but the advert's duties make it an easy question for anyone to ask | Clarify first, say who you'd tell, list the options, say what you'd record |
| G. Values / Behavioural | "Tell me about a time…" themed on the advert's duties | Low. Hannah didn't name a values round, and the company's published values couldn't be fetched | Pick a real instance. Tell only what happened. Use "we" for context and "I" for your part |

The Peer Evaluator persona is left out because no peer is on this call. Bank IDs skip F so they can't be confused with fit-snapshot rows.

## Question banks

### A. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | About 90 seconds, built from these three sentences only: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Finish on what drew you to this advert, in your own words. Don't go into why you're leaving here; A2 covers that | This almost always opens a screen, and it is where F6's two-plus years gets checked without anyone saying so. Tagged JD because it scores the experience requirement, though it's delivered as a story |
| A2 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your words, whole: "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it plainly and stop. If she follows up on it, give her your words again. Add nothing | Hannah named this topic. Tagged EXP because the reason for leaving is part of your work history. Your own statement fills the answer, so the pack adds nothing to it |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | "I'm hoping for £42,000." If she follows up on pay, your words again. If she asks what you earn now: "I'd rather focus on the range for this role." Give no figure | Hannah named this topic, and F11 shows your figure sits inside the advertised band. Tagged JD because pay is one of the listed job's terms |
| A4 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, as your contract states it. If she asks when you could start, the same applies: give your actual notice period | Hannah named this topic. Your material doesn't state a notice period, so check your contract before the call. Tagged JD because the start date is one of the job's terms |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute, or more days, or anything else on this topic, your words again. Add nothing | Hannah named this topic, and F10 is a gate your own words meet. Tagged JD because the office pattern is one of the advert's terms |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is scheduling deliveries for depots. This role coordinates production schedules between planning, the warehouse and QA. How does what you've done fit?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **The highest-ROI rehearsal in this pack.** Hold on: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if your depot schedules meant agreeing timings with other teams, say which teams and what was yours, in your own words. If they didn't, say so plainly and stay with the three depots. Follow-up 1, "but that's not production planning": don't argue and don't stretch; go back to the depots sentence. Follow-up 2, "so you'd be learning that on the job?": concede, in your own words, what would be new to you, then say what you'd want to learn first, as a plan. Name that limit before she does | F1 is the advert's headline duty and your thinnest bridge, so some version of this question is likely. Tagged JD because it scores the first listed responsibility |
| B2 | "Have you used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We run our own in-house stock system." Then stop, or add a short plan for learning SAP, said as a plan. If asked what the in-house system does, describe your own use in your own words. If your use is narrow, say so plainly | The advert names SAP, so a recruiter is likely to tick this box. F8 is a gap you stated yourself, and F9 is the honest adjacent fact. Tagged JD because it scores a listed plus |
| B3 | "Which part of this job would you find hardest on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Pick something real. SAP is the honest candidate from your own words: "I haven't used SAP." Add a learning plan, said as a plan. If something else in the advert would be newer to you, name it in your own words. Don't pick a fake weakness | This is a standard Skeptic stem, and F8 gives you a true answer ready to use. Tagged JD because it scores self-assessment against the listed duties |
| B4 | "Why Quillmoor, and why this role in particular?" | CO | [generic] | Keep this separate from why you're leaving (A2). Answer slot: if something about the work draws you, such as the advert's duties or the company's field, say what, in your own words. If what draws you is mostly the role's duties, say which ones. Web search wasn't permitted, so the pack has nothing researched about the company to offer here | Hannah will want a reason that points towards this job, not only away from your current one. Tagged CO because it tests your homework on the employer, though here it can only rest on the advert |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the figure exactly as you said it: about a third, over a year. Don't turn it into a percentage. Answer slot: say how the discrepancies were counted, what the figure is sensitive to, and which assumption behind it you'd defend least, all in your own words. If you don't know exactly how it was counted, say that plainly. That is an honest answer | F4 holds the one number in your material, and a number in conversation draws "how do you know?" Tagged EXP because it tests whether your claim survives scrutiny |
| C2 | "How much of that drop was down to the spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Your sentence states two facts: you rebuilt the spreadsheet, and discrepancies fell. It doesn't claim one caused the other. Answer slot: say which part was yours. If you know what else changed that year, say so. If you can't separate the causes, say that plainly | Tests attribution on F4. A candor answer here builds credibility. Tagged EXP because it is about what was actually you |
| C3 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] | Answer slot: if you have produced a regular report on deliveries or dispatch, say what it covered and who used it, in your own words. If you haven't, say so plainly, then describe how you would set up a weekly on-time report, as a plan | F5 is a listed duty your material doesn't cover yet, so rehearse the honest answer before the question arrives. Tagged JD because it scores a stated responsibility |
| C4 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say so and describe what you built in it, in your own words. If it was another tool, name it plainly. Don't name functions or features you didn't use | Excel is a stated requirement, and F7 shows a spreadsheet without naming the tool. Tagged JD because it scores a requirement directly |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Quickly: why should I put you forward over someone who's used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause. Concede first, plainly: "I haven't used SAP." Then hold on what your sentences carry: four years as a logistics coordinator, deliveries for three depots, chasing suppliers when orders slip, and the rebuilt stock-count spreadsheet, with discrepancies down about a third over a year. Describe what you did and let her draw her own conclusion. If she pushes a second time, give the same hold, shorter | F8 is the gap a time-boxed challenge is most likely to target. This rehearses the hold-then-concede shape on F6, F1 and F4. Tagged JD because it scores you against a listed plus |
| D2 | "Sixty seconds: what would you do in your first month?" | CASE | [generic] | A plan, not a past. Learn how schedules flow between planning, the warehouse and QA. Learn the ERP or stock system they use. Find out how the weekly on-time dispatch figure is put together today. Meet the suppliers you'd be chasing. Keep to time | A time-boxed version of a common question. The plan follows the advert's own duty list. Tagged CASE because it is a live problem with no claim about your past |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a key delivery will be a week late, and production is planned around it. What do you do?" | CASE | [generic] | Structure it: what you'd confirm with the supplier first (the new date, whether part of the order could come sooner), who you'd tell (planning, the warehouse, QA), what options you'd bring them, and what you'd record so it shows up in reporting. This question needs no claim about your past, so the guidance makes none | A live problem built from the advert's "chase late orders" and scheduling lines (F1, F3). Tagged CASE because it is reasoning out loud, not a record |
| E2 | "On-time dispatch dropped this week. How would you find out why before the weekly report?" | CASE | [generic] | Clarify what counts as on time. Split the late orders by cause, such as stock not available, a QA hold, a late supplier, or warehouse capacity. Check whether the stock records were right. Say what you'd report and what you'd fix next week | Built from the advert's weekly reporting and stock-accuracy lines (F5, F4). Tagged CASE because it scores structure |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time a supplier's late order put a schedule at risk." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pick one occasion behind your sentence about chasing suppliers when orders slip. It needs the order, what you did, and how it ended. Tell only what happened, in your own words. If no single occasion comes to mind, say so plainly and describe how you chase a slipped order, as your sentence puts it | The theme comes from the advert's "chase late orders" line, and F3 says you do this. Tagged VAL because it scores behaviour through one real example |
| G2 | "Tell me about a time you made stock records more accurate." | VAL | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F4. The beats are the two your sentence states: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slot: the advert's accuracy line makes "what prompted it?" likely. If you noticed a problem with the old spreadsheet, say what it was. If you were asked to rebuild it, say so plainly. Don't claim the rebuild caused the fall (see C2) | The theme comes from the advert's "keep stock records accurate" line. Tagged VAL because it asks for an instance rather than a figure |

### Requirement coverage

| Requirement (advert or recruiter) | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, E1, D2 |
| Track supplier deliveries | E1, G1 |
| Chase late orders | G1, E1 |
| Keep stock records accurate | C1, C2, G2, E2 |
| Report weekly on on-time dispatch | C3, E2 |
| 2+ years in operations or logistics coordination | A1, D1 |
| Confident with Excel | C4 |
| ERP experience (SAP or similar) a plus | B2, B3, D1 |
| Hybrid: two days a week at Avonmouth | A5 |
| £38,000–£44,000 | A3 |
| Notice period (Hannah's topic) | A4 |
| What's prompting a move (Hannah's topic) | A2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which ERP or stock system do you run, and how do new coordinators get trained on it?" | The advert names SAP as a plus, and F8 is your one stated gap. Asking about training shows you've already thought about how you'd get up to speed |
| R2 | "How is on-time dispatch measured today, and who reads the weekly report?" | It shows you read the advert closely, and the answer tells you what F5's reporting would actually involve |
| R3 | "Day to day, how does the coordinator sit between planning, the warehouse and QA? Who would I work with most?" | It goes straight at the advert's headline duty (F1). The answer gives you real detail to use in any later round |
| R4 | "Are the two Avonmouth days fixed, or chosen with the team?" | It's practical, and it builds on the pattern you've already said works for you (A5) |
| R5 | "What would a good first three months look like in this role?" | It gives you the hiring team's own measure of success to prepare against for the next stage |
| R6 | "What are the next steps after this call, and roughly what's the timeline?" | Hannah said she'd cover this. If she hasn't by the end, asking shows you're keen and tells you what to prepare for |

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." Plus F9's sentence at its own scope: "we run our own in-house stock system." |
| Coordinated production schedules between planning, the warehouse and QA | An inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation, not words for you: your material says deliveries for three depots, not production schedules. B1's answer slot stays inside the depots |
| The spreadsheet rebuild caused the one-third fall | An inflated form of F4. The sentence says "rebuilt … and discrepancies fell", which is two facts, not a cause | F4's sentence at its own scope. C2's answer slot asks only which part was yours |
| Rebuilt the stock system | An inflated form of F4. A spreadsheet is not a system | F4's sentence at its own scope: "I rebuilt our stock-count spreadsheet" |
| A pay figure other than £42,000, or a range around it | A reworded form of your stated figure, F11 | "I'm hoping for £42,000." |
| Open to more than three office days | Contradicted by your sentence, F10 | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

## Sources

**Provided documents:** the Quillmoor Diagnostics advert text, Hannah Lowther's LinkedIn message, and your own background notes, all pasted into this conversation.

**Searches sent:**

- `Quillmoor Diagnostics values`: refused (web search not permitted in this session)
- `Quillmoor Diagnostics Avonmouth news`: refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have themed the G bank on the company's own value names |
| 2. `Quillmoor Diagnostics interview process` | skipped | Hannah's message already fixes this session (a 30-minute call with her, and its topics), so the persona weights follow it |
| 3. `Quillmoor Diagnostics` strategy and recent news | unavailable | The search was refused. It would have given B4 a researched answer and added one company-knowledge question built on facts |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have added a read on the interviewer from her public professional profile, plus a reverse question tied to her path |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission for web search → targets 1, 3 and 4 rerun: Quillmoor's published values to theme the G bank, recent news so B4 and one company question rest on facts, and Hannah Lowther's public professional profile for an interviewer read and a tailored reverse question
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → company strategy context and reports on the interview process for the rounds after this screen
- Your CV → its own sentences enter the fit snapshot, possibly closing F2, F5 and F7
- Telling me, outside a drill, which tool the stock-count spreadsheet was built in, and whether you've produced any regular reports → F5 and F7 move from answer slots to your own words, along with C3 and C4
- Your notice period, if you'd like it rehearsed in your own words → A4 holds it
- Whatever Hannah says about next steps → a mini-pack for each later round, with its own persona weights
- A tuesday-dossier.md, if you ever have one → the main objection would be derived from evidence rather than inferred, and its prohibited claims would bind every cell. This pack is complete without one
