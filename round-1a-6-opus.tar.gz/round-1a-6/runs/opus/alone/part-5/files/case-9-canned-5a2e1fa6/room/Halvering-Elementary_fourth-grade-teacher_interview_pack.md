# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Orrinsford Community School District · 45-minute panel, Thursday**
**Panel:** Principal Dolores Vantongeren (hiring manager) and two members of the fourth-grade team (peers)

---

## How to use this pack

Two labels sit on every question:

- **Persona** says *how* a question is asked: who is asking, and in what style.
- **Type** says *what* is being scored:
  - **VAL**: whether your past behavior shows the district's published beliefs
  - **EXP**: whether what your CV says holds up, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: whether you know the district's and school's current direction
  - **CASE**: a live classroom problem, solved out loud

**Provenance labels:** `[grounded]` means traceable to your CV, the invite, or a source listed under Sources. `[inferred]` means derived from a representative job description, because you haven't shared the real posting. `[generic]` means a common pattern for this kind of interview, with no claim about this school.

The guidance gives you a structure to work from. It is not a script. Use your own words, and say only what you actually did.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | On your material the requirement is met, and grade 4 falls inside the 1–6 endorsement. It is rated medium only because nothing was checked against the license record. Verifying the record is up to you, and this pack looked nothing up. If it comes up, describe the license the way your CV does. You don't need to say the license number aloud |
| F2 | "Fourth Grade Teacher" — HR invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | You have said this gap yourself, and no wording closes it. Words: "I haven't taught fourth grade." Follow it with what you would do to get ready, framed as a plan and never as something you've already done. Add nothing to make the gap sound smaller. This is the highest-ROI rehearsal in the pack (A1) |
| F3 | "experience in grades 3 to 5 preferred" — representative JD | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade is inside the range. Lead with it in its own terms: six years, third grade, a public elementary school in Joliet |
| F4 | "plan and teach reading" — representative JD | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've run the after-school reading club for the last two years." — your CV | medium | [inferred] | transferability | Both sentences are about reading work: a curriculum move and a club. Neither says how you teach reading in your own classroom, and the words stay at their own scope. Answer slot: the posting's reading line makes a question about your own reading instruction likely. If you taught reading in your third-grade classroom, say how, in your own words. If you didn't, say so plainly and stay with the curriculum move and the club |
| F5 | "writing, math, science and social studies" — representative JD | none given | none | [inferred] | discovery | Your material doesn't say which subjects you taught. Answer slot: if you taught any of these in third grade, name which ones and how, in your own words. If you didn't teach some of them, say so plainly and say how you would prepare for them |
| F6 | "differentiate instruction using assessment data" — representative JD | none given | none | [inferred] | discovery | Your material doesn't show this either way. Answer slot: if you have used assessment results to group students or change your teaching, say how, in your own words. If you haven't, say so plainly and say what you would look at first |
| F7 | "keep clear classroom routines" — representative JD | none given | none | [inferred] | discovery | Answer slot: if you have routines you set up and used in your classroom, name one and how you taught it, in your own words. If none comes to mind, say so plainly and describe how you would set them up (B1) |
| F8 | "communicate regularly with families" — representative JD | "I write a weekly email to families." — your CV | medium | [inferred] | none | The sentence already meets the requirement. Say it as written: a weekly email to families |
| F9 | "Families Are Partners: each teacher speaks with every family each term." — district Mission and Beliefs page | "I write a weekly email to families." — your CV | low | [inferred] | discovery | The district's belief is about talking with every family each term, and your sentence is about a weekly email. Don't present the email as the same thing. Answer slot: if you have spoken with every family, through conferences or calls for example, say how, in your own words. If your contact was mainly the email, say so plainly and say how you would reach every family each term |
| F10 | "work with the grade-level team" — representative JD | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've never been a team lead." — your CV | medium | [inferred] | transferability | Both sentences stand together: you led your grade level's move to a new curriculum, and you have not been a team lead. Words: "I haven't been a team lead. I led our grade level's move to a new reading curriculum in 2024." Answer slot: if they ask what leading the move involved, say which parts were yours to decide or run, in your own words. If parts were decided by someone else, say so plainly |

---

## Reading the interviewer

Public professional footprint only. Nothing personal was searched.

| What the record shows | Source | What it means for Thursday |
|---|---|---|
| Principal at Halvering Elementary since 2022, after nine years as a reading specialist | Illinois principals' forum speaker page, search result | Reading instruction is her home ground. Expect B2 and D2 to come from her, with follow-up questions on specifics |
| Gave a 2025 forum talk, *Small Groups, Big Readers*, on weekly reading conferences in grades 3 to 5 | Same page | Don't repeat her talk back to her. Answer from your own practice, and use reverse question R1 to ask about it |
| Shared ground with you: reading in grades 3 to 5 | Her page above, and F3 and F4: "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | This is shared subject matter, not a shared career move. Your material shows no step like her move from reading specialist to principal, so don't present it as one |

Nothing was found about the two fourth-grade team members because no names were given.

---

## Persona table

| Persona | How it shows up on this panel | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal asks about F2 and F10, the stated gaps: no fourth grade, no team lead | High. A hiring manager is reducing risk, and F2 is the clearest risk in your material | Rehearse A1 until it feels routine. Say the gap plainly, give a concrete plan, and don't bluff |
| Case / Strategist | Live classroom problems: routines, a struggling reader, an upset parent | High. The district's hiring page says panels ask about reading instruction, classroom routines and work with families, and a principal tests how you'd handle real situations | Clarify, then structure (what first, what next, how you'd know it's working), then think out loud |
| Peer Evaluator | The two fourth-grade teachers ask what working with you would be like | Medium-high. Two of the three panelists are your future teammates | Talk about what you'd bring them, not only what you'd need. Name collaboration principles rather than guessing how their team works |
| Data-Driven Prober | Follow-ups on the reading club, the curriculum move and assessment data | Medium. The principal's reading-specialist background, plus the posting's "assessment data" line | Know what you can and can't say about each claim, and say "I don't know" plainly where that's true |
| Values / Behavioral | Questions themed on the district's three published beliefs | Medium. The district says the three beliefs "guide every hire" | Have a real example for each belief. Where you don't have one, say so plainly |
| Conversational | The opener and the license check | Low. It is usually brief, but it is still scored | A 90-second introduction built from your CV sentences (F1Q) |
| Pressure | A sharper version of A1 or a challenge on the curriculum move | Low. Nothing points to a stress-style panel, but it costs little to practice | Pause, restate the question, hold your position for two follow-ups, then concede only what's actually true |

Persona weights are based on the district's own hiring page, which describes one 45-minute panel of the principal and two grade-level teachers, and on the invite. The pack doesn't rely on a guessed interview pattern.

---

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. How would you handle that?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | **Highest-ROI prep in this pack.** Start with the plain acknowledgment: "I haven't taught fourth grade." Then your evidence in its own words: six years teaching third grade at a public elementary school in Joliet. Then a plan, framed as something you would do: what you'd learn before August, whom on the team you'd ask, and how you'd check you were on track. Prepare for three follow-ups. (1) "What will be hardest?" Name one real thing. (2) "Why not hire someone who has taught it?" Hold your ground on the six years and concede the fourth-grade content: "That part would be new to me." (3) "What would you need from us?" Answer with C1. Answer slot: the posting lists writing, math, science and social studies. If you taught any of these in third grade, say which, in your own words. If you didn't, say so plainly | F2 is the gap you stated yourself, and a panel hiring for fourth grade will ask about it in some form. JD because it scores the role's stated grade |
| A2 | "Have you been a grade-level team lead?" | EXP | [grounded] "I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" | "I haven't been a team lead." Then: "I led our grade level's move to a new reading curriculum in 2024." Keep both sentences at their own scope, and never let "led the move" turn into "led the team." Answer slot: if they ask what leading the move involved, say which parts were yours, in your own words. If some decisions were made by others, say so plainly | F10 sets two of your sentences side by side, and a panel that includes team members will check where one ends and the other begins. EXP because it tests what was actually yours |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick one real thing and say it plainly. The fourth-grade content (F2) is the one your material already names: "I haven't taught fourth grade." If something else in F5 to F7 is truly weaker for you, you can name that instead. Either way, follow it with what you would do about it, framed as a plan | A standard Skeptic stem. F2 gives you an honest answer you can say without hesitating, and a vague answer scores worse than a real one. JD because it is about the role's demands |
| A4 | "What's prompting the move after six years?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: give your actual reason in your own words, short and forward-looking. Don't criticize your current school. If part of the reason is wanting fourth grade or this district, say what draws you, from what you actually know of it | The six years in F3 make this question likely. Your material doesn't include your reason, so it is a slot. EXP because it tests whether your story is consistent |
| A5 | "Why Halvering, and why Orrinsford?" | CO | [grounded] | Answer slot: say what actually draws you. If it's true for you, you can point to things the district has published: its three beliefs, and the literacy plan the board adopted in August 2026, including the new grades 3–5 reading curriculum from fall 2027 (see Sources). Mention only what genuinely matters to you, and don't recite the plan | Most candidates won't have read the district's own plan, so this is a differentiator. CO because it scores your homework on the district |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's the first week of school. How do you set up routines in your fourth-grade classroom?" | CASE | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Structure your answer: clarify (class size, schedule), the few routines you'd teach first, how you'd teach and practice them, how you'd know they stuck, and what you'd change by week three. Answer slot: if there's a routine from your third-grade classroom you'd bring, name it and say why, in your own words. If none comes to mind, describe the plan | The district's hiring page names classroom routines as a panel topic (F7). CASE because it's a live problem to reason through |
| B2 | "In October you have a fourth grader reading about two years below grade level. What do you do?" | CASE | [grounded] | Walk through: what you'd check first, what you'd do in class this week, who you'd bring in (family, interventionist, team), and how you'd track progress and when you'd adjust. The question needs no claim about your past, so the guidance makes none | The district's "Every Child a Reader" belief and the principal's reading background both point here. It is likely her question, with follow-ups |
| B3 | "The district is moving grades 3–5 to a new reading curriculum in fall 2027. How would you help the team through it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Lead with the sentence: you led your grade level's move to a new reading curriculum in 2024. Answer slot: if particular parts of that move were yours to decide or run, say which and what you'd do the same or differently, in your own words. If they weren't yours, say so plainly and stay with what you saw. Don't claim you chose or designed the curriculum | Your strongest single link to this district's current plans. CO because it ties F4 and F10 to the published literacy plan |
| B4 | "A parent emails you upset that their child's grade dropped. How do you handle it?" | CASE | [grounded] | Structure your answer: respond quickly and calmly, offer a conversation rather than a reply-all, bring the evidence (work samples, what the grade reflects), agree on next steps, then follow up. Close on partnership | The district's hiring page names working with families as a panel topic, and "Families Are Partners" is a published belief. CASE because it is live problem-solving |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What would you bring to our team, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I've never taught fourth grade" | Bring: the curriculum move and the reading club, said as your CV says them. Need: be specific and honest, for example "I haven't taught fourth grade, so your unit plans and pacing would help me most early on." Then offer something back that you can actually do | The reciprocity question from the two teammates. It also answers F2 collegially. JD because it scores "work with the grade-level team" |
| C2 | "Tell us about a time you disagreed with a colleague about instruction." | VAL | [generic] | Pick a time that has a real disagreement, what you did, and a working relationship still intact afterwards. If no such time comes to mind, say so plainly, then describe how you would handle one | Peers want to know how you disagree with equals. Your material has no story for this, so the guidance helps you choose one rather than supplying it |
| C3 | "You led your grade level's move to a new reading curriculum. What was that like for the team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the move and the year. Answer slot: the posting's team-work line makes a question about colleagues likely. If colleagues had concerns and you worked through them, say what happened and which part was yours, in your own words. If there were no such concerns, or that wasn't your part, say so plainly and stay with the move | F10's adjacent evidence, asked from the side of the people who'd work with you. EXP because it tests attribution |
| C4 | "If our team splits up unit planning, how would you want to divide it, and what if someone's part isn't ready?" | CASE | [generic] | Propose principles rather than guessing how their team works: clear owners, a shared template, a check-in date, and a direct, kind conversation when something slips. Ask how they do it now | Persona stem on handoffs and credit. CASE because it's a hypothetical about the team you'd join |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about the reading club. Who comes, and has anything changed for them?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | The club, after school, two years, run by you. Answer slot: give real numbers only if you know them. If you saw changes in particular students, describe them. If you don't track it, or it's hard to say, say so plainly. Don't claim results you didn't see | F4's club is the likeliest item a prober will dig into. EXP because it tests what you can back up |
| D2 | "How do you use assessment data to group students for reading?" | JD | [inferred] | Answer slot: the posting's "differentiate instruction using assessment data" line raises this. If you've done it, say which assessments you used, how you grouped students and how often you regrouped, in your own words. If you haven't, say so plainly and describe what you'd look at first. If it fits your answer, you can mention the district belief that assessments inform teaching and never replace it | F6 is silent in your material, and the principal's reading-specialist background makes this follow-up likely. JD because it scores a stated responsibility |
| D3 | "After the 2024 curriculum move, how did you know whether it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if your grade level looked at results, say what was looked at and what you saw, in your own words, and name the part of any figure you'd defend least. If nobody measured it, or it was too early to tell, say so plainly. That's a credible answer | F4 and F10's strongest sentence, probed for evidence. EXP because it tests whether a claim holds up |

### E. Values / Behavioral (themed on the district's published beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our district believes in 'Every Child a Reader.' Tell us about a student you helped become a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Pick one real student, with where they started, what you did, and what changed. The reading club you've run for the last two years is one place to look. If no such student comes to mind, say so plainly, then describe how you'd approach it (B2) | A published belief used as an interview theme. Your material names the club but no student story, so the guidance helps you choose one |
| E2 | "Here, each teacher speaks with every family each term. How do you build partnership with families?" | VAL | [grounded] "I write a weekly email to families." | Start with the sentence: you write a weekly email to families. Answer slot: if you've also spoken with every family, say how, in your own words. If your contact was mainly the email, say so plainly and describe how you'd reach every family each term. Don't present the email as conversations | F9 is the gap between the published belief and your evidence, and it's an easy one to overstate. VAL because it scores a named belief |
| E3 | "Tell us about a time testing pressure pulled against what your students needed." | VAL | [grounded] | Pick a time that has a real tension, what you actually did, and what happened for the students. If no such time comes to mind, say so plainly, then describe how you'd handle it | The third belief, "Teach for Tomorrow, Not for the Test." VAL because it scores a specific published belief, not general good intentions |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1Q | "Tell us a bit about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second introduction in this order: six years teaching third grade in Joliet, the 2024 curriculum move you led, two years running the reading club, the weekly family email, then why fourth grade at Halvering (A5's slot). Use your own words and add nothing | Almost certainly the opener. It's still scored, and these four sentences are your strongest material |
| F2Q | "Is your license current, and does it cover fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Describe it the way your CV does: Professional Educator License, Elementary Education grades 1–6 endorsement, active through June 30, 2029. Grade 4 is inside that range. No need to recite the number | The invite's one stated requirement (F1). It probably won't come up, but it should take ten seconds if it does |
| F3Q | "What's a book you'd love to teach to fourth graders?" | JD | [generic] | Pick a real book, say why in terms of what students would get from it, and add how you'd use it | Casual questions about reading are still scored on a reading-focused panel |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who's already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | Pause, then concede and hold. Concede: "I haven't taught fourth grade." Hold: six years teaching third grade, and you led your grade level's move to a new reading curriculum in 2024. Don't criticize the other candidate. If pushed twice, hold on what you've actually done and concede only the new content | A time-boxed version of A1, drawing on F2, F3 and F4. Practicing it means you won't freeze if it comes sharp |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which parts were yours, in your own words. If the curriculum choice or other parts were decided by others, say so plainly. Being precise here builds credibility | F10's main sentence under attribution pressure. EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Illinois PEL with elementary endorsement (F1) | F2Q |
| Fourth Grade Teacher (F2) | A1, A3, G1, C1 |
| Grades 3 to 5 experience (F3) | A1, F1Q |
| Plan and teach reading (F4) | B2, B3, D1, D3, E1, F3Q |
| Writing, math, science, social studies (F5) | A1 (slot) |
| Differentiate using assessment data (F6) | D2, B2 |
| Classroom routines (F7) | B1 |
| Communicate with families (F8, F9) | E2, B4 |
| Work with the grade-level team (F10) | A2, C1, C2, C3, C4, G2 |
| Teach for Tomorrow, Not for the Test (belief) | E3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To the principal) "I saw your 2025 forum talk on weekly reading conferences in grades 3 to 5. How does that show up in fourth-grade classrooms here?" | It's about her own work and her area of expertise, and it shows you researched her, not just the school |
| R2 | "With the new grades 3–5 reading curriculum coming in fall 2027, how is the fourth-grade team getting ready?" | It shows you've read the district's literacy plan, and it connects naturally to B3 |
| R3 | (To the teachers) "What could a new teammate do in the first month that would genuinely help your team?" | The reciprocity question. It puts their workload at the center, which is what peers are judging |
| R4 | "How does the team plan: together, split by subject, or individually?" | You learn how the team works and show you're already picturing working with them |
| R5 | "How do teachers here meet the expectation of speaking with every family each term?" | It takes the published belief seriously and asks how it works in practice |
| R6 | "What support is there for a teacher new to fourth grade in their first year?" | It turns F2 into a forward-looking question, without apology |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | "I haven't taught fourth grade." Then a plan, framed as a plan |
| Has been a grade-level team lead | A negative you stated, F10 | "I haven't been a team lead." Alongside: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the grade-level team | Inflated form of F10's curriculum sentence | The sentence at its own scope: you led the move. The pack's observation, not words for you: your material says the move, not the team. G2's slot stays inside the move |
| Chose or designed the new reading curriculum | Inflated form of F4's curriculum sentence | The sentence at its own scope. B3's slot asks only which parts of the move were yours |
| Founded or created the reading club | Inflated form of F4's club sentence | "I've run the after-school reading club for the last two years." |
| Already speaks with every family each term | Inflated form of F9's email sentence | "I write a weekly email to families." E2's slot asks how else you've reached families |

---

## Sources

**Provided:** your HR invite and your CV text, both pasted in the conversation. Your Social Security number and license number were not used anywhere.

**Searches and fetches:**

- Search `Orrinsford Community School District values mission` → https://orrinsfordschools.example/about/mission-and-beliefs, fetched: the three beliefs and their definitions
- Search `Orrinsford Community School District teacher interview process` → https://orrinsfordschools.example/careers/how-we-hire-teachers: one 45-minute building panel (principal and two grade-level teachers) asking about reading instruction, classroom routines and work with families, with references taken up afterwards
- Search `Halvering Elementary School Orrinsford strategic plan news` → https://orrinsfordschools.example/news/board-adopts-literacy-plan: the 2026–2029 literacy plan adopted August 2026, which includes a new grades 3–5 reading curriculum from fall 2027 and a family reading night at every school each term
- Search `Dolores Vantongeren principal Halvering Elementary` → https://ilprincipalsforum.example/speakers/dolores-vantongeren: principal since 2022, nine years as a reading specialist before that, and a 2025 talk, *Small Groups, Big Readers*
- Search `fourth grade teacher job description Illinois elementary school district` → https://k12jobsboard.example/listings/fourth-grade-teacher, fetched: representative responsibilities and qualifications

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three beliefs by name, used as themes for E1 to E3, F9 and R5. No values cheat sheet, because no source names a dedicated values round |
| 2. `Orrinsford Community School District interview process` | yes | Confirms a single panel session. It set the persona weights and the B-bank topics |
| 3. District strategy and recent news | yes | The 2026–2029 literacy plan, behind A5, B3 and R2 |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | The interviewer read, R1 and the Prober weight |
| 5. Representative `Fourth Grade Teacher` JD | yes | Requirements F3 to F8 and F10, labeled `[inferred]` because no posting was supplied |

---

## Upgrade menu

- The actual Halvering posting → the `[inferred]` rows F3 to F8 and F10 become `[grounded]`, and coverage is checked against the school's own list
- Any HR note on format, such as a sample lesson or writing task → a dedicated build section for that deliverable
- Your answers to the slots in F4 to F7, F9 and F10 (which subjects you taught, how you've used assessment data, your routines, how you reach families, what leading the curriculum move involved) → those rows get your own sentences, and A1, B1, C3, D2, E2 and G2 become built around your real stories
- Names of the two fourth-grade teachers → a per-member read and a reverse question for each
- A printout of your license record → F1 moves from medium to high
- How much prep time you have → a prioritized prep schedule
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → the principal's talk read in full and more district context for B3 and R2
- A `tuesday-dossier.md` → an evidence-graded main objection and a prohibited-claims list built from verified evidence, instead of this pack's local version
