# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday, 2pm. A 30-minute phone call with Hannah Lowther, Talent Partner (recruiter). She will ring your mobile.
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", and then she'll tell you "about the team and the next steps."

## How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour against the company's published values
  - **EXP**: what you actually did, and whether your claims hold up
  - **JD**: the advert's duties, requirements and terms
  - **CO**: homework on the company
  - **CASE**: a live "what would you do" problem
- Treat the guidance as scaffolding, not a script. Say it in your own words.
- **Answer slots** tell you how to answer in the interview. They are not questions for you to answer here. Each one gives two honest branches, and both are fine answers.
- Provenance labels: `[grounded]` means it comes from your message or the advert. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a common pattern for this kind of role, with no claim about Quillmoor.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material describes delivery scheduling for three depots. It doesn't describe production scheduling between planning, a warehouse and QA, so your words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a question about who you coordinate with likely. If your scheduling involves working with other teams, say which teams and how, in your own words. If it doesn't, say so plainly and stay with the depots you schedule for |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. Nothing backs it up beyond your word, so expect a follow-up. Lead with the sentence in its own terms: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap. Keep the sentence's own shape: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Keep "about" and "over a year" in. The figure is likely to be probed (C1, E1) |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material doesn't mention any reporting. Answer slot: if you report on deliveries or dispatch now, say what you report and how often, in your own words. If you don't, say so plainly, then say what you'd want to understand first about how on-time dispatch is measured there |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap: four years against the two asked for. Say it as written |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says "spreadsheet" but not which program. Answer slot: if the spreadsheet is in Excel, say so and describe the rebuild in your own words. If it's in another program, name that program plainly |
| F7 | "ERP experience (SAP or similar) a plus" — advert, the SAP part | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You've already stated this gap, and the advert lists it as a plus, not a requirement. Words: "I've never used SAP — we run our own in-house stock system." Any plan to learn it is said as a plan, never as something you've done, and nothing is added to make the gap sound smaller |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" part | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Whether your in-house system counts as "similar" is for the interviewer to judge. Describe it, and don't call it an ERP. Answer slot: say what you use the in-house stock system for, in your own words |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is inside the advertised band. Words: "I'm hoping for £42,000." Add nothing |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advertised pattern is within your limit. Use your sentence whole, including the "more than three" part |

## Persona table

The loop for this session comes from Hannah's own message: one 30-minute phone call with her, with the agenda she listed. Nothing in hand says what comes after it.

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport | A friendly phone chat working through Hannah's agenda | high | Recruiter screens usually lead with this style, and her message lists the logistics topics outright | Treat every friendly question as scored. Have your logistics words ready and a 90-second answer for "walk me through your role" (A5) |
| Skeptic | Light probing of the gaps between your background and the advert | medium | Recruiter screens usually include a light Skeptic. F1 and F7 are where the advert and your material differ most | Rehearse B1 until it's boring. Build bridges only from your own sentences, and say the limits plainly |
| Data-Driven Prober | A follow-up or two on your one number | low | F3 holds the only figure in your material | Know what you can and can't say about how "about a third" was counted, and say plainly if you don't know |
| Case / Strategist | A quick "what would you do if…" | low | Rare in a 30-minute recruiter call. The advert's duties make one plausible | Clarify first, then who is affected, then options, then what you'd record |
| Pressure | A sharper version of the Skeptic questions | low | A recruiter screen is usually friendly. It's included so the style isn't new to you if it appears | Pause, restate the question, hold what your sentence says, and concede precisely |
| Values / Behavioural | Not weighted | none | Hannah's agenda names no values topic, and Quillmoor's published values weren't available (the search was refused). A6 covers one behavioural prompt | — |
| Peer Evaluator | Not weighted | none | A recruiter isn't a peer on the team | — |

## Question banks

### A. Conversational (Hannah's agenda first)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Use your own words: "I'm hoping for £42,000." Say it and stop. If she comes back to it, give the same words again. If she asks what you earn now: "I'd rather focus on the range for this role." | First on her list. F9 is inside the advertised band. Tagged JD because pay is a term of the listed job |
| A2 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, as your contract states it. Check the contract before the call so the period you give is exact | Second on her list. Tagged JD because it bears on the job's start date |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the journey or on more days, give the same words again and add nothing | Third on her list. F10 is the advertised pattern. Tagged JD because the office pattern is the listed job's term |
| A4 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your words, whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, about Reading or anything else, give the same words again and add nothing | Fourth on her list. Tagged EXP because it's about your own situation, not the advert |
| A5 | "So, walk me through your current role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second answer with only the beats these sentences state, in this order: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, and discrepancies falling by about a third over a year. Use your own words, and keep "for" the depots, not "running" them | Almost every screen opens with this. It covers F5, F2 and F3 in one go. Tagged EXP because it tests what you actually do |
| A6 | "Tell me about a time a supplier order slipped. What did you do?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick one real occasion an order slipped. The story needs the order, what you did when you chased it, and how it ended, told in your own words. If no single occasion comes to mind, say so plainly, then describe how you chase suppliers when orders slip | The theme comes from the advert's "chase late orders" (F2). An open prompt, so you choose the instance. Tagged EXP because it tests a real past event |
| A7 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet is in Excel, say so and describe the rebuild in your own words. If it's in another program, name it plainly. Describe what you did and let her judge the level, rather than calling yourself "advanced" | F6 is a quick check recruiters often make, and the advert names Excel outright. Tagged JD because it's a stated requirement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your experience is delivery scheduling. Have you coordinated production schedules across planning, a warehouse and QA?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **This is the most valuable rehearsal in the pack.** Hold only what the sentence carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of your scheduling involves working with other teams, say which teams and how, in your own words. If it doesn't, say so plainly (it's a limit, not a confession) and come back to the depots. Follow-up 1, "So no production scheduling?": the same hold, plus the slot's honest branch. Follow-up 2, "How would you get up to speed?": answer as a plan, not as experience, e.g. what you'd want to learn first about how planning, the warehouse and QA hand work over | F1 is where the advert's headline duty and your material differ most, so some form of this question is very likely. Tagged JD because it scores the first listed duty |
| B2 | "The advert mentions SAP or similar. What ERP systems have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Start with your own words: "I've never used SAP — we run our own in-house stock system." Answer slot: say what you use the in-house system for, in your own words. Don't call it an ERP; let her judge whether it counts as similar | F7 and F8. Recruiters often check listed systems. Tagged JD because it's named in the advert, as a plus |
| B3 | "Why Quillmoor, and why this role?" | CO | [generic] | Selection scaffold: name one or two lines from the advert that match your work and say why they appeal, in your own words. If what draws you is the fit with your work rather than the company itself, say so plainly. Don't add to your reason for leaving; if it comes up, use A4's words again. Research couldn't run, so look at Quillmoor's own website before Thursday for anything that genuinely interests you | A common "why here" check on motivation. Tagged CO because a good answer shows homework, and it is `[generic]` because no Quillmoor material was in hand |
| B4 | "Which part of this role would you find hardest at first?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name a real gap, not a disguised strength. The one your material states is SAP: "I've never used SAP — we run our own in-house stock system." Then describe how you'd get to grips with their system as a plan, never as something already done. F1's limit is the other honest option, worded as in B1 | A Skeptic stem that recruiters use as a self-awareness check. Tagged JD because the answer should be measured against the advert |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slots, each in your own words: how the fall was counted; what it depends on; the assumption behind it you'd defend least, said before she raises it; and which part was yours. "I don't know exactly how it was counted" is an honest answer. Keep "about" and "over a year" | F3 holds the only number in your material, and numbers attract follow-ups. Tagged EXP because it tests the claim itself |
| C2 | "What reporting do you do now on deliveries or dispatch?" | JD | [grounded] | Answer slot: if you report on deliveries or dispatch, say what you report, to whom and how often, in your own words. If you don't, say so plainly, then say what you'd want to understand first about how on-time dispatch is measured there | F4: the advert's weekly reporting duty, which your material doesn't mention. Tagged JD because it's a listed duty |
| C3 | "How do you keep stock records accurate day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from your sentence. Answer slot: if you have a routine for checking stock, describe it in your own words. If the spreadsheet rebuild is the main thing, say so and stay with it | F3 against the advert's "keep stock records accurate". Tagged JD because it's a listed duty |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery that production depends on will be three days late. What do you do?" | CASE | [generic] | Structure: what you'd ask the supplier first; who you'd tell, using the advert's planning, warehouse and QA; what options you'd look at; what you'd record. The question asks nothing about your past, so the guidance claims nothing about it | A live problem built from the advert's "chase late orders" and scheduling duties (F1, F2). `[generic]` because it's a pattern, not a fact about Quillmoor |
| D2 | "On-time dispatch dropped this week. How would you work out why?" | CASE | [generic] | Structure: first check how on-time is measured; then split the late orders by cause (late supply, production, warehouse, or a QA hold); then pick the biggest cause and decide what you'd report and to whom | Built from the advert's weekly dispatch reporting (F4). Tagged CASE because it tests reasoning live |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That third. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause, then hold what your sentence says: you rebuilt the spreadsheet, and over a year discrepancies fell by about a third. Answer slot: which part of the fall was yours. If you know, say how in your own words; if other things changed too, or you don't know, say so plainly. Concede precisely, but don't back away from the rebuild itself | The persona stem applied to F3. Tagged EXP because it tests attribution honesty |
| E2 | "No SAP. Why should we pick you over someone who has it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause, then acknowledge it: "I've never used SAP — we run our own in-house stock system." Then hold what you do have, in those sentences' terms: four years as a logistics coordinator, and scheduling deliveries and chasing suppliers for three depots. Keep to how you'd learn the system, said as a plan. Don't claim you'd pick it up faster than anyone else. Hold through two follow-ups, and concede only the SAP gap | F7 framed as pressure. Tagged JD because it presses on a listed plus |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA (F1) | B1, D1 |
| Track supplier deliveries and chase late orders (F2) | A5, A6, D1 |
| Keep stock records accurate (F3) | A5, C1, C3, E1 |
| Report weekly on on-time dispatch (F4) | C2, D2 |
| 2+ years in operations or logistics coordination (F5) | A5, E2 |
| Confident with Excel (F6) | A7 |
| ERP experience, SAP or similar, a plus (F7, F8) | B2, B4, E2 |
| £38,000–£44,000 (F9) | A1 |
| Hybrid, two days at Avonmouth (F10) | A3 |
| Notice period and reason for move (Hannah's agenda) | A2, A4 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What happens after today, and who would I meet at the next stage?" | She said she'll cover next steps. Asking who you'd meet lets you prepare for that round specifically |
| "How is the role's time split between planning, the warehouse and QA day to day?" | It goes straight at F1, the area you most need to understand, and shows you've read the first duty closely |
| "Which system does the team use for stock and scheduling, and how do new starters usually get up to speed on it?" | It raises F7 on your terms, as a ramp-up question, without assuming which system they use |
| "How is on-time dispatch measured for the weekly report?" | It shows interest in a listed duty (F4) and tells you what C2 and D2 would really involve |
| "Which days do people on the team usually spend at Avonmouth?" | Practical. It tells you how the two-day pattern works in practice |
| "What would a good first three months look like in this role?" | It tells you what they will judge a new starter on, so you can prepare the next round around it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules with planning, a warehouse and QA | Inflated form of F1 | F1's sentence at its own scope. Your material describes depot deliveries, not production. B1's slot stays inside the scheduling you do |
| Managed or ran the three depots | Inflated form of F1 | "I schedule deliveries for our three depots": scheduling for them, not running them |
| Discrepancies fell by exactly 33%, or by more than about a third | Inflated form of F3 | The sentence as you said it, with "about a third" and "over a year" |
| Advanced or expert Excel user | Inflated form of F6 | F6's sentence at its own scope. Your material says "spreadsheet", not which program or what level. A7's slot asks only which program |
| Calling the in-house stock system an ERP | Inflated form of F8 | "we run our own in-house stock system". Describe it and let the interviewer judge |
| Has used SAP | Negative you stated, F7 | "I've never used SAP — we run our own in-house stock system." No slot |

## Sources

- **Provided:** the advert text; Hannah Lowther's LinkedIn message; your background in your message.
- **Searches sent, all refused by the host's permission settings:**
  - `Quillmoor Diagnostics values`: refused
  - `Quillmoor Diagnostics Avonmouth news`: refused
  - `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Refused. It would have given B3 and the reverse questions Quillmoor's own published values to draw on. No values round was detected, so no cheat sheet either way |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message already fixes this session: a 30-minute phone call with her and the agenda she listed. The persona weights follow it |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Refused. It would have grounded B3 and given a company-specific CO question. Both are `[generic]` instead |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Refused. It would have given an interviewer read from her public professional profile, plus a reverse question tied to her career path |
| 5. Representative `Operations Coordinator` JD | skipped | You supplied the advert, which fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Allow web search:** Quillmoor's published values, recent news and Hannah's public professional profile. This grounds B3, adds a company-specific CO question and an interviewer read, and gives a reverse question tied to her career path. A deeper pass is also available: up to 6 more searches and 2 more fetches, which takes several more minutes.
- **Your notice period:** A2 is filled in your own words.
- **Your answers to the slots in F4, F6 and F8** (reporting, which program your spreadsheet is in, what the in-house system does): C2, A7 and B2 become story-mapped instead of slots.
- **Your CV:** more of your own sentences in the evidence column, possibly closing F4 and F6.
- **The rebuilt stock-count spreadsheet itself, or its discrepancy log:** F3's confidence moves from medium to high.
- **How much prep time you have:** a prioritised schedule for it.
- **A `tuesday-dossier.md`:** the main objection would come from checked evidence rather than this pack's inference, and the prohibited-claims list would come from a dossier.
