# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** a 30-minute video call with the office manager (name not given). Built on the assumption that the office manager is the person you would report to.

## How to use this pack

- **Personas** describe *how* a question is asked (who is asking, and in what style). **Types** describe *what* is being scored.
- Type key:
  - **VAL**: behaviour and values. Does your past behaviour show what they care about?
  - **EXP**: your experience. Does what you say about your background hold up when questioned?
  - **JD**: the job itself. Can you do the duties in the ad, including the ones you are thinner on?
  - **CO**: company knowledge. Have you done your homework on them?
  - **CASE**: a live problem. Can you think through a task from the job out loud?
- Provenance labels: `[grounded]` traces to your message or the ad as you described it. `[inferred]` is this pack's own derivation. `[generic]` is a common pattern for admin roles, with no claim about this employer.
- Question IDs are by persona (A, B, C, D, E, G). The letter F is reserved for the fit snapshot rows (F1 to F6).
- An **answer slot** is the pack saying "your own words go here". It gives you two honest branches and never fills either one in for you.
- The guidance gives you a structure to work from, not a script. Say it your own way.

## Fit snapshot

The requirements are the duties from the ad, as you described them in your message, plus the "Remote" in the job title from the invite.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as described in your message | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material describes a clinic appointment book, not other people's work calendars, and the words stay at that scope: "I ran the appointment book for four physios." Answer slot: the ad's calendar duty makes a question about tools and changes likely. If the book was kept in a software system, name it and say how you handled changes, in your own words. If it was on paper, or you don't know the system's name, say so plainly and describe how you ran the book |
| F2 | "booking travel" — the ad, as described in your message | none given | none | [grounded] | discovery | Your material says nothing either way about travel booking. Answer slot: if you have booked travel for anyone, at work or otherwise, say what and how, in your own words. If you haven't, say so plainly and describe how you would go about it, as a plan |
| F3 | "preparing documents in Word" — the ad, as described in your message | "I'm good with Word" — your message | low | [grounded] | discovery | A self-rating with nothing shown behind it, so expect a "what have you made in it" probe. Words: "I'm good with Word." Answer slot: if you made documents in Word in the clinic job, name the kinds. If you didn't, say so plainly and say where you do use it |
| F4 | "preparing documents in … Excel" — the ad, as described in your message | "okay with Excel" — your message | low | [grounded] | discovery | Your own rating, kept at its own level, with nothing added to make it sound stronger: "I'm okay with Excel." Answer slot: name the things you have actually done in Excel, in your own words. If they are basic, say so, and give your plan to build on them as a plan, never as something you already did |
| F5 | "processing supplier invoices" — the ad, as described in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material describes chasing invoices that were unpaid, not handling bills that suppliers sent in. Those are different sides of the same paper, so don't merge them. Words: "I chased unpaid invoices." Answer slot: if you ever handled bills that the clinic received, say what you did with them. If you didn't, say so plainly and stay with the chasing |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work from home the way this role needs. That is a term of the job, not a skill, so no wording covers it |

## Persona weights

The invite's own words, "a 30-minute video call with our office manager", describe one session run by one person. Treating that person as your likely future manager is this pack's assumption (`[inferred]`). On that basis the starting weights are the hiring-manager ones (Case and Skeptic), and the short format adds a friendly opener.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | "What would you do if…" tasks taken from the ad's duties | High. A manager buying admin capability tests the actual tasks: calendars, travel, documents, invoices | Clarify first, then give your steps in order, out loud. Saying "I'd check with you first" is a strength here, not a weakness |
| B. Skeptic | Quiet probing of the gap between reception work and office admin | High. F4 and F5 are the visible gaps, and the most predictable objection sits there (B1) | Rehearse B1 until it bores you. Use only the bridges your quotes carry, say the limit plainly, and add a learning plan |
| C. Conversational | "Tell me about yourself", chat about your day-to-day | Medium. 30 minutes usually opens warm, and warm questions still count | A practised 90-second arc built from your three quoted facts |
| D. Data-Driven Prober | "How did the appointment book actually work?" | Low to medium. Your two concrete claims, F1 and F5, invite a follow-up "how" | Know what you did and didn't do. Say "I don't know" where that's true |
| E. Pressure | A time-boxed "why you", or a push on "okay with Excel" | Low. Not typical for admin hiring, but one sharp question is possible | Pause, hold what you said, then concede specifically |
| G. Values / Behavioural | "Tell me about a time…" | Low to medium. A short call often includes one story question | One story for juggling bookings and one for chasing, taken only from your quotes |
| Peer Evaluator | Not included | Not plausible in a one-person call with the office manager | — |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people want the same hour tomorrow morning, and both say it's urgent. What do you do?" | CASE | [generic] | Work through it out loud: check what each meeting is for, and whether someone senior sets the priorities. Offer each person the nearest alternative slot. Don't decide on someone else's behalf if it isn't your call; flag it to whoever is. Confirm in writing and update both calendars. The question needs no claim about your past, so the guidance makes none | The ad's calendar duty (F1's requirement) tested as a decision. CASE because it scores how you reason, not your history |
| A2 | "A manager needs a two-day trip to a meeting in another city next week. Walk me through booking it." | CASE | [generic] | Ask first: dates, times, budget or travel policy, preferences. Then find options, get approval, book, put the confirmations and travel times into their calendar, and send one summary with every reference number. Mention checking the cancellation terms | F2 has no evidence behind it, so a live walkthrough is the honest place to show you can do this. CASE because it is a process from the ad |
| A3 | "A supplier's invoice arrives, and the amount doesn't match what was ordered. What do you do?" | CASE | [generic] | Don't pay it or pass it on as it stands. Check it against the order or delivery record, note the difference, contact the supplier to query it, tell whoever approves payments, and keep a record of the query until it's resolved | The ad's invoice duty (F5's requirement) asked as a decision, where F5's evidence doesn't reach. CASE because it is a live problem |
| A4 | "Turn a page of rough notes into a tidy Word document for a client by end of day. How do you approach it?" | CASE | [generic] | Clarify who it's for and whether there's a house template. Set up headings and styles, keep the layout consistent, proofread, send it as PDF if it's going outside the company, and check it before the deadline rather than at it | The ad's Word duty (F3's requirement) as a task. It lets you show method without claiming anything |
| A5 | "Set up a simple spreadsheet of this month's supplier invoices with a running total. How would you do it?" | CASE | [generic] | Columns: supplier, invoice number, date, amount, due date, status. A SUM for the total, and a filter to see what's unpaid. If there's a step you would need to look up, say so; that is better than bluffing a formula. The question needs no claim about your past | Joins F4 and F5's requirements in one practical test. CASE because it is a live task, and the likeliest way Excel gets tested in a 30-minute call |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is reception at a physio clinic. How much of the office side of this job, like supplier invoices and spreadsheets, have you actually done?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" "chased unpaid invoices" "okay with Excel" | **The highest-return rehearsal in this pack.** Hold only what the quotes carry: "I spent two years as a receptionist at a physiotherapy clinic. I chased unpaid invoices, and I'm okay with Excel." Answer slot: if you ever handled bills the clinic received, say what you did, in your own words. If not, say so plainly and stay with the chasing. Then give your plan for the gap as a plan (for example, the Excel basics you would practise first). Follow-up 1 ("so, no supplier invoices?"): give the honest branch again, calmly, with no extra claims. Follow-up 2 ("why should that not worry us?"): return to the quotes and the plan, and never add to them | F5 and F4 are where the ad presses hardest on your background, so this objection arrives in some form. JD because it scores the stated duties |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Answer honestly, using your own rating: "I'm okay with Excel." Don't trade it for a softer fake weakness. Then the plan, said as a plan. Stop there; don't over-apologise | F4 is your own stated limit. A planned, candid answer scores better than a dodge. JD because it maps to a listed duty |
| B3 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if you have, say what and for whom, in your own words. If you haven't, say so plainly, then give A2's steps as how you would do it | F2 has no evidence behind it, and the ad lists travel. JD because it is a stated duty |
| B4 | "You've been on a clinic reception desk. Why a remote role now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot: give your real reasons in your own words, kept positive and about what you want next. If part of the reason is practical, it's fine to say so briefly. Don't invent an enthusiasm you don't have | Moving from a front desk to remote work is the obvious motivation probe. EXP because it tests your story's consistency. The remote term itself (F6) is not bridged here |
| B5 | "Why this job?" | JD | [generic] | Selection scaffold: link one or two of the ad's duties to what you have actually done (F1, F5) and say you want more of that work. If nothing specific draws you to this employer, don't pretend to know more about them than you do; talk about the work | No company research came back (see Sources), so the answer stays with the role. JD because it rests on the ad's duties |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc with three beats, each one a quote: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, chasing unpaid invoices. Close with why admin work is the next step, in your own words | Nearly certain to open the call. C1 rests on F1 and F5 and sets up everything after it |
| C2 | "What was a normal day like in your receptionist job?" | EXP | [grounded] "ran the appointment book for four physios" "chased unpaid invoices" | Beats: the appointment book and the invoice chasing, both in your own words. Answer slot: if other tasks filled your day, name the ones you actually did. Don't add tasks the role "usually" involves | A chatty question that is really scoring how you describe your work. It draws on F1 and F5 |
| C3 | "Any questions for me?" | JD | [generic] | Pick two or three from the Reverse questions section. Never say "I think you've covered everything" | Friendly interviewers weigh this moment heavily as a sign of preparation |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. How did that work in practice?" | EXP | [grounded] "ran the appointment book for four physios" | Keep the number attached to what it counts: four physios. Answer slot: name the system if there was one and you know it; if there wasn't, or you don't know, say so. Say how you handled changes and cancellations, in your own words. If someone else set the rules, say so and describe your part | F1 is your strongest link to the calendar duty, so it is the likeliest thing to be probed. EXP because it tests what was yours |
| D2 | "How did you chase unpaid invoices? Walk me through it." | EXP | [grounded] "chased unpaid invoices" | Answer slot: your actual steps (calls, emails, reminders, records), in your own words. If the process was set by someone else, say so. Give no amounts or success rates unless you know them | F5 is the evidence closest to the invoice duty. A prober will ask what "chased" meant |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty seconds: why should we pick you for this role?" | JD | [grounded] "ran the appointment book for four physios" "chased unpaid invoices" | Pause, then two quoted facts and one sentence of motivation: you ran the appointment book for four physios, and you chased unpaid invoices. Stop at 30 seconds; a clean stop is part of the answer | Short calls often include a squeeze question. Rests on F1 and F5 |
| E2 | "'Okay' with Excel isn't really good enough for invoice work, is it?" | JD | [grounded] "okay with Excel" | Hold, then concede. Hold: "I'm okay with Excel," and don't upgrade it under pressure. Concede specifically: say what you would need to learn, and your plan for learning it. Don't fold into "I'm not right for this" | F4 under pressure. The test is composure plus honesty, and upgrading your rating would fail it |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had a lot of bookings to juggle at once." | VAL | [grounded] "ran the appointment book for four physios" | Story-mapped on F1: the appointment book, for four physios. Answer slot: pick a real occasion when the book was under strain, and say what happened and what you did, in your own words. If no particular time comes to mind, say so plainly, then describe how you kept the book running | Theme taken from the ad's calendar duty. VAL with EXP delivery, in STAR shape (situation, task, action, result) |
| G2 | "Tell me about a time you had to chase someone for something they owed." | VAL | [grounded] "chased unpaid invoices" | Story-mapped on F5: chasing unpaid invoices. Answer slot: pick one real case and say what you did and how it ended. Give no amount unless you know it. If no single case stands out, say so plainly and describe how you usually went about it | Theme taken from the ad's invoice duty. It tests tact and persistence |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Managing calendars (F1) | A1, C1, D1, G1 |
| Booking travel (F2) | A2, B3 |
| Word documents (F3) | A4 |
| Excel (F4) | A5, B1, B2, E2 |
| Supplier invoices (F5) | A3, B1, D2, G2 |
| Remote (F6) | none. It is a term you meet or don't, so it gets no rehearsed bridge |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like? Roughly how is the time split between calendars, travel, documents and invoices?" | Tells you which of your stories to lean on in the rest of the call, and shows you're thinking about the actual work |
| R2 | "Which tools does the team use for calendars and for invoices?" | Lets you name a concrete learning plan straight away, which is the strongest answer to B1 and E2 |
| R3 | "How many people would I be supporting?" | Shows you understand calendar work in practical terms, and helps you size the job |
| R4 | "What would a great first three months in this role look like to you?" | Invites the manager to describe success, which you can then reflect back |
| R5 | "How does the team keep in touch day to day when everyone's remote?" | Shows you've thought about how remote work actually runs, which is the substance behind F6 |
| R6 | "What are the next steps in the process after today?" | Lets you plan your preparation for any follow-up stage |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executives' or managers' calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." What the pack observes: your material says a clinic appointment book, not office calendars |
| Processed supplier invoices, or accounts payable experience | Inflated form of F5 (it switches which side of the invoice you were on) | F5's quote at its own scope: "I chased unpaid invoices." D2's slot stays inside the chasing |
| Strong or advanced Excel | Contradicted by your own words, F4 | "I'm okay with Excel." |
| Two years of administrative assistant experience | Inflated form of your job title | "two years as a receptionist at a physiotherapy clinic" |

## Sources

- Provided: your message (the invite text, the ad's duties as you described them, and your background).
- Search "Brennock Facilities Ltd values": refused.
- Search "Brennock Facilities Ltd interview process administrative assistant": refused.

Research tier: L1. Searches 2 of 6 sent, both refused. Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Refused. It would have themed the G questions on published values. Without it, no values section |
| 2. `Brennock Facilities Ltd interview process` | unavailable | Refused. It would have shown any later rounds. The invite's own words fix this session's format |
| 3. Company strategy / recent news | unavailable | Not sent after targets 1 and 2 were refused. It would have supported a CO question. B5 stays role-focused instead |
| 4. Interviewer name | n/a | No name was given, so there was no query to run. There is no interviewer read |
| 5. Representative job description | skipped | The ad's duties, as described in your message, fix the fit snapshot rows |

## Upgrade menu

- The ad's full text → requirements quoted from the ad itself rather than from your summary, plus rows and questions for anything else it lists (hours, tools, experience).
- The office manager's name → a short read of their public professional background, persona weights based on it, and a reverse question tailored to them.
- Allowing web search → targets 1 to 3 run: published values (for G questions), any later rounds, and a CO question. A deeper research pass is also available: up to 6 more searches and 2 more fetches, several more minutes.
- Your answers to the slots in F1 to F5 (the booking system, any travel booked, Word documents, Excel tasks, any bills received) → those rows' bridge language becomes your own words, quoted, and B1, B3, D1 and D2 get story-mapped.
- How much prep time you have → a prioritised schedule sized to it.
- A tuesday-dossier.md → the main objection grounded in verified evidence, and a prohibited-claims list built from checked facts rather than this pack's reading.
