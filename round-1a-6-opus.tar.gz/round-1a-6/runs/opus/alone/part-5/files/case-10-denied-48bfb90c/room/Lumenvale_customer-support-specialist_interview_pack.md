# Interview prep pack: Customer Support Specialist, Lumenvale Software

- **Role:** Customer Support Specialist (remote)
- **Company:** Lumenvale Software
- **Interviewer:** the support team lead (name not given). Treated here as your likely future manager, which the invite does not confirm
- **Format, as the invite describes it:** a text chat. Every answer you give is also a writing sample

## How to use this pack

Two axes run through it. **Personas** describe how a question is asked: the style, the pressure, the register. **Types** describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the values they care about |
| EXP | Whether what you say about your experience holds up when they dig into it |
| JD | Whether you can do the job the ad describes, gaps included |
| CO | How well you know the company and what it's doing now |
| CASE | How you reason through a live problem from the role |

The guidance is scaffolding, not a script. Every line about your past is built only from four sentences you wrote (the fit snapshot below). Where the pack needs something you didn't say, it leaves an **answer slot**: an instruction for the interview with two honest options, never a detail filled in for you.

Because the interview is typed, rehearse by typing. Aim for short paragraphs, three to six sentences an answer, and keep the 90-second spoken version as your length guide.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as quoted in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. You have three years against the ad's two, in your own terms. Nobody has seen evidence behind it yet, so expect a probe on the daily figure (C1). Give the figure exactly as you said it: around 60, calls and emails together. Keep the training at its own scope: four new starters, the refunds process, last year |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as quoted in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's "or similar" is the bridge. Name Freshdesk, and keep Zendesk out of any sentence about your past: "I use Freshdesk every day." Answer slot: because the ad names a tool, expect a probe on how you use yours. Describe what you do in it day to day, in your own words. If they mention a feature you haven't used, say so plainly and go back to what you do use it for |
| F3 | "clear written communication" — the job ad, as quoted in your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering emails is writing, but your material doesn't show whether the writing is clear. That is the interviewer's call, and in a text chat your answers are the evidence. Answer slot: if your emails were ever checked, scored or given feedback, say how, in your own words. If they weren't, say so plainly and let the answers you type make the case |
| F4 | "confidence handling escalations" — the job ad, as quoted in your message | none given | none | [grounded] | discovery | Your material says nothing about escalations either way. Answer slot: the ad names escalations, so expect a direct question. If you have handled escalated or angry customers yourself, pick one and say what you did, in your own words. If escalations went to someone else or didn't come your way, say so plainly and describe how you would handle one |
| F5 | Supporting a software product. This is a role-family expectation, not a line in the ad as you quoted it | "I've never worked for a software company" — your message | none | [grounded] | capability | No wording closes this gap, and you have said so. Words: "I haven't worked for a software company." Then say how you would learn the product, as a plan and never as a past. Add nothing to make the gap feel smaller |

## Persona table

The invite describes one session: a text chat with the support team lead. A team lead interviewing for their own team usually behaves like a hiring manager, so these weights start from that prior. If the lead turns out to be a peer, the weights change (see the closing question in the message).

| Persona | How it shows up in a text chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | "A customer writes in saying…, what do you reply?" Possibly asking you to type the actual reply | High. A support lead is hiring someone to handle their queue, and a text chat makes "show me the reply" easy to ask | Clarify, then structure, then answer. Type the reply itself when asked, not a description of it |
| Skeptic (bank B, 4 questions) | Polite, persistent questions about the energy-to-software move and the Zendesk line | High. F5 is the most visible gap against a software employer, and F2 names a different tool from the ad's | Concede the gap in your own words first, then hold on what your quotes carry, then give a ramp plan |
| Data-Driven Prober (bank C, 3 questions) | "How many?", "how do you know?", "what did that involve?" | Medium. F1 contains a figure, and a figure invites a follow-up | Know what you can and can't say about "around 60". Say plainly when you don't know how something was counted |
| Conversational (bank D, 3 questions) | Friendly openers: "tell me about yourself", "why us" | Medium. Most chats open this way, and the casual questions are still scored, especially on writing | Have a short typed arc ready. Treat every casual message as a writing sample |
| Values / Behavioral (bank E, 2 questions) | "Tell me about a time…" | Low to medium. No published values were in hand (research was unavailable), but behavioural prompts are common in support hiring | A selection rule for picking stories, with the honest fallback if no story fits |
| Pressure (bank G, 2 questions) | Short, blunt follow-ups, a time limit, "how much of that was you?" | Low. Hard to stage in text, but a quick "why you over someone with software experience?" is easy to type | Pause, hold your position through two follow-ups, and concede only what's real |
| Peer Evaluator (bank H, 2 questions) | "How would you work with product?", "what would you need from us?" | Low. Possible if the lead also works the queue alongside the team | Frame your answers around what you would bring the team, not only what you'd need |

Question IDs run by persona. The letter F is skipped because it is used for the fit-snapshot rows.

## Question banks

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: they've been charged twice this month and want their money back today. What do you reply?" | CASE | [generic] | Type the reply, not a description of it. Acknowledge the problem in one line, without repeating their anger back to them. Say what you'll check: the account and both charges. Say what you can do today and what needs approval, and give a time when they'll hear back. Keep it plain and short. Then add a line to the interviewer on what you would do behind the scenes, like checking the account and logging the ticket. The question needs no claim about your past, so the guidance makes none | A billing complaint is the likeliest live problem in any support queue. CASE because it is scored on structure and the written result |
| A2 | "A customer says your answer isn't good enough and wants a manager. What do you do?" | JD | [grounded] | Structure: stay calm in tone, restate their problem so they know they've been heard, and check whether there is something you can still do. If it needs escalating, say how you'd hand it over so they don't have to repeat themselves, and tell the customer what happens next and when. If you have a real example, the selection rule is under B3. This question asks for an approach, so give one | The ad's escalation line (F4's requirement), asked as a live decision. JD content with CASE delivery |
| A3 | "You log on to 40 unanswered tickets. How do you decide what to answer first?" | CASE | [generic] | Structure: scan first, then sort by urgency (anyone blocked or losing money), then by age, then quick wins. Mention sending holding replies where a full answer will take time. Say what you'd flag to the lead if the queue keeps growing. Don't describe a triage system from your current job unless you actually use one | Queue prioritisation is core to the role and easy to set in a chat. CASE because it tests reasoning, not history |
| A4 | "A customer reports a bug you can't reproduce. What do you send them, and what do you send our product team?" | CASE | [generic] | Two messages. To the customer: thanks, the specific details you need (steps, device or browser, a screenshot, when it happened), and an honest expectation of next steps. To product: a short, factual summary with the steps tried, what you saw, how many customers have reported it, and how urgent it is. This is the software side of F5, so answer it as an approach. It needs no claim about your past | The most software-specific case they are likely to ask, and a way to show you can think in their world. CASE, aimed at F5's gap |
| A5 | "Write me the reply you'd send now: a customer says a feature stopped working after our update, and you don't know why yet." | JD | [grounded] | The writing test. Open with a plain apology for the disruption. Don't guess at the cause. Say what you're doing and give a time for the next update. If there's a workaround, offer it; if not, say you'll follow up. Keep sentences short with no jargon. Read it back once before sending | The ad's "clear written communication" (F3's requirement). In a text chat this is the natural way to test it. JD content with CASE delivery |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we think you can support a software product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Concede first, in F5's words: "I haven't worked for a software company." Then hold only on what your quotes say: three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, and you use Freshdesk every day. Then give a ramp plan, said as a plan: what you'd do in your first weeks to learn the product, such as using it the way a customer does, reading the help pages and reading past tickets. Follow-up 1, "but software is technical": agree you'd have to learn the product, and repeat how. Follow-up 2, "and if you don't know an answer?": say how you'd find out and keep the customer updated. Don't call energy support "basically the same": that's a claim about the work, and you'd be the one defending it | F5 is the gap this employer sees first, so the objection will come in some form. JD because it scores fit to this role. Rehearsed as concede, hold, then plan |
| B2 | "Our ad mentions Zendesk. How quickly could you get up to speed?" | JD | [grounded] "I use Freshdesk every day" | Lead with the quote: "I use Freshdesk every day." Answer slot: if they ask what you do in it, describe your daily use in your own words. If they name a feature you haven't used, say so plainly and go back to what you do use. Learning Zendesk is a plan, not a past: say how you'd learn it. Don't put a number of days on it unless you have a reason for the number | F2 matches the ad's "or similar" but not its named tool, so a sceptic will check the difference. JD because it scores the tool requirement |
| B3 | "Tell me about a time you handled an escalation." | JD | [grounded] | Selection rule: pick a time a customer was angry or asked for someone senior, where you can say what you did yourself, what happened and how it ended. Answer slot: if you have one, tell it in your own words, with "I" for your part. If escalations went to someone else, or you haven't had one, say so plainly, give the nearest thing you have handled, or walk through how you would handle one (A2) | F4 has no evidence yet and the ad names escalations, so this question is close to certain. JD because it scores a stated requirement |
| B4 | "Why move from energy to software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Start from the quote. Answer slot: give your actual reason for the move, in your own words, and keep it about what you're moving towards. Don't borrow a reason you don't hold, such as an interest in tech you haven't mentioned. If asked again later in the chat, give the same reason in the same words | F1 and F5 together make "why the switch" a standard sceptic question. EXP because it tests whether your story stays consistent |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mention around 60 calls and emails a day. How is that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep the figure whole: around 60, calls and emails together. Don't split it into emails or tickets unless you know the split. Answer slots, in your own words: how you know the figure; what makes it go up or down; the assumption behind it you'd defend least; which part was yours. If it's your own estimate, say so, because "around" already does. "I don't know exactly how it was counted" is an honest answer | It's the only figure in your material, and figures get probed. EXP because it tests whether your own number holds up |
| C2 | "What do you actually do in Freshdesk on a normal day?" | EXP | [grounded] "I use Freshdesk every day" | Answer slot: walk through your real day in the tool, in your own words. Only name the features you use. If they ask about one you don't use, say so plainly and go back to what you do | F2's quote is short, so the prober will ask for detail. EXP because it tests what is actually yours |
| C3 | "You trained four new starters on refunds. What did that involve, and how did you know it had worked?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Keep the quote's scope: four new starters, the refunds process, last year. Answer slot: what the training involved, in your own words, and which part was yours. If you had a way of telling it had worked, say what it was. If there wasn't one, say so plainly and stay with what you taught | The training line in F1 is your clearest example of helping others, so it will be explored. EXP because it tests attribution |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me a bit about your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A typed arc of four to six sentences, built from the three quotes: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day; Freshdesk every day; training four new starters on the refunds process last year. Finish with an answer slot: why this role, in your own words. Write it in advance, then type it fresh in the chat rather than pasting a block | The near-certain opener. In text, the first message sets how they read your writing. EXP because it introduces your evidence |
| D2 | "What drew you to Lumenvale?" | CO | [generic] | Answer slot: say what actually caught your eye in the ad or on their careers page, in your own words. Research for this pack was unavailable, so it gives you no facts about the company. Don't fill the gap with general praise. Read their careers page and product pages before the chat (upgrade menu) | Near-certain, and the one CO question this pack can prepare without research. Without that research it stays generic |
| D3 | "How do you keep your tone right in writing when a customer is upset?" | JD | [grounded] | Answer slot: describe how you actually approach it, in your own words. If you don't have a habit for it, say how you would approach it, for example acknowledging before explaining, short sentences, no blame, and a clear next step. In a text chat, show it in how you type the answer | The ad's written-communication line (F3's requirement), asked casually. JD because it scores a stated requirement |

### E — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Selection rule: pick a time you did right by a customer even though it cost something you were measured on. It needs a named customer problem, a choice you made yourself, and an honest result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioural question in support. Values-style because it tests judgement. `[generic]`, since no published Lumenvale values were in hand |
| E2 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection rule: it needs a real stake, a moment you didn't back down, and a working relationship that survived. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural question for escalation-heavy roles. VAL because it scores behaviour, not skill |

### G — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Quickly: why you over someone who's already done software support?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | A short version of B1, typed fast but calmly. Concede: "I haven't worked for a software company." Hold: the three years, around 60 calls and emails a day, Freshdesk every day. Then one sentence of ramp plan. If they push twice, keep the same position rather than adding to it. Concede only that you'd need to learn the product | F5 again, under time pressure. Hold-then-concede is what's being scored |
| G2 | "Training four people on one process: how much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold on the quote: "I trained four new starters on our refunds process last year." Keep its verb and its scope. Answer slot: say which part was yours, in your own words. If you trained alongside someone, or the material already existed, say so plainly. That's a limit, not a confession | The training line in F1 is the claim most likely to be tested for size. EXP because it tests attribution |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You pass a bug to product and they say it's not a priority, but the customer keeps chasing. What do you do?" | CASE | [generic] | Structure: check that you gave product the full picture (how many customers, how much it costs them), keep the customer honestly updated, and raise it through the right channel if it keeps recurring. Show you can disagree without making it a fight. It needs no claim about your past | A support-and-product handoff problem, and the main way a peer would test you. CASE because it's a live problem |
| H2 | "What would you need from the team in your first month?" | CASE | [generic] | Name what you'd need (product walkthroughs, ticket history, someone to ask) and what you'd give back early (taking routine tickets off the team, flagging confusing help pages). Keep it as a plan | Reciprocity matters if the lead also works the queue. It also shows a ramp plan for F5 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" (F1) | D1, C1, C3, B4, G2 |
| "experience with Zendesk or a similar ticketing tool" (F2) | B2, C2 |
| "clear written communication" (F3) | A5, D3, A1 |
| "confidence handling escalations" (F4) | B3, A2, E2 |
| Supporting a software product, role-family (F5) | B1, G1, A4, H1, H2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What do the most common tickets look like for someone new in this role?" | It shows you're thinking about getting up to speed, which answers F5 before they raise it again |
| "When does a ticket go from support to product or engineering, and how is that handed over?" | Escalation is in the ad, and this shows you understand that escalation is a process, not just a conversation |
| "How do you measure quality in support here?" | It tells you what you'll be judged on, and shows you care about it |
| "What does training on the product look like for new specialists?" | It connects directly to your ramp plan in B1 and gives you something to refer back to |
| "What would a great first three months look like in this role?" | It gives you the lead's own definition of success, which helps if you get to later rounds |
| "What are the next steps after today, and is there a call or video stage?" | It helps you plan your prep for any next round |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has supported a software product or worked in software | A negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk. B2's and C2's slots stay inside Freshdesk |
| Handles around 60 emails, or 60 tickets, a day | Inflated form of F1: the number moved to a nearer noun | F1's figure whole: "around 60 calls and emails a day" |
| Led or ran onboarding for new starters | Inflated form of F1's training quote | The quote at its own scope: "I trained four new starters on our refunds process last year." C3's and G2's slots stay inside that training |

Nothing about escalations is listed, because your material is silent on them. That's an answer slot (F4, B3), not a prohibited claim.

## Sources

**Provided:** your message, including the invite text, the job-ad requirements as you listed them, and your background.

**Searches sent:**
1. "Lumenvale Software values": refused
2. "Lumenvale Software interview process customer support": refused
3. "Lumenvale Software news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Refused. It would have given official value names to theme bank E, and would have made a values cheat sheet possible if a values-style round were known |
| 2. `Lumenvale Software interview process customer support` | unavailable | Refused. It would have checked the loop against a company source. Persona weights rest on the invite's description and the hiring-manager prior |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Refused. It would have grounded D2 and a CO or CASE question in the current product and recent moves. Both stay generic |
| 4. `{interviewer name} Lumenvale Software` | n/a | The support team lead wasn't named, so there was no query to form. The interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The requirements in your message fix fit-snapshot rows F1 to F4 and the JD-tagged questions |

## Upgrade menu

- The full job ad text → each requirement quoted from the ad itself, plus rows and questions for any mid-list requirement your summary left out
- Allowing web search → targets 1 to 3 re-run: value names for bank E, a company check on the loop, and D2 plus one CO or CASE question grounded in Lumenvale's current product
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the company and a strategy-based question bank
- The support team lead's name → a reverse question tied to their own path, and persona weights read from their public profile
- Your answers to the answer slots (an escalation story, how your emails were checked, how "around 60" is counted, what the refunds training involved) → F3 and F4 get evidence, and B3, D3, C1, C3 and G2 become story-mapped
- An inspectable record from your current role, such as a QA or quality score on your tickets or a customer-satisfaction report from Freshdesk → F1 to F3 confidence can rise
- How much prep time you have → a prioritised prep schedule
- A `tuesday-dossier.md` → an evidence-derived highest-ROI objection and a prohibited-claims guardrail carried across sessions
