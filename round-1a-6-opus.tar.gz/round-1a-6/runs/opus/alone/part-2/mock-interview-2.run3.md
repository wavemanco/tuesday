Reading the skill's last reference files, then I'll do a little research on Atlas Freight and write the pack.
I've put together your prep pack: 22 practice questions with answer guidance, a table matching each JD line to your background, and questions for you to ask them. Your note didn't say who you're meeting, so I built it for a round with the hiring manager. I also couldn't look up Atlas Freight because web search permission was declined. So nothing in the pack comes from Atlas's own website, values or news, and anything about the company is marked as a general pattern.

**What to focus on this week:**
- **The scale question (B1).** Practise answering "You're over 3 supervisors today; this role leads 12 across 4 sites." It's the objection most likely to come up in some form. Name the size of the step yourself, stick to what you've actually run, then give a concrete plan for leading 12 supervisors.
- **Power BI.** You've said you haven't used it, so say exactly that and pair it with a specific plan to learn it (B3, D3). A gap you name yourself goes over better than one they find.
- **The 40% mis-pick number.** Be ready to explain how the rate was counted, what was your part, and which assumption behind it is weakest (C1, D2). If you don't know how it was counted, say so. Don't claim it lowered costs or improved on-time performance unless you know it did.
- **"5+ years leadership."** They may check this literally, so know your real number of years leading people (B4). Seven years in ops isn't the same claim.
- **The live-problem questions (A1–A3).** On-time performance and cost-per-shipment are where you have the least direct experience. A clearly structured answer to the problem questions is where you can make up the most ground.
- **Homework.** Read Atlas's website and recent news yourself before the interview, for the "why us?" question (E2).

Files are in `/var/tmp/tuesday-measure/1a6/runs/opus/alone/part-2/rooms/case-2-denied-bffeb2ef/`:
- `atlas-freight_operations-manager_interview_pack.md`

If you want a live run-through, I can play the skeptical hiring manager on B1.
I can also save a `tuesday-dossier.md` that records the gaps this prep found, for later sessions.
If you'd like the pack as a Word document, I can convert it.

Do you know whether you're meeting the hiring manager, a recruiter, or a panel, and has the recruiter mentioned anything to prepare, like a 90-day plan or a case? The answer changes how I'd weight the questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown. Built for a **hiring-manager round**, since your note didn't say who you're meeting. If it turns out to be a recruiter screen, a panel, or a peer, the persona weights change. See the closing question.

---

## How to use this pack

- **Personas** describe *how* a question arrives (who's asking, in what style). **Types** describe *what* is being scored.
- **Type key**
  - **JD**: can you do the listed job, gaps included
  - **EXP**: does what you said about your past survive scrutiny, and what was actually yours
  - **CASE**: a live problem from the role; structure and reasoning count more than the "right" answer
  - **VAL**: behavior and judgment, shown through a real story
  - **CO**: what you know about the company and its situation
- **Provenance labels:** `[grounded]` means it comes from your message or the JD text you gave me. `[inferred]` means it's derived from those, and the derivation is named. `[generic]` means it's a role-family pattern with no claim about you or Atlas.
- **Answer slots** are places where only you know the answer. Each one gives you two honest branches: say what you did, or say plainly that it wasn't part of your work. Never fill a slot with something that didn't happen.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material describes warehouse and distribution ops and a shift-manager role. It doesn't mention terminal operations or more than one site, so keep the words at that scope: "I've spent seven years in warehouse and distribution ops, and I'm currently a senior shift manager over three supervisors." Answer slot: the JD's four-site line makes a probe on multi-site or terminal work likely. If any of your work has covered more than one site, or a terminal or cross-dock operation, say what it was and which part was yours, in your own words. If none has, say so plainly and stay with the operation you run |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | A surge plan touches service under load, but your material doesn't say what the plan measured or whether on-time performance was tracked. Words: "I ran the site's peak-season surge plan two years running." Answer slot: if on-time or ship-on-schedule figures were tracked during those peaks, say what they were and how they were counted. If they weren't tracked, or weren't yours, say so plainly and describe how you ran the plan |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material says nothing about cost. Answer slot: if you've been measured on any cost figure, name it and what you did about it, in your own words. If you haven't, say so plainly and say how you'd start learning this network's cost-per-shipment |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words at their own scope: "I'm a senior shift manager over three supervisors." The step from three to twelve is this pack's observation, not words for you. Answer slot: if you've ever covered for or coordinated supervisors beyond your three, say when and how. If not, say so plainly, describe how you lead your three, and then lay out how you'd structure twelve, as a plan |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | A required years-of-experience line isn't a gate, but it's likely to be checked literally. Your material states seven years in ops. It doesn't say how many of those years you've led people. Answer slot: give the actual number of years you've led people, and in what roles, in your own words. If it's fewer than five, say the real number plainly and lead with what you've run |
| F6 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | medium | [grounded] | discovery | "Solid Excel" doesn't show whether you've built reporting other people used. Answer slot: if you've built a report or tracker that others relied on, say what it tracked and who used it. If you haven't, say so plainly and describe what you do use Excel for |
| F7 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | No wording can close this gap, and you've said so yourself. Words: "I haven't used Power BI." Then say how you'd learn it, as a plan and never as something you've done. Add nothing that makes the gap feel smaller |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | No gap. The certificate hasn't been inspected, though, so expect to be asked for a project. Lead with the credential: "I'm green belt certified." Keep the two quotes separate unless they really are one story. Answer slot: if the pick-path redesign was run as a green belt project, say so and which tools you used. If it wasn't, say so plainly and tell them as two separate facts |

---

## Persona table

No source I could read describes Atlas Freight's interview process (the web searches were refused; see Sources), so these weights rest on a **generic pattern** (screen, then hiring manager, then panel) plus the hiring-manager assumption. They aren't Atlas's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Here's a problem at one of our sites. What do you do?" | **High.** A hiring manager for a role that owns on-time and cost targets is buying how you'd run the job, so expect live problems | Clarify, then objective, segment, approach, metrics, risks. Think out loud. Challenge one premise per case, politely |
| Skeptic | Quiet probing of the gaps: scale (F1, F4), Power BI (F7), leadership years (F5) | **High.** A hiring manager's other job is de-risking the hire, and F1, F4 and F7 are the visible gaps | Rehearse B1 until it's boring. Build bridges only from what you stated, say the limit plainly, then give a concrete ramp plan |
| Data-Driven Prober | "How was the 40% counted?" | **Medium.** Your one headline number is a magnet for this | Know what you can and can't say about how the 40% was counted, and say plainly where you don't know |
| Pressure | Time-boxed "why you?", "how much was actually you?" | **Medium.** Common in ops leadership hiring, where composure under load is part of the job | Pause, restate, anchor in what you actually said, hold through two follow-ups, then concede specifically |
| Conversational | "Walk me through your journey." | **Medium.** Almost every round opens this way, and it's still scored | Have a 90-second arc ready. Treat casual questions about JD topics (Lean, reporting) as scored |
| Values / Behavioral | "Tell me about a time…" people-leadership stories | **Low to medium.** No values round is documented, but leading supervisors invites behavioral probes | Pick real stories using the scaffolds. "We" for context, "I" for your own part |
| Peer Evaluator | Seams with other functions, credit-sharing | **Low.** Only likely if a peer manager sits in | Talk about seam principles, not pretend knowledge of their org |

---

## Question banks

**Highest-ROI prep in this pack: B1** (the jump from three supervisors to twelve across four sites). Some version of it will come up.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of our terminals dropped noticeably last month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: how on-time is defined here, when the drop started, whether it's one site or several, and which lanes or customers it hits. Then segment (inbound vs outbound, shift, dock, carrier), form two or three hypotheses, name the data you'd pull for each, and separate containment this week from root-cause fixes. End with how you'd report progress. Say your structure out loud before you use it. The question needs no claim about your past, so the guidance makes none | "drive on-time performance" (F2's requirement) asked as a live problem. CASE because structure is what's scored |
| A2 | "It's your first 90 days running four sites. What do you do?" | CASE | [generic] | Learn before you change anything: visit every site, hold one-to-ones with the supervisors, get a baseline for on-time and cost-per-shipment by site, and agree a single daily report and huddle rhythm. Then pick one or two fixes where the data points clearly. Name what you'd deliberately *not* change in the first month. It's a plan, so say it as a plan | The JD's core line (F1's requirement). Hiring managers often use it to test whether a candidate rushes |
| A3 | "How would you bring cost-per-shipment down without hurting on-time performance?" | CASE | [generic] | Name the trade-off first. Then the common levers in this kind of operation: labor planned against volume, overtime, dock and door scheduling, re-handles, damage and claims. Say you'd measure both metrics side by side so a cost win can't hide a service loss. Ask what's already been tried | F3 is the requirement with no evidence behind it, so this is where a strong case answer earns the most. CASE, with the JD's own pairing as the premise |
| A4 | "What would a daily operations report across four terminals show, and how would you build it?" | JD | [grounded] "solid Excel"; "never used Power BI" | Content first: per-site on-time, cost-per-shipment, volume, labor, exceptions; who reads it and what decision it drives. Answer slot: if you've built a report or tracker others used, describe it in your own words. If not, say so plainly. On the tool: "I haven't used Power BI," then your learning plan. Don't imply the Excel work extends to Power BI | Covers "build reporting in Excel/Power BI" (F6, F7). JD-tagged because it's a stated duty. The content half lets you score before the tool gap comes up |
| A5 | "Peak is coming and two of the four sites are short-staffed. How do you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Work the case: forecast volume by site, set staffing against it, decide what moves between sites, set escalation triggers, and decide what you'd watch daily. You can say "I've run the site's peak-season surge plan two years running." Answer slot: if your plan dealt with staffing gaps, say how you handled them, in your own words. If it didn't, say so plainly and work the case from first principles | This is the one case where your own sentence is directly relevant. The quote stays at one site's plan |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're currently over three supervisors. This role leads twelve across four sites. Why are you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | **Deepest rehearsal in the pack.** 1) Name the step before they push on it: "It's a real step up. Today I'm a senior shift manager over three supervisors." 2) Say what you have, at its own scope: seven years in warehouse and distribution ops, and the site's peak-season surge plan two years running. 3) Answer slot: if any of your work has stretched beyond your own three supervisors or your own site, say what it was and your part. If none has, say so plainly. 4) Give the plan as a plan: how you'd lead through twelve supervisors (consistent daily metrics, a fixed one-to-one rhythm, developing your strongest supervisors). **Follow-up 1** ("But that's still one team"): hold by going back to what you've run, not by adding to it. **Follow-up 2** ("So it's a bet"): concede specifically. The scale is the risk, and your plan is how you'd reduce it. Don't fold into "I'm sure I'd figure it out" | F1 and F4 are the two biggest gaps, so a hiring manager will raise this in some form. JD because it scores the stated requirement directly |
| B2 | "We're freight terminals and your background is warehousing. What transfers, and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | What transfers, in your words: seven years in warehouse and distribution ops. Answer slot: if you've worked in a terminal or cross-dock operation, say so and what you did there. If not, say so plainly. On what doesn't transfer, name what you'd need to learn and how, as a plan. Don't describe your past using terminal vocabulary | F1's kind gap. Prepared, it's a strength: a candidate who can see the difference clearly reads as low-risk |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick the gap you actually stated: "I haven't used Power BI." Then a specific learning plan with a timeline, as a plan. Don't choose a fake weakness, and don't make this one smaller than it is | F7 is a stated gap, and naming it yourself scores better than having it found. JD because it's in the listed duties |
| B4 | "The role needs five-plus years of operations leadership. How many do you have?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the actual number of years you've led people, and in which roles, in your own words. Don't let "seven years in ops" stand in for leadership years if the two numbers differ. If it's fewer than five, say the real number and go straight to what you've run | F5 is likely to be checked literally. A clean number is far stronger than a vague one |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 40% mis-pick reduction. How was it counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Four slots, each in your own words: how the rate was counted (what counted as a mis-pick, and the before and after periods); what it's sensitive to; the assumption behind it you'd defend least, named before they find it; and which part was yours. "I don't know exactly how it was counted" is an honest answer if it's true. Don't claim it moved cost or on-time unless you know that it did | It's your one headline number. Defend-the-number EXP |
| C2 | "What did the pick-path redesign actually change, and what was your part?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beat your sentence states: the pick path was redesigned and the mis-pick rate fell 40%. Answer slot: say what changed in the path and which decisions were yours. If others did parts of it, name who and what. "We" for context, "I" for your part | The follow-up to C1. Attribution is what's scored |
| C3 | "How did you know the surge plan worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: if it was measured, say what and how it was counted. If it wasn't measured formally, say so plainly and say what you'd measure next time. Don't supply a result you didn't track | F2's thin bridge. Rehearsing the honest answer keeps you from improvising a number |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, then three beats from your own sentences: seven years in warehouse and distribution ops; cut the mis-pick rate 40% by redesigning the pick path; ran the site's surge plan two years running, and you're green belt certified. Concede the obvious: an insider knows the terminals. Then hold: what you'd bring is the improvement record you just named. Under 60 seconds | A classic stress stem. JD scoring, Pressure delivery |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold on your sentence. Answer slot: say exactly which part was yours, in your own words, and name anyone else's part. **Follow-up 1:** restate the same share calmly, without inflating it. **Follow-up 2:** concede the specific part that wasn't yours, if any, and keep the part that was | Pressure version of C2. Practice holding, then conceding |
| D3 | "Power BI is in the JD and you've never used it. Why should we take the risk?" | JD | [grounded] "never used Power BI" | Don't minimize it: "I haven't used Power BI." Hold on what the reporting is for: the decisions it drives on on-time and cost. Then the plan, as a plan. If pressed again, concede that it's a real ramp, and say how long you'd give yourself and how they'd see progress | F7 under pressure. The goal is to stay calm and keep the gap the exact size it is |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | 90-second arc: seven years in warehouse and distribution ops; now a senior shift manager over three supervisors; two things you're proud of (the 40% mis-pick cut through the pick-path redesign, and running the site's peak-season surge plan two years running); green belt certified. Answer slot: why this role, now, in your own words | It opens almost every round, and the answer sets the frame for the rest |
| E2 | "What drew you to Atlas Freight?" | CO | [generic] | This pack has no researched facts about Atlas (the searches were refused). Read their website and any recent news yourself, then say what you read and where. Connect it to the role's scope: four sites and a team of supervisors. Don't make up facts about them | The CO slot. Answering it with real homework is what separates candidates |
| E3 | "Are you using any Lean or Six Sigma at work these days?" | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Treat it as scored. "I'm green belt certified." Answer slot: if you've run a project with it (the pick path or anything else), say which and what you used. If the pick path wasn't run that way, say so and keep the two facts separate | Covers "Lean/Six Sigma a plus" (F8). Casual questions about plus-skills are often scored |

### V. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a supervisor on your team was underperforming. What did you do?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a real case with a clear expectation, a conversation you had, support or consequences, and an outcome you can name. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | The theme comes from "lead a team of 12 supervisors". Twelve supervisors makes supervisor performance a central part of the job |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a real stake, a moment you didn't back down, and a working relationship still intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you'd handle it | A standard behavioral stem. A manager-of-managers role sits between leadership and the floor |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than claiming to know their org: shared metrics, a regular sync, and escalating with data instead of opinions. Ask where friction sits today | Only likely if a peer joins. Low weight |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others contributed to the pick-path redesign, say who and how you credited them. If not, say so plainly and describe how you handle shared credit in general | Credit-sharing probe. It ties back to D2 |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, A5, B1, B2 |
| "drive on-time performance" | A1, A3, C3 |
| "cost-per-shipment down" | A3 |
| "lead a team of 12 supervisors" | B1, V1 |
| "build reporting in Excel/Power BI" | A4, B3, D3 |
| "5+ years operations leadership required" | B4 |
| "Lean/Six Sigma a plus" | E3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance trending across the four sites, and which site needs the most attention?" | Shows you think in baselines, and it feeds your 90-day answer (A2) |
| R2 | "How is cost-per-shipment calculated here, and what goes into it?" | Definitions decide which levers matter. It also signals you won't chase the wrong number |
| R3 | "What reporting exists today? Is there a Power BI setup I'd inherit, or would I build from scratch?" | Sizes your F7 gap honestly and shows you're already thinking about the build |
| R4 | "How are the twelve supervisors spread across the sites, and how experienced are they?" | Gets straight to the biggest part of the job, and tells you what B1 really means |
| R5 | "Six months in, what would tell you this hire worked?" | Gets the real scorecard, which you can then answer against |
| R6 | "Is this a new role or a backfill?" | Tells you whether you're building or inheriting, which changes everything above |

---

## Prohibited claims

What this pack won't coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Has run terminal or freight operations | Inflated form of F1 (a different kind of work) | F1's quote at its own scope: "7 years in warehouse and distribution ops." The limit is the pack's observation: your material says warehouse and distribution, not terminals. B2's slot stays inside what you've run |
| Has led multiple sites | Inflated form of F1 | "currently a senior shift manager over 3 supervisors" at its own scope. B1's slot asks only about work beyond your own team |
| Has led a team of twelve supervisors | Inflated form of F4 | "currently a senior shift manager over 3 supervisors." The step to twelve is said as a plan, never as a past |
| Seven years of operations *leadership* | Inflated form of F5's quote (ops years made into leadership years) | "7 years in warehouse and distribution ops" at its own scope. B4's slot asks for the real leadership number |
| Has used or built in Power BI | A negative you stated, F7 | "I haven't used Power BI." No slot |
| The mis-pick reduction cut cost-per-shipment or improved on-time | Inflated form of F8's quote (a quality figure made into a cost or service result) | "cut mis-pick rate 40% by redesigning the pick path" at its own scope. C1's slots stay on the mis-pick figure |
| The pick-path redesign was a green belt / Six Sigma project | Inflated form joining F8's two quotes | Each quote on its own. E3's slot lets you join them only if that's what happened |

---

## Sources

- **Provided:** your message (the JD lines and your background). No CV or full JD document.
- **Searches sent:**
  - `"Atlas Freight" regional logistics company values`: refused (web search permission not granted)
  - `"Atlas Freight" interview process operations manager`: refused
  - `"Atlas Freight" news 2026`: refused
- No dossier consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. A values page would have themed VAL questions with Atlas's own values by name |
| 2. `Atlas Freight interview process` operations | unavailable | The search was refused. A documented loop would have replaced the generic-pattern persona weights |
| 3. `Atlas Freight` strategy / recent news | unavailable | The search was refused. Recent news would have grounded E2 and at least one CO or CASE question in Atlas's current situation |
| 4. Interviewer name + company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD lines you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search** (it was refused this run) → Atlas's published values, its interview process and recent news. That adds grounded CO and CASE questions, a values cheat sheet if a values round turns up, and persona weights based on Atlas's actual process. A deeper research pass is also available on request (up to 6 more searches and 2 more fetches, several more minutes)
- **Who you're meeting** (name, title, relationship) → personalized persona weights, an interviewer read, and a reverse question tied to their own career path
- **The recruiter's prep email or process details** → coverage of any pre-declared deliverable, such as a 90-day plan, a case, or a presentation, with its own build section
- **The full JD text** → any requirements the summary leaves out (location, shift pattern, travel) become fit-snapshot rows, and any gate in them gets surfaced
- **Your CV** → CV lines join the evidence column, and F5's leadership years can be read off your actual roles
- **Your answers to the slots** (years leading people, how the 40% was counted, what the surge plan measured) → upgrades F2, F5, C1, C3 and B4 from answer slots to story-mapped guidance
- **A before-and-after mis-pick report or project write-up, and your green belt certificate** → the inspectable proof ops work keeps. It would lift F8 and the C-bank's confidence from medium toward high
- **How much prep time you have** → a prioritized prep schedule sized to it
- **A `tuesday-dossier.md` from an earlier evaluation of this role** → the top objection and the prohibited-claims list come from verified evidence rather than being inferred here
