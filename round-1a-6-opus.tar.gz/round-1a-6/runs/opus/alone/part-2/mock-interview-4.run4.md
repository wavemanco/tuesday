Reading through the skill's rules is done. Next I'll run a few company searches, then build your prep pack.
I've saved your prep pack as `Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the round your note describes: a 45-minute conversation with the hiring manager. It uses your dossier in place of a job description and a CV.

**Before you start:**
- **Check the date.** Today is Thursday 26 November. If the interview is today, read only question A1 and the "Prohibited claims" table. Everything else is backup.
- **Don't say "seven years".** The dossier's summary says "seven years of integration leadership", but none of your verified claims includes a number of years. The pack doesn't put a figure in your mouth, so if you're asked, give your actual years yourself.
- **Research Quartzline yourself.** The web searches I tried were refused, so the strategy questions and case studies are general patterns, not Quartzline-specific. The pack doesn't say anything about the company beyond what your dossier contains. Before the interview, look at their developer docs and recent news (question C3).
- **The dossier is from August.** It's 104 days old, so quickly check the posting hasn't changed.

**What's in the pack:**
- **The question to practise most is A1:** "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" Your dossier flagged this objection.
- **The answer structure is:** admit the gap plainly, describe your integration work only as big as it actually was, then give a ramp-up plan.
- **No bridging on roadmap ownership.** Your dossier says to admit this gap plainly rather than reach for adjacent work. That rule holds everywhere in the pack.
- **There are 22 questions in total,** each tied to one of your three verified claims or labelled as a general pattern.
- **Six questions to ask the interviewer.** Two come from your dossier: who makes which roadmap decisions versus the squad leads, and how partner adoption is measured today.

If you'd like to rehearse, I'll play the sceptical interviewer on A1, the question the pack names as the most worth practising.
I can also update your `tuesday-dossier.md` to record the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday (your words). Interviewer name not given.
**Built from:** your dossier (v1.1, generated 2026-08-14). Web research was attempted and refused, so everything about Quartzline itself is limited to the dossier's role profile.

---

## How to use this pack

- **Personas** describe *how* a question arrives (who asks, in what style). **Types** describe *what is being scored*.
- Type key:
  - **JD**: can you do the listed job, gaps included
  - **EXP**: do your stated claims survive a close look; what was actually you
  - **CASE**: a live problem from the role, scored on structure and reasoning
  - **CO**: company and strategy homework
  - **VAL**: whether past behaviour shows the company's published values
- **Provenance labels:** `[grounded]` = traceable to your dossier; `[inferred]` = the pack's own derivation, named; `[generic]` = a role-family pattern with no claim about you or Quartzline.
- **V1–V3** are the three `verified_candidate_evidence` entries in your dossier, in order. Each one is quoted exactly as the dossier gives it.
- The guidance gives you scaffolding, not a script. Say it in your own words, and say nothing a quote doesn't carry.
- Question bank letters skip **F** so that question IDs never clash with fit-snapshot rows (F1–F10).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3, "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | This is a bridge, positioned as adjacent and never as PM experience (the dossier's condition). First the plain acknowledgment, sourced from prohibited_claims: "Having held a product manager title or role": "I haven't held a product manager title." Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the material shows work that fed product, not a product role. Answer slot: the 3+ years line makes a probe on your years likely. Give your actual years and titles in your own words. The dossier's summary mentions years, but no verified entry carries a figure, so this pack supplies none |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | There is no bridge here. The dossier's acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" and its prohibited_claims "Having owned a product roadmap" close it. Words: "I haven't owned a product roadmap." Follow with a ramp plan, said as a plan and never as a past: how you would learn the roadmap's current state, who you would talk to first, and how you would make your first call. Don't reach for the roadmap-input sessions on this point. Here they would read as a bridge, and the dossier rules one out |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | The quote covers integrations of the vendor's APIs, not the API product itself, and your words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through to go-live." Answer slot: R2 makes a probe on what you shipped likely. If any change to the API or platform itself shipped from that work and part of it was yours, say what and which part, in your own words. If none did, or it wasn't yours, say so plainly and stay with the integrations you led to go-live |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1, "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | The quotes involve REST APIs and architecture, but they don't show whether docs or schemas were part of your work. Answer slot: if reading or writing API docs and schemas was part of scoping and architecture on those integrations, say how, in your own words. If it wasn't, say so plainly and stay with the integrations and the playbook. The dossier records the playbook as provided and inspectable. If you're free to share it, it's the one artifact you can put on the table |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important: the customer and product side | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1, "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | presentation | The quotes already name clients and product. Reword only those: the clients on 30+ integrations you led, and the product team your quarterly sessions fed client evidence to. The band is medium because the dossier marks V3 as confirmed with limited inspectable proof. Expect a probe on the sessions, and keep that claim at "feeding client evidence to product" |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important: the engineering and sales side | none given | none | [grounded] | discovery | Your material doesn't show work with engineering or sales. Answer slot: if you worked with engineering or sales on those integrations, say with whom and what part was yours, in your own words. If you didn't, say so plainly and stay with clients and product |
| F7 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [inferred] | discovery | Clarify strategy, per the dossier. No verified entry speaks to this. Answer slot: "agile delivery" is the probe. If you worked that way, say how, in your own words. If you never worked that way, say so plainly. Then say what you'd want to confirm about how Quartzline's squads define it |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | V1 names requirements within integration work. That isn't a product spec for a squad, and prohibited_claims "Having set prioritization for an engineering squad" holds. Words: "I led those integrations through scoping, requirements, architecture, UAT and go-live." Answer slot: the spec line makes a probe on what you wrote likely. If you wrote requirements yourself on those integrations, say what they covered, in your own words. If you didn't, or they weren't yours, say so plainly and stay with leading the integrations |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material doesn't show metrics work. Answer slot: if you tracked any measure on the integrations or the playbook, say what was counted and how, in your own words. If you didn't, say so plainly and say what you'd measure first |
| F10 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3, "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | medium | [grounded] | transferability | Words at their own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product, and I led scoping on 30+ client integrations." Answer slot: if gathering that client evidence meant talking to clients yourself, say how, in your own words. If it didn't, say so plainly and stay with the sessions. Medium caveat: name the sessions' limit before you're asked, so the prober doesn't extract it |

---

## Persona table

Your message establishes the session: one 45-minute conversation with the hiring manager. The weights follow the hiring-manager prior (Case/Strategist and Skeptic), adjusted by the dossier. No interviewer profile exists, so no signal adjustments were made.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 Qs) | Quiet pressure on the title gap and on roadmap ownership | High. The hiring-manager prior puts it in the top two, and the dossier names the title-and-roadmap objection, which lands on F1 and F2, both on must-have lines | Rehearse A1 until it's boring. Concede what the dossier fields close, then return to V1–V3 at their own scope, then give a ramp plan |
| Case/Strategist (bank B, 5 Qs) | Live problems on adoption, prioritisation and partner trade-offs | High. The hiring manager is buying capability on the role's own responsibilities, and a case asks about no past, which suits a candidate whose gaps are in the history rather than the reasoning | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case |
| Conversational (bank C, 3 Qs) | The opener and the closing minutes | Medium. In 45 minutes the "walk me through" opener is near-certain and it's scored | A pre-built 90-second arc from V1–V3. Treat casual questions as scored |
| Data-Driven Prober (bank D, 3 Qs) | "30+ — how are you counting?" and "what's in the playbook?" | Medium. V1 carries the one figure in your material, and V3 is medium confidence, which is exactly the seam a prober finds | Know how the figure was counted and say so in your words. Volunteer V3's limit first |
| Pressure (bank E, 2 Qs) | A time-boxed "why you" or "how much was actually you" | Low to medium. It's not the prior for this round, but the title gap invites it | Pause, restate, hold through two follow-ups, then concede the specific point the dossier fields close |
| Peer Evaluator (bank G, 2 Qs) | How you'd work with the two squad leads | Low to medium. The dossier flags decision authority versus the squad leads as unknown, so the hiring manager may test how you'd handle it | Propose working principles rather than claiming to know the seam |
| Values/Behavioral (bank H, 2 Qs) | A "tell me about a time" or two | Low. No values-style round is detected, but most hiring managers ask one behavioural question | Selection scaffolds with an honest branch. "We" for context, "I" for your part |

---

## Question banks

**Highest-ROI prep in this pack: A1.** The underwriting dossier named this objection. Rehearse it out loud until the concession sounds calm.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] prohibited_claims "Having held a product manager title or role", prohibited_claims "Having owned a product roadmap", "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", "Wrote the internal integration playbook her team uses", "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Concede first, plainly:** "That's right. I haven't held a product manager title, and I haven't owned a product roadmap." **Then what you did, at its own scope:** "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. I wrote the internal integration playbook my team uses. And I ran quarterly roadmap-input sessions feeding client evidence to product." Describe the work and let them draw the inference. Don't tell them what it proves. **Then a ramp plan, as a plan:** what you'd learn first (which decisions are yours versus the squad leads', the adoption baseline) and whom you'd talk to. **Follow-up 1** ("So that's not product management"): hold. "Right, it's adjacent, not the PM job." Return to the quotes and add nothing. **Follow-up 2** ("Who decided what product did with your input?"): answer slot. If you know how product used it, say so in your own words. If you don't, say so plainly. Never give the sessions a decision. The dossier marks V3 as the claim with the least inspectable proof, so keep it at "feeding client evidence to product" | The dossier's named objection, aimed at F1 and F2, both on must-have lines. JD, because it scores R1 directly. Its negatives are asked as the dossier wrote them, since each has a prohibited_claims source |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it, because naming it yourself is stronger than having it found: "Owning the roadmap. I haven't owned a product roadmap." Then the ramp plan, as a plan: the first decisions you'd expect to make, how you'd learn the current roadmap's reasoning, and who you'd lean on. Don't follow it with a bridge. The dossier closed this area to bridging | A Skeptic stem that lands on F2. Rehearsing the honest answer here stops the candidate reaching for the V3 sessions as a stand-in, which the dossier rules out |
| A3 | "What API or platform products have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start from what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through to go-live." Answer slot: if any change to the API or platform itself shipped from that work and part of it was yours, say what and which part, in your own words. If none did, or it wasn't yours, say so plainly and stay with the integrations you took to go-live. Don't call the integrations a product launch | R2 is a must-have, and F3 is adjacent rather than direct. The question presupposes shipping, which R2 raises and V1 doesn't carry, so the guidance is a slot whose second branch lets that premise be false |
| A4 | "Why product, why now, and why this role?" | JD | [generic] | Your reasons are yours, and the pack supplies none. Give them in your own words, in under a minute. Tie them to the role's own lines, which are fair to quote: "the partner-facing API platform", "Run discovery with integration partners". Keep any mention of your past to V1–V3 as worded in A1 | The Skeptic's "why leave, why here, why now". Motivation consistency gets scored hardest for career-switch candidates like F1 |
| A5 | "This PM makes calls the two squad leads may disagree with. Why would they follow someone who hasn't set a squad's priorities?" | JD | [grounded] prohibited_claims "Having set prioritization for an engineering squad", "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Concede: "I haven't set prioritization for an engineering squad." Then what you did lead, at its scope: "I led 30+ end-to-end client integrations, from scoping through go-live." Answer slot, from F6: if engineering teams were part of those integrations, say who and what your part was. If not, say so plainly. Then turn it into a clarifying question: how is authority split between this PM and the squad leads today (reverse question 1) | The dossier flags squad authority as unverified, and F8 sits on that line. JD, because it scores the "drive delivery with two engineering squads" responsibility |

### B — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of the partner API is yours to define and track. How would you define it, and what would you look at first?" | CASE | [generic] | Clarify first: adoption of what (the platform, a new endpoint) and by whom (all partners, or a segment). Then a funnel you'd propose: access granted, first successful call, production traffic, sustained usage. Segment by partner type or size. Ask what the baseline is today, since the dossier lists it as unknown. Name one way the metric could mislead (raw call volume can climb while few partners actually adopt). If asked what you've measured before, use the F9 slot: say what was counted, or say plainly that you didn't track measures | The "define and track adoption metrics" responsibility, with F9 silent. A case lets you show reasoning without needing a past. `[generic]` because no Quartzline data is in hand |
| B2 | "A large partner wants a breaking change to an endpoint other partners rely on. What do you do?" | CASE | [generic] | Clarify the need behind the request. Size who else is affected. Look at options: versioning, a non-breaking addition, a deprecation window. Bring engineering in on cost. Communicate the decision and its timeline to all affected partners. Name the risk you're trading off | A classic platform-API trade-off. It also tests R3 (technical fluency) live, without presupposing your history |
| B3 | "You inherit more partner requests than two squads can build this half. How do you decide what goes first?" | CASE | [generic] | Clarify first: which of these decisions are yours and which are the squad leads'. That's the dossier's open question, and asking it shows judgment. Then the objective for the half, then evidence per request (partners affected, revenue or adoption tied to it, effort from engineering). Make a visible trade-off and say how you'd communicate the no's. Keep it in the hypothetical. This is the case where "in my last role I prioritised…" would cross the prohibited_claims line | The roadmap-ownership responsibility (F2), asked as a decision rather than a record, which is the one safe way to show it |
| B4 | "Sales promised a partner a feature that isn't on the roadmap. What happens next?" | CASE | [generic] | Clarify what was promised and when. Find the partner's underlying need. Check whether something existing meets it. Bring sales and engineering into one conversation. Decide, communicate, and agree how commitments reach the roadmap next time | R4's engineering-and-sales side, where F6 is silent. The case lets you show the approach without a past claim |
| B5 | "How would you run discovery with our integration partners in your first month?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Plan: which partners (a spread by size and maturity), what you'd ask, how you'd turn notes into evidence, and who sees the output. If they ask what you've done closest to this, use the quote at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot from F10: if gathering that evidence meant talking to clients yourself, say how. If it didn't, say so plainly | The "Run discovery with integration partners" responsibility, where F10 is the nearest adjacent row. CASE, because it asks for a plan. The past is optional and quoted |

### C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", "Wrote the internal integration playbook her team uses", "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built from the three beats the quotes carry: the integrations you led from scoping to go-live, the playbook your team uses, and the quarterly sessions feeding client evidence to product. Answer slot from F1: your years and titles, in your own words. Close on why this role, in your own reasons. Rehearse with a timer | The near-certain opener, where V1–V3 get framed before any Skeptic question. EXP, because the arc is a claim about your history |
| C2 | "What's been your favourite integration to work on?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one of the integrations you led. The beats the quote gives you are scoping, requirements, architecture, UAT and go-live. Tell them in your own words, with only what actually happened on that one. If none stands out, say so and describe a typical one through those stages | It sounds casual but it's scored on communication economy. It also lets you rehearse V1 without inflating it |
| C3 | "What do you know about our API platform so far?" | CO | [generic] | Research Quartzline yourself before the interview, since this pack's search was refused: its partner docs, developer portal, recent announcements. Bring one specific observation and one genuine question. If you found little, say what you looked at and ask. Never fill a gap with a guess | No CO grounding exists in this pack. This is the homework question, and the honest answer depends entirely on your own reading |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "30+ integrations. How are you counting those?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words. Say how it was counted and what would make it higher or lower. Name, before they do, the part of the count you'd defend least. Say which part was yours (the quote says "led"). If you don't know exactly how it was counted, say so plainly. Don't round up | The one figure in your material. Every headline number gets a defend-the-number rehearsal |
| D2 | "Walk me through the integration playbook. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | You wrote it and your team uses it. Say that, then describe what it covers in your own words. If you're free to share it, offer to. The dossier records it as inspectable, so it's your strongest artifact. Don't widen "your team" to anyone beyond it | V2 is high confidence and inspectable. A prober will reward specifics you can show. It also touches R3 (F4) |
| D3 | "In those roadmap-input sessions, what evidence did you bring, and what did product do with it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say first that this is the claim with the least you can show for it. The dossier marks it medium. Then: you ran them quarterly, and they fed client evidence to product. Answer slot: what the evidence was, in your own words. On what product did with it: if you know, say so. If you don't, say so plainly. Never present product's decision as yours | V3 is medium confidence, the exact seam the dossier says to expect a probe on. Volunteering the limit turns a gotcha into credibility |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years on platform APIs?" | JD | [grounded] prohibited_claims "Having held a product manager title or role", "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, then A1 compressed: "I haven't held the PM title. What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Then one sentence of ramp plan. Stop before sixty seconds. If they push, hold on the quote and concede only the title | The time-boxed version of A1. Composure is what's scored |
| E2 | "That's integration work, not product work. How much of the product thinking was actually you?" | EXP | [grounded] prohibited_claims "Having held a product manager title or role", "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Agree with the true part: "It was integration work. I haven't held a product role." Hold on what you did: you led those integrations through scoping and requirements. Answer slot, inside V1's scope: if any scoping or requirements decisions on those integrations were yours to make, say which and how, in your own words. If none were, say so plainly. Hold through two follow-ups, then concede the specific point and nothing more | The pressure stem "how much was actually you", aimed at F1 and F8. EXP, because it tests attribution |

### G — Peer lens (squad leads)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A squad lead thinks a partner request is a distraction, and you think it matters. What happens?" | CASE | [generic] | Understand their reasoning first. Lay out the partner evidence. Agree on what would change either of your minds. Decide within whatever authority the role actually has, or escalate cleanly. Keep the relationship intact. Propose principles rather than claiming you know Quartzline's split | Squad authority is the dossier's top unverified risk, and this is how a hiring manager tests it without asking about your past |
| G2 | "How do you like to work with engineering squads day to day: sprints, kanban, something else?" | JD | [inferred] | Clarify strategy (F7). Answer slot: if you've worked in an agile setup, say how, in your own words. If you never worked that way, say so plainly. Then: "What I'd want to confirm is how your squads run planning and where the PM sits in it" | R5 (preferred). The dossier's clarify strategy binds here, so nothing about your past goes in unless you say it |

### H — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to a product or engineering team." | VAL | [generic] | Pick a time with a named stake, a moment you didn't fold, and the relationship intact afterwards. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem in hiring-manager rounds. `[generic]` because Quartzline's published values couldn't be researched |
| H2 | "When did you put a client ahead of an internal deadline or metric?" | VAL | [generic] | Pick a time where the client need was real, the internal cost was named, and you can say what part of the decision was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd weigh it | Client-facing work like V1 makes this a natural ask. A scaffold rather than a story map, because no quote carries such an event |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 — 3+ years PM experience | A1, A4, E1, C1 |
| Roadmap ownership (R1 sub-claim, responsibility) | A1, A2, B3 |
| R2 — Shipped API or platform products | A3, E2 |
| R3 — Technical fluency: API docs, schemas | B2, D2 |
| R4 — Stakeholder management | A5, B4, G1 |
| R5 — Agile delivery | G2 |
| Run discovery with integration partners | B5, D3 |
| Write specs and drive delivery with two squads | A5, E2, G1 |
| Define and track adoption metrics | B1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It comes straight from the dossier. Authority is asserted in the JD but not evidenced. The answer tells you whether you'd own the roadmap at all, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | It comes from the dossier. Adoption is a named responsibility with no stated baseline. If no baseline exists, you'd be building the metric, not moving it |
| 3 | "Where do partner integrations most often get stuck today?" | It's the ground nearest your adjacent work (F3, F10), and it turns the conversation to where you'd contribute first |
| 4 | "How do sales commitments to partners reach the roadmap now?" | It shows you're thinking about R4's sales side and the process seam behind case B4 |
| 5 | "Six months in, what would make you say this hire worked?" | It gets the real success criteria, which may differ from the JD's lines |
| 6 | "What's the hardest open question on the platform roadmap this half?" | It invites the hiring manager to talk about their actual problem, which is the best possible use of the last minutes |

---

## Prohibited claims

This pack won't coach any of these, in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held a product manager title." Then F1's quotes at their own scope |
| "I did the PM job without the title" / "de facto PM" | Implies the dossier's prohibited_claims "Having held a product manager title or role", and breaks its condition that the bridge is never positioned as PM experience | F1's quotes at their own scope. Describe the work and let the interviewer draw any inference |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan, as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Then V1 at its scope |
| Shipped an API or platform product | Inflated form of V1 (F3) | V1 at its own scope. The pack's observation: the material says integrations of the vendor's APIs, not the API product. A3's slot stays inside the integrations |
| Wrote product specs | Inflated form of V1's "requirements" (F8) | V1 at its own scope. E2's slot asks only which requirements decisions on those integrations were yours |
| Decided what product built from the roadmap-input sessions | Inflated form of V3 (F1, F10) | V3 at its own scope: sessions feeding client evidence to product. D3's slot asks only what you know product did with it |

---

## Sources

**Provided:** `tuesday-dossier.md`, version 1.1, generated 2026-08-14 by the job-underwriter skill. It supplied:
- `role_profile`: the requirements R1–R5, the responsibilities and the unknowns. This stands in for the JD.
- `handoff_to_mock_interview`: the verified evidence V1–V3, the allowed strategies per weak area, the named objection (A1), the risks and employer questions (reverse questions 1–2), and `prohibited_claims`.
- `decision`: context only.

The dossier had no `evidence_map`, `evidence_state` or `risk_register` sections. It is 104 days old, so the role profile reflects the posting as of August.

**Loop:** your message ("a 45-minute conversation with the hiring manager") establishes this session. No archetype fallback was used. No values-style round was detected, so the values cheat sheet is omitted.

**Searches sent:**
1. `Quartzline company values` — refused
2. `Quartzline interview process product manager` — refused
3. `Quartzline API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. Published values would have themed H1–H2 with Quartzline's own value names |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have shown whether other rounds follow this one and whether a values round exists |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have grounded C3 and the B-bank cases in current Quartzline priorities. They are `[generic]` instead |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form |
| 5. Representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirements and fixes the fit snapshot |

---

## Upgrade menu

- **Web search permission:** rerun targets 1–3, so H1–H2 map to Quartzline's published values and C3 and B1–B4 rest on its current strategy instead of `[generic]` patterns
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, recent org context and role-family interview reports, feeding a sharper CO and CASE bank
- **The hiring manager's name** → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- **Any recruiter prep email** → coverage of stated focus areas or any pre-declared exercise
- **The current posting text** → confirms the August role profile still holds, and turns any changed lines into updated F-rows
- **Something inspectable from the roadmap-input sessions**, such as an agenda or a summary sent to product → raises V3 from medium to high, which strengthens F5, F10, D3 and A1
- **Your own answers to the slots on agile, metrics, and engineering/sales work** → F6, F7 and F9 move from `discovery` to quoted rows, and G2, B1 and A5 become story-mapped
