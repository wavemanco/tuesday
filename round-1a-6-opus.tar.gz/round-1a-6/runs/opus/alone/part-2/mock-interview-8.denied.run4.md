I've read most of the prep-method notes. Two short ones are left, then I'll write your pack.
Now writing your pack.
I've saved your prep pack as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. It covers all three rounds on 5 December, built from what you pasted; I didn't do any web research, because your material already covered what that research would have found.

- **Shared core:** a table matching each line of the job description to your own sentences, with an honest way to answer where there's a gap. You'll see the gaps marked as "answer slots": two options, one if you did it and one if you didn't.
- **Round 1, the recruiter (8 questions):** includes salary, notice period, location and why you're leaving. The guidance on each says to give your real answer and adds nothing for you.
- **Round 2, the Head of Member Services (9 questions):** mostly behavioural, as the recruiter said.
- **Round 3, the panel (9 questions):** a cheat sheet linking each of the four values to a story you could tell, plus a step-by-step plan for the 20-minute escalation case.
- **Most important to practise:** question H1, "You haven't worked in a contact centre… why should I trust you with the contact-centre side?" Your contact-centre and senior-presenting gaps are the ones most likely to be pressed. H1 gives you the exact wording for admitting the gap first and holding steady through two follow-ups.
- **Things the pack won't coach you to claim:** a list at the end. It includes owning the complaints process across branches, coaching supervisors, writing the escalation script, and presenting to senior leaders.

Say the word and I'll play the Head of Member Services and run H1 with you live, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 5 December, per the recruiter's email. Round 1 is 30 minutes with the recruiter. Round 2 is 45 minutes with the Head of Member Services, your would-be manager, "mostly behavioural". Round 3 is 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation, scored against the four values.
**Interviewers:** not yet assigned beyond their roles, so there is no interviewer read.
**Mode:** loop. One shared fit snapshot and case build, then a mini-pack for each round.

---

## How to use this pack

- **Personas** describe *how* a question is asked: friendly, skeptical, under time pressure, as a case. **Types** describe *what* is being scored.
- Every question has a **Provenance** cell. `[grounded]` means it traces to something you or Ashgrove supplied. `[inferred]` means it's this pack's own reasoning, and the reasoning is named. `[generic]` means a standard pattern for this kind of role, with no claim about Ashgrove.
- An **answer slot** is a spot where the pack doesn't know the answer, so it gives you two honest branches. Fill it from what actually happened, or say plainly that it didn't happen.
- The guidance is scaffolding, not a script. Say it in your own words.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's four published values |
| EXP | Whether what you say about your experience holds up, and which part was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | How you structure a live problem from the role |

---

## Fit snapshot (shared across all three rounds)

Every quote in the evidence column is your own sentence from your message. Everything this pack says about your past comes from these four sentences and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch side) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not a process across branches, and your words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how a complaint got from first contact to closure at your branch likely. If parts of that were yours to decide, say which and how, in your own words. If the log was a record you kept and the decisions sat with someone else, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre side) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording can close this gap, and you have said so yourself. Words: "I haven't worked in a contact centre." Follow them with how you would learn it, said as a plan and never as something you've done. Add nothing that makes the gap sound smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | In your words the spreadsheet is monthly, it covers complaints, and you built it. Your material doesn't show whether it tracked volumes or resolution times. Answer slot: if it counted complaints or tracked how long they took to resolve, say which, in your own words. If it tracked other things, say what it tracked and stop there |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | You trained new tellers, not supervisors, and it was your branch's script. You can state as plain fact that you've been a branch supervisor for the last three years. Answer slot: the JD's coaching line makes a probe on coaching a fellow supervisor likely. If you've ever helped another supervisor with an escalation, say what happened and what your part was, in your own words. If you haven't, say so plainly and give how you would approach it |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence would be a named digital or online change you fed into, with your part in it stated. Answer slot: if you've worked with a digital or online-banking team, or passed member feedback into a change to an online journey, say what happened and what your part was. If not, say so plainly, then say how you would start working with the digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it in your own sentence's terms: "I've spent six years in retail banking, the last three as a branch supervisor." Let the interviewer map that onto "customer operations". Don't relabel your own history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" is your word. Whether those complaints came under regulatory rules isn't in your material. Answer slot: if they came under regulatory rules, such as required response times or a required final response, say which rules applied and which part of meeting them was yours, in your own words. If you don't know what rules applied, or the log wasn't the regulated process, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | This is a gap you stated. Words: "I haven't presented above regional level." Then a plan for how you'd prepare to present, said as a plan. Nothing added to shrink it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says "spreadsheet" but not which tool. Answer slot: if you built it in Excel, say so and name what you did in it, in your own words. If you used another tool, name it plainly |

No requirement here is a gate (a licence, location, pay or similar term). "4+ years" is a length-of-experience requirement, and it's graded like any other.

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced this case, and the panel scores against the four values. So the case is where the values get scored live, not only in the stories.

**What you can build on from your own material:**

| Draws on | Your sentence, exactly | How to use it in the case |
|---|---|---|
| F1 | "I handled the branch's formal complaints log and trained new tellers on our escalation script." | You know the branch end of an escalation. Speak from that seat and say it is the branch seat |
| F6 | "6 years in retail banking, the last 3 as a branch supervisor." | The panel are branch managers. You can say you've been a branch supervisor, with no claim beyond that |
| F2 | "Never worked in a contact centre, and I've never presented to anyone above regional level." | If the case involves the contact centre, ask how it works there rather than assuming |

**Structure for 20 minutes:**

| Step | Time | What you do | Value it shows | Provenance |
|---|---|---|---|---|
| Clarify | 2–3 min | Ask what the member wants, who holds the complaint now, how long it has been open, and whether a regulatory deadline is running | Members First, Always | [generic] |
| Member first | 4–5 min | What happens today for this member: one named owner, one plain-language contact, a date for the next update | Members First, Always and Plain Words | [generic] |
| Own it | 4–5 min | Whoever holds it keeps it until it's solved, including when it crosses between branch and contact centre | Own the Fix | [grounded] value text pasted from ashgrovecu.org |
| Find the cause | 3–4 min | Why it escalated: the script, a handoff, a policy, a training gap | Own the Fix | [generic] |
| Fix and report | 2–3 min | The process change, the coaching for the supervisor, and how it shows up in the monthly complaints report | Neighbours, Not Numbers: the branch keeps its relationship with the member | [inferred] from the JD's reporting and coaching lines |
| Close | 1 min | Name the value behind each decision you made, briefly | All four | [inferred] from the recruiter's note that the panel scores the four values |

**Theses you could run, each with the concession you should make:**

| Thesis | Concession you make out loud | Provenance |
|---|---|---|
| Fix the member's problem before fixing the process | A fast fix that skips proper investigation can break regulatory timelines, or simply be wrong. Say you would check what applies | [generic] |
| One owner for each complaint across channels, whoever found it first | One owner adds load to whoever picks it up, and handoffs sometimes exist for good reasons. Say you'd want to understand why the current handoffs exist | [grounded] Own the Fix, pasted values page |
| Every escalation becomes a line in the monthly report, so patterns get fixed and not just cases | Reporting doesn't resolve this member's complaint. Say the report comes second to the member | [grounded] JD reporting line |

**Differentiation:** the standard answer is a generic acknowledge, investigate, resolve, follow up. You stand out by (a) asking clarifying questions before you structure, (b) naming Ashgrove's values by their official names as your decision tests, and (c) closing on the process fix and the coaching, not only the single case.

**Things not to do, with two branch managers in front of you:** don't blame the branch in the case; treat it as a process to fix. Don't promise the member an outcome or compensation before the investigation. Don't describe how Ashgrove's contact centre works; ask.

---

## Grounding brief (from the July 2026 strategy brief the recruiter sent you)

The brief is about four months old as of 26 November 2026, so it's current enough to cite. Refer to it by name ("the 2026 strategy brief") so it's clear you read it.

| Fact | Source | What it likely means for your answers | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026 | Complaints about digital journeys become a data source for the digital teams. That connects to the JD's self-service line | [inferred] |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | Expect consolidation-related complaints in 2027. "Neighbours, Not Numbers" is under pressure here, and your panel is two branch managers, so handle the topic with care | [inferred] |
| Launch a small-business lending product in Q1 2027 | Strategy brief, July 2026 | A new product brings a new complaint category for the process you would own. Good material for a reverse question | [inferred] |
| Main competitive pressure is app-only banks | Strategy brief, July 2026 | Members can leave easily. A complaint handled well is a retention moment | [inferred] |
| Member-owned, about 900 staff | JD | Members are owners, so "member" is the word to use, not "customer" | [grounded] |

---

# Round 1: Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through, "why us", logistics | High. A 30-minute recruiter slot is mainly a screen, and the recruiter runs the process | A 90-second arc built from your three sentences. Treat casual questions as scored |
| Skeptic, light | Quick checks against the JD's requirements | Medium. Recruiters check for knockouts; the contact-centre and regulated-complaints lines are the obvious ones | A one-line honest answer, then move on. Don't over-explain |
| Pressure | Hardly at all | Low. Nothing in the recruiter's email suggests it | Pause, restate, answer |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, three beats, each one of your sentences in your own words: six years in retail banking with the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. End with one line on why this role, in your own words | F6, F1 and F3 cover the role's three main lines. EXP because a biography is the first place attribution gets set |
| R2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Give your real reason, in your own words. If it connects to something Ashgrove published, name one thing, not four: a value by its official name, or one point from the 2026 strategy brief. If no reason beyond the role itself comes to mind, say what the role is to you plainly rather than reciting the values page | Motivation is the recruiter's standard check. CO because naming one specific published thing shows you did the homework |
| R3 | "Why are you looking to move on from your current role?" | EXP | [generic] | Give your actual reason, in your own words, kept short and forward-looking. Add nothing you wouldn't repeat to the Head of Member Services | A standard recruiter logistics check. EXP because the reason gets compared against what you say in later rounds |
| R4 | "What are your salary expectations?" | JD | [generic] | Either give your own number or ask for the role's band first; which one is your choice. If asked what you earn now: "I'd rather focus on the range for this role." | Always asked at this stage. JD because it concerns the listed job's terms |
| R5 | "What's your notice period?" | JD | [generic] | Give your actual notice period | A standard logistics check. JD because the start date is a term of the role |
| R6 | "The role covers branches and the contact centre. How are you on location and travel between sites?" | JD | [grounded] | Give your actual position on location and travel, in your own words | The JD's "across branches and the contact centre" raises this, and so does the hub consolidation in the strategy brief. JD because it's a term of the role |
| R7 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from your sentence: you handled the branch's formal complaints log. Answer slot: if those complaints came under regulatory rules, name the rules and your part in meeting them, in your own words. If you're not sure what applied, say so plainly and stay with the log. Keep it to under a minute here; the manager round goes deeper | F7 is the requirement your material shows least clearly, and a recruiter may tick it off literally. JD because it scores a named requirement |
| R8 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then one sentence of plan, such as spending early weeks alongside contact-centre advisers on live complaints. Stop there. A short, unflustered answer is the whole job | F2 is a gap you stated, and the JD names the contact centre, so a knockout-style check is likely. JD because it's a literal requirement |

## Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "Will the panel case be given to me on the day, or is there a brief beforehand?" | Changes how you prepare for the 20 minutes, and shows you're taking the case seriously |
| "Is the case scored separately from the values, or are they scored together?" | Tells you whether to name the values inside the case |
| "When will the interviewers be confirmed, and could you share their names?" | Their names let you prepare for each person; the recruiter said they aren't assigned yet |
| "Where would the role be based day to day, given the move to five hubs?" | Shows you've read the strategy brief, and it's a real logistics point |
| "What happens after 5 December, and when would I hear?" | Simple, and recruiters expect it |

---

# Round 2: Head of Member Services (your would-be manager), 45 minutes

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" stories | High. The recruiter said this round is "mostly behavioural" | Pick from the selection scaffolds below. "We" for context, "I" for your part |
| Skeptic | Pressing on the contact-centre and senior-presenting gaps | High. A manager is taking the risk on gaps, and F2 and F8 are gaps you stated | H1 is your highest-ROI rehearsal. Name the limit first |
| Data-Driven Prober | Digging into the spreadsheet | Medium. The JD's monthly-reporting line matches the spreadsheet in F3 | Say only what the spreadsheet tracked. Fill the slots honestly |
| Case / Strategist | Strategy and planning questions | Medium. A manager owns the roadmap, and the strategy brief gives them material | Clarify, then structure, then tie back to the brief |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You haven't worked in a contact centre, and this role owns complaints across branches and the contact centre. Why should I trust you with the contact-centre side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** Name the limit before they finish pressing: "I haven't worked in a contact centre." Then what you bring, in your sentence's terms only: you handled the branch's formal complaints log and trained new tellers on your escalation script. Then a plan, said as a plan: sit with advisers on live complaints, read a sample of closed contact-centre cases, map where branch and contact-centre handoffs happen. Follow-up 1, "So you'd be learning on the job?": hold, "On the contact-centre side, yes, and I'd be open with the team about that." Follow-up 2, "Wouldn't someone from a contact centre be safer?": concede specifically without folding, "They'd know the contact-centre floor better on day one. I'd bring the branch side, where I handled the formal complaints log." Never hint at contact-centre exposure through words like "similar" or "phone-based" | F2 against the JD's contact-centre line is the most predictable objection to you. JD because it scores the stated requirement; Skeptic delivery |
| H2 | "Tell me about a complaint that was hard to resolve." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint from your time handling the branch's formal complaints log. It needs a member with a real problem, something that made it hard, and a decision of yours. Tell what you did, in your own words, and how it ended, including if it ended imperfectly. If no single complaint comes to mind where the decision was yours, say so plainly and describe how you handled the log | F1 is your nearest evidence, and the round is behavioural. VAL first because "Members First" and "Own the Fix" will be listened for; EXP second |
| H3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start from your sentence: you built it, it's monthly, your regional manager uses it. Answer slot: the JD's reporting line makes "does it track volumes and resolution times?" likely. If it does, say which, in your own words; if it tracks other things, say what. Answer slot: if you built it in Excel, say so and name what you did in it; if it was another tool, name it. On how the regional manager uses it, say only what you know; if you don't know, say so | F3 and F9 both rest on this sentence, so a Prober will spend time here. EXP because it tests what was actually yours |
| H4 | "If you reported complaints to me monthly, what would be on page one?" | CASE | [generic] | Structure: volumes, resolution times, oldest open cases, top themes by channel (branch, contact centre, digital), and one ask. Keep it to one page. Say you would ask what senior leaders already see before you designed it | The JD's monthly-reporting line turned into a live problem. CASE because it asks about no past |
| H5 | "Tell me about a time you escalated something above your branch." | VAL | [generic] | Selection scaffold: it needs a problem your branch couldn't solve alone, your decision to escalate, and what happened next. If no such time comes to mind, say so plainly, then describe how escalation worked at your branch from where you sat | The JD's escalation line, asked behaviourally. VAL because "Own the Fix" is about keeping hold of a problem, including after you escalate it |
| H6 | "You trained new tellers on the escalation script. How did you know it was working?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with what your sentence says: you trained new tellers on your escalation script. Answer slot: if you checked whether it was working, say how, in your own words. If there was no such check, say so plainly and stay with what you did. Don't say you wrote or designed the script; your sentence says "our escalation script" | F4 is your nearest evidence for coaching. EXP because it probes the gap between training and coaching |
| H7 | "This role coaches branch supervisors, the job you do now. How would you coach a supervisor who escalates too much, or too little?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Structure: find out why (unclear thresholds, fear of getting it wrong, workload), agree a plain threshold together, review a few real cases with them, follow up. You can say you know the supervisor's seat because you've had it for three years. Don't claim to have coached supervisors before | F4 against the JD's coaching line. CASE because it's a live coaching problem; the one premise is your own sentence |
| H8 | "The role presents to senior leaders. Tell me about presenting." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Plain acknowledgment: "I haven't presented above regional level." Answer slot: the JD's presenting line makes a follow-up likely. If you have presented at regional level, say to whom and what, in your own words; if you haven't presented formally at all, say so plainly. You can say, as stated, that you built the monthly complaints spreadsheet your regional manager uses; don't call it a presentation. Then a plan: how you'd prepare for a senior audience (one page, the three numbers that matter, one ask, a rehearsal with your manager) | F8 is a gap you stated, and the JD names it. JD because it scores the requirement; expect Skeptic delivery |
| H9 | "We're moving 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Structure: complaints will increasingly be about digital journeys; complaint themes are input for the digital teams' self-service work; members who can't or won't go digital need a clear route (Members First, Always); and the plain-language test applies to screens as well as letters (Plain Words). Answer slot: if you've ever passed member feedback into a digital change, say what happened and your part; if not, say so plainly and say how you'd start with the digital team | The strategy brief's headline target, plus F5 against the JD's self-service line. CO because it tests whether you can think at Ashgrove's level |

## Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "How do complaint numbers reach senior leaders today, and what would you want to change about that?" | It goes straight at the presenting requirement (F8) and shows you want to learn how it's done here |
| "How do complaints move between the branches and the contact centre today, and where do they get stuck?" | It goes straight at your F2 gap with curiosity rather than defensiveness |
| "How closely does Member Services work with the digital teams on the 2028 target?" | It connects the JD's self-service line to the strategy brief |
| "What would a good first six months look like in this role?" | Gives you the manager's actual priorities |
| "With small-business lending launching in Q1 2027, how ready is the complaints process for a new product?" | Shows you read the brief and are thinking ahead about the process you'd own |

---

# Round 3: Panel, two branch managers, 60 minutes (the values round)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One story prompt per value | High. The recruiter said the panel scores against the four values | Use the values cheat sheet. Name each value by its official name |
| Case / Strategist | The 20-minute escalation case | High. The recruiter announced it | Use the case build above: clarify first, then the structure |
| Peer Evaluator | "What would you need from us?" and how you'd handle disagreements | Medium. The panel are branch managers, and the JD puts the complaints process in their branches and has you coaching branch supervisors | Talk about what you'd bring them, not only what you'd need. Propose principles; don't claim to know how their branches work |
| Pressure, light | Pushing back inside the case | Medium. Twenty minutes is time-boxed, and a panel can play devil's advocate | Pause, restate, and hold your position through two follow-ups |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's point of view | Selection scaffold drawing on F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script.": pick a complaint where you chose the member's side over the branch's convenience. If none comes to mind, say so plainly and give how you would decide | P1 |
| Plain Words | If it needs explaining twice, the writing was wrong | Draws on F4, "I handled the branch's formal complaints log and trained new tellers on our escalation script.": answer slot, if you changed how you explained the script so new tellers got it first time, say how; if not, say so and pick another instance | P2 |
| Neighbours, Not Numbers | Every branch belongs to its town | Selection scaffold drawing on F6, "6 years in retail banking, the last 3 as a branch supervisor.": pick a time your branch's local relationships shaped how you treated a member. If none comes to mind, say so plainly and give how you would act | P3 |
| Own the Fix | Whoever finds a problem keeps it until it's solved | Draws on F3, "I built the monthly complaints spreadsheet our regional manager uses.": answer slot, if you built it because you spotted something nobody was tracking, that's your story; if you were asked to build it, say so plainly and pick another instance | P4 |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you decided something from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: from your time handling the branch's formal complaints log, it needs a member, a choice that cost the branch something (time, effort, a rule bent within policy), and your decision. Tell it in your own words, including how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | Members First, Always, with the prompt built on the value's own phrase. VAL because the panel scores this value |
| P2 | "When did you explain something so that a member or a colleague got it the first time?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from your sentence: you trained new tellers on your escalation script. Answer slot: if you changed how you explained it so they understood it first time, say what you changed and how you could tell it worked, in your own words. If not, say so plainly and pick another time you explained something to a member | Plain Words. VAL; your nearest sentence is the training in F4 |
| P3 | "Tell me about a time your branch's place in its town shaped how you handled a member." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: it needs a local relationship (a member known to the branch, a local business, a community event) and a decision of yours that it shaped. If no such time comes to mind, say so plainly, then say how you would weigh it | Neighbours, Not Numbers. VAL; it's especially live with branch managers during a consolidation year |
| P4 | "Tell me about a problem you found that wasn't strictly yours, and you kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet started because you spotted a gap, tell that: what you noticed, what you built, who uses it, in your own words. If you were asked to build it, say so plainly and pick another problem you found. It needs something you noticed, something you did, and it being solved | Own the Fix, with the prompt built on the value's own words. VAL; F3 is the nearest sentence |
| P5 | The case: "A member's complaint has bounced between a branch and the contact centre for three weeks, and they've now written to the CEO. Walk us through it." | CASE | [generic] | Use the case build: clarify (what the member wants, who holds it, how long it's been open, any regulatory deadline), member first, one owner, find the cause, fix and report, then close on the values. Ask how the contact centre handles it; don't assume | The recruiter announced a complaint-escalation case. The scenario is illustrative; the real one may differ. CASE |
| P6 | Pushback in the case: "The branch manager says the member's being unreasonable and wants it closed. What do you do?" | CASE | [generic] | Hold, then concede. Hold: you'd look at the complaint on its merits before closing it (Members First, Always). Concede specifically: the manager may know the member's history, so you'd ask. Don't fold to restore harmony, and don't criticise the manager | Branch managers will test whether you'll stand firm with them. CASE delivery, with VAL scored |
| P7 | "You'd be coaching supervisors in our branches. What would you need from us, and what happens when we disagree about whether something should have been escalated?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Lead with what you'd bring them: you know the supervisor's seat, because you've been a branch supervisor for the last three years. Then a principle for disagreements: agree the threshold in plain words up front, review real cases together, and let the member's outcome decide. Ask how escalation works in their branches now; don't claim to know | The JD's coaching line, from the peer side. CASE because it's a live working-relationship problem |
| P8 | "Eight branches are becoming five hubs over 2027. How do you handle complaints well through that, and keep 'Neighbours, Not Numbers'?" | CO | [grounded] | Structure: expect consolidation-related complaints and plan for them; brief branch teams on plain-language answers before members ask; track consolidation complaints as their own theme in the monthly report; protect the local relationship where a branch closes. Be sensitive: this affects the panel's own branches | The strategy brief's consolidation point against the published value. CO because it tests strategy fluency with people it affects |
| P9 | "A member tells you they're leaving for an app-only bank. What do you do?" | CASE | [grounded] | Structure: find out why first (a complaint, a feature, convenience), fix what can be fixed, explain plainly what Ashgrove offers, respect their choice, and record the reason as a theme for the report and the digital teams | The strategy brief names app-only banks as the main competitive pressure. CASE with CO content; Members First is scored |

## Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "When a complaint starts in your branch, which part of the current escalation path works least well for you?" | Peer framing; it shows you'll fix things with them, not to them |
| "What could a new Member Experience Lead do in their first month that would genuinely help your branches?" | A reciprocity question; it shows you're thinking about their load |
| "How are your teams preparing members for the move to hubs?" | It connects P8 to their own experience. Ask it with care |
| "Where do you see 'Neighbours, Not Numbers' working best in your branches today?" | Lets them talk about a value they're scoring you on |
| "How do you see the contact centre and the branches working together on complaints?" | It goes at your F2 gap through their eyes |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | R8, H1, H2, P5, P7 |
| Report monthly on complaint volumes and resolution times | H3, H4 |
| Coach branch supervisors on escalations | H6, H7, P7 |
| Work with digital teams on self-service journeys | H9, P9 |
| 4+ years in financial-services customer operations | R1 |
| Experience handling regulated complaints | R7, P5 |
| Confident presenting to senior leaders | H8 |
| Comfortable with Excel reporting | H3 |
| Four published values | P1, P2, P3, P4, with P5 and P6 scored on them too |
| Recruiter logistics: pay, notice, location, reason for leaving | R4, R5, R6, R3 |

---

## Claims this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process, or ran it across branches | Inflated form of F1 | F1's sentence at its own scope. Your material says the branch's log, not a process across branches. The F1 slot stays within the log |
| Contact-centre experience of any kind | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leadership or an executive team | A negative you stated, F8 | "I haven't presented above regional level." H8's slot asks only about regional level |
| Coached supervisors | Inflated form of F4 | F4's sentence at its own scope. Your material says you trained new tellers. H7 and P7 are plans, not past |
| Wrote or designed the escalation script | Inflated form of the sentence behind F1 and F4 | Your sentence says "our escalation script", which you trained tellers on |
| Built the regional complaints reporting, or reporting used across the region | Inflated form of F3 | F3's sentence at its own scope: you built the monthly complaints spreadsheet your regional manager uses |

---

## Sources

**Provided documents:**
- The JD, pasted by you.
- Ashgrove's values, which you copied on 26 November 2026 from ashgrovecu.org/about/values and pasted. It wasn't fetched again.
- The recruiter's email describing the three rounds on 5 December.
- Ashgrove's 2026 strategy brief (published July 2026, sent by the recruiter), as you summarised it.
- Your background, from your message.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values page you pasted this morning already fixes the cheat sheet and P1 to P4 |
| 2. Ashgrove interview process | skipped | The recruiter's email already fixes all three rounds and the persona weights |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 strategy brief (about four months old) already fixes the grounding brief and H9, P8 and P9 |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form. There is no interviewer read |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once the recruiter assigns them** → a read on each person, persona weights for each panel member, and a reverse question tied to each one's career.
- **Your answers to the answer slots** → F3 and F9 (what the spreadsheet tracked, and in which tool), F7 (whether the log was the regulated process) and F5 (any digital work) move from `discovery` to firm rows, and H3, R7 and H9 become story-mapped.
- **Your CV text** → more of your own sentences to draw on. The values stories P1 to P4 could move from selection scaffolds to mapped stories.
- **The full strategy brief text** → a richer grounding brief and sharper CO questions (H9, P8, P9).
- **How much prep time you have before 5 December** → a prioritised prep schedule.
- **Whether the case brief comes in advance** (one email to the recruiter) → the case build adjusts to the real scenario.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news, leadership context and any public candidate reports, which would feed the grounding brief and reverse questions.
- **A tuesday-dossier.md** → would carry verified evidence and agreed limits into this pack, so the highest-ROI objection would rest on checked evidence rather than this pack's own reading.
