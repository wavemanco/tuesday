Quick update: all six web searches were declined by permission, so I'm not retrying them. I'm building the pack from your message and the recruiter's email.
I've built your Tuesday prep pack. It covers the 15-minute POV, a 4-hour weekend plan and 23 practice questions split between Deepa and Ross, with answer guidance for each.

**What it's built on:** your message and the recruiter's email, and nothing else. The web searches on Kelverton, Deepa and Ross were declined, and I don't have the market report's contents. So the market points in the POV and the questions about Kelverton are general patterns. Your reading of the report fills them in.

**The POV:** I've set it up as 13 minutes spoken with 2 minutes spare. There are three options to choose two from, each with a downside you say out loud. I'd lead with "partner for what the operator gets, not for our pipeline" and "fewer, deeper partnerships", which includes the partners you'd say no to. A third option, tying partner pay to operators actually using the software, covers Ross's commercial angle. It ends on three changes operators would notice, which is what the recruiter asked for. On the report: agree with one point, go further than it on one, and don't read it back to the people who wrote it.

**The question most worth practising** is Ross saying you've never carried a direct quota, only influenced revenue. You said that yourself, so the answer starts by owning it. Then hold on "roughly £4M of influenced revenue" and say how you'd take on a number here, as a plan. The pack scripts both follow-ups. The other one to have ready is "how was the £4M counted?"

**Things the pack won't put in your mouth:** having carried a quota, having sold into rail, having "generated" or "closed" the £4M, knowing train operators (your words were bus and light rail, from the other side), or having founded the channel rather than run it.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/alone/part-2/rooms/case-5-denied-116ec73f:
- Kelverton-Rail_senior-partnerships-manager_interview_pack.md

Say the word and I'll play Ross on C1, the quota question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the JD and your CV? Either one turns the general role requirements into quoted ones, and "skip" is fine.

Do you want me to run the research? That's the standard 6 searches on Kelverton, Deepa and Ross, plus an optional deeper pass of up to 6 more searches and 2 page fetches, which takes several more minutes. Web search would need to be allowed for either.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes, Tuesday
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director
**Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."
**Built from:** your message and the recruiter's email. No JD, no CV, and the market report's contents aren't in hand. Web research was refused, so nothing in here about Kelverton comes from outside your message.

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what style. **Types** describe what is being scored.
- Type key:
  - **VAL**: behavioural or values alignment
  - **EXP**: work-experience deep-dive, meaning what you actually did
  - **JD**: can you do the listed job, gaps included
  - **CO**: company and market knowledge
  - **CASE**: a live problem, structured out loud
- Question IDs run by persona: A, B, C, D, E, G, H. **F** is skipped so the bank IDs don't clash with the fit-snapshot rows F1–F7.
- Provenance labels: `[grounded]` traces to something you or the recruiter wrote. `[inferred]` is derived, and the derivation is named. `[generic]` is a role-family pattern with no claim about Kelverton.
- **Answer slots** are instructions for the interview, not questions for you to answer here. Each has two honest branches, and both are good answers.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage: four hours over the weekend

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV. Pick two theses, write the operator close, then say it out loud twice against a 13-minute timer | Graded deliverable section |
| 2 | 45 min | Rehearse C1, the quota objection, out loud until it's boring, including both follow-ups. Then B1 and C2 on the £4M figure | C1, B1, C2 |
| 3 | 40 min | Ross's commercial bank: deal economics, the scorecard, and "what does it bring in" | B3, B4, C4 |
| 4 | 35 min | Deepa's skeptic bank: rail gap, the bus and light rail bridge, payments to rail | D1, D2, D3 |
| 5 | 20 min | Pick three reverse questions, one for each panellist and one for both | Reverse questions |
| 6 | 10 min | Reread the prohibited list, then close the laptop | Prohibited claims |

Everything else in this pack is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material shows a payments ISV channel you ran and grew. It says nothing about rail operator partnerships, so the words stay at that scope: "I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the 18-month framing makes a probe on how you'd sequence a partner programme likely. If the plan behind the 6-to-40 growth was yours to set, say what you sequenced and why, in your own words. If it was set by others, or there was no plan as such, say so plainly and stay with running the channel |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Bus and light rail network planning, seen from the other side, is next to train operators, not the same thing. The words stay there: "I spent five years in transport consulting on bus and light rail network planning, so I know the operator world from the other side." Answer slot: the recruiter's operator close makes a probe likely on which operator problems you saw first-hand. If you worked alongside operator teams, say on what, in your own words. If your counterparts were not operators, say who they were and stay with network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is roughly £4M, and it is influenced revenue. Keep both words. Your material doesn't show what commercial terms sat behind it. Answer slots the figure raises: how it was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours, each in your own words. "I don't know exactly how it was counted" is an honest branch. Separately, Ross's commercial push makes a probe on partner deal terms likely. If you set or negotiated partner economics, say how. If they were set by others or didn't exist, say so plainly and return to the influenced figure |
| F4 | Direct revenue accountability, since senior partnerships roles often carry a partner-sourced target (role-family pattern, not from a Kelverton source) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You've stated this gap yourself, and wording can't close it. Words: "I've never carried a direct quota — my number was influenced revenue." Then say how you'd take on a number here, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F5 | Experience selling to rail buyers, since the company sells to train operating companies (role-family expectation, not from a Kelverton source) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never sold into rail specifically." Then F2's adjacency, kept at its own scope, plus a ramp plan said as a plan |
| F6 | Building and scaling a partner ecosystem (role-family pattern) | "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap at this level, but the line is self-reported with nothing inspected behind it, so expect a probe (B2). Lead with the line in its own terms: you ran the ISV channel and took it from 6 partners to 40 |
| F7 | Credibility with senior operator and partner leaders (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a named senior counterpart, a decision you shifted, or a relationship you kept under strain. Selection scaffold: pick a time from either of your two careers when you had to win over someone senior on the other side of a deal or project. If none comes to mind, say so plainly and give the nearest thing your material does carry |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| F1 the 18-month POV | Graded deliverable, A1, A2, A3 |
| F2 what it means for operators | Graded deliverable close, A5, D2, H2 |
| F3 commercials | B1, B3, B4, C2, C4 |
| F4 direct revenue accountability | C1, B4 |
| F5 rail selling | C3, D1, D3 |
| F6 partner ecosystem | B2, E1 |
| F7 senior credibility | G2, H1 |
| Company and market knowledge | A4, E2. Generic only, because the research was refused and the report's contents aren't in hand |

---

## Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Facts about you to build on, each at its own scope:**
- F1: "running the ISV channel — took it from 6 partners to 40"
- F2: "bus and light rail network planning, so I know the operator world from the other side"
- F3: "roughly £4M of influenced revenue"

Use one of these as a single credibility sentence near the start. Don't build a section around your past. The panel asked where you'd take *their* partnerships.

**The market report.** Its contents aren't in this pack, so nothing here is grounded in it. Your own reading of it supplies the market facts. It was circulated internally, so treat it as something the panel already knows. Bring **one** point from it you agree with, to show you did the reading, and **one** place you'd go further or differently, with your reason. Reading the report back to its own authors scores as homework. Departing from it with reasons scores as judgment.

**Running order, 13 minutes spoken with about 2 minutes spare**

| Minutes | Beat | Provenance |
|---|---|---|
| 0:00–1:30 | Headline: the operator problem you'd organise partnerships around, in one sentence, then your two theses in one sentence each | [generic] |
| 1:30–4:00 | Diagnosis: what the partner programme should do for an operator that Kelverton can't do alone. Take the report's own framing of operator pain, plus your one divergence | [generic] |
| 4:00–10:00 | The 18 months: three phases, laid out below | [generic] |
| 10:00–12:00 | Commercials, said for Ross: how partnerships make money for Kelverton, and the two or three numbers you'd report | [generic] |
| 12:00–13:30 | Close: what it means for operators, stated as outcomes they would notice | [generic] |

**Thesis options.** Pick two. Each one has a concession you say out loud.

| Thesis | What it argues | Mandatory concession | Provenance |
|---|---|---|---|
| T1: Partner for the operator's outcome, not for our pipeline | Prioritise the partners whose products sit next to scheduling in an operator's working day, meaning the systems that feed a schedule or consume one, so the joins between systems stop being the operator's problem. Check which systems those are against the report | Pipeline from these partnerships is slower in the first 6–9 months, and you'd say so before Ross asks | [generic] |
| T2: Fewer, deeper partnerships | Tier the partners. A small set get a joint roadmap and co-selling, and the long tail gets a light, self-serve programme. **The anti-pick:** say no to partners who want a logo swap or a referral fee with no delivery commitment | Coverage gaps: some operators will want a partner you've deprioritised | [generic] |
| T3: Tie partner commercials to operator adoption | Partner economics weighted toward deployment and use, not only toward a signed deal. This is your bridge into Ross's half | Harder to measure, and partners may resist. You'd pilot it with one or two partners before rolling it out | [generic] |

The suggested pairing is T1 + T2 as the spine, with T3 as the commercials section. A likely consensus answer is "more partners, more integrations." T2 goes against it.

Answer slot on your own history: a panel may connect T2 to your 6-to-40 growth. If that growth taught you something about breadth versus depth, say what, in your own words. If it didn't, don't connect the two. Let T2 stand on its own reasoning.

**The 18 months**

| Phase | Months | What happens | Provenance |
|---|---|---|---|
| Listen | 0–3 | Talk to operators about where partners help and where they get in the way. Audit current partners against T1 and T2. Agree the scorecard with Deepa and Ross | [generic] |
| Prove | 3–9 | Two deep partnerships with one or two operators each. Pilot the T3 commercial terms with one partner | [generic] |
| Scale | 9–18 | Roll out the tiering. Publish the self-serve programme. Report partner-influenced and partner-sourced numbers separately | [generic] |

**The close the recruiter asked for: what it means for operators.** Three outcomes, each something an operator would notice. Check each against the report's reading of operator pain before you use it.

| Operator outcome | Provenance |
|---|---|
| Fewer suppliers they have to integrate themselves | [generic] |
| One accountable answer when schedule data crosses systems | [generic] |
| Partners who are paid when the operator actually uses what was sold, not only when it's signed | [generic] |

**Don't:**
- present the report back to the panel
- invent market figures
- say anything about rail that you'd need the report to back up, unless the report does back it up

---

## Persona table

The recruiter's email establishes this session: one panel, a presentation, then Q&A with a named commercial push. No values round is named, so there's no values cheat sheet.

| Persona | Who, and how it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa: "why that order?", "what would you cut?" during and after the POV | High. She's your future manager, and the POV is her brief | Clarify, state the objective, structure, then risks. Challenge one premise respectfully |
| Data-Driven Prober | Ross: denominators on the £4M and the 6-to-40 | High. "Ross will push on commercials" names it | Know what you can and can't say about how each number was counted. Name your weakest assumption first |
| Pressure | Ross: interruptions, "so what's the number?" | High. A commercial director told to push will push | Pause, restate, hold through two follow-ups, then concede the specific thing only |
| Skeptic | Deepa: the rail gap and the quota gap, asked quietly | Medium-high. She has to defend this hire | Rehearse C1 and D1 until they're boring. Bridge only from what you stated |
| Conversational | Either: the opener and the wind-down | Medium. A 60-minute panel usually spends a few minutes on it | A 90-second arc, rehearsed |
| Peer Evaluator | Deepa, on how you'd work with direct sales | Low-medium | Propose principles for the seam rather than pretending to know where it sits |
| Values / Behavioral | Either, briefly | Low. No values round is named | Two selection scaffolds ready |

---

## Question banks

### A. Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "running the ISV channel — took it from 6 partners to 40" | This is the POV, so use the running order in the graded deliverable section. One credibility sentence from your quote, at its scope: you ran the ISV channel and took it from 6 partners to 40. Then the headline, two theses, three phases, commercials, and the operator close. Stop at 13 minutes | The recruiter pre-declared this. It's the most heavily weighted 15 minutes of the hour. CASE because it is scored on structure |
| A2 | "If you could only fund three partnerships in year one, which kinds and why?" | CASE | [generic] | Name kinds of partner, not companies, unless the report names them. Rank them by what an operator would notice (T1). State what you'd stop doing to fund them | A natural follow-up that tests prioritisation. Generic because the research was refused |
| A3 | "Which partners would you say no to?" | CASE | [generic] | The T2 anti-pick: partners with no delivery commitment. Then say how you'd tell them no without burning the relationship, as a plan | The role's real job includes saying no, and saying it shows judgment |
| A4 | "What did you take from the market report, and where would you push back?" | CO | [generic] | One point you agree with, in the report's own terms, then one divergence with your reason. Don't recite it. If you have no divergence, say what you'd want to test first | The panel knows the report, so this is the cheapest way to check whether you think or just repeat. CO because it checks how you read their market |
| A5 | "What do train operators actually need from our partners?" | CASE | [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Structure it by operator outcome, using the close's three lines. Bridge from your quote at its scope: bus and light rail network planning, from the other side. Answer slot: if you saw operator problems first-hand in that work, name one in your own words. If your counterparts weren't operators, say who they were and stay with planning. Never "I know train operators" | F2 is the bridge the recruiter's operator close leans on. CASE content, delivered with a light EXP touch |

### B. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say "roughly" and "influenced" every time. Answer slots, each in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least (name that one before Ross does), and which part was yours. If you don't know exactly how it was counted, say so plainly. That beats a method you can't repeat under a second question | F3 is the headline number, and a commercial director will price it. EXP because it tests attribution |
| B2 | "Six to forty partners. How many of the forty actually produced revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know the split, give it and say how you know. If you don't, say so plainly and say what you'd measure here instead. Don't estimate a split on the spot | F6 is self-reported. A partner count invites a "how many are real" question |
| B3 | "A partner brings us into an operator deal. How would you structure the economics?" | CASE | [generic] | Structure: who sourced the deal, who delivers, who supports it afterwards, and how the split follows that work. Name the tension, which is partner margin against Kelverton's price to the operator. T3's adoption weighting is your differentiator. Make no claim about terms you've set unless F3's slot is answered yes | Ross's commercial push lands here. It's a live problem, so no claim about your past is needed |
| B4 | "What would you put on the partnerships scorecard I see each quarter?" | CASE | [generic] | Three to four numbers: partner-sourced revenue and partner-influenced revenue shown separately, deployments live through partners, and one leading indicator. Name which one you'd trust least and why | It tests whether you separate influenced from sourced. That matters given F4 |

### C. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a direct quota, only influenced revenue. Why would I give you a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Open with the acknowledgment, unprompted and without apology: "I've never carried a direct quota — my number was influenced revenue." Hold on only what your quotes carry: roughly £4M of influenced revenue. Answer slot: if any part of how that figure was tracked or reviewed looked like a target, say what, in your own words. If nothing did, say so plainly. Then move forward, as a plan and never as a past: how you'd want the number framed here, and what you'd need in the first 90 days to own it. **Follow-up 1,** "influenced is soft": hold. Repeat the figure at its scope and agree that influenced and sourced are counted differently. **Follow-up 2,** "so you've never been accountable": concede the specific thing, no direct quota, and nothing wider. Don't fold into "maybe I'm not the fit" | F4 is the most predictable objection to you. You stated the gap yourself, and Ross is set up to find it. JD because it scores a stated requirement of the role, delivered as pressure |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say which part was yours, in your own words. If it's hard to separate, say that plainly, and say what you did in the channel that the figure counts. Never round up | Attribution is the classic pressure probe on a headline number (F3) |
| C3 | "Sixty seconds: why you over someone who's sold to train operators for ten years?" | JD | [grounded] "Never sold into rail specifically"; "bus and light rail network planning, so I know the operator world from the other side"; "took it from 6 partners to 40" | First 10 seconds: "I've never sold into rail specifically." Then the two things your quotes carry: you know the operator world from the other side, through bus and light rail network planning, and you ran an ISV channel from 6 partners to 40. Say what you'd do differently with that mix, as a plan. Stop at 60 seconds | It combines F5 and F2. The timebox tests composure |
| C4 | "Nice POV. What does it bring in, in pounds, over 18 months?" | CASE | [generic] | Don't invent a figure. Give the model: number of deep partnerships × deals per partner × deal size, phased by your 18 months, and say which input you'd need their data for. If the report has a figure you'd anchor on, cite it as theirs | It forces a number. An invented number is worse than a clear model |

### D. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never sold into rail. What will you get wrong in your first three months?" | JD | [grounded] "Never sold into rail specifically" | Accept the premise; it's yours. Name one or two specific risks, for example misreading how operators buy or who signs, then the ramp plan, as a plan: who you'd talk to first and what you'd read. Don't pad it with consulting credentials | F5 is the gap Deepa owns if she hires you. Calibrated candour beats bluffing in front of the VP who knows this market |
| D2 | "How does bus and light rail network planning help you with train operators?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your words, at their scope: bus and light rail network planning, from the other side. Answer slot: if a specific part of that work carries over to train operators, name it in your own words. If you're not sure it carries over, say what carries over (the operator world from the other side) and what doesn't | F2's bridge will be tested. Keep it adjacent, not identical |
| D3 | "Payments partners and rail partners are very different. What carries over?" | JD | [grounded] "running the ISV channel — took it from 6 partners to 40" | Split it. What carries over is running a channel and growing it, at your quote's scope. What doesn't is the buyer, the sales cycle and the sector. Say the second half before she does | It tests whether F1 transfers or merely sounds like it does |
| D4 | "Why leave payments for rail, and why now?" | EXP | [generic] | Give your actual reason, in your own words. Your material doesn't state one, so the pack supplies none. Keep it about pull towards this role rather than push away from the last | Motivation consistency is the Skeptic's standard probe |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey." | EXP | [grounded] "9 years in partnerships"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc in order: consulting on bus and light rail network planning, then running the ISV channel at a payments company (6 to 40 partners, roughly £4M influenced), then why this role brings the two together. That last part is yours to say, in your own words | The likely opener. Casual in tone, but still scored |
| E2 | "What drew you to Kelverton specifically?" | CO | [generic] | Your own reason, in your own words, with one specific thing from the report or the recruiter's brief. The pack has no researched Kelverton facts to offer | A homework check. Generic because the research was refused |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our direct team owns operator relationships. Where's the seam with partnerships?" | CASE | [generic] | Propose principles: who owns the operator relationship, when a partner leads, how credit is split, and how disagreements get escalated. Ask how it works today before fixing it | Partnerships roles live at this seam. A principles answer beats a guess |
| G2 | "Tell us about a time a partner and a direct seller wanted the same deal." | EXP | [generic] | Selection scaffold: pick a real case of a credit or ownership clash. It needs what you did and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then say how you'd handle it | A credit-sharing probe. Open prompt, so you choose the instance |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told a partner something they didn't want to hear." | VAL | [generic] | Selection scaffold: a named partner, the hard message, and whether it actually landed. If no such time comes to mind, say so plainly and give the nearest thing you do have | Covers F7. Low weight, but have one ready |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a real trade-off with a cost you accepted. It echoes the POV's operator close. If none comes to mind, say so plainly and say how you'd choose | It ties the "what it means for operators" brief to how you've behaved |

---

## Reverse questions

| For | Question | Why it lands |
|---|---|---|
| Deepa | "At 6 and 18 months, how would you judge this role, and is the number sourced, influenced, or both?" | It raises the quota question on your terms and tells you how to calibrate C1 |
| Ross | "How do partner-led deals show up in your commercial numbers today?" | It speaks his language and shows you'd report into his view |
| Deepa | "Which current operator partnership would you most like to change, and why?" | It turns the POV into a working conversation about her actual problem |
| Both | "Where in the market report do the two of you read things differently?" | It invites them to debate in front of you, and it shows you read the report as a starting point |
| Both | "What do operators complain about most when partners come up?" | It ties back to your operator close and gives you material for the first 90 days |
| Deepa | "Where does partnerships end and direct sales begin today?" | It shows you'll manage the seam rather than fight over it |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or owned a revenue target | A negative you stated, F4 | "I've never carried a direct quota — my number was influenced revenue." No slot |
| Has sold into rail | A negative you stated, F5 | "I've never sold into rail specifically." No slot |
| Generated, closed or sourced £4M | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. Your material says influenced and roughly, and both words stay. B1 and C2's slots stay inside that figure |
| Knows train operators, or has heavy-rail operator experience | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, knowing the operator world from the other side. Your material says bus and light rail, from the other side. A5 and D2's slots stay inside that work |
| Built or founded the ISV channel | Inflated form of F1 | F1's quote at its own scope: running the ISV channel, taking it from 6 partners to 40. Your material says running, plus the growth. F1's slot stays inside the 6-to-40 growth |

---

## Sources

**Provided:**
- Your message, including the recruiter's email quoted in it.

**Not in hand:**
- The market report. You've read it, but its contents weren't shared, so nothing in the pack is grounded in it.

**Searches sent, all refused by permission:**
1. "Kelverton Rail values": refused
2. "Kelverton Rail interview process partnerships": refused
3. "Kelverton Rail scheduling software train operating companies news 2026": refused
4. "Deepa VP Partnerships Kelverton Rail": refused
5. "Ross Commercial Director Kelverton Rail": refused
6. "Senior Partnerships Manager" rail software train operating companies job description: refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have themed the H bank on Kelverton's published values |
| 2. `Kelverton Rail interview process` | unavailable | The search was refused. The recruiter's email already establishes this session, so the persona weights stand on it |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused. It would have grounded A4, C4, E2 and the POV theses in Kelverton's public moves |
| 4. `Deepa / Ross Kelverton Rail` | unavailable | Both searches were refused. They would have supplied an interviewer read and a reverse question tied to each panellist's path |
| 5. representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have turned F4–F7 from generic prose into quoted, inferred requirements |

---

## Upgrade menu

- **The JD text** → F4–F7 become quoted requirements, `[generic]` rows become `[grounded]`, and the coverage table is checked against the JD's own list.
- **Your CV** → F6 and F7 gain dated lines, and the D and E guidance can map to named stories instead of scaffolds.
- **The market report's headline points, pasted (just the parts you'd cite)** → the POV theses, A4, C4 and the operator close rest on Kelverton's own framing instead of on generic patterns.
- **Web search allowed** → targets 1–5 run: values for the H bank, recent news for the CO questions, Deepa's and Ross's public professional profiles for a panel read, and a representative JD.
- **Your answers to the answer slots in F1, F2 and F3, told here outside a drill** → they enter the snapshot, and A5, B1, B3, C1, C2 and D2 regenerate.
- **A `tuesday-dossier.md`** → verified evidence, an evidence-derived objection and a stricter prohibited list. It's useful but never required.
