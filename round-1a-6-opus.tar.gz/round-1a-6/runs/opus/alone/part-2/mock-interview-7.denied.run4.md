Web searches were refused, so I'm building the pack from your message alone and recording what the missing research would have changed.
Femi, your prep pack is saved as `Saltmarsh-Games_live-operations-producer_interview_pack.md`. I wrote it for a hiring-manager round, because you didn't say whether Tobias is the person this role reports to. My web searches were blocked, so nothing in it comes from Saltmarsh's website or from Tobias's public profile. It's built only from the job description and background you sent me.

If you'd like, I'll play Tobias and ask you B1, the "have you led a team?" question. The pack marks it as the most important one to practise.
I can also save a `tuesday-dossier.md` file listing the gaps this prep turned up, so you can bring it to later sessions.
I can convert the pack to a Word document too.

Is Tobias the hiring manager for this role? And did the recruiter say what the hour will cover, or ask you to prepare anything? Either answer changes how I'd weight the questions.
Do you want me to try the research again? You'd need to approve web search when it asks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interview:** 60 minutes, Friday, with Tobias Wrenfield, Head of Live Operations
**Relationship assumed:** hiring manager. You didn't say who the role reports to. The head of the function interviewing for a producer in that function usually means a hiring-manager round, but that's an assumption, not something I know.
**Research:** none. Every web search was refused, so nothing here is drawn from Saltmarsh's website, values, interview process or Tobias's public profile. See Sources.

---

## How to use this pack

- **Personas** describe how a question is asked: the interviewer's style and register. **Types** describe what is being scored.
- Type key:
  - **JD**: the job as listed. Can you do the stated work, including the gaps?
  - **EXP**: deep-dive on your experience. Do your claims hold up, and what was actually yours?
  - **CASE**: a live problem from the role. Is your reasoning structured?
  - **VAL**: behavioural. Do your past actions show how you work?
  - **CO**: company knowledge. Have you done your homework on this studio and its games?
- Provenance labels: **[grounded]** means it traces to your message or the JD you pasted. **[inferred]** means it's a derivation, and the row names what it's derived from. **[generic]** means a role-family pattern that makes no claim about you or Saltmarsh.
- An **answer slot** is an instruction for the interview, not a question for me. It has two honest branches, and either one is a good answer.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage: one evening before Friday

This assumes the interview is tomorrow and you have one evening.

1. **B1 out loud, three times.** This is the highest-ROI prep in the pack. Get the plain acknowledgment and the move to what you did ran until they feel boring.
2. **B4 out loud twice.** It's the in-app-purchases question. Have the acknowledgment and the learning plan ready.
3. **D1:** time your 90-second "journey" answer.
4. **A1 and A4:** sketch the structure for each on paper, one page apiece. Don't write a script.
5. **C1:** before the interview, write down which retention measures you presented and how they were counted, or note that you don't know.
6. **Play both Saltmarsh titles tonight,** if you can find which two the role covers. Note one current event in each. Research couldn't run, so this is your only source for D2 and the CASE questions.
7. **Pick three reverse questions.**

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one calendar of weekly content drops for one title. It doesn't say live events or two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "plan and run" makes a probe on how the calendar's contents were decided likely. If deciding what went into it was yours, say how, in your own words. If that wasn't your step, or there was no such step, say so plainly and stay with running the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | You stated a negative about leading, not about coordinating, and the pack keeps the two apart. Words for leading: "I haven't led a team." Answer slot: if running the calendar meant working with design, art, engineering or community to hit drop dates, say which disciplines and what you did with them, in your own words. If it didn't, say so plainly, then say how you'd approach it here, as a plan and never as a past |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting monthly numbers. It doesn't say reviewing events or owning KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you compiled or analysed those numbers, or ever reviewed how a specific drop performed, say what you did, in your own words. If the numbers came from someone else, or there was no per-drop review, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: "I wrote the release checklist our QA team still uses." It's a named document that's still in use, and nothing has been inspected behind it yet, so expect a probe on what's in it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Words at their own scope: "Four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Keep "associate" in. Answer slot: the JD's "live-service" makes a probe on how the title was run after launch likely. Describe it in your own words. If it wasn't a live service in the sense they mean, say so plainly and stay with the weekly drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but it's a statement with nothing inspected behind it, so expect a probe. Lead with it as written: weekly, the main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in what you said, but expect C1's probe on which measures they were and how they were counted. Answer it in your own words, and if you don't know how a figure was counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [inferred] | discovery | A checklist QA still uses is written work, but it doesn't show the range of writing the JD means: briefs, review write-ups, update notes. Answer slot: if you wrote other documents teams relied on, name one and what it was for, in your own words. If not, say so plainly and stay with the checklist |
| F9 | Live-event KPIs on mobile titles commonly include in-app spend; the JD doesn't say whether Saltmarsh's do | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | You stated this gap and wording can't close it. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan and never as a past. Nothing added to make the gap feel smaller |

---

## Persona table

The loop as your message gives it: one 60-minute session with Tobias Wrenfield, Head of Live Operations. Nothing in your material documents a values round, so the pack has no values cheat sheet.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Plan next quarter's events," "this event is underperforming," "draft a review" | High. The hiring-manager prior is Case plus Skeptic, and every JD line is operational work that can be asked as a live problem | Clarify, then objective, then structure, then risks, then metrics. Think aloud. Challenge one premise per case |
| Skeptic | Quiet probing of the gaps: team leadership, two titles, in-app purchases, owning KPIs | High. Same prior, and your F2, F3 and F9 rows are where the JD is thinnest for you | Rehearse B1 until it's boring. Bridge only from what you stated, plus a concrete ramp plan |
| Data-Driven Prober | "Which retention metrics, and how were they counted?" | Medium. The JD names retention metrics and KPIs, and F3 and F7 rest on one line about presenting numbers | Know what you can and can't say about how each figure was counted. Say plainly when you don't know |
| Conversational | The opener, "why live ops," "why us" | Medium. A 60-minute slot almost always opens casually, and casual answers are still scored, including on the JD's written-communication line | A rehearsed 90-second arc (D1). Treat every casual question as scored |
| Pressure | Time-boxed "why you, now" and launch-day incident questions | Low. No signal points to a stress interview, but live ops is incident-heavy work, so expect at least one fast question | Pause, restate the question, answer from what you stated, and hold through two follow-ups |
| Values / Behavioural | "Tell me about a time…" | Low. No values round is documented, but behavioural prompts show up in most hiring-manager hours | Selection scaffolds below. Use "we" for context and "I" for your part |
| Peer Evaluator | Cross-team friction between community, design and engineering | Low. The interviewer isn't a peer, but the JD's coordination line invites seam questions | Talk in seam principles and reciprocity. Don't pretend you already know their seams |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We have two titles and one live-events calendar for next quarter. How would you build it, and what do you need to know first?" | CASE | [generic] | Clarify first: each title's audience and current event cadence, which teams are shared across the two titles, fixed dates, and each title's KPI goal for the quarter. Then the structure: one view of both calendars, collisions on shared teams flagged, lock dates per discipline working back from each go-live, QA windows protected, and a buffer. Close with how you'd know it worked. This question needs no claim about your past, so the guidance makes none | The JD's first line, asked as a live problem. CASE because it scores structure. It also tests the two-title scope that F1 doesn't reach |
| A2 | "An event's art slips a week. It goes live in ten days on one title, and the other title's update needs the same engineers. What do you do?" | CASE | [generic] | Find out first: how firm the slip is and what's actually blocked. Then the options: cut scope, swap the event order, move the date, or rebalance shared engineering, each with its cost to each title. Say who you'd involve and when, and what you'd write down for everyone afterwards | Tests coordination under a dependency clash across two titles. Pressure on F2's requirement without asking about your past |
| A3 | "Day two of a live event, retention in the event's target group is below what we planned. Diagnose it." | CASE | [generic] | Clarify the definition and the baseline it's being compared with. Rule out tracking or build problems first. Segment: new versus returning players, platform, app version. Then check event design: difficulty, reward value, how players find the event. Then decide what you can change mid-event and what waits for the review | The JD's retention line asked as a live metric problem. Your F7 evidence is presenting numbers, so this checks that you can reason with them |
| A4 | "Outline a post-event review for me. What's in it, and who reads it?" | CASE | [generic] | Sections: the event's goal, KPIs against target, what shipped versus what was planned, live issues and QA findings, player and community feedback, and decisions with owners and dates. Then readers: Tobias, the discipline leads, community. Keep it short enough that people actually read it | The JD's "own the post-event review" plus its written-communication line. F3 doesn't reach review ownership, so rehearse the structure. CASE content, JD scoring |
| A5 | "Design wants a new event mechanic in the next update. QA says the release window is already full. How do you decide?" | CASE | [generic] | Clarify what the mechanic is for and what it would push out. Lay out the options: defer, ship a smaller version, or extend the window, each with its risk to quality and to the calendar. Say whose call it is and how you'd make the trade-off visible to both sides | The coordination and QA-checklist lines of the JD in conflict. Tests whether you protect the release process |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update. Have you led a team? How would you get four disciplines to a date when none of them report to you?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment and no softener: "I haven't led a team." Don't say "not formally" or "informally": both imply leadership you didn't describe. Then what your material does carry: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if running it meant working with any of those disciplines to hit drop dates, say which and what you did, in your own words. If it didn't, say so plainly. Then a plan, said as a plan: meet each lead in the first weeks, agree lock dates and how slips are flagged, and keep one shared calendar view. Hold through two follow-ups by coming back to the calendar you ran, never by adding to it. If pressed, concede specifically: "Coordinating four disciplines across two titles would be new at this scale for me." | F2 is where the JD's coordination line presses hardest, and you stated the leadership negative yourself, so some form of this will come. JD because it scores a stated responsibility |
| B2 | "We run two titles. You ran the calendar for one. What changes when it's two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote's scope: one title, weekly drops, two years. Answer slot: if you worked on the studio's other titles in any way, say how, in your own words. If you didn't, say so plainly. Then reason about what changes: shared teams, collision checks, prioritising when both titles want the same week, and one review rhythm. Don't claim two-title experience | F1's transferability gap, asked straight. JD because the "two titles" scope is stated |
| B3 | "Our producer owns the post-event review and its KPIs. Those retention numbers you presented: were they your analysis or someone else's?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you pulled, built or analysed the numbers, say how, in your own words. If someone else prepared them, say so plainly. Presenting them monthly is still yours. Don't call it "owning retention" | F3's gap. An attribution probe because "presented" is a verb a prober will test. EXP content, JD pressure |
| B4 | "Have you worked on a game with in-app purchases? How would you get up to speed if our event KPIs include revenue?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment first: "I haven't worked on a game with in-app purchases." Then a learning plan, as a plan: how each title makes money, which event KPIs track spend, who owns monetisation design, and reading past post-event reviews. Ask how their reviews weigh revenue against retention, since that also tells you how much this gap matters to them. Hold through follow-ups. Don't call retention work "basically the same" as revenue work | F9 is a gap you stated. Most mobile games monetise, so expect it. The second-deepest rehearsal. JD because it bears on "the KPIs it reports" |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; "Never led a team" | Pick one gap and name it in plain words: "I haven't worked on a game with in-app purchases" or "I haven't led a team." Then give a concrete ramp plan for it. Don't pick a fake weakness. This interviewer can check it against everything else you say | A standard Skeptic stem. It rewards the same candour B1 and B4 rehearse |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through those monthly retention numbers. Which measures, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slots, each in your own words: which retention measures you presented, how each was counted, what moves them, the assumption behind them you'd defend least, and which part of the work was yours. "I don't know how that was counted" is an honest answer, and a better one than a guess. The pack supplies no metric names or methods. Use only what you actually know | F7's only evidence is one presenting line. Retention metrics are named in the JD, so this probe is near-certain |
| C2 | "Walk me through the release checklist you wrote. What's on it, and why?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Describe what's on it and why each part is there, in your own words. Answer slot: the JD's "manage the release checklist with QA" makes a probe on running it each release likely. If you ran it with QA on releases, say how. If QA ran it without you, or there was no per-release step, say so plainly and stay with having written it and QA still using it | F4 is your most concrete piece of evidence, so make it specific. EXP because it tests what was yours |
| C3 | "How did you know whether a weekly drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: the JD's post-event-review line raises this. If you looked at how drops performed after they shipped, say what you looked at, in your own words. If there was no such step, or it wasn't yours, say so plainly and say what you'd measure first for an event here | It links F1 to F3: the calendar and the review. A prober will try to join them |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in four beats, each one a sentence you stated: four years as an associate producer at a puzzle-game studio; for the last two, you ran the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. Close with an answer slot: why this role, now, in your own words. Keep "associate" in | The opener is near-certain and scored on economy. That matters more here because the JD names written and clear communication |
| D2 | "Why live ops, and why Saltmarsh?" | CO | [generic] | Answer slot for "why live ops": your own reason. For "why Saltmarsh": research couldn't run, so play the two titles tonight and name one thing you noticed about a current event in each. Don't invent facts about the studio | The CO question this pack can't ground. Your own play session is the honest substitute |
| D3 | "On an update, how do you keep design, art, engineering, community and QA in the loop? What do you write, and when?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Answer slot: if you wrote briefs, status notes or similar for the drops, describe one and who read it, in your own words. If you didn't, say so plainly and stay with the checklist: "I wrote the release checklist our QA team still uses." Then say what you'd send here and when, as a plan | Covers the JD's written-communication line, and F8 is a discovery gap. Asked casually but scored |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The JD says three-plus years producing live-service games, and your title is associate producer. Sixty seconds: why are you ready for this now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Pause first. Hold with the quotes: four years as an associate producer, and for the last two, running the weekly content-drop calendar for the main title. Answer slot: why now, in your own words. Don't recast the title ("I was effectively a producer"). If pressed, concede specifically, naming B5's gap, without folding on the four years | F5 is a discovery gap on "live-service," and the title is visible. A time-boxed format tests composure |
| E2 | "Thirty seconds: an event's broken in production on launch day. What are your first three calls?" | CASE | [generic] | Three beats: get the right engineer and QA on it and confirm how big the problem is; decide whether to pull, pause or patch the event, and who makes that call; get community a holding message for players. After that, write up what happened | Live-ops incident pressure. Structure under a time limit is what's scored |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something unwelcome. The story needs a named stake, what you said, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A common behavioural stem. Saltmarsh's published values weren't available to theme it |
| V2 | "Tell me about a time a release didn't go to plan. What did you do?" | VAL | [generic] | Selection scaffold: pick a release that went wrong and you had a part in fixing. The story needs what broke, what you did, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Themed on the JD's release-checklist line. It tests what you do when the process fails |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community says players hated last weekend's event. Design says the numbers are fine. You're running the review. What do you do?" | CASE | [generic] | Treat both as data: what players actually said and how many said it, and what the numbers measure and what they miss. Get both teams into the review, record the disagreement and the decision, and agree what you'd test next time | The JD pairs community with KPIs in the same role. This is the seam between them |
| G2 | "How do you handle credit when an update's success spans design, art, engineering and community?" | CASE | [generic] | Principle first: credit goes to the people who made it, by name, in the written review. The producer's job is making the work visible. Say how you'd do that here | A peer-style seam question on the coordination line. It needs no claim about your past |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B2, C3 |
| "coordinate design, art, engineering and community teams on each update" | B1, A2, D3, G1, G2 |
| "own the post-event review and the KPIs it reports" | A4, B3, B4, C3, G1 |
| "manage the release checklist with QA" | C2, A5, V2 |
| "3+ years producing live-service games or apps" | E1, D1 |
| "experience running a content calendar" | B2, D1 |
| "comfortable with player-retention metrics" | C1, A3 |
| "clear written communication" | D3, A4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong post-event review look like here? Is there one you'd point to as the standard?" | It's the JD's own ownership line, and the answer shows you what you'll be judged on |
| R2 | "How are the two titles' calendars planned today? One calendar or two, and who decides when both need the same team?" | It goes straight at the two-title scope, and you'll learn where the friction is |
| R3 | "Which KPIs do the reviews report now, and how much weight does revenue carry against retention?" | It tells you how much B4's gap matters here. Ask it before the in-app-purchases question comes up, if you can |
| R4 | "As Head of Live Operations, what would you want this producer to have taken off your plate by month three?" | It's tied to Tobias's own role, and it turns his answer into your 90-day plan |
| R5 | "How does community feedback get into event planning today?" | The JD names community among the teams, and the question shows you think beyond the numbers |
| R6 | "What does the release checklist with QA look like today, and what's working or not about it?" | It connects to the checklist you wrote without overclaiming, and it invites a working conversation |

---

## Prohibited claims

The pack won't coach any of these. Each has the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, formally or informally | Negative you stated, F2 | "I haven't led a team." No softener |
| Has worked with in-app purchases or monetisation KPIs | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." |
| Ran a live-events calendar, or calendars across several titles | Inflated form of F1 | F1's quote at its own scope. The pack observes that your material says one weekly content-drop calendar for the main title |
| Owned post-event reviews or KPIs | Inflated form of F3 | F3's quote at its own scope. The pack observes that your material says presenting monthly retention numbers. B3's slot stays inside the presenting |
| Managed the release process | Inflated form of F4 | F4's quote: "I wrote the release checklist our QA team still uses." C2's slot stays inside the checklist |
| Producer, without "associate" | Inflated form of F5 | F5's quote: "4 years as an associate producer at a puzzle-game studio" |

---

## Sources

**Provided documents:** your message, which held the JD text and your background.

**Searches sent:**

| Query | Outcome |
|---|---|
| "Saltmarsh Games values" | refused |
| "Saltmarsh Games interview process producer" | refused |
| "Saltmarsh Games mobile studio news 2026" | refused |
| "Tobias Wrenfield Saltmarsh Games" | refused |

No page fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have given the official value names, used to theme the VAL questions, and the values cheat sheet if a values round is documented |
| 2. `Saltmarsh Games interview process` | unavailable | The search was refused. It would have given the loop structure. Persona weights rest on the hiring-manager prior instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The search was refused. It would have given the titles and recent moves for D2 and a strategy-grounded CASE question. Both are generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have given a public professional footprint for an interviewer read and a reverse question tied to his career path. Both sections are dropped or role-generic |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search permission** → research targets 1 to 4 run: published values that can theme the VAL questions, the interview structure, the names and current events of the two titles for D2 and the CASE questions, and Tobias's public footprint for an interviewer read and a reverse question tied to his path
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on Saltmarsh's games and recent studio news, so the CO and CASE questions stop being generic
- **Whether Tobias is the hiring manager, and any recruiter note on the hour** → persona weights recomputed, plus a build section for any presentation or task they've asked you to prepare
- **Your answers to the answer slots in B1, B3, C1, C2 and C3** → the bridges in F2, F3, F4 and F7 upgrade from slots to quoted lines
- **Your CV** → evidence cells quote dated lines, and F5's live-service question may close
- **A copy of the release checklist or a written review you can share, if your studio allows it** → F4 and F8 could move from medium to high confidence
- **A tuesday-dossier.md** → the gaps would be verified evidence rather than read off one message, and the prohibited list would carry checked limits
