The prep pack isn't built yet. I'm still reading the skill's rules for sourcing evidence so the pack follows your dossier's limits. Writing starts next.
I've built your prep pack from the dossier. Web research didn't run: the three searches I tried, for Quartzline's values, interview process and recent news, were refused. So the questions about the company and its strategy are general, not specific to Quartzline.

**What to rehearse first:** question A1 in the pack. It's the objection your dossier predicted: "You have never held the PM title or owned a roadmap — why should we hire you…" Answer it in three steps:
1. **Admit the gap plainly.** "I haven't held a product manager title or role, and I haven't owned a product roadmap."
2. **Describe your related work in your own words.** You led 30+ end-to-end client integrations of the vendor's REST APIs, and you ran quarterly roadmap-input sessions that fed client evidence to product. Mention yourself that you have little to show for the sessions, before they ask.
3. **Give a 90-day ramp plan,** framed as what you would do.

The pack also covers:
- **The coaching follows your dossier's limits.** Integration work is never described as PM experience. Nothing claims you owned a roadmap, set a squad's priorities or shipped an API product.
- **22 questions** that cover every requirement, including live cases on adoption metrics and on prioritising across two squads.
- **Six questions for you to ask**, with your dossier's two first: who owns which roadmap decisions versus the squad leads, and how partner API adoption is measured today.
- **Your "seven years" stays out.** That figure appears only in the dossier's decision summary, not in any confirmed evidence. Say your tenure in your own words.

I assumed Thursday means next week, since today is Thursday, 26 November. If it's today, rehearse A1 and C1 (how your "30+" was counted) and skip the rest.

Files are in the working directory:
- quartzline_product-manager-platform-apis_interview_pack.md

I can play the Skeptic on A1 live, with follow-ups that react to what you actually say.
I can also update your `tuesday-dossier.md` with what this prep exposed, for later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview Prep Pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (your words). Interviewer name not given.
**Built from:** your underwriting dossier (v1.1, 2026-08-14). Web research was attempted and refused (see Sources), so nothing here comes from Quartzline's website or recent news.

---

## How to use this pack

- **Personas** describe *how* a question gets asked. **Types** describe *what* gets scored.
- Type key:
  - **VAL**: behavioural and values fit, judged against the company's published values
  - **EXP**: deep-dive on your experience, testing whether your claims hold up and what was really yours
  - **JD**: the role's stated requirements, including its gaps
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, solved out loud
- Provenance labels: `[grounded]` traces to your dossier, `[inferred]` is this pack's derivation (the derivation is named), and `[generic]` is a role-family pattern with no claim about Quartzline or about you.
- An **answer slot** is an instruction for the interview, not a question for me. It names a likely probe and gives you two honest branches. Answer from your own experience either way.
- The guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep: A1.** Your dossier named this objection. Rehearse it until it bores you.

---

## Fit snapshot

The requirement text comes from your dossier's `role_profile`. Evidence is quoted exactly from `verified_candidate_evidence`. The dossier's confidence notes appear in the Confidence column and in the bridge text, not inside the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier's bridge strategy, with its condition: position this as adjacent work, never as PM experience. Lead with the plain acknowledgment its `prohibited_claims` supports: "I haven't held a product manager title or role." Then the quotes at their own scope: you led the integrations and you ran the roadmap-input sessions. The limit is the dossier's: this is a transferability gap. Say what you did and let the interviewer draw the inference |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap`, with `prohibited_claims` "Having owned a product roadmap" and "Having set prioritization for an engineering squad". Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. No bridge |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Your material says integrations of the vendor's APIs, not shipping an API product. Answer slot: R2 makes a probe on the go-live stage likely. Say what went live and what your part was, in your own words. If there is nothing beyond the listed stages, stay with them |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [grounded] | discovery | The quotes show REST API integration work and a written playbook. They don't show whether that work involved API docs or schemas. Answer slot: if you worked with API docs or schemas, name which and what you did with them, in your own words. If you didn't, say so plainly and return to the integration stages |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, customers | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | discovery | The quote reaches clients. It says nothing about engineering or sales. Answer slot: if engineering or sales were part of how those integrations ran, say who they were and how you worked with them. If they weren't, say so and stay with the client side |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, product | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The dossier marks this confirmed but with little inspectable proof, so expect a probe. Mention that limit before you're asked. The quote at its own scope: you ran the sessions, and they fed client evidence to product. Answer slot: if you know what product did with that evidence, say it in your own words. If you don't, say so plainly |
| F7 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy here is `clarify`. Answer slot: the interviewer may ask about "agile delivery experience". If you worked that way, say how, in your own words. If you never worked that way, say so plainly, then name what you'd want to confirm about how Quartzline's squads define it |
| F8 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | Same caveat as F6: confirmed, with little inspectable proof. Answer slot: if you had a method for gathering the client evidence those sessions carried, describe it in your own words. If you didn't, say so and describe how you'd run partner discovery here |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material doesn't show metrics work. Answer slot: if you tracked any adoption or usage measure, say what was counted. If you didn't, say so and say what you'd measure first. The dossier also lists "How adoption is measured today" as an unknown, which makes it a reverse question (R2) |
| F10 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [grounded] | discovery | The quotes name requirements as one integration stage, plus a playbook you wrote. They don't show specs written for engineering squads. Answer slot: if you wrote requirements documents that engineers built from, say what they covered. If you didn't, say so and stay with the playbook. Never imply you set squad priorities (see Prohibited claims) |

---

## Persona table

The loop is set by your own description: one 45-minute hiring-manager conversation. The starting weights come from the hiring-manager prior (Case/Strategist and Skeptic). No interviewer profile was given, so nothing adjusts them for the person.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | "Why you, without the title?" Gap-probing on F1 and F2 | Highest. Two must-haves (F1, F3) are transferability gaps, and the dossier named this objection | Rehearse A1 until it's boring. Give the plain acknowledgment first, then quotes at their own scope, then a ramp plan |
| Case/Strategist (B) | Live problems on the actual role: adoption, prioritization across two squads, specs, partner discovery | High. Hiring managers buy capability. CASE questions let you show reasoning without needing a past you don't have | Clarify, objective, segment, approach, metrics, risks. Think out loud. Challenge one premise per case |
| Data-Driven Prober (C) | "30+ — how was that counted?" Plus probes on the medium-confidence sessions claim | Mid. Your strongest evidence is one figure-bearing line (F3) and one medium claim (F6) | Know how the number was counted, or say you don't know. Volunteer the F6 limit before it's pulled out of you |
| Conversational (D) | "Walk me through the journey." Casual R3 and R4 asides | Mid. Openers in a 45-minute slot are short but still scored | A 90-second arc built only from your quotes. Treat casual questions on hot JD topics as scored |
| Pressure (E) | Time-boxed "why you" and "how much was you" | Low to mid. Not this round's prior, but the title gap invites it | Pause, restate, anchor in the quote, hold through two follow-ups, concede the specific thing |
| Values/Behavioral (V) | Story questions on candor and customer focus | Low. No values-style round is detected and Quartzline's values weren't read (research refused), so this bank is generic | Pick real stories. If none comes to mind, say so |
| Peer Evaluator (P) | Squad-lead seam and credit questions, asked by the hiring manager on the squads' behalf | Low. Squad leads aren't in this round, but decision authority versus squad leads is an open risk in the dossier | Propose seam principles. Don't claim a seam you've run |

---

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Highest-ROI rehearsal in this pack, named by your dossier.** Concede first, then give the bridge, then the plan. (1) Concede in the words the dossier's `prohibited_claims` and `acknowledge_gap` support: "That's right. I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Bridge, labelled as adjacent: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, scoping, requirements, architecture, UAT and go-live, and run quarterly roadmap-input sessions that fed client evidence to product." Mention the sessions' limit yourself: they're confirmed, but you have little to show for them. (3) Plan, said as a plan: what you'd learn in the first 90 days and from whom. Follow-up 1, "So you've been on the input side, not the decision side?": hold the same acknowledgment and don't add to it. Follow-up 2, "Why not the experienced PM?": don't claim to be better. Say again what you did and what you'd ramp on, and let them weigh it. Never call the integration work "product management" | The dossier's `likely_interviewer_objections` item, asked exactly as written. Both negatives in it have a source in `prohibited_claims`. JD because it scores R1 directly. Follow-ups go deepest here because F1 and F2 are the thinnest rows |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Name the real ones. Roadmap ownership and prioritization authority, in the `acknowledge_gap` words: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then F7's slot: if you've worked in agile delivery, say how; if you never have, say so. Close with what you'd do in the first month to close each gap, as a plan | Persona stem. It lets you volunteer F2 and F7 on your own terms. JD because it maps to R1 and R5 |
| A3 | "Tell me about the API or platform work closest to what this role ships." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3. The beats are the quote's stages: scoping, requirements, architecture, UAT, go-live. Tell them in your own words, across the integrations you led. Answer slot: R2's "shipped" makes a probe on go-live likely. Say what went live and what your part was. If nothing went beyond the listed stages, stay with them. Describe it as integration work, never as shipping an API product | Open prompt themed by R2, a must-have. F3 is the evidence, and the inflated form is on the prohibited list |
| A4 | "Why move from integration work into product management, and why now?" | EXP | [generic] | Selection scaffold. Give your actual reason in your own words: what you want to be doing that you aren't. If the roadmap-input sessions (F6) are part of the reason, say how. If they aren't, leave them out. Don't make up a moment of realisation | Motivation consistency is the Skeptic's core probe for a role change. Generic because no quote carries your motive |
| A5 | "What do you know about our partner API platform, and why Quartzline?" | CO | [generic] | Research didn't run, so the pack has no company facts for you. Use what you've actually read: the role's own lines (partner-facing API platform, two squads, adoption metrics) plus anything you read yourself before Thursday. Say only what you can source. "I couldn't find public detail on X, so I'd like to ask you" is a strong answer | A homework check is likely in any hiring-manager round. Generic because target 3 was refused (see Sources) |

### B — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has gone flat. Diagnose it." | CASE | [generic] | Clarify first: how is adoption defined today (keys issued, first successful call, production traffic, active partners)? Segment by partner type and integration stage. Walk the funnel from signup to first call to production to growth, and form one hypothesis per drop-off (docs, auth friction, missing endpoint, partner priorities). Name the data you'd pull and the one experiment you'd run first, plus the risk of optimising the metric over the partner. This question needs no claim about your past, so the guidance makes none | "Define and track adoption metrics" is a named responsibility (F9), and the baseline is a dossier unknown, so a case here is likely. CASE because it scores structure. Generic because strategy research was refused |
| B2 | "Two squads, three partner asks, one quarter. How do you decide what goes first, and how do you work it with the squad leads?" | CASE | [generic] | State the objective first, then the criteria (partner impact, adoption effect, effort, dependency, commitments). Show the trade-off out loud and name what you'd drop and why. Then the seam: say how you'd want decision rights agreed with the squad leads, and ask how it works at Quartzline. Answer as a hypothetical. Never say "the way I prioritised my squad" | Covers the roadmap and squad responsibilities (F2, F10). The dossier flags decision authority as unevidenced, so the hiring manager may test it here. CASE keeps it in the future tense, where F2 requires it |
| B3 | "Outline the spec for a new partner-facing endpoint." | CASE | [grounded] "Wrote the internal integration playbook her team uses" | Structure: problem and partner, success measure, request and response schema, auth, errors and versioning, docs and examples, rollout and deprecation, open questions for engineering. You can mention as context that you wrote the integration playbook your team uses (F4, F10), and say nothing more about it than that | Covers R3 and the spec responsibility. CASE delivery with one grounded anchor |
| B4 | "How would you run discovery with integration partners in your first 60 days?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Bridge from F8: "I ran quarterly roadmap-input sessions that fed client evidence to product." Mention the limit yourself: confirmed, but you have little to show for it. Answer slot: if you had a method for gathering that client evidence, describe it in your own words. If you didn't, say so plainly. Then the plan: which partners, what you'd ask, how you'd synthesise, and how findings reach the squads | Partner discovery is a named responsibility, and F8 is the medium-confidence seam a prober will find. JD first, CASE delivery |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ integrations: walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slots, each in your own words: how the 30+ was counted, and what counted as one integration; what the count is sensitive to; the assumption behind it you'd defend least, named before they find it; which part was yours. If you don't know how a part was counted, say so plainly. The pack supplies no method | Every headline figure gets a defend-the-number question, and F3 rests on this one. EXP because it tests attribution |
| C2 | "Pick one integration and take me from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on one real integration. The beats are the quote's five stages, in your own words. Answer slot: R3 makes a probe on API docs or schemas likely. If you worked with them on that integration, say which and what you did. If you didn't, say so and return to the stages | Premised on the quote's own stages. It tests depth behind F3 and F4 |
| C3 | "Your roadmap-input sessions: what came out of them that product acted on?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Before anything else: "These are confirmed, but I have little I can show you from them." Then the quote at its own scope. Answer slot: if you know of something product acted on, say what, and what your part in it was. If none was acted on, or you don't know, say so plainly. Never describe the decision as yours (see Prohibited claims) | F6 is medium confidence, and the dossier warns a probe is coming. The question presupposes an outcome, so the slot's second branch lets that premise be false |
| C4 | "Tell me about working in agile delivery: sprints, backlog, ceremonies." | JD | [grounded] | The dossier's strategy here is `clarify`, and no verified entry speaks to agile. Answer slot: if you worked that way, say how, in your own words. If you never did, say so plainly. Either way, add: "Here's what I'd want to confirm about how your squads run it." That's a reasonable question, not a dodge | R5 is preferred and the dossier routes it to clarify. JD because it scores the stated requirement |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, one per quote, in your own words, ending with why this role. Answer slot: give your actual timeline and titles yourself. The pack quotes none. Don't use any title with "product" in it unless you held it | Openers are scored. D1 sets the frame A1 will test, so it has to match A1 exactly |
| D2 | "What's a well-designed API doc you've used, and what makes it good?" | JD | [generic] | Selection scaffold. Pick one you actually used and name two concrete qualities (examples, error docs, versioning notes). If none comes to mind, say so and describe what you'd want in Quartzline's docs | A casual R3 probe. Generic because no quote names a doc |
| D3 | "How do you like to work with sales?" | JD | [generic] | Selection scaffold. If you've worked with sales, pick one real instance: what they needed, what you gave them, what you held back. If you haven't, say so and describe how you'd set up the relationship here | R4 names sales, and F5 shows no sales evidence. A casual question is still scored |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate who's already a PM?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, then about 60 seconds. Don't run the other candidate down. Say what you did (the quote) and what you'd bring from it in the interviewer's own terms: partner-facing API work. Hold if pushed twice. On the third push, concede the specific thing: "They'll know the PM job here better on day one. I'm not claiming otherwise." Don't fold further than that | A time-boxed version of A1. The test is composure, and the concession is the dossier's own limit |
| E2 | "That playbook. How much of it was actually you?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Hold: "I wrote it, and my team uses it." Answer slot: if others contributed sections or edits, say what was theirs. If no one did, say so. Offer to describe how it's organised | The stem is attribution pressure. The quote says "wrote", so that's what you hold |

### V — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to a client or to leadership." | VAL | [generic] | Selection scaffold. It needs a named stake, the truth you said, how it landed, and the relationship afterwards. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Persona stem. Generic because Quartzline's values weren't read. Partner-facing roles invite candour probes |
| V2 | "When did you put a client's needs ahead of an internal metric or deadline?" | VAL | [generic] | Selection scaffold. It needs the trade-off, your decision or recommendation, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Persona stem. It touches the adoption-metric responsibility (F9) from the values side |

### P — Peer Evaluator (asked by the hiring manager about the squads)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "If I'm a squad lead and you're the PM, where's the seam, and what happens when we disagree on what ships?" | CASE | [generic] | Propose principles, not a history. You own the problem, priority rationale and partner evidence. They own the how and the estimates. Disagreements go back to the objective and data, with a named escalation. Then ask how it works today, which is reverse question R1. Make no claim about seams you've run | The dossier flags decision authority versus the squad leads. CASE keeps it hypothetical, as F2 requires |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if those integrations involved other teams, say who and how you named their part. If they didn't, say so and answer as a principle. Keep "led" as the quote states it, no bigger | Credit probes test attribution honesty. F3 is the work most likely to have spanned teams |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years PM experience | A1, A2, E1, D1 |
| R2 Shipped API or platform products | A3, C1, C2 |
| R3 Technical fluency: API docs, schemas | B3, C2, D2 |
| R4 Stakeholder management | B4, C3, D3, P2 |
| R5 Agile delivery | C4, A2 |
| Own the roadmap (responsibility) | A1, A2, B2, P1 |
| Run discovery with integration partners | B4, C3 |
| Write specs and drive delivery with two squads | B2, B3, P1 |
| Define and track adoption metrics | B1, V2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From your dossier. The JD asserts decision authority but doesn't evidence it. The answer tells you whether the role is what it says, and asking shows you understand where PM authority really sits |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | From your dossier. Adoption is a named responsibility with no stated baseline. If there isn't one, you'd be building it, and that changes the job |
| R3 | "What would you want to see in the first quarter from someone coming into product from the integration side?" | It names your transition openly and asks them to set the bar, so the A1 objection becomes a ramp plan you both agree on |
| R4 | "Where does partner input reach the roadmap today: sales, support, the squads, or direct from partners?" | It tests the discovery responsibility and shows you think about evidence flow |
| R5 | "What's a recent partner request the team said no to, and how was that decided?" | It shows how prioritisation actually works here, which is the F2 skill you'd be ramping on |
| R6 | "At six months, what would make you say this hire was the right call?" | It gives you their success criteria directly, and it beats "I think you've covered everything" |

---

## Prohibited claims

Nothing in this pack asserts, softens or implies these claims.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier `prohibited_claims` | "I haven't held a product manager title or role," then F1's quotes at their own scope, positioned as adjacent |
| Having owned a product roadmap | dossier `prohibited_claims`; `acknowledge_gap` area | "I haven't owned a product roadmap," then a ramp plan as a future. No slot, no bridge |
| Having set prioritization for an engineering squad | dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." B2 and P1 stay hypothetical |
| Shipped an API product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says integrations of the vendor's REST APIs, not shipping an API product. A3's slot stays inside the integration stages |
| Decided what product built from the roadmap-input sessions | Inflated form of F6 | F6's quote at its own scope: you ran the sessions, and they fed client evidence to product. C3's slot asks only what you know product did with it |
| Integration work described as "product management" | dossier decision condition: the bridge "is positioned as adjacent (never as PM experience)" | Describe the work in the quotes' own terms and let the interviewer draw the inference |

---

## Sources

- **Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14. It supplied `role_profile` (the JD equivalent), `decision` (context only) and `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the A1 objection, risks and employer questions for R1 and R2, prohibited claims). It has no `evidence_map`, `evidence_state` or `risk_register` section, so the fit snapshot grades R2, R3, R4 and the responsibilities rows directly from the verified entries. The dossier's decision summary mentions "seven years of integration leadership", but no verified entry states a tenure, so the pack doesn't coach that figure.
- **Searches sent:** "Quartzline company values" (refused). "Quartzline interview process product manager" (refused). "Quartzline API platform news 2026" (refused).
- **Loop:** one session, established by your own words: "a 45-minute conversation with the hiring manager". No values-style round is detected, so there's no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. It would have themed the V bank on Quartzline's official values by name |
| 2. `Quartzline interview process product` | unavailable | Search refused. It would have shown whether more rounds follow this one. This session's structure rests on your own words |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. It would have grounded A5 and B1 in current strategy. Both are `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. There's no interviewer read, and the reverse questions are role-specific rather than person-specific |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search, or paste Quartzline's values or careers page and one recent news item.** That themes the V bank on official values, grounds A5 and B1 in current strategy, and confirms the loop structure.
- **The hiring manager's name.** That adds an interviewer read from their public professional footprint, persona weights tuned to them, and a reverse question tied to their own path.
- **Recruiter guidance (focus areas, any case or presentation they've flagged).** That adds a build section for any graded deliverable and reweights the Case bank.
- **How much prep time you have before Thursday.** That adds a prioritised prep schedule.
- **The full JD text.** The `role_profile` lines may be the underwriter's wording. The posting's own words make every requirement quote exact.
- **Notes or summaries from the quarterly roadmap-input sessions.** That could raise F6 and F8 from `medium` to `high`, and C3 and B4 would no longer need the limited-proof caveat.
- **Your own sentence on tenure and titles.** That gives D1's arc a grounded timeline and settles the "seven years" figure that only the decision summary carries.
- **Your answers to the slots in A3, C1, C2, C3, C4 and P2, given outside a drill.** Those rows would be regenerated from your words.
- **A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes.** It covers a strategy brief, loop reports for this role family, and recent org context, and needs search permission.
