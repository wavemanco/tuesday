Quick status: I've read the prep-pack rules. Next I'm running a few searches on Larkfield Systems (its values, how it interviews, recent news), then I'll write the three-round pack.
I've built one prep pack covering all three rounds: Tuesday with the Director, Thursday's panel, and Monday with the VP. It's saved as `/var/tmp/tuesday-measure/1a6/runs/opus/alone/part-2/rooms/case-6-denied-b11395d6/larkfield-systems_engineering-manager_interview_pack.md`. I used the role description in your message as the job description and the background you gave as your CV.

Web search wasn't permitted in this session, so the pack has no information from Larkfield's own pages. It has no cheat sheet of Larkfield's published values for Monday. The questions about the company itself (C2 and K1) are general rather than Larkfield-specific.

- **Structure:** the pack starts with one table that sets each line of the role against what you told me. Then each round gets its own section: who is likely to ask what and in what style, 8–10 practice questions with guidance, and five questions for you to ask them. A short schedule says what to practise before each round.
- **Most important to rehearse:** question A1, "You've been a lead of six. This is two squads and 11 engineers. Why are you ready?" Expect it on Tuesday, and again from the VP on Monday as H4 and J1. The guidance gives you the honest wording and says where to stop.
- **The 60% figure:** expect the staff engineers to ask exactly how it was counted (E1). Your sentence says on-call dropped *after* the reliability quarter, not *because* of it. Keep it that way unless you can show the cause.
- **The 40 interviews:** you wrote that you run the hiring loop, "about 40 interviews last year". Before Thursday, be ready to say whether those were your interviews or the whole loop's.
- **Two gaps you named yourself:** managing managers and a hardware-linked roadmap. The pack gives you your own words for each and a plan to describe. It doesn't help you talk around them.

If you like, I'll play the Director and run A1 with real follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, I can convert it.

1. Can you paste the full job posting and your CV? Any requirement the short description leaves out would get its own questions, and three areas now left for you to fill in could become stories: growing engineers, delivery ownership and device experience.
2. Do you want to allow web search? I'd use it to pull Larkfield's published values for Monday and ground the company questions in its current strategy.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop. Three rounds, one shared fit snapshot, then one mini-pack per round.

| Round | When | Who | Format |
|---|---|---|---|
| 1 | Tuesday 1 December | Director of Engineering, your would-be manager | 45 min, hiring-manager conversation |
| 2 | Thursday 3 December | Two staff engineers and a product manager | 60 min panel |
| 3 | Monday 7 December | VP Engineering, your would-be skip-level | 30 min, "values and leadership philosophy" (the recruiter's words) |

Assumptions: the role description in your message stands in for the job description, and your message stands in for your CV. No names were given, so there's no interviewer read. Web search was refused in this session, so nothing in this pack comes from Larkfield's own pages. Company-specific items are labelled `[generic]` because of that.

---

## How to use this pack

- **Personas** describe how a question gets asked: who is asking and in what style. **Types** describe what gets scored.
- Type key:
  - **VAL**: behavioural or values alignment. Does your past behaviour show what they value?
  - **EXP**: deep-dive on your experience. Do your claims hold up, and which part was actually yours?
  - **JD**: the stated job. Can you do what the role lists, including the parts you're missing?
  - **CO**: company and strategy knowledge. Can you think at their altitude?
  - **CASE**: a live problem from the role. Structure and reasoning, delivered out loud.
- Provenance labels: `[grounded]` traces to your message. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about Larkfield or about you.
- **Answer slot** means a place in your answer that only you can fill. It always has two honest branches. If the practice or event never happened, the second branch is the right answer.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage

You have five days before Tuesday, then two, then four. Do these in order.

**Before Tuesday (Director)**
1. A1, out loud, three times, including both follow-ups. This is the highest-ROI prep in the pack.
2. A2, the hardware question. Get the acknowledgment and the plan to under 90 seconds.
3. B1 and B2. Practise the structure, not a memorised answer.
4. C1, your 90-second arc.
5. Pick three reverse questions from Round 1.

**Before Thursday (panel)**
1. E1, the 60% figure. If you can, look at your own team's on-call data so you know what was counted. If you can't, rehearse saying so.
2. D1 and G1, the roadmap trade-off from the product side.
3. E4, the fleet incident case.

**Before Monday (VP)**
1. H1. Write down your own three leadership principles before you read the guidance.
2. J1 and J2, under time pressure. Use a 60-second timer.
3. H2.

Everything else is insurance.

---

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | One team of six is adjacent to two squads but doesn't reach it. Keep the words at that scope: "Three of my nine years have been as a team lead of six." If asked about managing managers, the words are yours as you gave them: "I've never managed managers." Answer slot: the two-squads line makes a probe on running more than one group likely. If work in your team ever ran through sub-leads or parallel workstreams, say how, in your own words. If it didn't, say so plainly and stay with the team you led |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [inferred] | discovery | The quote touches delivery, since you pushed a quarter's priorities through, but it doesn't show whether delivery commitments were yours to own. Words at its own scope: "I pushed a reliability quarter through against roadmap pressure, and afterwards my team's on-call burden dropped 60%." Answer slot: if your team's delivery commitments were yours to set and keep, say how, in your own words. If they sat with someone else, or there was no such process, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Running a hiring loop is adjacent to owning hiring for a team. Words: "I run our hiring loop for backend roles, about 40 interviews last year." Answer slot: "own hiring" makes probes on hire decisions and headcount likely. If either was yours, say which and how. If not, or there was no such step, say so plainly and stay with the loop. Whether the 40 were interviews you ran yourself or interviews the loop ran is yours to say. The pack reads it the smaller way |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Being a lead for three years touches growing people but doesn't show it. Answer slot: if you've helped someone on your team grow into more scope, say what you did, in your own words. If nothing comes to mind, say so plainly and say how you'd approach it |
| F5 | "partner with hardware and product on roadmap" (the hardware part) — role description, your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | This is a gap you stated yourself, and no wording closes it. Words: "I've never owned a hardware-adjacent roadmap." Then say how you'd learn it, framed as a plan and never as past experience. The role says partner and your sentence says owned. Don't widen your sentence to cover more than it says |
| F6 | "partner with hardware and product on roadmap" (the product part) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Holding a line against roadmap pressure is adjacent to partnering on a roadmap. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the partner-with-product line makes "who were you negotiating with?" likely. If it was product, say how that conversation went, in your own words. If the pressure came from somewhere else, say so plainly |
| F7 | "building device-management services" — role description, your message | none given | none | [grounded] | discovery | Your material shows no device-management or IoT work. Answer slot: if any of your work has touched physical devices or device fleets, say what, in your own words. If none has, say so plainly and say what you'd learn first |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1, lead two squads | A1, B1, H4, J1 |
| F2, own delivery | A3, B3, E2, K2 |
| F3, own hiring | B4, E3 |
| F4, own growth | H3, C1 |
| F5, partner with hardware | A2, B2, E4 |
| F6, partner with product | D1, D4, G1, J2 |
| F7, device-management services | A4, K1, D3 |

---

# Round 1: Director of Engineering (Tuesday, 45 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the step up from a team of six, and of the hardware gap | High. A hiring manager is de-risking the hire, and F1 and F5 are the two gaps anyone reading your background sees first | Rehearse A1 until it's boring. Bridge only from the quotes in F1 and F5. Name the limit before they do, then give a concrete plan |
| Case / Strategist | Live problems from their actual roadmap: the first 90 days, a hardware slip, hiring | High. A director usually tests how a new manager would actually run their org, and the role description names delivery, hiring and hardware partnership | Clarify, then objective, structure, approach, metrics, risks. Think out loud. Push back respectfully on one premise per case |
| Conversational | A friendly opener, "walk me through your background" | Low, but it's scored. It usually opens a 45-minute conversation | A 90-second arc built only from your own sentences |

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been a lead of six. This is two squads and 11 engineers. Why are you ready for that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I've never managed managers and never owned a hardware-adjacent roadmap" | **Highest-ROI prep in the pack.** Open with what's true at its own scope: "Three of my nine years have been as a team lead of six." Name the limit before they ask: two squads would be new to you. Then move to how you'd run it (B1), framed as a plan. Answer slot: if any of your six ever worked through sub-leads or parallel workstreams, say how, in your own words. If not, say so plainly. **Follow-up 1**, "how is two squads different?": answer with the plan, not with more history. **Follow-up 2**, "have you managed managers?": "I've never managed managers." Stop there, then say how you'd work with squad leads, as a plan. Hold the three years as a lead. Concede the step in scale explicitly. Never hold the position by adding to what you did | F1 is the first gap the Director will see. The question will come in some form, and a rehearsed, non-defensive answer changes the conversation. JD type because it scores the role's first listed line |
| A2 | "Nothing you've described touches hardware. How would you handle a roadmap that depends on hardware timelines?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain first: "I've never owned a hardware-adjacent roadmap." Then a plan, framed as the questions you'd ask hardware and product in your first weeks: lead times, how often devices can take updates, what can't change once a device ships, and where software has slipped against hardware before. Say these are the things you'd learn, not things you know. Don't borrow hardware vocabulary to sound closer than your sentence | F5 is a gap you stated, and the role description's partnership line makes it certain to come up. JD because it scores a listed responsibility |
| A3 | "Tell me about a time a delivery you were responsible for slipped." | JD | [generic] | Selection scaffold: pick a real slip where you can name what slipped, when you saw it, who you told and what you changed afterwards. Answer slot: if delivery commitments weren't yours to own, say so plainly and pick the nearest thing your work does carry. If no slip comes to mind, say so plainly, then say how you'd handle one | F2 is the delivery requirement, and your material doesn't show delivery ownership. An open prompt lets you pick a true story. The guidance makes no claim about your past |
| A4 | "Why move from payments into industrial IoT?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: your actual reasons, in your own words. The pack can't supply motivation. Give the same core reason in all three rounds, because a Skeptic scores consistency. Don't claim an interest in the domain that nothing you've done or read backs up. If you've read about device management, say what, specifically | F7 and the move from payments make "why here" a standard Skeptic probe. EXP because it tests your own story |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's your first 90 days with two squads and 11 engineers. What do you do?" | CASE | [generic] | Clarify first: what does the Director expect at day 90, and what's already committed to hardware and product? Then a structure. Weeks 1–4: 1:1s with all 11, read the current commitments, learn how the two squads are led day to day. Weeks 5–8: pick one fix both squads feel and say why. Weeks 9–12: set a rhythm with hardware and product. Name the risk: going wide and changing nothing. Everything here is a plan, so it makes no claim about your past | Both F1 and A1's follow-up land here. Having a concrete plan is the honest way to answer a scale gap. CASE because it's a live problem from the role |
| B2 | "Hardware tells you a board revision slips a quarter, and one squad's feature depends on it. Walk me through it." | CASE | [generic] | Clarify what actually depends on the new board. Lay out options: decouple the work so it can be built and tested without the board, re-sequence the squad onto other work, or cut scope. Tell product early, with options attached. Ask the staff engineers which option is real. Say plainly that this is the kind of dependency you'd want mapped in your first month (A2). Don't present it as something you've handled | Tests F5 as reasoning instead of history. The role description's hardware partnership line makes this the director's likely case. CASE delivery, JD content |
| B3 | "On-call across the two squads is burning people out. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the case first: measure the load, find the sources, set a budget for reliability work, and agree it with product. Then one sentence of your own story at its own scope: "I pushed a reliability quarter through against roadmap pressure, and afterwards my team's on-call burden dropped 60%." Stop there and let them ask. Don't describe what was in the quarter unless they ask (E2) | The case lets your one quantified result land where it belongs. F2 and F6 both draw on it. CASE first, EXP second |
| B4 | "Say you can add two engineers. How do you decide the roles, and how do you run the hiring?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Structure: start from the gaps on the roadmap, then the roles, then a loop that tests for them. Anchor: "I run our hiring loop for backend roles, about 40 interviews last year." Answer slot: if running the loop included designing it, deciding hires or planning headcount, say which and how, in your own words. If it didn't, or that step didn't exist, say so plainly and stay with running the loop | F3 is your strongest adjacent evidence for a listed responsibility. The slot keeps it from being stretched into owning hiring |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc with only these beats, in your own words: nine years in engineering, three of them as a team lead of six, now at a payments company. You run the hiring loop for backend roles, about 40 interviews last year. You pushed a reliability quarter through against roadmap pressure, and afterwards your team's on-call burden dropped 60%. End with why this role (A4's answer slot). Answer slot: if there's a person on your team whose growth you'd point to, add one line. If not, leave it out | It usually opens the 45 minutes, and a casual register still gets scored. F4 is thin, so the slot is optional |
| C2 | "What do you know about what we do here?" | CO | [generic] | Say only what you've read on Larkfield's own site and in the posting, and say where you read it. This pack holds no Larkfield facts because search was refused. Turn it into a question: "What I'd most like to understand is how device-management work splits between the two squads." | A standard check on your homework. `[generic]` because no company research is in hand |

### Reverse questions: Round 1

| Question | Why it lands |
|---|---|
| "A year from now, what would make you say this hire worked?" | You get the Director's own scorecard, which you can then use in Rounds 2 and 3 |
| "Do the two squads have tech leads today, and how do you see the EM working with them?" | Takes on the F1 gap directly, and tells you what "two squads" means in practice |
| "How are roadmap commitments set between hardware, product and these squads, and where does that break down?" | Shows you're already thinking about F5 and F6, and the answer feeds B2 and the panel |
| "What's the biggest delivery risk on the device-management roadmap over the next two quarters?" | It's a question about their problem, not about the job, and it gives you material for Thursday |
| "How do you support a manager who's stepping up in scope? What do your 1:1s with your managers look like?" | Asks honestly about the step up instead of hiding it, and shows how they manage |

---

# Round 2: Panel, two staff engineers and a PM (Thursday, 60 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Where the line sits between your role and theirs, "what would you need from me", and credit-sharing | High. All three panelists would work beside you. Staff engineers and a PM are pricing what an EM costs and adds to their work | Frame it as reciprocity. Propose principles for the boundary instead of pretending to know where it sits. Tell disagreement stories that show spine and tact together |
| Data-Driven Prober | The staff engineers take your numbers apart: the 60%, the 40 interviews, and what was in the quarter | Medium-high. Technical specialists tend to verify depth, and both figures in your material invite it | Know what you can and can't say about how each figure was counted. Name your weakest assumption first |
| Values / Behavioral | The PM asks for stories: saying no to the roadmap, disagreeing with a peer | Medium. A cross-functional panelist usually runs a scored behavioural conversation | Use "we" for context and "I" for your contribution, and pick stories where the hard truth actually landed |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | (PM) "When I want a feature and your engineers want to pay down debt, how do we decide?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Lead with a principle for the boundary: one shared view of what the debt costs, and an explicit trade agreed by both of you, not a fight each sprint. Then your story at its own scope: "I pushed a reliability quarter through against roadmap pressure, and afterwards my team's on-call burden dropped 60%." Answer slot: if a PM was your counterpart on that call, say how you made the case together. If it was someone else, say so plainly. Finish with what the PM gets from you, as a plan | F6 is the partnership requirement, and a PM will test whether "against roadmap pressure" means against them. JD because it scores a listed responsibility |
| D2 | (Staff engineer) "Where's the line between your call and ours on technical decisions?" | JD | [generic] | A principle, framed as your view: staff engineers own technical direction; the EM owns people, priorities and delivery, and makes sure decisions get made and stick. When you deadlock, say who breaks the tie and how. Answer slot: if you've disagreed with a senior engineer on a design, tell it in your own words. If not, say so plainly and stay with the principle | Staff engineers are pricing whether you'll take their turf or leave a vacuum. The answer is a principle, so it makes no claim about your past |
| D3 | (Staff engineer) "How technical are you these days? Could you review one of our designs?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the nine years in engineering. Answer slot: say what you actually do today to stay close to the technical work, in your own words. If you've stepped back from it, say so plainly. Don't claim device-management knowledge. Offer how you'd get up to speed on their system, as a plan | F7 means they'll want to know whether you can follow their domain. EXP because it tests what's true about you today |
| D4 | (PM) "What do you need from me as your PM, and what do I get from you?" | JD | [generic] | Reciprocity, as a plan. You need the why behind roadmap asks early, and a say before hardware dates are committed. They get honest capacity estimates, early warning on slips, and one place to go for engineering trade-offs. Keep it to what you would do, not what you have done | The required reciprocity question for a peer. F6 again, from the collaborative side |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your team's on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four answer slots, each in your own words. How it was counted: what was measured, and over what periods. What it's sensitive to. The assumption behind it you'd defend least: say it before they do. Which part was yours. "I don't know exactly how it was counted" is an honest branch. Your sentence says the drop came after the quarter, so keep "after". If other things changed in that period, say what. If you don't know, say so. Hold the figure through two follow-ups, and concede precisely on what you can't attribute | Your one headline metric will be taken apart by people who measure things for a living. F2 and F6 both rest on it. EXP, defend-the-number |
| E2 | "What did the reliability quarter actually contain?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The quarter and the push are yours to state. Answer slot: what the work was, in your own words, and which pieces you chose versus the team. If you didn't set the contents, say so plainly and stay with pushing it through. Don't describe practices you didn't run | The natural second level after E1, and the place a story tends to get padded. F2 |
| E3 | "About 40 interviews: are those yours or the loop's, and how do you keep interviewers consistent?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | First, say plainly whether the 40 are interviews you ran or interviews the loop ran. That's the defend-the-number slot that matters here. Answer slot: "own hiring" in the role description makes consistency a likely probe. If you've done something to keep interviewers consistent, say what, in your own words. If there was no such step, say so plainly and say what you'd do | F3's figure is ambiguous as written. Saying which reading is true is worth more than either reading |
| E4 | "A firmware update rolled to the fleet is knocking devices offline. You're the EM. What happens in the first hour?" | CASE | [generic] | Structure: stop or pause the rollout first. Set incident roles (someone leads, someone communicates, the staff engineers diagnose). Tell product and anyone customer-facing what you know and when you'll update them. Afterwards, run a blameless review covering how rollouts get staged. Say you'd lean on the staff engineers for device specifics. Present it as your plan, not as a fleet incident you've run | Staff engineers test incident leadership in their own domain. F5 and F7 make honesty about what you haven't run part of the test. CASE |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | (PM) "Tell me about a time you said no to a roadmap request." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use the beats your sentence states, in your own words: the roadmap pressure, the reliability quarter, that you pushed it through, and that your team's on-call burden dropped 60% afterwards. Answer slot: the partner-with-product line makes "what happened to the work you displaced?" likely. If you know, say what slipped and how you handled it. If you don't know, say so plainly | The PM's version of D1, asked as a story. F6. VAL because it scores how you behave under roadmap pressure |
| G2 | "Tell me about a time you disagreed with a peer and the relationship stayed good." | VAL | [generic] | Selection scaffold: pick a disagreement with a named stake, where you held a position, part of it landed, and you're still on good terms. "We" for the context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle one | A standard Peer and Values probe on a panel of future peers. Open prompt, so the guidance makes no claim about your past |

### Reverse questions: Round 2

| Question | Why it lands |
|---|---|
| (Staff engineers) "What could a new EM do in their first month that would genuinely help your work?" | The reciprocity question for peers. It shows you're thinking about what you bring them |
| (Staff engineers) "How do staff engineers and the EM split ownership here today?" | You learn where the line actually sits before you have to propose one, and it shows respect for their turf |
| (Staff engineers) "Where do device-management services hurt most operationally: on-call, rollouts, something else?" | Their real pain. Bring in B3's story only if their answer makes it relevant |
| (PM) "How does the roadmap get set between product, hardware and engineering, and where would you want an EM to push back?" | Invites the PM to say what partnership looks like to them, which is F6 from their side |
| (PM) "What's one thing a previous EM did that made your job easier, or harder?" | A concrete answer you can learn from, and it tells you where the PM hurts |

---

# Round 3: VP Engineering (Monday, 30 min, "values and leadership philosophy")

The recruiter's description makes this a values-style round. Larkfield's published values aren't in hand because search was refused, so there's no values cheat sheet. The VAL questions below use your own principles and the recruiter's wording instead. See the upgrade menu.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" and stories about hard calls | High. The recruiter named the round "values and leadership philosophy" | Two or three principles you actually hold, each tied to something you did where your own sentences carry it. Where they don't, say so instead of supplying the ending |
| Pressure | Sixty-second, time-boxed challenges at executive altitude | Medium. A skip-level in 30 minutes tends to test composure and brevity | Pause and restate the question. Anchor in what you actually said. Hold through two follow-ups, then concede what's real |
| Case / Strategist | Altitude: what success looks like, and where the domain is hard | Medium. Executives tend to check whether a new manager thinks beyond their own team | Hypotheses plus the questions you'd ask. No Larkfield facts you can't source |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" "I run our hiring loop for backend roles — about 40 interviews last year" | Answer slot: the principles are yours, and the pack doesn't supply them. Two or three, each one sentence. Where one of your sentences carries an example, attach it at its own scope. If a principle is about the team's long-term health, the reliability quarter is your example. If one is about hiring, use the loop you run. Where no example exists, say it's a principle you hold and how you'd act on it. Keep it to 90 seconds | The recruiter's own words name this as the round's centre. VAL |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: your sentence doesn't say who the roadmap pressure came from. If it came from leadership, tell the reliability quarter in your own words, at its own scope. If it came from product peers or elsewhere, say so and pick another story. If none comes to mind, say so plainly, then say how you'd handle it | A standard values stem. It fits F6's story only if leadership applied the pressure, and only you know whether it did |
| H3 | "Tell me about a hard people decision you made as a lead." | VAL | [generic] | Selection scaffold: a real decision about a person on your team, covering what you weighed, what you did, and what happened to them and to the team. "I" for your part. If no such decision comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle one | F4 (growth) is thin, and leadership-philosophy rounds tend to test it through people decisions. Open prompt |
| H4 | "What changes when you go from leading six people to leading eleven across two squads?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I've never managed managers and never owned a hardware-adjacent roadmap" | Your view, framed as a view: you can't be in every room, so you lead through the squads' own leads and routines, and you hire and grow people for that. Then the honest anchor: "Three of my nine years have been as a team lead of six. I've never managed managers." Say what you'd watch to know it's working | A1 again, at philosophy altitude. The VP will hear what the Director heard. F1 |

### Bank J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over an internal candidate who's already run two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause. Concede first and specifically: the internal candidate has the scale and the context you don't. Then hold on three things, each at its own scope: three years as a team lead of six, running the backend hiring loop, and the reliability quarter after which on-call dropped 60%. Don't disparage the hypothetical candidate. Stop at 60 seconds | F1's gap delivered as a stress test. Hold-then-concede is what's scored |
| J2 | "You pushed reliability work through against roadmap pressure. How is that not just ignoring the business?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: what happened afterwards, at its own scope, that on-call dropped 60%. Answer slot: if roadmap work slipped because of the quarter, say what and how you handled it. If you don't know, say so. Concede the real cost and keep the core claim. Through two follow-ups, return to the outcome you stated, never anything bigger | Your strongest story, attacked from the other side. Rehearsing it here protects G1 and D1 too. F6 |

### Bank K: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where do you think device management gets hard at industrial scale, and what would you want your squads to get right?" | CO | [generic] | Offer two or three hypotheses framed as hypotheses, such as updating devices you can't easily reach, long-lived hardware, and incidents that hit physical operations. Say how you'd test each in your first months. Cite only what you've actually read about Larkfield. Close with a question back to the VP | F7 at executive altitude. `[generic]` because no Larkfield strategy research is in hand. CO, with CASE delivery |
| K2 | "A year in, how would you and I know you'd failed?" | CASE | [generic] | Name the failure signals as a plan: commitments to hardware and product keep slipping, people leave, on-call creeps up, hires don't land. Say what you'd look at each quarter to catch them early, and what you'd want from the VP if you saw them | Tests self-awareness and altitude in 30 minutes. F2. CASE |

### Reverse questions: Round 3

| Question | Why it lands |
|---|---|
| "What separates the EMs who thrive here from the ones who struggle?" | Gets the VP's working definition of the values, which is the round's own subject |
| "Which engineering value is hardest to live up to here right now?" | Shows you know values cost something, and gives a candid answer you can respond to |
| "How do you want EMs to raise disagreement with their director or with product?" | Leadership philosophy as a question, and it ties back to your reliability story without you having to tell it again |
| "What's the leadership bet you're making for engineering over the next year?" | Lets the VP talk strategy, which they tend to enjoy, and gives you something to connect to |
| "What would you want to hear from me in my first skip-level 1:1?" | Forward-looking and concrete, and it ends the 30 minutes on working together |

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | "I've never managed managers." No slot |
| Has led two teams, or 11 engineers | Inflated form of F1 | F1's quote at its own scope: "Three of my nine years have been as a team lead of six." The limit is the pack's own observation, not words for you: your material says a team of six. A1's slot stays inside the team you led |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." No slot |
| Owned hiring for the team | Inflated form of F3 | F3's quote at its own scope: "I run our hiring loop for backend roles, about 40 interviews last year." B4's slot stays inside the loop |
| Personally ran about 40 interviews | Inflated reading of F3, where the figure belongs to the loop as written | The quote whole. E3 has you say which reading is true |
| "My reliability quarter cut on-call by 60%" | Inflated form of F2 and F6: "after" becomes "because" | Keep your own word, "after". E1's slot asks what else changed in that period |

---

## Sources

- **Provided:** your message. It contains the role description (used as the JD), your background (used as the CV), and the three-round schedule (the loop source for every round's format and interviewers).
- **Searches sent (3), all refused because web search permission wasn't granted:**
  - `Larkfield Systems values`: refused
  - `Larkfield Systems interview process engineering manager`: refused
  - `Larkfield Systems industrial IoT news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the values cheat sheet for Round 3 and value-themed VAL questions in Bank H |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. Your message already establishes the three rounds, so it would have added only round formats, such as whether Thursday includes a design exercise |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have grounded C2 and K1 in Larkfield's current priorities instead of `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there's no query to form and no interviewer read |
| 5. representative Engineering Manager JD | skipped | The role description in your message supplies the requirements in the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **The full posting text:** every F row gets checked against the posting's own lines, and mid-list requirements (on-call, tooling, location, travel) get JD-tagged questions.
- **Your CV:** finds evidence your message didn't mention, especially for F2, F4 and F7, which are currently answer slots.
- **Permission for web search:** a values cheat sheet for Monday built from Larkfield's published values, and C2 and K1 grounded in its current strategy instead of `[generic]`.
- **Deep research (L2, up to 6 more searches and 2 more fetches, several more minutes):** a strategy brief, round-format reports for this role family, and recent org context, for sharper K1 and Round 3 reverse questions.
- **Names of the Director, the staff engineers, the PM and the VP:** an interviewer read per round from their public professional footprint, persona weights tuned per person, and a reverse question tied to each interviewer's own path.
- **The recruiter's prep notes:** coverage of any pre-declared exercise, for example a design or prioritisation exercise on Thursday, as its own build section.
- **Your answers to the slots in A1, E1, E3 and F7:** for example whether any of your payments work touched physical devices. They'd turn F1, F2, F3 and F7 from slots into story-mapped rows.
- **A tuesday-dossier.md:** carries this prep's gaps and the objection in A1 into later sessions, so the next pack starts from verified evidence.
