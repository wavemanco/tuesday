Reading the prep-pack rules is done; now running a quick, budgeted research pass on Saltmarsh Games and the interviewer before building your pack.
I've built your prep pack and saved it as `saltmarsh-games_live-operations-producer_interview_pack.md`. It assumes Tobias is the hiring manager. Saltmarsh's careers page says this 60-minute session is with the hiring manager, and his title fits, but nothing confirms it.

What the research turned up:

- **The interview format is published.** Saltmarsh calls it "the Outage Hour". It opens with a tabletop exercise on a simulated outage during a live event, then moves to a conversation about their three values. There's no take-home.
- **Saltmarsh's current strategy.** It announced Project Larkspur in September 2026. From February 2027, both titles move to a season pass, share one events calendar and are run by a single live-ops team. The gaps you mentioned (one title, no in-app purchases) are the ones that touches.
- **Tobias's background.** He was a QA lead at a console studio before this job, and he gave a GDC 2026 talk called "Patch Notes Are a Promise". Expect him to dig into your release checklist.

The pack names B1 as the best use of your prep time: "You've run the calendar for one title — why are you ready to run two and coordinate four teams?" It gives you exact wording for what you can stand behind and for the limits. Friday is tomorrow, so if time is short, practise B1, the tabletop questions (A1–A3) and the values cheat sheet out loud.

Say the word and I'll play the Skeptic on B1 live, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager for this role? If your recruiter call flagged any focus areas, paste them in too. That would reweight every question bank.
Roughly how many hours do you have before Friday? I'll add a prioritised prep order sized to that time.
Want a deeper research pass (up to 6 more searches and 2 more page reads, several more minutes) for a fuller background on Project Larkspur and both games?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations — assumed to be the hiring manager for this role (see Reading the interviewer)
**Format:** one 60-minute session, Friday. Saltmarsh's interviewing page describes it as "the Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home.

---

## How to use this pack

- **Personas** describe *how* a question arrives — the tone and pressure. **Types** describe *what is being scored*.
- **Type key:**
  - **VAL**: values. Does your past behaviour show Saltmarsh's *published* values?
  - **EXP**: experience deep-dive. Does what you said about your work hold up under follow-ups?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company knowledge. Do you know what Saltmarsh is doing right now?
  - **CASE**: live problem. Can you structure and reason through it out loud?
- **Provenance labels:** `[grounded]` means it traces to your message, the JD or research listed in Sources. `[inferred]` means the pack derived it, and the derivation is named. `[generic]` means a role-family pattern with no claim about Saltmarsh or you.
- **Fit-snapshot rows are F1–F9.** Question banks use the letters A–E, G and H. F is skipped so the two never collide.
- **The guidance is scaffolding, not a script.** Where you see an **answer slot**, the pack doesn't know the answer and won't guess it. Give your own answer in your own words, or say plainly it wasn't yours or didn't happen.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers one title's weekly content-drop calendar. It doesn't cover live events across two titles, so keep your words at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: because the JD says two titles, expect a probe on juggling more than one schedule. If you ever planned around a second title or another team's calendar, say how, in your own words. If you didn't, say so plainly and stay with the calendar you ran. Your material also doesn't say what platform the game was on. If asked, say what it was |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Running a calendar touches coordination but doesn't show it. Answer slot: the JD names four teams, so expect "who did you work with on each drop?" If any of those teams' work fed the drops and you kept it on schedule, name the teams and what you did, in your own words. If a team wasn't involved, or someone else coordinated it, say so plainly and describe your part of the calendar. Leading is a separate question, and you've already answered it: if asked, your words are "I haven't led a team." Don't let that answer swallow the coordination answer |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is next to owning a post-event review, but it isn't the same thing. Words: "I presented the monthly retention numbers to the studio head." Answer slot: expect "did you ever review how a single drop performed?" If you did, say how, in your own words. If the monthly presentation was the only review you gave, say so plainly and describe that presentation. Also say whether you compiled the numbers or presented numbers someone else produced |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. It's still a line with nothing inspected behind it, and Tobias's QA-lead background makes a deep probe likely. Lead with the quote's own terms: you wrote it, and QA still uses it. Answer slot: if you also maintained or revised it after releases, say how. If it hasn't changed since you wrote it, or someone else maintains it, say so |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | Together, your two sentences already reach this requirement. Reword only them: "I've spent four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Keep the title as associate producer. Let the weekly drops speak for the live cadence rather than relabelling the game yourself |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Direct match. Lead with it in its own terms: weekly, the main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Reaches the requirement in role terms. Answer slot: a prober will ask which retention measures they were and how they were counted. Say which, in your own words. If you don't know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist that's still in use is written work. Whether it shows clear writing is the interviewer's call, not yours to assert. Answer slot: if you wrote other documents that people relied on, name them in your own words. If not, say so and stay with the checklist |
| F9 | Not in the JD. Saltmarsh's Project Larkspur announcement (news page, search result) moves both titles to a season-pass model from February 2027 | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so. Words: "I haven't worked on a game with in-app purchases." Then say how you'd learn it, as a plan and never as past experience. Don't add anything to make the gap feel smaller |

---

## Reading the interviewer

Public professional footprint only.

| What's known | Source | Provenance | What it means for Friday |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | GDC 2026 talk page (Sources) | [grounded] | This is the person whose team you'd join. Expect live-ops specifics, not generic producer questions |
| Previously a QA lead at a console studio | GDC 2026 talk page | [grounded] | F4 is your strongest line, and it's the one he's best equipped to probe. Expect D2 and E3. The mirror opportunity is real but narrow: say "Wrote the release checklist our QA team still uses" and let him ask. Don't claim QA expertise beyond that sentence |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk page | [grounded] | Player communications in the tabletop (A3) will be read through this lens. Announce only what's known. A reverse question on the talk (R1) shows you researched *him* |
| Whether he is the hiring manager for this role | Not established. Saltmarsh's interviewing page says the 60-minute session is with the hiring manager, and his title fits | [inferred] | The persona weights below assume he is. If he isn't, reweight (upgrade menu) |

---

## Persona table

The weights come from the published loop (tabletop plus values conversation), adjusted for an assumed hiring-manager relationship and Tobias's QA background.

| Persona | How it shows up on Friday | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event, run live | High. The interviewing page says the session opens with this | Clarify, then objective, then who you pull in, then decision, then comms, then follow-up. Think aloud. Challenge one premise politely |
| Skeptic | "One title, associate level, no monetization. Why you?" | High. A hiring manager is de-risking the gaps in F1, F2 and F9 | Rehearse B1 until it's boring. Name the limit before he does. Give a ramp plan as a plan |
| Values / Behavioral | The second half of the hour, mapped to the three published values | High. The interviewing page names a values conversation | Use the values cheat sheet. Each answer has a real story or an honest "nothing comes to mind, here's the nearest" |
| Data-Driven Prober | "Which retention numbers? How counted? What's on the checklist?" | Medium. JD names KPIs and retention. His QA background pulls toward checklist depth | Know what you can and can't say about how each number was counted. Say plainly when you don't know |
| Pressure / Stress | Interruptions mid-tabletop: "Engineering disagrees, decide now" | Medium. A live-incident simulation is built to create time pressure | Pause, restate, ask one question, decide. Hold through two follow-ups before conceding anything real |
| Conversational | Warm-up "walk me through your journey" | Low to medium. Usually the first two minutes of a 60-minute session | A pre-built 90-second arc from your own sentences (G1) |
| Peer Evaluator | "Community and design disagree, what do you do?" | Low. No peer round is documented, but cross-team coordination is in the JD | Propose principles for the seam rather than pretending to know Saltmarsh's org |

---

## Question banks

### A — Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event and a chunk of players can't claim event rewards. Walk me through your first fifteen minutes." | CASE | [grounded] | Clarify first: which title, which platforms, what share of players, since when, and whether it's the event or the whole game. Then the objective: protect players and contain the issue. Then who you pull in: the engineering on-call, QA to reproduce it, and community to hold the player channel. Then the first decision you need, and when you'd next update everyone. Say the structure aloud before filling it. The question needs no claim about your past, so don't make one | The interviewing page says the session opens with exactly this shape of problem. CASE because it scores structure under a live scenario. The scenario details are illustrative |
| A2 | "Engineering says the fix is two hours out. The event ends in one. Extend, end on time, or something else?" | CASE | [grounded] | Lay out the options: extend, end on time and compensate, or pause rewards. For each, name what it costs players and the team. Pick one and say what would change your mind. Saltmarsh's value "Players Before Plans" says that when the calendar and the players disagree, the players win, so naming it by name shows homework. Then still reason through it rather than reciting it | The obvious follow-up in an outage tabletop. CASE delivery, values-flavoured |
| A3 | "Draft the first message to players. Say it out loud." | CASE | [grounded] | Four beats: what's happening, who's affected, what you're doing, and when the next update comes. No fix time you can't stand behind. This is "Ship the Patch Not the Promise" and Tobias's talk in miniature. Keep it short | Tests "clear written communication" live, and lands on the interviewer's published theme |
| A4 | "The outage is over. How do you run the post-event review?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Give it as a plan: timeline, player impact, the KPIs the event was meant to move and what happened to them, root cause, and what changes. End with the checklist. You can say you wrote the release checklist your QA team still uses, and propose that the review's fixes land in this team's checklist, which is "Leave the Build Greener". If he asks whether you've run one, that's F3's slot: answer either branch honestly | Covers the "own the post-event review" line. JD content, CASE delivery. F4 is the one sentence the guidance rests on |
| A5 | "From February both titles share one events calendar under Larkspur. How would you plan the first quarter?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify: do the titles' players overlap, how long are seasons, and what's the team's capacity per week. Principles: stagger the big moments across the two titles, share freeze windows and one QA checklist, and leave a buffer before season ends. Risks: one title's slip cascading into the other. You can anchor in cadence: you ran a weekly content-drop calendar for your main title for the last two years. Don't claim to know Saltmarsh's internal plans | Larkspur is the company's current move (Sources) and the reason this role exists in its current shape. CO because it rewards homework. F1 is the quote |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep in this pack.** "This role runs the calendar for two titles and coordinates design, art, engineering and community. You've run the calendar for one title. Why are you ready?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | **Hold** on what you did: "Four years as an associate producer. For the last two I ran the weekly content-drop calendar for our main title." **Name the limit before he does:** "It's been one title's calendar, and I haven't led a team." **Answer slot, coordination:** if other teams' work fed your drops and you kept it on schedule, say which teams and how, in your own words. If not, say so and stay with the calendar. **Ramp plan, said as a plan:** what you'd do in your first weeks to learn the second title. **Follow-up 1** ("But who made the calls?"): the same slot, and answer whichever branch is true. **Follow-up 2** ("Have you managed anyone?"): "I haven't led a team." Then stop. Don't add to it | The predictable objection to this candidate for this JD. F1, F2 and F5 are where the JD's two-titles and four-teams lines press hardest. JD because it scores the stated scope. Deepest rehearsal means the exact concession wording, not stronger claims |
| B2 | "We're moving both titles to a season pass. What's your monetization experience?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | Say the gap first and plainly: "I haven't worked on a game with in-app purchases." Then what you do have, at its scope: you presented the monthly retention numbers to the studio head. Then how you'd learn it, as a plan, for example learning the season-pass KPIs from the team's own reviews. Don't describe any season-pass mechanics as things you've done | F9 is a stated gap, and Larkspur makes it visible (Sources). CO because the question arises from the company's strategy, not the JD |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick a real one. Monetization is the honest answer: "I haven't worked on a game with in-app purchases." Then a plan, not a past. Don't pick a fake weakness | Persona stem. F9 gives you a true answer in hand, and a true answer beats a polished one with this persona |
| B4 | "Why leave after four years, and why live ops here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Answer slot: give your actual reason for moving, in your own words. For "why here", you can point to what you read: the published values, Larkspur's shared calendar, Tobias's talk. Say "I read" rather than claiming to know what they want | Motivation consistency is the Skeptic's core. EXP because it probes your own story. Your reason isn't in the material, so it stays a slot |

### C — Values / Behavioral (the second half)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. The calendar you ran is the place to look. A strong story needs what players signalled, what you changed or argued to change, who had to agree, and how it turned out. If no such time comes to mind, say so plainly. Then give the nearest thing your material does carry, or how you'd handle it here | The published value, word for word (Sources). Your quote gives a place to look but not the story, so this is a scaffold |
| C2 | "Ship the Patch Not the Promise. When have you pushed back on announcing something before it was built?" | VAL | [grounded] | Selection scaffold. You need what was going to be announced, why it wasn't ready, what you said and to whom, and what happened. If no such time comes to mind, say so plainly. Then say how you'd handle it, for example tying announcements to the checklist's sign-off | The second published value, and the theme of Tobias's GDC talk. Likely to get extra weight with him |
| C3 | "Leave the Build Greener. How have you left a process better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats the sentence states: you wrote the release checklist, and QA still uses it. Answer slot: if there was a previous checklist or process, say what changed. If there was none, say so. Say whether writing it was your idea or assigned, whichever is true | Your strongest values match. F4 carries the story directly |
| C4 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. If one of those monthly presentations carried bad news, say what it was, how you framed it, and what happened next, in your own words. If none did, say so plainly. Then give another time, or how you'd handle it | Persona stem. F3 and F7 give a place to look. The quote doesn't say any news was bad, so the pack doesn't either |

### D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Talk me through the retention numbers you presented. Which ones, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which measures they were, how they were counted if you know, and what they were sensitive to. Name the assumption you'd defend least before he asks. Say whether you produced them or presented them. If you don't know how they were counted, say so plainly. That's an honest answer, not a failure | F7 and F3. Retention is a named JD requirement, so expect it to be probed. EXP because it tests what was yours |
| D2 | "Walk me through your release checklist. What's on it, and how has it changed?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Describe what's on it in your own words. Answer slot on change: if it's been revised, say how and by whom. If it hasn't, say so. Don't invent a revision history | F4 against a former QA lead. Expect it to go two levels deep |
| D3 | "How would you know whether an event worked? Which KPIs go in the post-event review?" | JD | [generic] | Structure: what the event was for, then the metrics that match it (participation, completion, retention around the event, sessions), then player sentiment from community, then incidents. Say plainly that under a season pass you'd also learn the revenue KPIs the team uses. Don't present that as existing knowledge | The JD's KPI line. `[generic]` because the metric list is a role-family pattern, not Saltmarsh's |

### E — Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate who already knows our games?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause, then: two years running a weekly content calendar, and a release checklist your QA team still uses. Concede the real point: an insider knows these games and you'd need to learn them. Hold on what you bring. Don't fold, and don't knock the hypothetical internal candidate | Persona stem. Tests composure. Your two strongest quotes are what you hold on |
| E2 | Mid-tabletop: "Stop. The engineering lead says you're wrong and wants to roll back the update. Your call, now." | CASE | [grounded] | Pause. Restate it ("rollback versus forward fix"). Ask the one question that decides it: what does the rollback cost players and data? Then decide out loud and say what would reverse you. Hold through one more push. Concede if new facts arrive, not because of the volume | The tabletop format invites a time-pressure interruption. Delivery is scored, not the "right" answer |
| E3 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if others contributed items or reviewed it, say who and what, plainly. Precise credit-sharing raises your credibility. If no one else contributed, say so without embellishing | Attribution probe on F4, likely given his QA background. Hold, then concede only what's true |

### G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these four beats: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. Close with why live ops at Saltmarsh, in your own words. Practise it out loud twice | Casual openers are still scored. F5, F6, F4 and F7 are the whole arc |
| G2 | "What live event in someone else's game do you think was really well run?" | JD | [generic] | Answer slot: pick a game you've actually played and an event you actually saw. Say what made it work in your view: timing, rewards, communication. Then one thing you'd have done differently. Don't pick one you only read about | Casual-register test of live-service fluency. `[generic]` because it's a common pattern, and your answer is yours alone |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Two days before an update, community says players will hate a change design is shipping. What do you do?" | CASE | [generic] | Get the evidence (what players are saying, and how many), bring design and community together quickly, and lay out the options: ship, delay, change, or ship with messaging. Name who decides. Tie it to "Players Before Plans" by name. Propose principles, not a claim about Saltmarsh's org | The JD's coordination line, asked as a seam problem |
| H2 | "Art is late and the event date is fixed. What do you do?" | CASE | [generic] | Clarify how late and what's missing. Options: cut scope, swap in a reusable asset, or move the date. Say who you'd tell and when, and what goes into the checklist. Don't promise players what isn't built ("Ship the Patch Not the Promise") | Classic live-ops trade-off from the JD's coordination line |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A5, B1 |
| Coordinate design, art, engineering and community | A1, B1, H1, H2 |
| Own the post-event review and its KPIs | A4, D3 |
| Manage the release checklist with QA | D2, E3, C3 |
| 3+ years producing live-service games or apps | G1, B1 |
| Experience running a content calendar | A5, C1, E1 |
| Comfortable with player-retention metrics | D1, D3 |
| Clear written communication | A3 |

---

## Values cheat sheet

Official names from Saltmarsh's values page (Sources). The meanings are paraphrased.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players need conflict, players win | Scaffold on F1, "I ran the weekly content-drop calendar for our main title for the last two years.", as the place to look: a drop where player response changed the plan. If none comes to mind, say so plainly and say how you'd handle it (C1) |
| Ship the Patch Not the Promise | Announce only what's built | Scaffold: a time you held back an announcement until the work was ready. If none comes to mind, say so plainly and give how you'd handle it (C2). Also Tobias's talk theme |
| Leave the Build Greener | Every release leaves the code and the checklist better | F4: "Wrote the release checklist our QA team still uses." (C3) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How does the team keep track of that today?" | Tied to his own published work. Shows you researched him, and opens his favourite subject |
| R2 | "Under Larkspur, what does the single live-ops group look like, and where does this producer role sit in it?" | Shows you read the strategy, and tells you what the job really is from February |
| R3 | "Who reads the post-event review today, and what decision does it feed?" | The JD says you'd own it. Knowing its audience is how you'd do it well |
| R4 | "How is the release checklist maintained with QA right now, and what would you most want changed about it?" | Plays to his QA background and your F4 strength without over-claiming |
| R5 | "When the calendar and the players disagree, who makes the call in practice?" | Turns "Players Before Plans" into a real operating question rather than reciting it |
| R6 | "What would a strong first ninety days look like in this role?" | Gives you his success criteria, and pairs with B1's ramp plan |

---

## Prohibited claims

Things this pack will not coach you to say, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led or managed a team | Negative you stated, F2 | "I haven't led a team." |
| Has worked on in-app purchases, monetization or season passes | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." Then a learning plan, as a plan |
| Has run live events across multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one title's weekly content-drop calendar. A probe on a second schedule gets F1's slot |
| Owned post-event reviews or KPIs | Inflated form of F3 | F3's quote at its own scope. The slot asks only whether you reviewed single drops and whether you compiled the numbers |
| Has the title "producer" | Inflated form of F5 | The title stays "associate producer" |
| Built or analysed the retention numbers | Inflated form of F7 | F7's quote. D1's slot asks whether you produced or presented them |
| Ran QA or owned releases | Inflated form of F4 | F4's quote: you wrote the checklist QA uses |

---

## Sources

**Provided:** your message (the JD text and your background).

**Searches sent:**
1. `Saltmarsh Games values` returned https://saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` returned https://saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` returned https://saltmarshgames.com/news/project-larkspur (September 2026: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams are retired in favour of a single live-ops group)
4. `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

**Pages fetched:**
1. https://saltmarshgames.com/values
2. https://saltmarshgames.com/careers/interviewing

**Target accounting**

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and the C bank: three values by official name |
| 2. `Saltmarsh Games interview process` | yes | Loop established as one 60-minute session (tabletop, then values conversation). Drove the A, E and C weights and a values-style round detection |
| 3. Saltmarsh strategy / recent news | yes | Project Larkspur: A5, B2, F9, R2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, R1, R4, the D2 and E3 emphasis |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Confirm Tobias is the hiring manager for this role**: the persona weights stop resting on an assumption. If he isn't, the banks get reweighted
- **How many hours you have before Friday**: adds a prep-triage section that orders the few things to do first
- **Notes from your recruiter call** (focus areas, anything said about the tabletop): coverage aimed at what they flagged
- **Your answers to the answer slots in F2, F3, F7 and F8**: those rows and their questions (B1, A4, D1, D3) get story-mapped instead of slotted
- **Your CV text**: more evidence quotes in the fit snapshot, and possibly new rows
- **A copy of your release checklist or a retention deck, if you're allowed to share one**: F4 and F7 could move from medium to high confidence, since those are the artifacts this field actually keeps
- **Deep research (L2)**: up to 6 more searches and 2 more fetches, several more minutes. Adds a grounding brief on Larkspur and the two titles, and a deeper read of Tobias's talk
- **A tuesday-dossier.md**: the highest-ROI objection would come from verified evidence, with a prohibited-claims list carried across sessions
