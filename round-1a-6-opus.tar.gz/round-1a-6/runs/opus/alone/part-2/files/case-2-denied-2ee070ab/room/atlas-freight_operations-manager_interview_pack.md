# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees, 4 sites)
**Interviewer:** unknown. The round type and your relationship to the interviewer are also unknown.
**Built as:** a full-loop pack with flat persona weights. That is noticeably weaker than a pack aimed at one known round. Once you know who you're meeting, the weights and banks get recomputed.

## How to use this pack

Two axes. **Personas** describe *how* a question is asked: who is asking and in what style. **Types** describe *what* is being scored:

| Tag | What it scores |
|---|---|
| JD | Whether you can do the listed job, gaps included |
| EXP | Whether your own claims survive scrutiny: what was actually you |
| CASE | Structure and reasoning on a live problem from the role |
| VAL | Behaviour against the company's values (none published in hand here, so these are generic) |
| CO | Homework on the company: strategy, recent moves |

Every question has a **Provenance** label. `[grounded]` means it traces to the JD or your own words, quoted beside it. `[inferred]` means it's derived from them, and the derivation is named. `[generic]` means it's a role-family pattern with no claim about Atlas Freight.

**Answer slots** are where the pack doesn't know something about your past. Each one gives you two honest branches: say what you did, or say plainly that it wasn't so. They're instructions for the interview, not questions for you now.

The guidance is scaffolding, not a script. Say it in your own words.

**Highest-ROI prep in this pack: A1**, the scale jump from 3 supervisors to 12.

## The fit snapshot

Requirements are quoted from the JD text in your message. Evidence is quoted from your message, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material covers warehouse and distribution ops. It doesn't mention terminal operations or four sites, so your words stay where the material is: "Seven years in warehouse and distribution ops." Answer slot: the JD's "across 4 sites" makes a probe on how far your current role reaches likely. Say exactly what your senior shift manager role covers, which shifts and which areas, in your own words. If it's one shift at one site, say so plainly |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge plan sits near service levels, but the material doesn't show what it moved. Answer slot: if anything was measured for the surge plan, say what was measured and what happened, using only figures you know. If nothing was measured, say so plainly and describe how you ran the plan |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | Mis-pick rate is a quality measure, so don't stretch this bridge. Answer slot: if the pick-path redesign's effect was counted on anything beyond mis-picks, say what was counted. If it wasn't, say so plainly and say what you would measure first in this role |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your words, at their own scope: "I'm a senior shift manager over 3 supervisors." The JD's span is four times that. Say the number as it is and don't round it up. Answer slot: if any of your 3 supervisors work shifts or areas you don't see every day, say how you lead them. If not, say so plainly and describe how you would do it |
| F5 | "build reporting in Excel/Power BI" (the Excel half) — JD | "solid Excel" — your message | medium | [grounded] | discovery | "Solid Excel" describes a skill level. The material doesn't show what it has produced. Answer slot: say what your Excel covers in your own words, what you've made with it and who used it. If nobody else used it, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" (the Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Your words: "I've never used Power BI." Then how you'd learn it, said as a plan and never as a past. Add nothing to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is not stated as seven years leading. A "required" years line is often screened literally, so expect it to be checked. Answer slot: count the years in which people reported to you and give that number in your own words. If it's under five, say so plainly and point to your current role |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. It's a credential with nothing inspected behind it yet, so have the details ready (when, through whom). Lead with your own words: "I'm green belt certified." The material doesn't link the certification to any specific piece of work, so your answer shouldn't either unless you can say where you used it |

## Persona table

No loop source establishes Atlas Freight's interview process: web research was refused, and your message doesn't name the rounds. These weights therefore rest on the generic archetype (screen, then hiring manager, then panel), with flat weights. That is a pattern, not this company's documented process. Skeptic gets one extra question only because the highest-ROI objection sits there.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the gaps between your material and the JD: span, sites, years, Power BI | Medium, as for all personas: round unknown. F1, F4, F6 and F7 give it the most material | Rehearse A1 until it's boring. Build bridges only from your quoted words, say the limit plainly, then give a ramp plan as a plan |
| Case / Strategist (B) | Live problems on OTP, cost per shipment and reporting across sites | Medium: a hiring manager for this role would plausibly test this way, but the round is unknown | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud, and ask how a metric is defined before diagnosing it |
| Data-Driven Prober (C) | Takes your 40% and your surge plan to their assumptions | Medium: F3's figure is exactly what a prober targets | Know what you can and can't say about how the 40% was counted. Say "I don't know" where that's true. Name your weakest assumption first |
| Pressure (D) | Time-boxes, devil's advocate, "how much was actually you" | Medium: unknown round | Pause, restate the question, anchor in what you actually said. Hold through two follow-ups, then concede specifically |
| Values / Behavioral (E) | "Tell me about a time…" stories on leadership and hard calls | Medium: no published values in hand, so these are generic | Pick real instances. "We" for context, "I" for your part. Where nothing comes to mind, say so |
| Conversational (H) | Friendly opener, casual questions about Lean/Six Sigma | Medium: almost every loop opens this way, and it's still scored | Have a pre-built 90-second arc. Treat the casual Lean question as scored |
| Peer Evaluator (G) | Another site or ops manager pricing what you add to their load | Medium: a panel of this size often includes one, but that's unconfirmed | Use reciprocity: what you bring them. Propose seam principles rather than pretending to know the seam |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage 3 supervisors today. This role leads 12 across four sites. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI rehearsal in this pack.** Name the limit before they do: "Today I'm a senior shift manager over 3 supervisors. Twelve across four sites is a bigger span than I hold now." Hold only what the quote carries, and don't describe the 3 as anything larger. Answer slot: say exactly what your role covers, which shifts and areas, in your own words. If it's one shift at one site, say so plainly. Then give your ramp plan as a plan: how you'd learn four sites and twelve supervisors in your first weeks. Follow-up 1, "that's a 4x jump": hold, restate your quote, concede that the span is new, return to the plan. Follow-up 2, "how do you lead people you don't see daily?": answer slot. If any of your 3 work shifts or areas you don't see daily, say how you lead them. If not, say so plainly and describe how you would | F4 is the widest gap between the JD's headline and your material, so this objection arrives in some form in nearly any round. JD because it scores the stated leadership requirement |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Pick the weakness you actually stated: "I've never used Power BI." Then "solid Excel", in those words, as where you'd start. Then a learning plan, said as a plan. Don't swap in a safer fake weakness: the interviewer can see F6 in the JD-versus-background gap anyway | F6 is the one gap you stated outright, and this stem invites it. JD because it scores self-assessment against the listed job |
| A3 | "The JD asks for 5+ years of operations leadership. How many of your years were in leadership roles?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Seven years is your time in ops, so don't say "seven years of leadership." Answer slot: give the number of years in which people reported to you, in your own words. If it's five or more, say it plainly. If it's under five, say so plainly and point to what you lead now: "a senior shift manager over 3 supervisors." | F7 is a "required" line that may be screened literally, and a vague answer reads as evasion. JD because it scores the stated requirement |
| A4 | "Your background is warehouse and distribution. This is terminal operations. What's different, and how would you close that?" | JD | [grounded] "7 years in warehouse and distribution ops" | Keep your side at the quote: "seven years in warehouse and distribution ops." Say what you'd expect to learn first in a terminal, as your own view and plan, not as a claim to terminal experience. Answer slot: say exactly what your current role covers in your own words. If none of it is terminal work, say so plainly | F1 is a kind-of-work gap as well as a scale gap. JD because it scores the core responsibility |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four terminals has slid for three weeks. Walk me through your first week." | CASE | [generic] | Clarify first: how is on-time defined, and has the definition or the data changed? Then segment by shift, lane, inbound versus outbound, and day of week. Ask what else changed three weeks ago: volume, staffing, a carrier, a schedule. Then pick one hypothesis to test first, say what you'd measure daily, and name the risk of fixing the wrong thing. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's on-time line (F2's requirement). CASE because it scores structure, not record |
| B2 | "Cost per shipment is up across the network. Where do you look first?" | CASE | [generic] | Start with the denominator: shipments counted how, and did the mix change? Then split the cost into its main buckets and compare the four sites to find where the rise sits. Say which bucket you'd test first and why, and what you'd need from finance. Close with what you'd report weekly | Built from the JD's cost-per-shipment line (F3's requirement). It tests whether you define the metric before diagnosing it |
| B3 | "Four site leads each report on-time a different way. How do you build one weekly report?" | CASE | [grounded] "solid Excel, never used Power BI" | Definitions first: one agreed definition of on-time, one data source, one owner per site. Then the layout: a few measures, trend versus target, by site. On tools, in your own words: you'd start in Excel ("solid Excel"), and "I've never used Power BI", so you'd learn it once the definitions are stable. Don't describe a Power BI build | The JD's reporting line (F5, F6) asked as a live problem. CASE because the definitional thinking is what gets scored, not the tool |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your mis-pick rate fell 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number in your own words, covering four things. How it was counted: over what period, and mis-picks out of what. What it's sensitive to. The assumption behind it you'd defend least, named before they ask. Which part was yours. The pack supplies none of these. If you don't know how it was counted, "I don't know exactly how it was counted" is an honest answer. Never invent a baseline | F3's evidence carries the only figure in your material, and every prober goes for the headline number. EXP because it tests the claim itself |
| C2 | "What part of that pick-path redesign was actually yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | "We" for context, "I" for your part. Answer slot: say which decisions in the redesign were yours and who else was involved, in your own words. If it was a team effort, say so plainly and name your piece. If you're asked for a share of the 40% you can't give, say you can't split it | Attribution is the follow-up that always comes after C1 (F3). EXP because it scores honesty about what was you |
| C3 | "Tell me about the peak-season surge plan. How did you know it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats your quote states: the site's surge plan, which you ran, two years running. Keep "ran" and don't upgrade it to "designed" or "built." Answer slot: if anything was measured for the surge plan, say what was measured and what happened, using only figures you know. If nothing was measured or you don't know, say so plainly and describe how you ran it | F2's evidence is your strongest operations story, and "how did you know" is where it gets tested. EXP because it probes the claim |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running" | Pause, then pick two of your quoted facts in their own words. For example: you ran the site's peak-season surge plan two years running, and you cut mis-pick rate 40% by redesigning the pick path. Then one sentence on what you'd bring as an outsider, said as a view and not a past. Stop before sixty seconds. If they push, hold on those facts and don't add scale you didn't state | A time-boxed motivation probe that tests composure (F1, F2, F3). JD because it's scored against the role's needs |
| D2 | "You've never used Power BI. Why should we trust our reporting to you?" | JD | [grounded] "solid Excel, never used Power BI" | Hold, then concede. Concede straight away: "I've never used Power BI." Hold on "solid Excel", in those words. Answer slot: say what you've made with Excel and who used it. If nobody else used it, say so plainly. Then give a concrete learning plan as a plan. On the second push, don't fold into promises you can't time. Restate the plan | F6 is a stated capability gap, and a pressure interviewer will lean on it. JD because it's the listed reporting requirement |
| D3 | "Green belt is a certificate. Where have you actually used it?" | EXP | [grounded] "green belt certified" | Answer slot: if you've applied green belt methods to a piece of work, name the work and the step that was yours, in your own words. If you haven't, say so plainly, then say what you'd apply first here as a plan. Don't attach the certificate to work it wasn't used on | F8's credential is the JD's "plus" and invites a "show me." EXP because it tests whether the claim has practice behind it |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time you told someone senior something they didn't want to hear. It needs a named stake, what you said, and where it ended up, including if it didn't land. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem. Generic because no Atlas Freight values were in hand |
| E2 | "Tell me about a time you had to hold a supervisor accountable for performance." | EXP | [grounded] | Selection scaffold, themed by the JD's "lead a team of 12 supervisors." Pick a real instance with one of your supervisors: what the gap was, what you said, what changed, and what you'd do differently. "I" for what you did. If no such time comes to mind, say so plainly and describe how you would handle it | The JD's leadership line (F4's requirement) makes a supervisor-management story near-certain. EXP because it tests what you actually did |
| E3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. It needs a real tradeoff, the metric you gave up, and why. Name your actual decision, not the team's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Freight operations trade service against cost (F2 against F3), so this is a likely behavioral theme. Generic: no published values |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running", "green belt certified" | A 90-second arc using only these beats, in your own words: seven years in warehouse and distribution ops; now a senior shift manager over 3 supervisors; you cut mis-pick rate 40% by redesigning the pick path; you ran the site's peak-season surge plan two years running; green belt certified. Close with one sentence on why this role, in your own words. Nothing on scale beyond the quotes | The opener in almost every loop, scored on economy. It draws on F1, F2, F3, F4 and F8 |
| H2 | "Are you doing anything with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Treat it as scored. "I'm green belt certified." Answer slot: if you're applying it to anything now, say what, in your own words. If you aren't, say so plainly and say what you'd look at first here | The JD's "plus" asked casually (F8). JD because it scores a listed qualification |
| H3 | "Why are you looking to move?" | EXP | [generic] | Give your actual reason, in your own words, framed toward this role rather than away from your current one. Don't criticise your current employer | Asked in some form in nearly every round. EXP because the answer is about your own history |
| H4 | "What do you know about Atlas Freight, and why us?" | CO | [grounded] | Do your own homework on Atlas Freight's website and recent news before the day: this pack couldn't. From the JD you can say it's regional logistics, about 800 employees, and four sites. "Why us" is your own reason, in your own words | The research that would have grounded a strategy question was refused (see Sources). CO because it scores homework |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites share trucks and dock time. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: one shared view of capacity, an agreed rule for priority calls, and escalation only after you've tried to settle it directly. Show both spine and tact | Multi-site ops (F1's requirement) puts you between peers. CASE because it's a live scenario |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if the pick-path redesign involved other teams, say who, and how you shared the credit, in your own words. If it didn't, say so plainly and pick another instance, or say how you would handle it | A standard peer probe. F3 is the obvious story, so rehearse its attribution |
| G3 | "What would you need from the other site managers in your first month, and what would you bring us?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Reciprocity first. What you bring, in your quote's words: you ran the site's peak-season surge plan two years running, and you can share how you ran it. What you need: their view of the seams, their supervisors' names, and their reporting. Keep it to what you'd do, not what you've done at their scale | Tests whether you reduce or add to a peer's load (F2, F4). JD because it maps to leading across sites |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A4, B1, D1, G1 |
| "drive on-time performance" | B1, C3 |
| "cost-per-shipment down" | B2 |
| "lead a team of 12 supervisors" | A1, E2, G3 |
| "build reporting in Excel/Power BI" | A2, B3, D2 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | D3, H2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and is it measured the same way at each?" | It shows you think in definitions before diagnoses, and the answer tells you what B1 and B3 really look like here |
| R2 | "How are the 12 supervisors split across the sites, and how long have most been in post?" | It shows you're already thinking about the team you'd lead, and it sizes the A1 jump in practice |
| R3 | "What reporting exists today? Is there a Power BI build, or would this role start it?" | It turns your stated gap into a scoping question and tells you how much of it matters on day one |
| R4 | "Which of the four sites needs the most attention right now, and why?" | It invites them to describe the real job, and gives you something specific to refer back to |
| R5 | "What's driving cost per shipment most right now, as the team sees it?" | It shows you'd own the JD's cost line, and it's the most role-specific thing you can ask |
| R6 | "What would make the first 90 days in this role a success, in your eyes?" | It gets the scorecard from the person who'll hold it |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal or multi-site operations | Inflated form of F1 | F1's quote at its own scope. Your material says warehouse and distribution ops, not terminals or four sites. A1's and A4's slots stay inside your current role |
| Led a team at the JD's scale | Inflated form of F4 | F4's quote at its own scope: "senior shift manager over 3 supervisors." Don't round it up |
| Seven years of operations leadership | Inflated form of F7's quote | "7 years in warehouse and distribution ops", as said. A3's slot asks only for your years with reports |
| Improved on-time performance | Inflated form of F2 | F2's quote at its own scope. C3's slot asks only what was measured for the surge plan |
| Designed or built the peak-season surge plan | Inflated form of F2's quote | "ran the site's peak-season surge plan two years running." Keep "ran" |
| Cut cost per shipment, or the 40% as a cost saving | Inflated form of F3 | F3's quote at its own scope: mis-pick rate. Your material does not link it to cost |
| Built reports or dashboards | Inflated form of F5 | "Solid Excel", as said. The F5 slot asks what it has produced |
| Power BI experience at any level | Negative you stated, F6 | "I've never used Power BI." No slot |
| The pick-path redesign as a Lean or Six Sigma project | Inflated form of F8 | "Green belt certified", as said. Your material doesn't connect the two. D3's slot asks only where you've used it |
| Sole credit for the 40% | Inflated form of F3's quote | The quote as said. C2's slot asks which part was yours |

## Sources

**Provided documents:** the JD text and the background in your message. No CV, no interviewer information.

**Searches sent (all refused, so nothing returned):**
- `Atlas Freight values mission`: refused
- `Atlas Freight interview process operations manager`: refused
- `Atlas Freight regional logistics news 2026`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. Would have themed the VAL questions on published values, and fed a values cheat sheet if a values round turned up |
| 2. `Atlas Freight interview process` | unavailable | Search refused. Would have replaced the generic archetype and flat persona weights with named rounds |
| 3. `Atlas Freight strategy / recent news` | unavailable | Search refused. Would have grounded H4 and a CASE question in current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD text you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting (hiring manager, a peer site manager, HR, a panel) → personas reweighted, the top bank deepened to 4–5 questions, and the low-likelihood banks trimmed
- The interviewer's name → an interviewer read from their public professional footprint, plus a reverse question tied to their path
- Any recruiter or HR guidance (focus areas, a presentation or exercise to prepare) → coverage of stated focus areas, and a build section for any pre-declared deliverable
- The full JD, if there's more than the excerpt → every extra requirement becomes a fit row and gets at least one question
- Your CV → more of your own sentences to quote, so the scaffolds in E1, E2 and E3 can become story-mapped answers
- Web search allowed in this session → targets 1–3 run, and H4 and the VAL rows can move from `[generic]` to `[grounded]`
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on Atlas Freight, loop reports and recent org context, for sharper CO and CASE questions
- Your green belt certificate details, or a before-and-after report on the mis-pick rate → raises F8 and C1 from `medium` toward `high`
- Your own answers to the answer slots (F1, F2, F3, F5, F7), told to me outside a drill → those rows regenerate with your words as evidence
- How much prep time you have → a prioritized prep schedule sized to it
- A `tuesday-dossier.md`, if you have one → verified evidence and a prohibited-claims list carried in from an evaluation. Not needed for this pack
