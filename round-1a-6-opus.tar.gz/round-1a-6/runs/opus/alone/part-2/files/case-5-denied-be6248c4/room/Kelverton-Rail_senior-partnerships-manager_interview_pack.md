# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, Tuesday
**Panel:** Deepa, VP Partnerships (your future manager); Ross, Commercial Director
**Format, as the recruiter set it:** 15-minute no-slides POV on operator partnerships over the next 18 months, landing on what it means for operators; then Q&A, with Ross pushing on commercials

---

## How to use this pack

Two axes. **Personas** describe how a question is asked (who is asking, in what style). **Types** describe what is being scored.

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values they care about |
| EXP | Whether your stated history survives scrutiny: what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Company and market homework, at their altitude |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your message or the recruiter's email; `[inferred]` is a derivation, which is named; `[generic]` is a role-family pattern with no claim about Kelverton. **The web research for this pack was refused** (see Sources), so everything about Kelverton beyond what you and the recruiter wrote is `[generic]`.

The guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview with two honest branches. Fill it from what you actually did, or say plainly that you didn't.

---

## Prep triage: your four hours

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV, then say it aloud twice with a timer. Cut whatever runs over 15:00 | Section: POV build |
| 2 | 35 min | Rehearse the highest-ROI objection, the quota question, including both follow-ups and the exact concession wording | D1 |
| 3 | 30 min | Defend your numbers: the £4M and the 6-to-40. Work out what you can and can't say about how each was counted | C1, C2, C3 |
| 4 | 30 min | Ross's commercials questions on your own plan: partner economics and how you'd measure year one | D3, D4, C4 |
| 5 | 20 min | The rail gap and the "other side" story: settle who your consulting clients actually were before anyone asks | B1, F2 |
| 6 | 15 min | Choose four reverse questions, with one for Ross | Reverse questions |
| 7 | 20 min | One live drill of D1 (offered at the end) | D1 |

Everything else in this pack is insurance.

---

## Fit snapshot

No JD was supplied. The requirements below come from the recruiter's own words where quoted, and from role-family patterns otherwise.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The POV looks forward, so it needs no past claim. Where it leans on your history, it leans on this sentence at its own scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the 18-month frame makes a probe likely on whether you have planned a channel over that kind of horizon. If you set a multi-quarter plan for the ISV channel, say what it was and how it held up, in your own words. If no such plan existed, or it wasn't yours, say so plainly and return to the 6-to-40 |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning. It does not say heavy rail or train operating companies, and the bridge doesn't either. Words: "Before partnerships I spent five years in transport consulting, on bus and light rail network planning." Answer slot: expect "who was the client?" If operators were your clients, say what kind of operator and what you did for them. If the clients were authorities or anyone else, say so plainly and stay with the planning work itself |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Words at the quote's scope: "roughly £4M of influenced revenue." The quote names no period, so never say "a year". The figure raises four slots, each answered in your own words: how it was counted, what it is sensitive to, the assumption behind it you'd defend least, and which part was yours (C1 to C3). "I don't know exactly how it was counted" is an honest answer if it is true |
| F4 | Carrying a direct revenue number, which some senior partnerships roles in software do. Whether this one does is unknown | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap you have stated, and no wording closes it. Words: "I haven't carried a direct quota; my number was influenced revenue." Then what you would need to own one, said as a plan and never as a past. Whether this role carries a quota is a reverse question (R2), not something to assume |
| F5 | Experience selling to or partnering with train operating companies (role-family) | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I haven't sold into rail." The adjacent evidence is F2, at F2's scope. Nothing gets added to make the gap feel smaller |
| F6 | Scaling a partner programme (role-family) | "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap. Say it in its own terms: you took the channel from 6 partners to 40. It is a stated line with nothing inspected behind it, so expect a probe on what the 40 produced (C2) |
| F7 | Senior relationships with operator and partner executives (role-family) | none given | none | [generic] | discovery | What strong evidence looks like: a named level of relationship you held and kept. Answer slot: if, in either role, you held relationships with senior people at partners or operators, name the level and one relationship, in your own words. If you didn't, say so plainly and say how you'd build them in your first 90 days |
| F8 | Fluency in Kelverton's own market picture (role-family; the report is the panel's shared reference) | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [generic] | discovery | This pack hasn't seen the report, so it supplies nothing from it. Answer slot: when asked about the report, name one finding you'd build on and one you'd test, from what you read. If nothing in it struck you as worth testing, say what you'd most want to verify with operators |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 18-month POV | POV build section, A1, A2, A3 |
| F2 operator payoff | POV close, A3, B1, G2 |
| F3 commercials | C1, C2, C3, D3, D4 |
| F4 direct quota | D1 (highest-ROI), B4 |
| F5 selling into rail | B1, D2, B4 |
| F6 scaling a programme | C2, E1 |
| F7 senior relationships | A4 |
| F8 market picture | A5, E2 |

---

## Graded deliverable: the 15-minute POV

### What you can build on

- **From the recruiter, `[grounded]`:** 15 minutes, no slides, an 18-month horizon, a close on "what it means for the operators themselves", and Ross pushing on commercials afterwards. Assume every claim in the POV will be tested in the Q&A.
- **About Kelverton, as you described it, `[grounded]`:** UK rail-tech, about 600 staff, selling scheduling software to train operating companies. Nothing else about them is established here.
- **From the report, which only you have:** choose two findings before you write anything. Use one as your **consensus anchor**, to show you did the reading, and one as your **point of divergence**, where you'll argue something the report doesn't. Every candidate who read it can recite it. Departing from it with reasons is what scores.
- **From your history:** F1, "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"; F2, "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". Use each at its own scope, and only where it helps the argument.

### Settle the definition in the first 30 seconds

"Operator partnerships" can be read two ways. Name the one you're taking:
1. **Partnerships with the operators themselves**: design partners, joint roadmaps, pilots.
2. **Third-party partners who serve operators**: integration partners, consultancies, systems integrators.

If the report or the JD settles which one Kelverton means, follow it. If not, say which you've taken and why, which shows judgement in itself.

### Thesis options, each with its concession `[generic]`

Pick two. Three is fine only if you stay under time.

| Thesis | The argument | Mandatory concession |
|---|---|---|
| T1 Depth before breadth | For 18 months, judge partnerships by what operators get from them, not by partner count. Run fewer partners, each tied to an outcome an operator would notice | It slows the headline number. Your own F1 story is a count (6 to 40), so own the tension rather than let them find it: "I've grown a channel by count; here I'd argue the first 18 months should be about depth." |
| T2 Integration as the operator's payoff | Scheduling software sits next to other systems an operator runs. The partnerships operators feel most are the ones that cut the work of joining those systems up | It depends on product and engineering commitment that Partnerships doesn't control. Without seeing the roadmap it is a hypothesis, so say so |
| T3 Operators as design partners | A small number of operators co-shape pilots and the roadmap, which ties them in and sharpens the product | Two risks: building for one operator, and design-partner terms eroding price. Ross will go straight to the second, so have your answer ready |

**Differentiation.** The consensus answer is "build an ecosystem: more partners, a marketplace, co-marketing." Diverge on sequencing: depth first, breadth when the first plays prove out.
**The anti-pick, where saying no is part of the job.** Recommend *not* building a reseller channel in this 18-month window if the direct team owns the operator relationships. Concession: if the report shows a reach gap the direct team can't close, you'd revisit.

### The commercial spine (for Ross)

For each thesis you keep, give one sentence on how it makes or protects money (partner-influenced pipeline, attach, retention or renewal) and the one metric you'd track. Name what you don't know yet, such as pricing, margins and the current partner economics, and say what you'd need to see before committing to a number. Don't put a figure in the talk that you can't source.

### Shape and timing

| Segment | Time | Content |
|---|---|---|
| Open | 1:00 | The definition you've chosen, a one-sentence thesis, and a one-sentence operator payoff |
| Where things stand | 2:00 | Your consensus anchor from the report |
| Theses | 6:00 | Two theses, each with its concession said aloud, then the anti-pick |
| Commercials | 2:00 | The commercial spine |
| Sequencing | 2:00 | Months 0 to 3: listen and audit (current partners, operators, the direct team). Months 3 to 9: two or three deep plays, piloted. Months 9 to 18: scale what worked and formalise the commercial model |
| Close | 2:00 | **What it means for operators**, in three plain sentences: what they spend less time on, what they get sooner, and who answers to them for the outcome. End on the operator, as the recruiter asked |

---

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa, going deeper into the POV: "what first", "what would you say no to" | High. She is the hiring manager and the recruiter made the POV the opening 15 minutes, so the Q&A will grow out of it | Clarify, then structure, then answer. Challenge one premise per question, respectfully |
| Data-Driven Prober | Ross, on the £4M and the 6-to-40 | High. The recruiter said Ross "will push on commercials", and your one figure is the obvious place to start | Know what you can and can't say about how each number was counted. Name the weakest assumption before he does |
| Pressure | Ross, interrupting and time-boxing on quota and rail | High. A Commercial Director pushing on commercials, facing a candidate who has stated F4 and F5, will apply pressure | Pause and restate the question. Hold what your quotes carry through two follow-ups, then concede the specific limit |
| Skeptic | Deepa, on fit: rail, transfer, why now | High. A hiring manager derisking the two gaps you named | Rehearse the gap answers until they're boring. Bridge only from F2 and F1 at their scope |
| Conversational | Openers and the "journey" question | Medium. Panels usually open warm, and this register is still scored | A 90-second arc (E1) |
| Peer Evaluator | Either panellist on the seam with direct sales | Low to medium. There's no peer on the panel, but partnerships and direct sales share operators | Propose principles for the seam rather than pretending to know where it sits |
| Values / Behavioural | One or two "tell me about a time" questions | Low. The recruiter named no values round, and Kelverton's values weren't researched (search refused) | Use the two scaffolds in bank G |

---

## Question banks

### A. Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you could do only one thing from that plan in your first 90 days, what is it?" | CASE | [generic] | Pick one thing and say why it comes first, what you'd need to learn before doing it, and what would tell you by day 90 whether it was working. Listening work (partners, operators, the direct team) is a defensible first move if you say what decision it feeds | The obvious next question after any 18-month plan. CASE because it tests prioritisation live |
| A2 | "How would you decide which partners to say no to?" | CASE | [generic] | Give two or three criteria, said aloud before you apply them: does an operator benefit you could name, do we have the capacity to support it, does it conflict with how direct sales owns the account. Then one example of a type of partner you'd turn down | Tests the judgement behind T1 and the anti-pick. Saying no is part of a senior partnerships role |
| A3 | "An operator tells us they don't want another vendor in the room. They want us to own the outcome. How does your plan respond?" | CASE | [generic] | Treat it as a real tension, not an objection to dodge. Kelverton stays accountable to the operator and partners sit behind that, so the operator gets fewer interfaces, not more. Say which thesis this strengthens and which it weakens | A live problem from the "land on operators" brief (F2's requirement). It tests whether your plan survives the operator's point of view |
| A4 | "Who's the first person at an operator you'd want a relationship with, and how do you get it?" | CASE | [generic] | Structure it: which role, why that role, the route in (through the existing account team, not around it), and what you'd bring them. Answer slot for F7: if you have held senior relationships at partners or operators, give the level and one example in your own words. If not, say so plainly and give the plan | Covers F7, which your material is silent on. CASE delivery so the plan carries it, whatever the answer slot holds |
| A5 | "What in our market report do you disagree with?" | CO | [generic] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Use your prepared point of divergence. Answer slot: name one finding you'd test and why, from what you actually read. If you don't disagree with anything, say so plainly and say which finding you'd most want to check with operators. Never cite a figure you aren't sure the report contains | F8. Recruiters attach a report so the panel can see what you did with it. CO because it is homework depth |

### B. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why would operators take your calls?" | JD | [grounded] "Never sold into rail specifically" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Lead with the plain acknowledgment: "I haven't sold into rail." Then the adjacent fact at its own scope: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: if operators were your consulting clients, say what kind and what you did for them. If they weren't, say who the clients were and stay with the planning work. Then the forward plan: operators take the first call through Kelverton's existing relationships, not yours. Never say you've worked with train operating companies | The second most predictable objection (F5, bridged only by F2). JD because rail access is a core requirement of the role |
| B2 | "Payments ISVs and rail operators are very different. What actually transfers?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Say what you did in your own words: you ran the ISV channel and took it from 6 partners to 40. Then give one thing you expect to transfer and one you expect not to, as a view about the future rather than a claim about the past. Naming what won't transfer is the credibility move | F1's scope against a new market. EXP because it tests which parts of the ISV work were yours |
| B3 | "Why leave payments for rail now?" | EXP | [grounded] "so I know the operator world from the other side" | Your motivation, in your own words. If the consulting years are part of the pull, you can say so in the words you used here: you know the operator world from the other side. If something else is driving the move, give that instead. Don't build a reason you don't hold | Motivation consistency is the Skeptic's core test. The F2 quote is a natural thread, but only if it is actually yours |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Pick one of the two gaps you've stated, rail or quota, and own it in its plain form ("I haven't sold into rail" or "I haven't carried a direct quota"). Then give a concrete ramp plan for it, said as a plan. Choosing the gap they already suspect is stronger than choosing a safe one | F4 and F5. Asking for a weakness lets you choose which gap, so choose on purpose |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the £4M. How was influenced revenue counted?" | EXP | [grounded] "roughly £4M of influenced revenue" | In your own words: how it was counted and over what period. The quote gives no period and no method, so the pack supplies neither. If you don't know exactly how it was counted, say so plainly. That beats an explanation that won't survive a second question. Then name the assumption behind the figure you'd defend least, before Ross does | F3's figure is a magnet for a Commercial Director. EXP because it tests what the number actually means |
| C2 | "Six to forty partners. How many of the forty actually produced revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know how many of the 40 contributed, and how concentrated it was, give it. If you don't know, say so plainly. Don't estimate on the spot. Then link it to T1: this is exactly why you'd measure depth here | F6. A count invites the "how many were real" question. Answering it honestly makes the T1 argument stronger |
| C3 | "How much of that growth was you, versus the company, the product or the market?" | EXP | [grounded] "running the ISV channel — took it from 6 partners to 40" | Say what was yours, in your own words. "We" for the context, "I" for your part. Answer slot: if particular partners came in through work that was yours, name that work. If the growth was mostly driven by forces outside the channel, say so and say what you did with them. An exact attribution scores higher than a large one | The attribution probe. It rehearses candour about F1 |
| C4 | "How would you measure partnerships here in year one, before revenue shows up?" | CASE | [generic] | Give leading indicators tied to your theses: partner-influenced pipeline, operator usage of an integration, pilots converted to contracts. Say which one you'd stake yourself on and why. Name what you'd need from Ross's side (pipeline data, attribution rules) | Ross needs to see how you'd be held to account. It also prepares the ground for D1 |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **HIGHEST-ROI PREP.** "You've never carried a direct quota. If I give you a number, why should I believe you'll hit it?" | JD | [grounded] "never carried a direct quota, only influenced revenue" "roughly £4M of influenced revenue" | **Pause. Then the acknowledgment, said first and flat:** "That's right. I haven't carried a direct quota; my number was influenced revenue: roughly £4M." **Then the plan, not a past:** what you'd need to own a number (clear attribution rules with direct sales, a pipeline you can see, a ramp period), and the first number you'd propose to be measured on. Answer slot: if your influenced-revenue figure was set or tracked against a target, say how, in your own words. If it wasn't, say so plainly and stay with the figure. **Follow-up 1, "So you've never been accountable for revenue":** hold. Don't accept a wider negative than the one you stated, and don't claim a quota. Restate: "I haven't carried a direct quota; my number was influenced revenue: roughly £4M." **Follow-up 2, "Influenced revenue is what partnerships people say when they can't prove anything":** concede the specific limit and nothing more: "That's fair. Influenced revenue isn't a quota, and I won't dress it up as one." Then turn it: "How would this role be measured?" | The most predictable objection in this panel: the recruiter put Ross on commercials and F4 is the gap you named. Rehearsed until boring, it becomes a moment where you look composed and honest. JD because it scores a core expectation of the role, delivered under pressure |
| D2 | "Sixty seconds: why you over someone who's sold scheduling software to operators for ten years?" | JD | [grounded] "9 years in partnerships" "Never sold into rail specifically" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Don't argue that you have their experience. You don't, and you've said so. Give three beats in 60 seconds: nine years in partnerships; five years of bus and light rail network planning; and a POV built around operators rather than around the software. Concede the rail gap in one clause ("I haven't sold into rail") and don't apologise for it | Time-boxed pressure on F5. JD because it scores the domain requirement |
| D3 | "Your plan assumes partners will invest. What's in it for them? Give me numbers." | CASE | [generic] | Structure the economics without inventing figures: what the partner gets (pipeline access, integration that sells their product, referral fee or revenue share), what it costs them, and the break-even you'd test in a pilot. "I'd want to see current partner economics before I put a number on it" is a strong answer if it comes with the test you'd run | Ross will test whether the POV has a commercial engine. CASE because it is a live problem |
| D4 | "How would you structure the commercial terms with a partner: referral, resale, revenue share?" | CASE | [generic] | Name the options and the trade-off for each (control, margin, channel conflict), then choose one for each of your theses and say why. Tie it back to the anti-pick: no resale in this window if direct sales owns the operator relationship | "Push on commercials" literally means this. It tests whether your plan's choices hold together |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your journey." | EXP | [grounded] "9 years in partnerships" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc in this order: transport consulting on bus and light rail network planning; partnerships; the ISV channel, taken from 6 partners to 40 with roughly £4M of influenced revenue; why rail now (your own reason, per B3). Every beat is a sentence you stated, so add nothing in between | The warm opener is still scored. It sets the frame for every later probe |
| E2 | "So, what did you make of the report?" | CO | [generic] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Short version of A5: your consensus anchor plus your divergence, in under a minute. Answer slot as in A5: use only findings you actually read | F8 asked casually, and still scored |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Our account managers own the operator relationships. Where does partnerships fit without stepping on them?" | CASE | [generic] | Propose seam principles rather than pretending to know where the seam sits: the account owner stays the operator's single point of contact, partners are introduced through them, and the attribution rules are agreed before deals rather than after. Then ask how it works today | The seam with direct sales is where the anti-pick and D1 meet |
| F-2 | "Tell me about a time credit for a deal was contested between your team and another." | EXP | [generic] | Selection scaffold: pick a time from the ISV channel when attribution between partners and another team was disputed. It needs the stake, what you did, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then say how you'd set attribution rules here | Persona stem on credit-sharing. Ross may ask it from the commercial side |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a truth that cost you something to say, and an ending where it actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem. A senior partnerships role includes telling leadership which partners aren't working |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific customer or partner, the metric you gave up, and why. If no such time comes to mind, say so plainly, then say how your POV puts operators first | Persona stem that mirrors the recruiter's "land on what it means for the operators themselves" |

---

## Reverse questions

Ask four. Make one of them R2, for Ross.

| # | Question | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which relationships do you mean: the operators themselves, or the partners around them?" (to Deepa, if the POV didn't already settle it) | It shows you noticed the ambiguity, and the answer tells you what the job actually is |
| R2 | "Does this role carry its own number, or is it measured on partner-influenced revenue? And how is attribution decided with direct sales?" (to Ross) | It settles F4 honestly and turns D1 into a shared design question |
| R3 | "What does a partnership look like that an operator would say made their life easier?" | It keeps the conversation on operators, as the recruiter asked, and gives you their vocabulary |
| R4 | "What would make the plan I just described wrong, from where you sit?" | It invites the challenge, which reads as confidence, and tells you what Deepa worries about |
| R5 | "Which commercial model have you tried with partners that didn't work, and why?" (to Ross) | It speaks Ross's language and shows you want lessons, not a blank slate |
| R6 | "What would a strong first six months look like, so you'd know the hire was right?" (to Deepa) | It is your future manager's own success criteria, heard first-hand |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or owned a revenue target | Negative you stated, F4 | "I haven't carried a direct quota; my number was influenced revenue." |
| Sold into rail, or sold to train operating companies | Negative you stated, F5 | "I haven't sold into rail." |
| £4M a year, or £4M closed or sourced | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The pack observes that the quote names no period and stays "influenced". C1's answer slot stays inside how that figure was counted |
| Built the ISV channel from scratch | Contradicted by F1's quote | "took it from 6 partners to 40" |
| Worked with train operating companies, or in heavy rail | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The pack observes that the material says that, not heavy rail. B1's answer slot stays inside who the consulting clients were |
| Worked for or as an operator | Inflated form of F2 on the relationship axis | Your own words, kept as yours: "so I know the operator world from the other side". The pack observes that the quote says consulting, not operating |

---

## Sources

**Provided:**
- Your message, including the recruiter's email quoted in it.
- The market report attached to the recruiter's email, which you read. **Its contents were not provided to this pack, and nothing here is drawn from it.**

**Searches sent (all refused, so no results came back):**
1. `Kelverton Rail values`: refused
2. `Kelverton Rail interview process partnerships`: refused
3. `Kelverton Rail scheduling software train operating companies news 2026`: refused
4. `Deepa VP Partnerships Kelverton Rail`: refused
5. `Senior Partnerships Manager rail software job description UK`: refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have themed the bank G questions with named values. The values cheat sheet is absent either way, because the recruiter's description of the round names no values round |
| 2. `Kelverton Rail interview process` | unavailable | Would have checked the recruiter's description of this round. Persona weights rest on the recruiter's email, which establishes this session |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Would have grounded the POV theses and the CO questions. As it is, T1 to T3 are `[generic]` and the report is your only company-specific source |
| 4. `Deepa` / `Ross` at Kelverton Rail | unavailable | Would have given a reading of each interviewer's public profile and a reverse question tied to their career path. The search for Deepa was refused, and no search for Ross was sent once that refusal came back |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have put quoted, `[inferred]` requirements in place of the `[generic]` rows F4 to F8 |

---

## Upgrade menu

- **The JD text** → rows F4 to F8 become quoted requirements, every JD requirement gets a coverage check, and any gate (location, travel) gets surfaced
- **Two or three key passages or figures from the market report, pasted** → a grounding brief, theses T1 to T3 tied to Kelverton's own numbers, and specific answers for A5 and E2
- **Allowing web search** → targets 1 to 5 rerun (values, process, recent news, Deepa's and Ross's public profiles); after that, an optional deeper pass of up to 6 more searches and 2 more fetches, taking several more minutes
- **Who your consulting clients were** (operators, authorities, others) → upgrades F2, B1, B3, D2 and E1 from answer slots to story-mapped answers
- **How the £4M was counted, and over what period** → upgrades C1, D1 and the F3 bridge
- **How many of the 40 partners produced revenue** → upgrades C2, and gives T1 a number of your own
- **Whether this role carries a quota** (one email to the recruiter) → reshapes D1 and F4 before Tuesday rather than in the room
- **Your CV** → evidence cells beyond the few lines in your message, and story-mapped answers for F7, F-2, G1 and G2
- **A `tuesday-dossier.md`** → verified evidence and a prohibited-claims list from an earlier review, making the highest-ROI objection evidence-derived rather than inferred
