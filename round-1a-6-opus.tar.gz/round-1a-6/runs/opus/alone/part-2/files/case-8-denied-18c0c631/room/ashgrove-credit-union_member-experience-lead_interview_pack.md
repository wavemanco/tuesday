# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of interviews:** 5 December 2026, three rounds in one day · **Mode:** loop (one shared fit snapshot, then a mini-pack per round)

| Round | Length | Who | What it holds, per the recruiter |
|---|---|---|---|
| 1 | 30 min | The recruiter | Screen |
| 2 | 45 min | Head of Member Services, who would be your manager | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | Values round scored against the four values, including "a 20-minute case on a complaint escalation" |

Interviewer names are not yet assigned, so there is no interviewer read; the personas below rest on each round's role.

---

## How to use this pack

- **Personas** describe *how* a question is asked (friendly, sceptical, probing, scored against values). **Types** describe *what* is being scored:
  - **VAL** — does your past behaviour show Ashgrove's four published values
  - **EXP** — does what you say about your experience survive follow-up questions
  - **JD** — can you do the listed job, including the parts you haven't done
  - **CO** — do you know Ashgrove's strategy and can you think at its level
  - **CASE** — a live problem from the role, reasoned through out loud
- **Provenance labels:** `[grounded]` = traceable to something you or the recruiter gave me; `[inferred]` = this pack's own derivation, named; `[generic]` = a role-family pattern, useful rehearsal, no claim about Ashgrove.
- **Answer slots** are instructions for your answer in the interview, with two honest branches. Fill them from what you actually did. If the practice didn't exist or wasn't yours, the second branch is the answer.
- Guidance is scaffolding, not a script. Say it in your own words.
- The four sentences in the fit snapshot's evidence column are everything this pack knows about your past. Everything the pack coaches about your experience comes from them.

---

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your sentence already clears the years. Say it in your own terms and let the panel map it: "I've spent six years in retail banking, the last three as a branch supervisor." Don't swap in the JD's phrase "customer operations" for your own history |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [inferred] | discovery | Your material says "formal", not "regulated", so the words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's "regulated complaints" line makes a probe on the rules behind that log likely. If those complaints were handled under regulatory rules or deadlines, say which ones and what they changed in how you handled them, in your own words. If they weren't, or you don't know which rules applied, say so plainly and describe the log as you handled it |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | One branch's log, not a process across branches. That limit is the pack's observation; your words are the quote at its own scope. Answer slot: "end to end" makes a probe on which steps of a complaint were yours likely. If you took complaints from first contact through to resolution, say which steps were yours. If some steps sat with someone else, say who and stay with what you handled |
| F4 | "…and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I haven't worked in a contact centre." Then how you'd learn it, said as a plan and never as a past. No claim to contact-centre work, and nothing added to make the gap feel smaller. Highest-ROI rehearsal: B2 |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | A monthly complaints spreadsheet you built. Your material doesn't say what it measures. Answer slot: if it counts complaint volumes or resolution times, say how each one is counted. If it tracks other things, name them and stay with those. One regional manager uses it; keep it at that scope |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | "Spreadsheet" doesn't say which tool. Answer slot: if you built it in Excel, say so and name the parts of Excel you actually used. If you used another tool, name it plainly |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | You trained new tellers on an existing script; the role coaches supervisors. Words: "I trained new tellers on our escalation script." Don't say you wrote it. Answer slot: if you have helped a fellow supervisor with an escalation, say what happened and what part was yours. If not, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I haven't presented above regional level." Then your preparation plan, as a plan. Your material doesn't show whether you've presented *at* regional level. Answer slot: if you have presented to your regional manager or a regional group, say what and to whom. If not, say so plainly |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have passed branch complaints or member feedback to a digital or app team, or worked on an online journey, say what it was and what part was yours. If not, say so plainly and go straight to how you'd work with them (C3) |

---

## Grounding brief

From the strategy brief Ashgrove published in July 2026, about four months old. Learn the vocabulary so you sound current. If something newer comes up in an interview, take the interviewer's version and don't correct them.

| Strategy point | Where it touches this role | Questions | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | The JD's self-service line. Complaints show whether digital journeys work for members | C2, C3 | [grounded] strategy brief |
| Consolidate eight branches into five hubs over 2027 | Complaints across branches will change shape during the move. Your panel are branch managers, so the plan is close to their own work | C5, panel reverse questions | [grounded] strategy brief; the closeness to the panel is [inferred] from their roles |
| Launch a small-business lending product in Q1 2027 | A new product brings new complaint types into the process you'd own | HM reverse question 6 | [grounded] strategy brief |
| Main competitive pressure: app-only banks | Members compare Ashgrove's service with app-only banks; complaints are where that comparison shows up | C2 | [grounded] strategy brief, the link to complaints [inferred] |

---

# Round 1 — Recruiter screen (30 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | High: the recruiter-screen prior, and 30 minutes leaves little room for more | Pre-script a 90-second arc (A1) from your four sentences; treat every casual question as scored |
| Skeptic (light) | Knockout check against the JD's hard requirements | Medium: recruiters screen the requirements list | Know your F2 answer slot cold before the call |

### Question bank — Conversational (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in three beats, all from your sentences: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with one line on why this role, in your own words. Add no titles, dates or numbers these sentences don't hold | F1, F2 and F5 carry the experience; the opener sets how every later answer is heard. EXP because the recruiter checks it against the JD as you speak |
| A2 | "Why Ashgrove, and why a credit union?" | VAL | [grounded] | Answer slot: give your actual reason, in your own words. If one of the four values genuinely drew you, name it by its official name ("Members First, Always", for example) and say why in a sentence. Don't recite all four. If one of the strategy brief's priorities is part of the reason, name it | The values page and strategy brief are raising sources; a recruiter checks motivation before passing you to the manager. VAL because the answer is heard against the published values |
| A3 | "Why this role?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: give your own reason. If it connects to the parts of your work your sentences name (the complaints log, the escalation-script training, the spreadsheet), say how in your own words, at their scope: one branch's log, new tellers, the spreadsheet one regional manager uses | F2, F7 and F5 are the bridge to this role, so say them at their real size here and the later rounds won't catch a bigger version |
| A4 | "What salary are you looking for?" | JD | [grounded] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | A standard screen logistics item; the only safe answer is yours |
| A5 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period | A standard screen logistics item |
| A6 | "The role covers branches and the contact centre. How do you feel about travelling between sites?" | JD | [grounded] | Logistics slot: give your actual answer. If you don't know where Ashgrove's sites are, ask the recruiter | The JD's "across branches and the contact centre" makes this likely; the recruiter checks it before the manager round |
| A7 | "Why are you looking to leave?" | EXP | [grounded] | Logistics slot: give your own reason, in your own words, in a sentence or two | A standard screen item. EXP because it's about your history |

### Question bank — Skeptic, light (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Lead with the quote's first half: "I handled the branch's formal complaints log." Then F2's answer slot: if those complaints fell under regulatory rules or deadlines, say which and what they changed in how you handled them. If they didn't, or you don't know which rules applied, say so plainly and describe how you handled the log. Don't upgrade "formal" to "regulated" unless that's what it was | F2 is a named JD requirement and the likeliest screen knockout. JD because it scores a stated requirement; `[inferred]` because the link from "formal" to "regulated" is the pack's to name, not yours to assume |

### Reverse questions — Round 1

| Question | Why it lands |
|---|---|
| "What does the 20-minute case look like: is the scenario given on the day, and is there anything to read beforehand?" | It's the graded deliverable, and the answer changes how you use your prep days |
| "How do the panel score against the four values: one value per question, or across the whole hour?" | It shapes how you spread the four stories in D3–D6 |
| "Is this a new role or a replacement?" | It tells you whether "own the complaints process" means running a process that exists or building one |
| "Who would this role work with day to day across the branches and the contact centre?" | It gives you real names and teams to use in C1 |
| "What happens after 5 December, and when would I hear?" | Basic logistics, and asking about them sounds organised |

---

# Round 2 — Head of Member Services, your future manager (45 min, "mostly behavioural")

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F4, F7, F8 | High: the hiring-manager prior, and your manager carries the risk of the gaps | Rehearse B2 until it's boring: plain acknowledgment, then what your sentences carry, then a plan |
| Values / Behavioral | "Tell me about a time…" | High: the recruiter's "mostly behavioural" | Pick your stories in advance (D1, D2). "We" for context, "I" for what you did |
| Case / Strategist | First-90-days, strategy-linked problems | Medium: the hiring-manager prior, but the recruiter's framing pulls it down | Clarify, then structure, then answer; use Ashgrove's own words (hubs, self-service, members) |
| Data-Driven Prober | Your spreadsheet, how you'd count resolution time | Medium: monthly reporting is a core JD line | Know what your spreadsheet does and doesn't measure (G1) |
| Pressure | Pushback on your answers | Low: nothing in the recruiter's description suggests it | Hold through two follow-ups on B2 |

### Question bank — Skeptic (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B2 | "You haven't worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | **Highest-ROI prep in this pack.** Open with the acknowledgment, before they finish pushing: "I haven't worked in a contact centre." Then hold on what you can stand behind: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then the plan, as a plan: in the first weeks you'd sit with contact-centre agents, listen to complaint calls, read recent cases, and ask where complaints get stuck between the contact centre and the branches. Name the limit yourself: you'd be learning the contact-centre side from the people who do it. Answer slot: if any complaints in your branch log arrived by phone or were passed over from a contact centre, say so; if not, don't stretch it. **Follow-up 1**, "Why would branch experience carry over?": don't claim it does. Say what you'd bring (the log, the escalation training) and what you'd have to learn. **Follow-up 2**, "So we'd be paying you to learn?": hold on the parts of the role your sentences cover (F2, F5, F7), concede the contact centre is a ramp, and give your own honest estimate of how long it would take. Never fold into "I'm a quick learner" in place of the plan | F4 is a gap you named yourself and the role names the contact centre explicitly, so your future manager will raise it in some form. Deepest rehearsal because a calm, specific acknowledgment changes how the rest of the interview goes. JD because it scores a stated responsibility |
| B3 | "This role coaches branch supervisors on escalations. You've trained new tellers. What's different about coaching supervisors?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Stay with your sentence: "I trained new tellers on our escalation script." F7's answer slot: if you've helped a fellow supervisor with an escalation, say what happened and what part was yours. If not, say so plainly. Then reason out loud about the difference, as a view, not a past: tellers need the script; supervisors already know it and need help with judgement, meaning when to depart from it, when to escalate early, and how to tell a member no in plain words | F7 is a transferability gap the JD names directly. JD content with CASE delivery: the second half is live reasoning |
| B4 | "You'd present monthly complaints reporting to senior leaders. You haven't presented above regional level. How would you prepare?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Acknowledge: "I haven't presented above regional level." F8's answer slot: if you've presented to your regional manager or a regional group, say what and to whom. If not, say so. Then the plan: one headline message per report; the numbers in plain words ("if a member needs it explained twice, we wrote it wrong" works for leaders too); what changed since last month and what is being done about it; rehearse with your manager before the first one and ask for feedback after. The spreadsheet stays at its scope: you built it, and your regional manager uses it | F8 is a stated gap behind a stated requirement, and your future manager would be the person putting you in front of those leaders. JD because it scores "confident presenting to senior leaders" |

### Question bank — Values / Behavioral (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint you handled that was hard to resolve." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Selection scaffold: pick one complaint from the branch's formal log that you remember clearly. It needs what the member was unhappy about, what *you* did (separate from what others did), how it ended, and one thing you'd do differently. Tell it in order. If no single case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F2 is the experience this round will mine. A "mostly behavioural" round asks for specific cases, and a pre-chosen one prevents a vague answer. EXP because the follow-ups test what was yours |
| D2 | "Tell me about a time an escalation didn't go the way it should have." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Selection scaffold: pick a real escalation: one that went up too late, too early, or to the wrong place. It needs what happened, what your part was, and what changed afterwards. Answer slot: if what you learned changed how you trained tellers on the script, say how. If it didn't, don't link them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation-coaching line and F7 make this likely. A story where something went wrong reads as candour, and as Own the Fix too |

### Question bank — Data-Driven Prober (G)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Beats your sentence states: you built it, it's monthly, your regional manager uses it. Then the slots the JD raises. *What it tracks:* if it counts complaint volumes or resolution times, say how each is counted; if it tracks other things, name them. *Tool:* if it's Excel, say so and name the parts of Excel you used; if not, name the tool. *Use:* if you know what your regional manager uses it for, say so; if you don't, say that plainly | F5 and F6 rest on this one sentence, so a prober will go two levels into it. EXP because what you built is the claim being tested |
| G2 | "How would you report resolution times so senior leaders can act on them?" | JD | [generic] | Structure it: say when the clock starts and stops; report the typical time and the long tail, not just an average; split by channel (branch vs contact centre) and by complaint type; show the trend against last month; list what is open past its target; end with one "so what" line. Name the weakest part yourself, before they do: if branches and the contact centre start the clock differently, the comparison isn't fair until that's fixed. Make no claim about your past here | The JD's reporting line asked as a live problem. `[generic]` because the method is a common reporting pattern, not an Ashgrove fact |

### Question bank — Case / Strategist (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your first 90 days: how would you get a picture of complaints across the branches and the contact centre?" | CASE | [generic] | Clarify first: what reporting exists today, and who owns each part. Then four strands. *Listen:* visit branches, sit in the contact centre. *Data:* pull the current logs and check that branches and the contact centre count things the same way. *People:* branch supervisors, contact-centre leads, digital teams. *Fix:* one visible quick fix, tracked to done (Own the Fix). Close with what your first monthly report would show. No claims about your past | The JD's "end to end across branches and the contact centre" as a plan. CASE because it scores structure |
| C2 | "We want 40% of member service through digital channels by 2028. What does that mean for complaints?" | CO | [grounded] | Think aloud in three parts. Complaints *about* the digital journeys themselves. Members who don't want to move channel; tie this to "Neighbours, Not Numbers". Complaint patterns as input to the digital teams' self-service journeys, so the app fixes what members complain about. Mention that app-only banks set the expectations members bring. Challenge one premise respectfully: 40% is a channel target, and complaints are how you'd know whether it's working for members | The strategy brief's headline target plus the JD's self-service line. CO first, CASE delivery: it tests whether you can think at Ashgrove's level |
| C3 | "How would you work with our digital teams on self-service journeys?" | JD | [grounded] | F9's answer slot first: if you've passed branch complaints or member feedback to a digital or app team, say what and what part was yours. If not, say so plainly. Then the plan: a regular feed of the top complaint reasons tied to digital journeys; test new journeys against real complaint cases; check the wording against "Plain Words"; report back whether complaints fell after a change | F9 is silent, and the JD names this responsibility, so a manager will ask. JD because it scores a listed duty |

### Reverse questions — Round 2

| Question | Why it lands |
|---|---|
| "What would good look like six months into this role?" | It gives you their success measure in their own words |
| "Where do complaints get stuck today between the branches and the contact centre?" | It's the problem C1 plans for, and it shows you're already thinking about the job |
| "How will the 2027 hub consolidation change complaint handling, and how early would this role be involved?" | It uses the strategy brief and asks about timing, the part only they know |
| "What do senior leaders do with the monthly complaints report today?" | It tells you what your B4 audience actually needs |
| "Where would you want me to lean on you while I learn the contact-centre side?" | It continues the candour of B2 and asks for help with the gap you named |
| "Will complaints about the new small-business lending product go through the same process?" | It shows you've read the brief and are thinking about the complaint types coming in Q1 2027 |

---

# Round 3 — Panel of two branch managers (60 min, values round + 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One question per value, scored | High: the recruiter says they "score against the four values" | Have one story or honest scaffold per value (D3–D6, cheat sheet below) |
| Case / Strategist | The 20-minute escalation case | High: announced by the recruiter | Use the case build below; think aloud |
| Peer Evaluator | "How would you work with us and our supervisors?" | Medium: the role coaches *their* supervisors, so they're weighing whether you'd help or get in their way | Reciprocity: what you bring their branches, not only what you need |
| Pressure | "Why you over one of our own?" | Low: a panel stem, kept for composure | Pause, then anchor in your sentences (E1) |
| Skeptic | The weakest-part question | Low: Round 2 covers the gaps; the panel may revisit one | Pick one stated gap and a plan (B5) |

### Question bank — Values / Behavioral (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Members First, Always. Selection scaffold: the formal complaints log is the natural place to look. Pick a case where the member's view changed what you decided. It needs what the member wanted, what the easier internal option was, what you chose, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | One VAL per published value, since the panel scores all four. The theme is the value's own words |
| D4 | "Tell me about a time you had to explain something more simply because it didn't land the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Plain Words. Your sentence gives the setting: training new tellers on the escalation script. Answer slot: the value ("if a member needs it explained twice, we wrote it wrong") makes a probe on rewording likely. If a teller or a member needed something explained twice and you changed how you explained it, say what you changed. If not, say so plainly and pick a member conversation instead, or say how you'd handle it | F7's training is the nearest setting your material carries; the slot keeps it honest. VAL because Plain Words is scored |
| D5 | "Tell me about a time knowing your local community changed how you handled something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Neighbours, Not Numbers. Selection scaffold: pick one moment from your branch years where knowing the member or the town changed what you did. It needs the local detail, what you did differently because of it, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Expect a follow-up on the hub plan (C5) | This is the value branch managers live with; the 2027 consolidation makes it a live topic for this panel. VAL because it's scored |
| D6 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Own the Fix. Answer slot: the value makes a probe on a problem you carried through likely. If the spreadsheet was built because of a problem you noticed, say what the problem was, what you did and where it stands now. If it wasn't, don't turn it into one: pick another problem you found and saw through, or say so plainly and say how you'd handle one | F5's spreadsheet is the only thing your material says you built; the slot stops it from becoming a fix story it wasn't. VAL because Own the Fix is scored |

### Question bank — Case / Strategist (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "A member has been passed between a branch and the contact centre three times about the same problem and now wants to escalate. Walk us through what you'd do." | CASE | [generic] | Run the case build below: clarify, member first, own it, fix the cause, close in plain words. Use the four value names out loud as you go: this round scores against them | A likely shape for the recruiter's "complaint escalation" case, using the JD's branch and contact-centre split. `[generic]` because the panel's actual scenario is unknown |
| C5 | "During 2027 we're consolidating eight branches into five hubs. A member whose branch is moving into a hub complains they're being left behind. How do you handle it, and what do you tell the branch teams?" | CO | [grounded] | Member first: listen, find what the member actually loses (a person they know, a short trip, cash access) and what Ashgrove can offer. Neighbours, Not Numbers: treat the town's view as real information, not noise. Plain Words in what you send. For branch teams: one clear script on what's changing and where complaints go, and a log of these complaints so the pattern reaches the people planning the hubs. Don't speculate about which branches are affected | The strategy brief's consolidation applied to a complaint, in front of the people it affects. CO content, CASE delivery |

### Question bank — Peer Evaluator (H)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'd be coaching our supervisors on escalations. How do you do that without undermining us as their managers?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Propose principles rather than pretending to know the arrangement: agree the coaching plan with the branch manager first; coach on cases, not on people; tell the manager what you've covered; let them own the team's day-to-day. Your sentence sits at its scope: "I trained new tellers on our escalation script." Don't describe it as coaching supervisors | The JD's coaching line in collegial form, from the people whose teams you'd coach. CASE because it asks how you'd work, not what you did |
| H2 | "If one of us thinks a complaint can be settled in the branch and you think it should escalate, what happens?" | CASE | [generic] | Principles: start from what the member needs (Members First, Always); agree the facts before the decision; if it's still split, say what the escalation criteria are and who decides; whoever decides, record why; follow up together afterwards. Show both spine and tact: you'd say so if you disagreed, and you'd keep the relationship | A seam question between the role and branch managers. `[generic]` because it's a pattern, not an Ashgrove process |

### Question bank — Pressure (E) and Skeptic (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over one of our own branch supervisors?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause, then hold on your three sentences: six years in retail banking, three as a supervisor; the branch's formal complaints log and training tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Concede without folding: an internal candidate would know Ashgrove's branches better, and you'd spend your first weeks learning them (C1). Don't run down internal candidates and don't claim to know them | A Pressure stem that a panel of branch managers could plausibly use. JD because it tests fit against the role |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level" | Pick one of the two gaps you named yourself, not a fake weakness: "I haven't worked in a contact centre," or "I haven't presented above regional level." Give the plan for it (B2 or B4) in three sentences. Don't name both and then add more | F4 and F8 are your sourced gaps; a panel may test whether you're as honest as you were in Round 2 |

### Values cheat sheet

From the values text you copied from ashgrovecu.org/about/values on 26 November 2026. Learn the official names word for word.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, not the organisation's | D3, selection scaffold: a case from your formal complaints log (F2, "I handled the branch's formal complaints log and trained new tellers on our escalation script") where the member's view changed your decision. If none comes to mind, say so plainly and give the nearest thing your material carries, or how you'd handle it |
| Plain Words | If it needs explaining twice, the explanation is the problem | D4: the setting is F7, "I handled the branch's formal complaints log and trained new tellers on our escalation script". Whether you ever reworded something is an answer slot: if yes, say what you changed; if not, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town | D5, selection scaffold from your branch years (F1, "6 years in retail banking, the last 3 as a branch supervisor"). If none comes to mind, say so plainly and say how you'd handle it |
| Own the Fix | Whoever finds a problem keeps it until it's solved | D6: F5, "I built the monthly complaints spreadsheet our regional manager uses". It's a fix story only if it was one: answer slot, both branches honest |

### The 20-minute case: build section

**Grounded facts to build on:** the JD's "Own the member complaints process end to end across branches and the contact centre" and "coach branch supervisors on escalations"; the four published values; the 2027 hub plan. About you: F2, "I handled the branch's formal complaints log and trained new tellers on our escalation script". Use it only at its scope.

**A 20-minute shape:**

1. **Clarify (2–3 min):** what has happened so far, what the member wants, what has been promised, any deadline, who's involved.
2. **Members First (4 min):** what you'd do for the member today: one owner, contact them, say what happens next and when.
3. **Own the Fix (5 min):** you keep hold of it across the branch and the contact centre until it's closed; no more passing it between them.
4. **Root cause (4 min):** why it bounced three times; what you'd check in the logs; whether it's a one-off or a pattern for your monthly report.
5. **Plain Words close (3 min):** the final reply to the member in plain language; what you'd tell the branch supervisor as coaching.

**Defensible theses, each with its concession:**

| Thesis | Mandatory concession |
|---|---|
| Fix the member's problem before fixing the process | Before the facts are clear you can't promise the member an outcome, only a next step and a time |
| One named owner from now on beats a better hand-off script | One owner per complaint costs capacity; at contact-centre volume that has a limit, and you'd say you'd need to learn where it is |
| The case is data: log why it bounced so it reaches the monthly report and the digital teams | In 20 minutes you can't know the root cause, only what you'd check first |

**Differentiation:** the consensus answer is "apologise, escalate, resolve". Go beyond it by naming the four values out loud at the step where each applies, and by ending on what changes so the next member isn't passed around three times.

**The anti-pick:** don't promise compensation or overrule the branch on the spot to make the member happy. Say you'd check what the process allows and come back within a stated time. Branch managers will be watching whether you'd undermine their teams.

### Reverse questions — Round 3

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your supervisors?" | Reciprocity: it asks what you can give their branches |
| "Which escalations reach you today that you think shouldn't?" | It tells you where the coaching should start, from the people who see the result |
| "What does 'Neighbours, Not Numbers' look like in your branches day to day?" | It asks about their value in their own words, which is the round they're scoring |
| "What would you never want the complaints lead to do in your branch?" | It shows you're thinking about their turf before you've arrived |
| "As the hub plan goes ahead in 2027, what are members in your towns asking about?" | It's a current topic they know first-hand, and it ties to C5 |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B2, C1, C4 |
| Report monthly on complaint volumes and resolution times | G1, G2, B4 |
| Coach branch supervisors on escalations | B3, H1, H2, D2 |
| Work with digital teams on self-service journeys | C2, C3 |
| 4+ years in financial-services customer operations | A1, E1 |
| Experience handling regulated complaints | B1, D1 |
| Confident presenting to senior leaders | B4, B5 |
| Comfortable with Excel reporting | G1 |

---

## Prohibited claims

Things this pack will not coach, and why. Under pressure these are the versions that come out of your mouth. Don't let them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or managed complaints across several branches | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." Whether it was regulated is F2's answer slot, filled only from what was true |
| Wrote or designed the escalation script | Inflated form of F7 | "I trained new tellers on our escalation script." Your material says you trained people on it, not that you wrote it |
| Coached supervisors | Inflated form of F7 | "I trained new tellers on our escalation script." Whether you've helped a fellow supervisor is F7's answer slot |
| The spreadsheet is used across the region or drives regional decisions | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." One manager uses it |
| Contact-centre experience | Negative you stated, F4 | "I haven't worked in a contact centre." No slot |
| Presented to senior leaders or executives | Negative you stated, F8 | "I haven't presented above regional level." No slot |

---

## Sources

**Provided documents**

- The job description, pasted
- Ashgrove's values text, which you copied from ashgrovecu.org/about/values on 26 November 2026 and pasted (not fetched by me)
- The recruiter's email describing the three rounds
- The points you gave from Ashgrove's July 2026 strategy brief, which the recruiter sent you
- Your background, from your message

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted fixes the cheat sheet and D3–D6 |
| 2. Ashgrove Credit Union interview process, member services | skipped | The recruiter's email fixes the three rounds, their lengths, the case and the values scoring |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 strategy brief, under six months old, fixes the grounding brief, C2 and C5 |
| 4. Interviewer name and Ashgrove Credit Union | n/a | No names yet, so there was no query to form; there's no interviewer read, and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Your answers to the answer slots** (whether the log was regulated, what the spreadsheet tracks and in which tool, any supervisor coaching, any regional presenting, any digital work) → F2, F5, F6, F7, F8 and F9 regenerate from your own words, and B1, B3, B4, G1, C3, D4 and D6 move from slots to mapped stories
- **Your CV** → dates, titles and any lines your message didn't mention go into the fit snapshot's evidence column
- **Interviewer names, once assigned** → a "Reading the interviewer" section, persona weights from each person's public professional footprint, and a reverse question tied to their own path
- **How much prep time you have before 5 December** → a prioritised prep schedule tied to question IDs
- **The full strategy brief text** → Ashgrove's own vocabulary and any headline numbers in the grounding brief
- **One email to the recruiter about the case format** → the case build tuned to the actual scenario type and any pre-reading
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → Ashgrove news since July, any candidate reports on its interviews, and recent organisational context for the role
- **A `tuesday-dossier.md`** → verified evidence and agreed limits for each gap, so the highest-ROI objection and the prohibited list come from checked evidence rather than this pack's reading
