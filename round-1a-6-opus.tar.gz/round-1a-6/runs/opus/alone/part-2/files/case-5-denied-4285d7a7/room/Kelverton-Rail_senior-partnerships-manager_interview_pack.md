# Kelverton Rail — Senior Partnerships Manager — second-round prep pack

**Round:** 60-minute panel on Tuesday. **Deepa**, VP Partnerships, would be your manager. **Ross** is Commercial Director. The first 15 minutes are your spoken POV, with no slides. The rest is Q&A, and Ross "will push on commercials" (the recruiter's words).

**Built from:** your message and the recruiter's email as you quoted it. Web research was refused in this session, and I have not seen the market report. Every claim here about Kelverton comes from your own description. Anything about rail or partnerships in general is labelled `[generic]`.

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what register. **Types** describe what the answer is scored on.
- Type key:
  - **VAL**: whether your past behaviour shows the values they care about.
  - **EXP**: whether your stated experience holds up when probed, and how much of it was yours.
  - **JD**: whether you can do the job as stated, gaps included.
  - **CO**: how well you know the company and its strategy.
  - **CASE**: how you structure a live problem from the role.
- **Provenance labels:**
  - `[grounded]`: traces to your message or the recruiter's words.
  - `[inferred]`: a derivation, with its source named.
  - `[generic]`: a role-family pattern that asserts nothing about Kelverton or about you.
- **Answer slots** are instructions for your answer on Tuesday, and you don't need to reply to them here. Each has two honest branches. Use the one that is true.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage — four hours

| Order | Block | Time | What to do |
|---|---|---|---|
| 1 | POV build | 75 min | Pick your definition, two theses and the anti-pick from the **Graded deliverable** section. Fill each slot with the report's own content. Say it out loud twice, timed, and aim to finish at 14 minutes |
| 2 | Highest-ROI objection | 40 min | Rehearse C1 until it's boring, then B1 and B2. Write down what you actually know about how the £4M and the 6-to-40 were counted |
| 3 | Ross's commercials | 30 min | B3, B4, B5 and D3, out loud, structure first |
| 4 | Rail and operator credibility | 25 min | C2, C3, C4 and D1 |
| 5 | Reverse questions | 15 min | Choose three, with one each for Deepa and Ross |
| 6 | Full run-through | 40 min | POV plus five random questions, recorded or drilled with me. Fix only the top two problems |
| 7 | Re-read the report | 15 min | Note just three things: one number, one segment or operator type, and one claim you'll respectfully push on |

Everything else in this pack is insurance.

---

## Fit snapshot

There is no JD, so the requirements come from the recruiter's own words (`[grounded]`) or are role-family requirements in plain prose (`[generic]`).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company, not operator partnerships in rail. The words stay at that scope: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the POV brief makes a question about how you set direction for that channel likely. If some decisions about the channel's direction were yours, say which ones and how you made them, in your own words. If none were, say so plainly and stay with the channel you ran |
| F2 | "land on what it means for the operators themselves" — recruiter | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Network planning for bus and light rail, done in consulting, is next door to train operating companies but doesn't reach them. "From the other side" is your phrase, and this pack doesn't decide which side that was. Words: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: the recruiter's close on operators makes a probe on what you saw of operators' work likely. If operators were your clients or counterparts, say who and what you saw, in your own words. If they weren't, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | This is influenced revenue, not revenue against a quota, and "roughly" stays. Words: "roughly £4M of influenced revenue." Answer slot: the recruiter's note makes a probe on the figure likely. Be ready to say, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know exactly how it was counted" is an honest answer if it's true |
| F4 | Carrying a direct revenue target, common for senior partnerships roles | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | Words from your own sentence: "I haven't carried a direct quota. My number was influenced revenue." Then say how you would take one on, framed as a plan and never as something you've done. Add nothing to make the gap sound smaller |
| F5 | Commercial experience in the rail sector, common for rail-tech partnerships roles | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | Words from your own sentence: "I haven't sold into rail specifically." Your F2 line is the adjacent work, at its own scope. Then a ramp plan, framed as a plan |
| F6 | Building and scaling a partner programme | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap. Nothing has been inspected behind the line, so expect a probe. Lead with it on its own terms: running the ISV channel, 6 partners to 40. Which part of that growth was yours is B2's and D2's slot |
| F7 | Senior-level partnerships experience | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap: "nine years in partnerships" covers it. Don't spend airtime defending seniority |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 POV on operator partnerships | Graded deliverable, A1, A2, A3, A5, D3 |
| F2 What it means for operators | Graded deliverable close, A2, C2, C3, H2 |
| F3 Commercials | B1, B3, B4, B5, C1 |
| F4 Direct quota | C1, B4 |
| F5 Rail commercial experience | C2, C3, D1 |
| F6 Scaling a partner programme | A3, B2, D2 |
| F7 Seniority | E1 |

---

## Graded deliverable — the 15-minute POV

**The brief, in the recruiter's words:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

### What you can build on

- **Kelverton, as you described it:** "UK rail-tech, ~600 staff, they sell scheduling software to train operating companies". This is your own description, and it's the only company fact in this pack.
- **The strategy team's market report.** You've read it and I haven't, so every report-shaped item below is a slot for you to fill from it. Deepa and Ross have the same report, and probably so do the other candidates. Use it to show you're grounded, then depart from it (see Differentiation).
- **About you:**
  - F1/F6: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
  - F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
  - Mention each in one sentence at most, at its own scope. The POV is about their operators, not your CV.

### Define the term in the first minute

"Operator partnerships" can mean two different things:

- **Deeper strategic relationships with operator customers**: co-development, joint roadmaps, and new commercial models.
- **Partners who serve operators alongside Kelverton**: integrators and adjacent software vendors.

Say which one you mean, or that you mean both in sequence, and why. This is the one premise worth challenging, and naming it early reads as clarity rather than a dodge. If the report uses one meaning, use its wording.

### Suggested 15-minute shape

| Time | Beat |
|---|---|
| 0:00–1:30 | Your definition, plus the whole answer in three lines: the three moves, and the one change operators would feel |
| 1:30–3:30 | Where Kelverton is: one point from the report you agree with, stated as the report's ("your strategy team's report says…"), and one place you see it differently, with your reason |
| 3:30–11:00 | Three moves in sequence: months 0–6, 6–12 and 12–18 |
| 11:00–14:00 | What it means for operators: one concrete operator-side change per move. This is the requested close, so give it real time |
| 14:00–15:00 | How you'd know it's working, and what you'd test in your first 90 days. Stop on time, because finishing early reads as control |

### Thesis options — pick two or three `[generic]`

These are general partnership patterns, not facts about Kelverton or UK rail. Each has a mandatory concession: say it before they do.

| Thesis | The move | Concession to say out loud | What operators get |
|---|---|---|---|
| T1 Depth before breadth | A small cohort of operators as design partners: joint roadmap input and early access, in exchange for data, feedback and a reference | Design partners pull the roadmap toward bespoke work. You'd protect it with a written partner charter and a cap on custom commitments | Their planners help shape the tool they'll be living in, and they get fixes and features earlier |
| T2 An ecosystem around the operator | Partners for the systems operators run alongside scheduling, so that integration is a product rather than a project | It adds partner-management cost, operators may not want more vendors in the room, and you'd first check what integrations Kelverton already has | Fewer one-off integration projects, and data that moves between their systems without manual rework |
| T3 A commercial model that shares outcomes | Pilot a partnership tier where part of the fee is tied to an operator-side result both sides agree to measure | Ross will say this exposes revenue to things Kelverton doesn't control. Pilot it with one cohort, with a floor and a defined measurement method | They pay more only when it works, which makes the case easier for their own approvers |

T2 is the thesis closest to the work in F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." You can say you ran an ISV channel. Don't present it as proof that T2 will work here. Describe what you did and let them draw the connection.

### Differentiation

- The consensus answer is whatever the report recommends. Bring one consensus item to show you read it, then one divergence with a reason.
- **The anti-pick:** "What I would not do in the first 18 months is chase partner count." Concession: breadth matters later, once depth has shown what a good partner looks like.
- The anti-pick shows the judgement to say no, which a senior partnerships role needs.

### The close — "what it means for the operators themselves"

- Give one sentence per move, in the operator's terms rather than Kelverton's.
- Answer slot: use the operator problems the report itself names. Where the report names none, say what you would go and find out from operators in your first 90 days. Don't supply a rail statistic the report doesn't contain.
- If you use your F2 line, keep it to "five years in transport consulting, on bus and light rail network planning". Don't stretch it to heavy rail or to working inside an operator.

---

## Reading the interviewers

This section draws only on the recruiter's email. The public-profile searches were refused, so there are no mirror opportunities: no shared career jump is offered.

| Interviewer | What the recruiter said | Practical implications |
|---|---|---|
| Deepa, VP Partnerships | "your future manager" | Your POV is about the area she owns, so treat the current state as her design. Frame changes as building on it, and ask before critiquing. Expect her to test whether she can delegate the strategy to you (A bank) and what it's like to manage you (G bank) |
| Ross, Commercial Director | "Ross will push on commercials" | Expect numbers to be probed down to their assumptions (B bank) and pushback under time pressure (D bank). Answer in commercial terms: who pays, for what, when, and what it costs Kelverton |

---

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Deepa extends your POV into live problems | Very high. She's the hiring manager, and the round opens with a strategy deliverable | Clarify, then state the objective, segment, give the approach, the metrics and the risks. Think aloud, and challenge one premise respectfully |
| B Data-Driven Prober | Ross takes the £4M and the 6-to-40 apart | Very high. The recruiter named commercials as his focus, and F3 is the headline figure | Know what you can and can't say about how each number was counted. Name the weakest assumption first |
| C Skeptic | Either of them, on quota, rail and the ISV-to-operator jump | High. F4 and F5 are stated gaps, and F1 and F2 are adjacencies | Rehearse C1 until it's boring. Build bridges only from your quoted lines, and say the limits plainly |
| D Pressure | Ross, time-boxed, questioning the plan | Medium-high. "Push" in the recruiter's note signals it | Pause, restate the question, hold through two follow-ups, then concede something specific |
| E Conversational | The opener, or a chat about the report | Medium. Second rounds often still open warm, and it's scored | A 90-second "journey" arc, and treat casual report questions as scored |
| G Peer Evaluator | Deepa on how you'd work with Ross and with sales | Medium. The panel pairs partnerships with commercial | Propose principles for the seam between teams, with reciprocity |
| H Values/Behavioral | One or two behavioural probes | Low. No values round is named, so no values cheat sheet is included | Selection scaffolds with honest branches |

---

## Question banks

### A — Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you could only do one of those moves in the first six months, which one, and what would you stop to make room for it?" | CASE | [generic] | Pick one thesis and say why it comes first: it unlocks the others, or it carries the least risk. Name something specific you'd deprioritise. Say what evidence in the first 90 days would make you switch. No claim about your past is needed | Prioritisation is the standard follow-up to any multi-move POV. CASE because it's a live decision about their plan |
| A2 | "Which operators would you start with, and how would you choose them?" | CASE | [generic] | Clarify first: do they want a named shortlist or the criteria? Give criteria: strength of the relationship, appetite to co-develop, timing in their contract or renewal cycle, and how visible a success would be to other operators. Say you'd test these against Kelverton's account data. If the report segments operators, use its segment names | Your T1 depends on choosing the cohort, so this is where Deepa tests whether the plan can be run. CASE |
| A3 | "Your background is ISV channels. Would you build an integration-partner programme around our operators, or is that the wrong model here?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer the strategy question on its merits, using T2 and its concession. On your background, say only what the quote carries: you ran an ISV channel at a payments company and took it from 6 partners to 40. Answer slot: if any choices about which partners to recruit or drop were yours, say what you weighed, in your own words. If none were, say so plainly and stay with running the channel. Name the difference between the two settings yourself: ISV partners and operators sit on different sides of the relationship | F1 and F6 are the evidence closest to T2, so it's the obvious bridge to test. CASE, delivered with EXP content |
| A4 | "Where does partnerships end and sales begin on an operator account?" | CASE | [generic] | Propose principles rather than claiming to know their seam. One owner per account relationship. Partnerships owns the partner-shaped parts: co-development terms, ecosystem partners, and the charter. Agree up front how jointly influenced revenue is credited. Ask how it works today | With partnerships aimed at customers, the overlap with sales is the obvious organisational risk. CASE |
| A5 | "What would you need to see in your first 90 days to know your POV is right?" | CASE | [generic] | Give three tests, one per move, each with a signal that would make you change course. Include a listening tour of operators and of Kelverton's own account teams. Make it clear your POV is a hypothesis you'd test | It checks whether you hold the POV as a hypothesis, which is what a manager wants. CASE |

### B — Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through the £4M. How was influenced revenue counted?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Start with the figure exactly as you hold it: "roughly £4M of influenced revenue". Answer slot, all in your own words: how it was counted, what it is sensitive to, which assumption behind it you would defend least (say it before he finds it), and which part was yours. If you don't know how it was counted, say so plainly. Don't round up, and don't relabel it as sourced or closed | F3's headline figure is the first thing a commercial director probes. EXP because it tests attribution |
| B2 | "6 partners to 40. How many of the 40 actually moved revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if you know how the revenue was spread across partners, say it in your own words. If you don't, say so plainly. Then say how the 40 were counted and which part of the growth was yours. Holding "6 to 40" exactly, with no embellishment, is the strong answer | F6's count is the second headline number, and partner count versus partner productivity is the classic follow-up. EXP |
| B3 | "What does the commercial model of an operator partnership look like: who pays whom, for what?" | CASE | [generic] | Structure it: the value exchange (what each side gives), the pricing levers (licence uplift, co-development contribution, outcome-linked component), the cost to Kelverton (product time, partner management), and the risk (bespoke drift, revenue volatility). Ask what Kelverton's current contract model is before proposing changes to it | This is Ross's native ground and puts T3 under load. CASE |
| B4 | "If we gave you a number for year one, what should it be measured on?" | CASE | [generic] | Propose layers: leading indicators (cohort signed, charter agreed, integrations live), then lagging ones (revenue from partnered operators, retention and expansion). Say you'd set the baseline from their data rather than pick a figure now. Don't name a number you can't back. If he wants a figure, say what you'd need to set one | It invites the quota conversation (F4) on your terms. CASE |
| B5 | "This plan costs money. What's the payback, and when would you kill it?" | CASE | [generic] | Name the costs, the signal you'd expect by month 6, and an explicit kill criterion. A pre-agreed kill point reads as commercial maturity | It tests whether you think like a budget owner. CASE |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Highest-ROI prep in this pack.** "You've never carried a quota. Your number was influenced revenue, and Ross's world is closed revenue. Why should we trust you with the commercials here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | **Name the limit first, before it's pushed:** "I haven't carried a direct quota. My number was influenced revenue." **Then hold on what's yours:** "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40, roughly £4M of influenced revenue." **First follow-up ("but influenced isn't closed"):** agree, then use B1's answer slot on how the figure was counted and which part was yours, in your own words. **Second follow-up ("so you've never been accountable for a number"):** hold with the same two sentences. Don't add to them, and don't recast influenced revenue as quota. **Then the plan, as a plan:** how you'd want a number set for this role (B4) and what you'd want reviewed monthly. Don't fold into apology, and don't inflate | F3 and F4 meet exactly where the recruiter said Ross will push, so this objection arrives in some form. JD because it scores a likely requirement of the role |
| C2 | "You haven't sold into rail. Why would an operator's commercial or planning director take you seriously?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Concede plainly: "I haven't sold into rail specifically." Then the adjacent work, at its own scope: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: if operators were your clients or counterparts, say who and what you learned about how they work, in your own words. If they weren't, say so and stay with the planning work. Then give a ramp plan: who you'd meet in your first month, and what you'd learn from Kelverton's own account teams | F5 is a stated gap, and F2 is the only adjacent evidence. JD |
| C3 | "Bus and light rail planning, from a consulting seat. How much of that carries over to heavy rail operators?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Say what the quote carries, and use "the other side" only if you can say which side you mean. Be explicit about what you don't know. The pack observes that heavy rail operators aren't part of your material. Answer slot: if something from that planning work bears on how operators schedule services, say what it is, in your own words. If you're not sure it does, say so and say what you'd need to learn | F2's adjacency is where an interviewer checks how much of the transfer is real. EXP |
| C4 | "Your ISV partners were businesses building on your platform. Our operators are customers. Isn't that a different job?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Agree that the relationship is different. That's the honest opening, and it disarms the question. Then F1's quote at its own scope. Answer slot: if any of the channel work looked like what Deepa means by operator partnerships, say which part, in your own words. If none did, say so plainly, then say what you'd carry over and what you'd have to learn | F1's transfer crosses the relationship axis, so this is the deepest version of the fit question. EXP |

### D — Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already sold to train operators?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, then three beats. First, what you've done: you ran an ISV channel and took it from 6 partners to 40. Second, what you'd bring: the POV in one line. Third, the limit, said before he does: "I haven't sold into rail specifically." Finish inside 60 seconds. Don't run down the hypothetical rival | Time-boxed comparison is the standard pressure move, and F5 is the obvious lever. JD |
| D2 | "That 6 to 40. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold: you ran the channel. Answer slot: say which parts of the growth were yours and which were the team's or the company's, in your own words. If you can't separate them cleanly, say that plainly. A precise split beats a big claim. Hold through a second push without upgrading the claim | It's the attribution stress test on F6. EXP |
| D3 | "Nice POV. Why would an operator partner with us rather than just buy software?" | CASE | [generic] | Restate the challenge, then hold the thesis: what the operator gets that a straight licence doesn't (from your close). Concede specifically, for example: "Some won't, which is why I'd start with a small cohort." Don't accept any premise about operators' finances that he hasn't sourced. Ask what he's seeing | It tests composure on your own deliverable. CASE delivery, pressure register |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. Why partnerships, why rail, why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc in time order: five years of transport consulting on bus and light rail network planning, then four years running the ISV channel at a payments company. Answer slot: why rail and why now, in your own words. This pack has none of your reasons, so don't borrow a reason that sounds good | It's the standard opener, and the motivation answer is scored even when asked casually. EXP |
| E2 | "What did you make of the report we sent over?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | One point you agree with, one divergence, and one question it raised for you, all taken from the report. Answer slot: the pack hasn't seen the report, so the content is yours. Don't recite its summary | It's an easy homework check that also tests judgement. CO |

### G — Peer Evaluator (Deepa as manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Ross and I will both have views on every operator deal. What happens when we disagree?" | CASE | [generic] | Principles: agree decision rights up front (partnership terms versus commercial terms), bring both views with a recommendation, escalate early rather than late. Ask how the two of them work today | The panel pairs the two functions, so the seam between them is live. CASE |
| G2 | "How do you handle credit when a partner-influenced deal closes through sales?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Your number was influenced revenue, so this is familiar ground. Answer slot: if you had a credit or attribution arrangement with sales, describe how it worked, in your own words. If you didn't, say so plainly and propose the principle you'd want here | It ties F3 to the working relationship. EXP |

### H — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you didn't fold, and a working relationship intact at the end. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you'd handle it | It's a persona stem, and a POV that challenges a report invites it. VAL |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric you gave up, and what the customer got. Ideally it echoes your operator close. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you'd handle it | It's a persona stem, and the recruiter's close on operators makes customer-first answers relevant. VAL |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (Deepa) "When you say operator partnerships, what's in scope today, and what would you most want to be different 18 months from now?" | It checks your POV's definition against hers and shows you're testing a hypothesis rather than defending it |
| R2 | (Ross) "How will commercial success in this role be measured: influenced, sourced, or a direct number?" | It brings up the quota question (F4) on your terms and shows you want to be accountable |
| R3 | (Deepa) "Which operator relationship today looks most like the partnership you want more of, and what made it work?" | It gets you a real case to build on, and she'll enjoy answering it |
| R4 | (Either) "What did the strategy team's report get right, and where does the commercial side see it differently?" | It shows you read the report critically and surfaces any tension between the two of them |
| R5 | (Deepa) "How do you and Ross split decisions on partnership commercials?" | It's about the seam you'd work inside, asked of your future manager |
| R6 | (Either) "Six months in, what would tell you this hire was the right call?" | It defines success in their words, which you can then reuse |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried or hit a quota | A negative you stated (F4) | "I haven't carried a direct quota. My number was influenced revenue." No slot |
| Has sold into rail | A negative you stated (F5) | "I haven't sold into rail specifically." No slot |
| Generated, sourced or closed £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is this pack's observation: the material says influenced. B1's slot asks only how the figure was counted and which part was yours |
| Personally recruited the growth from 6 partners to 40 | Inflated form of F6 | F6's quote at its own scope: running the channel, 6 partners to 40. D2's slot asks which parts of the growth were yours |
| Owned the ISV channel's strategy end to end | Inflated form of F1 | F1's quote at its own scope: running the ISV channel. F1's and A3's slots ask which decisions were yours |
| Experience in heavy rail, or with train operating companies | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, in consulting. The pack doesn't decide what "the other side" means, so C3's slot asks |
| Any figure, statistic or finding from the market report | The pack hasn't seen it | Only what you take from the report yourself, attributed to the report |

---

## Sources

**Provided documents:**

- Your message, including the recruiter's email as you quoted it.
- The market report is not in this conversation. Nothing in the pack draws on its content.

**Searches sent (all refused, so nothing came back):**

1. "Kelverton Rail values" — refused
2. "Kelverton Rail interview process partnerships" — refused
3. "Kelverton Rail scheduling software train operating companies news 2026" — refused
4. "Deepa VP Partnerships Kelverton Rail" — refused
5. "Senior Partnerships Manager rail technology SaaS job description UK" — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have themed VAL questions with Kelverton's own values. No values round is named, so no cheat sheet would have followed either way |
| 2. `Kelverton Rail interview process partnerships` | unavailable | The search was refused. The recruiter's email already establishes this session's format, so persona weights would barely have moved |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused. It would have given the CO questions and the POV's "where Kelverton is" beat current facts |
| 4. `Deepa` / `Ross` with `Kelverton Rail` | unavailable | The search for Deepa was refused, and none was sent for Ross once searching was refused. Profiles would have filled in the interviewer read, given mirror opportunities, and shaped a tailored reverse question |
| 5. representative Senior Partnerships Manager JD | unavailable | The search was refused. F4–F7 would have rested on a quoted posting labelled `[inferred]` rather than `[generic]` |

---

## Upgrade menu

- **JD text:** rows F4–F7 move from `[generic]` to `[grounded]`, and the coverage table gets checked against the real requirement list.
- **Key passages from the market report (pasted):** its segments, headline numbers and operator problems. The POV theses, the "where Kelverton is" beat, the operator close and E2 would then rest on its content instead of slots.
- **Permission to search the web:** targets 1–5 above. That brings current company news for the CO questions, a public-profile read of Deepa and Ross, and a representative JD.
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It covers a strategy brief, the interviewers' talks or writing, interview reports for this role family, and recent org changes, and adds a grounding brief section.
- **Pasted profile text for Deepa and Ross:** a sharper interviewer read, persona weights per person, and a reverse question tied to each one's path.
- **Your own answers to the slots in F1, F2 and F3:** which channel decisions were yours, who your consulting clients or counterparts were, and how the £4M was counted. A3, B1, B2, C1, C3, C4 and D2 would then become story-mapped rather than slotted.
- **A `tuesday-dossier.md`:** evidence-graded confidence for each claim, and a prohibited list built from verified evidence rather than from this pack's reading.
