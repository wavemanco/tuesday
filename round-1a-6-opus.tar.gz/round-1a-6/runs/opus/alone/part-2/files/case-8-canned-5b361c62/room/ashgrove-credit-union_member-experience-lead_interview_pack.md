# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 5 December 2026 · **Mode:** loop (three rounds, same day)

| Round | Who | Length | What the recruiter said it holds |
|---|---|---|---|
| R1 | The recruiter | 30 min | Screen |
| R2 | Head of Member Services, your future manager | 45 min | "mostly behavioural" |
| R3 | Panel of two branch managers | 60 min | "including a 20-minute case on a complaint escalation"; "The panel is also the values round — they score against the four values." |

Interviewer names have not been assigned yet, so there is no interviewer read; persona weights come from each round's relationship and the recruiter's own description.

---

## How to use this pack

- **Personas** are how a question is asked (friendly, sceptical, time-boxed). **Types** are what is being scored. Rehearse both.
- Type key:
  - **VAL** — does your past behaviour show Ashgrove's four published values
  - **EXP** — does what you say about your past survive follow-up
  - **JD** — can you do the listed job, gaps included
  - **CO** — do you know Ashgrove's strategy and can you think at its level
  - **CASE** — live problem, structure and reasoning out loud
- Provenance labels: `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Ashgrove.
- An **answer slot** is an instruction for the interview with two honest branches. Answer whichever branch is true. It is never a hint that the first branch is the right one.
- The guidance is scaffolding, not a script. Say it in your own words.

---

## Fit snapshot (shared by all three rounds)

Your four sentences, used throughout this pack exactly as you wrote them:

- S1: "6 years in retail banking, the last 3 as a branch supervisor."
- S2: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- S3: "I built the monthly complaints spreadsheet our regional manager uses."
- S4: "Never worked in a contact centre, and I've never presented to anyone above regional level."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material covers one branch's log, not a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the rest of the process likely. If any stage beyond keeping the log was yours, say which and what you did, in your own words; if none was, say so plainly and stay with the log and the training |
| F2 | "end to end across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | A monthly complaints spreadsheet you built is close to this, but your material does not say what it measures. Answer slot: if it tracks volumes or resolution times, say how each is counted, in your own words; if it does not, say so plainly and say what it does track |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Training new tellers is adjacent to coaching supervisors, not the same audience. Words: "I trained new tellers on our escalation script." Answer slot: if you have coached peers or more senior colleagues on escalations, say when and how, in your own words; if not, say so plainly and say how you would adapt the teller training for supervisors |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you fed member problems into an online or app journey, or tested one. Answer slot: if you have worked with a digital team on anything, say what and what your part was, in your own words; if you haven't, say so plainly and say how you would use complaint data to help a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. A sentence with nothing inspected behind it, so expect a probe on it. Lead with it as you wrote it: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" may or may not mean regulated; the pack infers only that it is close. Answer slot: if the log was kept to regulatory complaint rules, name the rules and what they required of you, in your own words; if it wasn't, or you don't know which rules applied, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated the limit. Words: "I haven't presented above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words; if you haven't, say so plainly. Then how you would prepare, as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says spreadsheet, not which tool. Answer slot: if it was built in Excel, say so and what it does, in your own words; if it was another tool, name it plainly |

**Highest-ROI prep in this pack: B1** — the scope objection built from F1 and F2. It will arrive in some form in R2, and probably again in R3.

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches (F1) | B1, B4, C5 |
| ...and the contact centre (F2) | B1, B3 |
| Report monthly on volumes and resolution times (F3) | B7, B8 |
| Coach branch supervisors on escalations (F4) | B5, B6, C7 |
| Work with digital teams on self-service journeys (F5) | B9 |
| 4+ years in financial-services customer operations (F6) | A1, C9 |
| Experience handling regulated complaints (F7) | A7 |
| Confident presenting to senior leaders (F8) | B2 |
| Comfortable with Excel reporting (F9) | A8 |

---

## Graded deliverable — the 20-minute complaint escalation case (R3)

The recruiter announced it: "a 20-minute case on a complaint escalation", scored by a panel that also scores "against the four values". You don't know the scenario, so rehearse a structure, not an answer. C5 is a practice scenario.

**Facts about you to build on** (quoted exactly; don't go beyond them):

- F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- F3: "I built the monthly complaints spreadsheet our regional manager uses."

**A 20-minute shape** `[generic]`

| Minutes | Move | Value it shows |
|---|---|---|
| 0–2 | Clarify: what the member actually wants, what has already been said to them, what formal stage the complaint is at, and the deadline or regulatory clock that applies. If you don't know the clock, say you would confirm it. Don't guess a number | Members First, Always |
| 2–5 | The member now: one named owner (you), contact today, a reply in plain words. Say one sentence of that reply out loud | Plain Words; Own the Fix |
| 5–10 | Investigate: the facts, who did what, what the branch tried, and whether the escalation route worked | Own the Fix |
| 10–15 | Fix and root cause: is this one case or a pattern? Say what you would look for in the complaints data | Own the Fix |
| 15–18 | Close the loop: what the branch supervisor is coached on, what gets recorded, how it shows up in the monthly report | Neighbours, Not Numbers |
| 18–20 | Check back with the panel: what you assumed, and what you'd want to know | — |

**Three defensible theses, each with its concession** `[generic]`

| Thesis | Mandatory concession |
|---|---|
| Fix the member's problem first, then the process | A quick fix for one member can break consistency with other members, or skip the formal route. So you would still record it and follow the formal stage |
| One named person keeps hold of it to the end ("Own the Fix") | The owner may not have authority to decide the remedy. The escalation route still matters, and the owner's job is to drive it, not bypass it |
| Treat every escalation as a possible pattern | In 20 minutes you have no data. Say what you would check rather than claiming a pattern exists |

**Beating the obvious answer.** Most candidates will say "apologise, escalate, resolve". Do that, then go further: (1) ask what outcome the member wants before you offer one; (2) say a line of the reply in plain words; (3) end with what changes so it doesn't happen again and how you would report it. The anti-pick: don't promise compensation or an outcome before you have the facts, and don't blame the branch. Two branch managers are scoring you.

---

## Grounding brief — what Ashgrove has said about itself

Use this vocabulary so you sound current. Every row comes from something you were given.

| Fact | Source | Provenance | Where it helps |
|---|---|---|---|
| Member-owned, about 900 staff | JD | [grounded] | A2, C9: "member-owned" is the organisation's own framing |
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026, sent by the recruiter | [grounded] | B9, R2 reverse questions |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief | [grounded] | C6, R3 reverse questions, A5 |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief | [grounded] | R2 reverse question 6 |
| Main competitive pressure: app-only banks | 2026 strategy brief | [grounded] | A2, B9 |
| Four values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | ashgrovecu.org/about/values, as you copied it on 26 November 2026 | [grounded] | All of R3; values cheat sheet |
| Hub consolidation changes which branch members use, so complaints may shift in volume and type during 2027 | This pack's reading of the brief's consolidation line | [inferred] | C6, B9. Say it as something you'd expect and check, not as a fact |

The brief is from July 2026. If anything in it has been updated, take the interviewer's version and don't correct them.

---

## Round 1 — Recruiter screen (30 min)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly "walk me through" and "why us" | High. A recruiter screen's default register, and the recruiter described the round only as 30 minutes with them | A 90-second background arc (A1) built from S1 to S3 only. Treat casual questions as scored |
| Skeptic (light) | Knockout checks against the JD's requirements | Medium. Screens check the listed requirements before passing you on | Answer the requirement plainly at the scope your sentences carry (A7, A8) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, four beats, each one only as your sentence says it: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on our escalation script; you built the monthly complaints spreadsheet your regional manager uses. End on why complaints work is what you want next, in your own words. Say "our escalation script", not "my script" | Every interviewer asks it, and here it sets the frame R2 and R3 will probe (F1, F3, F6). EXP because each beat will be followed up later |
| A2 | "Why Ashgrove, and why this role now?" | CO | [grounded] | One thing from the values text you actually agree with, in Ashgrove's own words (for example "we decide from the member's side of the counter"), and one thing from the brief, such as the move to digital service or hub consolidation, and why it makes this role interesting. Then your actual reason for wanting it now, in your own words. No claim about your past is needed | Motivation is the main thing a screen scores beyond knockouts. CO because the good answer shows you read the values and strategy you were given |
| A3 | "What's your notice period?" | JD | [generic] | Give your actual notice period. Nothing else to prepare | A screen's standard logistics question, asked of every candidate |
| A4 | "What salary are you looking for?" | JD | [generic] | Either give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Standard screen logistics. The pack supplies no figure, because only yours is safe to say |
| A5 | "The role covers branches and the contact centre. Where are you able to work, and how much travel suits you?" | JD | [grounded] | Say where and how often you can work, in your own words. If you'd like to know the base site, ask (R1 reverse question 5) | The JD's "across branches and the contact centre" raises it, and the brief's move to five hubs over 2027 makes location a live question |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your actual reason, briefly and in your own words, and keep it about what you want next rather than what you're leaving | Standard screen question; a long or negative answer is the only real risk |
| A7 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what your sentence says: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on the rules likely. If the log was kept to regulatory complaint rules, name the rules and what they required of you, in your own words; if it wasn't, or you don't know which rules applied, say so plainly and stay with the log you handled | A listed requirement, so likely as a knockout check (F7). JD because it scores a stated requirement; `[inferred]` because "formal" reaching "regulated" is the pack's inference |
| A8 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so and describe what it does, in your own words; if it was another tool, name it plainly. Don't call it the region's reporting; your sentence says your regional manager uses it | Listed requirement, a quick screen check (F9). JD because it scores the stated tool |

### Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "For the panel, how does the values scoring work? Is each value scored separately?" | You've been told they "score against the four values". Knowing the format tells you how to pace C1 to C4 |
| "When will I know who the interviewers are?" | Names let you prepare for each person, and asking shows you prepare |
| "What has prompted the role now?" | Tells you whether this role is new or a backfill, which changes what R2 will push on |
| "What happens after 5 December, and when should I expect to hear?" | Practical, and a normal close for a screen |
| "Is the role based at one site, or spread across the branches and hubs?" | Turns A5 into a two-way conversation and ties to the hub plan |

---

## Round 2 — Head of Member Services, your future manager (45 min, "mostly behavioural")

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: scope, contact centre, senior presenting | High. A hiring manager has to de-risk F1, F2 and F8, and behavioural questions are where gaps get tested | Rehearse B1 until it's boring. Concede early, specifically, then give a plan |
| Values / Behavioural | "Tell me about a time..." questions | High. The recruiter said "mostly behavioural" | Pick stories only from what you actually did; "we" for context, "I" for your part |
| Data-Driven Prober | Your spreadsheet: what it counts, how | Medium. Monthly reporting is in the JD and S3 is your closest evidence | Know what you can and can't say about how it's counted; say plainly where you don't know |
| Case / Strategist | Short live problems from the role | Medium. Hiring managers test the actual job, but "mostly behavioural" keeps this to one or two | Clarify, then structure, then answer; use Ashgrove's words (members, hubs, digital channels) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns complaints across every branch and the contact centre. You've handled one branch's log, and you haven't worked in a contact centre. Why are you ready to own the whole thing?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI rehearsal in the pack.** Concede first, before they push: "I haven't worked in a contact centre, and the log I handled was one branch's." Then what you did, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then a plan, said as a plan: for example, in the first weeks, sitting with contact-centre staff, reading the cross-channel complaint data, and finding where escalations break between channels. Follow-up 1, "So why would it scale?": go back to what you did and to the plan; add nothing. Follow-up 2, "What would you get wrong in month one?": a specific concession, for example that how contact-centre complaints are handled day to day is new to you and you'd need to learn it before changing anything. Never let the log grow past the branch | F1 and F2 are the biggest distance between your sentences and the JD, so some version of this is close to certain. JD because it scores the headline requirement; Skeptic delivery, with hold-then-concede |
| B2 | "You'd present the monthly complaints picture to senior leaders. You haven't presented above regional level. How would you handle that room?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words; if you haven't, say so plainly. Then how you'd prepare, as a plan: lead with the one number that matters, then the member impact, then what you're asking for; rehearse it with your manager first. Hold: the gap is experience of the room, not of the content. Don't fold that into "I'm not good at presenting" | F8 is a stated gap against a listed requirement, so expect it with some pressure. JD because it scores a requirement; hold-then-concede applies |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick a real one, not a disguised strength: the contact centre or senior presenting, both of which you've stated. Say it plainly, then one sentence of plan. If they ask about digital work, that's F5: answer slot — if you've worked with a digital team, say on what; if not, say so plainly | A classic Skeptic stem; with F2 and F8 stated, the honest answer is easy if rehearsed and awkward if not |
| B4 | "Tell me about a complaint that escalated, and what you did." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one real complaint from your branch. It needs the member's problem, what you personally did, how it ended, and what you'd do differently. "We" for context, "I" for your part. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry (handling the branch's formal complaints log) or how you would handle one | Behavioural core of an escalations role (F1). EXP because the follow-ups test what was actually yours |
| B5 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats your sentence states: new tellers, our escalation script, you trained them. Tell it in your own words. Answer slot: the JD's coaching line makes a probe on whether the training changed how escalations went likely. If you saw a change, say what and how you knew, in your own words; if you didn't track it, say so plainly and describe how you trained. Don't say you wrote the script; your sentence says "our" | F4's closest evidence, so the manager will test it. EXP because it's premised on S2 |
| B6 | "Tell me about a time you coached someone at your level or above on how they handled a member." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: a time you coached a peer or someone senior. It needs who, what you saw, what you said, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (training new tellers on our escalation script) and how you would adapt it for supervisors | The JD says "coach branch supervisors", and F4 covers tellers. JD because it scores the listed duty; behavioural delivery |
| B7 | "Walk me through the monthly complaints spreadsheet you built. What's in it, and how does your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats your sentence states: you built it, it's monthly, your regional manager uses it. Answer slot: the JD's volumes and resolution-times line makes a probe on what it measures likely. If it tracks volumes or resolution times, say how each is counted, in your own words, and which part of the counting you'd defend least; if it doesn't, say so plainly and say what it does track. On use: say what you've seen your regional manager do with it, if you know; if you don't, say so | S3 is your one number-shaped piece of evidence (F3, F9), so a Prober will go two levels into it. EXP; prober delivery |
| B8 | "Say average resolution time has crept up over three months. How would you find out why?" | CASE | [generic] | Clarify: when does the clock start and stop, and did the definition or the data change. Then split it: by channel (branch or contact centre), by branch, by complaint type, and volume against handling time. Pull a sample of slow cases and read them. Then a fix, and how you'd watch it in next month's report. Name one risk: chasing the average can hide a few very long cases | Tests the JD's resolution-times reporting as a live problem. CASE because it asks for structure, not a past |
| B9 | "We're moving 40% of member service to digital channels by 2028. What does that do to complaints, and what would you want from the digital team?" | CO | [grounded] | Treat it as hypotheses to check: complaints may move channel, and a failed self-service journey may show up as a contact-centre call. What you'd measure: complaints tagged by journey, and members who drop out of an app journey and then call. What you'd ask the digital team for: a shared tag for each journey and a monthly look at the top complaint causes together. Tie it to Plain Words: if members keep asking how a screen works, the screen is wrong. On your own digital experience, answer slot: if you've worked with a digital team, say on what and what your part was; if you haven't, say so plainly | Built on the brief's 40% target and the JD's self-service line (F5). CO first because it needs the strategy; CASE delivery |

### Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "What would good look like for complaints at the end of my first year?" | Gets the real success measure from the person who will judge it |
| "Where do complaints get stuck today: in branches, in the contact centre, or between them?" | Shows you're already thinking about the cross-channel part you haven't done, and gets you the facts to close F2 |
| "How do you expect the hub consolidation in 2027 to change the complaints picture?" | Uses the brief's own plan, and is a question only a manager can answer |
| "Who on the digital side would I work with most on self-service journeys?" | Turns F5 into a working relationship you're planning for |
| "When the monthly report goes to senior leaders, what do they want first: the numbers or the member stories?" | Faces the presenting gap (F8) head-on, as preparation |
| "Will the small-business lending launch in Q1 2027 bring new kinds of complaints into this team?" | Shows you read the whole brief, and it's a real planning question for the role |

---

## Round 3 — Panel of two branch managers (60 min: values round plus 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One or more questions per value, scored | Very high. The recruiter said "they score against the four values" | Use the values cheat sheet below: one story or scaffold per value, told with "I" for your part |
| Case / Strategist | The 20-minute escalation case | Certain. Announced by the recruiter | The 20-minute shape in the graded-deliverable section; rehearse C5 out loud |
| Peer Evaluator | "What would you need from us?", disagreement with branch managers | Medium. This role coaches their supervisors, so the panel will test how you'd work with them | Reciprocity: say what their branches get from you, not only what you need |
| Pressure | A time-boxed "why you" | Low. Panels sometimes press, and the gaps in F1 and F2 invite it | Hold-then-concede (C9) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side, even when it cost the branch something." | VAL | [grounded] | Members First, Always. Selection scaffold: it needs a real member, a choice where the branch's convenience and the member's interest pulled apart, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would decide | Built from the value's own words, "we decide from the member's side of the counter". VAL because the panel scores it |
| C2 | "Tell me about a time something had to be explained more than once, and what you did about it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain Words. Selection scaffold: a time a member or colleague didn't understand the first time, and you changed the explanation or the material. The nearest thing your material carries is training new tellers on our escalation script. Answer slot: if, while training, you changed how the script was explained because tellers didn't get it, say what you changed, in your own words; if not, say so plainly and pick another time | From "if a member needs it explained twice, we wrote it wrong". VAL; the strong answer fixes the wording, not the listener |
| C3 | "Tell me about a time knowing the local community changed how you handled a member's problem." | VAL | [grounded] | Neighbours, Not Numbers. Selection scaffold: a specific member, something you knew about the town or the person that a number wouldn't show, and what you did differently because of it. If no such time comes to mind, say so plainly, then give the nearest thing you do have, or how you would handle it | From "every branch is part of its town". Two branch managers will listen closely to this one |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Own the Fix. Answer slot: if you built the spreadsheet because something was missing or broken, say what it was and how you saw it through, in your own words; if it wasn't a fix for a problem, say so plainly and pick another time you found a problem and kept hold of it. Either way: what you found, why it was yours to keep, the moment you could have handed it off, how it ended | From "whoever finds the problem keeps hold of it until it is solved". VAL; this value is the closest to the job itself |
| C5 | "Practice case: a member has complained three times about the same fee at one branch, and now they've emailed the chief executive. You have 20 minutes. Talk us through it." | CASE | [generic] | Use the 20-minute shape above. Clarify first (what the member wants, what stage the complaint is at, which deadline applies, and say you'd confirm the rule rather than guess it). Own it today and say one plain-words line of your reply aloud. Investigate, then check for a pattern. Close with the supervisor coaching and how it shows in the monthly report. Don't blame the branch | Rehearsal for the announced case; the scenario is invented, so only the structure transfers. CASE, scored for structure and values together |
| C6 | "Say a branch is being consolidated into a hub next year and its members are already unhappy. How would you handle complaints through that change?" | CASE | [grounded] | Clarify what's changing for members and when. Then: expect complaints to rise and change type, as something you'd watch, not as a known fact; agree with the branch and hub managers who owns a complaint during the move; write member letters in plain words; report the consolidation's complaints separately so they're visible. Neighbours, Not Numbers: the branch is part of its town even as it closes | The brief's eight-to-five hub plan is the panel's own world. CASE content; CO because it needs the strategy |
| C7 | "You'd be coaching our supervisors on escalations. What happens when you and I disagree about how a complaint from my branch should be handled?" | CASE | [generic] | Principles, not a story: the member's outcome decides it; the branch manager owns the branch relationship, you own whether the process is consistent across branches; disagree in private, settle it on the member's side, and write down what was decided. If they ask for a past example, selection scaffold: a time you disagreed with someone senior and kept the relationship; if none comes to mind, say so plainly and stay with how you'd handle it | Peer seam between the role and the panel's own job (F4). CASE because it's a working-arrangement problem |
| C8 | "What would you need from branch managers, and what would we get from you?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Give first: a monthly view of their own branch's complaints, as a plan, since you've built a monthly complaints spreadsheet before; quicker help on escalations; supervisors who are coached the same way everywhere. Then need: a named contact in each branch and their honest view of where the process fails | Reciprocity question a peer panel asks (F3, F4). JD because it tests the coaching and reporting duties |
| C9 | "Sixty seconds. Why should we pick a branch supervisor for this?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, then: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on our escalation script; you built the monthly complaints spreadsheet your regional manager uses. One honest sentence: the contact centre is new to you. One sentence of plan. If pushed, hold on what you did, and don't add to it | Pressure stem aimed at F1, F2 and F6. EXP because it tests whether your summary of yourself holds |

### Values cheat sheet (for R3)

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, not the branch's convenience | Selection scaffold (C1): a choice where the member's interest and the branch's convenience pulled apart. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would decide |
| Plain Words | If someone needs it explained twice, fix the explanation | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot (C2): if you changed how the script was explained because tellers didn't get it, say what; if not, say so plainly and pick another time |
| Neighbours, Not Numbers | Each branch belongs to its local community | Selection scaffold (C3): a member, something local a number wouldn't show, and what you did differently. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot (C4): if you built it because something was missing or broken, say what and how you saw it through; if not, say so plainly and pick another problem you kept hold of |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What could I do in my first month that would genuinely help your branches?" | Reciprocity: it tells two future colleagues you're there to lighten their load |
| "When a complaint escalates from your branch today, what happens next, and what would you change?" | Gets the process from the people living it, which is the knowledge you'd need to close F1 |
| "Which of the four values is hardest to live out in a branch, day to day?" | Engages with the values they're scoring without reciting them |
| "What do your supervisors ask for when an escalation gets difficult?" | Directly about the coaching part of the job (F4) |
| "As branches move to hubs, what do you most want the complaints process to protect?" | Shows you know the hub plan affects them and asks for their priorities rather than offering yours |

---

## Prohibited claims — what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process, or ran complaints for the region | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation: your material says one branch's log, not a process across branches. B1's plan is said as a plan |
| Contact-centre experience of any kind | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Presented to senior leaders or executives | Negative you stated, F8 | "I haven't presented above regional level." The slot only asks about regional level |
| Coached supervisors | Inflated form of F4 | "I trained new tellers on our escalation script." Coaching anyone senior is asked as an open question (B6) with an honest branch |
| Wrote or designed the escalation script | Inflated form of F4: your sentence says "our escalation script" | "I trained new tellers on our escalation script." |
| Ran or ensured regulatory compliance for complaints | Inflated form of F7 | "I handled the branch's formal complaints log." Whether it was regulated is A7's answer slot, which stays inside the log |
| Built the region's complaints reporting, or a reporting system | Inflated form of F3 (scope drift) | "I built the monthly complaints spreadsheet our regional manager uses." Which tool and what it counts are answer slots (A8, B7) |

---

## Sources

**Provided documents**

- The JD, pasted in full.
- The values text, pasted, which you said you copied on 26 November 2026 from ashgrovecu.org/about/values. Not fetched; the pasted text is what this pack uses.
- The recruiter's email describing the three rounds, quoted.
- The 2026 strategy brief (published July 2026, sent by the recruiter), as you summarised it in four points.
- Your background, in four sentences, in your message.

No dossier was provided.

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted this morning fixes the values cheat sheet and C1 to C4 |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email sets out all three rounds, who runs each and what they hold, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief is under six months old and supplies the priorities the CO and CASE questions use |
| 4. Interviewer names | n/a | No names have been assigned, so there is no query to run; there's no interviewer read |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD, which fixes the fit snapshot and every JD-tagged question |

---

## Upgrade menu

- Your CV → interviewers will have it in front of them; with it, A1, B7 and C9 use its exact lines, and any figure on it gets a defend-the-number question.
- Interviewer names, once assigned → an interviewer read for each person, persona weights from their public professional profile, and a reverse question tied to their own path.
- Your answers to the answer slots, said here outside a drill → F3, F5, F7 and F9 move from `discovery`, and A7, A8, B7, B9 and C4 become story-mapped.
- The strategy brief's full text → the grounding brief uses its exact wording and any figures, and B9 and C6 get sharper.
- How much prep time you have before 5 December → a prioritised schedule, so you rehearse B1, B2 and the case first.
- A deeper research pass — up to 6 more searches and 2 more fetches, several more minutes → recent Ashgrove news since July and any published candidate reports for its interviews.
- A `tuesday-dossier.md` from job-underwriter → evidence checked against your record, a firm list of claims to avoid, and the objection to rehearse most taken from evidence rather than inferred.
