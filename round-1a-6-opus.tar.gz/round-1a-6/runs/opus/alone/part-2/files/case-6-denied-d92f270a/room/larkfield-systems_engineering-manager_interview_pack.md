# Interview prep pack: Engineering Manager, Larkfield Systems

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). **Candidate:** Yusuf.
**Mode:** Loop. Three scheduled rounds share one fit snapshot. Each round gets its own persona weights, question bank and reverse questions.

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | Hiring manager, your would-be boss | 45 min |
| 2 | The Thursday after | Two staff engineers + a product manager | Peer panel plus a cross-functional partner | 60 min |
| 3 | The following Monday | VP Engineering | Skip-level. The recruiter's description: "values and leadership philosophy" | 30 min |

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it's scored on. The same gap can come up as a friendly aside on Tuesday and a pointed challenge on Monday, so rehearse the content and the delivery.
- **Type key:**
  - **VAL:** behavioral or values alignment.
  - **EXP:** deep-dive on your experience (what was actually you).
  - **JD:** the stated responsibilities, including the gaps.
  - **CO:** company and strategy knowledge.
  - **CASE:** a live problem from the role.
- **Provenance labels:**
  - `[grounded]`: traces to your message or the role text you pasted.
  - `[inferred]`: this pack's own derivation, with the derivation named.
  - `[generic]`: a role-family pattern with no claim about Larkfield or about you.
- **Answer slots** are instructions for what to say in the interview. They aren't questions for this conversation. Each has two honest branches, and the second ("it wasn't like that") is always a good answer.
- The guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in the pack: A1**, the hardware-roadmap objection. It will come up in some form in all three rounds.

---

## Fit snapshot (shared across all three rounds)

All requirements are quoted from the role text you pasted. None of them is a gate (no location, authorization, schedule or credential term appears in that text).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material describes one team of six, not two squads, and your words should stay at that scope: "I've been a team lead of six for three years." The role text doesn't say whether the squads have their own leads. If the interviewer asks about managing managers, give the plain answer you've already stated: "I haven't managed managers." Answer slot: the two-squads line makes a question about leading beyond your own team likely. If you have coordinated work across more than your own team, say how, in your own words. If you haven't, say so plainly and stay with the team of six |
| F2 | "own delivery" — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote shows you shaping one quarter's priorities. It doesn't show how your team's delivery commitments are set or tracked. Answer slot: if you set or track your team's delivery commitments, say how, in your own words. If that sits with someone else, or there's no such process, say so plainly and come back to the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — JD (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | This is the same kind of work, but nothing backs it up beyond your own account, so expect follow-up questions. Open with the quote's own terms: you run the hiring loop for backend roles. The number counts interviews ("about 40 interviews last year"). It doesn't count hires, and it doesn't count interviews you sat in yourself unless you did. Your material doesn't say whether hire decisions or headcount were yours. B4 and C2 handle that with answer slots |
| F4 | "growth for 11 engineers" — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | "Team lead" can mean tech lead or line manager, and your material doesn't say which, so this pack takes the narrower reading. Answer slot: if you ran reviews, growth plans or promotion cases for the six, say which and how. If that sat with someone else, or there was no such process, say so plainly and describe what you did as lead |
| F5 | "partner with hardware and product on roadmap" — JD (the hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | No wording can close this gap, and you've said so yourself. Your words: "I haven't owned a hardware-adjacent roadmap." Then explain how you'd learn it, framed as a plan and never as something you've done. Add nothing that makes the gap sound smaller |
| F6 | "partner with hardware and product on roadmap" — JD (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Keep your words at the quote's scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after that." The quote doesn't say where the pressure came from or who you had to bring round. Answer slot: if product was the other side of it, say how you got agreement, in your own words. If it wasn't, say so plainly and stay with the quarter |
| F7 | "industrial IoT" and "device-management services" — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Your material names a payments company and says nothing either way about devices or IoT. Answer slot: if you have worked on device, embedded or IoT systems, say what, in your own words. If you haven't, say so plainly and say what you'd learn first |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Lead two squads | A2, B1, I3 |
| F2 Own delivery | B2, G1, E1 |
| F3 Hiring | B4, C2, H4 |
| F4 Growth for 11 engineers | H3, E4 |
| F5 Hardware partnership on roadmap | A1, A3, E5, G1, I1 |
| F6 Product partnership on roadmap | E2, E3, B3 |
| F7 Industrial IoT and device-management services | F3, G2, D1 |
| Headline metric (60%) | C1, F1, I2 |

---

## Persona weights by round

These priors come from the relationships you described. No interviewer names were given, so they aren't adjusted for any individual.

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Tue | Skeptic | "Help me understand" probes on the gaps between your role now and this one | High. A would-be boss is checking for risk, and F1 and F5 are the visible gaps | Rehearse A1 until it bores you. Build bridges only from your quoted facts, and give a concrete plan for learning |
| Tue | Case / Strategist | "Your first 90 days", "you have one engineer to move" | High. Hiring managers test with live problems from their own roadmap | Clarify, set the objective, structure, then cover risks. Think aloud |
| Tue | Data-Driven Prober | "How was that 60% counted?" | Medium. Your one headline number will be checked | Know what you can and can't say about how it was counted |
| Tue | Conversational | A "walk me through the journey" opener | Low, but scored | Have a 90-second arc ready |
| Thu | Peer Evaluator | The staff engineers ask where the EM stops and they start. The PM asks where the EM/PM line is | High. A panel of two peers and a partner is pricing what you add to or take off their workload | Talk about what you bring as well as what you need. Propose principles for the seam rather than pretending you already know where it is |
| Thu | Data-Driven Prober | Staff engineers going two levels deeper on the reliability quarter | High. Engineers dig into engineering claims | Same as Tuesday, more technical |
| Thu | Case / Strategist | A firmware slip or a fleet incident, set as a live problem | Medium. A 60-minute panel has room for one or two scenarios | Clarify before structuring. Name your assumptions about hardware out loud |
| Mon | Values / Behavioral | "Your leadership philosophy", "a time you..." | High. The recruiter's own description of the round | Tell stories built only from your quoted facts, and use the honest branch where none fits |
| Mon | Pressure | Time-boxed questions: "why you", "how much was actually you" | Medium. Executive rounds test composure, and 30 minutes forces short answers | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Mon | Conversational | Warm openers that are still scored | Medium | Keep answers short and consistent with what you said on Tuesday |

---

## Round 1: Tuesday, hiring manager (45 min)

**Weights:** Skeptic 3 questions, Case 4, Prober 2, Conversational 1. Two weight notes: A1 gets the most time even though Case has more questions, and Case runs long because the director is your future boss and will test how you'd run their teams.

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role partners with hardware and product on the roadmap. What's your experience there?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | **Highest-ROI prep in the pack.** Lead with the limit before they find it: "I haven't owned a hardware-adjacent roadmap." Then give the one roadmap fact your material carries, in its own terms: you pushed a reliability quarter through against roadmap pressure, and the team's on-call burden dropped 60% after that. Then give a plan, framed as a plan, built around what you'd want to learn first. For example: how far ahead hardware commits, how service releases depend on hardware dates, and where those dependencies have hurt before. **Follow-up 1** ("So you'd be learning on the job?"): hold. Say yes on the hardware side and repeat the quarter, adding nothing. **Follow-up 2** ("How long until you're useful?"): don't invent a timeline. If you have your own estimate, give it. If you don't, say you'd agree a checkpoint with them. Answer slot: if product or another team was the source of that roadmap pressure, say how you got agreement, in your own words. If it wasn't like that, say so plainly and stay with the quarter | F5 is a stated gap against an explicit line in the role text, so it's the most predictable objection. A rehearsed answer that names the limit first takes the sting out of it. JD because it scores the stated requirement |
| A2 | "You've been a team lead of six. This is eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold the quote's scope: three years as a team lead of six. "What changes" asks for reasoning about the role, so reason forward. You can't be in every discussion. Priorities have to be traded off between the squads. You need someone you trust in each squad. Answer slot: if you've coordinated work across more than your own team, say how, in your own words. If you haven't, say so plainly and stay with the six. If they ask whether you've managed managers: "I haven't managed managers." Then ask whether the squads have their own leads | F1's scope jump is the director's second derisking question. JD content delivered as a CASE question; JD is primary because the gap comes from the role text |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name it yourself, so A1 has already been said in your words: "I haven't owned a hardware-adjacent roadmap." Then give one sentence on how you'd close it, as a plan. Don't name a weakness your material doesn't carry just to sound safe | A standard Skeptic stem. F5 gives you an honest answer, so rehearse it rather than reaching for a softer weakness |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "First 90 days, two squads on device-management services. What do you need to know first?" | CASE | [generic] | Clarify first: what the squads own, what's committed to hardware and product, where on-call and incidents stand, and who the senior people are. Then the objective: earn trust and protect delivery. Then the sequence: listen, find the one fix to make, then change how work is planned. Name a risk: changing too much before you understand the hardware dependencies. The question asks about no past, so the guidance makes no claim about yours | F1's requirement asked as a live problem. Hiring managers use it to see whether you clarify before you plan |
| B2 | "One squad is behind on something hardware is waiting for, and the other is firefighting on-call. You can move one senior engineer. Walk me through it." | CASE | [generic] | Clarify: what the hardware dependency is and whether its date can move, and how bad the on-call pain is for customers. Structure it as a trade between a cost now and a cost compounding, and say who you'd talk to before moving anyone. A good answer also names what you'd stop doing, not only who you'd move | Tests F2 and F5 together, as a decision rather than a track record |
| B3 | "How would you decide whether to spend a quarter on reliability instead of roadmap here?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give the decision framework first: what reliability is costing (on-call, customer impact) against what the roadmap is worth, and who has to agree. Then use your one instance, at its own scope: you pushed a reliability quarter through against roadmap pressure, and the team's on-call burden dropped 60% after that. Don't claim the framework is the one you used unless it was. Answer slot: if you made that case to someone with numbers, say what you showed, in your own words. If you didn't, say so plainly and describe how the quarter got through | The director will test whether F6's story carries over to a setting with hardware. CASE because it asks for a decision here, using your history only as an example |
| B4 | "You'd own hiring for eleven engineers. Two roles are open. How do you run it?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the quote: you run the hiring loop for backend roles. Then plan for this role: what the device team needs, how you'd calibrate interviewers, and how you'd keep the bar consistent. Answer slot: the role text says you'd own hiring, so expect a question on who made hire and no-hire calls in your current loop. If they were yours, say how you made them, in your own words. If they sat with someone else, say so plainly and stay with running the loop | F3 is the strongest row in the snapshot. The aim is to show it fairly without stretching "run the loop" into owning hiring |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slots, in your own words. (1) How the 60% was counted: pages, hours, incidents, or whatever it was. If you don't know, say so. (2) What it's sensitive to, such as the period it was measured over or traffic changes. (3) The assumption behind it you'd defend least. Say that before they ask. (4) Which part was yours: the quote says you pushed the quarter through and the burden dropped after that. "After" is the honest word, so keep it. Don't supply a baseline or method you can't repeat under a second question | Your headline number gets checked. C1 is Tuesday's version and F1 is the panel's deeper one. EXP because it tests attribution |
| C2 | "About forty interviews last year. Walk me through what running that loop involved." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The number counts interviews. Answer slot: which part was yours. If you sat in all of them, say so. If the loop ran them and you ran the loop, say that. If you changed the loop's design or calibration, say what, in your own words. If you didn't, say so plainly and describe how you run it as it is | F3's number, checked the same way as the 60%. A count is easy to round up into "I interviewed 40 people" |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the journey. Why move from payments to industrial IoT now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Keep it to 90 seconds: nine years in engineering, three as a team lead of six, now at a payments company. Answer slot: your actual reason for this move, in your own words. Your material doesn't give one, so don't borrow one. If it isn't specific to IoT, say what drew you to this role. Keep it identical on Monday (J2) | F7's domain switch is the obvious "why". Inconsistent answers across rounds are what a loop catches |

### Reverse questions for the director

| Question | Why it lands |
|---|---|
| "What would make you say, six months in, that this hire worked?" | It gets the director to state their real scorecard, which you can then speak to in rounds 2 and 3 |
| "How do the two squads split device-management today, and do they have their own tech leads?" | It tells you whether F1 means managing managers, without leading with the gap |
| "How does the roadmap get set across hardware, product and engineering, and how far ahead does hardware commit?" | It shows you're already working on A1's learning plan, and the answer feeds your Thursday prep |
| "Is this a new role or a backfill, and what's the most urgent thing on the squads' plates?" | It shows what the role is really for and gives you material for B1 on Thursday |
| "How do you like to work with your EMs: cadence, decisions you want to see, ones you don't?" | The director is your would-be boss, and this signals you're thinking about the working relationship |

---

## Round 2: Thursday, panel (60 min: two staff engineers + PM)

**Weights:** Peer Evaluator 5 questions, Prober 3, Case 2. The staff engineers will test whether you add to or take off their load. The PM will test where the EM/PM line sits. The Skeptic's objections come back in collegial form (E5).

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | Staff engineer: "How do you decide when to stay out of a technical decision our squad is making?" | CASE | [generic] | Propose principles: you set the constraints (dates, reliability, cost), they own the design, and you step in when a decision crosses squads or risks a commitment. Say what you'd want from them in return. The question asks about no past, so make no claim about yours | Staff engineers are pricing whether an EM is a help or a bottleneck. CASE because it's a working-model question |
| E2 | PM: "Our roles sit side by side. Where's the seam on the roadmap, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose a seam rather than claiming to know it: product owns the what and the why, engineering owns the how, the cost and the risk, and the trade-off gets made in the open. Then give your one roadmap instance at its scope: the reliability quarter, pushed through against roadmap pressure. Answer slot: if a PM was on the other side of that, say how you disagreed and kept the relationship, in your own words. If it wasn't a PM, say so plainly | The product half of the "partner with hardware and product on roadmap" line, from the person you'd partner with. JD because it scores that line directly |
| E3 | PM: "Tell me about a time you disagreed with product on priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use the beats the quote states: the reliability quarter, the roadmap pressure against it, you pushing it through, and the drop after that. Answer slot: if the pressure came from product, say what the disagreement was and how it ended, in your own words. If it didn't, say so plainly, then give the nearest real disagreement with product you have, or how you'd handle one | An open question themed on F6's requirement. If the story doesn't involve product, the honest branch keeps you from forcing it |
| E4 | Staff engineer: "What would you need from us in your first month, and what would you take off our plate?" | CASE | [generic] | Answer the reciprocity part first: what you'd take on, such as hiring logistics, the planning overhead and on-call reviews. Then what you'd need: context on the system's history and an honest read of where it hurts. Answer slot: the role text says you'd own the engineers' growth, so expect a question on how you'd support staff engineers' own growth. If you've done that for senior people, say how. If you haven't, say so plainly and say what you'd ask them first | Peer reciprocity, plus F4's growth requirement in a peer's framing |
| E5 | PM: "How would you get up to speed on how the hardware roadmap constrains ours?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The collegial version of A1. Keep the same limit in the same words: "I haven't owned a hardware-adjacent roadmap." Then the plan: who you'd sit with on the hardware side, the last slips you'd want to understand, and where you'd ask the PM to help. Give the plan as a plan | The objection from F5 resurfacing collegially. Your answer has to match Tuesday's word for word on the limit |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | Staff engineer: "What actually went into the reliability quarter, and which of it was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The quote says what was yours: you pushed the quarter through. Answer slots: what the work was, in your own words. Which pieces you did hands-on, and which the team did. If you don't remember an item exactly, say so. Keep the 60% exactly as in C1: the team's burden dropped after that. Don't describe engineering work the quote doesn't carry unless it's what actually happened | The panel's deeper version of C1. Engineers ask about the work behind the number |
| F2 | Staff engineer: "How do you stay close enough to the technical details as an EM of eleven without becoming the bottleneck?" | CASE | [generic] | Reason it through: which reviews you'd join, which decisions you'd delegate, and how you'd know when you were out of touch. Answer slot: if you still write or review code as a lead, say how much, in your own words. If you don't, say so plainly | A standard staff-engineer test of how far an EM should be hands-on. CASE because it asks how you'd work here |
| F3 | Staff engineer: "What in your background is closest to device-management services?" | EXP | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: if you've worked on device, embedded or IoT systems, say what, in your own words. If you haven't, say so plainly, then name what you'd want to learn first. Don't claim payments systems resemble device management. Describe what you've built and let them draw the comparison | F7's domain gap from the people who know the domain. `[inferred]` because the gap is the pack's reading of a quote that doesn't address it |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | PM: "Hardware tells us a firmware release is slipping two weeks. Your squad's service was due to ship with it, and I want to hold our date. What do you do?" | CASE | [generic] | Clarify: is the dependency hard or soft, can the service ship behind a flag, and what has the customer been promised? Options: decouple, re-sequence, or move the date openly. Say what you'd tell the PM, and when. Name your weakest assumption about how hardware dates move, and say you'd check it. That connects to F5 without claiming anything | F2 and F5 in one live problem. The panel can test this without you having done it before |
| G2 | Staff engineer: "Devices across a customer's fleet stop checking in at 2am. Walk us through your first hour as the EM, and what you change afterwards." | CASE | [generic] | Structure it: make sure an incident commander is in place (not you, if someone else is better placed), communicate with the customer, protect the people on call, then hold a blameless review and decide what to fund afterwards. Answer slot: if you've run incident reviews in your current role, say how, in your own words. If you haven't, say so plainly | F7's domain set as a live problem. It also lets reliability show up without stretching the 60% |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| To the staff engineers: "What could a new EM do in the first month that would genuinely help you?" | It's the reciprocity question, and it tells them you're pricing their workload |
| To the staff engineers: "What's the piece of device-management you'd most want fixed if you had a quarter?" | It opens the reliability-versus-roadmap conversation on their terms, not yours |
| To the PM: "When hardware, product and engineering disagree on the roadmap today, how does it get resolved, and who has the final say?" | It shows you're preparing for A1's gap and tells you where the seam actually sits |
| To the PM: "What do you need from your EM that you're not getting now?" | Peer reciprocity aimed at the partner who'll judge you most on the roadmap line |
| To everyone: "How does on-call work for these squads today?" | It's a real question for an EM, and their answer shows whether your reliability experience applies here, without you claiming it |

---

## Round 3: Monday, VP Engineering (30 min, "values and leadership philosophy")

**Weights:** Values / Behavioral 4 questions, Pressure 3, Conversational 2. Thirty minutes means 90-second answers.

**No values cheat sheet.** The search for Larkfield's published values was refused (see Sources), so the values questions below are themed on the recruiter's words and standard values questions, not on Larkfield's own value names. If Larkfield publishes values, paste them and this round gains a value-by-value story map.

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | State two or three principles in your own words. Tie each one to a fact you've given, at its own scope: the reliability quarter you pushed through against roadmap pressure, and the hiring loop you run for backend roles. Answer slot: for any principle you can't tie to a fact you've given, either give the real instance in your own words or present it as how you intend to lead, not how you have led | The recruiter named this round's subject, so this question is close to certain. VAL because it's scored on whether the principles match what you've actually done |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Beats from the quote: the reliability quarter, the roadmap pressure, you pushing it through, and the drop after that. Answer slot: if leadership was who you had to convince, say what you told them and how it landed, in your own words. If it wasn't leadership, say so plainly, then give the nearest real instance you have, or how you'd handle one | A standard values question. F6 is the only story in your material that has pressure in it, and the honest branch stops you promoting it |
| H3 | "Tell me about a time an engineer on your team wasn't growing the way they or you wanted." | VAL | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: pick a time with a named person (anonymised), a conversation you had, and a change you can describe. Answer slot, from F4: if you handled reviews or growth plans as a lead, say how, in your own words. If that sat with someone else, say so plainly and describe what you did as lead. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The role text's growth requirement, asked as values. F4 is a discovery gap, so the material can't supply the story |
| H4 | "How do you make sure hiring decisions are fair and consistent?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the quote: you run the hiring loop for backend roles. Answer slot: if you've built or used calibration, structured scoring or debriefs, say what, in your own words. If you haven't, say so plainly and say what you'd put in place here | F3, framed as fairness. VAL because a VP asks it as a values question, not a process one |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you over an EM who's already shipped hardware-adjacent products?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, then concede the premise first: "I haven't owned a hardware-adjacent roadmap." Then give two facts at their scope: you run the hiring loop for backend roles, and you pushed the reliability quarter through. Then one line on how you'd close the gap. **Hold through two follow-ups** by repeating those facts, not adding to them. Concede specifically: the hardware learning curve is real. Don't fold into "you're probably right" | F5 as a stress test. Composure here matters more than content. JD because the scored content is still the role's requirement |
| I2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the quote's split, which is already honest: the burden was the team's, the push was yours, and the drop came after. Answer slot: which part of the work after the push was yours, in your own words. If you don't know how the 60% was counted, say so, as in C1. Don't claim the whole number, and don't disown the push | The standard attribution stress question. The quote's "after" is your best defence, so don't overwrite it |
| I3 | "You've never managed managers. If the squads need their own leads, are you the person?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Agree with the premise in your own words: "I haven't managed managers." Then answer the question honestly. If you'd want to grow into it, say how you'd prepare, framed as a plan. If you'd want to stay closer to the teams, say that. Don't imply experience the quote rules out | F1's gap at VP altitude. The negative is yours, so the question may assume it |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's something you've changed your mind about as a leader?" | VAL | [generic] | Selection scaffold: pick a real belief you held, the moment it changed, and what you do differently now. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | The recruiter's "leadership philosophy" asked casually. Casual questions are still scored |
| J2 | "Why Larkfield, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Give the same answer as D1 on Tuesday, in the same words. Answer slot: your actual reason, in your own words. A VP will notice if it has drifted since Tuesday | Consistency across the loop is the point of asking twice |

### Reverse questions for the VP

| Question | Why it lands |
|---|---|
| "What do EMs here tend to get wrong in their first year?" | It asks for the VP's real bar, and it reads as coachability |
| "How does your leadership philosophy show up when reliability and roadmap pull against each other?" | It mirrors the round's own subject back, on the one trade-off your material carries |
| "How do EMs here grow into leading leads, if they want to?" | It addresses I3 openly and signals ambition without claiming experience |
| "How do engineering and hardware leadership set priorities together at your level?" | It shows A1's gap is on your mind at the altitude the VP works at |
| "What would you want to have heard from me by the end of this round that you haven't yet?" | In 30 minutes, it gives you a last chance to answer the VP's real concern |

---

## Prohibited claims

This pack won't coach any of these. Each comes from your own words.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope. This pack's observation: your material describes one team of six |
| Has managed managers | A negative you stated, F1 | "I haven't managed managers." |
| Has owned, or partnered on, a hardware-adjacent roadmap | A negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." |
| Cut on-call by 60%, or caused the drop alone | Inflated form of the F6 quote | The quote at its own scope: the team's on-call burden dropped 60% after you pushed the reliability quarter through. C1 and I2 hold its slots |
| Owned the team's roadmap | Inflated form of F6 | F6's quote at its own scope. This pack's observation: your material describes one quarter pushed through against pressure |
| Made the hiring decisions or owned headcount | Inflated form of F3 | F3's quote: you run the hiring loop for backend roles. B4's slot stays inside the loop |
| Personally conducted about 40 interviews | Inflated reading of F3's number | The number counts the loop's interviews. Where your sentence can be read two ways, this pack takes the narrower reading. C2's slot asks which part was yours |
| Was line manager of the six, with reviews and promotions | Inflated reading of F4's "team lead" | F4's quote at its own scope. F4's slot asks what the lead role held |

---

## Sources

**Provided:** your message. That covers the role text, the three rounds and the recruiter's description of round 3, and your background. No dossier was present.

**Searches sent:**
- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT news": refused

**Fetches:** none.

The loop structure comes from your own description of the three rounds, which says who runs each one and what it holds, so the round structure stands without research. Nothing about Larkfield's values, strategy or interview formats is in this pack.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the values cheat sheet for round 3 and themed H1 to H4 on Larkfield's own value names |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have told us whether any round includes a system-design or case format. The rounds themselves stand on your description |
| 3. `Larkfield Systems` strategy and recent news | unavailable | The search was refused. It would have grounded at least one CO or CASE question per round in Larkfield's current priorities. Without it, B1, B2, G1 and G2 are `[generic]` and there are no CO questions |
| 4. Interviewer names at `Larkfield Systems` | n/a | No names were given, so there was no query to form. The interviewer read is absent |
| 5. Representative `Engineering Manager` JD | skipped | The role text you pasted provides the requirements in the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full job description** → more requirement rows (for example on-call, technical scope, location or travel terms). Every new line gets a JD-tagged question, and any gate surfaces in the fit snapshot.
- **Larkfield's published values or principles (pasted)** → a values cheat sheet for round 3. H1 to H4 get re-themed on the official value names, each mapped to one of your quoted facts.
- **Interviewer names** → a public-footprint read of the director, VP and panel, adjusted persona weights, and at least one reverse question per round tied to each interviewer's path.
- **Recruiter guidance on Thursday's panel format** (for example a case, a system-design segment or a roadmap exercise) → a dedicated build section if any of it is a graded exercise.
- **Allowing web search** → targets 1 to 3 re-run, which grounds CO and CASE questions in Larkfield's actual strategy. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is also available if you want it.
- **Your answers to the answer slots** (whether "team lead" included line management, whether hire decisions were yours, who the roadmap pressure came from, how the 60% was counted, and any device or IoT work) → F2, F4, F6 and F7 regenerate with your words. A1, B3, B4, C1, C2, E2, E3, H2, H3 and I2 move from slots to mapped stories.
- **A `tuesday-dossier.md`** → its verified evidence and prohibited-claims list would replace this pack's local versions, and the highest-ROI objection would rest on its evidence rather than on this pack's reading.
