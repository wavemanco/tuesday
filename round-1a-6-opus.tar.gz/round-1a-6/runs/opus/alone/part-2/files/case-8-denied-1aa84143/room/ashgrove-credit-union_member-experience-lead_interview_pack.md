# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 5 December, as the recruiter's email describes them
1. Recruiter screen, 30 minutes
2. Head of Member Services (your future manager), 45 minutes, mostly behavioural
3. Panel of two branch managers, 60 minutes: a 20-minute complaint-escalation case, and the values round, scored against the four values

Interviewer names haven't been assigned yet, so this pack has no interviewer read.

---

## How to use this pack

- **Personas** describe *how* a question is asked (friendly, sceptical, probing, under pressure). **Types** describe *what* is being scored. Each round has its own persona weights and question bank.
- **Type key:**
  - **VAL**: behaviour that shows Ashgrove's *published* values
  - **EXP**: whether your stated experience holds up, and what was actually yours
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, reasoned through out loud
- **Provenance labels:** `[grounded]` means it traces to something you or Ashgrove provided. `[inferred]` means it's this pack's own derivation, and says what it is derived from. `[generic]` means a common pattern for this kind of role, with no claim about you or Ashgrove.
- **Answer slots** are instructions for your real answer in the interview. Each one has two honest branches. Pick the one that's true. Neither branch is a confession.
- **Guidance is scaffolding, not a script.** Every suggested wording in this pack is a proposal, pending your approval. Change anything that isn't how you'd say it.
- Every claim the pack makes about your past rests on the four sentences quoted in the fit snapshot, and on nothing else.

---

## Fit snapshot

Shared by all three rounds. The evidence column quotes your message word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | This is covered, in branch terms. Say it in the quote's own words: "Six years in retail banking, the last three as a branch supervisor." Let the interviewer connect branch work to "customer operations" rather than relabelling it yourself. Answer slot: if you're asked what supervising covered, say what was yours, in your own words. Where something wasn't yours, say so plainly |
| F2 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes it likely you'll be asked what handling the log involved, from a complaint arriving to it being closed. Where parts of that were yours, say which and how, in your own words. Where a part was someone else's, or didn't happen at your branch, say so plainly and stay with the log you handled |
| F3 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | No wording closes this gap, and you've said so yourself. Words: "I haven't worked in a contact centre." Then say how you'd learn it, framed as a plan and never as past experience. Don't add anything to make the gap feel smaller |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The spreadsheet is monthly and covers complaints. Your material doesn't show what it counts. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks complaint volumes or how long complaints take to resolve, say which, and how each is counted, in your own words. If it tracks other things, say what it does track and stay there. Your sentence says the regional manager uses it, not that you report from it, so keep it at that |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes training new tellers on the branch's script, not coaching supervisors, and your words stay there: "I trained new tellers on our escalation script." The sentence says "our" script, so don't present it as one you wrote. Answer slot: the JD's coaching line makes it likely you'll be asked how you trained them. Say how, in your own words. If it was simpler than a coaching programme, say so plainly and stay with what you did |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you worked with a digital or IT team on something members use themselves. Answer slot: if you've passed complaint themes to a digital team, or worked on a self-service change, say what it was and what your part was, in your own words. If you haven't, say so plainly, then say what you'd bring to that work, as a plan |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | "Formal" is your word and "regulated" is the JD's. Don't swap one for the other. Answer slot: if the complaints in that log came under a regulator's complaint-handling rules, name the rules and what they meant for how you handled complaints, in your own words. If you don't know, or they didn't, say so plainly and describe the log as you handled it |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Answer slot: your sentence leaves open whether you've presented at regional level. If you have, say to whom and about what, in your own words. If not, say so plainly. Either way, follow with how you'd prepare a monthly report for senior leaders, framed as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says "spreadsheet", not Excel. Answer slot: if you built it in Excel, say so and describe what you built in it, in your own words. If you built it in another tool, name that tool plainly |

**Rows the material leaves thinnest:** F3 and F8 are gaps you've stated yourself. F6 has no evidence. F4, F7 and F9 hinge on facts only you know, and the answer slots are there for those.

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

**What's known about it:** the recruiter's email says the panel includes "a 20-minute case on a complaint escalation", and that "the panel is also the values round — they score against the four values." Nothing more is known about its format. Pending your approval.

**Grounded facts to build on**

| Fact | Provenance | Use it for |
|---|---|---|
| The case is on a complaint escalation, it lasts 20 minutes, and two branch managers run it | [grounded] recruiter's email | Timing: roughly 3 minutes to clarify, 12 to reason through it, 5 to close |
| The panel scores against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | [grounded] values page text and recruiter's email | Name each value out loud at the step that shows it |
| The role will "coach branch supervisors on escalations" | [grounded] JD | A step on the branch supervisor, not only the member |
| Your own material, F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | [grounded] your message | Your only reference point from your own experience. Use it at its own scope, for example "at my branch, complaints went into a formal log", and add nothing it doesn't say |

**A structure you can say out loud**
1. **Clarify (Members First).** Ask what the member wants. Ask what has already happened at the branch. Ask whether any regulatory deadline or required response applies, rather than assuming either way. Ask whether the member is in circumstances that need extra care.
2. **The member today (Members First).** What you'd do for this member now, before the investigation finishes.
3. **The supervisor (the JD's coaching line).** Decide whether you'd coach them through it or take it over, and why.
4. **The cause (Own the Fix).** Log it, find out why it happened, and keep hold of it until it's closed. Say who you'd tell, and how it feeds the monthly report.
5. **The response (Plain Words).** Write the final reply so the member wouldn't need it explained twice.
6. **The branch and its town (Neighbours, Not Numbers).** Say what this complaint means for that branch and its members.

**Theses to choose from (each with the concession you have to make)**
- **T1: Fix it for this member first, then fix why it happened.** Concession: a fast fix can skip the investigation that finds the cause. Say how you'd do both.
- **T2: Coach the supervisor through it rather than taking it off them.** Concession: some escalations should be taken over. Say where you'd draw that line.
- **T3: The response isn't finished until the member wouldn't need it explained twice.** Concession: if a required wording applies, plain words have to work alongside it, not replace it.

**How to differentiate:** the consensus answer is a tidy process walkthrough. Stand out by naming which value each step serves, out loud, because that's what the panel is scoring.
**What to avoid (the anti-pick):** don't promise compensation or an outcome before you have the facts. Don't blame the branch in front of two branch managers. Criticise the process, not the people.

---

## Grounding brief

These come from the July 2026 strategy brief as you summarised it, plus the values text you copied on 26 November 2026. Use the brief's own wording.

| Item | Provenance | Vocabulary to use | Questions where it comes up |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] strategy brief | "40% to digital channels by 2028" | B3, G1, I2 |
| Consolidate eight branches into five hubs over 2027 | [grounded] strategy brief | "eight branches into five hubs" | B3, G2, J1 |
| Launch a small-business lending product in Q1 2027 | [grounded] strategy brief | "small-business lending, Q1 2027" | B3, G3 |
| The main competitive pressure is app-only banks | [grounded] strategy brief | "app-only banks" | B3, I2 |
| Four values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | [grounded] values text copied 26 November 2026 | Use the exact names. Being quizzed on them in the panel round is likely | H1 to H5 |

Speak about these as Ashgrove's published plans. You can't know how they're going internally yet, so ask about that (see the reverse questions) rather than assuming.

---

# Round 1: Recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk through your background, motivation and logistics | High. A recruiter screen's usual style. The relaxed tone is the trap, because it's still scored | A pre-rehearsed 90-second arc (A1). Short, real answers on logistics |
| Skeptic (light) | Checks the JD's must-haves before passing you on | Medium. The JD lists regulated complaints and the contact centre, and the screen is where must-haves get checked | One plain sentence per gap, then move on. The deeper rehearsal is in Round 2 |

### Question bank: Conversational
Suggested wording is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc built only on what these sentences say: six years in retail banking, with the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on the escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Use your own words for your history, not the JD's ("owned the complaints process") | Every round opens with some version of this. EXP because it sets the facts the later rounds probe (F1, F2, F4) |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one value by its exact name and one item from the strategy brief, and say in your own words why they draw you. Your material shows no history with credit unions, so don't imply one | It tests whether you did the homework. CO because the values page and the brief are the source |
| A3 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, in a sentence or two, without criticising your current employer | A standard recruiter-screen check. EXP because it scores whether your story is consistent |
| A4 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | A standard screen item. JD because it concerns the listed job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | A standard screen item. JD because it concerns the job's terms |
| A6 | "The role spans branches and the contact centre. Where are you based, and how do you feel about moving between sites?" | JD | [grounded] | Logistics slot: give your actual base and the travel you can do, in your own words. If there are limits, state them plainly now rather than in Round 3 | The JD's "across branches and the contact centre" makes the question likely. JD because it concerns the job's terms |

### Question bank: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for regulated complaints experience. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with the quote: "I handled the branch's formal complaints log." Answer slot: if those complaints came under a regulator's complaint-handling rules, name the rules and what they meant in practice, in your own words. If you don't know, or they didn't, say so plainly and describe the log as you handled it. Don't swap "formal" for "regulated" | F7 is a stated requirement, and the recruiter screen is where it gets checked first. JD because it scores a listed requirement |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Answer in one breath with no apology: "I haven't worked in a contact centre." Then give a one-line plan for learning it. C1 has the full rehearsal | F3 is the clearest must-have gap. JD because the JD names the contact centre |
| B3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name two of the brief's four items in its own words, for example "40% to digital channels by 2028" and "eight branches into five hubs over 2027". Say why each matters for complaints, as your reasoning rather than inside knowledge | It's a cheap homework check most candidates fail. CO because the brief is the source |

### Reverse questions: Recruiter

| Question | Why it lands |
|---|---|
| "How does the panel score the four values: one score per value, or overall?" | It shapes how you spread stories across H1 to H4, and it shows you've read the process |
| "Can you tell me anything about the case's format: a written prompt, a role-play or a discussion?" | It's the one graded deliverable, and the answer reshapes your case preparation |
| "Is this a new role or a backfill?" | It tells you whether you'd be building the complaints process or inheriting it, which is useful for Round 2 |
| "Which tools does the team use for the monthly complaints report?" | It ties to the JD's Excel line (F9) and tells you what to brush up on |
| "What happens after 5 December, and when should I expect to hear?" | Practical, and it closes the screen cleanly |

---

# Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: the contact centre, senior presenting, one branch versus many | High. A hiring manager is reducing the risk in a hire, and F3 and F8 are the visible gaps | Rehearse C1 until it bores you. Name the limit before they do, then give a plan |
| Values / Behavioural | "Tell me about a time…" stories | High. The recruiter said this round is "mostly behavioural" | Story maps where your quotes carry a story, and selection scaffolds with an honest way out where they don't |
| Data-Driven Prober | Asks what the spreadsheet counts and who uses it for what | Medium. The JD's monthly reporting line and your spreadsheet sentence (F4) invite it | Know what you can and can't say about how it's counted. Say plainly what you don't know |
| Case / Strategist | Live questions on the strategy: digital, hubs, the lending product | Medium. A manager's usual mode, though the recruiter's "mostly behavioural" lowers it | Clarify, then state the objective, approach, measures and risks, thinking aloud |

### Question bank: Skeptic
Suggested wording is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked in a contact centre, and this role owns complaints there too. Why should I trust you with that half of the process?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI prep in this pack.** Name the limit before they press. Opening: "I haven't worked in a contact centre. What I have done is handle my branch's formal complaints log and train new tellers on our escalation script." Then the plan, framed as a plan: spend your first weeks with the contact-centre team on complaint calls, learn where their complaints and the branches' meet, and ask what they need before changing anything. Follow-up 1, "How would you know what good looks like there?": concede specifically, "I wouldn't yet. I'd learn it from the people doing it." Follow-up 2, "So we'd be paying you to learn?": hold on the quote, "For the contact centre, at first, yes. The complaints log and the escalation training are what I bring from day one." Don't fold, and don't stretch branch work into contact-centre work | F3 is the gap most certain to come up, and your future manager is the person who owns it. JD because the JD names the contact centre |
| C2 | "Tell me about the most senior audience you've presented to." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you've presented at regional level, say to whom and about what, in your own words. If not, say so plainly. Then the plan for the monthly report: lead with the one thing senior leaders need to decide, then the trend, in plain words. Hold through one push, and concede only what's true: "It's new for me at that level." | F8 is a stated requirement and a gap you've stated. The role reports upward every month. JD because it scores the listed requirement |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of your two stated gaps, say it plainly, and give a plan. Don't offer a fake weakness, and don't list both and spiral | A classic Skeptic stem. Your stated gaps (F3, F8) make it the safest place to be honest. JD because it scores self-assessment against the JD |
| C4 | "Owning complaints end to end across branches is a step up from one branch's log. What makes you ready?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Hold on the quotes: six years in retail banking, the last three as a branch supervisor, and handling the branch's formal complaints log. Answer slot: if you've done anything with complaints beyond your own branch, say what and what your part was. If you haven't, say so plainly and stay with the log you handled. Don't claim the wider scope | F2's scope gap, put directly. JD because the JD says "across branches" |

### Question bank: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a complaint had to be escalated beyond the branch. What did you do?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint from the log you handled that went beyond the branch. You need what the member wanted, what you did, who it went to, and how it ended for the member. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry, training new tellers on the escalation script, or how you'd handle one | The JD's escalation line in behavioural form. JD content in VAL delivery. Tagged JD because it scores the coaching-on-escalations requirement (F5) |
| D2 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: you need a named stake, a moment you didn't fold, and a working relationship still intact at the end. If no such time comes to mind, say so plainly, then say how you'd handle it | A common behavioural stem. It also tests the upward communication behind F8. VAL because it scores behaviour, not a requirement |
| D3 | "Tell me about how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map: new tellers, the escalation script, and that you trained them. Those are the beats the sentence states. Answer slot: say how you trained them and how you knew it had worked, in your own words. If there was no check afterwards, say so plainly | F5 is your nearest evidence for coaching supervisors, so expect it to be pulled on. EXP because it tests what was yours |

### Question bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story map: you built it, it's monthly, it covers complaints, and your regional manager uses it. Answer slot: if it tracks volumes or resolution times, say how each is counted, in your own words. If it tracks other things, say what. Say which tool it's in, and name the tool even if it isn't Excel. If you don't know how a number is produced, say that plainly | F4 and F9 meet here. It's the one artefact you built. EXP because it tests the claim behind it |
| E2 | "What does your regional manager actually use it for?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Your sentence says they use it. Answer slot: if you know what it informs, say so in your own words. If you don't, say so plainly rather than guess. Don't present yourself as the person who reports from it | A prober's next step after E1. EXP because it tests the scope of the claim |

### Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We're moving 40% of member service to digital channels by 2028. How should complaints work through that shift?" | CO | [grounded] | Clarify first: which journeys move first, and how complaints about digital channels are captured today. Objective: members never lose a way to complain. Approach: send complaint themes to the digital teams, and watch for complaints that the self-service journeys themselves create. Measures: complaint volumes and resolution times by channel. Risk: members who won't go digital. If asked about your own digital work, use the F6 slot | The brief's headline target, and the JD's digital line. CO because it's grounded in current strategy |
| G2 | "Eight branches become five hubs over 2027. What happens to complaints, and what would you watch?" | CO | [grounded] | Think aloud. Complaints may move channel or rise in the affected towns. Watch volumes by town before and after. Coach the supervisors in merging branches. Link it to Neighbours, Not Numbers. Concession: you don't know Ashgrove's current complaint data, so say what you'd look at first | A live change your future manager will be dealing with. CO because it's grounded in the brief |
| G3 | "Small-business lending launches in Q1 2027. What would you set up for complaints about it?" | CO | [grounded] | Clarify: who handles those members, branch or specialist staff. Set it up so complaints about the new product are tagged from the first day and show up in the monthly report. Ask how the teams expect to handle complaints from business members. Your material shows no small-business lending work, so don't imply any | A new product means new complaint types. CO because it's grounded in the brief |

### Reverse questions: Head of Member Services

| Question | Why it lands |
|---|---|
| "What would a strong first monthly complaints report look like to you, and who reads it?" | It targets F8 and F4 directly and shows you're thinking about the audience above you |
| "Where do complaints get stuck today between branches and the contact centre?" | It turns your biggest gap (F3) into curiosity about the real problem |
| "How will the move to five hubs change who handles complaints at branch level?" | It shows you know the brief and are thinking about your supervisors |
| "Which self-service journeys are first on the path to 40% digital, and how are complaints about them caught?" | It connects the JD's digital line to the strategy |
| "What would you want me to have learned by the end of my first three months?" | It's a manager's question, and it tells you how they'll judge your ramp-up |

---

# Round 3: Panel of two branch managers (60 minutes, including a 20-minute case; the values round)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One story prompt per value, scored | High. The recruiter said "they score against the four values" | One story per value from the cheat sheet below. "We" for context, "I" for your part |
| Case / Strategist | The 20-minute escalation case | High for the case itself, which is announced, and low elsewhere | Follow the case build in the graded-deliverable section |
| Peer Evaluator | "What happens when you and my branch disagree?" | Medium. The role works across their branches and coaches their supervisors | Agree principles for how you'd work together, and offer them something useful, not only what you need from them |
| Pressure | "Why would managers take coaching from a supervisor?" | Low to medium. A pattern for panels, and your title (F1) invites it | Pause, restate the question, hold on the facts, and concede only what's true |

### Question bank: Values / Behavioural
Suggested wording is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint from the log you handled where you chose what was right for the member. You need the member's situation, your decision, and what happened. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | It mirrors "we decide from the member's side of the counter" (Members First, Always). VAL because it's scored against that value |
| H2 | "Tell me about a time you had to explain something more than once. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A possible story: training new tellers on the escalation script. Answer slot: if you changed how you explained the script after a teller didn't get it, say what you changed, in your own words. If you didn't, say so plainly and choose another time, or say how you'd handle it | It mirrors "if a member needs it explained twice, we wrote it wrong" (Plain Words). VAL because it's scored against that value |
| H3 | "Tell me about a time you treated a member as part of the town, not a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold, set in your branch years: you need a named member situation (no personal details), what you did that a process wouldn't have done, and why the town mattered. If none comes to mind, say so plainly, then say how you'd handle it | It mirrors "every branch is part of its town" (Neighbours, Not Numbers). The hub plan makes it pointed for branch managers. VAL because it's scored against that value |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | A possible story: the spreadsheet you built. Answer slot: if you built it because of a problem you spotted, say what the problem was and how you kept hold of it until it was solved, in your own words. If it was asked of you, say so plainly and choose another story, or say how you'd handle it | It mirrors "whoever finds the problem keeps hold of it until it is solved" (Own the Fix). VAL because it's scored against that value |
| H5 | "Which of our four values will be hardest for you to live in this role?" | VAL | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one honestly and tie it to a real gap. For example, Own the Fix for complaints that run through a contact centre you haven't worked in, then your plan. Use the value's exact name | It tests whether you know the values by name and can be candid. VAL because it's scored against the values |

### Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Here's the escalation case. Talk us through it." | CASE | [grounded] | Use the case build in the graded-deliverable section: clarify, then the member today, the supervisor, the cause, the response and the town, naming the value at each step. Pick one thesis (T1 to T3) and make its concession | The announced 20-minute case. CASE because it's a live problem |
| I2 | "Partway through, the member says they're moving to an app-only bank. Does that change anything?" | CASE | [grounded] | Hold your resolution standard. The fix is decided on the facts, not on the threat. Then say what you'd learn from it for the digital path. Don't overpromise to keep the member | The brief names app-only banks as the main pressure, which makes this a likely twist. CASE because it tests composure inside the case |

### Question bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "If a member complains about my branch and you think my supervisor got it wrong, what happens?" | CASE | [generic] | Agree principles rather than claiming to know their setup: talk to the branch manager first, fix it with the supervisor as a coaching conversation, and base the member's outcome on the facts. Link it to Own the Fix and, with hubs coming, Neighbours, Not Numbers | This is where the role and their branches meet. CASE because it's a live working scenario |
| J2 | "What would you need from us, and what would we get from you?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Reciprocity, framed as a plan: offer each branch a monthly view of its own complaints and coaching for its supervisors on escalations. Ask for time with their supervisors in return. Your sentence supports having built a monthly complaints spreadsheet, nothing more | Peers price what you add to their work. JD because it maps to the reporting and coaching lines |

### Question bank: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You've been a supervisor, not a manager. Why should branch managers take escalation coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, then hold: "I've been a branch supervisor for three years. I've handled our formal complaints log and trained new tellers on our escalation script." Coaching would be for supervisors, which is the level you've worked at. If they push again, concede specifically: "I haven't managed a branch. I'd be coaching on escalations, not on running your branch." Never say you managed the branch | Your title (F1) against a panel of managers is the obvious pressure point. JD because it tests the coaching requirement (F5) |
| K2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I built the monthly complaints spreadsheet our regional manager uses." | Hold on the facts in the quotes. Concede that an internal candidate knows Ashgrove better, then say what you bring and how you'd learn Ashgrove fast. Stay under 60 seconds | A common time-boxed stem. JD because it scores fit to the role |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decisions are made from the member's point of view | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Selection scaffold: choose one complaint from that log where you chose what was right for the member. If none comes to mind, say so plainly and say how you'd handle it | H1 |
| Plain Words | If something needs explaining twice, the writing is at fault | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: say what you changed in how you explained the script, if anything. If nothing, say so and choose another time | H2 |
| Neighbours, Not Numbers | Each branch belongs to its town | F1: "6 years in retail banking, the last 3 as a branch supervisor." Selection scaffold from your branch years. If none comes to mind, say so plainly and say how you'd handle it | H3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F4: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if a problem you spotted led to it, tell that. If it was asked of you, say so and choose another story | H4 |

### Reverse questions: Panel

| Question | Why it lands |
|---|---|
| "What could a new complaints lead do in the first month that would genuinely help your branches?" | Reciprocity with peers. It shows you'd reduce their load rather than add to it |
| "When an escalation goes wrong today, what do your supervisors wish they'd had?" | It goes straight at the JD's coaching line, from their side |
| "What are members in your towns saying about the move to hubs?" | It's Neighbours, Not Numbers turned into a question, and timely given the brief |
| "What does a Plain Words complaint response look like to you?" | It uses their value's name and invites them to show what good looks like |
| "Which of the four values is hardest to live at branch level right now?" | It turns the values round into a two-way conversation |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches (F2) | C4, D1, I1 |
| …and the contact centre (F3) | B2, C1, C3 |
| Report monthly on volumes and resolution times (F4) | E1, E2, C2 |
| Coach branch supervisors on escalations (F5) | D3, K1, J2, I1 |
| Work with digital teams on self-service journeys (F6) | G1, I2 |
| 4+ years in financial-services customer operations (F1) | A1, K1 |
| Experience handling regulated complaints (F7) | B1 |
| Confident presenting to senior leaders (F8) | C2, C3, D2 |
| Comfortable with Excel reporting (F9) | E1 |

---

## Prohibited claims

These are claims this pack won't coach. Each tends to get reached for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre | A negative you stated (F3) | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders above regional level | A negative you stated (F8) | "I haven't presented to anyone above regional level." The regional-level slot in F8 stays open |
| Owned or ran the complaints process across branches | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: your material describes one branch's log, not a process across branches |
| Coached branch supervisors | Inflated form of F5 | F5's quote at its own scope: training new tellers on the escalation script. Your material says tellers, not supervisors |
| Wrote the escalation script | Inflated form of F5 | Your sentence says "our escalation script". Say you trained tellers on it |
| Reported monthly to the regional manager, or presented the figures | Inflated form of F4 | F4's quote at its own scope: you built the spreadsheet and the regional manager uses it |
| Managed the branch | Inflated form of F1 | F1's quote at its own scope: branch supervisor for the last three years |

---

## Sources

- **Provided:** the JD text; the values text you copied on 26 November 2026 (you named ashgrovecu.org/about/values as where it came from, and it wasn't fetched); the recruiter's process email; the July 2026 strategy brief, as the four points you gave.
- **Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted this morning fixes the cheat sheet and H1 to H5 |
| 2. Ashgrove interview process for member-services roles | skipped | The recruiter's email establishes all three rounds, who runs each, the case and the values scoring, so it fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, under six months old, fixes the grounding brief and G1 to G3 |
| 4. Interviewer names at Ashgrove | n/a | Only roles were given, so there was no name to search. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a read on each interviewer, per-person persona weights, and a reverse question tied to each one's career path
- **Your answers to the slots in F4, F7 and F9** (what the spreadsheet counts, whether the log's complaints were regulated, which tool it's in), told to me outside a drill → those rows are re-graded and B1 and E1 become story-mapped
- **Your CV** → CV lines are quoted beside your message, which may supply evidence for F6, F7 and F9
- **How much prep time you have before 5 December** → a prioritised prep schedule
- **The full strategy brief text** → the brief's own wording and figures in the grounding brief, and sharper versions of G1 to G3
- **Anything the recruiter can share about the case format** → the case build tuned to the real format
- **Deep research, L2** (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove news and organisational context, plus any published reports on how candidates found this process
- **A tuesday-dossier.md** → evidence-graded objections and a prohibited list carried between sessions. This pack is complete without one
