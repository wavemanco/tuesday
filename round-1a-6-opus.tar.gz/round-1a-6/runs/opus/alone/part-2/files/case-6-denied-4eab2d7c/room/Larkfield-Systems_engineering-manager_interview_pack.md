# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop, with three scheduled rounds. All three share one fit snapshot, one prohibited list and one set of sources. Each round gets its own mini-pack.

| Round | When | Who | Relationship |
|---|---|---|---|
| R1 | Tuesday, 45 min | Director of Engineering | Hiring manager, your would-be boss |
| R2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel: technical peers and a cross-functional partner |
| R3 | The following Monday, 30 min | VP Engineering | Skip-level. The recruiter described it as "values and leadership philosophy" |

---

## How to use this pack

- **Personas** describe how a question will be asked: the style and register. **Types** describe what is being scored. Rehearse both, because the same question feels different when a skeptic asks it quietly and when a pressure interviewer asks it against the clock.
- **Type key:**
  - **VAL** tests whether your past behaviour shows the values or leadership approach the round is about.
  - **EXP** is a deep-dive on your experience: what you actually did and how much of it was yours.
  - **JD** tests whether you can do the listed job, including its gaps.
  - **CO** tests your homework on the company and its strategy.
  - **CASE** is a live problem from the role, which scores your structure and reasoning.
- **Provenance labels:**
  - **[grounded]** traces to your message or the role text you pasted.
  - **[inferred]** is this pack's own derivation, and the derivation is named.
  - **[generic]** is a role-family pattern that makes no claim about Larkfield or about you.
- **Answer slots** mark places where the role raises a question your material doesn't answer. Each one gives two honest branches: one if you did it, one if you didn't. Answer from your own experience. Never fill a slot with what the role usually involves.
- **The guidance is scaffolding, not a script.** Say it in your own words.

---

## Fit snapshot (shared by all three rounds)

The requirements are quoted from the role description you pasted. All evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material shows one team of 6 at a payments company. The role is two squads and 11 engineers on device-management services. Keep the words at their own scope: "I've been a team lead of 6 for 3 years, at a payments company." Answer slot: "two squads" makes a probe on leading more than one team likely. If you have led across more than one team or workstream, say how, in your own words. If you haven't, say so plainly and stay with the team of 6 |
| F2 | "Lead two squads" — role description. The text doesn't say whether either squad has a lead who would report to you | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | This is a gap you stated, and it matters only if the squads have leads reporting to the EM. The role text doesn't say, which makes it a good reverse question in R1. Words: "I haven't managed managers." Then describe how you would approach it, framed as a plan and never as something you've done. Add nothing to make the gap feel smaller |
| F3 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material shows one quarter's priority call, carried through on your own team. It doesn't show you owning delivery for 11 engineers across two squads. Keep the sentence's own logic: the drop came *after* the quarter, so don't say *because of* it unless you can show that. Answer slot: "own delivery" makes a probe on how you run delivery likely. If you set the plans, cadence or tracking for your team, say how, in your own words. If those weren't yours, say so plainly and return to the reliability quarter |
| F4 | "own … hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but this is a self-reported line with nothing inspectable behind it, so expect a probe. Lead in the quote's own terms: you run the loop, for backend roles, about 40 interviews last year. Answer slot: "own … hiring" makes a probe on who makes the final call likely. If you made hire or no-hire decisions, say so and how. If the loop fed someone else's decision, say that plainly |
| F5 | "growth for 11 engineers" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Being a team lead touches people development, but your material doesn't show any growth work. The inference is the pack's, drawn from the title. Answer slot: if you've run career conversations, promotion cases or development plans for your team of 6, say what and how. If you haven't, say so plainly and say what you would do first |
| F6 | "partner with … product on roadmap" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material shows you holding a priority *against* roadmap pressure. It doesn't show you setting a roadmap *with* product. Answer slot: if the reliability quarter involved working it out with a product partner, say who and how it went, in your own words. If it didn't, say so plainly and stay with what you pushed through |
| F7 | "partner with hardware … on roadmap" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | This is a gap you stated, and wording can't close it. Words: "I haven't owned a hardware-adjacent roadmap." Then describe how you would learn it, framed as a plan and never as something you've done. Your message says nothing about other hardware contact, so the pack assumes none and claims none |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads (F1, F2) | A1, B2, B3, D4, K3, L2 |
| Device-management services | A2, D3, L1 |
| Own delivery (F3) | A3, A4, D2, E2 |
| Own hiring (F4) | C2, J4 |
| Growth for 11 engineers (F5) | A4, G2, J3 |
| Partner with product on roadmap (F6) | E2, E3, G1 |
| Partner with hardware on roadmap (F7) | B1, A2, K2 |
| Headline metric, 60% (F3) | D1, K1 |

---

## Prohibited claims (shared, built before the banks)

The pack will not coach the claims below. Watch for them in your own answers, especially under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Led multiple teams, or managed 11 engineers | Inflated form of F1 | F1's quote at its own scope. The pack's own note: your material says one team of 6 |
| Has managed managers | A negative you stated (F2) | "I haven't managed managers." |
| Has owned a hardware-adjacent roadmap | A negative you stated (F7) | "I haven't owned a hardware-adjacent roadmap." |
| "I cut on-call by 60%", or "the reliability quarter caused the 60% drop" | Inflated form of F3. It turns "my team's" into "I" and "after" into "caused" | F3's quote as you wrote it: your team's burden dropped 60% after you pushed the quarter through. The D1 and K1 slots stay inside that sentence |
| Owned delivery for the org, or owned the roadmap | Inflated form of F3 and F6 | F3's quote at its own scope. The pack's own note: your material says one reliability quarter, pushed through against pressure |
| Owned hiring decisions or headcount | Inflated form of F4 | F4's quote: you run the loop, for backend roles, about 40 interviews last year. The F4 slot asks only who made the final call |

**Highest-ROI prep in this pack: B1** (the hardware-roadmap objection). F7 is the gap you stated that sits closest to the job's core. It's likely to come up in some form in all three rounds: B1 in R1, E3 in R2 and K2 in R3.

---

# R1 — Tuesday: hiring manager (Director of Engineering), 45 min

### Personas

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | "Here are our two squads; plan your first quarter." Live problems on their roadmap | High. A hiring manager is buying capability, and a would-be boss will test how you'd run *their* teams | Clarify, then objective, then approach, then metrics, then risks. Think aloud. Challenge one premise respectfully |
| Skeptic | Quiet probing of F1, F2 and F7: scale, managing managers, hardware | High. They are de-risking the hire, and those three rows are the visible gaps | Rehearse B1 until it bores you. Use only the bridges your quotes carry, and state limits plainly, followed by a concrete plan |
| Conversational | "Walk me through your background." | Low. It usually comes in the first five minutes, and it is still scored | A 90-second arc built only from your four sentences |

### Bank

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit two squads on device-management services. What do you need to know in your first 30 days?" | CASE | [generic] | Clarify first: each squad's mission, who leads each one, current commitments to hardware and product, on-call load, open reqs. Then the objective (keep delivery steady while you learn), the approach (1:1s with all 11, sitting in on planning, meeting hardware and product counterparts), and how you'd know it's working. End on one risk, such as changing things before you understand them. This question needs no claim about your past | The most likely opener for a would-be boss. CASE because it scores structure on the actual job. Generic because Larkfield's real squad setup is unknown |
| A2 | "Hardware slips six weeks and your squad's committed release depends on it. What do you do?" | CASE | [generic] | Structure: confirm what is actually blocked and what isn't, find what can ship decoupled, re-plan with product, and tell stakeholders early with options. Ask one clarifying question aloud (for example, can the dependency be stubbed or feature-flagged?). Speak only in plan terms. Your material holds no hardware story (F7), so don't hint at one | Tests F7's area as reasoning, not record. A plausible live problem for a team that partners with hardware |
| A3 | "Roadmap pressure versus reliability: how do you decide when to stop and pay down?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give your decision criteria first, as principles. Then illustrate with the quote at its own scope: you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after. Answer slot: if you built the case with specific data or got agreement in a specific way, say what it was, in your own words. If not, say so plainly and stay with the decision and the outcome you stated | Your strongest story (F3) answers a question every EM gets. CASE leads because the question is about judgement, and the story is the illustration |
| A4 | "How would you split your time across delivery, hiring and growth for 11 engineers?" | JD | [grounded] | Answer as a plan: what you'd weight in month one and how that shifts later, how you'd know when one area is starving, and what you'd delegate to senior engineers. Make no claim about your past. If you want an example, choose one under C2 or A3 | Scores the stated job ("delivery, hiring and growth for 11 engineers"). Covers F5, which has no story yet |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see hardware in your background. How would you partner with a hardware team on a roadmap?" **The highest-ROI rehearsal** | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name the limit before they press: "I haven't owned a hardware-adjacent roadmap." Then give a plan, framed as a plan: learn hardware's release cadence and lead times, map where firmware and services depend on each other, agree early on how slips get communicated, and pair with whoever on the team knows it best. **Follow-up 1** ("So how would you know you're good at it?"): hold. Say what you'd watch in your first quarter, and don't reach for a past example. **Follow-up 2** ("We'd be paying for your ramp"): concede specifically: "Yes, there's a ramp on the hardware side, and I'd rather say so than pretend otherwise." Then return to what you can bring from day one: F4's loop and the F3 decision, each in its own quote's words. Never imply hardware experience you didn't state | F7 is a gap you stated, and it sits in the job's partnering line, so the objection will arrive in some form. JD because it scores a stated responsibility. It gets the deepest rehearsal because a candid, non-defensive answer here changes the interview |
| B2 | "You've led a team of 6. This is two squads and 11 engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Accept the premise as stated: team lead of 6 for 3 years. Then say what you expect to change (less hands-on time, more leverage through senior engineers, two planning rhythms), framed as expectations. Answer slot: if you've led across more than one team or workstream, say how. If you haven't, say so plainly and stay with the team of 6 | F1's scale gap is the second most predictable objection. JD because it tests the listed scope |
| B3 | "Would you be comfortable if one of the squad leads reported to you? Have you done that?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Answer plainly: "I haven't managed managers." Then describe, as a plan, how you'd approach it: agree how decisions split, coach rather than redo, and put a regular rhythm in place. Turn it into the reverse question about squad structure (R1 reverse question 1). Hold through one follow-up without adding to the acknowledgment | F2 matters only if squads have leads, and the role text is silent on that. This interviewer is the person who knows. EXP because it checks what you've actually done |
| B4 | "Why leave payments for industrial IoT, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: give your actual reasons, in your own words: what draws you to device management and this role, and why now. Keep it consistent across all three rounds, because the Skeptic is scoring motivation consistency. Don't criticise your current employer | Motivation questions are near-certain with a would-be boss. No quote states your reasons, so the guidance is a slot, not a script |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc built only from these three sentences: 9 years in engineering, 3 as team lead of 6 at a payments company; you run the backend hiring loop (about 40 interviews last year); you pushed a reliability quarter through against roadmap pressure, and your team's on-call burden dropped 60% after. Close with why this role, in your own words (B4) | It's usually the opening question, and economy here signals EM-level communication |
| C2 | "Tell me about your hiring loop." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F4: you run it, for backend roles, about 40 interviews last year. Answer slot: if you designed parts of the loop (stages, rubrics, calibration), say which and how. If it was in place before you, say so and describe how you run it. Second slot: if you made hire or no-hire calls, say so. If someone else did, say that. If asked how the 40 was counted, give your own count, or say it's approximate, as your "about" already does | F4 is your strongest match to a stated responsibility. Expect it to be probed |

### Reverse questions — R1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Do either of the squads have their own leads, and would they report to me?" | It resolves F2's relevance directly, with the person who decides, and shows you're thinking about structure |
| 2 | "How does the device-management roadmap get set with hardware today, and where does it hurt?" | It turns your F7 gap into curiosity about their actual process |
| 3 | "What would success look like at 6 and 12 months?" | It gives you the boss's scorecard and anchors the rest of the loop |
| 4 | "What's the biggest delivery risk across the two squads right now?" | It's an invitation to solve a problem in the room, and it shows you're thinking about delivery from day one |
| 5 | "What do you need from your EMs that you're not getting today?" | It frames you as reducing their load, which is what a would-be boss is buying |
| 6 | "Of the 11, how many seats are filled, and what's the hiring plan?" | It ties to F4 and shows you're already thinking about the hiring part of the job |

---

# R2 — Thursday: panel (two staff engineers and a PM), 60 min

### Personas

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | The staff engineers pick at the 60% figure and at technical decisions | High. Technical specialists dig for depth, and your headline number is the obvious target | Know what you can and can't say about how the 60% was counted. Name your weakest assumption before they do. Say "I don't know" where it's true |
| Peer Evaluator | "Where's the seam between staff engineers and the EM?" "What would you need from me?" | High. All three panellists will work beside you, and they're pricing what you add and what you cost | Use reciprocity framing. Propose principles for how the seam should work rather than claiming to know it. Bring disagreement stories that show both spine and tact |
| Values / Behavioral | The PM asks for STAR stories about conflict and partnership | Medium. A cross-functional interviewer usually scores behaviour | Use "we" for context and "I" for your contribution, and tell only the endings your material carries |
| Conversational | Warm-up, or a "why us" aside | Low | Reuse C1's arc and B4's reasons, and keep them consistent |

Your message doesn't say whether the panel includes a system-design or technical exercise. If the recruiter confirms one, this mini-pack needs a section for it (see the upgrade menu).

### Bank

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slots, each in your own words: how "on-call burden" was measured (pages, hours, incidents, or something else); over what window; what else changed in that period that the number is sensitive to; and the assumption behind it you'd defend least, named before they ask. If you don't know how it was counted, say so plainly. Keep "after", not "because", unless you can show the link | Every headline metric gets defended. Staff engineers will push two levels down, and the pack doesn't supply the method because only you know it |
| D2 | "What was in the reliability quarter, and what part was you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The quote's own beat is that *you pushed it through* against roadmap pressure. Answer slot: if you chose or shaped the work items, say which and how. If the team or someone else chose them, say so and describe what pushing it through involved. Split "we" for the team's work from "I" for yours | The attribution probe this panel is built for. Your verb is "pushed it through", and the pack keeps it there |
| D3 | "A rollout to part of a device fleet goes wrong mid-way. How should your team handle it?" | CASE | [generic] | Structure: contain the problem first (halt the rollout, find the affected cohort), communicate, recover safely, then hold a blameless review and decide the guardrails to add (staged rollouts, health gates). Ask aloud what can and can't be rolled back on these devices. Make no claim about your past | A live problem typical of device management in general, not known to be Larkfield's practice. It tests whether you can reason in the domain without claiming it |
| D4 | "How do you decide what a staff engineer owns and what the EM owns?" | CASE | [generic] | Offer principles: technical direction and design quality with staff engineers; people, delivery commitments and staffing with you; shared ownership of priorities. Say you'd agree it explicitly with each of them, and ask how they split it today | The staff engineers are pricing whether you'll crowd them or leave them alone. It relates to F1's two-squad scope |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Say I disagree with a priority your squad has set. How do we resolve it?" | CASE | [generic] | Describe a seam principle, not a turf claim: take the disagreement into the open early, agree on the criteria (customer impact, risk, cost), decide who breaks a tie, and commit once it's decided. Offer to write it down together | Tests how you disagree with equals, which this persona scores directly |
| E2 | PM: "Product wants a feature; your squads want a reliability investment. How do we decide together?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give the joint decision method first (shared data, a cost-of-delay view, splitting capacity rather than choosing one). Then illustrate with the quote at its own scope. Answer slot: if a product partner was part of that decision, say how you worked it with them. If the pressure came from elsewhere or you didn't work it through together, say so plainly and present the method as what you'd do here | F6: your story shows pushing *against* the roadmap, and the PM will test whether you can also decide *with* them |
| E3 | PM: "What would you need from me, and what would I get from you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Reciprocity framing: what you'd bring (predictable delivery commitments, early warning on risk, an engineering voice in trade-offs) as intentions, and what you'd need (context on customers and hardware timelines). If hardware comes up, use the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap," and say you'd lean on them for that context early | Peer partnership fit, and B1's objection in collegial form. JD because it scores "partner with hardware and product" |

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you pushed back on a roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3. The beats are the ones the quote states: there was roadmap pressure, you pushed a reliability quarter through it, and your team's on-call burden dropped 60% after. Answer slot: the role's "partner with … product" makes a probe on the relationship likely. If you know how the people pushing the roadmap took it, say so, honestly. If you don't, or it was strained, say so plainly rather than supply a happy ending | A STAR story your material actually carries, told to a PM. VAL because it's scored on behaviour under tension |
| G2 | "Tell me about a time you helped an engineer grow." | VAL | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: pick one engineer on your team of 6, what they needed, what you specifically did, and what changed for them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would approach it. Don't build a story from what team leads usually do | F5 has no story in your material yet. The role names "growth for 11 engineers", so this is likely. The label is inferred because the link from your title to growth work is the pack's |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What draws you to device management?" | EXP | [generic] | Answer slot: give your own reasons, consistent with B4. Treat it as scored even when it's asked casually | Casual questions about the core domain are still scored, and the panel will compare your answer with R1 |

### Reverse questions — R2

| # | Question | Why it lands |
|---|---|---|
| 1 | To the staff engineers: "What could a new EM do in the first month that would genuinely help your work?" | The reciprocity question. It shows you plan to reduce their load, not add to it |
| 2 | "How do staff engineers and the EM split ownership here today?" | It shows you're asking how the seam works rather than claiming it, and it answers D4 with real data |
| 3 | "What does on-call look like on the device-management services right now?" | It invites F3's area naturally, without boasting |
| 4 | To the PM: "Where does the seam between hardware, product and engineering cause the most friction?" | It shows you're curious about the F7 gap, with someone who lives on that seam |
| 5 | To the PM: "When engineering wants to trade roadmap for platform health, how does that get decided?" | It tests their culture against the decision you've already made once (F3) |

---

# R3 — Monday: VP Engineering, 30 min, "values and leadership philosophy"

### Personas

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy?" "Tell me about a time…" | High. The recruiter named the round's focus as "values and leadership philosophy" | Bring a short, specific philosophy, and back each principle with a story your material carries, or say plainly where you don't have one |
| Pressure | Time-boxed challenges, or "How much of that was you?" | Medium. A skip-level interviewer tests composure, and 30 minutes forces short answers | Pause, restate the question, anchor in your quotes, and hold for two follow-ups before conceding anything specific |
| Case / Strategist | "Where should device management go?" "What does your org look like in two years?" | Low. Strategy fluency is a skip-level differentiator, but it isn't this round's stated focus | Form one view, with a stated uncertainty. Use Larkfield's own vocabulary from your own reading of their site |

**Values cheat sheet: not included.** Larkfield's published values couldn't be retrieved (the search was refused), and the pack won't guess them from memory. Paste their values page and this round gets a value-by-value story map (see the upgrade menu).

### Bank

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, in a couple of sentences?" | VAL | [generic] | Answer slot: give two or three principles you actually hold, in your own words, each one short enough to remember. Then offer to back one with a story. A3/G1 is the one your material carries (F3). Avoid slogans you couldn't illustrate | This is the round's named focus. The pack can't write your philosophy, only check that each part has a story |
| J2 | "Tell me about a time you made an unpopular call for the long-term health of your team." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3, with the same beats as G1, told at VP altitude: the trade-off you saw and the outcome you stated, nothing more. Answer slot: if there was a cost to the decision (a slipped commitment, unhappy stakeholders), say what it was honestly. If there wasn't one you know of, say so | Your best-evidenced leadership story, and it fits a philosophy round exactly. Tell it slightly differently from R2, but consistently |
| J3 | "Tell me about a time you got a call about a person wrong." | VAL | [generic] | Selection scaffold: a real misjudgement (a hire, a promotion, a conflict), what you learned and what you changed. If no such time comes to mind, say so plainly, then say how you'd catch one early. Don't invent one to seem self-aware | VPs probe self-awareness. No quote carries this story, so it's a scaffold, not a story map |
| J4 | "What does 'raising the bar' in hiring mean to you?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Philosophy first (what you look for and how you keep it fair and consistent), then ground it in F4: you run the backend loop, about 40 interviews last year. Answer slot: if you changed how the loop works, say what and why. If not, say so and describe what you'd want in Larkfield's loop | It links the "hiring" responsibility to values, which is natural ground for a VP |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold first: your part, in your sentence, was pushing the quarter through against roadmap pressure. Concede specifically: the burden was your *team's*, the drop came *after* the quarter, and you'd credit the team with the work. Answer slot: if you know what else affected the number, say it. If you don't, say so. Don't fold into "it was all the team", and don't inflate it into "I cut on-call" | Classic attribution pressure on your headline figure. It rehearses holding firm on your part and conceding honestly on the rest |
| K2 | "Sixty seconds: why you over an internal candidate who knows our hardware?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I've never managed managers and never owned a hardware-adjacent roadmap." | Concede first, briefly: "I haven't owned a hardware-adjacent roadmap, and an internal candidate knows things I'd have to learn." Then your two quoted strengths, in their own words: the hiring loop you run, and the reliability quarter you pushed through. Finish with a one-line ramp plan. Stay under 60 seconds | B1's objection at VP speed. JD because it scores fit to the listed job |
| K3 | "You've never managed managers. Why should we bet two squads on you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Accept it without defending: "That's right, I haven't managed managers." Hold on what's true: 3 years as team lead of 6. Then explain how you'd earn the scope, as a plan. If R1 told you the squads have no leads under the EM, say so briefly, without implying they made the gap irrelevant | The negative's source is your own message, so if it comes up, rehearse candour. Pressure tests composure on a gap you'll have to admit |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Where do you think device management is heading in industrial IoT?" | CO | [generic] | Before Monday, read Larkfield's own site and recent news yourself and take their vocabulary from it. Form one view with one stated uncertainty, and concede where you'd still be learning (F7). This pack supplies no facts about Larkfield, because the research didn't run | Company-strategy fluency separates candidates at skip level. Generic because no strategy source was retrieved |
| L2 | "Two years from now, if you've succeeded, what does your org look like?" | CASE | [generic] | Answer as a vision: delivery health, a team that grows its own people, a hiring bar you'd stand behind, and a working rhythm with hardware and product. Name one measure for each. Make no claims about your past | It tests altitude and links your leadership philosophy to outcomes in a short round |

### Reverse questions — R3

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which leadership behaviours separate the EMs who thrive here from those who struggle?" | It matches the round's own theme and gets you their real values in their own words |
| 2 | "Where do Larkfield's values show up in hard decisions, like a roadmap-versus-reliability call?" | It ties their values to the one story you have (F3) without repeating it |
| 3 | "What's the growth path for EMs here, including toward managing managers?" | An honest, forward-looking question that frames F2 as ambition, not a hole |
| 4 | "What's the biggest bet engineering is making in the next year?" | Strategy altitude, and it gives you material for a thank-you note |
| 5 | "What would you want to hear from me 90 days in?" | It closes on outcomes, which a skip-level remembers |

---

## Sources

- **Provided:** your message (the role description, the three rounds and your background).
- **Search 1:** `Larkfield Systems values`. Refused (no web search permission in this session).
- **Search 2:** `Larkfield Systems industrial IoT news`. Refused (no web search permission in this session).
- No dossier was provided.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. It would have moved the R3 values cheat sheet and VAL themes. The cheat sheet is dropped and R3's VAL questions take their themes from the recruiter's words |
| 2. `Larkfield Systems interview process engineering manager` | skipped | Your message already sets the three rounds, who runs each and how long, which fixes the persona weights and the banks for each round |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Refused. It would have moved L1 and the strategy-grounded CO/CASE questions, which are left generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there's no interviewer read |
| 5. representative Engineering Manager JD | skipped | The role description you pasted sets the fit snapshot's requirements and the JD-tagged questions |

---

## Upgrade menu

- **The full JD text:** may add requirements (on-call expectations, location, tech stack) that the short role description leaves out. Each one gets a fit-snapshot row and a JD-tagged question
- **Your CV:** quotes for F5 (growth) and F6 (product partnering) that could replace their answer slots with story maps, and more stories for J1–J3
- **Larkfield's values page, pasted:** an R3 values cheat sheet mapping each published value to F3 or F4, or to an honest scaffold, plus one VAL question per value
- **Web search permission:** retries targets 1 and 3, which ground L1 and adds a strategy-grounded CO question in R1 and R3
- **A deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief, the interviewers' public talks or writing, loop reports and recent org context. It needs search permission
- **Interviewer names, for any round:** an interviewer read, per-panellist persona weights in R2, and at least one reverse question tied to each person's own path
- **Recruiter guidance on the Thursday panel:** if there's a system-design or technical exercise, R2 gets a build section for it
- **Your answers to the slots in D1/K1** (how the 60% was counted) **and F4** (who makes the final hire call): F3 and F4 upgrade from answer slots to story-mapped guidance in A3, C2, D1, D2, G1, J2, J4 and K1
- **R1's answer on squad structure:** reweights B3 and K3 for R3
- **Prep time available:** a prioritised schedule across the two weeks
- **A `tuesday-dossier.md`:** would add a verified evidence map and objection list. It's not needed for this pack
