# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The careers page says this 60-minute interview is with the hiring manager, so the pack treats him as your likely future manager.
**Format, per Saltmarsh's careers page:** "the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

**Personas** describe how a question gets asked: the person and their style. **Types** describe what is being scored. Rehearse both, because the same content lands differently when it comes as a casual aside than when it comes as a time-boxed challenge.

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values |
| EXP | Whether what you say about your work holds up, and what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you've done your homework on Saltmarsh's current direction |
| CASE | How you structure and reason through a live problem from the role |

Provenance labels: `[grounded]` means it traces to something you wrote or to a source listed under Sources. `[inferred]` means it's derived from a source, and the derivation is named. `[generic]` means a role-family pattern with no claim about you or Saltmarsh.

**Answer slots** are instructions for the interview itself, not questions for you to answer here. Each one has two honest branches. Pick the branch that's true.

The guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage

The pack assumes you have about one evening, since the interview is tomorrow.

1. **C1, out loud, three times**, including both follow-ups. It's the highest-ROI prep in this pack.
2. **A1 to A4 as one continuous tabletop**, spoken aloud and timed at 20 minutes. That's the first half of the Outage Hour.
3. **The values cheat sheet, plus B1 and B2.** For each one, either pick a story or settle on the honest branch before you walk in.
4. **The answer slots in F4, F5 and F6.** Work out privately which branch is true for you, so you aren't deciding it live.
5. **Read the Project Larkspur announcement and the values page yourself**, and spend 15 minutes in each title (see A5, C3, F2).
6. **Pick three reverse questions.**

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Keep the words at their own scope: "Four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Your material shows the weekly drops for two of the four years. It doesn't say what the title's live updates looked like before that. Answer slot: the JD's live-service line makes a probe on the first two years likely. If the title was getting live updates then and you worked on them, say what you did, in your own words. If not, say so plainly and stay with the two years on the calendar |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The quote at its own scope is one title and weekly content drops: "I ran the weekly content-drop calendar for our main title." Your material doesn't say whether the drops included events or whether the title was on mobile. Answer slot: if the drops included time-limited events, say which; if the game was on mobile, say so; if neither, say so plainly and stay with the weekly calendar you ran. Running two titles is something to describe as a plan, never as a past |
| F3 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | There's no gap here, but there's also nothing behind it yet that an interviewer can inspect, so expect a probe. Lead with the quote in its own terms: you ran it, weekly, for two years |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material doesn't show who you worked with to get each drop out. Answer slot: if getting a weekly drop out meant working with design, art, engineering or community, say which teams and what part was yours, in your own words. If it didn't, or that part wasn't yours, say so plainly and return to running the calendar |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The quote at its own scope: "Every month I presented the retention numbers to our studio head." Presenting numbers is not the same as owning a review. Answer slot: if you put the numbers together or chose which ones went in, say so. If you ran any review after a content drop, say how. If neither, say so plainly and stay with presenting them monthly |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | This is the closest match in your material. Keep the words at "wrote" and "still uses": "I wrote the release checklist our QA team still uses." Managing a checklist is ongoing work. Answer slot: if you ran it release to release, or updated it over time, say how. If QA runs it and your part was writing it, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | There's no gap, but expect the Prober to ask which numbers they were and how they were counted (E1). Know what you can and can't say about that before you walk in |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Offer the checklist as your written work: you wrote it, and QA still uses it. If you're allowed to share a copy or an excerpt, bring it. A document the interviewer can actually look at is what would move this row to high |
| F9 | Monetised live content. This isn't in the JD; it comes from Saltmarsh's Project Larkspur announcement, which a search result describes as moving both titles to a season-pass model | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | You've stated this gap yourself, and wording can't close it. Words: "I haven't worked on a game with in-app purchases." Then explain how you'd learn it, framed as a plan, never as a past. Add nothing to make the gap feel smaller |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A5, C1 |
| Coordinate design, art, engineering and community on each update | C1, G1, G2 |
| Own the post-event review and its KPIs | A4, C2, E3 |
| Manage the release checklist with QA | D1, D2, B3, A4 |
| 3+ years producing live-service games or apps | C4, F1 |
| Experience running a content calendar | C1, F1 |
| Comfortable with player-retention metrics | E1, E2, E3 |
| Clear written communication | A3, D3, B3 |

---

## Reading the interviewer

This section rests on one search result for a GDC 2026 talk page. I didn't watch or read the talk itself.

- **Public path:** Head of Live Operations at Saltmarsh Games, and previously a QA lead at a console studio.
- **Self-stated theme:** his talk, "Patch Notes Are a Promise", argues that "a live team is judged by how often its patch notes describe what actually shipped."

**What follows for Friday:**

1. Release discipline and honest player communication are his own public theme. Saltmarsh's value "Ship the Patch Not the Promise" says the same thing. Expect A3, D3 and B2 in some form.
2. With a QA background, he's likely to probe the checklist (F6) more deeply than most. D1 and D2 are where that happens. Keep to "wrote" and "still uses" unless you can truthfully say more.
3. **Shared jump:** none to offer. His public path runs from QA to live ops, and none of your fit-snapshot rows carries the same move. Reverse question R1 asks about his path instead.

---

## Persona table

These weights rest on the documented Outage Hour format (tabletop, then a values conversation) and on a hiring-manager relationship.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The tabletop itself: a simulated outage during a live event | Highest. The careers page names a live-incident tabletop as half the hour, and hiring managers lean toward live problems anyway | Clarify, then stabilise, then communicate, then decide, then record. Think aloud and challenge one premise respectfully |
| Values / Behavioural (B) | The second half: "a values conversation" | High. It's documented in the format, and the three published values are short and easy to probe by name | One story or one honest branch per value. Use "we" for context and "I" for your own part |
| Skeptic (C) | Quiet probes on scale (two titles, four disciplines), title, and monetisation | High. A hiring manager is de-risking gaps, and F2, F4 and F9 are visible ones | Rehearse C1 until it's boring. Bridge only from your own quotes. Give a concrete plan for anything you haven't done |
| Pressure (D) | The tabletop tightening: time-boxed calls, "do you ship?" | Medium. A simulated outage has pressure built in | Pause and restate the question. Hold a position through two follow-ups, then concede specifically |
| Data-Driven Prober (E) | Retention numbers and post-event KPIs | Medium. The JD names retention and KPIs, and you presented retention monthly (F7) | Know how each figure was counted, or say plainly that you don't. Name your weakest assumption first |
| Conversational (F) | The opener and the transitions | Low, but scored | Have a 90-second arc ready, and treat casual questions as real ones |
| Peer Evaluator (G) | Seams with community and engineering inside one live-ops group | Low. There's one interviewer, but the job is coordination | Propose seam principles, and say what you'd give as well as what you'd need |

---

## Question banks

### A — Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two hours into a weekend event on one title, event rewards stop granting and community channels are filling up. Walk me through your first 30 minutes." | CASE | [inferred] | Clarify first: which title, all players or a segment, since when, and what exactly is failing. Stabilise: get on-call engineering, and decide whether to pause the affected part of the event. Communicate: give the community team a holding message with what's known now and when the next update will come. Decide: extend, compensate or wait, and who signs off. Record: start a timeline now so the review isn't reconstructed from memory. Say each step aloud as you take it. This guidance makes no claim about your past | Derived from the careers page's "live-incident tabletop on a simulated outage during a live event". The scenario details are this pack's own. CASE because it scores structure under a live problem |
| A2 | "Engineering says the fix needs a client update that won't clear store review before Monday. The event ends Sunday. What now?" | CASE | [grounded] | Separate what can change server-side, such as extending the event or granting rewards directly, from what needs the client update. Weigh extending the event against compensating afterwards, and tie the choice to the published value "when the calendar and the players disagree, the players win." Say what you'd need to know first, such as whether the calendar can absorb a two-day extension. Name the cost you're accepting | The follow-up a tabletop naturally takes. It's grounded on the values page, which supplies the principle the answer should mirror. CASE with a VAL undertone |
| A3 | "What goes in the first player-facing message, and what stays out?" | CASE | [grounded] | In: what's affected, that the team is on it, what players should or shouldn't do, and when the next update comes. Out: any fix time or compensation you can't stand behind yet. The values page says "we announce what is built, not what is hoped", and the interviewer's public theme is patch notes that describe what actually shipped. Mirror the principle, not his wording | This sits on his own published theme and a Saltmarsh value at once, so it's very likely. It also covers the JD's written-communication line. CASE in JD content |
| A4 | "The event's over. How do you run the post-event review on that outage?" | CASE, JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure: a timeline, the impact on the event's KPIs, root cause, what changes, and who owns each change. Close the loop into the checklist. On your own checklist, keep to the quote: you wrote it and QA still uses it. Answer slot: the values page says every release leaves "the checklist better than it found" it, so expect a probe on whether yours changed after a problem. If it did, say how, in your own words; if it didn't, or that wasn't yours, say so plainly and stay with having written it | The JD names "own the post-event review", and F5 and F6 are the closest material you have. CASE delivery, JD content |
| A5 | "From February both titles share one events calendar. How would you plan a month of it?" | CASE, CO | [inferred] | Clarify each title's goals and player base first. Then avoid collisions, sequence the shared art and engineering capacity, protect QA windows, leave a buffer for slips, and line up the community calendar. Say what you'd check with each title's leads before locking dates. Before Friday, read the Larkspur post yourself so you can use its own terms. Running two calendars is a plan, never a past (F2) | The premise comes from a search-result description of Project Larkspur, not a page I fetched, so read it yourself before relying on it. It's the differentiator question at Saltmarsh's current altitude. CASE in CO content |

### B — Values / Behavioural (the values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans — tell me about a time the calendar and the players disagreed." | VAL | [grounded] | Selection scaffold: pick a time when what players were doing changed or held up a planned drop. It needs what players did, what you changed or argued for, and what it cost the plan. If no such time comes to mind, say so plainly, then explain how you'd handle it, using A2 as your live version | The value's official name and meaning come from the values page. None of your quoted sentences carries this story, so it's a scaffold. VAL |
| B2 | "Ship the Patch Not the Promise — when have you kept an announcement to what was actually built?" | VAL | [grounded] | Selection scaffold: pick a time when what was communicated about a drop was cut back to match what was ready. It needs what was going to be said, what was actually ready, and your part in closing the gap. If no such time comes to mind, say so plainly, then walk through how you'd decide what goes in a player message (A3) | This is both a published value and the interviewer's own theme, which makes it the likeliest VAL question. No quote carries the story. VAL |
| B3 | "Leave the Build Greener — what have you left better than you found it?" | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6: you wrote the release checklist, and QA still uses it. Those are the beats the quote states, so tell them in your own words. Answer slot: the value names the checklist, so expect a probe on whether yours improved over time. If you updated it, say what and why; if not, or that wasn't yours, say so plainly and stay with having written it | The one value your material maps to directly. The value even names "the checklist". VAL, with EXP scrutiny on attribution |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs the message, the stake, the moment you didn't soften it, and an intact relationship afterwards. If one of your monthly retention presentations was such a time, it qualifies; tell it in your own words. If none comes to mind, say so plainly and say how you'd handle bringing bad numbers to a studio head | It's a persona stem that a values conversation commonly reaches for, and F7 is the nearest material. VAL |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role coordinates design, art, engineering and community on every update, across two titles. What's the closest you've done to that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Never led a team, and never worked on a game with in-app purchases." | **The highest-ROI rehearsal in this pack.** Open with the hold, which goes only as far as the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's coordination line makes this probe certain. If getting each drop out meant working with design, art, engineering or community, say which teams and what was yours, in your own words. If it didn't, or that part wasn't yours, say so plainly and stay with running the calendar. Then the two titles, said as a plan: how you'd sequence shared teams and where you'd start. **Follow-up 1**, "but you've never led a team": "I haven't led a team." Then return to the calendar; coordinating a schedule and leading people are separate claims. **Follow-up 2**, "an art lead says your date won't work — what do you do?": answer it as a plan, never as a remembered past. The limit is said, never apologised for | F2 and F4 are where this JD presses hardest on your material, so the objection arrives in some form. Its depth is in the follow-ups and the exact concession, not in extra content. JD, because it scores the listed requirement |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Pick a real one. Owning the post-event review (F5) is the honest candidate: "I've presented our retention numbers to the studio head every month." Answer slot: if you also built the numbers or ran a review after a drop, say so; if not, say plainly that the review itself would be new, and give a 30-day plan for learning how Saltmarsh runs it. Never pick a fake weakness | A standard Skeptic stem. F5 is the gap between presenting numbers and owning a review. JD |
| C3 | "Our titles are moving to a season pass. Have you worked on monetised live content?" | JD, CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: how you'd learn the titles' economy, who you'd sit with, and what you'd read first. Don't make the gap feel smaller, and don't claim monetisation knowledge you got from reading | F9 is a gap you've stated, and the search result on Larkspur makes the season pass a live topic. JD-adjacent, in CO context |
| C4 | "Your title is associate producer. Why are you ready to be the producer?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses." | State the facts at their scope: four years as an associate producer, two of them running the weekly content-drop calendar for the main title, and you wrote the release checklist QA still uses. Let him draw the conclusion rather than telling him what it proves. Answer slot: give why this role and why Saltmarsh, in your own words | Title gaps are a predictable hiring-manager probe (F1). EXP, because it scores how you represent your own level |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. The fix is ready but QA hasn't finished the checklist. Do you ship?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Pause and restate the question. Position: you don't skip the checklist blind; you ask QA which items cover what this fix touches, and agree a scoped pass with them. You can say "I wrote the release checklist our QA team still uses" as context for knowing what goes into one, but not as a claim that you've made this call before. Hold through two pushes. Then concede specifically, for example that if the event is losing players by the hour, a narrower pass is a real trade-off and you'd name who signs it off | It tests composure, and a QA-background interviewer will press on checklist discipline (F6). CASE delivered as pressure |
| D2 | "That checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and QA still uses it." Answer slot: if others added items or reviewed it, name their part plainly: "we" for theirs, "I" for yours. If it was yours alone, say so without decoration. Don't add how it was adopted or what it prevented unless that's true and yours | F6 is your strongest line, which makes it the line a prober tests for attribution. EXP |
| D3 | "Players are furious, the studio head wants an ETA in the next post, and engineering won't give one. What goes out?" | CASE | [grounded] | Hold: no ETA you can't stand behind, which mirrors "we announce what is built, not what is hoped". Offer a time for the next update instead. Concede that this costs goodwill in the short term, and say how you'd explain the choice to the studio head | The stakeholder squeeze inside an outage tests both the published value and written communication. CASE under pressure |

### E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You presented monthly retention to your studio head. Which metrics, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, in your own words: which retention numbers they were, how they were counted, what they were sensitive to, the assumption behind them you'd defend least, and which part was yours (compiling, analysing, or presenting). If you don't know how a figure was counted, say so plainly. That's an honest branch, not a failure | Every metric on your record gets a defend-the-number check (F7). EXP |
| E2 | "How would you tell whether an event moved retention, rather than just coinciding with it?" | CASE | [generic] | Compare against a baseline period or a holdout if one exists. Watch for self-selection, since players who join events were already more engaged; that's the weakest assumption, so name it first. Check for seasonal effects and other launches in the same window | A standard analytics probe for a KPI-owning role. CASE, because it scores reasoning, not record |
| E3 | "What KPIs would you put on a post-event review for a season-pass event?" | JD, CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Engagement: participation, completion, and session changes. Retention: the participant cohort at day 1, 7 and 30. Monetisation: conversion and revenue per user. Then be plain: "I haven't worked on a game with in-app purchases", so you'd learn how Saltmarsh reads the monetisation side. Finish with what decision the review should feed | It's the JD's KPI line on Saltmarsh's announced model, and F9's gap shows up inside it. JD content, CASE delivery |

### F — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; writing the release checklist QA still uses; presenting monthly retention numbers to the studio head. Close with why live ops at Saltmarsh, which is an answer slot in your own words | It's the opener, and it's scored on economy. Every beat is one of your own sentences. EXP |
| F2 | "What are you playing at the moment? Any live events you admire?" | CO | [inferred] | Bring one genuine example and say what the event did for players. Play Tidepool Tactics and Lantern Row before Friday. If you haven't had time, say what you have seen rather than bluffing | The titles are named in a search result about Larkspur. A casual question that's still scored. CO |

### G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Live ops is becoming one group across both titles. Where's the seam between you and community, and what happens when you disagree?" | JD | [inferred] | Propose principles rather than pretending to know the seam: community owns the voice to players, the producer owns the dates and what ships, and you agree up front who announces what. Disagreements get settled against the calendar and the player evidence. Answer slot: the JD names community coordination. If you worked with a community team on drop announcements, say how, in your own words; if not, say so plainly | The "one group" premise comes from the Larkspur search result, and the JD names community. JD |
| G2 | "What would you need from engineering in week one, and what would you give them?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Reciprocity first: what you'd give is an early, stable calendar, lock dates, and a clear release checklist. You can say you wrote the one your QA team still uses. What you'd need is their real capacity and their known risks | Covers the engineering coordination line (F4) from the partner's side. JD |

---

## Values cheat sheet

The source is the values page at saltmarshgames.com/values, fetched.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and player behaviour conflict, the schedule gives way | Selection scaffold: a time players' behaviour changed or held up a planned drop. It needs what players did, what you changed, and what it cost the plan. If none comes to mind, say so plainly and show how you'd handle it (A2) |
| Ship the Patch Not the Promise | Communicate what's ready, never what's hoped | Selection scaffold: a time communication about a drop was cut back to what was ready, and your part in that. If none comes to mind, say so plainly and walk through A3 |
| Leave the Build Greener | Each release leaves the code and the checklist better than before | F6: "Wrote the release checklist our QA team still uses." Answer slot on whether you improved it over time, as in B3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead to running live ops. What from QA do you still lean on most during an event?" | It's tied to his public path, and it turns the interview toward his own experience |
| R2 | "Your GDC talk argued that a live team is judged by whether its patch notes describe what shipped. How does the team track that today?" | It shows you looked him up, and the answer tells you how the role is measured |
| R3 | "With Larkspur moving both titles onto one calendar in February, what does this role own during the transition?" | It's current. It also surfaces the real scope of a role that's being created during a reorganisation |
| R4 | "What does a good post-event review look like here? Who reads it, and what decision does it feed?" | It goes straight at a JD responsibility, and the answer shows what "owning the KPIs" means in practice |
| R5 | "Is the release checklist with QA something this role inherits or rebuilds?" | It plays to F6 without overclaiming, and tells you the state of the process |
| R6 | "Which of the three values is hardest to hold during a live event?" | It invites candour, and it shows you read the values as working rules rather than slogans |
| R7 | "What would make the first 90 days a success in your eyes?" | It gives you his criteria in his words, which you can use in any follow-up |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | A negative you stated: "Never led a team" | "I haven't led a team." |
| Worked on a monetised game, an in-app-purchase economy or a season pass | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for multiple titles, or ran live events | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says weekly content drops for one main title. F2's slot stays inside that calendar |
| Owned the post-event review, or set the KPIs | Inflated form of F5 | F5's quote at its own scope. The pack's observation: your material says you presented the numbers. C2's slot stays inside what you did with them |
| Managed the release process or ran QA | Inflated form of F6 | "I wrote the release checklist our QA team still uses." D2's slot stays inside the writing and who else contributed |
| Has been a producer, or has four years running live ops | Inflated form of F1 | F1's quotes at their own scope: four years as an associate producer, two of them on the weekly calendar |

---

## Sources

**Provided:** your message (the JD text and your background).

**Searches sent:**

1. `Saltmarsh Games values` returned saltmarshgames.com/values
2. `Saltmarsh Games interview process producer` returned saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio news 2026` returned saltmarshgames.com/news/project-larkspur. Only the search snippet was used; the page wasn't fetched
4. `Tobias Wrenfield Saltmarsh Games` returned talks.gdconf.example/2026/patch-notes-are-a-promise. Only the search snippet was used; the page wasn't fetched

**Fetched:** saltmarshgames.com/values and saltmarshgames.com/careers/interviewing.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet, B1 to B3, A2, A3 and D3. Three values, by their official names |
| 2. Saltmarsh interview process | yes | The loop is established: the Outage Hour, a tabletop then values, with no take-home. It set the persona weights and confirmed a values round |
| 3. Saltmarsh strategy / recent news | yes | The Project Larkspur snippet (season pass, one shared calendar, one live-ops group) drives A5, C3, E3, G1, F9 and R3. It's labelled inferred because the page wasn't fetched |
| 4. Tobias Wrenfield, Saltmarsh | yes | The GDC 2026 talk snippet drives the interviewer read, R1 and R2, and the emphasis on A3, D1 and D2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Deeper research.** Up to 6 more searches and 2 more fetches, taking several more minutes. It would let me read the full Larkspur post and the GDC talk, look for candidate reports of the Outage Hour, and check recent org context. A5, C3, G1, R2 and R3 would move from snippet-based to fully sourced.
- **Your CV text.** Each extra sentence becomes a quotable piece of evidence. F4 and F5 are the rows most likely to change, and C1, C2 and G1 could become story-mapped.
- **Your answers to the slots in F2, F4, F5 and F6.** These cover whether the drops included events, whether the game was on mobile, who you worked with on each drop, what you did with the retention numbers, and whether you kept the checklist up to date. Your answers would turn C1, C2, A4, B3, D2 and E1 from slots into stories.
- **The recruiter's prep notes, if any.** Any stated focus areas for the Outage Hour would reweight A and B.
- **A copy or excerpt of the checklist you can share.** It would move F8, and possibly F6, from medium to high.
- **A tuesday-dossier.md.** It would add an evidence-graded objection list and a prohibited-claims list confirmed with you, in place of the ones this pack built locally.
