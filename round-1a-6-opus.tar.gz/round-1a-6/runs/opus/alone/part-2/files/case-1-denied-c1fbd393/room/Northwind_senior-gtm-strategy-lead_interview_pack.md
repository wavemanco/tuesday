# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He would be Priya's **peer**, and both roles report to the same VP.
**Format:** one 60-minute conversation.
**Built from:** the coach's notes (JD highlights, Priya's background, Dan's profile, the research note). Web research was attempted and refused by this host; see Sources.

---

## How to use this pack

Read it on two axes:

- **Personas show how a question is asked**: the register, the follow-ups, the pressure. Dan will mix several in one hour.
- **Types show what is scored.** Each question has one primary type:

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's values. Here it is generic, because Northwind's published values were not available |
| EXP | Whether claims about her past hold up: what was actually hers |
| JD | Whether she can do the listed job, gaps included |
| CO | Fluency in Northwind's strategy, competition and priorities |
| CASE | Structure and reasoning on a live problem from the role |

**Provenance labels:** `[grounded]` traces to the coach's notes. `[inferred]` is derived, and the derivation is named. `[generic]` is a role-family pattern with no claim about Northwind or Dan.

**The guidance is scaffolding, not a script.** Wherever a cell says *answer slot*, the pack does not know the answer. Priya fills it from what she actually did, or says plainly that it wasn't hers or never happened. Each answer should take 90 to 120 seconds to say.

**Highest-ROI prep in this pack: D1**, the sales-ops and quota-setting objection. Dan owns that domain, so it will come up in some form, probably framed collegially. Rehearse it until it sounds boring. **D2** (partner-motion design, which the JD says is "required") is a close second.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your note | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy and ops. It doesn't show go-to-market ownership, and her words stay at the quote's scope: "Two years in strategy consulting, then nine years in product strategy and ops at a large consumer-tech company." Answer slot: "own GTM strategy" makes a probe likely on whether any of that work was go-to-market strategy for a product. If some was, she says which product and which part she owned, in her own words. If none was, she says so plainly and stays with the product-strategy work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your note | none given | none | [grounded] | discovery | Strong evidence would be an analysis that found where an existing customer base under-bought, and what was done about it. Answer slot: if any of her work found growth inside an existing base, she names that work in her own words and says which stage it touched. If none did, she says so plainly and walks through how she would find whitespace here (C2 is the rehearsal). She shouldn't relabel past work with the JD's stage names. She describes the work and lets Dan map it |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your note | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. It's a self-report with nothing inspected behind it, so expect a probe on "independent". She names the tools in the quote's terms. Answer slot: if she has built an analysis end to end herself, she offers to walk through it, covering the question, the data, the query and what it fed. If her analyses were always shared work, she says which parts were hers |
| F4 | "partner-motion design experience required" — JD highlights, your note | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in negotiations is adjacent to designing a partner motion, but it isn't the same thing, and the bridge shouldn't be stretched. Her words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "required" makes a probe on design almost certain. If she shaped any part of how partners were chosen, paid or engaged, she says which part and how she decided, in her own words. If she didn't, or there was no such design step, she says so plainly and stays with the model |
| F5 | "strong cross-functional influence" — JD highlights, your note | "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | No gap. Both quotes reach influence in role-relevant terms: consensus across orgs, and a proposal that was adopted and credited. Lead with them in their own terms ("set ... with cross-org consensus", "proposed", "credited"). Expect Dan to ask how the consensus was reached and how the figure was counted (A1, B2) |
| F6 | "AI experience a plus" — JD highlights, your note | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The material shows daily use of AI tools. It doesn't show AI product or AI go-to-market work. Her words: "I use AI tools daily." Answer slot: if any of her work involved shipping, pricing or selling an AI feature, she says what and what part was hers. If none did, she says so and offers a user's-eye view of what makes a copilot stick, framed as a hypothesis |
| F7 | Working fluency in sales planning, meaning coverage, capacity and quota, which is the peer's own domain. Inferred from Dan's title, "Director of Sales Strategy" (your note), and the JD's land/adopt/expand/renew line | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A stated gap that wording can't close. Her words: "I haven't done classic sales-ops or quota-setting work." Then how she would learn it, said as a plan and never as past experience. She doesn't present volume targets as quotas, and adds nothing to make the gap feel smaller |

---

## Reading the interviewer

Built from Dan's profile as summarised in your note. His public footprint could not be checked because the search was refused.

| Signal | What it implies for this hour | Provenance |
|---|---|---|
| Director of Sales Strategy and Priya's peer, both reporting to the same VP | He is weighing whether she lightens or adds to his team's load, and where the line between their roles falls. Expect collegial seam and credit questions (B bank). Gaps from the other banks will come back phrased as "how would that work with my team" | [grounded] |
| Self-describes as "relentlessly data-driven" | Every number gets probed down to how it was counted. The ~$400M figure (F5) is the obvious target. Prober weight goes up. A plain "I don't know exactly how finance counted it" will play better with him than a fluent guess | [grounded] |
| Career spine in pricing and monetization roles | Case questions lean toward pricing, packaging and unit economics (C3, C4). Shared vocabulary on offer: the F4 quote, "built a partner-level revenue model used in carrier negotiations", is monetization-adjacent language he will recognise. It's a mirror opportunity in vocabulary only, kept at the quote's scope | [grounded] |
| One early-stage-startup chapter | Scrappy builder stories land well. Expect a probe on big-company pace (D4, F2). Priya's material shows no startup chapter, so no shared career move is offered. Reverse question R2 uses his chapter instead | [grounded] |

---

## Persona weights

Starting point for a peer interview: Peer Evaluator and Data-Driven Prober lead. The adjustments come from Dan's profile. The loop is set by your note: this is one 60-minute session with Dan. Northwind's wider interview loop couldn't be researched.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?", "What's the denominator?", follow-ups two levels deep | Very high. Peer prior plus his "relentlessly data-driven" self-description | Know what she can and cannot say about how each figure was counted. Name the weakest assumption before he does. Offer to walk an analysis end to end if she built one herself |
| B. Peer Evaluator | Seams, credit, "what would you need from me" | Very high. This is the core of the peer prior, and they share a VP | Frame things in terms of what she brings his team. Propose principles for dividing the work rather than pretending to know where the line sits. Show spine and tact together when they disagree |
| C. Case / Strategist | Live GTM, whitespace and pricing problems | High. The JD is strategy-heavy, and his pricing background tilts the cases toward monetization | Clarify, then set the objective, segment, choose an approach, pick metrics, name risks. Use Northwind's own priorities as the vocabulary |
| D. Skeptic | The sales-ops gap, partner design, why B2B, why now | High. F7 is a gap in his own domain, and F4 is a "required" line | Rehearse D1 until it's boring. Bridge only from the quotes. Say the limit before he asks for it |
| E. Conversational | The journey opener, a casual "what are you doing with AI" | Medium. Usually the first five minutes, and still scored | A 90-second arc built from F1. Treat the AI aside as scored, because AI is a plus on the JD |
| F. Pressure | Time-boxed "how much was you", "why not an internal hire" | Low to medium. Peers rarely go hostile, but a pricing-minded skeptic may test the headline number hard | Pause and restate. Hold through two follow-ups, then concede the specific uncertainty |
| G. Values / Behavioral | "Unpopular truth", "data versus a senior opinion" | Low. No values round is detected for this session, and Northwind's values weren't available | A selection scaffold with an honest way out. These questions are themed generically |

---

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the ~$400M ARR uplift. How was that number counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start at the quote's own scope: she proposed the store-surface change, and it was credited with roughly $400M in ARR uplift. Keep "credited", because it's the honest verb. Answer slots, each in her own words: how the figure was counted, and if she doesn't know, she says "I don't know exactly how it was counted"; what it is most sensitive to; and the assumption behind it she would defend least, named before Dan asks. Which part was hers: the proposal is in the quote. Anything beyond it, such as building, launching or measuring, she claims only if it was hers, and otherwise says plainly whose it was | F5 holds the CV's headline metric, and Dan's self-description makes a defend-the-number probe close to certain. EXP because it tests attribution and counting, not the strategy |
| A2 | "What else changed around the same time that could explain that lift?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | This is the sensitivity slot, asked as a follow-up. Answer slot: if she knows of concurrent changes or how they were controlled for, she says so in her own words. If she doesn't, she says so plainly and says what she would want to see to be confident. She doesn't invent a control group or a test design. Ending on "credited is the word I'd stand behind" is a strong close | A data-driven interviewer goes two levels down. Rehearsing the second level separately stops A1's good answer from collapsing on the follow-up. EXP for the same reason as A1 |
| A3 | "Tell me about the partner-level revenue model. What went into it, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The quote's beats: she built it, it was partner-level, and it was used in carrier negotiations. Answer slot on contents: if she can describe its inputs and structure, she does so in her own words and keeps confidential specifics general. Answer slot on use: if she was in or close to the negotiations, she says in what role. If she wasn't, she says so plainly and stays with how the model was used. "Used in" doesn't mean she negotiated | F4 is the nearest evidence to the "required" partner line, and to Dan's pricing and monetization background. A prober will open the model before a skeptic challenges the gap. EXP because it tests what was hers |
| A4 | "This role runs its own analysis in SQL and Tableau. What's one analysis you've built yourself, end to end?" | JD | [grounded] "skilled in SQL/Tableau" | Pick one analysis where she wrote the queries herself. It should have a business question, the data she used, what she built, and the decision it fed. Offer to sketch the query logic aloud. If no single analysis was fully hers, she says which parts were and stays there. She shouldn't name a dashboard or a dataset she can't describe from memory | Covers the JD's SQL and Tableau line (F3), and "independent" is the word a data-driven peer tests. JD because it scores a stated requirement directly |
| A5 | "Say Compass, our AI copilot, is launching. What would you put on the first adoption dashboard, and what number would make you change course?" | CASE | [grounded] | Clarify first: who gets Compass (existing enterprise accounts or new logos) and whether it's priced separately. Then structure it: activation (accounts switched on), adoption (weekly active users per account against licensed seats, with the denominator said aloud), depth (tasks per user), and the commercial link (expansion or renewal in accounts that use it against those that don't). Name the kill-or-double-down threshold as a hypothesis to test, not a fact. Close by naming the metric's weakest assumption, such as usage not meaning value | The research note names Compass as a stated priority. The question lets her show the SQL/Tableau mindset on Northwind's own problem. CASE because it's a live problem with nothing presupposed about her past. Provenance is grounded on the research note, which couldn't be checked for currency |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We'd both report to the same VP. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than a boundary she can't know yet. Sales Strategy owns the core motion's planning. Emerging Products owns the new lines' motion until they scale into the core. The two share one set of account and pipeline definitions. When they disagree: bring the data first, agree on what would change each other's mind, then go to the VP together with one recommendation, never separately with two. Then ask him where he sees the seam. Asking is part of the answer | The core peer question, especially with a shared VP. CASE because it's a live organisational problem, and `[generic]` because the seam principles are a pattern rather than a fact about Northwind |
| B2 | "Tell me how you got cross-org consensus on the annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The quote's beats: she set annual volume targets, and did it with cross-org consensus. Answer slot: the JD's "strong cross-functional influence" makes a probe likely on who disagreed and how it was resolved. If someone pushed back, she says who (by function) and what moved them, in her own words. If there was no real disagreement, she says so and describes how she reached agreement. She calls them volume targets, never quotas (see F7) | F5 is the strongest evidence for influence, and the closest thing to Dan's planning world, so he'll test it. EXP because it checks what the consensus actually took |
| B3 | "Tell me about a time you had to move a team you had no authority over." | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift"; "set annual volume targets with cross-org consensus" | Choose one of the two quoted stories. Answer slot: if getting the store-surface change adopted meant persuading another org, she says who and how, in her own words. If adoption didn't need persuading, she uses the volume-targets story instead. A good answer needs a named stake, a point where agreement wasn't given, and the relationship still intact at the end. If neither story has that, she says so plainly and gives the nearest example she can stand behind | Covers the JD's cross-functional influence line (F5) through an open prompt. JD because it scores a stated requirement. The peer register makes it a "will you be easy to work with" test |
| B4 | "What would you need from my team in your first 90 days, and what would you give back?" | JD | [grounded] "skilled in SQL/Tableau" | The needs: access to bookings, pipeline and account data; his team's segment and territory definitions, so the new lines speak the same language; and a standing slot to test GTM hypotheses against his team's view. The give-back, kept to the quote: "I'm skilled in SQL and Tableau, so I can do my own analysis rather than queue behind your analysts." Then offer one shared artifact, such as a new-lines view of the installed base his team can reuse. Present it as an offer, not a promise of results | The reciprocity test every peer runs. It's also where F7's gap becomes concrete: she'll need his team's planning knowledge, so she should say so as a two-way trade. JD because it scores the influence and analysis lines together |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You'd own GTM for two new product lines. What do you need to know before you set a plan?" | JD | [grounded] | Clarify: what each line is, who it's for, its maturity, and whether it sells into the existing base or to new logos. Objective: tie it to the three stated priorities, which are enterprise expansion, Compass and profitability. A plan that grows revenue at negative margin misses the third. Segment by land, adopt, expand and renew. Motion: direct, partner, or attach to the core sale, with a reason for each line. Metrics: one leading and one lagging per stage. Risk: the larger platform vendor's bundling. Challenge one premise politely, for example "should both lines get the same motion?" | This is the role's headline mandate (F1), delivered as a case. Primary type JD because it scores the stated responsibility. CASE is the delivery, and the research note supplies the vocabulary |
| C2 | "How would you find whitespace for a new line in our installed base, using the data we have?" | CASE | [generic] | Structure: an account-by-product matrix showing who owns what. Add fit signals (firmographics, use of adjacent products, support patterns) and timing signals (renewal windows, contract expansions). Rank accounts by propensity and size. Validate with a small sales pilot before scaling. Say the SQL aloud at a high level: join accounts to products to usage, then filter by renewal date. Name the weakest assumption, which is that usage of adjacent products predicts appetite | Covers F2's requirement as a live problem, since her material is silent on it. `[generic]` because the method is a pattern. Dan will look for data discipline here |
| C3 | "A much larger platform vendor bundles a good-enough version of what we sell. How do we respond: price, packaging, or motion?" | CO | [grounded] | Don't open with a price cut. Profitability is a stated priority, and a discount war against a bigger balance sheet is a losing trade. Lay out the options. Packaging: bundle the new lines and Compass so Northwind's own bundle is the deeper one. Segment: concentrate where depth beats good-enough. Motion: partners who are not aligned with the bundler. Say what data would decide it: win/loss reasons, discount trends, renewal risk in accounts that also use the bundler. Concede the honest limit: some low-end loss may be the right call | The research note names bundling as the main competitive threat, and Dan's pricing background makes this his home ground. CO because it tests strategic fluency in Northwind's position |
| C4 | "Compass: separate SKU, bundled into existing contracts, or a lever for expansion? Pick one and defend it." | CASE | [grounded] | Pick one, say why, then say what would change her mind. One defensible line: use it as an expansion lever, included in higher tiers, because it supports enterprise expansion and gives an answer to the bundler, with a paid add-on for heavy usage to protect margin. Name the trade-off: it's harder to read Compass's standalone value. Name the data needed: usage against renewal and expansion. Hold the pick through one push-back, then concede the specific uncertainty | All three stated priorities meet in one pricing decision, in Dan's native language. CASE because it's a live decision, and the forced choice tests whether she will take a position with a peer |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle the sales-planning side of this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Name the limit first, before he presses: "I haven't done classic sales-ops or quota-setting work." Then the adjacent fact at its own scope: "I've set annual volume targets with cross-org consensus." She doesn't call them quotas. Then a plan, said as a plan: learn his team's coverage and capacity model first, agree shared definitions, and lean on his team's expertise rather than rebuild it. If he follows up with "so how is that different from quota?", answer slot: she says in her own words what the volume targets were used for. If she doesn't know how they connected to sales compensation, she says so. If he follows up with "why not hire someone who has?", she holds by returning to the JD's weight (new-line GTM, whitespace, partner motion, independent analysis) and the quotes that speak to them. She never stretches the volume targets | F7 is a stated gap in the interviewer's own domain, so it is the objection most certain to come up, probably phrased collegially. JD because it scores fit to the job's planning side. Deepest rehearsal means the limit comes first and the hold stays inside the quotes |
| D2 | "The JD says partner-motion design is required. Tell me about a partner motion you've designed." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Second-deepest rehearsal. She holds at the quote: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if she shaped how partners were selected, paid, tiered or engaged, she says which part and how she decided, in her own words. If she didn't, or no such design existed on her side, she says so plainly, then explains how she would design one for Northwind as a plan: partner type by product line, economics, enablement and attribution. Through two follow-ups she goes back to the model and the plan and adds nothing to her past | F4 is adjacent work against a "required" line, and the question presupposes a practice the quote doesn't carry, so the honest second branch has to be ready. JD because it scores the stated requirement |
| D3 | "Land, adopt, expand, renew: which of those stages have you worked on directly?" | JD | [grounded] | Answer slot: if any of her work grew revenue inside an existing customer base or protected it at renewal, she names the work in her own words and lets Dan map it to a stage. If none did, she says so plainly and moves to how she would find whitespace here (C2's structure). She doesn't relabel consumer-tech work with B2B stage names | F2's requirement has no evidence in the material. The question names the JD's own stages, so the slot needs an honest "none" branch. JD because it scores the stated line, with provenance grounded on the JD highlights |
| D4 | "Nine years in consumer tech. Why B2B data infrastructure, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: the reason is hers alone, and she gives it in her own words. Shape: why this role (one or two JD lines that genuinely pull her), why Northwind (one of the research note's priorities she wants to work on), and why now. It should match whatever she has told the recruiter. She doesn't claim B2B experience she hasn't stated, and doesn't talk down the past role | F1 shows a consumer-tech career moving into a B2B role, and Dan's startup chapter makes pace and fit probes likely. EXP because it tests whether her motivation story holds together |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc built from the quotes only: consulting, then product strategy and ops, the partner-level revenue model, and the store-surface proposal and the credit it got. End on why this role, in one sentence that bridges to D4. Expect him to pick a thread to pull, so put the strongest one last | The opener in nearly every peer interview, and casual is still scored. EXP because whatever she highlights becomes the next probe |
| E2 | "What are you actually doing with AI tools these days?" | JD | [grounded] "uses AI tools daily" | Answer slot: she names the tools and one real, repeated use from her own work, in her own words. Then turn it to Compass as a user's hypothesis: what makes a copilot stick or fail, as she sees it as a daily user. She doesn't claim AI product or AI GTM experience unless she has it (F6) | AI is a plus on the JD and a stated Northwind priority, and casual asides on plus-skills get scored. JD because it tests the plus line |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "$400M credited to one surface change. Honestly, how much of that was you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, then hold the quote: "I proposed the change. The uplift was credited to it." Hold through two follow-ups without inflating or apologising. Then concede specifically: the credit was assigned by whoever counted it, and building and shipping involved others. Answer slot: if she knows who did what, she says so in her own words. If she doesn't, she says so. She doesn't fold the claim down to nothing, because the proposal was hers | The pressure version of A1, aimed at F5's headline. A pricing person may test it harder than politeness suggests. EXP because it scores attribution under stress |
| F2 | "Sixty seconds: why you over an internal sales-ops person who already knows our pipeline?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Concede the specific point first: "I haven't done classic sales-ops or quota-setting work, and an internal person knows your pipeline better on day one." Then hold with the quotes: she's skilled in SQL and Tableau, and she built a partner-level revenue model used in carrier negotiations. The role is about new lines, where knowing the core pipeline matters less than structuring a new motion. Stop at 60 seconds | Combines F7 and F3 under a time limit. It's the short, sharp version of D1. JD because it scores her fit against the alternative hire |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time the data said one thing and a senior stakeholder wanted another." | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift"; "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time she held a data-backed position with someone senior. It needs a named stake, the moment she didn't fold, what was decided, and the relationship intact afterwards. Answer slot: if the store-surface proposal or the volume targets involved that kind of disagreement, she says so in her own words. If neither did, she picks another true story, or if none comes to mind, says so and describes how she would handle it | Themed on Dan's "relentlessly data-driven" self-description, which counts as the interviewer's own words, so it will resonate with him. VAL because it scores behaviour against a stated working style, since Northwind's values couldn't be fetched |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a time she said something leadership didn't want to hear, and it landed. It needs what was said, to whom, the risk to her, and what changed. Use "we" for context and "I" for her contribution. If no such time comes to mind, she says so plainly and gives the nearest true example. She doesn't invent the ending | A common behavioral probe in strategy roles. Peers ask it to see whether she'll be honest with the shared VP. `[generic]` because no published Northwind value themes it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines (F1) | C1, D4, E1 |
| Whitespace across land/adopt/expand/renew (F2) | D3, C2 |
| Independent analysis in SQL and Tableau (F3) | A4, B4, A5 |
| Partner-motion design, required (F4) | D2, A3 |
| Strong cross-functional influence (F5) | B3, B2, B1 |
| AI experience, a plus (F6) | E2, A5 |
| Sales-planning fluency, the peer's domain (F7) | D1, F2, B4 |
| Headline metric, the ~$400M uplift | A1, A2, F1 |
| Stated priorities: enterprise expansion, Compass, profitability, bundling threat | C3, C4, A5, C1 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "Coming from pricing and monetization, how do you think about packaging new lines alongside the core? Is that a seam we'd share?" | It's tied to his career path and turns a monetization topic into a conversation between peers |
| R2 | "What from your startup chapter shows up in how you run sales strategy here?" | It's tied to his path, and it shows she read *him*, not just the company |
| R3 | "What could someone in my seat do in the first month that would genuinely help your team?" | The reciprocity question a peer interview calls for. It answers B4's question from his side |
| R4 | "Do Sales Strategy and Emerging Products work from one source of truth for account and pipeline data today, or two?" | It speaks to a data-driven interviewer in his own terms and surfaces the real seam |
| R5 | "Where does the bundling pressure show up first in your numbers: win rates, discounting or renewals?" | It shows command of the research note and invites him to share his data |
| R6 | "With profitability a stated priority, how is the VP weighing growth from new lines against margin?" | It shows she has heard the three priorities as a set, and tells her how the role will be judged |
| R7 | "How do you expect Compass to be sold: through the existing field motion, through partners, or both?" | It ties the AI launch to the partner-motion requirement, where her role and his meet |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Designed a partner motion or partner programme | Inflated form of F4 | F4's quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." The limit is the pack's observation: the material says she built a model, not that she designed a motion. D2's slot stays inside the model |
| Led or ran the carrier negotiations | Inflated form of F4 ("used in") | F4's quote. A3's slot asks only what her role was, with "I wasn't in the room" as an honest branch |
| Drove, delivered or generated the ~$400M ARR | Inflated form of F5 ("proposed ... credited with") | F5's quote: "proposed a store-surface change credited with a ~$400M ARR uplift." Keep "proposed" and "credited" |
| Has set sales quotas or run sales ops | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." Volume targets are never called quotas. No slot |
| Has owned GTM strategy | Inflated form of F1 ("product strategy & ops") | F1's quote at its own scope. The slot in C1 and D4 never names ownership as hers |
| Has AI product or AI GTM experience | Inflated form of F6 ("uses AI tools daily") | F6's quote: "I use AI tools daily." E2's slot stays inside use |

---

## Sources

**Provided:** the coach's notes. These include the JD highlights, Priya's background, Dan Kovac's profile summary (role, self-description, career spine) and the coach's research note on Northwind's priorities and competitive threat. No dossier was present.

**Searches sent:**

| Query | Outcome |
|---|---|
| Northwind Data company values | refused |
| Northwind Data interview process strategy | refused |
| Northwind Data Compass AI copilot (a check of the research note) | refused |
| Dan Kovac Northwind Data sales strategy | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Refused by this host. It would have themed the G bank on Northwind's published values. It wouldn't have added a values cheat sheet, because no values round is detected for this session |
| 2. Northwind Data interview process | unavailable | Refused. Your note establishes this session (one hour with Dan as a peer), so the persona weights hold. It would have shown whether a values or case round sits elsewhere in the loop |
| 3. Northwind Data strategy and recent news | unavailable | Refused. It was a quick check that the research note is current and genuine. It would have confirmed or corrected the vocabulary in C1 to C4 and A5. Those rows rest on the note as given |
| 4. Dan Kovac at Northwind Data | unavailable | Refused. It would have checked his public footprint and added any talks or posts to the interviewer read. That read rests on your note alone |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix rows F1 to F6 and the JD-tagged questions. A representative JD would only add `[inferred]` lines |

---

## Upgrade menu

- **Full JD text** → mid-list requirements (named tools, methods, partner types) get their own rows and questions, and the coverage table checks against the whole list rather than the highlights.
- **Web search allowed in this session** → targets 1 to 4 rerun. That means Northwind's published values for the G bank, the wider interview loop, a check that the research note is current, and Dan's public talks or posts for the interviewer read.
- **Deep research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Northwind's segments, numbers and recent moves, which makes C1 to C4 sharper and more current.
- **Priya's own CV lines** → evidence cells quote her wording rather than the coach's summary, which is the version Dan will have read.
- **An inspectable artifact**: a redacted walkthrough of an SQL/Tableau analysis she built, or the structure of the partner revenue model → F3 and F4 could rise from medium to high confidence.
- **Priya's answers to the slots in F1, F2, F4 and F6, and in A1's counting slots** → those rows move from answer slots to story-mapped guidance, and D2 and D3 get firmer holds.
- **The rest of the interview schedule, if Dan isn't the only round** → per-round mini-packs with their own persona weights.
- **Prep time available** → a prioritised prep schedule at the top of the pack.
- **A tuesday-dossier.md** → an objection drawn from verified evidence instead of inferred, plus prohibited claims checked against her confirmed history.
