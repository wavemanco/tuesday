# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara · **Date of loop:** 5 December 2026 · **Mode:** loop (three rounds, one shared fit snapshot, a mini-pack per round)

| Round | Who | Length | What it holds (from the recruiter's email) |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, your future manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | "a 20-minute case on a complaint escalation"; "they score against the four values" |

Interviewer names have not been assigned yet, so there is no interviewer read; personas rest on the round types the recruiter named.

---

## How to use this pack

- **Personas** describe *how* a question arrives (friendly aside, quiet probe, live case). **Types** describe *what* is being scored.
- **Type key:** **VAL** — your past behaviour against Ashgrove's four published values. **EXP** — whether what you've said about your experience holds up under follow-ups. **JD** — can you do the listed job, gaps included. **CO** — Ashgrove's strategy and position. **CASE** — a live problem from the role, reasoned out loud.
- **Provenance labels:** `[grounded]` traces to something you or the recruiter supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about Ashgrove or you.
- **Answer slot** = a point where the honest answer depends on something only you know. Each slot has two branches; either branch, said plainly, is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in this pack: C1** (Round 2), the contact-centre objection. It will come up in some form, probably in more than one round.

---

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | The quote meets the stated four years. Words: "Six years in retail banking, the last three as a branch supervisor." No bridge needed. Expect it to be read quickly, not probed |
| F2 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's log, not a process across branches, and your words should stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which steps of a complaint were yours likely. If you took complaints on that log through from receipt to resolution, say which steps were yours and how, in your own words. If some steps sat with others, or the log was a record you kept rather than cases you resolved, say so plainly and stay with the log you handled |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap that wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | Your material says formal, not regulated, and the pack does not assume they are the same. Answer slot: if the complaints on that log were handled under regulatory rules, say which rules and what part of that handling was yours, in your own words. If they were not, or you don't know which rules applied, say so plainly and stay with the log you handled |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | "Monthly" and "complaints" match. Your material does not show whether it tracks volumes or resolution times, and it says your regional manager uses it, not that you report from it. Answer slot: if the spreadsheet counts volumes or resolution times, say which and how they are counted, in your own words. If it does not, say what it does track and stop there |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says spreadsheet, not which tool. Answer slot: if it is built in Excel, say so and what you used in it, in your own words. If it is in another tool, name that tool plainly |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material covers training new tellers on a script, not coaching supervisors. It says "our escalation script" and does not say who wrote it. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you trained likely. Say what the training involved and which parts were yours to shape, in your own words. If it was delivering the script as written, say so plainly and stay with that |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here either way. Answer slot: if you have worked with a digital or online team on any member- or customer-facing journey, say what it was and which part was yours. If you haven't, say so plainly, then say how you would start, as a plan |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated this gap, so the words are yours: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. Your material does not say whether you have presented at regional level. Answer slot: if you have, say to whom and on what. If you haven't, say so plainly |

**Reading the snapshot:** F1 is the only row with no gap. F3 and F9 are gaps you stated yourself. F4, F5, F6 and F8 depend on details only you can supply, so each has an answer slot. F2 and F7 are real work that is close to the requirement but narrower than it.

---

## Grounding brief: Ashgrove's current context

From the material you supplied. Learn the vocabulary so you sound current. Don't recite it.

| Fact | Source | Provenance | Where it shows up in this pack |
|---|---|---|---|
| Member-owned, about 900 staff | JD | [grounded] | A2, J3 |
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief (July 2026), as you summarised it | [grounded] | A7, E1, Round 2 reverse questions. This is the context for the JD's digital self-service line (F8) |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief | [grounded] | E2, I2, Round 3 reverse questions. `[inferred]` from the panel being two branch managers: the consolidation may affect their own branches, so treat it as a member-experience problem to handle well, never as a judgement on the decision |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief | [grounded] | Reverse questions. `[inferred]` a new product needs complaint categories and escalation routes from day one |
| Main competitive pressure: app-only banks | 2026 strategy brief | [grounded] | A7, E1. Ashgrove's own values ("every branch is part of its town") are its answer to say back to them, rather than a claim of your own about the market |
| Four values: Members First, Always · Plain Words · Neighbours, Not Numbers · Own the Fix | ashgrovecu.org/about/values, as you copied it on 26 November 2026 | [grounded] | Round 3 values cheat sheet, H1–H4, the case build |

You have a summary of the strategy brief, not its text, so quote the four headline points and not specific numbers beyond them.

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced it, so the panel will grade it. You don't know the scenario in advance. Below is a structure that works on any version of it.

**Facts about you that you can use (from the fit snapshot):**
- F2: "I handled the branch's formal complaints log"
- F7: "trained new tellers on our escalation script"
- F5: "I built the monthly complaints spreadsheet our regional manager uses."

Use them once, briefly, as context ("I handled the branch's formal complaints log, so…"). The case is scored on reasoning, not on your CV.

**A 20-minute shape** `[generic]`:

| Minutes | Step | What you say out loud |
|---|---|---|
| 0–3 | Clarify | What does the member want? Has a formal complaint been logged? Are there time limits that apply? Is the member in a vulnerable situation? What has the branch already tried? |
| 3–6 | The member's position now | What can be done today, from the member's side of the counter (Members First, Always) |
| 6–11 | Resolution and escalation decision | Who holds the case, what decides whether it escalates, and what you'd need from the supervisor |
| 11–15 | Root cause | Is this a one-off, or a pattern? What would you check? |
| 15–18 | Record and report | How it shows up in the monthly report, and what you'd watch next month |
| 18–20 | Close | The reply to the member in plain words, and one line on what changes so it doesn't recur |

**Three theses you can take, each with its mandatory concession:**

| Thesis | Concession you say before they do |
|---|---|
| Fix it for this member first, then fix the cause | Fixing the cause can take longer than the member will wait, so you tell the member plainly what is fixed now and what isn't yet |
| Escalation should be decided by clear criteria (repeat complaint, vulnerability, financial harm, any regulatory time limit), not by how loud the complaint is | No set of criteria covers every case. Supervisors still need room for judgement, and that is what coaching is for |
| Every escalation is data: log it so the monthly report can show the pattern | One complaint is not a trend. You wouldn't redesign the process because of a single case |

**How to stand out from the obvious answer:** the answer most candidates give is "listen, apologise, escalate, follow up." Go further in two ways. (1) Read "Own the Fix" literally `[inferred]` from the value's own words, "whoever finds the problem keeps hold of it until it is solved": the supervisor who found the problem may keep hold of it, with your support, rather than you taking it off them. Name that tension aloud and say how you'd decide. (2) End with what the branch can resolve itself next time, which connects the case to the JD's coaching line.

**What not to do:** don't overrule the branch in front of the member, and don't promise a refund or outcome before checking what policy allows. Panel members are branch managers, so an answer that sidelines the branch costs points on Neighbours, Not Numbers.

No requested close was named by the recruiter. If the case brief names one, use theirs.

---

# Round 1 — Recruiter screen (30 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through, motivation, logistics | High — the default for a recruiter round, and 30 minutes leaves room for little else | A pre-practised 90-second biography (A1). Treat every casual question as scored |
| Skeptic (light) | Quick checks against the four listed requirements | Medium — recruiters screen against the JD's requirements list, and F3 and F9 are gaps you've stated | Short, plain answers drawn from your own sentences. No defending at length here; save depth for Round 2 |
| Others | — | Low — nothing in the recruiter's email points to cases or deep probing in this round | — |

### A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, four beats, in this order: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Then one sentence on why this role, in your own words. Stop there and let them choose what to ask about | Every round opens with something like this. F1, F2, F5 and F7 are the material, and saying them in this order puts complaints first, where the JD starts; EXP because it is your own history |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Answer slot: give your actual reason, in your own words. If it connects to something Ashgrove has published (member-owned, the four values), name the specific value and why it matters to you. If your reason is the role itself (owning complaints end to end), say that plainly. Don't list all four values back at them | Motivation is checked in every recruiter screen. CO because they are listening for whether you know what Ashgrove is |
| A3 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your actual reason, in one or two sentences, in your own words. Point it towards what this role has rather than away from your current employer | A standard logistics question. The only safe answer is your own, so the pack supplies no reason |
| A4 | "What salary are you looking for?" | JD | [generic] | Either give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | A standard logistics question. Nothing here should come from the pack |
| A5 | "What's your notice period?" | JD | [generic] | Give your actual notice period | A standard logistics question |
| A6 | "The role spans branches and the contact centre. Where are you based, and how does that work for you?" | JD | [grounded] | Give your actual location and what travel between sites you can do, in your own words | The JD's "across branches and the contact centre" makes location a live question, especially with branches becoming hubs in 2027 |
| A7 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Two or three of the four headline points from the strategy brief, accurately: 40% of member service to digital channels by 2028; eight branches becoming five hubs over 2027; a small-business lending product in Q1 2027; app-only banks as the main competition. Then one sentence on what that means for complaints, framed as your thinking: e.g. members will complain through new channels, and the report needs to show it | Recruiters often test homework lightly. You were sent the brief, so not knowing it would stand out |

### B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log" | Say what you handled, in those words: the branch's formal complaints log. Answer slot: if those complaints were handled under regulatory rules, say which rules and what part was yours, in your own words. If they were not, or you don't know which rules applied, say so plainly and stay with the log | F4 is a stated requirement your material only partly reaches. JD because it scores the listed requirement directly |
| B2 | "Have you presented to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." | Your own words: "I've never presented to anyone above regional level." Then one sentence of plan: how you'd prepare for a senior audience. Don't add more. If they ask whether you've presented at regional level: if you have, say to whom and on what; if not, say so plainly | F9 is a stated gap the recruiter will screen on. A short, calm answer here keeps it from becoming the story of your application |
| B3 | "How comfortable are you with Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built and who uses it, in those words. Answer slot: if it's in Excel, say so and what you used in it. If it's in another tool, name the tool plainly | F6 is a listed requirement. The spreadsheet is your strongest single fact, so use it here |

### Reverse questions — Round 1

| Question | Why it lands |
|---|---|
| "How do the three rounds' scores come together? Does the panel's values score carry the same weight as the manager's round?" | Tells you where to put your prep effort, and signals you take the values round seriously |
| "Is there anything in my background you'd want me to address directly with the Head of Member Services?" | Brings the likely objection (C1) out early, so you walk into Round 2 knowing it |
| "Will I get the case material for the panel on the day, or beforehand?" | A practical prep question about the graded deliverable |
| "Is this a new role, or am I replacing someone?" | A new role means setting things up; a replacement means inheriting a process. That changes how you frame Rounds 2 and 3 |
| "What's the timeline after 5 December?" | Logistics. Recruiters expect it, and it's a natural close |

---

# Round 2 — Head of Member Services, your future manager (45 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions | High — the recruiter said "mostly behavioural" | Pick a specific complaint or occasion for each story. Use "we" for context and "I" for your part. Where your material has no story, say so rather than inventing one |
| Skeptic | Quiet probing of the gaps: contact centre, senior audiences | High — a hiring manager is taking the risk on you, and F3 and F9 are the obvious risks | Rehearse C1 until it's boring. Use only bridges you've stated yourself, plus a concrete plan for the first months |
| Case / Strategist | Live problems from the strategy brief | Medium — a hiring-manager prior, reduced because the recruiter said "mostly behavioural" | Clarify, then structure, then answer. Use Ashgrove's own words (members, hubs, digital channels) |
| Data-Driven Prober | Questions about the monthly spreadsheet | Low to medium — the JD's monthly reporting line and F5 invite it | Know what you can and can't say about how your spreadsheet counts things. Say plainly where you don't know |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never worked in a contact centre, and this role owns complaints there end to end. Why should I trust you with that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **Highest-ROI rehearsal in this pack.** Name the limit before they push: "I've never worked in a contact centre." Then what you do have, in your words: "I handled the branch's formal complaints log." Then a plan, said as a plan: in your first weeks, sit with contact-centre colleagues, read their complaints alongside the branches', and learn how escalations look from their side before changing anything. **Follow-up 1** ("But the volumes are completely different"): hold without claiming knowledge you don't have — "I don't know the contact centre's volumes yet; that's the first thing I'd look at." **Follow-up 2** ("Wouldn't a contact-centre specialist be safer?"): concede the specific point — someone from a contact centre would start out knowing how it works, and you wouldn't. Hold the core: what you'd bring is the complaints log and the escalation training you've described. Don't argue that branch experience is better | F3 is a stated gap against the JD's first line, and your future manager owns both channels, so this objection will arrive in some form. JD because it scores the headline responsibility; Skeptic because the test is honest self-assessment under pressure |
| C2 | "What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level." | Your own words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and on what, in your own words. If you haven't, say so plainly. Then the plan: how you'd prepare the first monthly report for a senior audience, e.g. one page, the main trend first, plain words. Hold: don't upgrade any past audience to "senior" | F9. This interviewer is likely to be in the audience for your reports, so they care about this more than anyone else in the loop |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Pick one of the two gaps you've stated yourself (the contact centre or senior presenting) and say it in your own words. Don't pick something your material is merely silent on (e.g. digital work) and present it as a weakness, because that adds a negative you haven't stated. Then the plan. 60 seconds | A Skeptic stem that's almost certain in a manager round. The honest, specific answer scores; a fake weakness doesn't |

### D — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint that escalated at your branch. What happened and what did you do?" | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint from the log you handled (anonymised, no member details) where you can say what the member wanted, what you did yourself, and how it ended. Your part, as "I". If no such case comes to mind where you acted yourself, say so plainly, then describe how the log worked and what you'd do differently | The JD's "own the member complaints process" and "escalations" make this very likely. EXP because it tests what was actually yours on the log (F2) |
| D2 | "Tell me about a time you helped someone handle escalations better." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7: you trained new tellers on your escalation script. Tell it in your own words. Answer slot: say what the training involved and which parts were yours to shape. If it was delivering the script as written, say so plainly and stay with that. Don't describe yourself as having written the script unless you did | The JD's coaching line; JD because it scores a listed responsibility. F7's gap (tellers rather than supervisors) is where the follow-up goes |
| D3 | "Tell me about a report you've produced that other people rely on." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5: you built it, it's monthly, it's about complaints, and your regional manager uses it. Answer slot: if you built it to solve a particular problem, say what it was; if not, say why you built it. If it tracks volumes or resolution times, say how. If it doesn't, say what it does track | The JD's monthly reporting line. Your strongest single fact; EXP because the follow-up will be about what's in it |
| D4 | "When did you put a customer ahead of a process or a target?" | VAL | [generic] | Selection scaffold: pick a time when following the process or target and doing right by the customer pulled in different directions. It needs a specific customer situation (anonymised), what the process said, what you did, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that matches "Members First, Always". Your manager may test values too, ahead of the panel |

### E — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital channels by 2028. What does that mean for complaints, and what would you do first?" | JD | [grounded] | Clarify first: which services, and what the complaints data shows about digital today. Then structure: (1) members who can't or won't move to digital; (2) making it easy to complain inside digital journeys; (3) splitting complaints by channel in the monthly report so digital teams see their share; (4) bringing that data to the digital teams. Risk: digital complaints may look lower only because they're harder to make. No claim about your past is needed. If asked whether you've done this, F8's answer slot applies | The JD's digital line, set against the strategy brief's 40% target. JD as the primary type because it scores the listed digital responsibility through a case |
| E2 | "Over 2027 we're consolidating eight branches into five hubs. How do you stop complaint handling slipping during that?" | CASE | [grounded] | Structure: before (expect complaints about the changes themselves, and agree who owns each branch's open complaints); during (no complaint lost when staff or branches move, with weekly tracking during the moves); after (compare hub complaint volumes and resolution times with the old branches). Keep it member-side: what the member in a closing branch experiences. Avoid any view on whether consolidation is right | Comes straight from the strategy brief; a manager will want to see you think at their level. CASE because it's a live problem |

### G — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through your monthly complaints spreadsheet. What does it measure, and how?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Premised on F5's own words. Say what it tracks and how each figure is counted, in your own words. If there's a figure you'd defend least, name it before they ask. Answer slot: if it includes resolution times, say how they're measured, e.g. when the clock starts and stops. If it doesn't, say so. "I'd need to check how that was counted" is an honest answer | F5 and F6 come together here. The JD names "volumes and resolution times", so expect them to ask about exactly those |
| G2 | "Complaint volumes went up 20% last month. How would you work out why?" | CASE | [generic] | Check the counting first: did the definition, channel or logging change? Then split it: by branch, channel, product and cause. Then timing: anything that changed that month, such as a branch move or an app change. Then the member impact. Then what you'd report and what you'd watch next month. Say the structure aloud before going through it | A persona stem matching the JD's monthly reporting line. It tests reasoning, not memory |

### Reverse questions — Round 2

| Question | Why it lands |
|---|---|
| "What does the monthly complaints report look like today, and what would you want it to tell you that it doesn't?" | This is your future manager's own reporting need. Asking it shows you'll build the report for them |
| "Do branch and contact-centre complaints come together in one process today, or two?" | Faces the gap from C1 directly and shows you've thought about how you'd learn it |
| "As members move to digital channels, are complaints starting to come through those channels yet?" | Ties to the 40% target and shows you've read the brief |
| "What would a good first 90 days look like to you?" | Gets their expectations on record and gives you something concrete to answer to |
| "How will the hub consolidation change where complaints get handled?" | Shows you see what the 2027 plan means for this role |

---

# Round 3 — Panel of two branch managers, including the 20-minute case (60 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value, scored | High — the recruiter said they "score against the four values" | One story per value, picked in advance (see the cheat sheet below). Use the value's name once, then let the story do the work |
| Case / Strategist | The 20-minute escalation case | High for that 20 minutes — announced by the recruiter | The case build above: clarify, the member's position, decide, root cause, record, close |
| Peer Evaluator | "What would you need from us", where supervisors fit in | Medium — `[inferred]`: branch managers are the people whose supervisors you'd coach, so they're pricing what you add to their branches | Frame what you'd bring their branches as well as what you'd need. Propose principles; don't pretend to know their branches |
| Pressure | Interruptions, devil's advocate | Low — nothing in the recruiter's email suggests it | Pause, restate, answer |

### Values cheat sheet

Value names and wording as you copied them from ashgrovecu.org/about/values on 26 November 2026.

| Value (official name) | What it means in practice | Your story |
|---|---|---|
| Members First, Always | Decisions are judged from the member's side of the counter | Selection scaffold (H1): a decision where the member's view and the branch's convenience pulled apart, and you took the member's side. Needs a specific situation (anonymised), the other view, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If something has to be explained twice, the explanation was at fault | F7: "trained new tellers on our escalation script" — the training is your nearest story (H2), with the answer slot there |
| Neighbours, Not Numbers | Each branch belongs to its town; members are people, not cases | Selection scaffold (H3): a time you treated a member as a person in their community rather than a case to close. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F5: "I built the monthly complaints spreadsheet our regional manager uses." — with the answer slot in H4 on whether it fixed a problem you found; otherwise a scaffold |

### H — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a time when the easy option for the branch and the right option for the member differed, and you chose the member's. Needs a specific situation (anonymised), what the easy option was, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, in its own words. VAL because the panel scores against this value by name |
| H2 | "Tell me about a time you had to explain something so it landed the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7: you trained new tellers on your escalation script. Answer slot: the value says "if a member needs it explained twice, we wrote it wrong", so expect a probe on whether you changed how you explained something. If you did, say what you changed and why, in your own words. If you didn't, say so plainly and describe how you trained | Plain Words. F7 is the nearest thing your material carries to it |
| H3 | "Tell me about a time you treated a member as a person rather than a number." | VAL | [grounded] | Selection scaffold: pick a member situation (anonymised) where you took account of who they were in the community, not just the case. It needs what you noticed, what you did differently because of it, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers. Branch managers will likely care about this value most, so it's probably scored hardest |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you built the spreadsheet because you found a problem, say what the problem was, what you did, and how you saw it through, in your own words. If you built it for another reason, say so plainly, and choose a different story: a problem you found yourself, kept hold of, and saw solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix, in its own words. F5 is your strongest artifact, but your material doesn't say why you built it, so the slot comes before the story |

### I — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | The 20-minute case. A likely shape: "A member has complained twice at a branch and is still unhappy. The supervisor escalates it to you. Take us through what you do." | CASE | [generic] | Use the 20-minute structure and the three theses in the graded-deliverable section. Ask your clarifying questions first, out loud. Use your facts once, as context: you handled the branch's formal complaints log. Close with the reply to the member in plain words | The recruiter announced it, so it's graded. The exact scenario is unknown, so this is a likely shape and not a prediction |
| I2 | "A long-standing member at a branch that's becoming part of a hub complains that the change ignores people like them. What do you do?" | CASE | [grounded] | Structure: hear the specific harm (distance, access, a familiar face); what can be done for this member now; what Ashgrove's own plan offers them; record it as consolidation feedback so the pattern is visible. Respect the decision and the member at the same time. Avoid any view on the consolidation itself | Combines the 2027 hub plan with Neighbours, Not Numbers. `[inferred]` the panel's own branches may be affected, so a careful answer matters |

### J — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would we get from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "trained new tellers on our escalation script" | Say what you have, in your words: three years as a branch supervisor, and you trained new tellers on your escalation script. Let them draw their own conclusions from that. Then reciprocity, as a proposal: what you'd give (clear escalation criteria, monthly feedback on their branch's complaints) and what you'd need (time with supervisors, and their view of what goes wrong). Don't claim you've coached supervisors before | The JD's coaching line, from the people whose staff you'd coach. F7's gap is where they'll push |
| J2 | "One of my supervisors disagrees with how you've told them to handle an escalation. What happens?" | CASE | [generic] | Listen to their reasons first; check both views against the process and the member's outcome; if it's still unresolved, take it to the branch manager rather than overruling them. Then record what you learned, because the disagreement may show a gap in the process. Show you'd stand firm on the member's outcome and be easy to work with on everything else | A where-do-our-jobs-meet question, typical of peer evaluators. CASE because it's a live scenario |
| J3 | "Most of your experience is in retail banking. What's different about a member-owned organisation, and how would it change how you handle complaints?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say your background as it is: six years in retail banking. Answer slot: if your employer wasn't member-owned, say so plainly and what you'd expect to change; if it was, say that. Then use Ashgrove's own words: member-owned, Members First, Always. Don't claim to know credit-union culture from the inside | A predictable question for a candidate whose experience is called "retail banking", asked collegially. CO because it tests whether you understand what Ashgrove is |

### Reverse questions — Round 3

| Question | Why it lands |
|---|---|
| "When a complaint escalates out of your branch today, what do you wish happened that doesn't?" | A reciprocity question. It gets their real pain points and makes them co-designers of your role |
| "What would make coaching on escalations actually useful to your supervisors, rather than one more thing on their plate?" | Shows you understand you'd be working in their branches |
| "How do you keep 'Neighbours, Not Numbers' strong as branches move into hubs?" | Uses their value and their strategy together. Ask it with genuine interest, not as a challenge |
| "Which of the four values do complaints test most, in your experience?" | Invites their stories and ties the panel's scoring frame to the role |
| "With small-business lending launching in Q1, how are branches getting ready for complaints from business members?" | Shows you've read the strategy brief and are already thinking about the complaints process for the new product |

---

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | C1, C3, D1, I1 |
| "report monthly on complaint volumes and resolution times" | D3, G1, G2 |
| "coach branch supervisors on escalations" | D2, J1, J2 |
| "work with digital teams on self-service journeys" | E1 |
| "4+ years in financial-services customer operations" | A1, through the biography; F1 has no gap, so no separate probe |
| "experience handling regulated complaints" | B1 |
| "confident presenting to senior leaders" | B2, C2 |
| "comfortable with Excel reporting" | B3, G1 |

---

## Prohibited claims

The claims this pack won't coach, and why. They hold in every round and in any drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a complaints process across several branches, end to end | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation of the limit: your material covers one branch's log, not a process across branches |
| Has worked in, or handled complaints for, a contact centre | Negative you stated, F3 | "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | "I've never presented to anyone above regional level." |
| Coached branch supervisors | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." The pack's observation: your material covers training tellers, not coaching supervisors |
| Wrote or designed the escalation script | Inflated form of F7 | F7's quote at its own scope. The pack's observation: your material says "our escalation script" and doesn't say who wrote it |
| Runs the region's complaints reporting | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: your material says your regional manager uses it, not that you report from it |

---

## Sources

**Provided documents:**
- The Member Experience Lead JD, pasted
- Ashgrove's four values, as you copied them from ashgrovecu.org/about/values on 26 November 2026
- The recruiter's email describing the three rounds on 5 December
- Your summary of Ashgrove's 2026 strategy brief (published July 2026, sent to you by the recruiter)
- Your background, as written in your message

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you copied this morning fix the cheat sheet and the H questions |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes the loop: three rounds, who runs each, the 20-minute case, and which round scores the values |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 strategy brief is under six months old and supplies the priorities and the competitive picture behind A7, E1, E2 and I2 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names have been assigned, so there was no query to form; there's no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned** → a read of each person's public professional background, persona weights per panel member, and at least one reverse question tied to each person's career
- **How much prep time you have before 5 December** → a prep schedule ranking what to rehearse first, keyed to question IDs
- **Your answers to the answer slots in F2, F4, F5, F6, F7 and F8** (which complaint steps were yours, whether the log was regulated, what the spreadsheet tracks and in what tool, what the training involved, any digital work) → those rows and B1, B3, D1–D3, E1, G1, H2, H4 and J1 become story-mapped answers instead of slots
- **A copy of the monthly complaints spreadsheet with all member data removed, if your employer's policies allow** → the inspectable artifact for complaints reporting; it would raise F5 and F6 from `medium` to `high` and let G1 be rehearsed on the real columns
- **Your CV** → a check of the fit snapshot against your written record, and possibly more stories for the values cheat sheet
- **The full text of the strategy brief** → a grounding brief in Ashgrove's own wording and numbers, and sharper E1 and E2 cases
- **Deeper research pass (L2)** — up to 6 more searches and 2 more fetches, several more minutes → recent Ashgrove news and context on the hub programme, and candidate reports on its interviews where any exist
- **A `tuesday-dossier.md`** → evidence grades checked against your inputs, and a list of claims to avoid that's built from a fuller review rather than inferred here; not needed for this pack
