# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Format:** one 60-minute interview, Friday
**Assumed relationship:** hiring manager. Your note says what Tobias's title is but not whether you would report to him, so the persona weights below assume he is your future manager.

---

## How to use this pack

Two separate things organise the pack:

- **Personas** describe *how* a question is asked: a quiet skeptic, a live case, a friendly opener.
- **Types** describe *what* the question is scoring:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether your experience holds up under questioning, and what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | How much you know about the company: its games, strategy and recent moves |
| CASE | How you structure and reason through a problem from the role, live |

Provenance labels: **[grounded]** means it traces to the JD or your own words. **[inferred]** means it is derived, and the derivation is named. **[generic]** means it is a role-family pattern with no claim about Saltmarsh or about you.

**The guidance is scaffolding, not a script.** Every sentence it gives you about your past is one you wrote in your message. Where your message doesn't cover something an interviewer is likely to ask, the guidance gives an **answer slot**: what to say if it was true for you, and what to say if it wasn't. Both branches are honest answers.

---

## Prep triage: one evening before Friday

1. **A1 out loud, three times.** This is the highest-ROI prep in the pack (about 25 min).
2. **A2's plain acknowledgment** about in-app purchases, said until it sounds calm, then the follow-up (10 min).
3. **D1**, your 90-second journey, timed (10 min).
4. **The structures for B1 and B2**, on one index card each (20 min).
5. **The slots in C1 and A4.** Know which retention measures you presented, who calculated them, and what platform your main title was on (10 min).
6. **Play both Saltmarsh titles** if you can identify them, and note one specific thing about their events (30 min).
7. **Pick three reverse questions**, including R3 (5 min).

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | This is your strongest line, and the words stay at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." The pack's own observation is that your material describes content drops for your main title. It doesn't describe live events, more than one title, or a mobile platform. Answer slot: the JD's "two of our mobile titles" makes a probe on those three likely. If your drops included events, if you planned across another title, or if the game was on mobile, say which, in your own words. If not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Running a calendar touches this requirement but doesn't show coordination across these four disciplines. Answer slot: if you worked with design, art, engineering or community to get drops out, say who and what your part was. If that sat with someone else, say so plainly and describe how you ran the calendar. If leadership comes up, your own words: "I haven't led a team." That sentence is about leading, not coordinating, so don't let it grow into a claim that you haven't worked across disciplines |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Presenting monthly numbers is near this requirement, but your material doesn't show a post-event review, or ownership of one. Answer slot: if you ran or took part in reviews after content drops, say what they covered and what your part was. If there were none, say so plainly and present your answer as how you would run one |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Lead with the quote's own terms: "I wrote the release checklist our QA team still uses." Writing it is not the same as managing it each release. Answer slot: if you worked through it with QA at releases, say how. If QA ran it without you, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Not a gate. Your four years as a producer are stated, but your material doesn't say how much of that was on a live-service game. Answer slot: if the main title was updated after launch for longer than the two years you ran its calendar, say for how long. If you don't know, or it wasn't, say plainly: four years as associate producer, the last two running the weekly content-drop calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. It's a single line in your message with nothing behind it to inspect, so expect a probe. Say it in the quote's terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap. Lead with "I presented the monthly retention numbers to the studio head." Answer slot: the JD's metrics line makes "which measures, and how were they counted" likely. Name the measures in your own words and say whether you calculated them. If someone else did, or you don't know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A checklist the team still uses is a written document that has lasted, and that's all the line says. Let the interviewer judge your writing from it, and from B5 if they ask you to draft something live |

---

## Persona table

The loop is one 60-minute session with Tobias, as your own message describes it. The weights rest on the assumption that he is the hiring manager. A hiring manager is buying capability and checking your gaps, so the Case/Strategist and the Skeptic come first.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet questions about the step from associate producer to producer, one title versus two, and in-app purchases | High. A hiring-manager prior, plus F1, F2 and your stated "Never led a team, and never worked on a game with in-app purchases" | Rehearse A1 until it's boring. Hold on what the quotes carry, say the limit before he does, then give a plan |
| Case/Strategist | Plan a calendar for two titles, diagnose an event that is underperforming, settle a scope fight | High. A hiring-manager prior, and the JD's first line is planning work | Clarify, then objective, structure, dependencies, metrics, risks. Think aloud |
| Data-Driven Prober | Which retention measures, who counted them, and how you would show that an event caused a lift | Medium. The JD names retention metrics and KPIs (F3, F7) | Know what you can and cannot say about your monthly numbers, and say plainly when you don't know |
| Conversational | A friendly opener, your journey, what you're playing | Medium. Almost every 60-minute interview opens this way, and it is still scored | A 90-second arc built only from your four sentences |
| Peer Evaluator | How you work with design, art, engineering and community | Low to medium. The JD's coordination line, asked collegially | Propose principles for how the teams hand off work. Don't claim to know Saltmarsh's teams |
| Pressure | Sixty-second challenges, "how much was actually you" | Low. Not a stated style, but it appears in some form in most rounds | Pause, anchor in what you stated, hold through two follow-ups |
| Values/Behavioral | Behavioural "tell me about a time" questions | Low. No values round is documented, and Saltmarsh's published values could not be researched | Only stories you can stand behind, otherwise the honest branch |

---

## Question banks

### A — Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs the events calendar for two titles and coordinates design, art, engineering and community on every update. You've been an associate producer on one main title. Why are you ready for this step?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team" | **The highest-ROI rehearsal in this pack.** Open with what you have: "For the last two years I ran the weekly content-drop calendar for our main title," after four years as an associate producer. Name the limit before he does: your calendar was for your main title, and your title was associate. Answer slot on coordination: if you worked with any of those four disciplines on drops, say who and what your part was. If not, say so plainly and stay with the calendar. Answer slot on more than one title: if you ever planned across another title, say so. If not, say it plainly. Then give a plan, said as a plan: how you would learn both titles' rhythms in your first weeks. Follow-up 1, "Have you ever been the one people answer to?": "I haven't led a team," then return to the calendar. Follow-up 2, "So why not hire someone who has?": hold. Don't add experience. Concede the gap specifically and repeat the plan | F1 and F2 are where the JD presses hardest against your material, so this objection will come in some form. JD type because it scores the stated scope of the role |
| A2 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment, said calmly and without apology: "I haven't worked on a game with in-app purchases." Then what you do have, at its own scope: "I presented the monthly retention numbers to the studio head." Then how you would learn it, said as a plan, for example by asking R3 or playing the titles' events as a paying player. Don't add anything that makes the gap sound smaller. If pushed on whether you understand event monetisation, say what you'd want to learn first, not what you know | The JD names retention, not revenue, so this isn't a stated requirement. It is a gap you named yourself, and the Skeptic's "I don't see X in your background" stem fits it exactly. EXP because it checks your history |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team" | Pick one real gap from the fit snapshot rather than a disguised strength. F3, the post-event review, or F1's second title are honest choices. If you choose team leadership, your words are "I haven't led a team." Give the gap in one sentence, then the plan in two | A standard Skeptic stem. Your gaps are visible in F1 to F3, and naming one cleanly is scored as self-awareness |
| A4 | "Your title was associate producer. How many of your four years were on live content, and how much of the calendar was actually yours to decide?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Facts first, in the quotes' terms: four years as associate producer, the last two running the weekly content-drop calendar. Answer slot: if the game was live for longer, say for how long. If you know what platform it was on, say so, especially if it was mobile. If you decided what went into each drop or when, say which decisions were yours and how you made them. If those calls were made above you, say so plainly and describe how you ran the calendar | Covers F5's "3+ years live-service" line and the associate title together. EXP because it tests attribution |
| A5 | "Why live ops, and why Saltmarsh?" | EXP | [generic] | Selection scaffold: your real reason, in your own words. It needs one thing about the work you want more of and one specific thing about Saltmarsh. Only use Saltmarsh specifics you have actually seen, for example in their games. If you haven't played them, play them tonight rather than inventing an impression | A motivation-consistency check that every Skeptic runs. [generic] because research on Saltmarsh couldn't run, so the pack holds no company facts to give you |

### B — Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch a 12-week live-events calendar across our two titles. What do you need to know first?" | CASE | [generic] | Clarify first: each title's audience and current cadence, which KPIs the events serve, shared versus dedicated art and engineering capacity, fixed dates such as holidays or platform features, and lead times per discipline. Then the objective. Then structure: big anchor events versus recurring smaller beats, staggered across the titles so shared teams aren't hit in the same week. Then dependencies and release-checklist gates working back from each launch, review points, and risks. Challenge one premise politely, for example whether both titles should run on the same cadence | The JD's first line made into a live problem, and the likeliest hiring-manager case. [generic] because it is a structure for the problem, not a fact about Saltmarsh |
| B2 | "An event goes live and day-one participation is well below plan. Walk me through the first 48 hours." | CASE | [generic] | First check the data is real: tracking, dashboards, time zones. Then check delivery: did the event reach players? Look at configuration, client version, store review, and whether the event is visible in game. Then segment: which title, region, new versus returning players. Separate what you fix now from what you leave for the review. Say who you tell and when, and log it all for the post-event review | Tests the "run" half of "plan and run" and the KPI reporting line. CASE delivery |
| B3 | "A week before launch, design wants to add a feature to the event. Engineering says it's too late. What do you do?" | CASE | [generic] | Get the facts: the player value, the risk, what QA would need. Lay out options: ship as planned, slip the date, or add it in a later patch. Say who makes the call and what the release checklist requires. Close the loop with both teams and community. Show that you protect the date and the relationships together | Tests the JD's coordination line as a decision. Hiring managers use scope fights to see how a producer handles disagreement |
| B4 | "How would you run a post-event review here: what's in it, who's in the room, what does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Frame this as a plan. Who: design, art, engineering, community, QA, analytics. What it reports: participation, completion, retention against a baseline, incidents and bugs, community sentiment, effort against plan, and two or three decisions for next time. If you mention your own reporting, keep to "I presented the monthly retention numbers to the studio head." Answer slot: if you ran or took part in reviews after drops, say what they covered and your part. If there were none, say so plainly and keep this as how you would do it | F3 is a stated responsibility with thin evidence, so rehearse a clear plan. JD type because "own the post-event review" is listed |
| B5 | "Mid-event, community flags a wave of complaints about a bug. Talk me through it, and say the two updates you'd write: one for the studio, one for players." | CASE | [generic] | First confirm and size the problem with QA and engineering. Decide on a hotfix, a config change or compensation, and who signs it off. Studio update: what happened, impact, action, owner, next update time. Player update: plain, acknowledges the problem, says what's happening and when they'll hear more, and promises nothing you can't control. Keep each to two or three sentences | Covers the JD's community line and "clear written communication" (F8) live. CASE with a writing component |

### C — Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers. Which measures were they, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: name the measures you presented, in your own words, and say whether you calculated them or someone else did. If you don't know how a figure was counted, say so plainly. That is an honest answer, not a failure. Name the assumption behind the numbers you'd defend least before he does, if you know one. Don't adopt industry measures you didn't present | F7 is grounded but has nothing to inspect, so a prober will go one level deeper. EXP because it tests what was yours |
| C2 | "Tell me about a time the retention numbers changed what went into the content calendar." | EXP | [grounded] "Presented the monthly retention numbers to the studio head"; "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if a time comes to mind, say what moved, what changed in the calendar, and which part of that was yours. If no such time comes to mind, or the two weren't connected, say so plainly, describe each on its own terms, then say how you would connect them here | The JD pairs KPIs with the event review, so a prober links F3, F6 and F7. An open prompt, so you pick the instance or decline it |
| C3 | "If players who joined an event show better day-7 retention, how would you know the event caused it?" | CASE | [generic] | Name the trap: engaged players join events, so the comparison is biased. Better comparisons: matched non-participants, a holdout group, the period before the event, and the same time in previous years. Say what you would ask analytics for, and what result would change your mind | Tests "comfortable with player-retention metrics" at depth. [generic] because it is a method, not a claim about you |

### D — Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built from those four sentences only: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for your main title, the release checklist QA still uses, and the monthly retention numbers you presented to the studio head. End with your own reason for wanting this role | The near-certain opener, and the one that sets every later question. Time it |
| D2 | "What live-service games are you playing at the moment? What do you make of their events?" | CO | [generic] | Only games you actually play. Give one specific observation about an event's design or timing and one thing you'd change. If you've played Saltmarsh's titles, lead with them | Casual in tone, but it scores genuine interest. CO because it tests homework |
| D3 | "What would your QA team say it's like working with you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | The fact you can stand on: "I wrote the release checklist our QA team still uses." Answer slot: say what they would actually say, in your own words. Don't put words in their mouths that you haven't heard | Ties to F4 and the JD's QA line in a friendly register |

### E — Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to get people from different disciplines to agree on a release date." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: it needs named disciplines, a real disagreement, what your part was, and how it ended. If no such time comes to mind, say so plainly, give the nearest thing your material does carry (running the weekly content-drop calendar), or say how you would handle it | The JD's coordination line (F2) as a peer would ask it. An open prompt, so the honest branch is always available |
| E2 | "What will you need from the community team on each update, and what will you give them?" | CASE | [generic] | Give and take. You need early warning on player sentiment, input on timing, and feedback after launch. You give a reliable calendar, early notice of content, clear incident updates and credit in reviews. Propose a simple shared rhythm rather than claiming to know Saltmarsh's | Tests whether a hire adds to or reduces the community team's load. CASE because it asks you to design the working relationship, not recount one |

### F — Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate who already knows our games?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Pause. Three facts in the quotes' own terms: the calendar, the checklist, the retention numbers. Then concede what is true: an internal candidate knows the games better. Then say what you'd do about that in your first month. Don't fill the silence | A time-boxed composure check. The concession earns credibility |
| F2 | "Writing a checklist isn't managing a release. How much of the release process was actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold on "I wrote the release checklist our QA team still uses." Answer slot: if you worked through it with QA at releases or signed releases off, say which. If QA ran it without you, say so plainly. Concede that the JD's "manage" is more than you've stated, without folding on what you did write | F4's limit asked with pressure. Hold through two follow-ups, then concede |

### G — Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time something you shipped went wrong after release. What did you do?" | EXP | [generic] | Selection scaffold: it needs what went wrong, what you did yourself, and what changed afterwards. If no such time comes to mind, say so plainly, then say how you would handle it here | The JD's release checklist and post-event review lines make this likely. EXP primary, VAL delivery |
| G2 | "Tell me about a time you had to deliver bad news to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if a month's retention numbers you presented to the studio head were bad news, say what you said and what happened next. If not, pick another instance or say plainly that none comes to mind, then say how you would deliver it | A standard values stem, and F7's presentation line is the obvious place for it to land |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles (F1) | A1, A4, B1, B2 |
| Coordinate design, art, engineering and community (F2) | A1, B3, B5, E1, E2 |
| Own the post-event review and its KPIs (F3) | B4, C2 |
| Manage the release checklist with QA (F4) | F2, D3, G1 |
| 3+ years producing live-service games or apps (F5) | A4 |
| Running a content calendar (F6) | A1, C2, D1 |
| Comfortable with player-retention metrics (F7) | C1, C2, C3, G2 |
| Clear written communication (F8) | B5 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first six months look like in this role, for each of the two titles?" | Shows you're already thinking in his terms, and tells you which title needs more attention |
| R2 | "Who reads the post-event review today, and what's a decision it has changed?" | Shows you see the review as a tool, not a report. His answer tells you how much of F3 you'd be building versus inheriting |
| R3 | "Which KPIs does the events calendar answer to: retention, revenue, or both?" | Raises the in-app purchase question from your side, as curiosity rather than defence, and tells you how big that gap is in practice |
| R4 | "Are design, art and engineering shared across the two titles or dedicated to each?" | Shows you're already thinking about scheduling conflicts, and gives you a concrete fact for any follow-up case |
| R5 | "How does the release checklist with QA work today, and what would you most want changed?" | Plays to F4 without boasting, and invites him to tell you the real problem |
| R6 | "What drew you to live operations, and what do you wish producers knew in their first month here?" | Turns a one-way interview into a conversation about his own path. Keep it to his professional path |
| R7 | "Who would I report to, and which teams would I work with most closely?" | Settles the relationship question this pack had to assume |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or an events calendar | Inflated form of F1 | F1's quote at its own scope: the weekly content-drop calendar for your main title. The pack's own observation: your material says content drops, not live events |
| Planned a calendar across multiple titles | Inflated form of F1 | F1's quote, "our main title", unchanged. A1's slot stays inside what you did |
| Owned post-event reviews or KPIs | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." The pack's observation: presented, not owned. B4's slot asks only what reviews there were |
| Calculated or analysed the retention numbers | Inflated form of F7 | "Presented the monthly retention numbers to the studio head." C1's slot lets you say who calculated them |
| Managed releases or ran QA | Inflated form of F4 | "Wrote the release checklist our QA team still uses." F2's slot stays inside the checklist |
| Has led a team | A negative you stated | "I haven't led a team." No slot |
| Has worked on in-app purchases or monetisation | A negative you stated | "I haven't worked on a game with in-app purchases." No slot |

---

## Sources

**Provided documents:** the JD text in your message, and your background in your message.

**Searches sent:**

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process producer`: refused
- `Saltmarsh Games mobile studio news 2026`: refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused

Web search permission was not granted in this session, so all four calls were refused and nothing in this pack comes from research. No page fetches were sent. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have themed VAL questions with Saltmarsh's published values. A values cheat sheet would also need a documented values round |
| 2. `Saltmarsh Games interview process producer` | unavailable | Would have confirmed whether more rounds follow. Your own message establishes Friday's single 60-minute session, so the weights stand |
| 3. `Saltmarsh Games` strategy and recent news | unavailable | Would have grounded a CO question and B1 in Saltmarsh's actual titles and recent moves. A5 and D2 stay generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have produced a section on reading the interviewer, adjusted persona weights, and tied R6 to his public career path |
| 5. Representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Whether Tobias is your future manager, a skip-level or a panel lead → persona weights recomputed, and a bank added or swapped if he isn't the hiring manager
- Web search allowed in this session → Saltmarsh's published values, its interview process and recent news, and Tobias's public career path, which together unlock a section on reading the interviewer, a CO question grounded in their games, and a reverse question tied to his path
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a strategy brief on Saltmarsh's titles and competitors for B1 and A5
- The recruiter's prep email, if any → coverage of any set task or stated focus areas for Friday
- The names of the two titles → B1, B2 and D2 rebuilt around the real games
- Your answers to the slots (whether the main title was on mobile, which disciplines you worked with on drops, whether drops had reviews, who calculated the retention numbers) → F1, F2, F3, F5 and F7 upgraded, with A1, A4, B4, C1 and C2 story-mapped instead of slotted
- A copy of the release checklist with confidential details removed, or a past retention deck → F4, F7 and F8 rise from medium toward high, with something concrete you could describe
- A `tuesday-dossier.md` → the highest-ROI objection taken from verified evidence instead of inferred, and a prohibited-claims list carried across sessions
