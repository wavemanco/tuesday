# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop. Three scheduled rounds share one fit snapshot, and each round gets its own mini-pack.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (your would-be manager) | 45 min | Hiring manager |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers and a cross-functional partner |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level, values-style round |

The loop comes from your own description of the rounds, so the persona weights rest on that schedule, not on an archetype. No interviewer names were given, so the pack has no interviewer read.

---

## How to use this pack

- **Personas** describe *how* a question is asked (the interviewer's style). **Types** describe *what* is being scored.
- **Type key:**
  - **VAL**: behavioural and values. Does your past behaviour show what they value?
  - **EXP**: experience deep-dive. Does what you said survive scrutiny, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, including the gaps?
  - **CO**: company and strategy. Can you think at the company's altitude?
  - **CASE**: live problem. Structure and reasoning on a problem from the role.
- **Provenance labels:** `[grounded]` means traceable to your own words or the role description. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern that claims nothing about Larkfield or about you.
- **Answer slot** marks a place where the interviewer will likely probe something your material doesn't show. Answer it from what actually happened, in your own words. Each slot has an honest branch: if the thing didn't happen, or wasn't yours, say so plainly.
- Guidance is scaffolding, not a script. Every answer should be speakable in 90 to 120 seconds.

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you gave. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material shows one team of six in payments. It doesn't show two squads, eleven people or device management, so the words stay at the quote's scope: "I've been a team lead of six for three years, at a payments company." If you're asked about managing managers, use your own stated negative: "I haven't managed managers." Answer slot: "two squads" makes a probe on running more than one team likely. If you have coordinated work across more than one team, say what and how, in your own words. If you haven't, say so plainly and stay with the team of six. How you would run two squads is a plan, said as a plan |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The reliability quarter shows you changed what the team worked on. It doesn't show how delivery was planned, tracked or recovered on your team. Answer slot: if you ran planning, tracking or slip recovery for your team of six, say how, in your own words. If that was someone else's job, or there was no such process, say so plainly and return to the reliability quarter |
| F3 | "hiring" (own hiring for 11 engineers) — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Keep the words at their own scope: "I run our hiring loop for backend roles. That was about 40 interviews last year." The number counts interviews, and "about" stays. Answer slot: owning hiring makes probes on role definition, hire decisions and closing candidates likely. If any of those were yours, say which and how. If none were, say so plainly and stay with running the loop |
| F4 | "growth for 11 engineers" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | Being team lead touches growth but doesn't show it. Answer slot: if you ran growth conversations, feedback or promotion cases for your six, say how, in your own words. If you didn't, say so plainly and say what you would do first |
| F5 | "partner with hardware … on roadmap" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | You stated this gap yourself, and wording can't close it. The words: "I haven't owned a hardware-adjacent roadmap." Then say how you would learn it, as a plan and never as a past. The requirement says *partner*, while your negative says *owned*. Don't widen your negative into a claim about all hardware contact, and don't add anything to make the gap feel smaller |
| F6 | "partner with … product on roadmap" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The words, at their own scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." The sentence doesn't say where the pressure came from, so don't name product unless it was product. Answer slot: if you worked with a product partner to make the case, say who and how. If the pressure came from elsewhere, or there was no partner, say so plainly and stay with the quarter |

**Requirement coverage**

| Requirement | Questions that cover it |
|---|---|
| F1: lead two squads, device-management services | A1, A2, P1, D4, B2, P3, H1 |
| F2: own delivery | B4, B1, B6 |
| F3: hiring | D3, G3, P1 |
| F4: growth for 11 engineers | E4, G4, G5 |
| F5: partner with hardware on roadmap | A3, B1, B5, B6, P3 |
| F6: partner with product on roadmap | B3, E2, B5, G2 |
| The 60% figure (defend the number) | D1, D2, P2 |
| The 40 interviews (defend the number) | D3 |

---

## Round 1: Tuesday, hiring manager (Director of Engineering, 45 min)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the jump from one team of six to two squads, and of the hardware gap | **High.** A hiring manager is de-risking the biggest gaps, and F1 and F5 are exactly those | Rehearse A1 until it's boring. Hold the line at what the F1 quote carries, state the limit before you're asked, then give a concrete plan |
| Case/Strategist | Live problems from the role: hardware collisions, fleet incidents, delivery health | **High.** This person will be your manager and wants to see how you'd run their roadmap | Clarify, then objective, options, trade-offs, communication and risks. Think aloud, and respectfully challenge one premise per case |
| Conversational | The opener ("walk me through…") and the first-90-days question | **Medium.** Most 45-minute manager rounds open warm. The casual questions are still scored | Have a 90-second arc built only from your quoted sentences |
| Pressure | One time-boxed "why you" | **Low.** It's not the dominant style for this relationship, but it's cheap to rehearse | Pause, then anchor in what you stated. Don't oversell |

### Question bank

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led one team of six. This role is two squads and eleven engineers. How would you run that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | **The highest-ROI prep in this pack.** Hold: "I've been a team lead of six for three years." State the limit before they find it: "I haven't managed managers." Answer slot: if you have coordinated work across more than one team, say what and how, in your own words. If you haven't, say so plainly. Then the plan, said as a plan: what you'd ask first (how the squads are split today, whether there are squad leads), what you'd keep, and what you'd change last. Follow-up 1, "So you'd be learning on us?": concede specifically that two squads is a bigger scope than you've had, and hold that leading a team is not new. Follow-up 2, "What breaks first at eleven?": answer from the plan, not from a past you didn't describe | F1 is the widest gap between the role and your material, so this objection arrives in some form in every round. JD because it scores the role's headline requirement. It's rehearsed deepest here because your would-be manager owns this risk |
| A2 | "Who would report to you, and have you had leads reporting to you before?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | "I haven't managed managers." Say it plainly, then turn it into a question for them: how are the two squads structured today? Then say how you'd approach growing or working through squad leads, as a plan. Don't soften the negative, and don't add a "but sort of" | A2 is the second follow-up level of A1, and F1's stated negative makes it a predictable probe. JD because it tests the role's structure |
| A3 | "How would you partner with our hardware team on the roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | "I haven't owned a hardware-adjacent roadmap." Then the plan, said as a plan: what you'd learn first (their release cadence and lead times, where the squads depend on them, where it hurts today), who you'd meet in week one, and how you'd make dependencies visible. Ask them what the current friction is | F5 is a capability gap you stated yourself, so expect it from the person who owns that partnership. JD because "partner with hardware" is in the role description |
| A4 | "Why leave payments for industrial IoT?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: give your actual reason, in your own words. Keep it forward-looking: what draws you to this role, not what's wrong with the current one. Don't claim an interest in devices or IoT you don't hold. If the honest reason is the role's scope rather than the domain, say that | F1 shows a payments background against a device-management role, so motivation consistency is a likely Skeptic probe. EXP because it tests your own story |

**Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A hardware launch date moves up, and the firmware team needs a device-management feature you'd planned for next quarter. Walk me through what you do." | CASE | [generic] | Clarify: what's fixed, what does a slip cost each side, and who decides. Objective: protect the launch without silently breaking squad commitments. Options: re-sequence, cut scope, borrow capacity, or say no with a reason. Name the trade-off you'd pick and how you'd communicate it to product, hardware and the squads. Challenge one premise, such as whether the full feature is needed for launch. This question needs no claim about your past | It's a live version of F5 and F2: the hardware dependency and delivery ownership. `[generic]` because it's a role-family pattern, not a fact about Larkfield's roadmap |
| B2 | "Suppose a rollout from one of your services to the device fleet starts failing on a slice of devices. What do you do in the first hour, and in the first week?" | CASE | [generic] | First hour: stop the bleeding (pause the rollout, size the blast radius, open an incident, name a lead, communicate). First week: root cause, what made it reach devices, and what changes in rollout practice. Say who you'd pull in from hardware. Structure beats domain fluency here, so don't fake device-specific terms | It tests device-management operations (F1) through incident leadership. `[generic]` because it isn't a claim about how Larkfield ships |
| B3 | "How do you decide when to spend a quarter on reliability instead of features?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F6: the reliability quarter, pushed through against roadmap pressure, with on-call burden dropping 60% after. Tell it in your own words, and keep "after" as your sentence has it. Answer slot: the role's "own delivery" line makes a probe on how you decided likely. If there was a signal you used, name it. If it was a judgement call, say so plainly. Then state the principle you'd bring, as a principle | F6 is your strongest story and a hiring manager will want the decision behind it. CASE delivery and EXP content: it scores your reasoning, anchored in what you did |
| B4 | "How did you run delivery on your team? Planning, tracking, what happens when something slips?" | JD | [inferred] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: if you ran planning, tracking or slip recovery for your team, say how, in your own words. If that sat with someone else, or there was no such process, say so plainly and return to the reliability quarter as what you did shape. Then say how you'd run delivery across two squads, as a plan | F2 is a discovery gap on a headline requirement, so the honest answer needs to be ready before the probe. The question's premise comes from the role description, and the guidance doesn't adopt it |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc with only these beats: nine years in engineering, three as team lead of six, at a payments company; you run the backend hiring loop, about 40 interviews last year; you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Close with why this role, using A4's honest answer | Every round opens with something like this, and it sets which threads they pull. EXP because it's your history, told at its own scope |
| C2 | "What would a great first 90 days look like for you here?" | JD | [generic] | Listen first (one-to-ones with all eleven, the hardware and product partners, on-call and delivery health), then name one early commitment and one thing you'd deliberately not change yet. It's a plan, so it makes no claim about your past | Hiring managers use this to test how you'd ramp, which matters more given F1 and F5. JD because it maps onto the role's responsibilities |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal staff engineer stepping up?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, then three beats from the quotes: three years leading a team of six, running a hiring loop of about 40 interviews last year, and a reliability quarter pushed through against roadmap pressure. Don't knock the hypothetical internal candidate. If they push back, hold on those three and concede that you'd be new to their domain | A persona stem that tests composure and a crisp case, drawing on F1, F3 and F6. JD because it compares you against the role |

### Reverse questions for Tuesday

| Question | Why it lands |
|---|---|
| "Six months in, what would make you say this hire worked?" | It gets your future manager's actual scorecard, which you can use in rounds 2 and 3 |
| "How are the two squads structured today? Are there leads, and who do they report to?" | It addresses the F1 gap head-on, as planning rather than worry |
| "When the device-management roadmap and the hardware roadmap conflict, who decides, and how does that go today?" | It shows you see the F5 seam and want to know how it works now |
| "What's the biggest delivery risk the squads carry right now?" | It's a manager-level question, and the answer gives you material for the Thursday panel |
| "How do you support a manager stepping into a bigger scope than they've had before?" | It names the gap honestly and asks how they invest in people, which builds trust |

---

## Round 2: The Thursday after, panel (two staff engineers and a PM, 60 min)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | The staff engineers take your figures apart: the 60%, and the 40 interviews | **High.** A technical-specialist prior plus a peer prior both put Prober near the top, and you have two figures | Know exactly how each figure was counted, or say plainly that you don't. Name your weakest assumption first |
| Peer Evaluator | All three ask what you'd need from them, how disagreements go, and how credit works | **High.** Staff engineers and a PM price what an EM adds to, or costs, their work | Use reciprocity framing. Propose seam principles rather than pretending to know their seams |
| Case/Strategist | The PM runs a roadmap and sequencing problem | **Medium.** "Partner with product on roadmap" is in the role, so the PM will likely test it live | Clarify, structure, trade-offs, then how you'd communicate |
| Pressure | "How much of that was actually you?" | **Medium.** Peer technical interviewers often test attribution directly | Hold through two follow-ups, then concede exactly what's real |

### Question bank

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through that 60% drop in on-call burden. How was it measured?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer each in your own words, from what you know. How was "on-call burden" counted? What is the 60% sensitive to (period compared, team changes)? Which assumption would you defend least? Name it before they do. Which part was yours? If you don't know how it was counted, say so plainly. That's an honest answer, and a better one than a method you can't repeat. Your sentence says the burden dropped "after" the quarter. Keep that link as stated, and if asked whether the quarter caused it, say what you actually know | It's your headline figure, and two staff engineers will test it to its assumptions. EXP because it scores whether F6's number survives scrutiny |
| D2 | "What did the reliability quarter actually contain, and which parts were yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Beats from the sentence: you pushed the quarter through, against roadmap pressure. Answer slot: say what work the quarter held and who did what, using "we" for the team and "I" for your part, in your own words. If the technical choices weren't yours, say so plainly. Pushing it through is your part, and it stands | It's an attribution probe on F6, the story every round will hear. EXP because it tests what was actually yours |
| D3 | "About 40 interviews last year. What does your loop assess, and do you know whether it predicts good hires?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Keep "about," and keep the number on interviews. Answer slot: say what the loop assesses and how you count the 40, in your own words. If you have evidence on how hires performed, say what it is. If you don't, say so plainly, then say what you would track here | F3's figure and its hiring requirement in one probe. EXP because it defends the number and the practice behind it |
| D4 | "How technical do you stay as a manager? Could you review a design for a device-fleet service?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Lead with what the quote carries: nine years in engineering. Answer slot: say where you still go deep technically, in your own words. Your material doesn't show device-fleet work. If you haven't done it, say so plainly and say how you'd review such a design: which questions you'd ask, and when you'd defer to staff engineers | Staff engineers test whether an EM can engage technically, and F1's domain gap makes the device angle likely. JD because it scores the role's "building device-management services" |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What would you need from staff engineers, and what would you leave to us?" | JD | [generic] | Reciprocity first: what you'd bring them (protected focus time, clear priorities, air cover on reliability work). Then what you'd ask for (technical direction, early warning on risk). Give principles, not a turf map you can't know yet. This makes no claim about your past | It's the core Peer Evaluator question for an EM hire. JD because leading squads that include staff engineers is in scope |
| E2 | "Say we disagree on a quarter's priorities: I want features, you want reliability work. How does that go?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Give principles first: shared data, explicit trade-offs, decide and commit. Then the story at its own scope: you pushed a reliability quarter through against roadmap pressure. Answer slot: if a product partner was part of that, say how the conversation went. If the pressure came from elsewhere, say so and don't cast it as product. Show spine and tact together | It's the PM's version of F6, testing whether you're a partner or an obstacle. CASE delivery with your story as anchor |
| E3 | "How do you handle credit when work spans product, hardware and your squads?" | VAL | [generic] | Give a principle and how you'd act on it: credit the people who did the work, by name, in the forums that matter to them. This makes no claim about your past. If you have a story, use one of your quoted sentences. Otherwise, keep it forward-looking | A persona stem the PM is likely to use, given the three-way partnership in the role. VAL because it tests behaviour with peers |
| E4 | "How would you grow a senior engineer toward staff?" | JD | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: if you've grown someone on your team of six toward a bigger scope, say how, in your own words. If you haven't, say so plainly. Then give the plan: scope with real ambiguity, sponsorship, and visible work. Staff engineers will notice if you borrow their vocabulary for a past you didn't have | F4 is a discovery gap and these interviewers are staff engineers, so it's a natural probe. JD because "growth" is in the role |

**Case/Strategist (PM)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "A customer wants remote configuration for devices in the field, and it depends on a firmware change. How would you size and sequence it with me?" | CASE | [generic] | Clarify: who's asking, what's the value, and what's the firmware lead time. Split it into what the squads can build independently and what waits on hardware. Give a rough sequence, the risks, and what you'd tell the customer and when. Ask the PM what they already know. It makes no claim about your past | It tests the PM partnership and the hardware dependency (F5, F6) live. `[generic]` because it's not a fact about Larkfield's customers |
| B6 | "How do you estimate and communicate delivery dates when hardware dates keep moving?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | If they ask about past hardware work: "I haven't owned a hardware-adjacent roadmap." Then the plan: give ranges rather than dates, name dependencies explicitly, set re-plan triggers, and communicate the same way to everyone. Don't present the plan as something you've done | It sits where F2 (delivery) meets F5 (the hardware gap), from the person who'll feel slips most. JD because it scores the stated partnership |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P2 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, then hold on what the sentence carries: you pushed the quarter through against roadmap pressure, and it was your team's on-call burden that dropped. Answer slot: if you did more than push it through, say what, in your own words. If the technical work was the team's, say so plainly. That's a concession, not a retreat. Hold through two follow-ups, and never claim the 60% as personally yours | It's the classic attribution probe on F6's figure, likely from a staff engineer. EXP because it scores honesty about contribution |

### Reverse questions for Thursday

| Question | Why it lands |
|---|---|
| "What could a new EM do in the first month that would genuinely help your work?" (to the staff engineers) | It's a reciprocity question that shows you're pricing your value to them, not just your needs |
| "Where does on-call hurt most today?" | It ties directly to your strongest story without bragging about it |
| "How do roadmap trade-offs between hardware, product and the squads get made now, and where does it break?" (to the PM) | It shows you see F5 and F6 as one seam, and you'll learn where the pain is |
| "What's one technical decision in device management you'd want the next EM to understand on day one?" (to the staff engineers) | It's a humble, specific learning question in the domain you're newer to |
| "What would make our partnership work, from your side?" (to the PM) | It invites the PM to define the relationship, which is a strong peer signal |

---

## Round 3: The following Monday, VP Engineering ("values and leadership philosophy," 30 min)

The recruiter's description makes this a values-style round. Larkfield's published values aren't in hand, so the pack has no values cheat sheet. The upgrade menu says what would add one.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time…" and "what's your philosophy…" | **High.** The recruiter named the round's focus as "values and leadership philosophy" | Map each answer to one of your quoted sentences, or pick honestly. Use "we" for context and "I" for your part |
| Pressure | Time-boxed challenges on the two stated gaps | **Medium.** The skip-level prior favours composure tests, and 30 minutes means short answers | Hold, then concede the specific gap without folding |
| Case/Strategist (strategy-heavy) | Altitude: why this work matters to the business | **Medium-low.** It's the skip-level prior, but this round is values-focused | Reason aloud from the role. Don't assert company facts you haven't read |
| Conversational | The closing "where do you want to be" | **Low.** | Answer honestly, in your own words, in under a minute |

### Question bank

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What's your leadership philosophy?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name two or three beliefs, in your own words, and anchor each in one sentence above. For example, you might anchor something about team health in the reliability quarter, and something about who you bring in in the hiring loop. If a belief you hold has no story here, say it as a belief, not as a record. Keep it under 90 seconds, because a VP will dig into one belief | The recruiter named this round's theme. VAL because it scores what you value, shown through what you did |
| G2 | "Tell me about a time you held a position against pressure from above." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The reliability quarter fits only if the roadmap pressure came from above you. If it did: you pushed the quarter through against that pressure, and on-call burden dropped 60% after. Answer slot: the role's "partner with product on roadmap" line makes a probe on how you made the case likely. If you made it, say to whom and how, in your own words. If the pressure came from elsewhere, say where, or pick another time. If none comes to mind, say so plainly and say how you'd handle it | It's a persona stem, and F6 is your one quoted story of holding a position. VAL because it tests leadership behaviour under pressure |
| G3 | "Tell me about a time you got a hiring decision wrong, or nearly did." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Selection scaffold: pick a real case from running the loop. It needs what you thought, what you missed or caught, and what you changed. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would guard against it. Don't invent a mis-hire to sound reflective | "Hiring" is in the role and F3 is your evidence, so the values angle on it is likely. VAL because it tests judgement and humility |
| G4 | "How do you give hard feedback to someone on your team?" | VAL | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold: pick a time with your team of six when you gave feedback someone didn't want. It needs what you said, how they took it, and where the relationship ended up. If no such time comes to mind, say so plainly, then give how you would do it | F4 is a discovery gap and a VP probes growth through feedback. VAL because it tests behaviour, not process |
| G5 | "What would your team say is the hardest thing about working for you?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: give a real answer, in your own words, with what you're doing about it. If you've had direct feedback from your six, use it. If you haven't, say that's what you'd guess and why. Avoid a disguised strength | It tests self-awareness, a common values-round probe for managers. VAL because it scores candour |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P3 | "Thirty seconds. You've never managed managers or owned a hardware roadmap. Why should I take the bet?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Concede first, briefly, in your own words: "That's right. I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then hold on two things the quotes carry: three years leading a team of six, and a reliability quarter you pushed through against roadmap pressure. End with one line of your ramp plan. If they push again, don't add claims. Repeat the hold more briefly | It's the VP version of A1, the highest-ROI objection, time-boxed. JD because it scores the role's two named gaps |

**Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where do device-management services matter most to an industrial IoT business like ours?" | CO | [generic] | Reason aloud from the role description: devices in the field, fleets that need managing, and the cost when that fails. Then turn it to them: ask where they see it. Don't state Larkfield facts you haven't read | The skip-level prior expects altitude. `[generic]` because no Larkfield strategy research landed, which is the honest cost noted in Sources |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Where do you want to be in three years?" | EXP | [generic] | Answer slot: your actual aim, in your own words, tied to this role's scope. If you don't know yet, say what you want to have learned | It's a common VP closer that tests whether the role fits your direction. `[generic]` because it draws on no claim about your past |

### Reverse questions for Monday

| Question | Why it lands |
|---|---|
| "What separates the managers who thrive here from the ones who struggle?" | It's a values question turned back on them, and the answer tells you what the culture rewards |
| "How do you want your engineering managers to disagree with you?" | It signals spine, and it fits a leadership-philosophy round |
| "What are you hoping this hire changes for the two squads?" | It gets the VP's intent for the role in one line |
| "What's a leadership value you hold that's hardest to live out at this company's size?" | It invites the VP's own philosophy, which matches the round's theme |
| "What would make you confident, a year from now, that you'd made the right call?" | A direct close that invites any remaining doubt into the open while you can still address it |

---

## Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers, or had leads reporting to them | Negative the candidate stated, F1 | "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | "I haven't owned a hardware-adjacent roadmap." No slot. A plan for learning it, said as a plan |
| Led two teams, or a group larger than six | Inflated form of F1 | F1's quote at its own scope: team lead of six for three years. The pack's observation: the material says one team of six, not two squads. A1's slot stays inside work across teams |
| Owned hiring decisions or headcount | Inflated form of F3 | F3's quote at its own scope: runs the backend hiring loop, about 40 interviews last year. The slot asks only which parts were the candidate's |
| Personally cut on-call by 60%, or the quarter caused the 60% drop | Inflated form of F6 | F6's quote at its own scope: the team's on-call burden dropped 60% after the quarter was pushed through. The figure stays on on-call burden, it's the team's, and the link is "after" |
| Product pushed back on the reliability quarter | Inflated form of F6 | F6's quote says "roadmap pressure" and names no source. The slot asks where it came from |

---

## Sources

**Provided material:** your message. That covers the role description (quoted), the three-round schedule, and your background.

**Searches sent:**

- `Larkfield Systems values`: refused (web search permission wasn't granted)
- `Larkfield Systems interview process engineering manager`: refused
- `Larkfield Systems industrial IoT news`: refused

No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The call was refused. It would have supplied the official value names for a Monday values cheat sheet and themed G1 to G5 around them |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The call was refused. Your description already establishes the three rounds. This would have added formats, such as whether the panel includes a case |
| 3. `Larkfield Systems` strategy / recent news | unavailable | The call was refused. It would have grounded H1 and the CASE questions in current Larkfield priorities instead of `[generic]` patterns |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form. The pack has no interviewer read |
| 5. Representative Engineering Manager JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → more requirements become fit-snapshot rows and JD questions, likely including any mid-list items the summary leaves out
- **Your CV** → more quotable sentences, so more answers become story-mapped instead of answer slots
- **Larkfield's published values page** (pasted, or fetched once search is allowed) → a Monday values cheat sheet, with each value mapped to one of your stories, and G1 to G5 themed to their own words
- **Web search allowed** → targets 1 to 3 rerun: official values, documented loop format, and current strategy for the CO and CASE questions
- **Deeper research pass** → a strategy brief, recent org context and role-family loop reports. Cost: up to 6 more searches and 2 more fetches, several more minutes
- **Interviewer names** (Director, staff engineers, PM, VP) → an interviewer read, persona weights tuned per person, and at least one reverse question tied to each person's own path
- **Recruiter guidance for the Thursday panel** (format, any case or design exercise) → coverage of any pre-declared deliverable
- **Your answers to the F2, F4 and F6 slots** (how you ran delivery, growth on your team, and where the roadmap pressure came from) → those rows move from slots to story-mapped guidance in B3, B4, E2, E4, G2 and G4
- **Prep time available** → a prioritized triage schedule across the three rounds
- **A `tuesday-dossier.md`** → evidence-derived objections and a verified prohibited-claims list. It would sharpen the pack, and the pack is complete without it
