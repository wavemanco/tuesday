# Stripe — Product Operations Manager — final-round prep pack

Final round. Interviewers and their relationship to the role are not known yet. No JD, CV or recruiter notes were provided, and web research was refused in this session, so this pack is built from general product-operations patterns. Every row is labeled `[generic]` because of that.

## How to use this pack

- **Personas** describe *how* a question is asked (the interviewer's style). **Types** describe *what is being scored*.
- Type key:
  - **VAL**: behavioral or values alignment. Does your past behavior show the company's published values?
  - **EXP**: work-experience deep-dive. Does what you say about your past hold up under scrutiny, and how much of it was yours?
  - **JD**: role-driven. Can you do the listed job, including the parts where you're weaker?
  - **CO**: company and strategy knowledge. How deep did your homework go?
  - **CASE**: a live problem from the role, answered in real time.
- Provenance labels: `[grounded]` means traceable to something you gave me or to research cited in Sources. `[inferred]` means derived from a representative source. `[generic]` means a general pattern for the role family, with no claim about Stripe or about you. This pack is all `[generic]` for now.
- The guidance is scaffolding, not a script. I don't have your CV, so nothing here says what you did. Each past-experience question gets **selection criteria** for picking your own story, plus an honest fallback for when no story fits.
- Question IDs run A, B, C, D, E, G, H by persona. F is skipped so it can't be confused with the fit-snapshot rows F1 to F7.

## Fit snapshot (self-assessment worksheet)

No JD and no CV were provided, so this is the worksheet version. The requirements below are common product-operations requirements, written in plain prose and not quoted from any posting. Fill in the evidence column yourself before the interview. Any row where you can't write a real sentence is where to rehearse an honest answer.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating product launches across engineering, support, sales, legal and other teams. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence here is a specific launch where you can say which readiness pieces were yours and how you knew the launch was ready. Pick a launch where your own part is clear and you can say what would have broken without it. If no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Turning customer, support and sales feedback into input the product team acts on. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence is a feedback channel you can describe end to end: where input came from, how it reached product, and one thing that changed because of it. Pick an example where the change is traceable. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Defining and tracking operational metrics, often with SQL or dashboards. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence is a number from your own work that you can defend: how it was counted, what it is sensitive to, and which part was yours. Pick the figure you understand best, not the biggest one. If you don't know how a figure was counted, saying so is an honest answer |
| F4 | Designing repeatable processes and tooling that scale. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence is a process you can describe as it was before and after, with your part in the change named. Pick one where you can say who used it afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influencing teams you don't manage. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team that you can tell from both sides, with the relationship still intact at the end. Pick one where you can say what you conceded. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritizing under ambiguity when many requests compete. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence is a moment where you chose what not to do and can explain the trade-off. Pick one where the cost of saying no was real. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Clear written and spoken explanation of operational problems to senior audiences. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence is a document or update you wrote that changed a decision. Pick one you could summarize in two sentences. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

None of what you've shared says how many sessions the final has or who runs them, so the loop isn't established. I've used the **generic archetype** (screen, then hiring manager, then panel) with **flat weights**. Those weights rest on a pattern, not on Stripe's documented process. Every persona gets 3 questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: why product ops, why here, why now, and where you're weakest | Flat. Final rounds commonly include someone whose job is to derisk the hire, but that's a pattern, not a fact about this loop | Rehearse A1 until it feels boring. Bridge only from adjacent work you can actually describe. Where you have none, say the limit plainly and give a ramp plan |
| Case / Strategist | Live operational problems: diagnose this spike, plan this launch | Flat. Case-style questions are typical for operations roles. Without a JD, the cases here are generic | Clarify, then objective, segmentation, approach, metrics and risks. Think aloud. Challenge one premise per case, respectfully |
| Data-Driven Prober | Asks for denominators, how a figure was counted, and its assumptions | Flat. Product ops sits close to metrics, so expect at least one number to be probed | Know what you can and can't say about how each of your numbers was counted. Name the weakest assumption before they do |
| Peer Evaluator | Where the seam sits between teams, how you disagree with equals, credit-sharing | Flat. Product ops works between product, engineering and go-to-market teams, so peers are plausible interviewers | Frame it as reciprocity: what you'd bring them, not only what you'd need. Propose principles for the seam rather than pretending to know it |
| Values / Behavioral | STAR-shaped stories mapped to values | Flat. Stripe's published principles aren't in hand, so these questions use general themes | Use "we" for context and "I" for your own contribution. Pick stories where a hard truth actually landed. If your material shows none, say so |
| Pressure | Time-boxed questions, devil's advocate, "how much of that was you" | Flat. It could come from any interviewer in a final | Pause, restate the question, anchor in what you actually did, and hold through two follow-ups before conceding anything real |
| Conversational | Friendly openers that are still being scored | Flat. Nearly every session opens with one | Have a 90-second arc for your journey ready. Treat casual questions about the role as scored |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **The highest-ROI rehearsal in this pack.** Pick one requirement from F1 to F7 where your evidence column is thinnest, and name it plainly. Don't pick a disguised strength. Then give a 30-to-60-day plan to close it, said as a plan and never as something you've done. Hold through two follow-ups by going back to the plan. If they press on whether the gap is disqualifying, concede exactly what you don't know yet and keep the plan | Almost every final asks it in some form, and a rehearsed, non-defensive answer changes the interview. The objection is inferred here, not drawn from your material, so it may move once your CV is in. JD because it scores the role's requirements against you |
| A2 | "If I don't see a product operations title in your background, how would you handle this role?" | JD | [generic] | Don't argue about the title. Pick the one piece of your work that is closest to F1 or F2 and describe what you did, in your own words, at its real size. Let the interviewer draw the connection. If nothing in your work comes close, say so plainly, then say how you would ramp | The background-mismatch probe is the Skeptic's main tool. It's asked conditionally because I don't know your background. JD because it tests fit against the role |
| A3 | "Why product operations, and why now?" | EXP | [generic] | Two parts. Why this kind of work: something specific you've found you like doing, in your own words. Why now: the honest reason for this move. Keep it consistent with whatever you say in H1. Don't invent a narrative arc your history doesn't have | The "why leave, why here, why now" check for consistency. EXP because the answer rests on your own history |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A feature launched to business customers two weeks ago, and support contacts about it have tripled. Diagnose it. What do you need to know first?" | CASE | [generic] | Clarify first: tripled from what base, and which customers. Segment: new versus existing users, one flow or many, one region or all. Find out whether contacts are confusion, bugs or a policy question. Choose an immediate action and a durable fix. Decide which metric tells you it's resolved. Name the risk of over-reacting to a small base. The question needs no claim about your past, so the guidance makes none | Tests F1, F4 and F6 as a live problem. CASE because structure is what's scored |
| B2 | "Sketch the plan for launching an existing product to customers in a new country. What do you need to know first?" | CASE | [generic] | Clarify: which product, which customers, and what "launched" means. Objective and success metric. Readiness workstreams: legal and compliance, support coverage and language, pricing and billing, sales enablement, documentation. Who owns each and how you'd track it. The go/no-go criteria. One risk you'd escalate early | F1 as a live plan. Regulated or financial products usually carry compliance workstreams, which is a pattern, not a claim about Stripe. CASE delivery |
| B3 | "Product teams say they never hear from customers. Support says they file feedback and nothing happens. Design the feedback loop." | CASE | [generic] | Diagnose before designing: where does feedback die? Then intake, deduplication and tagging, a prioritization rule product agrees to, closing the loop back to support, and one metric that shows the loop works. Name the trade-off between volume and signal | F2 and F4 as a design problem. CASE because it scores how you build a process |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a number from your own work that you'd want us to remember. Walk me through how it was counted." | EXP | [generic] | Pick the figure you understand best, not the biggest one. Then cover, in your own words: how it was counted, what it is sensitive to, and which part of it was yours. If you don't know how it was counted, say so plainly. That's an honest answer and better than a method you can't repeat | F3 is probed in almost every ops loop. EXP because it tests whether your numbers hold up |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it yourself before they do: the assumption you'd defend least, in your own words. Say what would change if it were wrong. If you don't know the assumptions, say so plainly and say what you'd check | The weakest-assumption move turns a gotcha into credibility. Same EXP logic as C1 |
| C3 | "If you owned operational health for a product, which three metrics would you watch every week, and what would make you distrust each one?" | CASE | [generic] | Choose three metrics that cover outcome, quality and load (for example, a success rate, an error or contact rate, and a time-to-resolve). For each, name one way it could mislead you. The question is hypothetical, so the guidance makes no claim about your past | F3 as a live design problem. JD content with CASE delivery |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam between product ops and product management, and what happens when we disagree?" | JD | [generic] | Don't pretend to know their seam. Propose a principle, for example: PM owns what and why, product ops owns how it lands and whether it's working. Then say how you'd surface a disagreement: with data, early, and in the open. Ask them where the seam sits today | F5 as a peer question. JD because it tests the role's boundaries |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a time when work spanned teams and you can say exactly which part was yours. Use "we" for the whole and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers price whether you'll share credit. EXP because it rests on your history |
| D3 | "What would you need from a partner team in your first month, and what would you bring them?" | JD | [generic] | Answer the reciprocity half first: what you'd bring, such as visibility into customer pain, cleaner launch checklists, or fewer surprise escalations, framed as offers. Then one or two things you'd need. Keep it short | Peers weight whether a hire reduces their load. JD because it maps to F5 |

### E. Values / Behavioral

Stripe's published principles weren't retrieved, so these questions use general themes. Once research runs, each published principle gets its own question with a mapped story.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, where you didn't soften the message into nothing and the relationship survived. Say what you said, how it landed, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ops roles often carry bad news upward. VAL because it scores behavior, not skill |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time where the trade-off was real and you can name both the metric and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-versus-metric is a standard values probe and ties to F2. VAL |
| E3 | "Leadership has fixed a launch date. A week out, you see a readiness risk. What do you do?" | CASE | [generic] | Size the risk first: who it hits and how badly. Bring options, not just the problem: ship as planned, ship with mitigations, ship to a smaller group, or slip. Recommend one. Say how you'd escalate without going around anyone. It's hypothetical, so no claim about your past | F1 and F7 under pressure from above. VAL content with CASE delivery |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give one honest edge an outsider has (a fresh view, or experience from a different setting) and one concrete thing you'd do early. Don't run down the hypothetical internal candidate. Stay within 60 seconds | Composure under a time limit. JD because it asks you to make your case against the role |
| G2 | "That result you just described: how much of it was actually you?" | EXP | [generic] | Hold, then concede. Restate your own part precisely, in the same words you used before. If they push twice, concede exactly what was other people's and keep what was yours. Don't fold everything to keep things pleasant, and don't grow your part either | Attribution probes exist to catch inflation, and the preparation is candor. EXP |
| G3 | "Why Stripe, and not another company?" | CO | [generic] | Build this from your own reading of Stripe's public material before the interview. Use only facts you can point to a source for, and one honest reason it matters to you. This pack has no researched Stripe facts to give you. Don't recite anything you can't source | Motivation under pressure. CO because it tests homework. It stays generic until research runs |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three moves with the reason for each, and why this role is the natural next one. Every beat should be something you can expand on if asked. End on why product ops, consistent with A3 | Every session opens with something like it, and it's scored for economy. EXP |
| H2 | "What are you actually playing with these days that's relevant to this role?" | JD | [generic] | One real thing you've been learning or using, such as a tool, an analysis method or something you've read, and why it interests you. If it's early, say it's early | The casual register hides a scored question about curiosity. JD because it checks fit to the role |
| H3 | "How would you explain what product operations does to someone outside the company?" | JD | [generic] | Two or three sentences, in plain words. Then one example of what it looks like done well. It isn't about your past, so no claim needed | F7, tested casually. JD because it shows whether you understand the role |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch coordination | B2, E3, A2 |
| F2 Feedback loops | B3, E2, A2 |
| F3 Metrics | C1, C2, C3 |
| F4 Process and tooling | B1, B3 |
| F5 Influence without authority | D1, D2, D3 |
| F6 Prioritization under ambiguity | B1, A1 |
| F7 Written and spoken explanation | E3, H3 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What would make someone in this role clearly successful at six months?" | It gets their real scorecard, which no posting carries, and shows you're thinking about outcomes |
| "Where does product ops sit relative to product and engineering here, and where does that seam create friction today?" | It shows you know the role lives on seams, and the answer tells you what you'd really be doing |
| "What's an operational problem the team has been meaning to fix but hasn't had someone to own?" | It invites them to picture you in the job, and gives you something concrete for any follow-up note |
| "How does the team decide which product feedback gets acted on?" | It ties to the feedback-loop work at the center of most product ops roles, and the answer shows how mature the process is |
| "What did the last person to grow out of this role go on to do?" | It shows you're thinking long-term, and tells you whether the role has a path |
| "What would you need from a new person in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer. It signals you want to reduce their load |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed yet | No sentences about your past are in hand, so there is no wording of yours that could be stretched | Every past-experience cell is a selection scaffold with an honest fallback. This list fills in as soon as your CV or your own descriptions arrive |

## Sources

- Provided: your message ("final-round interview at Stripe for a Product Operations Manager role").
- Searches sent, all refused by this session's permissions:
  - `Stripe operating principles`: refused
  - `Stripe interview process final round product operations`: refused
  - `Stripe strategy news 2026`: refused
  - `Stripe "Product Operations Manager" job posting`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values or operating principles | unavailable | Would have added a values cheat sheet, plus VAL questions named for each published principle and mapped to stories |
| 2. Stripe interview process for product operations | unavailable | Would have set persona weights from documented rounds instead of the generic archetype |
| 3. Stripe strategy and recent news | unavailable | Would have grounded G3 and added CO and CASE questions on current priorities |
| 4. Interviewer name at Stripe | n/a | No name was given, so there was nothing to search |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the seven `[generic]` fit rows into quoted `[inferred]` requirements |

## Upgrade menu

- Allow web search → Stripe's published principles by name (a values cheat sheet and a VAL bank mapped to them), the documented loop structure, and CO and CASE questions on current strategy. Targets 1, 2, 3 and 5 would then run
- The JD text → F1 to F7 become `[grounded]` requirements quoted from the posting, the JD-tagged questions follow the real list, and any gate (location, work authorization) shows up as its own row
- Your CV, or a paragraph on your background → the worksheet becomes a real fit snapshot, scaffolds become story maps, the highest-ROI objection is drawn from your actual gaps, and the prohibited list fills in
- Who's in the final round and how they relate to the role → persona weights move off flat, and the deepest banks go where they belong
- The recruiter's prep email → a build section for any declared deliverable (case, presentation, written exercise). If the final is several sessions, the schedule → a mini-pack per session
- Interviewer names → a section reading each interviewer from their public professional footprint, plus a reverse question tied to their own path
- How much prep time you have → a prioritized prep schedule sized to it
- A deeper research pass, with up to 6 more searches and 2 more fetches and several more minutes → a grounding brief on current Stripe vocabulary and strategy
- A tuesday-dossier.md → an evidence-derived top objection and a prohibited-claims guardrail carried in from earlier work
