# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack assumes he is the hiring manager for this role. You didn't say, and the answer changes the persona weights.
**Format:** one 60-minute session, Friday.

---

## How to use this pack

Two things organise every question:

- **Personas** describe *how* a question arrives: who is asking and in what style.
- **Types** describe *what is being scored*:
  - **VAL**: behavioural or values alignment
  - **EXP**: deep-dive on your work experience. Do your claims hold up, and what was actually yours?
  - **JD**: a stated responsibility or requirement from the job description
  - **CO**: knowledge of the company and its games
  - **CASE**: a live problem from the role, worked through out loud

Fit rows are numbered F1 to F9. Question IDs use letters by persona: A, B, C, D, E, G and H. F is skipped so a question ID never looks like a fit-row ID.

**Provenance labels:**
- `[grounded]`: rests on your own sentences, quoted.
- `[inferred]`: the pack's own reading of the fit.
- `[generic]`: a role-family pattern with no claim about you or Saltmarsh.

The guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.

---

## Prep triage

This assumes you have about one evening before Friday. If you have more, the order stays the same.

1. **B1, three times out loud.** It is the highest-ROI prep in this pack (see the Skeptic bank). Get the concession wording smooth, then rehearse the two follow-ups.
2. **B2, the in-app-purchase question.** Practise the one-sentence acknowledgment until it sounds calm, then the plan.
3. **D1, a 90-second arc.** Time it.
4. **A3 and A5, post-event review and KPIs.** F3 is your thinnest row, so arrive with a structure ready.
5. **Play Saltmarsh's two titles, if you can find out which ones they are (D2).** Note one live event you saw in each.
6. **Pick two or three reverse questions.**

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material covers one weekly content-drop calendar, for your main title. It doesn't cover live events across two titles, so the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Don't relabel the drops as "live events". Describe them and let Tobias draw the comparison. Answer slot: the JD's two-title line makes a probe on running more than one game likely. If you ever planned around a second title's schedule, say how, in your own words. If you didn't, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Leading a team and coordinating teams are different things, and the JD line asks for the second. Your material doesn't show how the weekly drops were coordinated across disciplines. For the part you stated, the words are: "I haven't led a team." Answer slot: if you worked with design, art, engineering or community on the drops, say who, and what you did to keep them in step, in your own words. If you didn't, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review" — JD | none given | none | [grounded] | discovery | Your material doesn't show a post-event review. Answer slot: if you looked back at how a content drop performed after it went out, in writing or in a meeting, say what that covered and which part was yours. If there was no such review, say so plainly and describe how you would run one. A3 rehearses that structure |
| F4 | "the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. It doesn't say you chose the KPIs or produced the numbers, so the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose what was measured, or pulled the numbers together yourself, say which, in your own words. If someone else produced them, say so plainly and stay with presenting them |
| F5 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap. But this is a single line with nothing behind it to inspect, so expect a probe (C1). Lead with it in its own terms: monthly, retention, to the studio head |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist and managing it with QA on each release are adjacent but not the same. The words stay at your scope: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA on releases or kept it updated, say how, in your own words. If you didn't, say so plainly and stay with writing it |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | Put the two sentences together and keep the title as you stated it: "Four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." The weekly drops say what the work was. Don't add the JD's "live-service" label to your own history |
| F8 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with it in your own words: weekly, main title, the last two years |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A document that QA still uses is adjacent evidence of clear writing, and you can say it at that scope. Answer slot: if you also wrote the regular updates, briefs or notes that went with the drops, say what they were, in your own words. If you didn't, say so plainly and stay with the checklist |

---

## Persona table

The relationship prior is "hiring manager", which puts Case/Strategist and Skeptic on top. Searches couldn't run, so there is no interviewer profile to adjust the weights. Your own words establish the loop: one 60-minute session with the Head of Live Operations. No values-style round is documented.

| Persona | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | "Here's a situation on our calendar. What do you do?" | High. A hiring manager for a live-ops role is buying the ability to run the calendar, so expect live problems | Clarify, then objective, approach, metrics and risks. Think aloud, and challenge one premise politely |
| B. Skeptic | Quiet probing of the step up: two titles, four disciplines, in-app purchases | High. F1 and F2 are where the JD presses hardest, and your stated in-app-purchase negative is an obvious gap for a mobile studio | B1 rehearsed until it's boring. Bridges built only from your own sentences, limits said plainly, and a ramp plan stated as a plan |
| C. Data-Driven Prober | "How were those retention numbers counted?" | Medium. The JD names retention metrics and KPIs, and F4 and F5 rest on one sentence | Know what you can and can't say about how the numbers were produced, and say plainly when you don't know |
| D. Conversational | "So, walk me through your journey." | Medium. It's the standard opener, and it's still scored | A timed 90-second arc. Treat casual questions on the games as scored |
| E. Peer Evaluator | Cross-team friction scenarios | Low to medium. This is the coordination line of the JD, delivered collegially | Propose principles for working at the seam between teams. Don't claim to know Saltmarsh's process |
| G. Pressure | "Sixty seconds. Why you?" | Low. There's no signal that this interviewer works this way, but the candidate shouldn't meet the style for the first time live | Pause, restate, hold on what you actually said, and concede the real gap without folding |
| H. Values / Behavioural | "Tell me about a time…" | Low. There's no values round on record, but one behavioural question is common | Map a story only where your own sentences carry it. Otherwise use the honest branch |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit the live-events calendar for two titles. What do you need to know in your first two weeks before you change anything?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Structure it. What is already committed and announced to players? What capacity does each discipline have? What did past events achieve against their targets? When are the release and QA windows? Which community promises are already out there? Then: what you would leave alone, and what you would look at first. You can anchor once: "For the last two years I ran the weekly content-drop calendar for our main title." Don't claim that calendar covered events or two titles | This is the core of the role (F1, F8) asked as a live problem. CASE delivery on JD content |
| A2 | "Two events, one on each title, both need the same engineering sprint. How do you decide?" | CASE | [generic] | Clarify first: the goal of each event, what is fixed (dates announced to players, platform deadlines), and what can be cut down. Then: compare the impact you'd expect against what each event costs; look for scope you could cut or a reusable feature; decide who makes the final call; and say how you'd tell each team and the community. The question asks nothing about your past, so the guidance claims nothing | Tests the two-title and coordination lines of the JD together (F1, F2). `[generic]` because it's a pattern, not Saltmarsh's process |
| A3 | "An event just ended and the numbers came in below target. Walk me through your post-event review." | CASE | [generic] | Cover, in order: what the target was and why; the baseline you'd compare against; which player segments moved; whether the cause was execution, design or something external; what you'd keep and what you'd change; who owns each follow-up; and how you'd write it up so it gets read. Present this as how you would run a review, not as one you've run | F3 is your thinnest row, so arriving with a structure is the honest cover. CASE, because it's a live problem from the JD's post-event review line |
| A4 | "The night before an event goes live, QA finds a bug. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: how severe the bug is and how many players it hits; who has the authority to decide; the options (fix and ship, ship with the feature off, delay); what you'd tell players and when; and what goes into the checklist afterwards. You can mention that you wrote the release checklist your QA team still uses. Don't say that it handled a case like this unless one actually happened | The release-checklist line of the JD (F6) as a live problem, anchored to the one sentence that carries it |
| A5 | "What would you put on a post-event KPI report for a mobile live event?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Build it in layers: did players take part, did they finish, did it affect retention compared with a baseline, did the content land, and where revenue applies, the revenue measures. Anchor: "I presented the monthly retention numbers to the studio head." On revenue, the plain line is: "I haven't worked on a game with in-app purchases, so that's the layer I'd learn from your past reviews." | The JD's KPI line (F4, F5). Tagged JD because it scores the stated requirement. The revenue layer is where the B2 gap shows up, so answer it here before he asks |

### B. Skeptic

**B1 is the highest-ROI prep in this pack.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran the content calendar for your studio's main title. This role is two titles, with design, art, engineering and community on every update. What makes you ready for that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team" | **Hold:** stay only on what the quote carries. "For the last two years I ran the weekly content-drop calendar for our main title." **Name the limit before he does:** two titles would be new. Answer slot: if you worked with design, art, engineering or community on the drops, say how you kept them in step, in your own words. If you didn't, say so plainly and stay with the calendar. Then give your ramp plan, as a plan: learn each title's cadence, meet each discipline lead, read past event reviews. **Follow-up 1, "But you've never led a team":** "I haven't led a team." Then you can point out that the JD describes coordination, and return to the calendar. **Follow-up 2, "So who actually made the calls on the calendar?":** Answer slot. If the calls were yours, say which ones and how you made them. If they weren't, say who made them and what your part was. Don't add anything to the quote to make the answer feel bigger | F1 and F2 are where this JD presses hardest against your stated background, so this objection will arrive in some form. JD, because it scores the calendar and coordination lines directly |
| B2 | "I don't see in-app purchases in your background. If an event's KPIs included revenue, how would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | Give a one-sentence acknowledgment with no apology: "I haven't worked on a game with in-app purchases." Then a plan, stated as a plan and never as past work: learn each title's economy, sit with whoever owns the revenue numbers, and read the last few event reviews. Then return to what you have: "I presented the monthly retention numbers to the studio head." Hold through a follow-up by repeating the plan. Don't reach for adjacent claims about monetisation | This is the gap you stated yourself, and for a mobile studio it's the likeliest second objection. It ties to the JD's KPI line (F4). The premise is conditional, because the JD doesn't say what Saltmarsh's KPIs are |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one real answer and own it. Your stated candidates are revenue KPIs on a game with in-app purchases, or working at a scale you haven't led. Name it, give the plan, and stop. Don't turn it into a strength in disguise | A standard Skeptic stem. Rehearsing it stops you from naming a gap you can't follow up on |
| B4 | "Why this move, and why now?" | EXP | [generic] | Answer slot: give your actual reason, in your own words. If part of it is wanting to work on more than one title, or a larger live operation, say so only if it's true. Keep it forward-looking and don't criticise your current or last studio | The "why here, why now" check. The pack supplies no reason, because only yours will hold |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, in your own words: which retention measure it was, who produced the numbers, what they were sensitive to, and the assumption behind them you would defend least. If you don't know how they were counted, say so plainly. That's an honest answer, and a better one than a method you can't defend on the second follow-up. Then say what part was yours | F4 and F5 rest on this one sentence. Defend-the-number EXP |
| C2 | "Tell me about a time the retention numbers moved and you had to explain why." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a month when the numbers moved and you were the one explaining. A good story has a named change, what you looked at, and what the studio head did next. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | An open prompt themed on the JD's retention line (F5) |
| C3 | "How did you know whether a content drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if drops were judged by a measure or a look back afterwards, say what it was and what part was yours, in your own words. If there was no such step, say so plainly, then say how you would judge one, using A3's structure | This links F8 to the post-event review line (F3). The premise is the JD's, and the guidance doesn't adopt it |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made of your four sentences, in order: four years as an associate producer at a puzzle-game studio; for the last two, the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. Close with why this role, using B4's answer. Time it | It's the opener, and it sets how every later answer is heard (F7, F8) |
| D2 | "Have you played our games? What did you think of the events?" | CO | [generic] | Play both titles tonight if you can find out which they are. Name one event you saw in each: one thing it did well and one thing you'd test. If you couldn't play them, say so rather than bluff. The research for this pack couldn't run, so the pack has no facts about the titles | The only CO question available without research, and a casual one that is scored |
| D3 | "How do you keep four teams informed about an update? What does your writing look like?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Anchor: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote the updates or briefs that went with the drops, say what they were and who read them, in your own words. If you didn't, say so plainly and describe how you would do it: one source of truth, a fixed format, what changed since last time | Covers the JD's written-communication line (F9) and part of the coordination line (F2) |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Art says the event assets will be a week late, and engineering has already locked the build. What do you do?" | CASE | [generic] | Clarify what's late and why. Look at options: reduce the art scope, use placeholder or reused assets, move the event, or split it into phases. Decide who makes the call, and how you tell community. Protect the relationship with art: don't make it a blame story | The coordination line (F2) as a live seam problem |
| E2 | "Tell me about a time you disagreed with someone on another team about a release or a content drop." | EXP | [generic] | Selection scaffold: pick a real disagreement with a named stake, where you held a view and the working relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle one | An open prompt themed on the JD's coordination line (F2) |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds. Why you, over someone who's already run live ops on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause. Concede in one line: "I haven't worked on a game with in-app purchases." Then hold on your two strongest sentences: the weekly calendar for the main title for two years, and the release checklist QA still uses. End with the plan from B2. Don't disparage the hypothetical other candidate | B2's gap under time pressure. Composure is what's being scored |
| G2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and QA still uses it." Answer slot: if others added to it or reviewed it, say who and what. If they didn't, say so. Precise credit is the answer, so don't shrink it or stretch it | An attribution probe on the one line that carries F6 |

### H. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if any of those monthly presentations carried bad news, say what it was, how you delivered it and what happened next, in your own words. If none did, say so plainly and pick another time, or say none comes to mind and how you would handle it | A common behavioural stem. F5's sentence is your closest material, but only if the story is real |
| H2 | "Tell me about a time something went wrong on a release." | VAL | [generic] | Selection scaffold: pick a release where something broke or nearly did. A good story has what happened, what you did, and what changed afterwards (perhaps in the checklist, if that's true). If none comes to mind, say so plainly, then give the nearest thing you have, or how you would handle one | An open prompt themed on the JD's release-checklist line (F6) |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B1 |
| Coordinate design, art, engineering and community | A2, B1, D3, E1, E2 |
| Own the post-event review and its KPIs | A3, A5, B2, C3 |
| Manage the release checklist with QA | A4, G2, H2 |
| 3+ years producing live-service games or apps | D1, B1 |
| Experience running a content calendar | A1, D1, C3 |
| Comfortable with player-retention metrics | C1, C2, A5 |
| Clear written communication | D3, A3 |

---

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a good post-event review look like here? Who reads it, and what decision does it feed?" | F3 is your thinnest row. You learn the format and show you're thinking about the deliverable |
| "Are the two titles planned on one shared calendar or on two separate ones?" | It goes straight to the two-title part of the job and tells you where the real coordination work sits |
| "Which KPIs matter most for events on these titles, and how are the targets set?" | It shows you take metrics seriously, and it tells you how much of the job is revenue (B2) |
| "As Head of Live Operations, what's the hardest trade-off your team makes between the two titles?" | It's aimed at his own role and invites him to talk about the actual work |
| "Where does the release checklist with QA stand today? Is it settled, or something this hire would shape?" | It connects to F6 naturally without you overselling it |
| "What would make the first 90 days in this role a success for you?" | It gives you his scoring sheet, and you can echo it in your follow-up note |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated, F2 | "I haven't led a team." |
| Has worked on live events, or KPIs, for a game with in-app purchases | A negative you stated ("never worked on a game with in-app purchases") | "I haven't worked on a game with in-app purchases." |
| Ran live-event calendars across multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one weekly content-drop calendar for the main title. B1's slot stays inside that calendar |
| Owned or designed the retention analysis or the KPIs | Inflated form of F4 and F5 | "I presented the monthly retention numbers to the studio head." The pack's observation: your material says presented, not produced or chose. C1's slot asks how the numbers were counted |
| Manages the release process or QA | Inflated form of F6 | "I wrote the release checklist our QA team still uses." The pack's observation: your material says wrote, not ran with QA |
| A producer title beyond associate producer | Inflated form of F7 | "4 years as an associate producer at a puzzle-game studio." |

---

## Sources

- **Provided:** your message (the JD text and your background).
- **Searches sent, all refused** because web search permission wasn't granted:
  - "Saltmarsh Games mobile studio values": refused
  - "Saltmarsh Games interview process producer": refused
  - "Saltmarsh Games mobile news 2026": refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused
- **Fetches:** none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. It would have themed the VAL questions on Saltmarsh's published values |
| 2. Saltmarsh Games interview process | unavailable | Refused. Your own words establish this session (60 minutes, Head of Live Operations), so it would have mainly confirmed the format and any case exercise |
| 3. Saltmarsh Games strategy / recent news | unavailable | Refused. It would have named the two titles and recent events, giving D2 and a CASE question real material |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused. It would have supplied an interviewer read, adjusted the persona weights, and made one reverse question specific to his career |
| 5. A representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search, and the four refused searches rerun.** You would get Saltmarsh's values, the names of its two titles, recent news and Tobias's public profile. That turns D2 and the reverse questions from generic to specific and adds a section on reading the interviewer.
- **A deeper research pass,** offered once: up to 6 more searches and 2 more fetches, several more minutes. It adds a company brief and strategy-based CASE questions.
- **Whether Tobias is the hiring manager, and any recruiter note on format** (a case exercise, a calendar walkthrough, a presentation). This reweights the personas and adds a build section for any piece of work you're asked to bring.
- **Your answers to the answer slots in F2, F3 and F4.** Say how you worked with other disciplines on drops, whether drops were reviewed afterwards, and who produced the retention numbers. Those rows and B1, C1, C3 and A3 then become story-mapped instead of slot-based.
- **A tuesday-dossier.md, if you have one,** sharpens the objections and adds a guardrail on what not to claim.
