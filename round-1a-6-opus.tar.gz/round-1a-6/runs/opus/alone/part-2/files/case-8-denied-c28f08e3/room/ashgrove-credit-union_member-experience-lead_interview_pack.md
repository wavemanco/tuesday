# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Candidate:** Dara · **Date:** 5 December 2026 · **Mode:** loop. There are three rounds on one day, with one mini-pack per round.

| Round | Who | Length | What the recruiter said it holds |
|---|---|---|---|
| 1 | Recruiter | 30 min | "30 minutes with me" |
| 2 | Head of Member Services (your future manager) | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | "including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values." |

Interviewer names haven't been assigned yet, so there is no interviewer read. Persona weights come from the round types the recruiter described.

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what style. **Types** describe what is being scored. Rehearse both, because the same content lands differently depending on how it's asked.
- **Type key:**
  - **VAL**: behaviour that shows Ashgrove's published values.
  - **EXP**: deep dive into your experience, and what was actually yours.
  - **JD**: can you do the listed job, gaps included.
  - **CO**: company and strategy knowledge.
  - **CASE**: a live problem from the role.
- **Provenance labels:**
  - `[grounded]`: traceable to your message, the JD, the values text or the strategy brief.
  - `[inferred]`: this pack's own derivation, which is named.
  - `[generic]`: a common pattern for this kind of role, with no claim about Ashgrove or you.
- **Answer slots:** an answer slot is a place where only you know the truth. It gives two honest branches. Either is a good answer. Never fill a slot with something that didn't happen.
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Highest-ROI prep in this pack: D1** (round 2). It's the objection most likely to come up, in some form, in every round.

---

## Fit snapshot

The quotes below are everything this pack knows about your past. Every story in the banks draws only on these four sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's formal log, not a process across branches, and the words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what handling the log involved likely. If parts of it were yours to decide, say which and how, in your own words. If they weren't, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, the contact-centre half | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | This is a gap that wording can't close, and you've said so. Words: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The spreadsheet is monthly and about complaints, but your material doesn't show what it counts. Answer slot: say what the spreadsheet counts and where its numbers come from, in your own words. If you're not sure how a figure is counted, say so plainly. Keep "our regional manager uses" exactly as it is: it says who uses it, not who you report to |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and "our" script, not one you wrote. Words: "I trained new tellers on our escalation script." Answer slot: expect a probe on how you trained them. Say how, in your own words. If the training was mostly walking them through the script, say so plainly and stay there |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Answer slot: if you've worked with a digital team, or on something members do for themselves online or in an app, say what it was and which part was yours. If you haven't, say so plainly. Then say how you'd start, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor. "Customer operations" is the JD's phrase. Let the interviewer make that match, and describe your years in your own words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | "Formal" is your word. Your material doesn't show which rules the log followed. Answer slot: say what made the log formal, meaning what rules or deadlines it followed, if any, and what your part in them was, in your own words. If you don't know, say so plainly and stay with the formal log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this gap. Words: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say what, to whom and how it went, in your own words. If you haven't, say so plainly. Then give a plan for building it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: name the tool you built it in and what you used it for, in your own words. If it isn't the tool they named, say so plainly |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own complaints end to end, branches and contact centre (F1, F2) | D1, B1, I2, H1 |
| Report monthly on volumes and resolution times (F3) | F2, F1 |
| Coach branch supervisors on escalations (F4) | D4, H3, I1, J1 |
| Work with digital teams on self-service journeys (F5) | E1, E2 |
| 4+ years financial-services customer operations (F6) | B4, A1 |
| Regulated complaints experience (F7) | B1, H1 |
| Confident presenting to senior leaders (F8) | B2, D2, C4 |
| Excel reporting (F9) | B3, F1 |

---

## Grounding brief: talk like you've read the strategy

This section uses only the July 2026 strategy brief the recruiter sent you and the values you pasted. The brief is about four months old.

| Fact | Where it will come up | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | The JD's "self-service journeys" line, plus E1 and E2. Complaints about digital journeys are what the monthly report will increasingly carry | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Your panel is two branch managers, and this plan changes their branches. Speak about it carefully and practically, not as a win to celebrate (G3) | [grounded] |
| Small-business lending product launches in Q1 2027 | A new product means new kinds of complaint. Good reverse-question material for round 2 | [grounded] |
| The main competitive pressure is app-only banks | A strong frame for the case: a badly handled complaint is a member who can leave for an app (H1) | [grounded] |
| Their own words are "member", "branch", "hub", "digital channels" and "self-service" | Say "members", not "customers". Plain Words is a scored value, so plain speech is part of the answer | [grounded] |

---

## Round 1: recruiter (30 min)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk-through, plus logistics | High. A recruiter screen is mostly this, and casual questions are still scored | Have a 90-second arc built only from your four sentences (A1) |
| Skeptic (light) | Knockout checks against the requirements list | Medium. The JD lists four requirements, and a recruiter checks them literally | Give each stated gap plainly and briefly. Don't hedge a "no" into a "sort of" |

### Question bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Build a 90-second arc in three beats, each one a sentence you gave. You spent six years in retail banking, the last three as a branch supervisor. You handled the branch's formal complaints log and trained new tellers on your escalation script. You built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Add nothing to the middle | F6, F1 and F3 are your strongest material, and this question is the warm-up that sets every round after it. EXP because it tests how you summarise your own record |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one value by its exact name and one fact from the brief, such as the move of member service to digital by 2028 or the hub plan. Answer slot: give your real reason for a credit union in your own words. If you don't have one specific to credit unions, say what draws you to this role instead | This is a motivation-consistency check. CO because it scores homework on the values and strategy, which you have in hand |
| A3 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, and point it toward what this role offers. Don't criticise your current employer | This is standard recruiter logistics. EXP because it's about your own history |
| A4 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a standard recruiter check. JD because it's about the job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | This is a standard knockout and timing check |
| A6 | "The role spans branches and the contact centre. Where are you based, and how do you feel about working across sites?" | JD | [grounded] | Logistics slot: give your actual location and the travel that works for you, in your own words | The JD's "across branches and the contact centre" makes a location question likely |

### Question bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for regulated complaints experience. Tell me about your complaints experience." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what your material carries: "I handled the branch's formal complaints log." Answer slot: say what made the log formal, meaning what rules or deadlines it followed, if any, and what your part in them was, in your own words. If you don't know, say so plainly and stay with the log you handled | F7 is the requirement most likely to be checked literally. JD because it scores a listed requirement |
| B2 | "Have you presented to senior leadership before?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it straight: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom. If you haven't, say so plainly. Don't let the recruiter's friendliness pull a "no" into a "sort of" | F8 is a stated gap. Rehearsing the plain version here keeps it from wobbling in round 2 |
| B3 | "Excel reporting is on the list. How comfortable are you with it?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: name the tool you built it in and what you can do in it, in your own words. If it isn't the tool they named, say so plainly | F9's gap is the tool, which is cheap to settle in one sentence |
| B4 | "The role needs four-plus years in financial-services customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "Six years in retail banking, the last three as a branch supervisor." Stop there and let it land. Describe the years in your own words, not the JD's | F6 is your strongest row. The recruiter checks it literally |

### Reverse questions (round 1)

| Question | Why it lands |
|---|---|
| "For the 20-minute case, will I see the scenario in the room or beforehand?" | It's a prep question the recruiter can answer, and it shows you're taking the case seriously |
| "Is this a new role or a backfill?" | It tells you whether you're building the complaints process or inheriting one, which changes your round 2 framing |
| "How does this role work alongside the contact centre's own management?" | It goes straight at F2's area without raising it defensively |
| "What does the Head of Member Services most want from this hire in the first six months?" | It gives you something to aim at in round 2 |
| "What's the timeline after 5 December?" | Practical. Recruiters weigh real interest |

---

## Round 2: Head of Member Services, your future manager (45 min, "mostly behavioural")

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" prompts | High. The recruiter said "mostly behavioural" | Use STAR shape. Say "we" for context and "I" for your part. Choose stories from your own material, and use the honest branch where none fits |
| Skeptic | Probes the gap between one branch and an organisation-wide role | High. A future manager is buying down the risk in the gaps | Rehearse D1 until it's boring. Name the limit before they press it |
| Case / Strategist | Short live problems on digital and reporting | Medium. A manager's usual tilt, reduced by "mostly behavioural" | Clarify, then structure, then answer, using Ashgrove's own strategy words |
| Data-Driven Prober | Digs into the spreadsheet | Medium. Monthly reporting is a listed duty, and F3 is your nearest evidence | Know exactly what your spreadsheet counts and where the numbers come from |

### Question bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint that went wrong before it went right." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Look first among the complaints that passed through the log you handled. Pick one with a member's real problem, a moment where it was going badly, what you did that was yours, and how it ended. If no such complaint comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F1 is your complaints evidence. A manager will want to hear it as a story. VAL because "Members First, Always" and "Own the Fix" are what's being scored |
| C2 | "Tell me about a time something you trained someone on didn't land the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Look first at the new tellers you trained on your escalation script. Answer slot: if part of the script didn't land with a teller, say what and what you changed, in your own words. If none comes to mind, say so plainly and describe how you trained them | This is "Plain Words": "if a member needs it explained twice, we wrote it wrong." F4 is the nearest material |
| C3 | "Tell me about a problem you found that wasn't strictly yours to fix." | VAL | [generic] | Selection scaffold. It needs a problem you spotted, a point where you could have handed it off, what you did to keep hold of it, and a result. If no such time comes to mind, say so plainly, then give the nearest thing or how you would handle it | This is "Own the Fix": "whoever finds the problem keeps hold of it until it is solved." Your material doesn't show such a story, so this is a scaffold |
| C4 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | Selection scaffold. It needs a named stake, the moment you said it, and an intact working relationship afterwards. Pick one where the truth actually landed. If no such time comes to mind, say so plainly and say how you would handle it | Presenting to senior leaders is in the JD, and a manager tests for spine. This is a persona stem, themed by F8's requirement |

### Question bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across every branch and the contact centre, and you've never worked in a contact centre. Why are you ready for it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "6 years in retail banking, the last 3 as a branch supervisor." | **This is the highest-ROI rehearsal in the pack.** **Name the limit first:** "I haven't worked in a contact centre." **Then hold on what you carry, in your own words:** six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. **Then a ramp plan, said as a plan:** early time with contact-centre colleagues on live complaints, and a side-by-side look at how complaints are logged there and in branches. **Follow-up 1, "How would you know what good looks like there?":** hold. Give the plan and the questions you'd ask the contact-centre lead. Don't claim a view you haven't formed. **Follow-up 2, "So they'd be teaching you?":** concede it specifically: yes, on how the contact centre works. Then hold that what you bring is the branch side you described. **Never say a complaint is a complaint whatever the channel.** Nothing in your material backs that up | F2 and F1 are the widest gap between you and the JD's headline line, and your future manager is the person who carries that risk. It will come in some form in every round. JD because it scores the end-to-end requirement, in a Skeptic's delivery |
| D2 | "This role presents to senior leaders, and you haven't presented above regional level. How will that go?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Hold-then-concede.** "I haven't presented to anyone above regional level." Answer slot: if you've presented at regional level, say what and to whom. If not, say so plainly. Then give a plan, as a plan: what you'd want to know about the audience, and a dry run with your manager before the first one. If pushed, concede specifically that it's new at that level. Don't fold into "I'm sure I'll be fine" | F8 is a stated gap on a listed requirement, and a manager will want to see how you handle it |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the gaps you stated, either the contact centre or presenting above regional level, not a fake weakness. Say it in one sentence, then give your plan. Don't list both unless asked | Reuses D1 and D2 in a different shape. This is a persona stem |
| D4 | "You've trained new tellers. Coaching branch supervisors is a different thing. How would you approach it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold to what you did: "I trained new tellers on our escalation script." Agree that supervisors are different. Then give an approach, as a plan: start from real escalations they've had, ask before telling, and agree what "good" looks like together. Don't describe coaching supervisors as something you've done | F4 sits next to the requirement but doesn't reach it, and the gap is level, not subject |

### Question bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "This role works with our digital teams on self-service journeys, and we're aiming to move 40% of member service to digital by 2028. What would you bring to that?" | JD | [grounded] | Answer slot (F5): if you've worked with a digital team or on a self-service journey, say what and which part was yours. If you haven't, say so plainly. Then give your plan: complaints show where members get stuck, so you'd bring the digital team the patterns from the complaints data, in plain words, and ask what they need from you | F5 is silent in your material, and the brief's 40% target makes this line live. JD in a case shape |
| E2 | "A member complains that the app wouldn't let them do something a branch always did for them. How do you handle it, and what do you do with it afterwards?" | CASE | [inferred] | Split the answer in two. First, this member: listen, fix or route it today, and explain in plain words. Second, the system: log it so it shows in the monthly report, check whether it's a pattern, and take it to the digital team. Close with Members First: decide from the member's side | Derived from the brief's digital target and the JD's self-service line, so it's `[inferred]`. CASE because it's a live problem |

### Question bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | You built it, it's monthly, it's about complaints, and your regional manager uses it. Those are your beats. Answer slot: say what it counts and where its numbers come from, in your own words. If you don't know exactly how something is counted, say so plainly. Name the tool you built it in | F3 and F9 both rest on this sentence, so a prober will go two levels deep. EXP because it tests what's actually yours |
| F2 | "What would be on page one of a monthly complaints report for senior leaders?" | JD | [grounded] | This is a proposal, not a past. Start with volumes and resolution times, since those are the JD's words, and how they're trending. Then the top causes in plain words, one member's story to make it real, and actions with owners. Name one thing you'd leave off and why | It scores F3's requirement directly, in a case shape. Plain Words applies to the report itself |

### Reverse questions (round 2)

| Question | Why it lands |
|---|---|
| "Where do complaints get stuck today: in branches, in the contact centre, or between them?" | It's the core of the job, and it opens the contact-centre topic on your terms |
| "What does the monthly report look like now, and who reads it?" | It tells you what F2's report replaces and who the senior audience is |
| "How will the move to five hubs change who owns a complaint locally?" | It shows you've read the brief and are thinking about "Own the Fix" through the change |
| "With small-business lending launching in Q1 2027, how will complaints on that product be handled?" | It's current, specific and about a real new load on your future team |
| "A year from now, what would tell you this hire was the right one?" | Managers answer this with their real priorities |

---

## Round 3: panel of two branch managers (60 min, 20-minute case, scored on the four values)

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Story prompts scored against the four values | High. The recruiter said they "score against the four values" | Map a story to each value (see the cheat sheet). Use the honest branch where none fits |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter announced it | Use the build section below. Clarify, then structure, then decide, then close the loop |
| Peer Evaluator | "What would you need from us?" and probes on who owns what | Medium. You'd coach their supervisors, and the hub plan touches their branches | Frame it as reciprocity. Propose principles for who owns what rather than claiming to know the current setup |
| Pressure | "Why would our supervisors listen to you?" | Low. Panels sometimes test composure | Pause and restate. Hold through two follow-ups. Concede specifically |

### Graded deliverable: the 20-minute complaint-escalation case

The case content isn't known yet, so this prepares a method, not an answer.

**Facts to build on**
- The four values, by exact name: "Members First, Always", "Plain Words", "Neighbours, Not Numbers" and "Own the Fix".
- The pressure from app-only banks, from the brief.
- The hub plan, from the brief.
- Your own side, from F1: "I handled the branch's formal complaints log."
- From F4: "I trained new tellers on our escalation script."

**Structure** (say it aloud before using it):
1. Clarify the facts and what the member wants.
2. Contain the problem for this member today.
3. Investigate.
4. Decide, and explain the decision in plain words.
5. Check the rules: ask which regulatory obligations and deadlines apply. Don't recite rules you aren't sure of.
6. Fix the cause, and make sure it shows in the monthly report.
7. Coach the supervisor involved.

**Three theses you can defend, each with its concession**

| Thesis | Concession to say aloud |
|---|---|
| Fix this member's problem first, then fix the system. They are two separate jobs | Sometimes the member can't get the outcome they want, and the honest answer in plain words is the fix |
| An escalation is data. Log it, look for the pattern, and report it | One case isn't a trend, so don't redesign a process on a single complaint |
| Whoever takes the escalation keeps hold of it until it's closed ("Own the Fix") | Keeping hold means tracking it and following up, not taking over the branch's job |

**How to stand out:**
- **The common answer** is apologise, escalate, resolve. Use it as your base, then add your divergence.
- **Your divergence:** keep the branch in the loop and coach the supervisor rather than taking the case away from them. This is "Neighbours, Not Numbers", and you'll be saying it to two branch managers.
- **What not to do:** don't promise compensation or an outcome before investigating just to make the complaint go away.

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's point of view, not the branch's | Selection scaffold. Pick a time you chose what was right for a member when it was harder for the branch. It needs the member's need, the cost to the branch, and your decision. If none comes to mind, say so plainly and say how you would decide (G1) |
| Plain Words | If it needs explaining twice, rewrite it | The nearest place to look is F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If something in training tellers on the script had to be explained again, that's a candidate story. If not, pick another time, or say so plainly (C2, G2) |
| Neighbours, Not Numbers | Every branch belongs to its town | Selection scaffold. Pick a time you treated a member or a situation as part of the local community rather than as a number. If none comes to mind, say so plainly and answer it as a plan (G3) |
| Own the Fix | Whoever finds the problem keeps it until it's solved | The nearest place to look is F3: "I built the monthly complaints spreadsheet our regional manager uses." If you built it because you noticed a problem, that's a candidate story, told only as far as it really went. If not, pick another time, or say so plainly (C3, G4) |

### Question bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter, even when it was harder for the branch." | VAL | [generic] | Selection scaffold, as in the cheat sheet. It needs the member's need, the branch's cost, your decision and the result. Say "I" for your part. If none comes to mind, say so plainly and say how you'd decide | "Members First, Always" is scored, and the panel uses the value's own words |
| G2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Look first at the complaints in your log, or at teaching the escalation script. Answer slot: if a member or teller needed something explained twice and you changed how you said it, say what, in your own words. If none comes to mind, say so plainly and say how you would rewrite something that didn't land | "Plain Words" is scored, and the question uses the value's own definition |
| G3 | "Over 2027, eight branches become five hubs. How do you keep complaints handling local when a member's branch has gone?" | VAL | [grounded] | Acknowledge that it's a real loss for members and staff. Don't treat it as painless in front of two branch managers. Then give ideas, as a plan: the hub knows the town's history, complaints during the move get tracked separately in the monthly report, and members hear in plain words what's changing. Ask what they're already hearing | "Neighbours, Not Numbers" meets the hub plan. It's the sharpest values-and-strategy question for this panel |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [generic] | Selection scaffold. It needs a problem you found, a point where you could have handed it off, what you did, and the end. If none comes to mind, say so plainly, then give the nearest thing or how you'd handle it | "Own the Fix" is scored, and the question uses the value's own words |

### Question bank H: Case / Strategist (the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | Practice case: "A long-standing member complains that a fee was charged wrongly. The supervisor's first reply made it worse, and the member now says they'll move to an app-only bank. Talk us through it." | CASE | [generic] | Use the build section's structure aloud: clarify, contain, investigate, decide, explain plainly, check the rules, fix the cause, coach. Name the app-only threat as the stakes, not the decision driver. Close on what you'd tell the member, in plain words | This is a practice scenario, not a prediction of the real case. It rehearses the format the recruiter announced |
| H2 | Follow-up: "It turns out there were three similar complaints across two branches this month. What now?" | CASE | [generic] | Move from the member to the system. Check whether it's a pattern, find the cause, decide who owns the fix, report it monthly, and tell the branches what you found. Concede that three cases may not be a trend yet | Panels usually widen a case partway. This tests the "escalation is data" thesis |
| H3 | Follow-up: "The supervisor followed the script and still got it wrong. How do you coach them?" | CASE | [generic] | Ask before telling: what did they see, and what did the member need? Then ask whether the script is the problem. If it is, that's a Plain Words fix to the script, not a fault in the person. Agree one change and follow up | This tests the JD's supervisor-coaching line live, in front of the managers whose supervisors you'd coach |

### Question bank I: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would you give us back?" | JD | [grounded] | Use reciprocity. What you'd need from them: time with supervisors and honest cases. What you'd give back: a clear monthly picture of their branch's complaints and fewer escalations bouncing back to them. Propose this as a plan, not something you've done | The JD's coaching line, seen from the branch managers' side |
| I2 | "When a complaint involves both a branch and the contact centre, who owns it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Propose a principle: whoever first takes it keeps hold of it until it's closed, and hands over with the full history ("Own the Fix"). If they ask about contact-centre experience: "I haven't worked in a contact centre." Then ask how it works today | Peers probe who owns what. F2's gap may return here in a friendlier form |

### Question bank J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You've been a branch supervisor. Why would our supervisors take coaching from you on escalations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause first. **Hold:** "I've been a branch supervisor for three years, so I've been where they are." Then "I trained new tellers on our escalation script." **Follow-up:** hold again by offering to learn from their supervisors' cases. **Concede specifically:** you haven't coached supervisors yet. Don't fold into apology | F6 and F4 are your footing. This tests composure in front of the people whose teams you'd coach |
| J2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I built the monthly complaints spreadsheet our regional manager uses." | Use only your sentences: your branch years, and the complaints spreadsheet your regional manager uses. Then add one value by name. Concede that an internal candidate knows Ashgrove better, and hold that you bring a fresh branch-side view. Stop at sixty seconds | A time-boxed persona stem. It tests economy under pressure |

### Reverse questions (round 3)

| Question | Why it lands |
|---|---|
| "What would you want from someone coaching your supervisors, and what wouldn't you want?" | It's a reciprocity question, and it shows you'd work with them, not over them |
| "When a complaint escalates past your branch today, what happens next, and what do you hear back?" | It shows where "Own the Fix" breaks today, in their own words |
| "How are members in your towns responding to the hub plans?" | "Neighbours, Not Numbers", asked with care |
| "Which complaints could members solve themselves in the app, and which should never go digital?" | It ties the 40% digital target to what they see at the counter |
| "What does a good escalation look like from your side?" | It gives you their definition of success for the role's core duty |

---

## Prohibited claims

This pack won't coach the following claims. Each one is the stretched form of something you did say, or a gap you stated.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack observes that the material describes one branch's log, not a cross-branch process. A1 and D1 stay inside the log |
| Has contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." The only slot is regional level, which stays inside your sentence |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." D4 and J1 give coaching only as a plan |
| Wrote the escalation script | Inflated form of F4 ("our" script) | "I trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F7 ("formal" stretched) | "I handled the branch's formal complaints log." B1's slot asks what made the log formal, nothing wider |
| Reports monthly on complaint volumes and resolution times | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." F1's slot asks what it counts |
| Builds Excel reporting | Inflated form of F9 | The same quote. B3's slot asks you to name the tool |

---

## Sources

**Provided documents**
- The JD.
- The values text, which you copied on 26 November 2026 from ashgrovecu.org/about/values. It was pasted, so it wasn't fetched.
- The recruiter's email describing the process.
- The July 2026 strategy brief, summarised in your message.
- Your background, from your message.

**Searches and fetches:** none were sent. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted that morning from the official page fix the cheat sheet and the G bank |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes the loop: three rounds, their lengths, the case and the values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief is under six months old and fixes the grounding brief, E1, E2, G3 and H1 |
| 4. Interviewer name + Ashgrove | n/a | No names have been assigned, so there's no query to form. The upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, once assigned:** an interviewer read, persona weights tuned to each person's public professional background, and one reverse question tied to each person's path.
- **Your answers to the answer slots in F1, F3, F4, F5, F7, F8 and F9:** each answer becomes quoted evidence. Those rows and B1, B3, E1, F1 and D2 would be rebuilt as story-mapped guidance.
- **A redacted copy of the monthly complaints spreadsheet:** F3 and F9 would move from `medium` toward `high`, because the report itself is the proof this field keeps. F1 would get real beats.
- **Your CV:** more of your own sentences to map to the four values, so fewer scaffolds in C1, C3, G1 and G4.
- **How much prep time you have before 5 December:** a prioritised prep schedule, starting with D1.
- **Any detail the recruiter can share on the 20-minute case:** the build section would be fitted to the actual scenario rather than a method.
- **A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes):** recent news on the hub plan and any published candidate reports on Ashgrove's interviews, for the G3 and H banks.
- **A `tuesday-dossier.md` from an earlier evaluation:** verified evidence and an agreed prohibited-claims list to build the guidance on. It's never required.
