# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, Tuesday, 60 minutes. Panel interview.
**Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director.
**Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."

---

## How to use this pack

- **Personas** describe how a question is asked: the interviewer's register. **Types** describe what is being scored.
- Type key:
  - **VAL**: behaviour and values. Does your past behaviour show what they care about?
  - **EXP**: work-experience deep-dive. Do your claims hold up, and what was actually yours?
  - **JD**: the role itself. Can you do the listed job, gaps included?
  - **CO**: company and strategy. Can you think at Kelverton's altitude?
  - **CASE**: a live problem from the role, solved out loud.
- Provenance labels: `[grounded]` traces to something you or the recruiter wrote. `[inferred]` is derived, and the derivation is named. `[generic]` is a role-family pattern with no claim about Kelverton.
- **Guidance is scaffolding, not a script.** Every answer slot asks you to give the real answer in your own words. If the honest answer is "that wasn't me" or "there was no such step", that branch is a full answer.
- Question IDs run A to H with **F skipped**, so they never clash with fit-snapshot rows F1 to F7.

## Prep triage: your four hours

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV, then say it out loud twice against a timer. Aim for 13 minutes, which leaves room for an interruption | Section "Graded deliverable" |
| 2 | 30 min | Re-read the market report for four things only: one point you agree with, one you would push on, the words it uses for operators' problems, and how it describes who buys and how they buy | Feeds POV moves 1 and 3, and A5 |
| 3 | 45 min | The commercials block, out loud: B1 (the highest-ROI prep in this pack), B3, D2 | Bank B, Bank D |
| 4 | 30 min | Rail credibility: C1, C2, C3 | Bank C |
| 5 | 20 min | Live cases: A1, A2, A3 | Bank A |
| 6 | 15 min | Choose 3 reverse questions, one for each panellist and one spare | Reverse questions |
| 7 | 25 min | One full run: POV plus B1, with a friend or a drill here | Drill offer |

Everything else in this pack is insurance.

## Fit snapshot

No job description was supplied and research could not run, so the requirements come from the recruiter's own words (`[grounded]`) and, where the recruiter said nothing, from the role family. Role-family requirements are plain unquoted prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows an ISV channel at a payments company. It does not show partnerships with operators, so the words stay with the channel: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: "operator partnerships" makes a probe on the difference likely. If any of those 40 relationships worked like a strategic relationship with an end customer, say which one and how, in your own words. If none did, say so plainly and stay with the channel you ran |
| F2 | "land on what it means for the operators themselves" — recruiter | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, done from the consulting side. It does not say train operating companies, scheduling software or the vendor side. Words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if you worked directly with operators in that consulting, say who they were and in what capacity, in your own words. If you didn't, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Influenced revenue is a commercial outcome, but it is not one you owned directly, and the words keep that limit: "roughly £4M of influenced revenue." The figure will be probed. Four answer slots, each in your own words: how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part of it was yours. "I don't know exactly how it was counted" is an honest answer |
| F4 | Owning a direct revenue number (role family) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You have stated this gap, so it gets plain words: "I haven't carried a direct quota. My number was influenced revenue." Then describe how you would want to be measured here, said as a plan and never as a past. Nothing added to make the gap look smaller |
| F5 | Experience selling into rail operators (role family) | "Never sold into rail specifically" — your message | none | [grounded] | capability | Stated gap, plain words: "I haven't sold into rail specifically." The nearest evidence is F2's quote at its own scope, plus a concrete ramp plan said as a plan. Never imply rail selling experience |
| F6 | Building and scaling a partner programme (role family) | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap, but it is a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: 6 partners to 40, in four years. Don't describe the growth method unless you are describing what you actually did |
| F7 | Senior-level partnerships tenure (role family) | "9 years in partnerships" — your message | medium | [grounded] | none | No gap. Note that your own message counts the five consulting years separately ("Before that, 5 years in transport consulting"). Be ready to say which years you count as partnerships, in your own words |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Operator partnerships plan | POV build, A1, A3, A4, C3, E1 |
| F2 Operator benefit | POV close, A2, A4, B4, H1 |
| F3 Commercials | B2, B3, B4, D2, D3 |
| F4 Direct revenue ownership | B1 (highest-ROI), D3 |
| F5 Rail selling | C1, C2, C4 |
| F6 Scaling a partner programme | D1, G1 |
| F7 Tenure | G1 |
| Kelverton's own strategy | A5, G2. These stay generic until research or the report's content is in hand |

## Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words:** "where you'd take our operator partnerships over the next 18 months", "no slides needed", "land on what it means for the operators themselves".

**One thing to know going in.** The panel's strategy team circulated the market report you have read. Deepa and Ross know it better than you do. Reciting it scores as homework. **Use one point from it to show you've done the reading, then make one argued departure from it.** That combination is what scores as judgement.

### Facts you can build on about yourself

These are quoted from your fit-snapshot rows. Don't stretch them.

- F1: "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4 and F5 are gaps you have stated. Don't build on them. The plan answers them (see move 3 and B1).

### Suggested 13-minute shape

| Minutes | Beat |
|---|---|
| 0–1 | Frame: the one sentence you want them to remember, and the operator outcome you will finish on |
| 1–3 | What you heard: one consensus point from the report, and the assumption you are making that they can correct |
| 3–9 | Three moves across 18 months (theses below), each with its concession said aloud |
| 9–11 | Commercials: how you would measure it and what you would want to be accountable for. This sets up Ross |
| 11–13 | What changes for operators. This is the requested close |
| 13 | What you would want to validate in your first 90 days. Hands over to Q&A |

### Thesis options

Pick two or three. All of them are `[generic]`: they are structural arguments about rail-tech partnerships, not facts about Kelverton. Ground each one in the report's own vocabulary before Tuesday.

| Thesis | The argument | Mandatory concession |
|---|---|---|
| T1 Depth over count | In 18 months, the partnerships that matter are the few integrations that sit next to scheduling in an operator's working day. Measure integration depth and operator adoption, not partner logos | It is slower to show progress, and the first two quarters produce little visible revenue. It also departs from how your own F1 quote reads ("6 partners to 40"). Answer slot: if your 6-to-40 years taught you something about count versus depth, say what, in your own words. If they didn't, argue the thesis on its own reasoning |
| T2 Operators as design partners | Treat a small number of operators as co-design partners on the partner roadmap. They tell you which integrations matter, and the operator benefit is built in rather than claimed | Operator procurement and governance limit what a pilot can promise, and an operator design partner can drift into free consulting. Say how you would bound it |
| T3 The people who shape requirements | Work with the advisers and integrators who shape operators' requirements before a tender is written, as influence partners and not resellers | This depends on how operators buy today. Check it against the report's account of buyers and procurement. Your F2 quote is bus and light rail network planning, so don't claim you know rail advisers from the inside (F5) |
| Anti-pick | Say what you would *not* do in 18 months: for example, launch a broad marketplace or chase partner numbers. A partnerships leader who can say no scores here | Saying no closes off options Ross may value. Name what would make you revisit it |

### The 18-month arc

- **0–3 months:** listen. Operator conversations, partner audit, agree the measures with Deepa and Ross.
- **3–9 months:** two or three focused pilots.
- **9–18 months:** scale what worked and stop what didn't.

Say the stop criteria aloud. They are where Ross's commercial push lands.

### Commercials beat: set this up before Ross asks

Propose the measures yourself. Two kinds, `[generic]`:

- **Operator outcomes:** adoption of partner integrations, and retention or expansion of operators who use them.
- **Kelverton revenue:** partner-sourced and partner-influenced pipeline, defined the way Kelverton already defines them.

Then say what you would own. This is where F4 meets the plan: "I haven't carried a direct quota; I'd want to agree up front which of these numbers is mine." See B1.

### The requested close: what it means for operators

- End on two or three concrete changes in an operator's working week, `[generic]` until you have matched them to the report's own list of operator problems. Examples to test: fewer manual hand-offs between scheduling and the systems around it, and faster recovery when the plan changes.
- Say it from the operator's side ("their planners would…"). Don't say "Kelverton would…".
- Don't present F2 as rail-operator insight. Your message says bus and light rail network planning. If you use it, use those words.

## Persona table

The recruiter's description establishes this session: one 60-minute panel, a POV, then Q&A. Weights come from that and from each panellist's relationship to you. No public profile was read, because research was refused.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Both panellists, through the POV and live problems | High. A hiring manager plus a commercial director, and the round is built around a strategy POV | Clarify, then state the objective, then structure the answer. Use the report's vocabulary. Challenge one premise respectfully |
| Pressure | Ross | High. "Ross will push on commercials" is the recruiter's own warning | Pause, restate the question, hold through two follow-ups, then concede specifically. Anchor only on what you actually stated |
| Skeptic | Deepa, mostly | Medium-high. The hiring-manager prior, and two stated gaps (F4, F5) | Rehearse B1 and C1 until they bore you. Plain acknowledgment, then the bridge at its own scope, then the ramp plan |
| Data-Driven Prober | Ross | Medium. Commercials plus a headline figure (F3) | Know what you can and cannot say about how the £4M was counted. Name the weakest assumption first |
| Peer Evaluator | Ross, as the commercial side you will share deals with | Low-medium. Partnerships and commercial teams share credit and the boundary between them | Propose principles for the boundary rather than claiming to know Kelverton's |
| Conversational | Openers, either panellist | Low. It is a second round, but an opener is still likely | A 90-second arc, built only from your quotes |
| Values | Either panellist | Low. No values round is documented, and Kelverton's values could not be researched | One customer-first story and one unpopular-truth story, chosen in advance |

## Question banks

### A — Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If we hired you, what happens in your first 90 days?" | CASE | [generic] | Clarify first: what has already been tried in operator partnerships? Then three beats: who you would talk to (operators, partners, the account owners), what you would audit, and the one or two measures you would agree with Deepa and Ross. End on what you would have decided by day 90. This question asks nothing about your past, so the guidance makes no claim about it | The most predictable follow-up to any 18-month POV. CASE because it tests how you sequence the work |
| A2 | "An operator says they'll only use a partner integration if we stand behind it in their contract. How do you handle that?" | CASE | [generic] | Clarify: what are they worried about, uptime, support or data? Then choose an approach: Kelverton stands behind it, the partner contracts directly, or a joint support model. Give the commercial and risk trade-off of each, then say which you would push for and why. Name the risk, a partner failing on Kelverton's contract, and how you would limit it | Brings the operator benefit and the commercial risk into one live problem, which is exactly both panellists' brief. CASE, with JD-type content |
| A3 | "How do you decide which partners to say no to?" | CASE | [generic] | Criteria before examples: operator demand, how close the partner's product sits to scheduling, Kelverton's capacity to support the integration, and commercial upside. Then the anti-pick from your POV. Don't claim past no-decisions unless you can name a real one in your own words | Tests judgement in a role where saying no matters. CASE |
| A4 | "At month 18, how would an operator know your partnerships work made a difference?" | CASE | [grounded] | Straight from the recruiter's close: "what it means for the operators themselves." Give two or three observable changes from the operator's side, then how you would check them (operator interviews, adoption data). Keep them `[generic]` until you have matched them to the report's operator problems | The recruiter named the operator benefit as the close, so expect them to push on it in Q&A. CASE, with CO content |
| A5 | "You've read the report our strategy team circulated. Where would you disagree with it?" | CO | [grounded] | One point of agreement, so they know you read it, then one argued divergence with your reasoning and what would change your mind. Be respectful: the panel's colleagues wrote it. Never correct a figure from memory | The report is shared material, so departing from it with reasons is the differentiator. CO |

### B — Pressure: Ross on commercials (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota. Why should I trust you with a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Pause. Concede first, exactly: "That's right. I haven't carried a direct quota. My number was influenced revenue, roughly £4M." Then hold on what the quote carries: you took an ISV channel from 6 partners to 40 with roughly £4M influenced. Answer slot: if you can say how the influenced figure was tracked and what part of it was yours, say so in your own words. If you can't, say that plainly. Then the move forward, said as a plan: propose which number you would own here and how it should be measured. **Follow-up 1** ("influenced isn't owned"): agree, don't argue it, and return to the measure you proposed. **Follow-up 2** ("so you'd want a soft target"): hold the line. You are asking to define the number clearly, not to dodge it. Never imply you carried a quota, and never call the £4M closed or booked | F4 is a stated gap, and the recruiter flagged that Ross will push on commercials, so this arrives in some form. JD, because the role family expects revenue ownership. Pressure delivery |
| B2 | "Sixty seconds. How much revenue does your plan add in 18 months?" | CASE | [generic] | Don't invent a number. Give the model out loud: number of focused partners × deals each influences × average deal value. Say which input you would defend least and what Kelverton data you would need to fill it in. Offer to come back with a figure in the first 90 days. Time-boxed, so stop at 60 seconds | A time-boxed push like this is what "push on commercials" usually looks like. CASE |
| B3 | "Influenced revenue is a number partnerships teams give themselves. Why is yours real?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold, then concede. Start by agreeing that the definition matters. Then four answer slots, in your own words: how the £4M was counted, what it is sensitive to, which assumption behind it you would defend least, and which part of it was yours. If you don't know how it was counted, say so plainly. Keep "roughly" in the sentence | F3's figure is the headline target for a commercial prober. EXP, because it tests attribution |
| B4 | "Why would an operator pay us more because we have partners?" | CASE | [generic] | Challenge the premise respectfully: they might not pay more. The value might show up as retention or wider use instead. Separate value to the operator from price, then say how you would test whether partner integrations change renewals | Tests whether you can tie operator benefit to Kelverton revenue without overclaiming. CASE |

### C — Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. How do you get credible with operators quickly?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Plain acknowledgment: "I haven't sold into rail specifically." Then the bridge at its own scope: five years in transport consulting, bus and light rail network planning. Answer slot: if that work involved operators directly, say how, in your own words. If it didn't, say so and stay with the planning work. Then a ramp plan, said as a plan: who you would listen to first and what you would read. Never say you know train operators | F5 is a stated gap and the obvious objection for a hire from outside rail. JD |
| C2 | "Your consulting was bus and light rail. What carries over to train operators, and what doesn't?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Name what doesn't carry over first. That earns trust for the rest. Then answer slot: what you believe carries over, in your own words, about the network planning you did. Keep "from the other side" accurate: the consulting side, not the vendor side | F2's limits are where a manager probes. EXP |
| C3 | "Running an ISV channel at a payments company is a different motion from partnering with train operators. What transfers?" | EXP | [grounded] "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say what you ran, in the quote's terms. Answer slot: describe what working with those partners actually involved and what part was yours, in your own words. Don't use the role family's vocabulary for it. Then say honestly what doesn't transfer, and how you would close that gap | F1 is a transferability row. The question names the gap directly, so rehearse it without defending too hard. EXP |
| C4 | "Why rail, and why now, after payments?" | EXP | [generic] | Your message doesn't give your reason, so this is an answer slot: give your actual reason in your own words. If it connects to your transport consulting years, say how. If it doesn't, don't force that link | A motivation-consistency probe is near-certain from a hiring manager. EXP |

### D — Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Of the 40 partners, how many actually produced revenue?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you know the split, give it. If you don't, say so plainly rather than estimate. Don't describe a long tail you haven't stated | F6's count is the denominator a prober reaches for. EXP |
| D2 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The four slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least (say it before they ask), and which part was yours. "I don't know exactly how it was counted" is an honest branch. Keep "roughly" | Defend-the-number for F3's headline figure. EXP |
| D3 | "What's the one metric you'd want Deepa to judge you on at month 12?" | CASE | [generic] | Choose one and defend it: an operator-outcome measure or a revenue measure. Say why that one, and what would tempt someone to game it. This links to B1 | Tests whether your measures are real or decorative. CASE |

### E — Peer Evaluator: Ross as your commercial counterpart (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How would you work with whoever already owns the commercial relationship with each operator?" | CASE | [generic] | Propose principles, not Kelverton's boundary, which you don't know: one owner per operator relationship, partnerships brought in early, and credit agreed before the deal. Ask how it works today | The boundary between partnerships and commercial is where partnership hires create friction. CASE |
| E2 | "How do you handle credit when a deal a partner helped with closes through sales?" | EXP | [generic] | Open prompt: choose a real instance from your channel years. It needs the deal, who took credit, and how you handled it. If no instance comes to mind, say so plainly and describe how you would handle it here | Ties straight to influenced revenue (F3). EXP |

### G — Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Remind us of the journey: consulting, then payments, then here." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc with three beats: transport consulting, then the ISV channel from 6 to 40, then why this role. The "why" is yours to give; see C4. Stop at 90 seconds | A second-round opener. Casual, but scored for economy. EXP |
| G2 | "What's caught your eye in rail tech since we last spoke?" | CO | [generic] | Answer slot: give something you actually read or noticed, report included. Don't reach for a headline you can't discuss | A casual question about a hot topic is still scored. CO |

### H — Values (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a time with a named metric, a customer or partner it would have hurt, and the decision you made. If no such time comes to mind, say so plainly, then give the nearest thing you can, or how you would handle it with an operator | Mirrors the operator-first close. VAL is themed by a persona stem, because Kelverton's values could not be researched |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you didn't fold, and the relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing you can | Partnerships roles often have to tell leadership no. Low weight, but cheap to prepare |

## Reverse questions

No public profile was read, so these are tied to each panellist's role.

| For | Question | Why it lands |
|---|---|---|
| Deepa | "What would tell you, 12 months in, that this hire was the right call?" | It invites your future manager to set the bar, which you can then test against your POV |
| Ross | "How does Kelverton count partnership revenue today: sourced, influenced or something else?" | It turns the quota question into a shared definition problem, on his own ground |
| Both | "Where did the strategy report land internally? What was argued about?" | It shows you read the report as a live argument, not as gospel |
| Deepa | "What has been tried in operator partnerships before, and what did you take from it?" | It stops you proposing something that has already failed, and shows you are listening first |
| Ross | "Is partnerships' success measured jointly with the commercial team, or separately?" | It surfaces the credit question in E2 before it becomes friction |
| Both | "Which operator would you most want me to talk to in my first month, and why?" | It keeps the operator at the centre, which is where the recruiter asked you to land |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a direct quota or owned a revenue target | A negative you stated, F4 | "I haven't carried a direct quota. My number was influenced revenue." No slot |
| Has sold into rail | A negative you stated, F5 | "I haven't sold into rail specifically." No slot |
| Knows train operating companies, or knows operators from a vendor's seat | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, done from the consulting side. The limit is the pack's own observation: your material does not mention train operators. C1's and C2's slots stay inside the consulting work |
| £4M as closed, booked or sourced revenue | Inflated form of F3 | "roughly £4M of influenced revenue", with "roughly" and "influenced" both kept |
| Personally signed or built each of the new partners | Inflated form of F1 | "took it from 6 partners to 40". C3's slot asks only what was yours |

## Sources

- **Provided:** your message, and the recruiter's email as you quoted it. The market report was not shared here, so nothing in this pack draws on its content.
- **Searches sent:** all five were refused, because web search permission was not granted:
  1. `Kelverton Rail values`: refused
  2. `Kelverton Rail interview process partnerships`: refused
  3. `Kelverton Rail scheduling software train operating companies news 2026`: refused
  4. `Deepa VP Partnerships Kelverton Rail`: refused
  5. `Senior Partnerships Manager rail technology job description UK train operators`: refused
- No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have themed the H bank from official values. No values round is documented, so there would have been no cheat sheet either way |
| 2. `Kelverton Rail interview process` | unavailable | The search was refused. It would not have changed this session, because the recruiter's email already describes it |
| 3. Kelverton strategy and recent news | unavailable | The search was refused. It would have grounded A5, G2 and the POV theses in Kelverton's current moves. The market report is the stronger source here |
| 4. Interviewer footprint: Deepa, Ross | unavailable | The search for Deepa was refused, and none was sent for Ross. It would have given an interviewer read, adjusted persona weights and added a reverse question tied to their careers |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused. It would have turned the role-family rows F4 to F7 into quoted requirements |

## Upgrade menu

- **The job description text:** rows F4 to F7 become quoted requirements, and every JD line gets a covering question.
- **Web search permission:** targets 1 to 5 run. That gives Kelverton's real values, its current strategy for A5 and G2, and Deepa's and Ross's public career paths for a tailored interviewer read and reverse questions.
- **Then, if you want it, a deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It adds a strategy brief, the panellists' talks and writing, and any recent changes at Kelverton.
- **The report's main points, in your own summary, if you're comfortable sharing internal material:** a grounding brief, POV theses tied to its actual numbers, and an exact consensus point and divergence for A5.
- **Your answers to the slots in B1, B3, D1, D2 and C3** (how the £4M was counted, what the 40 partners did, what was yours): those rows move from answer slots to mapped stories.
- **A partner-influenced pipeline report or deal sheet from your ISV channel, if you have one you can describe:** F3 and F6 move from medium towards high confidence.
- **A `tuesday-dossier.md`:** an evidence-graded highest-ROI objection and a list of claims you have already verified, carried between sessions. It is an addition, not a prerequisite.
