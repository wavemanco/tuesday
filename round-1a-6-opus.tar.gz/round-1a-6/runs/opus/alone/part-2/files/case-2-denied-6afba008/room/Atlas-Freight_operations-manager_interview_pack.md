# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known. **Round type:** not known.
**Built on:** the JD lines and background you gave in your message. No round type or loop source was available, so persona weights are flat (see the persona table).

---

## How to use this pack

Two axes organize every question:

- **Personas** describe *how* a question is asked: who's asking and in what style.
- **Types** describe *what* is being scored:
  - **JD**: can you do the listed job, gaps included
  - **EXP**: does your stated experience hold up under scrutiny, and what was actually yours
  - **CASE**: structured reasoning on a live problem from the role
  - **VAL**: behavioral stories
  - **CO**: company and strategy knowledge (none in this pack, because research didn't run; see Sources)

Provenance labels: `[grounded]` traces to your message or the JD. `[inferred]` is a derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about Atlas Freight.

An **answer slot** is an instruction for the interview where your material is silent. It always has two honest branches, and both are fine. Treat the guidance as scaffolding, not a script. Say it in your own words.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution, at one site, on a shift. It doesn't show terminal operations or four sites, and the words stay at that scope: "I have 7 years in warehouse and distribution ops, and I've run the site's peak-season surge plan two years running." For the move to four terminals, give a plan for how you'd learn the sites, said as a plan and never as a past |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Answer slot: the JD's on-time line makes a probe on how you've tracked or improved on-time or service-level performance likely. If you have, say what you tracked and what you changed, in your own words. If you haven't, say so plainly and say how you would measure it first |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Answer slot: expect a probe on cost. If you've tracked cost per shipment, or another cost or labor measure, say which one and what moved it, in your own words. If you haven't, say so plainly and say what you'd look at first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words at the quote's own scope: "I'm a senior shift manager over 3 supervisors today." The JD's span is 12, and the pack's observation is that your material shows 3. The bridge is how you lead your 3 now plus a plan for 12, said as a plan |
| F5 | "build reporting in Excel" — JD | "solid Excel, never used Power BI" — your message | low | [grounded] | discovery | "Solid Excel" doesn't yet show reporting. Answer slot: if you've built reports or trackers in Excel, say what they tracked and who used them, in your own words. If you haven't, say so plainly and stay with "my Excel is solid" |
| F6 | "build reporting in … Power BI" — JD | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | A gap you stated yourself. Words: "I've never used Power BI." Then how you'd learn it, said as a plan and never as progress you haven't made. Add nothing to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is not the same claim as seven years in leadership, and your material doesn't say how many of those years involved leading people. A titled-years line like this is likely screened literally; that's a reading of the JD, not a known fact about Atlas. Answer slot: say how many of your 7 years you've been leading people, as the real number, in your own words |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap. It's a stated credential with nothing inspected behind it, so expect a light probe. Lead with it in its own terms: "I'm Green Belt certified" |

---

## Persona table

No round type, interviewer or loop source was available, so this uses the generic archetype (screen, then hiring manager, then panel) with **flat weights**, said plainly. If you find out who you're meeting, the weights change (see the upgrade menu). Bank letters skip F so they don't collide with fit-snapshot IDs.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Probes the jump from 3 supervisors on a shift to 12 across four terminals | Flat weight. F1, F4 and F7 give this persona the most to work with, so it holds the highest-ROI question | Rehearse A1 until it's boring. Bridge only from what you stated, and name the limit before they do |
| B. Data-Driven Prober | Asks how the 40% was counted | Flat weight. The 40% is your one headline number, and numbers draw probers | Know what you can and can't say about how it was counted |
| C. Case / Strategist | Live problems on on-time and cost per shipment | Flat weight. The JD's two headline metrics invite live cases | Clarify, then objective, segment, approach, metrics, risks. Think aloud |
| D. Pressure | Time-boxed, devil's advocate, the Power BI gap | Flat weight | Pause, restate, anchor in what you stated, then hold through two follow-ups before conceding |
| E. Values / Behavioral | STAR stories on leading supervisors and holding service | Flat weight. No published values were in hand, so the themes come from the JD | "We" for context, "I" for your contribution |
| G. Conversational | "Walk me through your journey," casual Lean question | Flat weight. Casual questions are still scored | A pre-built 90-second arc |
| H. Peer Evaluator | Seams with other site leads and with customer service | Flat weight. Four sites means peers at the other sites | Reciprocity: what you bring them, not just what you need |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage 3 supervisors today. This role leads 12 across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **Highest-ROI rehearsal in this pack.** Name the size of the jump before they do: "Twelve across four sites is a bigger span than the 3 supervisors I lead today." Then hold on what you've done: "I'm a senior shift manager over 3 supervisors, and I've run the site's peak-season surge plan two years running." Then the plan, said as a plan: how you'd get to know each site and its supervisors in the first 90 days. Through two follow-ups, return to those two facts. Never widen them. The honest concession is the span, said in those words | F1 and F4 are where this role presses hardest, so some form of this question is near-certain. JD because it scores the stated span |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Give the real answer you've already stated: "I've never used Power BI. My Excel is solid." Then a concrete learning plan, as a plan. Don't swap in a safer-sounding weakness, because the interviewer will reach Power BI anyway | F6 is a gap you stated, and naming it first turns it into candor |
| A3 | "The posting asks for 5+ years of operations leadership. How many of your years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say how many of your 7 years you've been leading people, as the real number, in your own words. If it's under five, say the number plainly and stay with what you lead today. Never round 7 years of ops into 7 years of leadership | F7 is the one requirement marked "required," and it's likely read literally |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slots, each in your own words: how the 40% was counted, what it's sensitive to, the assumption behind it you'd defend least (name it before they do), and which part was yours. If you don't know exactly how it was counted, say so plainly. That beats a method you can't repeat under a second question | Every headline number gets a defend-the-number question, and this is the only one in your material |
| B2 | "What did redesigning the pick path actually involve?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats your sentence carries: the pick path, redesigned, mis-picks cut by 40%. Answer slot: the JD's Lean/Six Sigma line makes a probe on how you approached the change likely. Say how you went about it, in your own words. If there was no formal method, say so plainly and describe what you changed | It tests what was actually yours behind the number. EXP, premised only on your sentence |
| B3 | "How would you report on-time performance across four terminals each week?" | JD | [generic] | Structure: define on-time (against what promise), cut it by site and shift, pair it with one or two leading indicators, and set who sees it and how often. The question asks for a design, not your past, so the guidance makes no claim about it | F2 and F5 together. JD content with CASE delivery |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Suppose cost per shipment rose this quarter at one of four terminals but not the others. Diagnose it." | JD | [generic] | Clarify first: same period, same definition? Then split the numerator (labor hours and overtime, linehaul, dock and handling, damage and claims) from the denominator (volume, shipment mix). Compare against the other three sites as your control. Name what data you'd pull first and the first two hypotheses you'd test | F3: the JD's cost line, asked as a live problem. JD content, CASE delivery |
| C2 | "On-time performance dropped at two terminals last month. What do you do in your first week?" | JD | [generic] | Clarify where in the flow the misses happen (dock, loading, dispatch, linehaul). Check what the two sites share and what changed. Go to the floor and talk to the supervisors. One containment action now, root cause after. Say how you'd know it's fixed | F2. Tests clarify-before-structure |
| C3 | "Plan your first 90 days owning four terminals." | JD | [generic] | Days 1–30: visit every site, meet each supervisor one to one, baseline on-time and cost per shipment by site. Days 31–60: pick the biggest gap and one quick win. Days 61–90: a shared weekly report and a cadence with the supervisors. A plan, not a past | F1. The likely close to a hiring-manager conversation |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Concede the real point first: they know the terminals. Then hold on three facts in your own words: you cut the mis-pick rate 40% by redesigning the pick path, you ran the site's peak-season surge plan two years running, and you're Green Belt certified. Stop under 60 seconds | Composure under a time box. Every fact used comes from your own sentences |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say which part was yours. If others shared the work, name your part plainly and credit theirs. If it was yours, say so without apology. Hold through two follow-ups by repeating the same split, never by enlarging it | An attribution probe on your only metric. Candor rehearsed |
| D3 | "You've never used Power BI, and our reporting runs on it. Why shouldn't that rule you out?" | JD | [grounded] "solid Excel, never used Power BI" | Don't argue the premise. You stated it: "I've never used Power BI. My Excel is solid." Answer slot: if you've started learning it, say what you've done. If you haven't, say so plainly and give your plan with a date. Hold that it's learnable without claiming progress you haven't made | F6 under pressure. The premise is your own words, so the question is lawful |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to deal with a supervisor who was underperforming." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a time with one of your supervisors that has a clear problem, a conversation you led, and a result you can name. If no such time comes to mind, say so plainly, then give how you would handle it | The theme comes from the JD's 12 supervisors (F4) |
| E2 | "Tell me about a time you had to protect service when a plan went off track." | VAL | [grounded] "ran the site's peak-season surge plan two years running" | Selection scaffold: it needs a named stake, the decision you made, and the result. If something in the peak-season surge plan you ran went off track, that may be your story. If nothing did, or no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Theme from the JD's on-time line (F2) |
| E3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a time you told someone senior something they didn't want to hear, where it actually landed and the relationship held. If no such time comes to mind, say so plainly, then give how you would handle it | A persona stem. Common in panels |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc: 7 years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, two proof points (the 40% mis-pick cut, the peak-season surge plan two years running), and why this role next. Answer slot: the roles before your current one aren't in your material, so give them in your own words | It's scored, and it sets the frame for everything after |
| G2 | "What draws you from warehouse into terminal operations?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Answer slot: give your own reasons, in your own words. Don't describe terminal experience you haven't stated. If you're asked what carries over, stay with what your sentences carry | F1's warehouse-to-terminal step, asked as motivation |
| G3 | "Are you doing anything with Lean these days?" | JD | [grounded] "green belt certified" | Lead with "I'm Green Belt certified." Answer slot: if you have a current improvement project, describe it in your own words. If you don't, say so plainly and stay with the certification | F8: a "plus" skill, asked casually but scored |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Customer service keeps promising delivery windows the terminals can't hit. How do you handle that seam?" | CASE | [generic] | Propose principles rather than pretending to know their seam: one shared definition of on-time, an agreed escalation path, a weekly look at misses together. Show both spine and tact | F2 across a seam. The interviewer's own team may sit on the other side |
| H2 | "How do you handle credit when an improvement spans shifts or teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others worked on the pick-path redesign, say how you shared the credit, in your own words. If it was yours alone, say so and pick another time credit was shared. If none comes to mind, say how you would handle it | Credit-sharing is a peer staple, and it tests attribution again |
| H3 | "What would you need from the other site leads in your first month, and what would you give back?" | CASE | [generic] | Give before you ask: what you'd bring (fresh eyes, a shared report they can use), then what you'd need (their baselines, their known problems) | The four-site structure (F1) makes peer leads likely |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| F1 Own daily terminal operations across 4 sites | A1, C3, G2, H3 |
| F2 Drive on-time performance | B3, C2, E2, H1 |
| F3 Cost per shipment down | C1 |
| F4 Lead a team of 12 supervisors | A1, E1 |
| F5 Build reporting in Excel | B3, A2 |
| F6 Power BI | A2, D3 |
| F7 5+ years operations leadership | A3 |
| F8 Lean/Six Sigma a plus | G3, B2 |
| Company strategy (CO) | none: research didn't run, so a CO question would have been invented |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured today, and how much does it vary across the four sites?" | It shows you think in the JD's own metric, and the answer tells you where the problems are |
| R2 | "Where does cost per shipment stand against target, and what's driving it?" | The other headline metric. It also shows whether there's a target at all |
| R3 | "What does reporting look like today: what's in Excel, what's in Power BI, and who builds it?" | It shows you know the reporting is part of the job, and it sizes the Power BI gap for you |
| R4 | "How are the 12 supervisors spread across the sites, and how long have most been in role?" | It shows you're already thinking about the team you'd lead |
| R5 | "What would make the first six months in this role a success?" | It gets the real scorecard, which may differ from the JD |
| R6 | "Is this a new role or a backfill, and what's changed since it was last filled?" | It tells you what the role is really for |

---

## Prohibited claims

What this pack won't coach, and why. Each entry is a wording a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations | Inflated form of F1 | F1's quote at its own scope: "7 years in warehouse and distribution ops." The pack's observation: the material says warehouse and distribution, not terminals |
| Managed multiple sites | Inflated form of F1 | "ran the site's peak-season surge plan two years running", at its own scope. The pack's observation: the material says one site |
| Led a team of 12 supervisors, or a span that size | Inflated form of F4 | "I'm a senior shift manager over 3 supervisors today." |
| Seven years of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops", at its own scope. A3's slot asks only how many of those years involved leading people |
| Has used or built in Power BI | Negative you stated, F6 | "I've never used Power BI." No slot |

---

## Sources

- **Provided:** your message, with the JD lines as you quoted them and your background.
- **Searches sent:**
  - "Atlas Freight regional logistics company values": refused (search permission not granted)
  - "Atlas Freight interview process operations manager": refused (search permission not granted)
  - "Atlas Freight logistics terminals news 2026": refused (search permission not granted)
- **No dossier** was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The search was refused. A values page would have themed the E bank by Atlas's own value names and, with a values round, added a cheat sheet |
| 2. Atlas Freight interview process, operations | unavailable | The search was refused. Loop structure would have replaced the flat persona weights |
| 3. Atlas Freight strategy / recent news | unavailable | The search was refused. It would have added a CO question and grounded C1 and C2 in current priorities |
| 4. Interviewer name + Atlas Freight | n/a | No name was given, so there was no query to form. There's no interviewer read |
| 5. Representative Operations Manager JD | skipped | The JD lines you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Who you're meeting and in what round** (hiring manager, peer, site leadership, HR) → real persona weights instead of flat ones, and banks reordered and resized
- **The interviewer's name** → an interviewer read and a reverse question tied to their own career path
- **The recruiter's prep email**, if there is one → coverage of any announced presentation or case, plus the stated focus areas
- **The full JD text** and **your CV** → more requirements turned into questions, and evidence quotes for your earlier roles in G1
- **Your answers to the answer slots** (how many years you've led people, whether you've tracked on-time or cost measures, Excel reports you've built) → F2, F3, F5 and F7 become story-mapped instead of slots, and A3, B3, C1 and C2 get sharper
- **Allowing web search** → the values, loop and news targets run, adding a CO question and possibly a values cheat sheet
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on Atlas Freight and a sharper CASE bank
- **A tuesday-dossier.md**, if you have one → evidence-graded objections and a prohibited-claims list carried in from earlier work
