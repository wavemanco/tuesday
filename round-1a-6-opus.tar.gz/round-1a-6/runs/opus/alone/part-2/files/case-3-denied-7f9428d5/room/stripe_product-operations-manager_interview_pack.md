# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not named; relationship unknown.
**Built from:** your one-line message only. No JD, no CV, and no web research, because every search was refused in this session (see Sources). Every question and requirement here is a role-family pattern, labeled `[generic]`. The upgrade menu at the end says what each missing input changes.

---

## How to use this pack

- **Personas** describe *how* a question arrives: who asks it, and in what style. **Types** describe *what* is being scored. Rehearse both: the same content can be asked by a friendly peer or a time-boxing skeptic.
- **Guidance is scaffolding, not a script.** Each cell tells you what a strong answer is built from. With no CV in hand, questions about your past get a *selection scaffold*: what kind of story to pick, and what to say if you don't have one. Fill them in from your own work, in your own words.
- **Question IDs:** A = Case/Strategist, B = Values/Behavioral, C = Skeptic, D = Data-Driven Prober, E = Peer Evaluator, G = Pressure, H = Conversational. (F is kept for fit-snapshot rows.)

| Type | Name | What it's really testing |
|---|---|---|
| VAL | Behavioral / values | Whether your past behavior shows the company's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually yours |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company & strategy | Homework depth; thinking at the company's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role, delivered live |

---

## Fit snapshot

This is the **worksheet version**. You haven't shared a CV or the JD yet, so the requirements are typical product-ops requirements (plain prose, `[generic]`), and every evidence cell is empty. Use the right-hand column to pick your story for each row before the interview. Once you send the JD and CV, this table is rebuilt around your actual evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launch readiness between product teams and the operational teams that support users (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a launch where you set the readiness checklist or owned the go/no-go call, with a named outcome. Pick a launch where your part is easy to state in one sentence, and say which decisions were yours. If you have no launch like that, say so plainly, then give the nearest work you do have, or walk through how you would run one |
| F2 | Turn operational data into decisions: queries, dashboards, metric definitions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a metric you defined or an analysis you ran yourself, where you can say how the number was counted and what it changed. Pick one you can take apart under questioning. If you have none, say so plainly and say how you would approach the first analysis in this role |
| F3 | Build feedback loops from users and support back into product priorities (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a channel or routine you set up that carried user signals to a product team, and one change it led to. Pick an example where the line from signal to decision is visible. If you have none, say so plainly and sketch how you would build one |
| F4 | Design processes and tooling: playbooks, documentation, automation (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a process you designed or changed, with what it replaced and what it improved. Pick one where you can name the before and after. If none comes to mind, say so plainly and describe how you would decide what to fix first |
| F5 | Influence without authority across product, engineering, support and other teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a time you moved a team that didn't report to you, with the disagreement and how it ended. Pick one where the relationship survived. If none comes to mind, say so plainly and say how you would handle it |
| F6 | Prioritize and run programs under ambiguity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a time you chose what not to do, with your reasoning and the trade-off you accepted. Pick one with a real cost. If none comes to mind, say so plainly and walk through how you would make the call |
| F7 | Domain fluency in the product area the team supports (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: hands-on use of, or work near, the product area. Pick what is true for you, at its real depth. If you have no such exposure, say so plainly and say how you would ramp up in the first month |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1, E2, B4 |
| F2 Operational data | A2, D1, D2, D3 |
| F3 Feedback loops | A3, B2 |
| F4 Process and tooling | A4, D3 |
| F5 Influence without authority | B1, B3, E1, E2 |
| F6 Prioritization | A5, B4 |
| F7 Domain fluency | C2, H2 |

---

## Persona table

**How the weights were set:** a final round with your interviewers' roles unknown, so the weights are blended. "Final round" doesn't say how many sessions there are or what each one covers, so the loop isn't established. These weights rest on the **big-tech structured** archetype (recruiter → hiring manager → skills/case → behavioral/values → committee). That's a common pattern, not Stripe's documented process. The archetype raises Case and Values/Behavioral. If you send your schedule, the weights get re-read from it.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan a launch, diagnose a metric, design a process | Highest (5 questions). The archetype raises it, and product ops is a role where live operating problems are the natural test | Clarify → objective → segments → approach → metrics → risks; think aloud; challenge one premise respectfully per case |
| Values / Behavioral | "Tell me about a time…" stories, often from someone outside the function | High (4). The archetype puts a values round somewhere in the loop. Stripe's published principles couldn't be fetched, so these questions use generic themes | "We" for context, "I" for your part; pick stories where the hard truth actually landed; where you have none, say so |
| Skeptic | Quiet probing of gaps and motivation: why here, why now, what you'd be weakest at | Medium (3). Final rounds tend to test whether the story holds together | Rehearse C1 until it's boring; build bridges only from work you actually did; have a concrete ramp plan |
| Data-Driven Prober | Asks how numbers were counted; follow-ups two levels deep | Medium (3). Product ops sits on operational data (F2), so expect any figure you mention to be probed | Know how each number you'll cite was counted; name the weakest assumption first; say plainly when you don't know |
| Peer Evaluator | Seams between teams, "what would you need from me", disagreement with equals | Medium (3). Product ops works between teams (F5), and final rounds often include future collaborators | Reciprocity: what you bring their team; propose principles for the seam instead of pretending to know it |
| Pressure | Interrupts, time-boxes, questions motives | Low (2). Nothing points to it, but it can show up in any round | Pause, restate, anchor in what you said; hold through two follow-ups before conceding anything real |
| Conversational | Friendly openers that are still scored | Low (2). Almost every session opens this way | A rehearsed 90-second career arc; treat casual questions as scored |

---

## Question banks

**Highest-ROI prep in this pack: C1** ("Which part of this role would you be weakest at on day one?"). Some version of it is likely in a final round, and a rehearsed, non-defensive answer changes how the rest of the interview goes.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A new product feature launches in three weeks and the support team hasn't been briefed. What do you do this week?" | CASE | [generic] | Clarify first: who the users are, how big the launch is, what support will see. Then: triage what must be ready on day one (top expected questions, escalation path, known limits) versus what can follow. Name owners and a readiness check before launch, and say how you'll know in week one whether support was ready (ticket volume, time to resolve, escalations). Close with the risk you'd flag to the product lead now. The question asks nothing about your past, so the guidance claims nothing | Launch readiness (F1) is a typical core of product ops; CASE because it scores structure on a live problem |
| A2 | "Support tickets about one feature rose 30% week over week. Diagnose it." | CASE | [generic] | Don't jump to a cause. First check whether it's real: did the definitions, tagging or volume baseline change? Then segment: which users, plans, regions, channels, since when. Line it up against recent launches, outages or docs changes. Form two or three hypotheses, say which data would separate them, and what you'd do in the meantime for affected users | The Prober's metric-diagnosis pattern applied to operational data (F2); CASE because reasoning is scored, not the answer |
| A3 | "Design a system that gets user feedback from support into product teams' priorities." | CASE | [generic] | Objective first: decisions, not a feedback archive. Intake (tagging taxonomy, who tags), aggregation (volume plus severity plus affected-user value), a regular forum where product teams see it, and a closing loop back to support on what happened. Metrics: share of top issues that get a product decision, time to decision. Risk: loudest-voice bias, which you'd counter with a weighting rule | Feedback loops (F3) are a standard product-ops mandate; CASE |
| A4 | "Ops spends 20 hours a week on a manual review. How do you decide whether to automate it?" | CASE | [generic] | Clarify what the review protects against before touching it. Weigh: cost of the hours, error rate today, cost of an automated mistake, how stable the rules are. Options: automate the clear cases and keep humans on the edge cases, improve tooling, or leave it. Say how you'd pilot it and what would make you roll back | Process and tooling judgment (F4); CASE |
| A5 | "Three product teams each want your support for launches in the same month. How do you decide?" | CASE | [generic] | Ask what each launch risks if it's under-supported (user impact, revenue, regulatory or trust exposure, reversibility). Make the criteria visible to all three teams before you rank, so the call isn't personal. Say what each team gets, including the one that gets least, and how you'd escalate if they disagree | Prioritization under constraint (F6); CASE |

### B. Values / Behavioral

Stripe's published principles couldn't be fetched, so these use generic themes. Once the values page is in hand, each value gets its own question.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear, with a named stake, the way you framed it, and what happened next. "We" for context, "I" for what you said. If the truth didn't land, say so and what you learned. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | A standard values theme, and close to the influence work in F5; VAL because it scores past behavior |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where a metric and a user's interest pointed in different directions, what you chose and what it cost. Name the trade-off plainly. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | Tests user-first judgment, which the feedback-loop work in F3 depends on; VAL |
| B3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a cross-team piece of work and say exactly what was yours and what was others'. The precision is the answer. If you can't think of one, say how you would handle it | Cross-team work (F5) makes credit a real question; VAL because it tests behavior, not knowledge |
| B4 | "You discover a process your team runs is quietly failing users, but fixing it means missing a launch date. What do you do?" | CASE | [generic] | Size the harm first: how many users, how bad, how reversible. Options: fix now, launch with a mitigation and a dated fix, or delay. Say who you'd tell and when, and what you'd recommend. A values round scores whether you surface it at all, so lead with that | A values theme asked as a live dilemma (F1, F6); CASE because it asks about no past |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal.** Pick one real gap from the fit snapshot rows, the one you'd genuinely rank lowest, not a disguised strength. Say it in one sentence, plainly. Then a concrete 30-day plan to close it: who you'd learn from, what you'd ship or read, how you'd know you'd caught up. **Hold-then-concede:** follow-up 1, "Why should we take that risk?": go back to your plan, don't enlarge your strengths. Follow-up 2, "Anything else?": concede a second, smaller gap specifically rather than saying "nothing". Never claim a gap away | Some version of this objection is likely in a final; rehearsing a non-defensive answer is the best use of an hour. JD because it scores the role's requirements against you |
| C2 | "Why Stripe, why this role, why now?" | CO | [generic] | Three short parts. Why the company: something specific you've seen yourself as a user, builder or reader, not a slogan. Why product ops: what in this kind of work you want more of. Why now: what you're ready for. Keep each to two or three sentences. Research the company's current priorities yourself beforehand, since this pack couldn't | Motivation consistency is the Skeptic's core test; CO because it rewards homework (F7) |
| C3 | "How would you handle the parts of this role you haven't done before?" | JD | [generic] | Name which parts those are, honestly. Then the method: find who's done it here, learn the existing playbook before changing it, take on a small piece early to learn by doing. Don't promise mastery; promise a ramp | The forward-looking version of the background-gap probe; JD |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a number you've reported on. Which assumption behind it would you defend least?" | EXP | [generic] | Selection scaffold: pick a figure you know well enough to take apart. Say how it was counted, what it's sensitive to, and the assumption you'd defend least, in your own words, before they ask. If you don't know how it was counted, say so plainly. If no figure comes to mind, say so plainly and say how you'd check a number before reporting it | Operational data (F2) puts any number you cite under the Prober's lens; EXP because it tests precision about your own work |
| D2 | "Adoption of a new feature is up 15%, and so are tickets about it. What's your read?" | CASE | [generic] | Don't call it good or bad yet. Normalize: tickets per active user, not raw tickets. Segment by ticket type (how-to versus bugs versus billing). Rising how-to questions with adoption can be healthy; rising bugs isn't. Say what you'd look at next and what would change your mind | Tests reading two metrics together (F2); CASE |
| D3 | "How would you measure whether a process change actually worked?" | CASE | [generic] | Define success before the change, with a baseline. Pick one primary metric and one guardrail metric (for example, speed up while error rate holds). Note confounders like seasonality or a concurrent launch, and when you'd run a holdout versus a before/after comparison | Process (F4) and data (F2) together; CASE |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles instead: a named owner for each decision, a shared definition of "ready", disagreements raised early and in the open, and escalation as a last resort, agreed in advance. Ask what's worked for them | Peer interviewers test partnership fit (F5); CASE because it asks about no past |
| E2 | "A PM ships a change without telling support, and tickets spike. What do you do the next day?" | CASE | [generic] | First the users: get support what they need today. Then the PM, privately and without blame: what happened, and a lightweight launch-notice step that makes it easy next time. Fix the system, not the person | Launch readiness (F1) and influence (F5) under friction; CASE |
| E3 | "What would you need from my team in your first 90 days, and what would you bring us?" | JD | [generic] | Reciprocity first: what you'd take off their plate or make easier. Then what you'd need: access, context, a regular check-in. Keep the ask small and specific | Peers weigh whether a hire adds to or reduces their load; JD because it scores how you'd work in the role |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then three beats: what you bring that someone from inside may not (an outside view, a specific skill you actually have), how fast you'd ramp, and an honest nod to what an insider knows that you'd have to learn. Stay inside 60 seconds | Composure under a time-box; JD because it scores fit for the role |
| G2 | "In the story you just told, how much of the result was actually you?" | EXP | [generic] | Rehearse precise attribution for every story you plan to use: one sentence on what was yours, one on what was the team's. Hold that line through two follow-ups; if pushed, concede specifically ("the analysis was mine; the decision was my manager's") rather than shrinking or inflating | Attribution probes exist to catch inflation; EXP because it tests what was actually yours |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A rehearsed 90-second arc: where you started, the one or two moves that matter for this role, and why this role is the next step. Every clause should be something you'd happily be asked about | Almost every session opens this way, and it's scored; EXP |
| H2 | "What are you curious about in this space right now?" | CO | [generic] | One genuine thing you've been reading about or using, said specifically, and a question it raises for you. Do your own reading on the company's recent news first, since this pack couldn't | Casual questions on the company's space test real interest (F7); CO |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first six months look like for this role, and what would make you say the hire wasn't working?" | Gives you the scorecard directly and shows you're thinking about outcomes, not tasks |
| R2 | "Where does product ops sit relative to the product teams here: embedded, central, or something in between?" | Shows you understand the seam the role lives on, and the answer tells you how the job really works |
| R3 | "What's the operational problem your team most wishes someone owned right now?" | Invites them to describe the real job; you can then say how you'd approach it |
| R4 | "How do product teams here decide which user feedback changes the roadmap?" | Tests the feedback loop you'd be building (F3) and shows you know it's central |
| R5 | "What's something about how this team works that surprised you when you joined?" | Personal and concrete; works with any interviewer and usually gets a candid answer |
| R6 | If the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: shows you're thinking about their load, not just your onboarding |

---

## Prohibited claims

No entries yet. This list is built from the quotes in the fit snapshot, and every evidence cell is `none given`. Nothing was refused; there was nothing to inflate yet. Once your CV arrives, this section lists the stretched versions of your own lines that the pack won't coach, each with its honest form.

---

## Sources

**Provided documents:** your message ("I have a final-round interview at Stripe for a Product Operations Manager role.").

**Searches sent:**
- "Stripe operating principles": refused
- "Stripe interview process final round onsite operations": refused
- "Stripe Product Operations Manager job description": refused
- "Stripe 2026 news strategy annual letter stablecoins agentic commerce": refused

No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Search refused by this session's permissions. Would have moved: the values cheat sheet (dropped without it) and one VAL question per published value in bank B |
| 2. `Stripe interview process` product operations | unavailable | Search refused. Would have moved: loop structure and persona weights, which currently rest on the big-tech structured archetype |
| 3. `Stripe strategy` / recent news | unavailable | Search refused. Would have moved: CO and CASE questions grounded in current strategy (C2, H2 and bank A are generic without it) |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so no query could be formed; the interviewer read is absent |
| 5. representative Product Operations Manager JD | unavailable | Search refused. Would have moved: fit-snapshot requirements from `[generic]` prose to quoted `[inferred]` lines, and the JD-tagged questions |

---

## Upgrade menu

- **The JD text** → seven `[generic]` fit-snapshot rows become quoted `[grounded]` requirements; JD-tagged questions are rebuilt around its actual lines, and the coverage table checks every one
- **Your CV or a summary of your background** → the fit snapshot turns from a worksheet into your evidence, quoted; guidance becomes story-mapped instead of selection scaffolds; the prohibited-claims list gets built; C1 is rehearsed on your real biggest gap
- **Who you're meeting and in what role (manager, peer, skip-level, cross-functional)** → persona weights read from your actual loop instead of an archetype; per-session mini-packs if your final has several sessions
- **Interviewer names** → a public-footprint read of each, and a reverse question tied to their path
- **The recruiter's prep email** (focus areas, any case, presentation or take-home) → a build section for each graded deliverable
- **Web search allowed in this session** → Stripe's published principles (values cheat sheet plus one VAL question each), its documented interview loop, and current-strategy CO and CASE questions
- **Deeper research pass (L2)** → a strategy brief, role-family loop reports and recent org context; up to 6 more searches and 2 more fetches, several more minutes, run only if you say yes
- **How much prep time you have** → a prioritized prep schedule sized to it
- **A `tuesday-dossier.md`** → the highest-ROI objection taken from verified evidence rather than inferred, and a prohibited-claims guardrail carried over from earlier evaluation; the pack works without one
