# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy, a **peer** (same VP) · **Format:** one 60-minute conversation

---

## How to use this pack

Two axes organize every question:

- **Persona** = *how* the question arrives (who's asking, in what register). Banks are ordered by how likely each persona is with Dan.
- **Type** = *what* is being scored:

| Tag | What it scores |
|---|---|
| **EXP** | Whether claims about past work survive scrutiny, and what was actually hers |
| **JD** | Whether she can do the listed job, gaps included |
| **CO** | Homework on Northwind's strategy, competition and priorities |
| **CASE** | Structure and reasoning on a live problem from the role |
| **VAL** | Behavior that matches stated values |

Question IDs use one letter per persona: A Prober, B Peer, C Case, D Skeptic, E Conversational, G Pressure, H Values. F is kept for fit-snapshot rows (F1–F7).

**Answer slots.** Where the material doesn't say whether Priya did something, the guidance gives two honest branches instead of an answer. She fills them from her own experience, or says plainly the thing wasn't hers or didn't happen. The guidance is scaffolding, not a script: she should rehearse it in her own words.

**Evidence source.** Every quote about Priya's background comes from the notes you sent, cited as "the coach's notes". Before rehearsing, she should check that each quote matches what she would say herself.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy & ops in consumer tech. It doesn't show owning GTM for a product line, and the words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company, and I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's "own GTM strategy" line makes a probe on go-to-market decisions likely. If any launch, pricing or channel decisions were hers to make, she says which and how, in her own words. If none were, she says so plainly and stays with product strategy & ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | low | [grounded] | discovery | The material doesn't show customer-lifecycle or whitespace analysis either way. Answer slot: if she has segmented customers or accounts by lifecycle stage, she says where and how, in her own words. If she hasn't, she says so plainly and shows the method live (C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but it's a self-rating with nothing inspected behind it. Expect "show me". Lead with the skill in its own words, then a real analysis she ran herself (A4) |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says she built a revenue model that was used in negotiations. It doesn't say she designed a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any of her work set partner terms, structures or programs, she says what and which part was hers. If none did, she says so plainly and stays with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other words. Reworded only: "I set annual volume targets and got cross-org consensus on them." Expect a probe on how that consensus was reached (A3) |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The material shows daily use of AI tools, not building or launching AI products, and the words stay there: "I use AI tools daily." Answer slot: which tools she uses and for what, in her own words (E2) |
| F7 | B2B sales-planning mechanics (quota, territory, capacity) that a GTM strategy lead partners on with Sales Strategy | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [generic] | capability | A stated gap that wording can't close. Words: "I haven't done classic sales-ops or quota-setting." Then how she would learn it, said as a plan and never as past experience. Never relabel the volume targets (F5) as quotas |

---

## Reading the interviewer

Built only from what your message says about Dan's profile. A public-profile search was attempted and refused (see Sources), so nothing here is independently verified.

| Signal | Source | Provenance | Implication for Priya |
|---|---|---|---|
| Self-describes as 'relentlessly data-driven' | Your message | [grounded] | Prober weight goes up. Every figure (above all F1's ~$400M) will be pushed to how it was counted. She should name her weakest assumption before he does, and "I don't know how that was counted" is an acceptable answer |
| "career spine is pricing and monetization roles" | Your message | [grounded] | Case questions tilt toward pricing, packaging and unit economics (C1, C2, B4). Shared vocabulary: revenue modelling. F4's quote, "built a partner-level revenue model used in carrier negotiations", is the natural place to meet him, told at its own scope |
| "one early-stage-startup chapter" | Your message | [grounded] | Expect probes on big-company pace and scrappiness. No fit-snapshot row shows a startup chapter for Priya, so this isn't a shared jump to claim. It's a reverse-question opening instead (R2) |
| "he would be Priya's PEER, both reporting to the same VP" | Your message | [grounded] | He's judging whether she adds to his team's load or takes some off it. Frame answers around reciprocity and the seam between the two teams (B1, B2) |

---

## Persona table

| Persona | How it shows up with Dan | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Line-by-line on numbers: inputs, denominators, "how was that counted" | high | Peer prior plus his 'relentlessly data-driven' self-description | Know what she can and can't say about how each number was counted. Name the weakest assumption first. Offer to walk an analysis she did herself end to end |
| Peer Evaluator | Seam between the teams, what she needs from him, disagreement and credit | high | Peer prior and the shared VP | Lead with reciprocity. Propose principles for the seam rather than claiming to know it. Show spine and tact together |
| Case / Strategist | Live pricing, packaging and GTM problems tied to Northwind's priorities | medium | His pricing spine, plus a strategy role with live priorities (Compass, bundling threat) | Clarify, then objective, segments, options, metrics, risks. Think aloud and challenge one premise per case |
| Skeptic | Quiet probing of the quota gap (F7) and the move from consumer to B2B | medium | F7 sits in Dan's own job. The startup chapter adds pace and scrappiness probes | Rehearse D1 until it's boring. Give the plain acknowledgment, then the quote, then a ramp plan |
| Conversational | Friendly opener and a casual AI aside | medium | A single 60-minute conversation usually opens informally, and the casual questions are still scored | A 90-second arc (E1). Treat the AI aside as a scored JD question |
| Pressure | A time-boxed "how much was you" or "why you" | low | Peers rarely stress-interview, but an attribution squeeze is the natural follow-up to the Prober's questions | Pause, restate, hold the verb, and concede specifically |
| Values / Behavioral | One or two "tell me about a time" questions | low | Your message describes one conversation with Dan and no values round. Northwind's values weren't retrievable | Have two stories ready, with "I" for her own contribution |

---

## Question banks

### A — Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Stay in the quote's words: she *proposed* the store-surface change, and it was *credited with* a ~$400M ARR uplift. Keep both verbs. Answer slots, each in her own words: how the figure was counted; what it is sensitive to; the assumption behind it she would defend least, named before Dan names it; and which part was hers. If she doesn't know how it was counted, she says so plainly. "I don't know how finance attributed it" is a complete answer to that slot. She shouldn't offer a baseline or attribution method she couldn't repeat under a second question | Every headline metric gets a defend-the-number question, and F1's figure is the largest number in the material, put in front of a self-described data-driven interviewer. EXP because it tests what the figure actually is |
| A2 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: she built it, it was partner-level, and it was used in carrier negotiations. "Used in" stays "used in", not "I negotiated". Answer slot, raised by the JD's "run independent analysis in SQL and Tableau": what she built it in and how, in her own words. Answer slot, raised by the JD's partner-motion line: if the model shaped how partner terms were structured, she says how and which part was hers. If it didn't, or that wasn't hers, she says so plainly and stays with building the model | F4 is the closest evidence to the only requirement marked "required", so Dan will open it up. EXP because it's a deep-dive into a claimed artifact, with JD relevance noted here |
| A3 | "How did you set those annual volume targets, and how did you get consensus across orgs?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats: annual, volume targets, set by her, with cross-org consensus. Answer slot, raised by the JD's "strong cross-functional influence": if reaching consensus meant working through disagreements, she says what they were and what she did. If it didn't, she says so plainly and describes how the targets were agreed. Answer slot, raised by Dan's 'relentlessly data-driven': the assumption behind the targets she'd defend least, in her own words, or a plain "I'd have to check". They stay *volume targets*, never quotas (see D1) | F5 is the evidence for cross-functional influence and sits right next to the quota gap (F7), so Dan will test where it ends. EXP because he is probing the record |
| A4 | "Tell me about an analysis you ran yourself, end to end, in SQL and Tableau." | EXP | [grounded] "skilled in SQL/Tableau" | The quote states a skill, not an analysis, so this is a selection scaffold. Pick one analysis where she wrote the queries and built the view herself. It needs the question she was answering, what the data showed, and what someone decided because of it. If no such analysis comes to mind, she says so plainly, then gives the nearest thing her material does carry. Offer to walk through the query logic if he wants more depth | F3 is a self-rating with nothing inspected, and the JD's "independent analysis" line plus Dan's data focus make a "show me" near certain. EXP first because it tests the claim, JD second |
| A5 | "Tell me about a time your analysis said one thing and a senior stakeholder wanted another." | EXP | [generic] | Selection scaffold. Pick a time with a named stake, what the data showed, what she said and to whom, and how it ended, including whether the relationship held. Use "we" for context and "I" for her own part. If no such time comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she would handle it | The theme comes from Dan's own self-description. It scores whether data or politics won and how she handled the person. EXP because it is about past behavior, and `[generic]` because no quote carries such a story |

### B — Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We'd sit side by side under the same VP. Where's the seam between my team and yours, and what happens when we disagree?" | CASE | [grounded] | Don't claim to know the seam; propose principles: "I'd expect Sales Strategy to own the core motion, coverage and quota mechanics, and Emerging Products GTM to own the new lines' strategy and how they plug into that motion. Shared metrics where they overlap. When we disagree, we look at the data together before anything goes to the VP, and we align in public." Then ask him where he sees the seam today. The question needs no claim about her past, so the guidance makes none | The peer prior plus the shared-VP structure from your message make this close to certain. It scores turf awareness. CASE because it's a live organizational problem |
| B2 | "What would you need from my team, and what would you take off our plate?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with reciprocity. She runs her own analysis, in the quote's words: skilled in SQL and Tableau. So she'd pull her own data rather than queue requests for his analysts. What she needs: his team's view of coverage, pipeline and pricing guardrails. What she offers: sharing whitespace findings for the new lines with his team first | Peers weigh what a hire adds to or removes from their own load. JD because "independent analysis" is the JD line being tested |
| B3 | "Tell me about a time you disagreed with someone at your level in another org. How did it resolve?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The targets are the nearest story the material carries, but the quote says consensus, not disagreement. Answer slot, raised by the JD's "strong cross-functional influence": if there was a disagreement with a peer over the targets, she tells it in her own words: what each side wanted, what she did, and how it ended. If there wasn't, she says so plainly and picks another time she and a peer disagreed. If none comes to mind, she says so and describes how she'd handle one with Dan | F5 is the closest evidence, and disagreement style between peers is exactly what this persona scores. EXP because it's about the record |
| B4 | "New product lines aren't on my sellers' quotas yet. How do you get their attention?" | CASE | [grounded] "No classic sales-ops or quota-setting experience." | Open by giving him the expertise: "I haven't done classic sales-ops or quota-setting, so I'd want your read on this." Then structure the options: which segment the lines attach to (enterprise expansion, per your research note); what makes it worth a seller's time (attach to existing deals, quota credit versus spiffs, as options to weigh rather than claims); enablement; partners as a second channel; the metric to watch (attach rate). Close by asking which lever has worked at Northwind | F7's gap meets the seam in Dan's own territory. CASE because it's a live problem, and it scores whether she adds to or reduces his load |

### C — Case / Strategist (weight: medium, tilted to pricing)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. Do we bundle it into existing plans, sell it as an add-on, or price on usage? How do you decide?" | CO | [grounded] | Clarify first: who Compass is for, and what it costs Northwind to serve per use. Name the tension in the stated priorities out loud: enterprise expansion and the AI launch favor reach, while profitability favors margin. Options: bundling defends against the larger vendor's bundling but gives up direct revenue; an add-on monetizes cleanly but slows adoption; usage pricing ties price to cost but makes bills harder for enterprise buyers to predict. Recommend one with a test, for example a usage allowance inside enterprise tiers with a charge above it, tracking adoption and gross margin per account. Then name the weakest assumption in her own recommendation. No claim about her past | Dan's pricing and monetization background, plus two of the three priorities in your research note, make this his native question. CO first because it rests on the research note, CASE delivery |
| C2 | "A much larger platform vendor bundles a good-enough version of one of our new products for free. What's your GTM response?" | CASE | [grounded] | Don't race to cut price. Segment where "good enough" wins and where it doesn't. Offer hypotheses to test about where Northwind competes (depth, neutrality across platforms, integration), and name a segment she'd concede. Separate the response for new logos (land) from the installed base (expand and renew). Leading indicators: win/loss against the bundled offer, and churn at renewal | Your research note names bundling as the main competitive threat. It scores structure and willingness to say no. CASE first, CO second |
| C3 | "First 90 days: how do you find whitespace for a new product line across land, adopt, expand and renew? What data do you pull first?" | JD | [grounded] | Structure by stage. Land: accounts that fit but don't buy. Adopt: usage depth among buyers. Expand: accounts using adjacent products but not the new line. Renew: risk signals. Data: installed base, product telemetry, CRM opportunities, support tickets. Say what she'd query herself in SQL and which Tableau view she'd hand Dan's team, then how she'd check the findings with sellers. Answer slot: if she has segmented a customer base this way before, she says where, in her own words. If not, she says so plainly, and the case is where she shows the method | F2 is a discovery gap on a headline JD line, and a live case lets her show the method without claiming a past. JD first, CASE delivery |
| C4 | "Design a partner motion for one of the new lines. Who are the partners, what's in it for them, and how do you know it's working?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure: partner types as options (resellers, systems integrators, cloud marketplaces, technology integrations); the job each does in land versus expand; partner economics (margin, referral fee, co-sell credit); channel conflict with direct sellers, which is Dan's seam, so name it; metrics (partner-sourced pipeline, attach rate). She may cite the model in the quote's words, a partner-level revenue model used in carrier negotiations, as the reason she'd start with partner economics. She never calls it designing a partner motion | This is the only requirement marked "required", and F4 is transferability. A live design lets her show the skill without stretching her record. JD first, CASE delivery |

### D — Skeptic (weight: medium; holds the highest-ROI question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't set quotas or run sales ops. Why should my sellers trust land-and-expand strategy from someone who hasn't?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in this pack.** Concede first, plainly: "I haven't done classic sales-ops or quota-setting." Then hold on what she did, in the quote's words: she set annual volume targets with cross-org consensus. Never call them quotas. Then the ramp, said as a plan and never as past experience: learn Northwind's coverage and quota model from his team in the first weeks, and build the new lines' plans to fit it. Close with reciprocity: that's why the seam with his team matters. **Likely follow-up 1:** "Volume targets aren't quotas." Agree, because that was her first sentence, and come back to the targets as consensus work across orgs without adding to them. **Likely follow-up 2:** "So what will you get wrong first?" She names it herself, in her own words. The honest area is the quota and capacity mechanics she hasn't run. Hold through both follow-ups, and fold only on what she conceded at the start | F7 is a stated gap sitting in the interviewer's own job, and the JD's land/adopt/expand/renew line (F2) makes it unavoidable. JD because it scores the sales-facing core of the role. Candor beats bluffing, because Dan owns this competency personally |
| D2 | "Why leave consumer tech for B2B data infrastructure, and why now?" | EXP | [generic] | Her real reasons, in her own words. Your notes give none and the pack supplies none. Shape: one sentence on why move, one on why Northwind, one on why this role, with the last tied to a JD line (two new product lines, partner motion, AI) and a priority from your research note. Forward-looking, with no criticism of her current employer | The motivation probe a Skeptic always runs, aimed at the visible jump in F1. EXP because the reason for leaving is about her |
| D3 | "I don't see partner-program design or B2B selling in your background. How would you handle the partner motion here?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Don't argue with the observation. Answer with what the material carries: she built a partner-level revenue model used in carrier negotiations. Answer slot, raised by the JD's partner-motion line: if any of her work designed partner terms or programs, or sold to business customers, she says what and which part was hers. If none did, she says so plainly and stays with the model. Then the plan: how she'd learn Northwind's partner landscape, using C4's structure | F4 is transferability on the requirement marked "required". JD because it scores that line |

### E — Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "proposed a store-surface change credited with a ~$400M ARR uplift" | 90 seconds. Beat 1: two years in strategy consulting at a top firm. Beat 2: nine years in product strategy & ops at a large consumer-tech company. Beat 3: two proof points, each in its own words: she built the partner-level revenue model used in carrier negotiations, and she proposed the store-surface change credited with a ~$400M ARR uplift. Beat 4: why this role, in her own words, tied to one JD line. Then stop and let Dan pick the thread | Rapport openers are scored on economy. This arc deliberately sets up A1 and A2, which she has rehearsed. EXP because it's the record |
| E2 | "What are you actually doing with AI tools these days?" | JD | [grounded] "uses AI tools daily" | Raised by the JD's "AI experience a plus". Answer slot: which tools she actually uses and for what, in her own words. If any of it feeds her analysis or strategy work, she says how. If not, she says so plainly. Then turn to curiosity about Compass from a buyer's point of view, asked as a question rather than offered as a claim. She never stretches daily tool use into building or launching AI products | F6, asked in a casual register but scored, on a JD plus and a stated company priority. JD |

### G — Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds. That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then hold on her verb: she proposed the change, and it was credited with the uplift. Answer slot: which part of making it happen was hers beyond proposing it, in her own words. If nothing beyond the proposal, she says so plainly, because proposing it is the claim. Hold through two follow-ups by returning to "proposed". If pressed, concede specifically who else made it happen, but don't fold into "it was a team thing" either | Attribution squeeze on F1's headline figure. Unlike A1 (how it was counted), this scores composure and credit. EXP |
| G2 | "Ninety seconds: why you over someone from my own team?" | JD | [grounded] "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Don't run down internal candidates. Hold on what she brings, in the quotes' words: her own analysis in SQL and Tableau, and the partner-level revenue model. Concede the obvious, consistent with D1: they know Northwind's sales motion better on day one. Close on what an outside view adds to two new product lines, in her own words | A pressure stem that comes naturally from a peer who owns sales strategy. JD because it scores fit to the role |

### H — Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, the truth she delivered and to whom, the moment it could have gone wrong, and a hard truth that actually landed. "We" for context, "I" for her own part. If no such time comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she would handle it | Northwind's values weren't retrievable, so this is a role-family stem rather than a mapped value. It's still plausible in a 60-minute peer conversation. VAL |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time with the metric at stake, the customer reason, what she decided or argued for, and what it cost. If no such time comes to mind, she says so plainly and describes how she would weigh it | Same basis as H1. It also speaks to a data-driven interviewer: a deliberate exception to the metric, with reasons. VAL |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (F1) | C1, C2, D2, E1 |
| "identify whitespace across land/adopt/expand/renew" (F2) | C3, D1 |
| "run independent analysis in SQL and Tableau" (F3) | A4, B2, A2 |
| "partner-motion design experience required" (F4) | C4, D3, A2 |
| "strong cross-functional influence" (F5) | A3, B3, B1 |
| "AI experience a plus" (F6) | E2, C1 |
| Sales-planning mechanics, generic (F7) | D1, B4, G2 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "With your pricing and monetization background, how do you think pricing decisions for new lines like Compass should get made here, and who should own them?" | Tied to his career spine. It opens his native topic and the seam at the same time |
| R2 | "You've worked at an early-stage startup. What from that chapter shows up in how you run sales strategy at a company this size?" | Tied to his path. It turns a likely pace probe into a peer conversation |
| R3 | "What could someone in my seat do in the first month that would genuinely help your team?" | The reciprocity question. It signals she's thinking about his load, not just her own scope |
| R4 | "Where do enterprise expansion and the push to profitability pull against each other in your team's planning?" | Built on your research note. It shows she has absorbed the priorities and sees the tension between them |
| R5 | "When the bundling pressure shows up in a deal, what does it look like from your sellers' side?" | Uses the competitive threat from your research note and asks for evidence from the field, which a data-driven peer respects |
| R6 | "How does our VP expect your team and Emerging Products GTM to split land/adopt/expand/renew planning?" | Makes the seam explicit without assuming it, and shows she read the JD closely |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product or launch | Inflated form of F1 | F1's quotes at their own scope. The pack's observation: the material shows product strategy & ops, not owning GTM. D2 and C-bank answers stay at that scope |
| Drove, delivered or generated the ~$400M ARR uplift | Inflated form of F1 | F1's quote: she "proposed" the change, and it was "credited with" the uplift. A1 and G1 hold that verb |
| Negotiated the carrier deals | Inflated form of F4 | F4's quote: the model was "used in carrier negotiations". A2's slot stays with the model |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material shows a revenue model, not a partner-motion design. D3's slot stays inside the model |
| Has set quotas or run sales ops | Negative stated in the coach's notes, F7 | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting." Volume targets are never relabelled as quotas |
| Led cross-functional influence or negotiation beyond the targets | Inflated form of F5 | F5's quote: she "set annual volume targets with cross-org consensus". A3 and B3 slots stay inside the targets |
| Built, shipped or launched AI products | Inflated form of F6 | F6's quote: she "uses AI tools daily". E2's slot names only the tools she uses |

---

## Sources

**Provided:** your message, containing the JD highlights, the candidate notes, the notes on Dan, and your research note on Northwind's three priorities and the bundling threat.

**Searches sent (all refused, because web search permission wasn't granted in this session):**
- "Northwind Data company values": refused
- "Northwind Data interview process GTM strategy": refused
- "Northwind Data Compass AI copilot launch": refused
- "Dan Kovac Northwind Data Director of Sales Strategy": refused

**Fetches:** none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The search was refused. It would have themed H1 and H2 on Northwind's own value names. Without them, the values bank stays `[generic]` |
| 2. Northwind Data interview process, GTM / strategy | unavailable | The search was refused. Your message already establishes this session (one 60-minute conversation with Dan), so it would only have shown whether a values round exists elsewhere in the loop |
| 3. Northwind Data strategy / recent news | unavailable | The one call checked your research note (Compass) and was refused. The note still supplies C1, C2, B4, R4 and R5. The search would have confirmed the note is current |
| 4. Dan Kovac, Northwind Data | unavailable | The search was refused. It would have verified the profile notes in the interviewer section and added any talks or posts as question themes |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Web search permission** → targets 1–4 rerun: Northwind's published values become a mapped values section, Dan's profile is verified, and the research note is checked for currency.
- **Deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Northwind's segmentation, numbers and recent moves, plus a sharper bundling-competitor case for C2.
- **Full JD text** → mid-list requirements surface and get their own questions, and the F1–F6 requirement quotes come from the posting itself instead of highlights.
- **Priya's CV or her own words** → evidence cells quote her rather than the coach's notes, and phrasing in E1, A1 and A2 matches how she actually describes the work.
- **One inspectable artifact** (a sanitized version of the revenue model or business case, or a performance review naming her role in the store-surface change) → F1 and F4 move from `medium` to `high` confidence.
- **Her answers to the answer slots** (how the ~$400M was counted, any lifecycle or whitespace analysis, any B2B or partner-terms work) → F2, A1, A2, D3 and G1 become story-mapped instead of slotted.
- **Recruiter guidance** (focus areas, or whether Dan will set a case or ask for a POV) → a graded-deliverable build section.
- **Prep time available** → a prioritized prep schedule sized to it.
- **A `tuesday-dossier.md`** → verified evidence and an evidence-derived prohibited-claims list would replace the locally built ones.
