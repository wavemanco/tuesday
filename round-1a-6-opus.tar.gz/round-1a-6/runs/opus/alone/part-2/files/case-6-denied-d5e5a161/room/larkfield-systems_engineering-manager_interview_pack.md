# Interview prep pack — Engineering Manager, Larkfield Systems

**Candidate:** Yusuf · **Mode:** loop (three scheduled rounds)

| Round | When | Who | Length |
|---|---|---|---|
| 1 | Tuesday | Hiring manager — Director of Engineering, your would-be boss | 45 min |
| 2 | The Thursday after | Panel — two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering — "values and leadership philosophy" | 30 min |

Built from your message alone. Web research was attempted and refused by this session's permissions, so nothing here about Larkfield itself comes from a source: company-specific questions are labelled `[generic]` and the values cheat sheet is absent (see Sources and the upgrade menu).

---

## How to use this pack

- **Personas** describe *how* a question arrives (the style of the person asking). **Types** describe *what is being scored*.
- **Type key:**
  - **VAL** — behaviour and values: does your past behaviour show what they say they value
  - **EXP** — experience deep-dive: do your own claims survive scrutiny, and what was actually you
  - **JD** — role-driven: can you do the listed job, gaps included
  - **CO** — company and strategy: can you think at the company's altitude
  - **CASE** — live problem from the role, solved out loud
- **Provenance** on every row: `[grounded]` traces to what you told me, `[inferred]` is this pack's derivation (named), `[generic]` is a role-family pattern with no claim about you or Larkfield.
- **Answer slots** are instructions for the interview, not questions for you now. Each has two honest branches; either one is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep in the whole loop: A1** (Round 1). The same objection comes back as M1 on Monday.

---

## Shared fit snapshot

Requirements are quoted from the role text in your message; no fuller JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message, "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads of eleven, and the words stay there: "For three years I've been a team lead of six." If asked about managing managers, your own words: "I've never managed managers." Answer slot: "two squads" makes a probe on leading across more than one team likely. If you have led work that spanned more than one team, say what it was and which part was yours; if not, say so plainly and stay with the team of six. The role text does not say whether the squads have their own leads; that is a Round 1 reverse question, not an assumption |
| F2 | "own delivery" — role text, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | One quarter pushed through is a delivery decision, not the whole of owning delivery, and the bridge should not stretch. Words at the quote's scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: "own delivery" makes a probe on how your team plans and tracks its commitments likely. If that was yours, say how you ran it, in your own words; if it sat with someone else, or there was no such process, say so plainly and describe the part you did own |
| F3 | "hiring ... for 11 engineers" — role text, your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in kind, but a self-report with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles. The figure counts interviews, not hires, and stays attached to interviews. Answer slot: "own ... hiring" makes a probe on who decides hire or no-hire likely. If the decision was yours, say how you make it; if it sits with someone else, say so plainly and describe what running the loop involves |
| F4 | "growth for 11 engineers" — role text, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Leading six people touches growth without showing it; your material is silent here, which is not the same as absent. Answer slot: if you have run development conversations, promotion cases or growth plans for anyone on your team, say which and how, in your own words; if not, say so plainly and say what you would do first with eleven |
| F5 | "partner with ... product on roadmap" — role text, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote shows one roadmap negotiation, not an ongoing roadmap partnership. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if a product manager was part of agreeing that quarter, say how that conversation went and which part of it was yours; if the pressure came from elsewhere, or no product partner was involved, say so plainly and tell it as it happened |
| F6 | "partner with hardware ... on roadmap" — role text, your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap you have stated, and wording cannot close it. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "device-management services" in "industrial IoT" — role text, your message | none given | none | [grounded] | discovery | Your material says nothing either way about devices or device fleets. Answer slot: if any of your work has touched physical devices or software running on them, say what and which part was yours; if none has, say so plainly and say what you would learn first |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| F1 Lead two squads | A1, A2, B1, E1, E2, M1 |
| F2 Own delivery | B2, B3, G1, L2 |
| F3 Hiring | D2, H2, K4 |
| F4 Growth | C2, L2 |
| F5 Partner with product | B3, E3, H1 |
| F6 Partner with hardware | A3, B2, E4 |
| F7 Device-management domain | A4, G3, J1, L1 |

---

## Prohibited claims

Built from the snapshot before any bank was written. No cell in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | "I've never managed managers." |
| Has owned or shaped a hardware-adjacent roadmap | Negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." No slot |
| Has led two teams, or more than six people | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team of six. A1's slot stays inside work you led |
| The reliability quarter caused the 60% drop | Inflated form of F2 and F5: the quote says "after", not "because" | The quote at its own scope: the burden "dropped 60% after" the quarter. How much was the quarter, and how it was counted, are D1 and M2's slots, in your words |
| Owned the team's roadmap | Inflated form of F5 | F5's quote at its own scope: one reliability quarter pushed through |
| Made the hiring decisions, or hired around 40 people | Inflated form of F3: 40 counts interviews | F3's quote at its own scope. D2's slot asks who decides |
| Owned delivery end to end | Inflated form of F2 | F2's quote at its own scope. F2's slot asks how planning worked |

---

# Round 1 — Hiring manager (Tuesday, 45 min)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the jump: six to eleven, one team to two, payments to devices, no hardware roadmap | High. Hiring-manager prior is Case plus Skeptic; F1 and F6 are the largest gaps, and your would-be boss is the person who has to defend the hire upward | Name the limit before it is asked for, in your own stated words, then a concrete ramp plan said as a plan |
| Case / Strategist | Live problems from the role: first 90 days, a hardware slip, reliability versus roadmap | High. Hiring-manager prior; they are buying how you would run their actual org | Clarify, objective, options, decision, risks; challenge one premise per case |
| Conversational | "Walk me through your journey" opener | Medium-low. Most hiring-manager rounds open this way, and it is still scored | One rehearsed 90-second arc from your own quotes |
| Data-Driven Prober | Picks at the 60% and the 40 interviews | Low-medium. Your two numbers are magnets for any interviewer | Know what you can and cannot say about how each was counted |

## Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led one team of six. This is two squads and eleven engineers, working right up against hardware. What makes you ready for that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | **The highest-ROI rehearsal in this pack.** Open with what the quotes carry: three years leading a team of six; you run the backend hiring loop; you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Then name the limit before they do, in your words: "I've never managed managers, and I've never owned a hardware-adjacent roadmap." Then the plan, said as intent: what you would learn first and from whom. Follow-up 1, "So why not wait until you have?": hold by returning to the team of six and the reliability quarter; add nothing to them. Follow-up 2, "What will you get wrong first?": concede one of the two stated gaps specifically, and how you would find out early. Answer slot: "two squads" makes a probe on leading across teams likely. If you have led work spanning more than one team, say what and which part was yours; if not, say so plainly and stay with the team of six | F1 and F6 together are the single most predictable objection, and a Director hiring a first-time manager at this size has to ask it; JD because it scores the stated scope. Deepest rehearsal means the exact concession wording, never more content than the quotes hold |
| A2 | "Have you managed managers or tech leads before?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Answer the first half plainly: "I've never managed managers." Answer slot for tech leads: if anyone on your team led a piece of work and you coached them through it, say who and how, in your own words; if not, say so plainly. Then turn it into a question for them: whether the two squads have leads today (Round 1 reverse question 1) | F1: eleven engineers across two squads may or may not include leads, and the Director knows which; JD because it probes the structure the role implies |
| A3 | "Device management sits right against hardware. What do you know about working with hardware teams?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Lead with the stated limit: "I've never owned a hardware-adjacent roadmap." Answer slot: if any of your work has involved a hardware team or physical devices, say what and which part was yours; if none has, say so plainly. Then the plan, as a plan: the first things you would want to learn from the hardware lead, such as how their release cadence couples to the services, and what failure looks like in the field. Calibrated candour beats bluffing a competency this interviewer may personally own | F6 is a stated capability gap on a named responsibility; asking it plainly is cheap for them. JD because "partner with hardware" is in the role text |
| A4 | "Why leave payments for industrial IoT, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: give your actual reasons, in your own words. If the step up in scope is part of it, say so; if something about devices or industrial work draws you, say what, specifically; if neither, say what does. Don't claim a long-standing interest in IoT that you do not have. Keep "why now" separate from anything negative about your current employer | F7 is silence on the domain, and the Skeptic's motivation probe always arrives; EXP because it tests whether your story is consistent |

## Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads on day one. What do you do in your first 90 days?" | CASE | [generic] | Clarify first: do the squads have leads, what is on fire, what has already been promised to hardware and product. Then structure: listen (one-to-ones with all eleven, the hardware and product partners), learn the system (services, on-call, incident history), pick one delivery risk to fix visibly, and commit to one change by day 60 to 90 with a measure you would watch. Say what you would *not* change in the first month. No claim about your past is needed | F1: the Director wants to see how you would run their org, not your current one; CASE because it is live and role-specific |
| B2 | "Hardware tells you a firmware release slips six weeks. Your squad's feature depends on it, and product has already promised it to a customer. What do you do?" | CASE | [generic] | Clarify: what exactly depends on the firmware, whether the services side can ship behind a version check, who made the promise and what was promised. Options: decouple and ship partially; hold and reset expectations; re-sequence the squad onto other work. Decide, say who you would tell and in what order, and how you would stop the same coupling surprising you next time. Challenge one premise, for example whether the promise was a date or an outcome | F2 and F6: delivery across a hardware dependency is the specific shape of this role; CASE because it scores structure, and it lets you show hardware judgement without claiming hardware history |
| B3 | "Product wants the roadmap, and on-call is wearing people down. How do you decide how much capacity goes to reliability?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give the decision structure first: what evidence of burden you would gather, what the incidents cost, a time-boxed commitment, the measure you would watch. Then the one story, at its own scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Keep "after"; let them ask how much was the quarter. Answer slot: if you made the case with data or with specific people, say what and with whom, in your own words; if it was simpler than that, say so plainly | F2 and F5: this is your strongest quote and it maps directly to a live trade-off; CASE first, EXP second, because the structure is scored before the story |

## Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with three beats, each one a quote: nine years in engineering, the last three as a team lead of six, at a payments company; you run the backend hiring loop, about 40 interviews last year; you pushed a reliability quarter through against roadmap pressure and on-call burden dropped 60% after. Close on why this role, with A4's answer. Rehearse it to time | Opener in almost every hiring-manager round, and the arc you set here frames the rest; EXP because every beat can be followed up |
| C2 | "How do you think about growing the people on your team?" | JD | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: if you have worked on someone's growth on your team of six — a development conversation, a stretch assignment, a promotion case — pick one and say what you did and what happened, in your own words; if not, say so plainly and say how you would approach it with eleven. Principles are fine, but one real instance beats three principles | F4 is silent in your material and the role text names growth explicitly; JD because it scores a listed responsibility |

## Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, all in your own words. How it was counted: say what was measured and over what period; if you do not know exactly, say so. What it is sensitive to: say what else changed in that period, if anything. The assumption you would defend least: name it before they do. Which part was yours: say what you did and what the team did. Keep "after" rather than "because" unless you can say why | Every headline number gets a defend-the-number question, and this is your only performance figure; EXP because it tests attribution |
| D2 | "You run the backend hiring loop. What does running it involve, and how do you know it picks well?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Describe what running the loop means, in the quote's terms. The figure is about 40 interviews last year, which counts interviews, not hires. Answer slot: if you decide hire or no-hire, say how; if someone else decides, say so plainly. If you have any way of telling whether hires worked out, say what it is; if you don't, say so and say what you would track | F3: hiring is a named responsibility and your only direct quote on it; EXP because the Director will check what "run" means |

## Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Do the two squads have their own tech leads or managers today, or would all eleven report to me directly?" | Settles whether F1's managing-managers question is live, and shows you are thinking about structure before style |
| 2 | "Twelve months in, what would make you say this hire worked?" | Gets the real success criteria from the person who sets them |
| 3 | "How does the roadmap get made between hardware, product and these squads today, and where does it go wrong?" | Turns F6 into a learning question rather than a defence |
| 4 | "What does on-call and incident load look like for device-management services right now?" | Lets you connect to your reliability story without asserting anything about their system |
| 5 | "How many of the eleven are in seat, and how many are still to hire?" | Hiring is in the role text; tells you how much of year one is hiring |
| 6 | "How do you support managers stepping up in scope?" | Asks for the support you will need without framing it as a weakness |

---

# Round 2 — Panel: two staff engineers and a PM (the Thursday after, 60 min)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Staff engineers: where your call ends and theirs begins. PM: how roadmap disagreements get settled | High. Peer prior is Peer Evaluator plus Prober; the panel blend puts it top because all three will work beside you | Reciprocity: what you bring them, not only what you need. Propose seam principles rather than pretending to know their seams |
| Data-Driven Prober | Staff engineers go two levels down on the reliability quarter and on incidents | Medium-high. Peer prior; staff engineers will test whether you understand the technical substance of your own story | Know your assumptions; say plainly when you do not know |
| Values / Behavioral | PM: "tell me about a time you disagreed with product" | Medium. A cross-functional interviewer's prior is Values/Behavioral plus Conversational | Story where one of your quotes carries it; honest branch where none does |
| Conversational | Warm-up and "how hands-on would you be" | Medium-low. Panels open friendly; the hands-on question is scored by staff engineers | Short, honest, specific |

## Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where do you draw the line between your call and ours on technical decisions?" | JD | [generic] | Propose principles: technical direction sits with the people closest to the code; you own the trade-offs against delivery, people and partners; disagreements surface early and get decided, not left to drift. Answer slot: if you have had a technical disagreement with a senior engineer as a lead, tell it, with what you did and how it ended; if none comes to mind, say so plainly and stay with the principles | F1: staff engineers are pricing whether you add to or reduce their load; JD because leading the squads includes this seam |
| E2 | "What would you need from staff engineers, and what would you take off our plates?" | JD | [generic] | Lead with what you would take: people, hiring, cross-team negotiation, shielding focus time. Then what you would need: honest reads of technical risk early, and help growing others. Ask them what they would want, which turns it into a conversation | F1: reciprocity is the Peer Evaluator's scoring axis; JD because it is the working contract of the role |
| E3 | "When product wants features and you want reliability, how do we settle it?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Principle first: make the cost visible, agree a time box, agree what will be measured, revisit together. Then the story at its scope: "I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after." Answer slot: if a product manager was part of agreeing it, say how that went and what you gave up; if not, say so plainly. The PM wants to hear that you would not do it *to* them | F5: the PM's central question about any EM; JD because "partner with product on roadmap" is in the role text |
| E4 | "Hardware, product and your squads all touch the roadmap. How would you learn where the seams are?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say it plainly once: "I've never owned a hardware-adjacent roadmap." Then the plan as a plan: who you would sit with first, which past slips or incidents you would read, and what you would ask the PM to show you. Ask the panel where the seam hurts most today (Round 2 reverse question 2) | F6 returns in collegial packaging; JD because it scores a listed partnership |

## Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What was driving the on-call burden before the reliability quarter, and what did the quarter actually change?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: say what was driving the burden and what work went into the quarter, in your own words and at the level of detail you actually know; if some of it was the team's work rather than your direction, say which. If you don't know a figure, say so. Staff engineers will follow up twice: have one technical detail you can go deep on | F2 and the 60% figure: engineers test whether a manager understands the substance; EXP because it is a deep-dive on your own story |
| G2 | "Of that 60%, how much would have happened anyway?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The weakest-assumption move: say, in your own words, what else might have moved the number in that period, before they do. If you don't know, say so plainly. Hold the core: the quarter happened and the burden dropped after it. Concede what you can't attribute | Every quantified claim gets its assumption probed; EXP because it scores attribution honesty |
| G3 | "Say a bad update goes out to devices in the field and a chunk of them go offline. How does your team respond, and what changes afterwards?" | CASE | [generic] | Structure: stop the rollout, size the blast radius, recover, communicate (hardware, support, product, customers), run a blameless review, then prevention such as staged rollouts and a quick way to halt. Answer slot: if you have worked on anything running on devices, say what; if not, say plainly that your incident instincts come from services work and say what you would expect to be different with devices | F7: a live problem in the role's domain, where engineers can see your judgement without you claiming device history; CASE because it scores reasoning |

## Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you disagreed with a product manager on priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | If the roadmap pressure on your reliability quarter came from a product manager, that is your story, at its scope: you pushed the quarter through; the burden dropped after. Answer slot: say how the disagreement went and how the relationship was afterwards, in your own words; if the pressure came from someone else, or there was no PM involved, pick another time you disagreed with a PM, and if none comes to mind, say so plainly and say how you would handle one | F5: the role text names product as a partner, and the PM will want a real disagreement story; VAL because it scores behaviour |
| H2 | "Tell me about a time a hire you made or recommended didn't work out." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold: pick a case from the loop you run where someone you recommended, or turned down, turned out differently than you expected — it needs what you saw at the time, what happened, and what you changed. If no such case comes to mind, say so plainly, and say how you would notice one | F3: hiring is a named responsibility and panels test whether you learn from misses; EXP because it probes what running the loop actually involved |

## Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What drew you to device management?" | JD | [generic] | Answer slot: your real reason, in your own words, consistent with A4 on Tuesday. If something specific about devices interests you, say what; if it is more about the role than the domain, say that honestly | F7: casual openers on the domain are still scored; JD because the domain is the role |
| J2 | "How hands-on would you be with the code?" | JD | [generic] | Say what you actually intend: how much code, if any, and where you would draw the line so you are not on the critical path. Staff engineers mainly want to hear that you won't be a bottleneck or a surprise reviewer | F1: the staff engineers' quiet question; JD because it defines how you would lead the squads |

## Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question; tells them you are pricing your value to them |
| 2 | "Where does the seam between hardware and these services cause the most friction today?" | Turns F6 into a learning conversation with the people who live in it |
| 3 | (PM) "How do you and the squads decide between roadmap features and platform or reliability work now?" | Opens the E3 conversation from their side |
| 4 | (Staff) "What's one kind of decision you'd want an EM to leave to you?" | Shows you mean the seam principles from E1 |
| 5 | "If this role has had someone in it before, what worked that you'd want kept?" | Signals you won't arrive and change everything |

---

# Round 3 — VP Engineering, "values and leadership philosophy" (the following Monday, 30 min)

This round is the loop's values-style round: the recruiter's own description, as you relayed it, documents one. Larkfield's published values could not be fetched, so there is no values cheat sheet; paste them and this round gets one.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "What's your leadership philosophy", "tell me about a time" | High. The recruiter named the round as values and leadership philosophy | Two or three principles, each backed by a story from your own quotes; honest branch where none fits |
| Pressure | Time-boxed "why you", "how much was actually you" | Medium. Skip-level prior is Case plus Pressure; 30 minutes compresses everything | Pause, restate, hold through two follow-ups, then concede what is real |
| Case / Strategist | Altitude: where device management is going, how you'd measure your org | Medium-low. Skip-level prior, but the round's stated focus is values | Ask-back first, structure second, no invented company facts |

The Conversational persona was rehearsed in Round 1 (C1); reuse that arc if the VP opens with it.

## Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What's your leadership philosophy, in a couple of minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold: pick two or three principles you actually hold and can back with something you did. Where one of your quotes carries a principle, use it at its scope: if you believe the team's health is the manager's job, the reliability quarter you pushed through is the story; if you believe hiring is where a team is made, running the backend hiring loop is. A principle with no story behind it, say as a belief, not a record. Stop at two minutes | The recruiter named leadership philosophy as the round's subject; VAL because it scores whether your principles show in your behaviour |
| K2 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | If the roadmap pressure you pushed against came from someone senior, that is the story, at its scope: you pushed the quarter through; the burden dropped after. Answer slot: say who the pressure came from, what you did when it pushed back, and how the relationship was afterwards, in your own words; if it wasn't someone senior, pick another time, and if none comes to mind, say so plainly and say how you would handle it | F5: your strongest quote is a held-position story, and values rounds ask for exactly this; VAL because it scores behaviour under pressure |
| K3 | "Tell me about a time you got something wrong as a lead." | VAL | [generic] | Selection scaffold: pick a real mistake from your three years as a lead — it needs what you decided, what went wrong, what you owned out loud, and what you changed. Not a disguised strength. If none comes to mind, say so plainly, and talk about the nearest thing: a call you would make differently now | F1: a first-time leader at this scale will be asked whether they learn; VAL because the VP scores self-awareness |
| K4 | "How do you decide who to hire, and what do you do when the loop disagrees?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Describe how the loop you run works, in its own terms. Answer slot: if disagreements in the loop come to you to resolve, say how you handle them; if someone else resolves them, say so plainly and say how you would. Tie it to a principle from K1 if one fits | F3: hiring is half of what makes a manager's philosophy visible; VAL first, JD second |

## Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "What do you think matters most for a device-management platform at a company like ours over the next couple of years?" | CO | [generic] | You don't have researched facts about Larkfield's strategy, so don't invent any. Ask back first: what they see as the biggest constraint. Then reason from the role text: services that manage devices in industrial settings, with hardware as a partner. Structure your view around a few general pressures any such platform faces, such as fleet growth, safe updates, security, and uptime for customers, and say which you'd want to understand first | F7: skip-level rounds test altitude; CO because it scores strategic thinking, and `[generic]` because research did not run |
| L2 | "How would you measure whether your two squads are doing well?" | CASE | [generic] | Three lenses: delivery (commitments met, predictability), system health (incidents, on-call load), people (retention, growth, hiring). Say how you'd avoid gaming any one of them, and that you'd agree the measures with your Director | F2 and F4: a VP wants to see a manager who measures outcomes and people together; CASE because it is live |

## Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Sixty seconds: why you, over an internal candidate who already knows our devices?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, then three beats from your quotes: three years leading a team of six; you run the backend hiring loop; you pushed a reliability quarter through against roadmap pressure, and the burden dropped after. Concede plainly: "I've never owned a hardware-adjacent roadmap", so an internal candidate knows the devices better. Hold on what you'd bring. Under follow-up, don't add to the beats | A1's objection, compressed and time-boxed; JD because it scores fit to the role |
| M2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold then concede. Hold: pushing the quarter through against roadmap pressure was yours; the quote says so. Concede: the work during the quarter was the team's, to whatever extent it was, and the drop came after the quarter, which is not the same as all of it coming from it. Answer slot: say which part was yours, in your own words | The Pressure persona's signature stem; EXP because it scores attribution under stress |

## Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do the managers who do well here have in common?" | Lets the VP tell you their values in their own words |
| 2 | "How do you want managers to bring you bad news?" | A leadership-philosophy question back at them |
| 3 | "As you see it, where does engineering need to be in two years for the device business?" | Shows altitude without claiming facts about their strategy |
| 4 | "Which of your values is hardest to live in practice?" | Signals you take values as behaviour, not slogans |
| 5 | "What do you expect a manager at this level to change beyond their own squads?" | Tells you how big the role really is |

---

## Sources

- **Provided:** your message (role text, round schedule, background). No CV, JD document or values page was supplied.
- **Loop:** established by your own words (three sessions, each with who runs it), so no archetype fallback was used.
- **Searches sent** (all refused by this session's permissions, nothing returned):
  - "Larkfield Systems values" — refused
  - "Larkfield Systems interview process engineering manager" — refused
  - "Larkfield Systems industrial IoT news 2026" — refused
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the values cheat sheet for Round 3 and themed K1 to K4 by Larkfield's own value names |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. Your own words already establish the three rounds, so it would only have confirmed or refined persona weights |
| 3. `Larkfield Systems` strategy / recent news | unavailable | The search was refused. It would have grounded L1 and the device-domain questions (A4, G3, J1) in Larkfield's current priorities instead of `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form; no interviewer read |
| 5. representative Engineering Manager JD | skipped | The role text you quoted fixes the fit snapshot's requirements and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → requirement rows quoted from the full posting instead of the one-paragraph role text; mid-list requirements get their own questions; any gates (location, travel, on-call) surfaced
- **Your CV** → more quoted sentences, so scaffolds such as C2, H2, K3 become story-mapped answers
- **Your answers to the slots in F2, F4, F5 and F7** → those rows move from `discovery` toward graded evidence, and B3, C2, E3, G3 and H1 are rewritten around what you actually did
- **Web search allowed in this session** → targets 1 to 3 rerun; then a deeper pass on offer, at most 6 more searches and 2 more fetches, several more minutes, for a strategy brief and recent org context
- **Larkfield's published values or leadership principles, pasted** → a values cheat sheet for Round 3, with each value mapped to one of your quoted stories or an honest scaffold
- **Interviewer names** → a read of each interviewer's public professional footprint, per-person persona weights for the panel, and a reverse question tied to each one's path
- **Recruiter guidance** (focus areas, anything to prepare) → coverage of any pre-declared deliverable, such as a "first 90 days" presentation
- **How much prep time you have before Tuesday** → a prioritized prep schedule
- **A `tuesday-dossier.md`** → an evidence-graded objection and prohibited-claims list from a verified evidence map, instead of one built locally from your message
