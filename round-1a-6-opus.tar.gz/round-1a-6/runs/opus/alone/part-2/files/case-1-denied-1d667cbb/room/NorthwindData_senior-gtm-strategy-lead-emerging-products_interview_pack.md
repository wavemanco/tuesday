# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. He would be a **peer**: you'd both report to the same VP.
**Format:** one 60-minute conversation.
**Built from:** the coach's notes (JD highlights, Priya's background, Dan's profile, a research note on Northwind). No full JD, no CV, no web research (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question is asked: the style, the pressure, the follow-ups. **Types** describe *what* is being scored. Rehearse both. The same question asked collegially by a peer and asked by a skeptic needs the same content with different delivery.
- **Question IDs** are grouped by persona: A Prober, B Peer Evaluator, C Case/Strategist, D Skeptic, E Pressure, R Rapport, V Values. Fit-snapshot rows are numbered F1 to F7.
- **Answer guidance is scaffolding, not a script.** Every claim about Priya's past rests on a sentence quoted in the Provenance column. Where the material doesn't carry a detail, the cell gives an **answer slot**: an instruction for the interview with two honest branches. It is never a gap for the pack to fill in.
- **Provenance labels:** `[grounded]` traces to the coach's notes; `[inferred]` is this pack's derivation, with the derivation named; `[generic]` is a role-family pattern that makes no claim about Northwind or Priya.

| Tag | Type | What it's scoring |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the company's published values (none were in hand, so V-bank themes are generic) |
| EXP | Experience deep-dive | Whether claims survive scrutiny; what was actually Priya's |
| JD | Role / JD-driven | Whether she can do the listed job, including its gaps |
| CO | Company & strategy | Homework depth: whether she can think at Northwind's level |
| CASE | Live problem | Structure and reasoning on a problem from the actual role |

---

## Fit snapshot

Requirements come from the JD highlights in the coach's notes, plus one row (F7) derived from Dan's seat.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, coach's notes | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says product strategy & ops at a consumer-tech company, not GTM ownership of new B2B product lines, and the words stay there: "I spent two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company." Answer slot: the JD's own-GTM line makes a probe on that work likely. Say which parts of it were yours to set and how you decided, in your own words; where a part was someone else's, or there was no such decision, say so plainly and stay with the work you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | Proposing a change to a consumer store surface is not the same as mapping B2B lifecycle whitespace, so don't stretch the bridge. Answer slot: the JD's whitespace line makes a probe on where the proposal came from likely. If it came out of analysis you ran, say what you looked at; if it didn't, say so plainly. Then show how you'd look for whitespace here (C2) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. It is a self-description with nothing inspected behind it, so expect Dan to probe it. Lead in the quote's own terms, then offer to walk through an analysis end to end (A3) |
| F4 | "partner-motion design experience required" — JD highlights, coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a model used in negotiations, not a partner motion designed, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on the model likely. Say which parts were yours (its build, its assumptions, how it was used in the negotiations) in your own words; where a part was someone else's, say so and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights, coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap: the quote already speaks to cross-org work. Lead with it in its own terms ("I set annual volume targets with cross-org consensus") and let Dan draw the word "influence" himself |
| F6 | "AI experience a plus" — JD highlights, coach's notes | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Daily tool use sits next to the AI line but doesn't reach past it, and the words stay there: "I use AI tools daily." Answer slot: the JD's AI line and Compass make a follow-up likely. Say what you use the tools for and what they have changed in your work, in your own words; if not much has changed, say so plainly |
| F7 | Sales-ops and quota-setting fluency, derived from the interviewer's seat (Director of Sales Strategy); not a JD line | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [inferred] | capability | A gap wording can't close, and the material states it. Words: "I haven't done classic sales ops or quota-setting." Then how you'd learn Northwind's version, said as a plan and never as a past. Volume targets (F5) are never relabeled as quotas |

**Requirement coverage**

| JD requirement | Fit row | Questions |
|---|---|---|
| Own GTM strategy for two new product lines | F1 | D1, D3, C3, R1 |
| Whitespace across land/adopt/expand/renew | F2 | C2, A1 |
| Independent analysis in SQL and Tableau | F3 | A3, B5 |
| Partner-motion design (required) | F4 | D2, A2, B3 |
| Strong cross-functional influence | F5 | B1, B2, A4 |
| AI experience (a plus) | F6 | R2, A5, C4 |
| Sales-ops / quota fluency (from Dan's seat) | F7 | D1, A4 |

---

## Reading the interviewer

Everything here comes from your description of Dan. A web check of his public footprint was refused, so nothing below goes beyond what you reported.

| Signal | Source | What it means for this hour |
|---|---|---|
| Peer, reporting to the same VP | Coach's notes | He is weighing what you'd add to his team's load and what you'd take off it. Expect seam and credit questions in a collegial register (B bank), and have a reciprocity answer ready (B5) |
| Self-describes as "relentlessly data-driven" | Coach's notes, from his profile | Every number gets probed down to its assumptions (A1, A2, E1). Name your weakest assumption before he does |
| Career spine in pricing and monetization | Coach's notes | Case questions will lean toward pricing, packaging and unit economics, his native language (C1, C4) |
| One early-stage-startup chapter | Coach's notes | Builder stories land well, and scrappiness probes are likely (E2). Reverse question 2 draws on this |
| Director of Sales Strategy title | Coach's notes | F7 is most visible from his chair, which is why D1 is the highest-ROI prep |

**Mirror opportunity, shared vocabulary rather than a shared career jump:** revenue modeling sits close to Dan's monetization work. F4's quote is the one to bring: "built a partner-level revenue model used in carrier negotiations". Talk in its terms, not his. Nothing in Priya's material parallels his startup jump, so the pack doesn't offer one.

---

## Persona table

| Persona | How it shows up with Dan | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | "How was that counted? What's in the denominator?" Two levels below every number | high | Peers usually probe competence, and his self-description pushes this up further | For each figure, know what you can and can't say about how it was counted. Name the weakest assumption first. Offer an end-to-end walkthrough only of work you did yourself |
| Peer Evaluator | "Where's our seam? What do you need from me?" | high | The peer relationship is the starting assumption, and a shared VP makes the seam real | Reciprocity: what you bring his team, not only what you need. Propose seam principles rather than guessing Northwind's org |
| Case / Strategist | Live GTM, pricing and packaging problems on Northwind's priorities | mid | It's a strategy role, and his pricing background tilts cases toward monetization | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise per case |
| Skeptic | "You haven't carried a quota. Why trust your GTM?" | mid | F7 is visible from his seat, and F1 and F4 are transferability gaps | Rehearse D1 until it's boring. Bridge only from quoted evidence and give a concrete ramp plan |
| Pressure | Time-boxed "how much was actually you" questions | low | Not typical of a peer conversation, but a data-driven interviewer pressing on a $400M figure gets close | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational / Rapport | "Walk me through the journey." Casual questions about AI | low | Openers and the AI plus-skill are still scored | A pre-scripted 90-second arc, and treat the AI question as scored |
| Values / Behavioral | "Tell me about an unpopular truth" | low | Your description of the session names no values round | Selection scaffolds with honest branches. Don't stretch a story to fit |

---

## Question banks

### A. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The store-surface change credited with a ~$400M ARR uplift: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The beats are the ones the quote states: you proposed the change, and the change was credited with a ~$400M ARR uplift. Keep "proposed", "credited" and the "~". Then the four slots a figure raises, each in your own words. **How it was counted:** if you know the method, describe it; if another team did the attribution and you don't know how, say so plainly. **What it's sensitive to.** **The assumption you'd defend least:** name it before Dan does. **Which part was yours:** the quote says you proposed it, so stay there unless more was yours, and if others carried it, name who and what they did | This is the headline metric in F2's evidence and the first place a self-described data-driven interviewer will go. EXP because it tests attribution and counting, not the idea |
| A2 | "You built a partner-level revenue model used in carrier negotiations. Walk me through it." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats the quote states: you built it, it was partner-level, and it was used in carrier negotiations. If he asks for its inputs and assumptions, give them in your own words, and name the one you'd defend least. Answer slot: the JD's partner-motion line makes a probe on how the model was used likely. Say which parts were yours (the build, the assumptions, its use in the negotiations) in your own words; where a part was someone else's, say so plainly and return to the model you built | F4 is the evidence nearest the one "required" JD line, and a monetization interviewer will want to see the model's mechanics. EXP because it verifies the claim before D2 tests the requirement |
| A3 | "This role runs its own analysis in SQL and Tableau. Tell me about an analysis you built end to end yourself." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold. Pick one analysis you did yourself in SQL or Tableau. It needs a question someone needed answered, the data you pulled, what you found, and what happened next. Offer to walk through it step by step. If no single analysis comes to mind that was yours end to end, say so plainly, then give the nearest thing your material carries ("I'm skilled in SQL and Tableau") and how you'd run the first analysis here | Covers F3. A Prober tests a skills claim by asking for one concrete artifact. JD type because "independent analysis" is a stated requirement |
| A4 | "You set annual volume targets with cross-org consensus. Walk me through how one year's targets got set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The beats the quote states: you set them, they were annual, they were volume targets, and they had cross-org consensus. Tell the steps in your own words. Keep the term "volume targets" and never call them quotas (F7). If asked whose numbers fed in or who signed off, answer from what actually happened; if you don't remember, say so | F5 is the closest thing in the material to Dan's own work, so he'll test it in detail. EXP because the method is the claim being tested |
| A5 | "Say Compass is launching. What three metrics go on the first-90-day dashboard, and which one would you trust least?" | CASE | [grounded] | Clarify first: which customers, and what counts as "launched". Objective: adoption that leads to expansion, tied to Northwind's enterprise-expansion priority. Three metrics, for example activation among eligible accounts, depth of repeat usage, and expansion pipeline where Compass was involved. Then name the one you'd trust least (pipeline "influence" depends on attribution) and say how you'd check it. The question asks nothing about your past, so the guidance claims nothing | Grounded in the research note's Compass priority. CASE because it's a live problem, and the trust-least step is the Prober's weakest-assumption test in case form |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "My team owns sales strategy for the core business, and you'd own GTM for two new lines. Where's the seam, and what happens when we disagree?" | JD | [inferred] | Propose principles rather than guessing Northwind's org: one shared definition of accounts and pipeline; targets for new products decided jointly before they reach core reps' plans; a standing check-in; disagreements go to the data first and to your shared VP only as a last resort. For the disagreement half, pick a time you disagreed with a peer team. It needs a real stake, your position, and the relationship intact afterward. If none comes to mind, say so plainly and say how you'd handle it with him | The premise is inferred from Dan's title plus the JD's two-product-line scope. JD because cross-functional influence is listed. This is the signature peer question |
| B2 | "Tell me about getting cross-org consensus on those volume targets. Who had to agree, and what did it take?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The beats the quote states: annual volume targets, set by you, with cross-org consensus. Say who had to agree in your own words. Answer slot: the JD's cross-functional-influence line makes a pushback probe likely. If a team disagreed, say what happened and what part of resolving it was yours; if there was no real disagreement, say so plainly and describe how the consensus was reached | Covers F5 as the peer would test it, and asks how the consensus actually came about. EXP because it verifies the story behind the quote |
| B3 | "How would you design a partner motion for a new product line here, and where does my team come in?" | CASE | [grounded] | Clarify which product line and which partner type (resellers, systems integrators, marketplaces, technology alliances). Objective: reach versus margin, given the profitability priority. Motion: sourcing, co-selling or resale. Economics: partner margin against direct cost of sale. **Conflict rules with direct reps** (this is Dan's seam: who gets credit when a partner touches a direct account). Metrics: partner-sourced pipeline, win rate, margin. Risks: channel conflict, partners pushing the bundled rival. Said as a plan; makes no claim about your past | The JD's required line asked as a live problem. Grounded in the JD and the research note. CASE because it scores structure, and the peer packaging shows up in the conflict-rules beat |
| B4 | "How do you handle credit when work spans teams? Take the store-surface change." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | "We" for the change, "I" for the proposal: the quote says you proposed it and that it was credited with a ~$400M ARR uplift. Answer slot, on which part was theirs: if other teams built, tested or shipped it, name them and what they did; say what was yours in your own words, and stop where the quote stops | A credit-sharing probe on F2's headline number, which matters to a peer whose team's work could sit under your numbers. EXP because attribution is the claim being tested |
| B5 | "What would you need from my team in your first 90 days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau" | **What you'd bring:** you're skilled in SQL and Tableau, so you can pull your own numbers instead of adding to his team's queue (an offer about the future, not a claim about the past). **What you'd need:** his team's account and pipeline definitions, how quota and comp treat new products, and one rep leader to pressure-test targets. Close by asking what would help him most (reverse question 3) | The reciprocity test a peer runs, and it draws on F3. JD because it maps to the independent-analysis line |

### C. Case / Strategist (weight: mid; tilted toward pricing for Dan)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a competing product in for free. How do you position and price our new line against that?" | CO | [grounded] | Clarify: which line, which segment, which use cases the bundle covers well enough. Segment by where the bundle wins (good enough, already deployed) and where Northwind can win (depth, neutrality, fit with Northwind's existing footprint). Pricing and packaging options: a focused entry offer, attaching to existing contracts at renewal, usage-based expansion. Metrics: win rate against the bundle, displacement at renewal. Challenge one premise: "free" still costs the buyer in switching, integration and lock-in. Assert no Northwind product facts you don't have | The research note names bundling as the main threat, and pricing is Dan's native language. CO because it scores strategic homework; delivered as a case |
| C2 | "Find whitespace for a new product line across land, adopt, expand and renew. Where do you start in the data?" | JD | [grounded] | Define each stage as data. Land: target accounts with no Northwind product. Adopt: bought but not using. Expand: using, with room to grow. Renew: coming due. Join install base, usage, firmographics and renewal dates. Size each cell and prioritize where the new line attaches to existing footprint (the enterprise-expansion priority). Validate with Dan's team and build the Tableau view. Name the weakest assumption: whatever proxy you use for propensity | The JD's whitespace line asked as a live problem, covering F2's discovery gap. JD content with CASE delivery. Tagged JD because the requirement is what's scored |
| C3 | "Our priorities are enterprise expansion, Compass and reaching profitability. Where do they pull against each other in GTM for a new product?" | CO | [grounded] | Name the tensions. Expansion against profitability: discounting, partner margins, cost of sale. Compass as an expansion lever against its cost to serve. A focused new line against attention pulled from the core. Propose a decision rule (for example, new-product targets with a margin floor) and challenge one premise respectfully | Built directly on the research note's three priorities. CO because it tests whether she can think at the company's level |
| C4 | "How would you package Compass: add-on, tier, or usage-based? And how would you test it?" | CASE | [grounded] | Clarify the buyer and the value metric. Weigh the options against the bundling threat and the profitability priority. Test with pilot cohorts, price checks at renewal, and a watch on cannibalization. Name the weakest assumption: willingness to pay while a bundled alternative exists | A Compass case in Dan's monetization language, touching the AI line (F6). CASE because the reasoning is what's scored |

### D. Skeptic (weight: mid). **D1 is the highest-ROI prep in this pack.**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your nine years are in consumer tech, and you haven't run sales ops or set quotas. Why should a B2B sales org trust your GTM calls?" | JD | [grounded] "No classic sales-ops or quota-setting experience" "9 at a large consumer-tech company in product strategy & ops" "set annual volume targets with cross-org consensus" "built a partner-level revenue model used in carrier negotiations" | **Open with the plain acknowledgment, unhedged:** "I haven't done classic sales ops or quota-setting." Then only what the quotes carry, in your own words: "I set annual volume targets with cross-org consensus," and "I built a partner-level revenue model used in carrier negotiations." Let Dan draw the link himself; don't tell him these prove you can do his job. **Then the ramp, as a plan:** first learn from his team how quota, territories and comp treat new products, then pressure-test new-product targets with them before reps see them. **Follow-up 1**, "Aren't volume targets basically quotas?": hold. They were volume targets, and you won't call them quotas. **Follow-up 2**, "Week one, sales leaders reject your targets. Then what?": a plan, not a past. Say whose data you'd use and who you'd bring in, with the shared VP only as a last resort. **Follow-up 3**, "Consumer to B2B: what doesn't transfer?": answer slot. Name what you think won't transfer, in your own words, and concede it specifically. The material doesn't show B2B selling, so don't reach for it | This is the objection F7 and F1 make almost certain, coming from the person whose job sits on the other side of the gap. The negative in the question has a source in the coach's notes. JD because it scores fitness for the stated GTM mandate. It gets the deepest rehearsal: three follow-ups, exact acknowledgment wording, and the limit named before he asks |
| D2 | "Partner-motion design is a required line for this role. What partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold to the quote: "I built a partner-level revenue model that was used in carrier negotiations." The pack's own observation: the material says a model used in negotiations, not a motion designed, so don't relabel the model as a motion. Answer slot, staying inside the model: say which parts were yours (the build, the assumptions, how it was used in the negotiations) in your own words, and where a part was someone else's, say so. If he presses on whether that was a partner motion, answer from what you actually did. Then pivot to how you would design the first one here (B3's structure), said as a plan | The only "required" JD line, and F4 is a transferability gap, so a careful reader will ask. JD because it tests the stated qualification directly |
| D3 | "Why leave consumer tech for emerging-products GTM at a 3,000-person B2B company? Why here, and why now?" | JD | [grounded] | Answer slot: give your actual reasons for leaving and for this role, in your own words. For "why here", connect to what the research note says: enterprise expansion, Compass, the push to profitability, the bundling threat. Present these as reasons the role interests you, not as claims about Northwind beyond the note | A motivation probe that the F1 transferability gap makes likely. JD because it tests fit with the role. Grounded in the research note |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then hold: "I proposed the change; it was credited with a ~$400M ARR uplift." Hold that through two follow-ups without growing or shrinking it. Concede specifically through the answer slot: if others carried parts of it, name who and what; if you know how the credit was assigned, say so, and if you don't, say so plainly. If the proposal was yours, don't fold to "it was a team thing"; the quote says the proposal was | The persona stem that probes attribution, applied to F2's figure. A data-driven peer is likely to ask it bluntly. EXP because attribution honesty is what's scored |
| E2 | "Sixty seconds. Emerging products here won't have a big-company machine behind them. When have you built something with nothing behind you?" | EXP | [generic] | Pause, then stay inside sixty seconds. Selection scaffold: pick a time you built something without a team or budget behind it. It needs a named goal, what you had to work with, what you did yourself, and where it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries and how you'd run the first 90 days here with little machinery | Dan's startup chapter makes a scrappiness probe likely. Generic because none of Priya's quoted sentences carries a story like this. EXP because the scored content is a past instance |

### R. Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | A 90-second arc: two years of strategy consulting at a top firm, then nine in product strategy and ops at a large consumer-tech company. Pick two quoted stories at their own scope (the revenue model used in carrier negotiations, and the volume targets set with cross-org consensus). End on why this role: your actual reason, in your own words | Every conversation opens here, and it's still scored for economy. It draws on F1, F4 and F5. EXP because it sets up the claims he'll probe |
| R2 | "What are you actually doing with AI these days?" | JD | [grounded] "uses AI tools daily" | Treat this as scored. "I use AI tools daily." Then which tools and what you use them for, in your own words. Answer slot: the JD's AI line and Compass make a follow-up on what they've changed in your work likely. If something has, say what; if not much, say so plainly | Covers F6, the JD's plus-skill, asked casually. JD because the requirement is what's scored |

### V. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told leadership something they didn't want to hear. It needs the stakes, what you said, how it landed, and the relationship afterward, and the truth should have actually landed. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Persona stem. No Northwind values were in hand, so it's generic. VAL because behavior is what's scored |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time you chose the customer's outcome over a number you were measured on. Name the metric you set aside and why, which matters to a data-driven listener. If none comes to mind, say so plainly, then say how you'd make that call here | Persona stem, and it's sharper with an interviewer who self-describes as data-driven. VAL; generic for the same reason as V1 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| 1 | "With your pricing and monetization background, how do you think about packaging a new product against a free bundle? Where have you seen it work?" | It's tied to his career spine and Northwind's stated main threat, so it turns the conversation into a peer exchange in his native language |
| 2 | "You've worked in an early-stage startup. Which startup habits does emerging-product GTM here most need, and which ones break at 3,000 people?" | It's tied to his startup chapter, and the answer tells you how scrappy the role is expected to be |
| 3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question: it shows you're thinking about his load, not only yours |
| 4 | "How do new-product targets interact with core quotas and comp today, and where has that seam caused friction?" | It goes straight at F7. You learn the mechanics you've said you haven't run, and you show you know where the friction is |
| 5 | "Where does Compass sit in the GTM plan: sold by the core team, by a specialist overlay, or through partners?" | It connects the role's partner-motion requirement to a stated company priority, and the answer shapes your first 90 days |
| 6 | "With profitability a stated priority, how is our VP weighing growth bets on new lines against efficiency this year?" | It reads the shared VP's priorities through a peer, and it's useful diligence before accepting |

---

## Prohibited claims

What this pack will not coach, each with its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed partner motions or partner programs | Inflated form of F4 | F4's quote at its own scope: "I built a partner-level revenue model used in carrier negotiations." The limit is the pack's observation, not words for Priya to say: the material says a model used in negotiations, not a motion designed. The slots in A2 and D2 stay inside the model |
| Negotiated the carrier deals | Inflated form of F4 | F4's quote. The material says the model was used in negotiations; it doesn't say who negotiated |
| Drove, delivered or owns ~$400M ARR | Inflated form of F2's quote | "I proposed a store-surface change credited with a ~$400M ARR uplift." Keep "proposed", "credited" and "~". The slots in A1, B4 and E1 ask only which part was hers and how the figure was counted |
| Set quotas, ran sales ops, or did quota planning | Negative stated in the coach's notes, F7 | "I haven't done classic sales ops or quota-setting." No slot. Volume targets are never relabeled as quotas |
| Owned GTM for product launches | Inflated form of F1 | F1's quote at its own scope: product strategy & ops at a large consumer-tech company. F1's slot asks only which parts of that work were hers to set |
| Has AI product experience | Inflated form of F6 | "I use AI tools daily." R2's slot stays with what the tools have changed in her work |

---

## Sources

**Provided documents:** the coach's notes, covering the role and JD highlights, Priya's background, Dan Kovac's profile as reported, and a research note (Northwind's three stated priorities and the bundling threat).

**Searches sent:**
- `"Northwind Data" company values`: refused
- `"Northwind Data" interview process strategy role`: refused
- `"Northwind Data" Compass AI copilot launch`: refused (a quick check of the research note)
- `"Dan Kovac" Northwind Data sales strategy`: refused

No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. It would have given the V bank Northwind's published values as themes. The values cheat sheet stays out either way, because no values round is in this session |
| 2. `Northwind Data interview process` | unavailable | The call was refused. The coach's notes already establish this session (one 60-minute conversation with a peer), so it would only have added context on later rounds |
| 3. `Northwind Data strategy` / recent news | unavailable | The call was refused. It was a check that the research note is still current; it would have refreshed Compass's status and the bundling picture behind C1, C3, C4 and A5 |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. It would have checked and extended the interviewer read beyond the coach's description |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied in the coach's notes fix the fit-snapshot requirements and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → F1 to F6 checked against the posting's own wording, and any mid-list requirement the highlights left out gets a JD-tagged question
- **Priya's CV** → evidence cells move from the coach's summary to her own lines, and every metric on her CV gets a defend-the-number question
- **Priya's own answers to the answer slots** (F1, F2, F4, F6; A1, A2, B2, D2, E1) → those rows regenerate story-mapped on what she actually did
- **Prep time available** → a prioritized prep schedule (until then, start with D1, then A1, D2 and B1)
- **Web search allowed** → targets 1 to 4 rerun: Northwind's published values as V-bank themes, a current check on Compass and the bundling threat, and Dan's public footprint
- **Deep research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Northwind's strategy, competitive set and org context, which sharpens the C bank
- **Recruiter guidance** → coverage of any pre-declared deliverable or stated focus areas
- **Schedule of later rounds** → per-round mini-packs with their own persona weights
- **A tuesday-dossier.md** → the highest-ROI objection derived from confirmed evidence rather than inferred, and a prohibited-claims list built from confirmed evidence
