# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** all three rounds on 5 December 2026
**Format:** loop mode, built on the recruiter's email: a shared fit snapshot, then one mini-pack per round
**Interviewers:** Round 1 is the recruiter. Round 2 is the Head of Member Services, your future manager. Round 3 is a panel of two branch managers. No names have been assigned yet.

---

## How to use this pack

- **Personas = how a question is asked.** Examples: a friendly recruiter, a sceptical manager, a values panel.
- **Types = what is being scored.** Every question has one type tag:
  - **VAL**: whether your past behaviour shows one of Ashgrove's four published values
  - **EXP**: whether what you say about your own work holds up when probed, and what was actually you
  - **JD**: whether you can do what the job description lists, including the parts where you have gaps
  - **CO**: whether you know Ashgrove's strategy and pressures and can think at its level
  - **CASE**: a live problem set in the role, worked through out loud
- **Provenance labels:**
  - `[grounded]`: traceable to something you gave me
  - `[inferred]`: derived by this pack
  - `[generic]`: a common pattern for this kind of role, with no claim about Ashgrove
- **The guidance is scaffolding, not a script.** Every claim about your past uses your own sentences, quoted. An **answer slot** marks a place where only you know the answer. It always has two honest branches, and "no, that wasn't me" is one of them.
- **Highest-ROI prep in this pack: D1** (Round 2), the contact-centre objection. Rehearse it until it bores you.

---

## Fit snapshot (shared across all three rounds)

Your evidence comes from the background in your message. No CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's formal complaints log. It does not describe a process across branches. Keep your words at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe on the stages of a complaint likely (logging, investigating, responding, closing). If any of those stages were yours, say which and how, in your own words. If a stage wasn't part of the log, or wasn't yours, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You've said this yourself, and no wording will close it. Your words: "I've never worked in a contact centre." Then say how you would learn it, framed as a plan and never as something you've done. Never claim contact-centre work, and don't add anything to make the gap sound smaller. D1 rehearses this in depth |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The spreadsheet is monthly and about complaints. Your material doesn't say what it measures. Answer slot: if it counts complaint volumes or resolution times, say which and how, in your own words. If it doesn't, say so plainly and say what it does track |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script. It doesn't say you coached supervisors or wrote the script, so keep both words: "I trained new tellers on our escalation script," and "the last three years as a branch supervisor." Answer slot: if you have ever coached another supervisor on an escalation, say what happened, in your own words. If you haven't, say so plainly and stay with the teller training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a time you fed into a digital or self-service change, for example by passing on what members complained about. Answer slot: if you have done anything like that, say what it was and what part was yours, in your own words. If you haven't, say so plainly and say how you would start, framed as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Six years is more than the four asked for. Say it in your own sentence's terms: "Six years in retail banking, the last three as a branch supervisor." Don't relabel it with the JD's phrase. Let the interviewer make the match |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | A formal complaints log touches this requirement. Your material doesn't say whether the complaints in it were handled under regulatory rules. Answer slot: if they carried regulatory requirements you worked to (deadlines, written responses, referral rights), say which ones and what you did, in your own words. If they didn't, or you aren't sure, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I built the monthly complaints spreadsheet our regional manager uses." — your message | none | [grounded] | capability | You've stated this gap yourself. Your words: "I've never presented to anyone above regional level." The adjacent fact, at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Then say how you'd prepare, framed as a plan. Never imply you have presented to senior leaders |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet". It doesn't name the tool. Answer slot: name the tool you built it in. If it was Excel, say so and describe what the spreadsheet does, in your own words. If it was something else, say what |

No requirement in the JD is a gate. "4+ years" is a length-of-experience requirement, and it is graded on fit like the rest.

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| F1 Own the complaints process end to end | A1, B1, C1, D3, G1 |
| F2 Across branches and the contact centre | B2, D1, G1 |
| F3 Monthly reporting on volumes and resolution times | C5, E2, H2 |
| F4 Coach branch supervisors on escalations | C2, H1 |
| F5 Digital teams and self-service journeys | E1 |
| F6 4+ years in financial-services customer operations | A1 |
| F7 Regulated complaints | B1, C1 |
| F8 Presenting to senior leaders | B3, D2 |
| F9 Excel reporting | C5 |
| The four values (panel scoring) | V1–V4, C2, C3 |
| The strategy brief | A2, E1, G2, H3 |

---

## Prohibited claims (shared)

The pack will not coach these claims anywhere. Each one is either a stretched version of something you said or something you said wasn't true.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." This pack's observation: your material describes one branch's log, not a cross-branch process |
| Has contact-centre experience | A negative you stated, F2 | "I've never worked in a contact centre." No slot |
| Coached branch supervisors | Inflated form of F4 | "I trained new tellers on our escalation script." This pack's observation: your material describes tellers, not supervisors |
| Wrote or designed the escalation script | Inflated form of F4 | "trained new tellers on our escalation script". This pack's observation: "our" script, trained on, not authored |
| Built the region's complaints reporting | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." This pack's observation: one spreadsheet, used by your regional manager. Nothing says it is the region's reporting system |
| Has presented to senior leaders | A negative you stated, F8 | "I've never presented to anyone above regional level." No slot |
| Ran or managed the branch | Inflated form of F6 | "the last 3 as a branch supervisor". This pack's observation: supervisor is the title you gave |

---

## Grounding brief (shared)

Here is the vocabulary to sound current in. These rows come from your summary of Ashgrove's July 2026 strategy brief and from the JD. The brief is about four months old, so nothing in it reads as stale.

| Fact | Source | Provenance | Where it shows up |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | Your summary of the July 2026 strategy brief | [grounded] | E1, F5's discovery slot, Round 2 reverse questions |
| "consolidate eight branches into five hubs over 2027" | Your summary of the July 2026 strategy brief | [grounded] | G2, H3, Round 3 reverse questions. Your two panellists are branch managers, so this is close to home for them |
| "launch a small-business lending product in Q1 2027" | Your summary of the July 2026 strategy brief | [grounded] | Round 2 reverse questions. A new product can bring new kinds of complaints. That link is this pack's reasoning, not something the brief says |
| "the main competitive pressure is app-only banks" | Your summary of the July 2026 strategy brief | [grounded] | E1, A2 |
| "member-owned, about 900 staff" | JD | [grounded] | A2 |

Use these facts to ask better questions and frame cases. Don't recite them. Every prepared candidate has the same brief.

---

## Values cheat sheet (Round 3 is the values round)

The panel scores against these four values. Names and wording come from the text you copied on 26 November 2026. None of your quoted sentences carries a complete story for a value, so each row gives selection criteria. Pick your stories before the day.

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decisions made from the member's point of view, even when that is less convenient for the institution | Selection scaffold: pick a time you made or pushed for a decision because it was right for the member, even though it was harder for the branch. It needs a named member situation (anonymised), the tension, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it |
| Plain Words | If something needs explaining twice, the explanation was at fault, not the reader | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Tell the teller training in your own words. Answer slot: if you changed how you explained the script after something didn't land, say what you changed. If you didn't, say so plainly and describe how you trained them |
| Neighbours, Not Numbers | Each branch belongs to its town, and members are people, not metrics | Selection scaffold: pick a time when knowing the local community changed how you handled a member or a complaint. It needs the local detail, what it changed, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved, with no hand-offs into the void | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if there is a complaint from that log that you kept hold of until it was solved, tell it, including what you did and where it ended. If none comes to mind that you can tell accurately, say so plainly and pick another time you found a problem and kept hold of it |

---

## Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly walk-through, motivation, logistics | High. A recruiter screen's default register, and this one is only 30 minutes | Have a 90-second arc ready. Treat casual questions as scored. Have reverse questions ready |
| B. Light Skeptic | Quick knockout checks against the JD's requirements | Medium. Recruiters screen against the JD's listed requirements, and F2 and F8 are gaps you stated | Short honest answers built from your own sentences. Keep the deep versions for Round 2 |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using your own sentences: "I've spent six years in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log and trained new tellers on our escalation script, and I built the monthly complaints spreadsheet our regional manager uses." Then why this role, as an answer slot: say in your own words what draws you to owning complaints across a whole organisation. Stop at 90 seconds | The biography question opens almost every screen, and F1, F3, F4 and F6 all live in it. EXP because it sets the facts every later round will probe |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one value by its official name and one item from the strategy brief, in your own words. For example, "Members First, Always" and the move to digital channels. Answer slot: give your actual reason for wanting a member-owned organisation. If you don't have a specific one, say what you do know you want from the role instead | Motivation consistency is scored even in a friendly register. CO because it tests homework on the values page and the brief |
| A3 | "What are your salary expectations?" | JD | [generic] | Your choice: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | A standard recruiter logistics question, and the only safe answer is your own. JD because pay is one of the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Give your actual notice period | Standard logistics. JD because the start date is one of the job's terms |
| A5 | "The role covers branches and the contact centre, and the branch network is changing. How are you with travelling between sites?" | JD | [grounded] | Give your actual position on travelling between sites, in your own words | The JD's "across branches and the contact centre" and the hubs plan make location a live question. JD because it concerns the job's terms |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your own reason, in your own words, and keep it pointed at what you're moving toward | Standard logistics. EXP because the answer is about your own history |

### Bank B: Light Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD asks for regulated complaints experience. Is that something you've handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the fact: "I handled the branch's formal complaints log." Answer slot: if those complaints carried regulatory requirements you worked to, name one in your own words. If you aren't sure they did, say so plainly and describe the log | F7 is a discovery row the recruiter can tick or not in one answer. JD because it scores a listed requirement |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Short and plain: "No, I've never worked in a contact centre." Then one line of plan: how you'd get up to speed on it early. Don't apologise and don't pad. D1 is the deep version | F2 is a gap you stated, and a recruiter checking it against the JD is likely. JD because it scores the "contact centre" clause |
| B3 | "This role presents to senior leaders. What's your experience there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | "I've never presented to anyone above regional level." Then the adjacent fact: "I built the monthly complaints spreadsheet our regional manager uses." End with one line on how you'd prepare. D2 is the deep version | F8 is a stated gap that sits next to a listed requirement. JD because "confident presenting to senior leaders" is one |

### Reverse questions: Round 1

| Question | Why it lands |
|---|---|
| "How does the panel score the four values? Is it one question per value, or across the whole conversation?" | Shapes how you spread your stories across Round 3, and shows you read the values |
| "For the 20-minute case, will I get any material in advance, or is it presented on the day?" | Directly changes your case preparation |
| "What would the Head of Member Services want this person to have changed by six months in?" | Gives you Round 2's agenda before you walk in |
| "Is this a new role or a backfill?" | Tells you whether you'd be building the complaints process or inheriting one, which reframes D1 and E1 |
| "What's the timeline for a decision after the 5th?" | A practical question, and recruiters expect it |

---

## Round 2: Head of Member Services (your future manager), 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C. Values / Behavioral | "Tell me about a time…" questions | High. The recruiter said this round is "mostly behavioural", which outweighs the usual hiring-manager focus on cases | Story-select before the day. Use "we" for context and "I" for your contribution. Every story needs an ending you can stand behind |
| D. Skeptic | Probes the F2 and F8 gaps and the F1 scope | Medium. A hiring manager is derisking their own hire, and F2 covers half the process they would hand you | Hold-then-concede. Concede the gap first, in your own words, before they press |
| E. Case / Strategist | One or two live problems from their roadmap | Low-medium. The round is mostly behavioural, but a manager is likely to test the digital shift and the monthly reporting | Clarify, then state the objective, structure, and risks. Think aloud |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint that was hard to resolve." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, within the log: "I handled the branch's formal complaints log." Pick one complaint from it that you can tell accurately: the member's problem (anonymised), what you did, and where it ended. Say "I" only for the parts that were yours. If none comes to mind that you can tell in full, say so plainly and describe how you handled the log | F1 and F7 both meet here, and a manager will want a real case. VAL because it is likely scored on "Own the Fix" or "Members First, Always" |
| C2 | "Tell me about a time you had to explain something so it landed first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: "I trained new tellers on our escalation script." Tell it in your own words. Answer slot: "Plain Words" makes a probe on how you checked it had landed likely. If you checked, say how. If you didn't, say so plainly and describe the training | Tests "Plain Words" through F4, which is also the coaching requirement. VAL because the theme is a published value |
| C3 | "Tell me about a problem you found and kept hold of until it was fixed." | VAL | [grounded] | Selection scaffold: pick a time you noticed a problem that could have been passed on, and you kept hold of it. It needs the problem, the moment you could have handed it off, what you did, and the end state. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | "Own the Fix" is the value closest to this role's mandate, so expect it in both rounds. VAL because the theme comes straight from the published value |
| C4 | "Tell me about a time you told someone more senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time you raised an unwelcome fact with a manager. It needs the stake, what you said, how you held it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then say how you would handle it | The role reports monthly to senior leaders, and unwelcome numbers will come up. VAL because it is behavioural, while the scaffold is a common pattern for this kind of role |
| C5 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats from the quote: you built it, it is monthly, it covers complaints, and your regional manager uses it. Answer slot: the JD's "complaint volumes and resolution times" line makes a probe on what it measures likely. If it tracks those, say how, in your own words. If not, say plainly what it does track. Name the tool you built it in. Answer slot: if you know what your regional manager uses it for, say so. If you don't know, say so | F3 and F9 both rest on one sentence, so a manager will dig into it. EXP because it tests what the spreadsheet actually is |

### Bank D: Skeptic (holds the highest-ROI rehearsal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never worked in a contact centre, and half of this complaints process runs through one. Why should I trust you with it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI prep in the pack.** Open by conceding, before they press: "That's right, I've never worked in a contact centre." Then what you do have, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then a plan, framed as a plan: how you'd learn the contact centre's side first (listening in, reading its complaints alongside the branch ones, asking its team leads where escalations break). **Follow-up 1, what you'd actually do in month one:** give the plan in two or three steps, in your own words. **Follow-up 2, "Isn't that learning on our time?":** hold, don't fold: "Partly, yes. On contact-centre workflows I'll be learning at the start, and I'd rather say that than pretend." Then return to the log. Answer slot: if any complaints in the branch log came in through a contact centre, say what you did with them. If none did, or you don't know, say so plainly. Never claim channel experience you don't have, and never argue that complaints are the same everywhere | F2 is the biggest gap, you stated it yourself, and it covers half of the JD's first line, so this objection will arrive in some form. JD because it scores the "contact centre" clause. The Skeptic delivers it with a follow-up meant to test whether you stay composed |
| D2 | "You've never presented above regional level, and this role reports to senior leaders every month. How do I know you'll hold the room?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Concede plainly: "I've never presented to anyone above regional level." Adjacent fact: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you have presented at regional level, say what and to whom. If not, say so. Then the plan: how you'd prepare the first monthly report, for example the one number that matters, the one ask, and answers to the likely questions ready. Hold through one follow-up by returning to the plan. Concede that the first one will be the hardest | F8 is a second stated gap on a listed requirement. JD because it scores "confident presenting to senior leaders". This interview is itself a chance to show a crisp delivery |
| D3 | "How much of the branch's complaints handling was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Hold on the sentence: "I handled the branch's formal complaints log." Answer slot: say which complaints you resolved yourself and which went to someone else, in your own words. If others shared the log, say who did what. Don't widen the claim to the branch's whole complaints handling | F1 is where attribution gets probed. EXP because it scores honesty about what was yours |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and what would you do in your first 90 days?" | CASE | [grounded] | First clarify: which journeys are going digital first, and is complaints data already split by channel. Then the objective: members who move to the app still get heard and resolved. Then structure: complaints about digital journeys, complaints that come in through digital, and what branch complaints tell the digital team before a journey launches. Tie it to the JD's "work with digital teams on self-service journeys" and to app-only banks as the competitive bar. Risks: members who don't move. Make no claim about your own past here | A live problem drawn from the brief and from F5's requirement. CASE because it scores structure, and the strategy hook marks you as prepared |
| E2 | "Resolution times have crept up three months running. Diagnose it." | CASE | [grounded] | First clarify: in which channel, at which stage, and for which complaint types. Segment by branch versus contact centre, by complaint type, and by stage. Hypotheses: a volume change, a staffing change, or one complaint type stuck at one stage. Then say what you'd check first and what you'd report up. Name the assumption you'd trust least in your own diagnosis | Draws on F3's requirement ("resolution times"). CASE because it is a live diagnosis, and the weakest-assumption move is what scores well |

### Reverse questions: Round 2

| Question | Why it lands |
|---|---|
| "Where does the complaints process break most often today, in branches, the contact centre, or between them?" | Asks about the seam D1 worries about, so you sound curious rather than defensive |
| "Who reads the monthly complaints report, and what decisions has it changed?" | Shows you think of reporting as a tool for decisions, and tells you about the F8 audience |
| "How will complaint routing change as branches move into hubs during 2027?" | Uses the brief's language and shows you've thought past the interview |
| "When the small-business lending product launches in Q1 2027, how will its complaints come into this process?" | Few candidates will connect the new product to complaints |
| "What would you want me to have fixed by the end of my first year?" | Lets your future manager define success in their own words |

---

## Round 3: Panel of two branch managers, 60 minutes (values round plus a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| V. Values / Behavioral | Questions scored against the four values | High. The recruiter said the panel "score against the four values" | Have one story ready per value, using the cheat sheet. Land the ending |
| G. Case / Strategist | The 20-minute complaint-escalation case | Certain. The recruiter stated it | Follow the case build section below |
| H. Peer Evaluator | "What would you need from us?" and probes on the branch seam | Medium. Branch managers are the people whose supervisors you'd coach and whose numbers you'd report | Lead with what you'd bring them. Propose principles for working together rather than claiming to know their branches |

### Bank V: Values (one per value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell us about a time you decided something from the member's side of the counter, even when it was harder for the branch." | VAL | [grounded] | Use the "Members First, Always" scaffold from the cheat sheet. It needs the member's situation (anonymised), the tension, your decision, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | The value's own phrasing ("member's side of the counter") makes this question nearly certain. VAL by definition |
| V2 | "Tell us about something you had to explain again because people weren't getting it the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The "Plain Words" row of the cheat sheet, using the teller training: "I trained new tellers on our escalation script." Answer slot: if you changed how you explained it, say what changed. If you didn't, say so plainly and pick another time from your own experience | Comes from "if a member needs it explained twice, we wrote it wrong". VAL, and also tests F4's coaching requirement |
| V3 | "Tell us about a time when knowing the town or the community changed how you handled a member." | VAL | [grounded] | Use the "Neighbours, Not Numbers" scaffold from the cheat sheet. If no such time comes to mind, say so plainly, then say how you would handle it | The panel are branch managers, so this value is closest to home for them. VAL by definition |
| V4 | "Tell us about a problem you found that wasn't strictly yours, and what you did with it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the "Own the Fix" row of the cheat sheet. Answer slot: a complaint from the log that you kept hold of until it was solved, or another time you found a problem and kept hold of it. If none comes to mind that you can tell accurately, say so plainly | "Own the Fix" is the value the role is built on. Use a different story from C3 if you can, because the two rounds may compare notes. VAL by definition |

### Bank G: Case (the 20-minute escalation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained twice at their branch and once to the contact centre about the same issue, and now wants to speak to someone senior. Walk us through it." | CASE | [generic] | Use the case build section below: clarify, act for the member now, keep ownership, check the regulatory clock, find the root cause, and close in plain words. Make no claim about your own past here | The recruiter announced a 20-minute escalation case. Its exact content isn't known, so this is a likely shape, not Ashgrove's case. CASE by definition |
| G2 | "And the member's branch is one of those closing into a hub next year, and they're angry about that too. What changes?" | CASE | [grounded] | Separate the two complaints: the original issue, and the closure, which is a decision you don't own. Fix the first. For the second, listen and record it, say plainly what you can and can't change, and make sure it reaches whoever owns the hubs programme. Don't defend or criticise the strategy | The brief's "eight branches into five hubs" is personal for a branch-manager panel. CASE because it tests whether you can keep a fix you own separate from a decision you don't |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would you bring?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with what you'd bring: "I was a branch supervisor for the last three years, and I trained new tellers on our escalation script." Then what you'd ask of them: time with their supervisors, and their view of where escalations go wrong. Answer slot: if you've coached a fellow supervisor, say so in your own words. If not, say plainly that coaching supervisors would be new and say how you'd approach it | F4 is the transferability row, and these managers' supervisors are the people you'd coach. JD because it scores a listed requirement, and the reciprocity framing is how a peer evaluator asks it |
| H2 | "Your monthly report will put our branch's numbers next to everyone else's. What do you do when a manager thinks the numbers are unfair?" | CASE | [grounded] | A principle, not a war story: agree the definitions with branches before the numbers go up, show them their figures before senior leaders see them, and fix the data if it's wrong. Hold your ground if the data is right. Make no claim about your own past here | F3's requirement ("report monthly") lands on these managers directly. CASE because it is a live situation set in the role |
| H3 | "Eight branches becoming five hubs. How do you keep 'Neighbours, Not Numbers' true through that?" | CO | [grounded] | Acknowledge the tension honestly; don't pretend there isn't one. Then a principle: complaints from towns losing a branch are tracked as their own group, so the panel and senior leaders can see what the change is doing to those members. Don't criticise the strategy and don't oversell it | Combines the brief with a value, in front of the people most affected. CO because it tests whether you can think at the organisation's level without losing the branch view |

### Case build section: the 20-minute complaint escalation

The recruiter announced this case. Its content is unknown, so the structure is a common pattern for this kind of case, labelled `[generic]`. The facts it can draw on are F1 and F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script."

**Structure (say it out loud before you use it):**
1. **Clarify.** What is the complaint, how many contacts have there been, what has the member been told, what did they ask for, are they vulnerable, and is anything time-critical.
2. **Act for the member now.** One owner, one point of contact, and a clear next step and date in plain words.
3. **Check the regulatory clock.** Regulated complaints usually carry deadlines and required written responses `[generic]`. Ask which rules apply rather than stating them.
4. **Find the root cause.** Why did three contacts not resolve it, and where did the hand-off between branch and contact centre fail.
5. **Fix the pattern.** Log it so the monthly report would catch a repeat, and coach the escalation point that failed.
6. **Close.** The member's outcome, stated plainly.

**Three defensible theses, each with its concession:**

| Thesis | Concession you say out loud |
|---|---|
| The failure is the hand-off, not the member, so one person keeps hold of it from here (Own the Fix) | Some cases have to go up a level for authority or regulatory reasons. Keeping hold of a case means staying with it, not refusing to escalate |
| Fix it for the member before fixing the process (Members First, Always) | You can't promise an outcome before you know the facts. You can promise a date and a person |
| One case is a signal for the monthly report, not a conclusion | One complaint doesn't prove a pattern. You'd check the log before calling it one |

**How to stand out from the obvious answer:** the obvious answer is "apologise, escalate, resolve". You can do better by asking which channel each contact came through and how the branch-to-contact-centre seam failed. That is the seam this role owns, and it is where hubs and digital will add new ones.

**The anti-pick (what you'd decline to do):** don't offer a goodwill payment or bypass the formal process just to calm the member before you have the facts. Say why: it fixes this member's mood, not the problem, and the next member pays for it.

**Close with:** what the member will hear, in one plain sentence.

### Reverse questions: Round 3

| Question | Why it lands |
|---|---|
| "What do your supervisors find hardest about escalations today?" | Gives you material for the coaching mandate from the people who would know |
| "What could I do in my first month that would actually help your branches?" | A reciprocity question, which peer evaluators value |
| "How are your towns taking the move to hubs?" | Shows you understand "Neighbours, Not Numbers" as their day-to-day reality |
| "Which kind of complaint does the current process handle worst, from where you sit?" | Invites them to brief you, and shows you'd start by listening |
| "How would you want your branch to appear in a monthly complaints report?" | Raises the H2 tension yourself, and it reads as respect |

---

## Sources

**Provided documents:**
- The JD
- The values text, copied by you on 26 November 2026 from ashgrovecu.org/about/values (pasted, not fetched)
- The recruiter's email
- Your summary of Ashgrove's July 2026 strategy brief
- Your background, from your message

**Searches and fetches sent:** none.

**Target accounting:**

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted this morning fixes the cheat sheet and the VAL banks |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the loop: three rounds, who runs each, the case, and the values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 strategy brief, under six months old, fixes the grounding brief and the CO and CASE questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewers have been named, so there was no query to form. The interviewer read is left out |
| 5. representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

The loop comes from a loop source, the recruiter's email, so no archetype fallback was used.

---

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for each person, persona weights set per panel member, and at least one reverse question tied to each person's own career path
- **Your CV** → dates, scope and any further roles in the fit snapshot's evidence cells, and possible evidence for F5, which your message doesn't cover
- **Your answers to the answer slots in F3, F7 and F9** (what the spreadsheet measures, whether the log's complaints were regulated, and which tool you built in) → those rows can move from `discovery` to `none` or `presentation`, and B1, C5 and the case section get firmer wording
- **The strategy brief text itself** → exact figures and wording in the grounding brief, which currently rests on your summary
- **One email to the recruiter about the case format** (pre-read or cold, and whether materials are provided) → a case build section matched to the actual format
- **Prep time available before 5 December** → a prioritised prep schedule sized to it
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent org context around Ashgrove, such as leadership changes or the hubs programme, and any published candidate reports for this role family
- **A tuesday-dossier.md** → evidence-verified grading of the gaps above, a named highest-ROI objection, and a fixed list of claims never to make
