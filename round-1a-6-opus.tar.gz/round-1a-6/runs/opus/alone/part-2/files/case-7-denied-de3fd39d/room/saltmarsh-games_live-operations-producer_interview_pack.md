# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Your relationship to him isn't stated, so this pack treats him as the likely hiring manager.
**Format:** one 60-minute interview, Friday

---

## How to use this pack

Two axes. **Personas** describe how a question arrives (who asks it and in what style). **Types** describe what is being scored:

- **VAL**: behaviour and values. Does what you've done show how you work?
- **EXP**: work-experience deep-dive. Does what you said hold up, and what was actually you?
- **JD**: the listed job. Can you do what the posting asks, gaps included?
- **CO**: company knowledge. Have you done your homework on Saltmarsh and its games?
- **CASE**: a live problem from the role, worked through out loud.

**Provenance labels:** `[grounded]` means traceable to something you gave me (quoted beside it). `[inferred]` means a derivation, which is named. `[generic]` means a role-family pattern with no claim about you or Saltmarsh.

The guidance is scaffolding, not a script. Wherever it gives you words to say, they are proposed wording, pending your approval: change anything that doesn't sound like you or isn't exactly what happened. An **answer slot** is where your material doesn't say something the interviewer is likely to ask. It always has two honest branches, and either one is a good answer.

---

## Prep triage

Friday is tomorrow, so this assumes one evening plus Friday morning.

1. **A1, the highest-ROI rehearsal in the pack.** Say it out loud three times, then do the two follow-ups. About 30 minutes.
2. **Play both Saltmarsh titles tonight** and do at least one live event in each if one is running. D3 and B1 are much stronger from first-hand play, and the research for this pack couldn't run (see Sources). About 45 minutes.
3. **B1 and B2, out loud and timed.** These are the two live problems most likely to fill the middle of the hour. About 20 minutes.
4. **D1, your 90-second journey arc.** It's the opener, so get it under two minutes. About 10 minutes.
5. **Pick your three or four reverse questions** from the list near the end. About 5 minutes.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title and a weekly content-drop calendar, not a live-events calendar across two titles, and your words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title" (pending your approval). Don't call the drops "live events" unless that's what they were. Answer slot: the two-titles line makes a probe on running parallel schedules likely. If the calendar you ran had to fit around other titles or shared teams, say how, in your own words. If it didn't, say so plainly and describe how you would plan for two |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but there's nothing inspected behind it, so expect a probe on the detail. Lead with the quote's own terms: weekly, main title, two years |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | Leading a team and coordinating teams are different things. The JD asks for coordination, and your material doesn't say whether running the calendar involved it. The plain acknowledgment, if leadership comes up: "I haven't led a team" (pending your approval). Answer slot: if running the calendar meant working with any of design, art, engineering or community on drops, say which ones and what your part was, in your own words. If it didn't, say so plainly and describe how you would set up that coordination here, as a plan |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a post-event review, and your words stay there: "Every month I presented the retention numbers to the studio head" (pending your approval). Answer slot: if you wrote or ran any review after a content drop, say what it covered. If not, say so plainly and say what you would put in one |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist is your sentence. Managing it release by release is the JD's. Your words: "I wrote the release checklist our QA team still uses" (pending your approval). Answer slot: if you also kept it updated or ran it with QA on releases, say how. If that was someone else's job or never happened, say so plainly and stay with having written it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | The two sentences together already speak to it: four years producing, two of them running a weekly content cadence. Put them next to each other: "Four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title" (pending your approval). Keep "associate producer" as your title |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting the numbers touches on the requirement but doesn't show how much you worked with them. Answer slot: if you know how they were defined (which day-N, which cohort) or you prepared them yourself, say so in your own words. If someone else produced them and you don't know how, say so plainly and say what you'd want to understand first |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | A written document a team still uses touches on this, but it isn't writing for a wider audience. Answer slot: if you wrote other things people relied on (briefs, notes, the monthly presentation), name them. If not, stay with the checklist and the fact that QA still uses it |
| F9 | A role-family pattern, not in this JD: live events on mobile titles often sit alongside in-app offers | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap you've stated, and wording can't close it. The JD doesn't name monetization, so don't raise it first. If it comes up: "I haven't worked on a game with in-app purchases" (pending your approval). Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

**The single most likely objection** is F3 against F1: coordinating four disciplines across two titles, from a background of one title and no team leadership. A1 rehearses it.

---

## Persona table

The loop is one 60-minute session with Tobias (your words). No other source on Saltmarsh's process could be read, so these weights rest on the hiring-manager pattern, not on Saltmarsh's documented process.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probes on the two-titles scale, team coordination, and the step up from associate producer | High. A Head of Live Operations hiring a producer is buying someone to run his calendar, so he'll de-risk the gaps in F1 and F3 first | Rehearse A1 until it's boring. Bridge only from your four sentences, state limits before you're asked, and give a concrete ramp plan |
| Case / Strategist | Live problems: plan a quarter, diagnose an event dip, a late fix before launch | High. This is the hiring-manager prior, and the JD is all live-operations doing | Clarify, then the objective, then the structure, then metrics and risks. Think out loud and question one premise per case |
| Data-Driven Prober | Digs into the retention numbers and how you knew drops worked | Medium. The JD names retention metrics and KPIs, and F4 and F7 are where you'd be probed | Know what you can and can't say about how the numbers were counted, and say plainly when you don't know |
| Conversational | The journey opener, what you're playing, why Saltmarsh | Medium. Almost every 60-minute hiring-manager interview opens and closes this way, and it's still scored | A tight 90-second arc, plus real first-hand play of their games |
| Pressure | Time-boxed "why you" and "how much was actually you" | Low. Nothing in the inputs suggests a stress style, but a short challenge is common | Pause, restate, anchor in what you said, and hold through two follow-ups |
| Values / Behavioral | "Tell me about a time" stories on shipping and things going wrong | Low. No values round is documented and Saltmarsh's values couldn't be read | One story per stem, chosen from what actually happened, and say so if nothing fits |
| Peer Evaluator | How you'd work the seams with community, design and QA | Low. Tobias isn't a peer, but the JD's coordination line brings these questions up in collegial packaging | Reciprocity: what you bring each team, and principles for where the seams are |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see team leadership in your background. How would you handle coordinating design, art, engineering and community on every update, across two titles?" | JD | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI rehearsal in the pack.** Open with the limit before he presses on it: "I haven't led a team." Then what you did: "For the last two years I ran the weekly content-drop calendar for our main title" (pending your approval). Answer slot: if running the calendar meant working with any of those four teams, say which ones and what your part was, in your own words. If it didn't, say so plainly and give your plan for how you'd set up coordination here. **Follow-up 1, "But two titles?"** Hold to the quote's scope ("my calendar was for our main title") and give the plan. **Follow-up 2, "What if engineering won't hit your date?"** Switch to structure: what you'd ask, what moves, who hears it. Never argue that coordinating isn't leading. Just don't let the two words merge | F3 and F1 are where the JD presses hardest on your material, so this objection will come in some form. JD because it scores the coordination line directly |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team" "never worked on a game with in-app purchases" | Name one real one, then a plan. Your material states two negatives, and neither is a JD line word for word. The JD lines your material is thinnest on are the post-event review (F4) and cross-team coordination (F3), so choose one of those if it's honestly the weakest. Say the limit plainly, then what you'd do in the first month. Don't pick a fake weakness | A Skeptic staple. JD because the honest answer has to be one of the posting's requirements |
| A3 | "If our live events run alongside in-app offers, how would you get up to speed on that side?" | JD | [grounded] "never worked on a game with in-app purchases" | Only if he raises it: "I haven't worked on a game with in-app purchases" (pending your approval). Then a learning plan, said as a plan: who you'd sit with, what you'd read in the data, which past events you'd review. Don't apologize and don't add anything to shrink the gap | F9 is a stated gap. The question's premise is a role-family pattern, `[generic]` as a claim about Saltmarsh, which is why it's asked conditionally |
| A4 | "Why leave a puzzle studio, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Answer slot: your reasons are yours, and nothing in your material gives them. Say your actual reason in your own words. If something in this JD genuinely draws you (two titles, owning a post-event review), say which line and why. Nothing negative about your current studio | Motivation consistency is a core Skeptic check. EXP because it tests your own story |
| A5 | "You've been an associate producer. This is a producer role. What's the step up for you?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Keep your title as it was. Lay out what you did in it: the weekly calendar, main title, last two years. Answer slot: if any decisions on that calendar were yours to make, say which ones. If they weren't, say so plainly and describe what you ran. Then name the part of this role that would be new, from the JD | F6 meets the title gap. JD because it tests the seniority the posting implies |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan a quarter of live events across our two titles. What do you need to know first?" | CASE | [generic] | Clarify first: each title's audience and current cadence, shared team capacity (art and engineering most of all), the KPIs that matter this quarter, and any fixed dates (platform features, seasonal moments). Then structure it: a backbone cadence per title, staggered so the two titles don't need the same team in the same week, plus buffer for late fixes. Then risks: clashes, slipping assets, QA load at release. Finish with how you'd review each event. Mention what you saw playing their games | The JD's first line, asked as a live problem. CASE because it scores structure, not history |
| B2 | "Day two of an event, participation is well below the last one. Diagnose it." | CASE | [generic] | Check the data first: is tracking right, and is the comparison like for like? Then segment by title, platform and new versus returning players, and walk the funnel: did players see the entry point, start, finish? Look outside the game too: a store feature last time, a competing launch, a bug. Then decide whether to fix, hold or extend, who you'd tell, and write it down for the post-event review | Live-ops diagnosis is the most common hiring-manager case for this role family. CASE delivery, JD content (KPIs) |
| B3 | "Engineering says a fix the event needs won't make the release cut. The event starts in four days. What do you do?" | CASE | [generic] | Clarify how bad it is: does the event break, or is it just worse? Options: ship as is, cut or swap the affected content, move the date, or take a hotfix route if one exists. Bring QA in through the release checklist, tell community early if players will notice, and make the call with the right owner, not alone | Tests the JD's coordination and release-checklist lines together, under time pressure. CASE |
| B4 | "Walk me through what goes into a post-event review you'd write for us." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: the goal and the bet, the results against KPIs (B5), what worked, what didn't, what you'd change, decisions, and owners. Keep it short. Your nearest experience, in its own words: every month you presented the retention numbers to the studio head. Answer slot: if you wrote any review after a content drop, say what it covered. If not, say so plainly and let the structure carry the answer | F4 is your thinnest line against a responsibility the JD gives this role outright. JD content. It also covers the written communication line |
| B5 | "Which KPIs would you report after an event, and which one would you trust least?" | JD | [generic] | Role-family set: participation rate, completion rate, retention of participants versus non-participants (D1 and D7), sessions per day during the event, churn just after it ends, and community sentiment. Revenue per event only if events are monetized there. For the one you'd trust least, name the weakest assumption yourself: for example, participation can be inflated if players are auto-enrolled. Ask how Saltmarsh defines them | The JD names KPIs as yours to report. JD, delivered as a light case |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The monthly retention numbers you presented: how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know the definitions (which day-N, which cohort, which date range), say them in your own words. If you didn't define them, say so plainly and say who did, if you know. "I presented them, I didn't build them" is a strong answer when it's true. Name the assumption you'd trust least, if you know one | F7 is the line a Prober will push two levels down. EXP because it tests what was actually yours |
| C2 | "Tell me about a time a retention number you presented changed what the team did next." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: a month where a number moved, someone acted on it, and you can say what your part was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (presenting the numbers monthly) or how you'd make the numbers drive decisions here | Tests "comfortable with player-retention metrics" as behaviour, not familiarity. EXP |
| C3 | "How did you know whether your weekly content drops were working?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you tracked anything on the drops, say what and how in your own words. If you didn't, or nobody did, say so plainly and say what you'd measure first (see B5) | Connects F1 to F7. JD because the posting ties events to KPIs |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only on these four sentences: four years as an associate producer at a puzzle-game studio; for the last two, the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head (pending your approval). End on why this role is the next step, in your own words | The opener, and it's scored. EXP because it sets up every probe that follows |
| D2 | "What mobile games are you playing at the moment, and what do you think of their live events?" | CO | [generic] | Answer slot: name games you actually play. One specific thing you liked in an event and one you'd change beats a list. If you play little on mobile, say what you do play and pick one live game to study before Friday | Casual, but it scores whether you think like a live-ops person. CO because it tests fluency with the market |
| D3 | "What drew you to Saltmarsh?" | CO | [generic] | The research couldn't run, so this rests on your own play tonight: name both titles, something specific you noticed in each, and one JD line that genuinely draws you. Nothing you haven't seen yourself | A preparation signal hiring managers weigh. `[generic]` because no Saltmarsh facts are in hand |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live ops with monetization?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, then hold: the calendar you ran, weekly, for two years, plus the checklist and the retention reporting if there's time. Concede plainly when pressed: "I haven't worked on a game with in-app purchases" (pending your approval). Then the plan. Hold through two follow-ups by going back to what you did, never by adding to it | F9 and F1 as one challenge. JD because it's the role's competitive bar |
| E2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it, and QA still uses it. Answer slot: if others contributed sections or reviewed it, say so and say which part was yours. If it was all yours, say that plainly | Attribution probe on F5. EXP |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to tell someone senior that something wasn't ready to ship." | VAL | [generic] | Selection scaffold: a named stake, a moment you held your position, and a working relationship still intact at the end. Use "we" for the context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | The unpopular-truth stem, set on the release-checklist line. VAL because it scores how you behave, not what you know |
| F2 | "Tell me about a time a content release went wrong. What did you do?" | VAL | [generic] | Selection scaffold: what broke, what you did in the moment, and what changed afterwards. If nothing went wrong on your watch, say so plainly and describe how you'd run the response and the review here | Raised by the JD's release-checklist and post-event-review lines. VAL delivery, JD content |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community tells you two days before an event that players will hate a change. Design disagrees. What do you do?" | CASE | [generic] | Get both views and the evidence behind each, then name who owns the call. Find the smallest change that addresses the risk (messaging, a tweak, a staged rollout), agree how you'll know which side was right, and log it for the post-event review | The JD's coordination line at the community-design seam. CASE |
| G2 | "How do you keep a release checklist with QA from turning into box-ticking?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Start from what you did: you wrote the checklist and QA still uses it. Answer slot: if you kept it current (adding steps after misses, removing dead ones), say how. If not, say so plainly and say how you'd keep it alive here | F5 against the JD's "manage" verb. JD |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1, E1 |
| Coordinate design, art, engineering and community on each update | A1, B3, G1 |
| Own the post-event review and the KPIs it reports | B4, B5, B2 |
| Manage the release checklist with QA | E2, G2, B3 |
| 3+ years producing live-service games or apps | A5, D1 |
| Experience running a content calendar | A1, C3, B1 |
| Comfortable with player-retention metrics | C1, C2, B5 |
| Clear written communication | B4, E2 (no dedicated question, because a 60-minute conversation tests it through how you describe written work) |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Are the two titles planned on one shared calendar or two, and where do they compete for the same teams?" | It goes straight at the hardest part of the job and shows you've thought about it as one system |
| R2 | "What does a post-event review here report today, and who reads it?" | It's a responsibility you'd own, and the answer tells you what B4 should have sounded like |
| R3 | "What would you change about how releases go through QA right now?" | It invites him to name a pain point you can speak to from the checklist you wrote |
| R4 | "What would make someone in this role a clear success after their first 90 days?" | It gets you his real scoring sheet and shows you're thinking about delivery |
| R5 | "How do live ops and community work together on event communication?" | It shows you've read the coordination line as more than design and engineering |
| R6 | "How big a part do in-game offers play in your events?" | It's useful to know whatever the answer, and asking calmly shows you're not avoiding a gap you've already prepared for in A3 |

(Tobias's career path couldn't be researched, so none of these ties to it. See the upgrade menu.)

---

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F3 | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases or monetization | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar, or ran one across multiple titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says a weekly content-drop calendar for the main title. A1's slot stays inside that calendar |
| Owned post-event reviews or retention KPIs | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers. B4's slot asks only whether you wrote any review |
| Managed the release process or the QA team | Inflated form of F5 | F5's quote at its own scope: you wrote the checklist QA still uses. G2's slot asks only whether you kept it current |
| Held the producer title | Inflated form of F6 | "Associate producer," as you gave it |

---

## Sources

- **Provided:** your message, with the JD text and your background.
- **Searches sent, all refused** (search permission wasn't granted in this session, so nothing came back):
  - "Saltmarsh Games values": refused
  - "Saltmarsh Games interview process live operations producer": refused
  - "Saltmarsh Games mobile studio news 2026": refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused
- No dossier was provided.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | The one search was refused. It would have given value names for VAL questions and possibly a values cheat sheet |
| 2. Saltmarsh Games interview process, live ops | unavailable | The one search was refused. It would have shown whether Friday is one round of several, and adjusted the persona weights |
| 3. Saltmarsh Games strategy and recent news | unavailable | The one search was refused. It would have named the two titles and current priorities, turning B1, D3 and R1 from `[generic]` to `[grounded]` |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The one search was refused. It would have given his public career path, an interviewer read, and a reverse question tied to his path |
| 5. Representative Live Operations Producer JD | skipped | You supplied the JD, and it fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Whether Tobias would be your manager, and whether Friday is one round of several → persona weights recomputed, and a peer or skip-level bank swapped in if needed
- Allowing web search → rows 1 to 4 above: Saltmarsh's values (VAL questions and possibly a cheat sheet), its interview process, its two titles and recent news (CO and CASE questions grounded), and Tobias's public career path (an interviewer read and a tailored reverse question)
- A deeper research pass, once search is allowed → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief, Tobias's talks or writing, candidate reports on Saltmarsh interviews, and recent org context
- Any recruiter guidance (focus areas, a task to bring) → coverage of anything pre-declared, plus a build section for any deliverable
- Your answers to the answer slots in F1, F3, F4, F5, F7 and F8 → those rows move from slots to story-mapped guidance in A1, A5, B4, C1, C3, E2 and G2
- A redacted copy of the release checklist you wrote → F5 and F8 move from claims nothing backs up to something you can show
- A `tuesday-dossier.md` from an evaluation of this role → an evidence-derived highest-ROI objection and a prohibited-claims guardrail, instead of ones inferred here
