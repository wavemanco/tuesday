# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Saltmarsh's careers page says the 60-minute interview is run by the hiring manager, so this pack treats him as your likely future manager.
**Format:** Saltmarsh calls it the "Outage Hour": "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." (saltmarshgames.com/careers/interviewing)

---

## 1. How to use this pack

- **Personas** describe how a question is asked (who is asking, and in what style). **Types** describe what is being scored.
- **Type key:**
  - **VAL**: values. Does your past behaviour show Saltmarsh's three published values?
  - **EXP**: experience deep-dive. Does what you said about your past hold up, and which parts were actually yours?
  - **JD**: the job description. Can you do the listed job, including the parts you have gaps in?
  - **CO**: company knowledge. Do you know Project Larkspur and what it changes?
  - **CASE**: a live problem. Can you structure your reasoning on the spot? The outage tabletop is one long CASE.
- **Provenance labels:**
  - **[grounded]**: comes from your message, the JD, or a Saltmarsh page listed in Sources.
  - **[inferred]**: the pack's own derivation, with the source named.
  - **[generic]**: a role-family pattern with no claim about you or Saltmarsh.
- **Answer slots** are instructions for the interview, not questions for me. Each one has two honest branches. Choose the one that is true.
- The guidance is scaffolding, not a script. Say it in your own words.
- Question bank IDs run A, B, C, D, E, G. There is no bank F, so question IDs never clash with fit-snapshot rows (F1 to F9).

## 2. Prep triage (one evening; the interview is tomorrow)

1. **C1: the season-pass / in-app-purchase question** (highest-ROI prep, 30 min). Say the acknowledgment out loud until it sounds calm, then rehearse both follow-ups.
2. **Tabletop run-through A1 → A2 → A3 → E1** (45 min). Practise the structure out loud with a timer. Expect this to take up half the hour.
3. **B3 and B4** (20 min). Your checklist is the story that best fits both Tobias's talk and "Leave the Build Greener".
4. **Decide your answer slots for F3, F4 and F5** (20 min). Work out which branch is true for you, so you aren't deciding live.
5. **Pick two reverse questions** (5 min). Include R1 or R2.

Everything else is insurance.

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes one title and content drops. The JD asks for two titles and live events. The words stay at the scope you gave: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title line makes a probe on handling more than one title likely. If you ever planned around another title's or another team's schedule, say how, in your own words. If you didn't, say so plainly and describe how you'd approach two titles, as a plan. A second slot: if any of those drops were time-limited events, say what kind. If they weren't, say what a drop was |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. It's a claim from your message with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, the main title, the last two years |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on a weekly drop calendar. It doesn't say whether the title was live for all four years. Answer slot: if the main title was a live game the whole time, say so plainly and give four. If the live part was only the calendar years, say that, and give the number that's true. This is not a gate. It's a years requirement graded like any other, and the honest count is safer than a generous one |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a calendar may have involved getting work out of other teams, but the quote doesn't show it. Answer slot: if running the calendar meant getting design, art, engineering or community to deliver for a drop, name which teams and what you did to keep them on schedule, in your own words. If it didn't, say so plainly and describe what running the calendar involved. Coordinating is not leading, so this slot is separate from your "Never led a team" |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | transferability | Presenting monthly numbers is not owning a post-event review. Your words: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared those numbers, or wrote up what drove them, say what part was yours. If someone else produced them, say who, and that your part was presenting them. If you never ran a review after a drop, say so, and describe what you'd put in one, as a plan |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect Tobias to ask which numbers they were. Answer slot: name the retention measures in those monthly numbers, and how they were counted, if you know. If you don't know how they were counted, say so plainly and stay with presenting them |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Your strongest row. Lead with it in the quote's own terms: you wrote it, and QA still uses it. Answer slot: the JD says "manage", so expect a probe on keeping it current. If you updated it after releases, say how. If someone else maintains it now, or it hasn't changed, say so |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is written work, but nothing has been inspected. Answer slot: if you can explain how the checklist is laid out and why it's still in use, do. If you're allowed to show a redacted copy, offer it. In the interview itself, E1 is where your writing gets tested live |
| F9 | Saltmarsh's two titles are moving to a season-pass model under Project Larkspur (Saltmarsh news, search result; not in the JD) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You said this yourself, so these are your words to give back: "I haven't worked on a game with in-app purchases." Follow it with how you would learn it, stated as a plan, never as experience. Add nothing that makes the gap sound smaller. C1 rehearses this |

## 4. Reading the interviewer

| Item | What's public | Provenance |
|---|---|---|
| Career pattern | Head of Live Operations at Saltmarsh Games. Previously a QA lead at a console studio. | [grounded] GDC 2026 talk listing |
| Published theme | Talk title: "Patch Notes Are a Promise". The listing summarises his argument as: "a live team is judged by how often its patch notes describe what actually shipped." | [grounded] GDC 2026 talk listing |
| Implication 1 | Expect release-quality probes: QA sign-off, checklists, and whether what you tell players matches what shipped. Persona weighting moves the Prober up because of this. | [inferred] from the talk's theme |
| Implication 2 | In the tabletop, honest player comms will probably score higher than a quick ETA. This matches the value "Ship the Patch Not the Promise". | [inferred] from the talk plus the values page |
| Implication 3 | He comes from QA, so a vague answer on the checklist would be noticed. Stay exact about what you wrote and what you didn't. | [inferred] from his career pattern |
| Mirror opportunity | You don't share a career path with him, so don't present one. You do share vocabulary through F7: "Wrote the release checklist our QA team still uses." Use B3 and B4 for this. | [grounded] F7 |

## 5. Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The outage tabletop: what you'd do, in what order, and why | **Highest.** The careers page says the first part of the hour is a live-incident tabletop, and hiring-manager rounds already lean this way | Clarify first, then: impact → people → players → event decision → record. Think aloud, and question one premise per scenario |
| Values / Behavioural | The second half: the three published values | **High.** The careers page names a values conversation | Use one story or scaffold per value (section 7). Say "we" for context and "I" for your own part |
| Skeptic | Gaps: one title versus two, no in-app purchases, post-event review ownership | **Medium-high.** A hiring manager is managing risk, and F1, F5 and F9 are visible gaps | Rehearse C1 until it bores you. Bridge only from your own sentences. Give a ramp plan |
| Data-Driven Prober | Retention numbers and checklist detail | **Medium**, raised from the hiring-manager default because of Tobias's QA background and his talk's theme | Know what you can and can't say about how each number was counted, and say "I don't know" plainly where that's true |
| Pressure | Time-boxed moments inside the tabletop ("sixty seconds, what do you post?") | **Medium-low.** A simulated outage makes time pressure part of the format | Pause, restate the question, and keep to what you actually said |
| Conversational | Opener and "why here" | **Low but certain.** Nearly every interview opens this way | Have a 90-second arc ready, built from your four sentences only |
| Peer Evaluator | Not expected | **Dropped.** The documented loop is one hour with the hiring manager, with no peer session | None |

## 6. Question banks

### A. Case / Strategist: the outage tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event on one of our titles and logins start failing. Talk me through your first hour." | CASE | [grounded] | Clarify first: which title, how many players are affected, and whether event progress is at risk. Then go in order. (1) Confirm the scope with the engineering on-call. (2) Get the right people in: engineering, QA, community. (3) Tell players what is confirmed, with no ETA you can't keep. (4) Decide what happens to the event: pause, extend, or let it run. (5) Start a timeline for the post-event review. Say the structure out loud before filling it in | The careers page says this format opens the hour. CASE because it scores structure under a live problem, and it doesn't ask about your past |
| A2 | "Engineering has a hotfix, but shipping it today means skipping part of the release checklist. Do you ship?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Don't answer yes or no straight away. Ask which items would be skipped and what risk each one covers, then find out whether QA can sign off on a reduced pass. Record what was skipped, and make sure it is run after the fix ships. Answer slot: if the checklist you wrote had an emergency or hotfix path, say how it worked. If it didn't, say so plainly and describe what you'd want one to contain | F7 makes this the place your own work meets the tabletop. It's a likely follow-up given Tobias's QA background. CASE because the decision is live |
| A3 | "It's fixed, but players lost six hours of event progress. What do you do for them, and what do you tell them?" | CASE | [grounded] | Use both values here. "Players Before Plans": extend the event or restore progress before protecting the original calendar. "Ship the Patch Not the Promise": tell players only what is fixed and confirmed. Outline compensation options and how you'd choose between them, then what goes into the review | The values page supplies both principles, so this is the obvious way into the values half of the hour. CASE because it's a decision, not a memory |
| A4 | "From February both titles share one events calendar. How would you plan the first month so they don't collide?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: shared teams, art and engineering capacity, and QA windows. Then stagger the peak events, protect release slots, build in buffer days, and set a regular review. Answer slot: if two drops ever competed for the same people or the same slot on your calendar, say how it was settled and what part was yours. If that never came up, say so plainly and answer as a plan | Project Larkspur (Sources) makes this a live problem for this role. F1 is the adjacent evidence. CASE, with company knowledge in the content |
| A5 | "After the outage weekend, walk me through the post-event review you'd write. Which KPIs go in it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: what happened, the timeline, the impact on players, how the event did against what was planned, retention afterwards compared with before, and what changes in the checklist. Answer slot: if you prepared the monthly retention numbers or wrote anything about what drove them, say what part was yours. If your part was presenting them, say so, and give this answer as a plan | This tests the JD's post-event review line, which is where F5 is thinnest. It's tagged JD because it scores that requirement, with a CASE format |

### B. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our first value is Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time from your calendar years when a planned drop moved, changed or was cancelled because of what players were doing or saying. It needs the plan, the player signal, what you did, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | This is the value's own wording, from the values page. F1 is the window you'd look in, but no quote carries a story, so this is a scaffold |
| B2 | "Ship the Patch Not the Promise: tell me about a time you pushed back on announcing something before it was ready." | VAL | [grounded] | Selection scaffold: a time something was about to be promised to players or the studio before it was built, and what you said or did. It needs the stake, your move, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | This value matches Tobias's talk, so it's likely to be asked. Nothing in your material carries a story for it yet |
| B3 | "Leave the Build Greener: what did you leave better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F7. The beats are the ones the quote states: you wrote the release checklist, and QA still uses it. Answer slot: if it replaced an earlier process or fixed a recurring problem, say what, in your own words. If it was the first one, or you don't know why it was needed, say so and stay with the fact that it's still in use. Don't say what it proves. Describe it and let Tobias draw the conclusion | F7 is your best story, and the value names "the checklist" outright. VAL because it scores a published value |
| B4 | "How would you know whether your patch notes describe what actually shipped?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Outline a check: compare the draft notes against what QA verified in the build before publishing, and remove anything unverified. Answer slot: if your checklist had a step linking release notes to what QA checked, say so. If it didn't, say so plainly and propose one | This comes straight from Tobias's GDC talk. It's tagged VAL because it tests "Ship the Patch Not the Promise", with a CASE format |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Highest-ROI prep.** "Both titles are moving to a season pass. What's your experience with monetised events: in-app purchases, passes?" | CO | [grounded] "never worked on a game with in-app purchases" | **Name the limit before he does:** "I haven't worked on a game with in-app purchases." Then give your plan: how you'd get up to speed on season-pass design before February, stated as a plan. Then what does carry over, at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." **Follow-up 1:** "So what do you know about season passes?" Answer only with what you actually know, and say where it runs out. Don't recite research. **Follow-up 2:** "So I'd be training you on monetisation." Concede exactly that point: yes, on monetisation. Hold on the calendar and the checklist, using the F2 and F7 quotes. Never suggest that a puzzle game's economy counts as purchase experience unless that's true | F9 is the gap you stated, and Larkspur (Sources) means it will come up. CO because it's driven by strategy. It gets the deepest rehearsal because a calm limit, said first, turns the riskiest moment into a credibility gain |
| C2 | "You've run one title's calendar. This is two titles on one calendar. What breaks first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the premise: yes, one title. Then answer the question as a plan: shared-team capacity, QA windows, and community comms for two player bases. Answer slot: if your calendar ever had to fit around another title or team, say how. If it didn't, say so plainly | F1 is a transferability gap, and the JD's two-title line points straight at it. JD because it scores the calendar requirement |
| C3 | "This role coordinates design, art, engineering and community. When have you had to get work out of people who didn't report to you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Never led a team" | Answer slot: if running the calendar meant getting other teams to deliver for a drop, name the teams and what you did to keep them on schedule, in your own words. If it didn't, say so plainly and describe what the calendar involved. If he asks about leading people, your words: "I haven't led a team." Coordinating without authority is the question here, and it is separate from that | F4 is a discovery gap. The JD names four teams. JD because it scores that line |
| C4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Pick one real gap and name it calmly. F5, owning the post-event review, is the honest candidate: "I presented the monthly retention numbers to the studio head," and then which branch of the F5 slot is true for you. Add a short ramp plan. Don't choose a fake weakness | This is the Skeptic's standard opener. F5 is the thinnest row of the JD's own requirements |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented monthly retention numbers. Which numbers, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Four slots, all in your own words. (1) Which measures they were, and how they were counted. (2) What moved them. (3) The assumption behind them you'd defend least. (4) Which part was yours. "I don't know how it was counted" is an honest answer. Don't name a metric you didn't present | F6 is the retention evidence, and this probe comes up wherever numbers are mentioned. EXP because it tests what you actually did with them |
| D2 | "Did retention ever move after one of your drops? How would you know it was the drop?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Presented the monthly retention numbers to the studio head." | Answer slot: if you ever linked a drop to a change in retention, say how, and which part of the work was yours. If you didn't, say so plainly. Then say how you'd separate the effect of an event from the noise, as a plan | This links F1 and F6 under the JD's retention requirement |
| D3 | "This role manages the release checklist with QA. Walk me through the one you wrote." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Describe what it covers and why each section is there, in your own words. Answer slot: if you updated it after releases, say how. If someone else maintains it, say so. If you can share a redacted copy, offer it | F7 sits directly on the JD's checklist line, and Tobias comes from QA |
| D4 | "The role asks for three-plus years producing live-service games. How many of your four count?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Use the F3 answer slot: give the number that is true, and say what the years before the calendar involved. Don't stretch the count | F3 is a discovery gap, and years requirements are often checked literally |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | (interrupting the tabletop) "Sixty seconds. Players are flooding the community channels. What do you post, word for word?" | JD | [generic] | Pause, then draft it aloud. Acknowledge the problem, say what is confirmed, say what you're doing, and say when the next update will come, not when the fix will. Keep it short, and promise nothing unconfirmed | The JD asks for clear written communication, and this tests it live. JD content with a CASE delivery. It's generic because no Saltmarsh template was found |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it. Answer slot: if others added items or it built on an earlier list, say so plainly and say which part was yours. Don't make your share bigger or smaller than it was | This is the Pressure persona's attribution stem, aimed at F7, your strongest claim. It's a test of honesty |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc built from those four sentences, in that order, then one line on why live ops at Saltmarsh. Nothing beyond them | The opener sets the frame Tobias listens through. Keep it to what you can defend |
| G2 | "Why Saltmarsh, and why now?" | EXP | [grounded] | Answer slot: give your real reason in your own words. If Larkspur's shared calendar is part of the appeal, you can say so, because it's public. Don't make up a reason for leaving | Every interview asks this, and your material doesn't give your reason, so this is a slot |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A4, C2 |
| Coordinate design, art, engineering and community teams | C3, A1 |
| Own the post-event review and its KPIs | A5, C4 |
| Manage the release checklist with QA | D3, A2, E2, B3 |
| 3+ years producing live-service games or apps | D4 |
| Experience running a content calendar | C2 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | E1 |

## 7. Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (B1), searched within F1's "I ran the weekly content-drop calendar for our main title for the last two years." You need a drop that changed because of players. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (B2). Nothing in your material carries a story yet. If no time comes to mind, say so plainly, then give how you would handle it. Pair it with B4 |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F7: "Wrote the release checklist our QA team still uses." (B3) |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued that a live team is judged by how often its patch notes match what shipped. How do you track that here?" | It's tied to his own published work, and it shows you researched him, not only the company |
| R2 | "You came to live ops from QA. How does that shape how the live-ops group runs releases?" | It's tied to his career path, and it opens the topic where your checklist work fits |
| R3 | "With per-title event teams retired under Larkspur, how will this role split its time between Tidepool Tactics and Lantern Row?" | It shows you know the strategy and asks about the real shape of the job |
| R4 | "What does a good post-event review look like here? Is there one you'd point to?" | It's the requirement where you most need to calibrate, and his answer tells you what the standard is |
| R5 | "When has Players Before Plans actually moved the calendar?" | It asks how a value works in practice, which values conversations reward |
| R6 | "What would you want this person to have done by the time the shared calendar goes live in February?" | It gives you a concrete success measure and moves the conversation toward working together |

## 9. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has run a live-events calendar for multiple titles | Inflated form of F1 | F1's quote at its own scope. The pack observes that your material says one title and content drops. C2's slot stays inside that calendar |
| Four years producing live-service games | Inflated form of F3 | F3's quotes at their own scope. D4's slot asks for the count that is true |
| Has owned post-event reviews or set event KPIs | Inflated form of F5 | F5's quote at its own scope: "I presented the monthly retention numbers to the studio head." A5's slot stays inside that |
| Built or analysed retention metrics | Inflated form of F6 | F6's quote at its own scope. D1's slots ask only what you know about how the numbers were counted |
| Ran QA or owns the QA process | Inflated form of F7 | F7's quote: you wrote the checklist, and QA still uses it |
| Has led a team | A negative you stated ("Never led a team") | "I haven't led a team." No slot |
| Has worked on in-app purchases, season passes or monetised events | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |

## 10. Sources

- Provided: the JD text and your background, both from your message.
- Search: `Saltmarsh Games values`. Returned https://saltmarshgames.com/values
- Search: `Saltmarsh Games interview process producer`. Returned https://saltmarshgames.com/careers/interviewing
- Search: `Saltmarsh Games mobile studio news 2026`. Returned https://saltmarshgames.com/news/project-larkspur (September 2026; Larkspur facts come from the search snippet only, since the page was not fetched)
- Search: `Tobias Wrenfield Saltmarsh Games`. Returned https://talks.gdconf.example/2026/patch-notes-are-a-promise
- Fetch: https://saltmarshgames.com/values. The three values and their definitions.
- Fetch: https://saltmarshgames.com/careers/interviewing. The Outage Hour format.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, bank B, and A3: three values by official name |
| 2. `Saltmarsh Games interview process producer` | yes | Loop established: one 60-minute hiring-manager session, a tabletop then a values conversation. Sets the persona weights and the A bank, adds section 7, and drops the Peer persona |
| 3. `Saltmarsh Games` strategy / recent news | yes | Project Larkspur: A4, C1, F9, R3, R6 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, B4, R1, R2, and the Prober weighting |
| 5. Representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- **A redacted copy of your release checklist**, if you're allowed to share it → the inspectable artifact that would raise F7 and F8. You could also offer to show it in D3.
- **Your own answers to the answer slots on F3, F4 and F5**, told to me outside a drill → those rows, and C3, C4, D4 and A5, become story-mapped instead of slots.
- **Your CV text** → more of your own sentences to quote, especially for B1 and B2, which are scaffolds right now.
- **Any prep note from the recruiter** → their stated focus areas, folded into the weights.
- **Deep research (L2):** up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Larkspur from the full page, the content of Tobias's talk rather than only its listing, and candidate reports on the Outage Hour.
- **A `tuesday-dossier.md`** → carries this pack's gaps and objections into later sessions, and would bind the prohibited list to a verified record.
