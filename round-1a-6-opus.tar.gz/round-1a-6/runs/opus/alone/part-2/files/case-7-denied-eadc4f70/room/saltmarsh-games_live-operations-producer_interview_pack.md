# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations — assumed to be the hiring manager for this role (not confirmed)
**Format:** one 60-minute interview, Friday
**Candidate:** Femi

---

## How to use this pack

- **Personas** describe *how* a question is asked (the style). **Types** describe *what* is being scored.
- Type key:
  - **JD** — can you do the job as listed, gaps included
  - **EXP** — does your stated experience hold up under follow-up; what was actually you
  - **CASE** — a live problem from the role, reasoned out loud
  - **VAL** — behaviour and judgement stories
  - **CO** — company and strategy homework (none in this pack: research could not run)
- Provenance labels: `[grounded]` means traceable to your JD or your own sentences; `[inferred]` means derived from them, with the derivation named; `[generic]` means a pattern for this kind of role, with no claim about Saltmarsh or about you.
- IDs: F1–F8 are fit-snapshot rows. Question banks use A, B, C, D, E, G, H (F is skipped so the two never collide).
- **Answer slots** are instructions for the interview, not questions for now: each has two honest branches, and either one is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## Prep triage — interview is tomorrow, so one evening

1. **B1, out loud, three times** — the highest-ROI prep in this pack. Get the hold and the answer slot boring.
2. **B2 and B3** — the two plain acknowledgments. Say each sentence aloud until it comes out flat and unapologetic, then go straight to the plan.
3. **C1** — decide, before you go in, what you can and cannot say about how the monthly retention numbers were counted.
4. **A1 and A4** — run the case structure aloud once each: calendar planning, then post-event review.
5. **D1** — time your 90-second arc.
6. **Reverse questions** — pick three.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one named title, not a live-events calendar across two, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one title likely. If you have planned across more than one title at once, say how, in your own words; if you have not, say so plainly and describe how you would extend your calendar approach to two, as a plan |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your material does not show which teams a drop involved or what your part with them was. Leading a team and coordinating teams are different things, so the stated negative about leading does not answer this row either way. Answer slot: if running the calendar meant working with design, art, engineering or community on drops, say which teams and what that work was, in your own words; if it did not, or that sat with someone else, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly retention numbers is adjacent to owning a post-event review, and does not reach it on its own. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you reviewed what a drop did after it shipped, say how and what you reported, in your own words; if there was no such review, or it was not yours, say so plainly and describe how you would run one, as a plan |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Writing the checklist is strong adjacent evidence; the material does not say whether you also ran it with QA release to release. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you worked it through with QA on each release or revised it with them, say how, in your own words; if that was QA's or someone else's, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Four years as an associate producer clears the count; the material does not say whether all four were on a live-service title. Answer slot: if the title had live content through all four years, say so and what your part was before the last two; if live content only began, or only reached you, in the last two, say so plainly and stay with the two years you ran the calendar. Resolve it downward, never up |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms — weekly, your main title, the last two years — because a named calendar beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the quote's terms, but a prober will ask what sat behind the presentation. Keep the verb: you presented them, monthly, to the studio head. Whether you also counted or analysed them is C1's answer slot, not something to say here |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A checklist a QA team still uses is one written artifact, and a good one; it does not by itself cover the event comms, reviews and updates the role writes. Words: "I wrote the release checklist our QA team still uses." Let the interviewer draw the inference about your writing |

---

## Persona table

The loop is set by your own words: one 60-minute session, run by Tobias. Weights assume he is the hiring manager — not confirmed, and the first thing to correct if wrong.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | "Plan next quarter's events", "this metric dropped, diagnose it", "art is late, what now" | High — a hiring manager buys capability, and a Head of Live Ops will test the job on its own problems | Clarify, then objective, then structure, then metrics, then risks. Think aloud. Challenge one premise per case, politely |
| Skeptic (bank B) | Quiet probes on the step from associate producer to producer, on two titles, on the gaps in your message | High — hiring-manager prior, and F1, F2 and F5 are where the JD presses hardest on your material | Rehearse B1 until it is boring. Hold on what your quotes say, concede plainly what they do not, then give a plan |
| Data-Driven Prober (bank C) | "How were those retention numbers counted?" "How do you know a drop worked?" | Medium — the JD makes post-event KPIs this role's output, and your one stated metric habit is the monthly retention numbers | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (bank D) | The opener, "why live ops", "why us" — friendly and still scored | Medium — almost every 60-minute hiring-manager interview opens and closes this way | Time a 90-second arc built only from your own sentences; never answer the reverse-question slot with "you've covered everything" |
| Pressure (bank E) | "Sixty seconds: why you?" "How much of that was actually you?" | Low — no signal he interviews this way, but one pointed attribution question is common | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |
| Peer (bank G) | Seam questions between community, engineering and QA | Low — he is not a peer, but this role sits on every team's seam, so expect one | Propose seam principles rather than pretending to know their seams; say what you would bring each team |
| Values / Behavioral (bank H) | "A time you told leadership something unwelcome" | Low — no values round is named in your session, and Saltmarsh's published values could not be researched | Pick a real story or say plainly none comes to mind; "we" for context, "I" for your part |

---

## Question banks

### A — Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're handed next quarter's events calendar for both titles. How do you plan it — what do you need to know first?" | CASE | [generic] | Clarify first: each title's audience and current cadence, fixed dates (seasonal moments, platform or store features), what recent events showed, and how much design, art, engineering, community and QA time each event costs. Then build one shared view across both titles so the two never compete for the same people in the same week; set lead times per discipline backwards from each date; define each event's success measure before it ships; name the risks you would watch. The question needs no claim about your past, so this makes none | F1's requirement asked as a live plan. CASE because it scores structure; it also covers the JD's live-events and content-calendar lines |
| A2 | "Three days into a week-long event, retention among players in the event is below the last comparable event. Diagnose it." | CASE | [generic] | Check the number first: same cohort definition, same day count, tracking intact. Segment: new vs returning, platform, region, players who started vs finished the event. Then causes: event-side (difficulty, rewards, how players find it, bugs), outside (store featuring, holidays, competing launches). Separate what you can change mid-event from what goes into the post-event review. Say what you would tell the team today | F7's and F3's requirements under pressure of time; CASE because the interviewer scores the order you reason in, not the answer |
| A3 | "Art tells you the event's key assets will land four days late, and the date is already announced to players. What do you do?" | CASE | [generic] | Confirm what exactly is late and what is not. Lay out options: cut scope, reuse existing assets, split the event, or slip the date. Name who decides, bring community in early if players will see a change, and record the cause for the post-event review. No claim about your past is needed | The JD's coordination line (F2) as a live problem; CASE because it tests decisions across design, art and community rather than a record |
| A4 | "What goes into a good post-event review, and which KPIs would you report?" | JD | [generic] | Structure: the goal set before launch, results against it, what players did (participation, completion, retention of participants vs non-participants), what broke and why, what to change, owners and dates. If the title has in-app purchases, revenue measures belong too — ask which ones the team reports rather than guessing. Do not present this as how you have run reviews; F3's slot is where your own experience goes, if asked | The JD names the post-event review and its KPIs as this role's own; JD because it scores the stated responsibility, with CASE delivery |
| A5 | "Both titles want to ship an update the same week and QA can only take one properly. How do you sequence them?" | CASE | [generic] | Clarify: what each update carries, which is tied to a player-facing date, risk of each, and whether either can split. Decide on player impact and risk, not on who asks loudest. Say who you would bring in, how the release checklist gates each, and how you would tell the team whose update moves | The JD's release-checklist and two-titles lines (F4, F1) together; CASE because it tests trade-offs live |

### B — Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update, across two titles. What have you coordinated yourself, and how?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "4 years as an associate producer at a puzzle-game studio" | **The highest-ROI rehearsal in this pack.** Open with the hold: "I was an associate producer for four years, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: if running the calendar meant working with design, art, engineering or community on drops, say which teams and what that work was, in your own words; if it did not, or that sat with someone else, say so plainly — it is a limit, not a confession. Then two titles: if you have planned across more than one at once, say how; if not, say so and give your plan for two. Follow-up one ("but you were an associate"): keep the title as it is and return to the calendar you ran. Follow-up two ("so who actually ran the teams?"): concede exactly what your slot answer said, no more, no less. Never add a team, a meeting or a conflict your answer did not contain | F2 is the thinnest row against the JD's central line, and F1 and F5 sit beside it, so this objection arrives in some form. JD because it scores the stated responsibility; the deepest follow-ups are here because the material is thinnest here |
| B2 | "Have you led a team?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment, said flat: "I haven't led a team." Then return to what you did: "For the last two years I ran the weekly content-drop calendar for our main title." Do not reach for "led without authority" or similar — your material does not say it. If they push on how you would grow into it, answer as a plan, in the future tense | The JD does not ask for team leadership, but the step from associate producer to producer makes the question likely `[inferred]`. EXP because it tests honest self-assessment on your own stated negative |
| B3 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: how you would learn the titles' economies in your first weeks and who you would learn from. Never imply familiarity from playing such games or reading about them unless you would say exactly that, in those words | The JD does not mention in-app purchases; on mobile live-service titles, events are often tied to them `[generic]`, which is not established for Saltmarsh. EXP because it is your stated negative |
| B4 | "The role asks for 3+ years producing live-service games. How many of your four years were live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" | Lead with the quotes: four years as an associate producer; the last two running the weekly content-drop calendar. Answer slot: if the title had live content through all four years, say so and what your part was before the last two; if live content only began, or only reached you, in the last two, say so plainly. Never round up — "four years of live ops" is not in your material | F5 is the one count the JD states, and your material leaves its live-service part open. JD because it scores a listed requirement literally |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick one honestly and say it in one sentence — B3's acknowledgment is the cleanest, because you stated it. Then a concrete ramp plan, as a plan: what you would learn, from whom, by when. Do not pick a fake weakness, and do not stack three | A stock Skeptic question that a prepared answer turns into a credibility gain; JD because it asks you to score yourself against the listed job |

### C — Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Those monthly retention numbers you presented — how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The quote states you presented them, monthly, to the studio head — start there. Then four answer slots, each in your own words: which retention measure it was and how it was counted; what it was sensitive to; the assumption behind it you would defend least, named before they ask; and which part was yours — pulling, calculating, interpreting or presenting. If you do not know how it was counted, say so plainly and say who did — "I presented them" is an honest answer and a complete one | F7 and F3 rest on this line, and a Head of Live Ops reporting KPIs will probe it. EXP because it tests what sat behind the number |
| C2 | "Tell me about a time a number changed what went on the content calendar." | JD | [grounded] "Presented the monthly retention numbers to the studio head" "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a month where what the numbers showed changed a drop — it needs the number, the change, and what was your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — presenting the monthly retention numbers, running the calendar — or how you would use the numbers to shape a calendar | Joins F6 and F7, the two rows where your material is strongest; JD because the role links KPIs to the calendar |
| C3 | "How did you know whether a weekly drop worked?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if drops were measured, say what was measured and how, and which part was yours, in your own words; if there was no per-drop measure, or it was not yours, say so plainly and say what you would measure first | F3's requirement, asked from F6's evidence; JD because it scores the post-event KPI line |

### D — Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | A 90-second arc in four beats, one per quote: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for your main title; writing the release checklist your QA team still uses; presenting the monthly retention numbers to the studio head. Close with why this role — your own reason, in your own words. Time it; stop at 90 seconds | The biography opener is near-certain and scored on economy; EXP because the arc is your record, and it lines up with F6, F4 and F7 |
| D2 | "Why live ops — and why Saltmarsh?" | JD | [generic] | Answer slot: say your own reasons for each, in your own words. Research on Saltmarsh could not run, so do not state facts about the studio or its titles from memory; if you have played their games or read about them, say exactly what you did | A casual motivation question that is still scored; JD because it tests fit with the role as listed. `[generic]` because the pack holds no Saltmarsh facts |
| D3 | "What's something you've written that a team actually relied on?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F8: you wrote the release checklist, and your QA team still uses it — those are the beats the quote states. Answer slot: the JD's checklist-with-QA line makes a probe on keeping it current likely; if you revised it with QA over time, say how, in your own words; if you did not, say so plainly and stay with having written it | The JD names clear written communication; F8 and F4 share this quote. JD because it scores the listed requirement |

### E — Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who's already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Never led a team, and never worked on a game with in-app purchases" | Pause. Concede the premise in one line: "I haven't worked on a game with in-app purchases." Then hold on what you did: two years running the weekly content-drop calendar for your main title, and the release checklist your QA team still uses. End on the plan for the gap, not on a claim to learn faster than anyone. If interrupted, finish the sentence you are on and return to the calendar | Combines B3's gap with time pressure; JD because it scores you against the listed job in comparison |
| E2 | "That release checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold on the quote: you wrote it. Answer slot: if others shaped it — QA, a lead, a template — say who and how, in your own words; if no one else did, say so plainly. Concede only what is true, and do not trade "wrote" for a bigger verb | F4 and F8 both rest on this line, so it will be tested; EXP because it is an attribution probe |

### G — Peer (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Community wants to announce an event date before engineering will commit to it. Where's the seam, and what do you do?" | CASE | [generic] | Name the seam: community owns what players hear, engineering owns what can ship. Propose a principle — no public date without an engineering commit, or a public window instead of a date — and say how you would get both sides to agree it once rather than every event | The JD's coordination line (F2) as a seam problem; CASE because it tests judgement between teams |
| G2 | "QA says the release checklist slows them down. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure: find which items cost the most time and which catch real problems, cut or merge the rest, agree changes with QA, try it for a few releases. Answer slot: if you have faced this with the checklist you wrote, say what happened, in your own words; if not, say so and answer as a plan | The JD's checklist-with-QA line (F4); CASE because it is a live problem, with your own checklist as the natural anchor |

### H — Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: a time you delivered unwelcome news upward — it needs what the news was, how you said it, and what happened next. If a month's retention numbers were bad news you presented, that may be the story, but only if it happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — presenting the monthly numbers — or how you would handle it | Persona stem; F7's quote is the nearest candidate story, but the material does not say any month was bad news. VAL because it scores behaviour |
| H2 | "When did you put players ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where what was right for players cost a number in the short term — it needs the decision, the trade-off, and your part. If no such time comes to mind, say so plainly, then say how you would handle it | Persona stem adapted to players; `[generic]` because Saltmarsh's values could not be researched. VAL because it scores judgement |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A5, B1 |
| Coordinate design, art, engineering and community on each update | B1, A3, G1 |
| Own the post-event review and its KPIs | A4, A2, C3 |
| Manage the release checklist with QA | A5, D3, E2, G2 |
| 3+ years producing live-service games or apps | B4 |
| Experience running a content calendar | A1, C2, D1 |
| Comfortable with player-retention metrics | C1, C2, A2 |
| Clear written communication | D3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who reads it?" | The JD makes it this role's own output; asking shows you are already thinking about what you will hand in |
| R2 | "How are the two titles' calendars planned today — one shared view or separately?" | Goes straight to the two-titles line, and the answer tells you where the work is |
| R3 | "Which KPI do you look at first after an event?" | Invites his own view as Head of Live Operations, and tells you what you will be judged on |
| R4 | "Where does the release checklist with QA stand today, and what would you change first?" | Ties to the line where your material is strong, without claiming anything |
| R5 | "What would make the first 90 days in this role a success, from where you sit?" | Turns the interview into planning together, and the answer is your onboarding brief |
| R6 | "How did you come to lead live operations here?" | A conversation about his own path; no public profile could be researched, so ask it openly |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases" | "I haven't led a team." Then the calendar you ran |
| Has worked on a game with in-app purchases, or on event monetization | Negative you stated: "Never led a team, and never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then a plan, as a plan |
| Planned and ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the weekly content-drop calendar for your main title. B1's slot stays inside that calendar |
| Owned post-event reviews and their KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers to the studio head. C3's slot asks only what was measured |
| Analysed or built the retention numbers | Inflated form of F7 | F7's quote at its own scope: presented. C1's slot asks which part was yours |
| Managed the release checklist with QA release to release | Inflated form of F4 | F4's quote at its own scope: you wrote it and QA still uses it. D3's and E2's slots stay inside that |
| Four years of live-service producing | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer; the last two running the weekly content-drop calendar. B4's slot settles the rest |

---

## Sources

- Provided: the JD text you pasted; your background, from your message.
- Searches sent, all refused by this session's permissions (nothing returned):
  - "Saltmarsh Games values" — refused
  - "Saltmarsh Games interview process producer" — refused
  - "Saltmarsh Games mobile studio news 2026" — refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search refused. Would have supplied official value names to theme bank H and, if a values-style round were documented, a values cheat sheet |
| 2. Saltmarsh Games interview process | unavailable | Search refused. Would have shown whether this session is one of several rounds and what it holds; weights rest on your words plus the hiring-manager assumption instead |
| 3. Saltmarsh Games strategy and recent news | unavailable | Search refused. Would have grounded a CO question and sharpened D2 and the reverse questions on the two titles |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Search refused. Would have supplied an interviewer read, persona weights from his public footprint, and a reverse question tied to his path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Whether Tobias is your future manager, and whether this is the only round → persona weights confirmed or recomputed; banks reordered if he is a skip-level or a panel lead
- The recruiter's prep email or any stated focus areas → coverage of anything pre-declared, such as a presentation or calendar exercise, as its own build section
- Web search allowed → targets 1–4 rerun: Saltmarsh's published values theming bank H, the documented interview process, a CO question on the two titles, and an interviewer read with a reverse question tied to Tobias's path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Saltmarsh's titles and recent moves, and his talks or writing if any exist
- Your full CV → more quoted sentences, so the selection scaffolds in C2, H1 and H2 can become story-mapped answers
- Your answers to the slots in B1, B4 and C1 → F2 and F5 move off `discovery`, and the three highest-pressure rows become story-mapped
- An inspectable artifact — the release checklist itself, redacted, or a monthly retention deck you presented → F4, F8 and F7 can rise from medium to high confidence
- A tuesday-dossier.md → the objection for B1 derived from verified evidence rather than inferred here, and a prohibited-claims list checked against confirmed claims
