# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Interviewer not named.
**Built from:** your `tuesday-dossier.md` (v1.1, generated 2026-08-14). No company research. The web searches this pack tried were refused (see Sources).

---

## How to use this pack

- **Personas** describe *how* a question is asked: who asks it and in what style. **Types** describe *what* is being scored.
- Type key:
  - **JD**: can you do the job as listed, gaps included
  - **EXP**: does what you've said about your past hold up, and how much of it was yours
  - **CASE**: how you structure a live problem from this role
  - **CO**: company and strategy knowledge (none in this pack, because there was no research)
  - **VAL**: behaviour against published values (themed here by the JD, since no values were researched)
- Provenance labels: `[grounded]` means it traces to your dossier. `[inferred]` means it is this pack's own derivation, with the derivation named. `[generic]` means a role-family pattern that makes no claim about you or Quartzline.
- **The guidance is scaffolding, not a script.** Every sentence about your past comes from one of three confirmed sentences in your dossier (VE1 to VE3, listed under Sources). An **answer slot** marks a point where the interviewer will probe something your material doesn't show. Answer it from what actually happened, and either branch is a good answer.
- **Highest-ROI prep in the pack: A1.** Your dossier named this objection.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | low | [inferred] | transferability | Bridge. Position it as adjacent work, never as PM experience (the dossier's condition). Words at the quotes' own scope: "I led 30-plus end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and I ran quarterly roadmap-input sessions feeding client evidence to product." State the limit yourself before you're asked: this is work next to product management, not product management. VE3 is confirmed but has little inspectable proof behind it, so say that before a prober finds it. Derivation: the dossier's bridge strategy for R1 |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities; the dossier's R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this as a capability gap whose only allowed strategy is acknowledge_gap. Words, sourced from prohibited_claims "Having owned a product roadmap" and "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then give a ramp plan, said as a plan and never as something you've done. No bridge, no slot, and nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1 | high | [grounded] | transferability | VE1 is inspectable (the dossier notes a playbook was provided). Words at the quote's scope: "I led 30-plus client integrations of the vendor's REST APIs through to go-live." The pack's own observation of the limit: the material shows you led integrations of the vendor's APIs. It does not show you building or shipping the API product itself. Answer slot: the JD's "Shipped API or platform products" line makes a probe on what went live likely. If part of what went live was something your team built rather than configured, say what, in your own words. If not, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Wrote the internal integration playbook her team uses" — dossier VE2 | high | [inferred] | discovery | Both quotes touch the requirement (REST API integrations, an architecture stage, a playbook) but don't show work with docs or schemas. Answer slot: the JD's "API docs, schemas" makes a hands-on probe likely. If your scoping or architecture work meant reading or writing API docs or schemas, say which and how, in your own words. If it didn't, or someone else did that part, say so plainly and stay with the integrations you led and the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier VE1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier VE3 | medium | [inferred] | discovery | The quotes reach clients (client integrations) and product (sessions feeding client evidence to it). They say nothing about engineering or sales. VE3 is medium (confirmed, limited inspectable proof), so volunteer that. Answer slot: the JD's "across engineering, sales, customers" makes a probe on each likely. If you worked with engineering or sales on those integrations, say how, in your own words. If not, say so plainly and stay with the clients and the product input |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | The dossier's strategy here is clarify, and no verified entry speaks to agile delivery itself. Answer slot: the JD's "Agile delivery experience" line makes the probe likely. If those integrations ran in sprints or another agile practice, say how, in your own words. If you never worked that way, say so plainly. Then: "Here's what I'd want to confirm about how your squads run delivery: the cadence, who owns the backlog, and how a spec gets into a sprint" |

The dossier's decision summary also mentions years of integration leadership. No verified entry states a tenure, so this pack doesn't put a figure in your mouth. Use your actual years (see D1 and the upgrade menu).

---

## Persona table

The loop is set by your own words: one 45-minute conversation with the hiring manager. These weights start from the hiring-manager prior (Case/Strategist plus Skeptic). Your dossier's named objection moves the Skeptic to the top. There is no interviewer profile, so nothing else adjusts them.

| Persona | How it shows up in this conversation | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the missing PM title and roadmap ownership, plus "why now" | Very high. A hiring manager is de-risking a gap, and the dossier names exactly this objection | Rehearse A1 until it's boring. Concede first, bridge only from VE1 to VE3 at their scope, then give a ramp plan |
| Case / Strategist (B) | "How would you…" problems taken from the JD's responsibilities: the roadmap, discovery, adoption metrics, the squads | Very high. A hiring manager buys capability, and live problems are the one place you need no past claim | Clarify, set the objective, segment, give the approach, the metrics, the risks. Think aloud and challenge one premise per case |
| Data-Driven Prober (C) | Follows up on the 30+ figure and on the technical stages of the integrations | Medium. Your headline figure is the obvious target, and R3 invites hands-on questions | Know how the 30+ was counted. Name your weakest assumption first, and say plainly what you don't know |
| Conversational (D) | The opener ("walk me through your journey") and casual questions about the playbook | Medium. Most hiring-manager conversations open this way, and those answers are still scored | A pre-built 90-second arc from VE1 to VE3 |
| Pressure (E) | Time-boxed versions of the objection, or "did any of it actually change anything?" | Low to medium. Nothing signals a stress interviewer, but the objection invites a sharp form | Pause, restate the question, hold through two follow-ups, then concede specifically |
| Values / Behavioral (V) | Behavioural "tell me about a time" questions themed by the JD's stakeholder line | Low. No values round is documented and no values were researched | Selection scaffolds with honest branches |
| Peer Evaluator (P) | How you'd work with the two squad leads. The hiring manager may ask this on the leads' behalf | Low. It's not a peer round, but the squad-authority unknown makes the question likely | Propose principles for where your role meets theirs instead of pretending to know it, and clarify decision rights |

---

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role", "Having owned a product roadmap", "Having set prioritization for an engineering squad" | **Highest-ROI rehearsal; your dossier named this objection.** (1) Concede first and plainly: "I haven't held the PM title, and I haven't owned a roadmap." (2) What you did, at its own scope: "I led 30-plus end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. I wrote the integration playbook my team uses. And I ran quarterly roadmap-input sessions feeding client evidence to product." Name the limit on the third before you're asked: it was input to product, and there's little to show for it. Describe the work and let them draw the conclusion. Don't call it proof that you can do the job. (3) The ramp, as a plan: what you'd learn first and from whom, the squad leads and partners included. **Follow-up 1:** "What's the closest you've come to a prioritization call?" Don't reach for one. Say "I haven't set priorities for an engineering squad," then return to the integrations you led. **Follow-up 2:** "A three-year PM would ramp faster." Concede that specifically: on roadmap ownership and prioritization, probably yes. Hold on what the three sentences carry. Never fold into "it's basically the same job" | F1 and F2 are the gap the JD's must-have presses on hardest, so this objection will arrive in some form. JD, because it scores R1 directly. The follow-ups are drawn from the dossier's prohibited claims, because those are where a candidate under pressure reaches |
| A2 | "Owning the partner API roadmap is the core of this job. What in your background prepares you for that, and what doesn't?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having owned a product roadmap" | Answer "what doesn't" first: "I haven't owned a product roadmap." Then the nearest thing, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." That was the input side, and the decisions sat with product. Volunteer that there's limited proof of it to show. Close with the ramp plan, said as a plan | F2 is acknowledge-only, so this rehearses the acknowledgment without a bridge, which is the one the dossier forbids. JD because it's the first responsibility the JD lists |
| A3 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | "I led 30-plus client integrations of the vendor's REST APIs, end to end, through to go-live." Keep your side of it clear: you led integrations of the vendor's APIs. Don't call them API products you shipped. Answer slot: if part of what went live was something your team built rather than configured, say what, in your own words. If not, say so plainly and stay with the integrations | R2 is a must-have, and F3 is where your words most easily drift into the JD's vocabulary. JD because it's the requirement asked as a yes/no |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Pick the real one, F2, rather than a safe-sounding weakness: "Roadmap ownership. I haven't owned a product roadmap." Then say what you'd do about it in the first 90 days, as a plan. A rehearsed, specific answer here makes A1 easier when it comes | Hiring managers use this stem to test self-assessment. JD because it scores against the listed job. The honest pick is the one the dossier already settled |
| A5 | "Why move into product management now?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: give your actual reason, in your own words. The pack supplies no motive. If the quarterly sessions are part of why, you can say so at their scope ("I ran quarterly roadmap-input sessions feeding client evidence to product"), but only if that's true for you. Keep it to two or three sentences, and don't criticise your current role | A career-switch candidate always gets "why now". EXP because it tests whether your story holds together. F1's bridge only lands if the motive is real |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Say you inherit the partner API roadmap in your first month. How do you decide what goes on it?" | CASE | [generic] | Clarify first: what's already committed, who decides what (raise the squad-lead question here, naturally), and what the roadmap is for this year. Then: the objective (adoption? partner retention?), partner segments, the evidence you'd gather (partner interviews, support tickets, usage data), how you'd rank it, and the risks. The question asks nothing about your past, so the guidance makes no claim about it | It's the JD's first responsibility, asked as a live problem. CASE because structure is what gets scored. It's also where you can show roadmap thinking without claiming roadmap history (F2) |
| B2 | "How would you run discovery with our integration partners?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: which partners and why, what you're trying to learn, the format (interviews, observing an integration, ticket review), and how findings reach the squads. You can name the nearest thing you've done, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Add the limit yourself: limited proof to show. Don't describe what those sessions contained beyond that sentence | It's a JD responsibility, and F5's medium evidence is relevant to it. CASE delivery, but expect a probe on the sessions themselves (see E2) |
| B3 | "How would you define and track adoption for a partner-facing API?" | CASE | [generic] | Ask for the current baseline first, since the dossier flags none is stated. Then a funnel, from access granted to first call to production traffic to sustained use. Add one leading and one lagging measure, a split by partner segment, and what you'd do when a metric drops. Name the weakest assumption in your own framework before they do | A JD responsibility with an unknown baseline. CASE because it's a live design problem. These funnel stages are a common pattern, not Quartzline's actual measures |
| B4 | "Two squad leads push back on the priorities in your spec. What do you do?" | CASE | [generic] | Clarify who holds which decision first. That is the open question in your dossier, and asking it here reads as judgment. Then: understand the objection, separate the facts (cost, risk) from preferences, find what you can agree on, and escalate only if there's a real conflict about the goal. Don't illustrate it with a past squad-prioritization story, because no such sentence exists (prohibited_claims: "Having set prioritization for an engineering squad") | It hits the JD's "two engineering squads" line and the authority unknown. CASE because it's hypothetical, and it's the natural place to slip in a past example you don't have |
| B5 | "A large partner says our API docs are the reason their integration is late. What do you do?" | CASE | [grounded] "Wrote the internal integration playbook her team uses" | Structure: confirm what's actually blocking them, separate a docs gap from a product gap, fix the partner's immediate problem, then decide whether it's systemic. You can mention, at its scope, that you wrote the integration playbook your team uses. Don't describe doc-writing you haven't stated. Answer slot: the JD's "API docs, schemas" line makes a probe likely. If you've worked on API docs or schemas directly, say how, in your own words. If not, say so plainly | It combines R3 with partner-facing pressure. CASE because it's a live problem. F4 is discovery, so the slot covers the probe |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations: how are you counting those?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts client integrations, and it stays attached to that noun. Answer slots, in your own words: how the integrations were counted; what the count is sensitive to (for example, what counts as one integration); the assumption behind it you'd defend least, named before they ask; and which part was yours. "Led" is the sentence's verb, so keep it. If you don't know exactly how a figure was counted, say so plainly | It's your headline number, and a prober will go two levels into it. EXP, defend-the-number |
| C2 | "Pick one of those integrations and walk me through it, scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The beats are the stages the sentence names: scoping, requirements, architecture, UAT, go-live. Choose a real one and tell it in your own words. Answer slot: the JD's "Write specs" line makes a probe on requirements likely. If you wrote the requirements for that integration, say what they covered. If someone else did, or they weren't written down, say so plainly and describe how you led that stage | It tests whether "led end to end" holds up stage by stage. EXP. The spec probe connects to F1 |
| C3 | "Talk me through how you read an API reference or a schema. What do you check first?" | JD | [inferred] | Answer slot: if you've read or written API docs or schemas in your integration work, say what you check and why, in your own words. If not, say so plainly, then reason it through live (auth, endpoints, request and response shapes, errors, versioning) as how you'd approach it, not as something you've done | It's R3 asked hands-on. JD because it scores a stated requirement. F4 is discovery, so the slot carries the answer |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: the integrations you led, the playbook you wrote, the sessions feeding product, and why that points you toward this role. Answer slot: give your actual years and titles in your own words. The pack has no verified tenure. End on why this role, briefly, so you set up A1 rather than wait for it | The opener is almost certain, and it's scored. EXP because it frames everything after it. It's built only from the three sentences behind F1 |
| D2 | "Tell me about that playbook. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the sentence states: you wrote it, and your team uses it. Answer slot: say what it covers in your own words, and keep "who uses it" at your team unless you know of wider use | It's an inspectable artifact (F4), so it's likely to be picked up. EXP because it tests ownership. A narrow, accurate scope is better than a wide one here |
| D3 | "What's your experience been working with sales?" | JD | [inferred] | Answer slot: the JD's "across engineering, sales, customers" makes this likely. If you worked with sales around those integrations, say how, in your own words. If you didn't, say so plainly, then name what your material does carry: client integrations and input to product | It's R4's thinnest part (F5), asked casually. JD because it scores the stakeholder requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. Why you over someone who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | A1 compressed. Pause, then: "I haven't held the PM title. What I bring is that I led 30-plus end-to-end client integrations of the vendor's REST APIs." Add one sentence on the ramp. Stop at sixty seconds. If they interrupt, hold the same sentence and don't add to it | It's the same objection, time-boxed. The time limit is what's tested, and the content is set in F1 |
| E2 | "Those roadmap-input sessions. Did product actually change anything because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if you know of a product change your input fed, say what, in your own words, and how you know. If you don't know, or none did, say so plainly and stay with what the sessions were. Volunteer that there's limited proof to show before they ask. Hold, then concede: don't upgrade "feeding" into "shaped" | VE3 is medium, so this is where a prober finds the gap (F1, F5). EXP because it tests attribution |

### V. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a client and an internal team wanted different things." | VAL | [inferred] | Selection scaffold: pick a real case with a named disagreement, your part in resolving it, and the relationship intact at the end. Use "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the client integrations you led) or how you'd handle it | The theme comes from R4. VAL because it's a behavioural story. No quote carries the event, so it's a scaffold |
| V2 | "Tell me about a time you told a stakeholder something they didn't want to hear." | VAL | [generic] | Selection scaffold: a real moment, what the hard truth was, how you delivered it, and whether it landed. If it didn't land, say so. If no such time comes to mind, say so plainly and describe how you'd approach it | A persona stem that hiring managers use for PM judgment. VAL, generic, because no values were researched |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How would you work with the two squad leads day to day?" | CASE | [generic] | Propose principles rather than claim to know where your role meets theirs: agree decision rights early, keep shared priorities visible, set how often you review them, and say what you bring them (partner evidence, clear specs). Ask how it works today | It's the dossier's squad-authority unknown, asked from the leads' side. CASE because it's prospective |
| P2 | "Tell me about a time engineering and a client disagreed about what an integration should include." | EXP | [inferred] | Selection scaffold: a real integration where scope was contested, what each side wanted, and what part of the resolution was yours. Don't make up the outcome. If no such time comes to mind, say so plainly and stay with how you led the scoping stage | R4 with engineering (F5's gap). EXP because it tests a specific past. No quote carries the event |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A4, A5, E1, D1 |
| R1 sub-claim and JD responsibility: own the roadmap | A2, B1 |
| R2: shipped API or platform products | A3, C2 |
| R3: technical fluency, API docs and schemas | C3, B5, D2 |
| R4: stakeholder management across engineering, sales, customers | D3, V1, P2, B2 |
| R5: agile delivery experience | none as its own question. It's preferred, and F6 holds the clarify line for when it comes up inside B4 or P1 |
| Responsibility: discovery with partners | B2 |
| Responsibility: specs and delivery with two squads | B4, P1, C2 |
| Responsibility: adoption metrics | B3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier's risk that the JD asserts authority but doesn't evidence it. It reads as diligence and tells you what the job actually is |
| R-2 | "How is partner API adoption measured today, and what's the current baseline?" | From the dossier's risk that no baseline is stated. It shows metric thinking, and the answer tells you whether you'd be inheriting measurement or building it |
| R-3 | "What would you want this person to have done by day 90?" | It turns your ramp plan into their expectations, which is the thing that matters most for someone new to the title |
| R-4 | "Where do partners get stuck most often today: onboarding, docs, or something else?" | It keeps the conversation on partners and gives you material for any case question still to come |
| R-5 | "How does product work with the teams that deliver integrations to partners?" | It's where your background sits. The answer shows whether that background is valued here or treated as a different function |
| R-6 | "What made you open this role now?" | It tells you whether this is a new role or a backfill, and what problem it was opened to solve |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held the PM title." Then VE1 and VE3 at their own scope, as adjacent work |
| Having owned a product roadmap | Dossier prohibited_claims, and an acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan said as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set priorities for an engineering squad." In case questions (B4, P1), reason forward and don't reach for a past example |
| Shipped API or platform products | Inflated form of VE1 (built locally) | VE1 at its own scope: you led 30-plus client integrations of the vendor's REST APIs through go-live. The limit is the pack's observation: integrations led, not an API product shipped. A3's slot stays inside the integrations |
| Shaped or decided what product built | Inflated form of VE3 (built locally) | VE3 at its own scope: sessions feeding client evidence to product. E2's slot asks only what you know changed. Never "shaped" or "drove" |

---

## Sources

- **Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14. Sections it supplied: `role_profile` (stands in for the JD: R1 to R5, responsibilities, unknowns), `decision` (context only), and `handoff_to_mock_interview` (verified evidence, weak areas with strategies, the named objection, risks, employer questions, prohibited claims). It has no `evidence_map`, `evidence_state` or `risk_register` sections. Confidence bands come from the handoff. The dossier is more than three months old, so the JD lines are as of August.
- **VE1 to VE3** are the three `verified_candidate_evidence` entries, in the order the dossier lists them. Each evidence cell quotes the entry and leaves out its confidence note, which goes to Confidence and to the bridge.
- **Searches sent:**
  - "Quartzline company values": refused
  - "Quartzline interview process product manager": refused
  - "Quartzline API platform news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have themed the VAL questions with published values. No values sheet was due either way, because your words name no values round |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. Persona weights still rest on your own words (one hiring-manager conversation). It could have added known case formats to bank B |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have added at least one CO question and grounded B1 and B3 in Quartzline's current priorities and vocabulary |
| 4. interviewer name at Quartzline | n/a | No name was given. There's no interviewer read |
| 5. representative PM, Platform APIs JD | skipped | The dossier's role_profile supplies the requirements that fix the fit snapshot and the JD questions |

---

## Upgrade menu

- **Allow web search** → Quartzline's published values, its interview process and its current strategy: a CO question and company vocabulary in B1 and B3 (targets 1 to 3).
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, recent org context and role-family loop reports, if you'd like it once search is allowed.
- **The hiring manager's name** → an interviewer read from their public profile, reweighted personas, and a reverse question tied to their path.
- **The current posting, or the recruiter's latest note** → confirms the August requirements still stand, and covers any pre-declared deliverable.
- **Your actual years and titles in integration work** → D1, A1 and E1 gain a tenure line. The dossier summary mentions a figure, but no verified entry states it.
- **How the 30+ was counted** → C1's slots become a quoted answer.
- **Your answers to the slots on docs and schemas, sales and engineering, and agile** → F4, F5 and F6 move off discovery, and C3, D3, V1, P2 and B5 become story-mapped.
- **How much prep time you have** → a prioritised prep schedule sized to it.
