# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown. This pack assumes a hiring-manager round, the likeliest first conversation for this role. If you learn otherwise, the persona weights change.
**Loop:** unknown. No loop source was available, so the persona weights rest on the Generic archetype plus hiring-manager priors. They are a pattern, not Atlas Freight's documented process.

---

## How to use this pack

- **Personas** describe *how* a question is asked: who is asking, and in what style. **Types** describe *what* is being scored.
- Type key:
  - **VAL**: values or behavioural alignment, shown through past behaviour
  - **EXP**: work-experience deep-dive. Do your claims survive scrutiny, and what was actually you
  - **JD**: can you do the listed job, gaps included
  - **CO**: company knowledge and homework
  - **CASE**: a live problem from the role, solved out loud
- **Provenance** labels: `[grounded]` = traceable to what you told me or the JD you quoted. `[inferred]` = this pack's derivation, with the derivation named. `[generic]` = a role-family pattern with no claim about you or Atlas Freight.
- **Answer slots** are instructions for the interview, not questions for me. Each has two honest branches. Pick the one that is true.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.

---

## Fit snapshot

Requirements are quoted from the JD text in your message. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and "the site", not terminal operations across four sites. The words stay at that scope: "Seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site terminal line makes a probe on multi-site or terminal work likely. If any of your work spanned more than one site or was in terminal operations, say what and for how long, in your own words. If none was, say so plainly and stay with the site you know |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Running a surge plan touches on-time performance, but the material does not show whether on-time was a measure you tracked or were held to. Answer slot: if on-time performance was a number you tracked or answered for, say which number and how you moved it, in your own words. If it was not, say so plainly and talk about how you ran the surge plan |
| F3 | "drive … cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a cost measure you owned or moved, with the figure and how it was counted. Answer slot: the JD makes a cost-per-shipment probe certain. If you have had a cost target or moved a cost metric, say which one and how it was counted. If you have not, say so plainly and say how you would approach it, as a plan |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The material says three supervisors today, and the JD says twelve. The words stay at that scope: "Today I'm a senior shift manager over three supervisors." Answer slot: if you have led more supervisors at any point, such as covering another shift, say when and for how long. If you have not, say so plainly and describe how you lead the three, then how you would run twelve, as a plan |
| F5 | "build reporting in Excel" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-rating. It does not show reporting you built. Answer slot: if you have built a recurring report in Excel, describe what it tracked and who used it. If you have not, say so plainly and say how you would build one for four sites |
| F6 | "build reporting in … Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years in ops is not the same claim as seven years in leadership, and the material does not say how many were in leadership roles. Because the posting says "required", expect it to be checked literally. That reading is this pack's inference, not a gate. Answer slot: give your actual number of years in roles where you led people, with the titles. If it is fewer than five, say so plainly and do not count non-leadership years as leadership |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | No gap, but a self-reported credential with nothing inspected behind it. Lead with it in your own terms: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a link to the pick-path work likely to be probed. If you used green belt methods on the pick-path redesign, say which and how. If you did not, keep the two separate |

---

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on on-time performance, cost-per-shipment, a first-30-days plan, peak planning | High. A hiring manager is buying capability, and the JD's two headline metrics are natural case material. Assumes a hiring-manager round | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Quiet probing of the scale jump (F4, F1), years of leadership (F7), terminal versus warehouse (F1), Power BI (F6) | High. The fit snapshot has two transferability rows on the role's core scope, plus a stated capability gap. A hiring manager de-risks exactly these | Rehearse B1 until it is boring. Bridge only from what you stated, name the limit first, and give a concrete ramp plan |
| Data-Driven Prober | Goes after the 40% mis-pick figure and anything measured in the surge plan | Medium. One headline metric in your material is a magnet, and the role is metric-driven | Know what you can and cannot say about how the 40% was counted. Name your weakest assumption before they do |
| Conversational / Rapport | "Walk me through your journey", "what do you know about us", Lean asked casually | Medium. Openers in most rounds, and the JD's Lean "plus" is the kind of topic asked in passing | A 90-second arc built only from your own sentences. Treat casual questions as scored |
| Pressure | Time-boxed "why you", "how much was actually you" | Low to medium. Less typical of a hiring manager, but the scale gap invites it | Pause, restate, anchor in what you stated, and hold through two follow-ups before conceding anything real |
| Values / Behavioural | Supervisor accountability, resistance to change on the floor | Low. No values round is detected: no loop source is available and the Generic archetype has none. Behavioural questions still appear in most rounds | We for context, I for contribution. Choose stories your material carries, and say so when it does not |
| Peer Evaluator | A site lead or supervisor on the panel asking what you would need, or how you would settle cross-site friction | Low. Only if peers join the round | Lead with what you bring them. Propose principles rather than pretending to know their seams |

---

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of our four terminals has slipped for three weeks. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: how "on time" is defined here and which shipments it covers. Check the data before trusting the trend. Segment by shift, by day, by inbound versus outbound, and by customer or lane. Form two or three hypotheses, then separate quick containment from root cause. Say which supervisors you would pull in and what number you would watch weekly. The question asks about no past, so the guidance makes no claim about yours | The JD's on-time line (F2) is the headline metric, so a diagnosis case is close to certain. CASE because it scores structure live |
| A2 | "Cost-per-shipment is above target across the network. Where do you look first?" | CASE | [generic] | Clarify what is in the metric: which costs and which shipments count. Break it into cost buckets over volume. Compare the four sites against each other before assuming one cause. Pick one or two levers, pilot at one site, measure, then spread. If F3's answer slot applies to you, a cost metric you actually moved can be one sentence here, in your words. Otherwise keep this a plan | The JD's cost-per-shipment line (F3) is the row with no evidence, so the case is where you show thinking you cannot yet show as history. CASE delivery, JD content |
| A3 | "Four sites, twelve supervisors. How do you spend your first 30 days?" | CASE | [generic] | Visit every site and see each shift. Meet each supervisor one to one. Learn how on-time and cost-per-shipment are counted and reported today. Find one quick, visible fix, and hold back from big changes until you understand the sites. Close with what you would report to your manager at day 30 | Tests whether you can operate at the role's scope (F1, F4) without overclaiming. CASE because it is a plan, not a record |
| A4 | "If you built a daily ops report for four terminals, what would be on it?" | JD | [grounded] "solid Excel"; "never used Power BI" | Design it: a few KPIs, with the JD's two first. Show them by site and shift, trended against target, with exceptions flagged for action. Build it in Excel, which your words support as "solid Excel". On Power BI, plain: "I haven't used Power BI," then how you would learn it. Answer slot: if you have built a recurring Excel report, describe it in a sentence. If you have not, say so plainly and stay with the design | Covers the JD's reporting line (F5, F6) in one question. JD because it scores a stated responsibility, CASE in delivery |
| A5 | "Peak hits all four sites at once. How would you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Start with the quote at its own scope: you ran the site's peak-season surge plan, two years running. Answer slot: if parts of the plan were yours to design, say which and how you decided. If the plan was handed to you to run, say so plainly and talk about running it. Then the four-site version, said as a plan: what you would standardise across sites, and what you would leave to each site | F1's strongest quote, stretched by the question to four sites. The guidance keeps the history at one site and the plan in the future tense |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're a senior shift manager over three supervisors. This role is twelve supervisors across four sites. Why are you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **Highest-ROI prep in this pack.** Hold only what the quotes carry: "Today I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Name the limit before they do: "Twelve is four times the team I lead today." Answer slot: if you have ever led more supervisors or another site, even temporarily, say what and for how long. If you have not, say so plainly. Then the ramp plan, as future: weekly cadence with each supervisor, one standard report across sites, and what you would delegate. Follow-up 1, "But managing managers at scale?": return to the three supervisors and the slot, and add nothing. Follow-up 2, "What would you do differently with twelve?": the ramp plan, said as a plan. Never fold the plan into a claim that you have already done it | F4 and F1 are the two transferability rows on the role's core scope. Some version of this objection is almost certain. JD because it scores the stated span directly |
| B2 | "The JD asks for five-plus years of operations leadership. How many of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the actual number of years you have led people, with titles, in your own words. If it is five or more, say it and stop. If it is fewer, say so plainly, then the seven years of ops in those words, without calling them leadership years. Precision here buys trust for everything after | F7 is likely checked literally. A vague answer reads as hiding. JD because it is a stated requirement |
| B3 | "Our sites are freight terminals, not warehouses. What doesn't transfer?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say your seven years were in warehouse and distribution ops, in those words. Answer slot: if any of your work was in terminal operations, say what. If none was, say so plainly. Then say, as a plan, what you would want to learn about terminal operations in your first weeks and who you would learn it from. Acknowledging the difference is stronger than blurring it | F1's limit is the kind of seam a hiring manager from the freight side tests early. JD because the JD's terminal line is the source |
| B4 | "You've never used Power BI, and this role builds reporting in it. Won't that slow you down?" | JD | [grounded] "never used Power BI"; "solid Excel" | Plain: "I haven't used Power BI." Then "solid Excel", in your words. Then a dated learning plan, as future. If you start learning before the interview, say only what you have actually done by then. Do not hedge it into familiarity | F6 is a gap you stated, so the negative in the question has a source. JD because reporting is a listed responsibility |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Give a real one. The one your material states cleanly is Power BI: "I haven't used Power BI," plus the plan. Avoid a disguised strength such as "I care too much". It reads as evasion. If you would honestly pick something else, pick it and say how you would close it | Tests honest self-assessment. F6 gives a sourced, low-damage answer, while F4 and F7 are better handled in B1 and B2 |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate 40%. How was that counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Keep the 40% attached to the mis-pick rate, never errors in general or cost. Answer slot: say how the 40% was counted, in your own words. If you do not know exactly, say so plainly; "I don't know how it was counted" is an honest answer. Then say which part of the redesign was yours, in your own words. If others did parts of it, say so | Every headline metric gets a defend-the-number rehearsal. F8's figure is the only one in your material, so it will be probed |
| C2 | "What else changed in that period, and how do you know the pick path did it?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: name, in your own words, what the figure is sensitive to and the assumption behind it you would defend least. Say it before they find it. If you do not know what else changed, say so. A named weakness gains credibility, while a defended-to-the-death number loses it | The weakest-assumption move for F8's figure. EXP because it tests whether you know your own number |
| C3 | "Walk me through the peak-season surge plan. What did you measure to know it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Start from the quote: you ran it, two years running. Answer slot: the JD's on-time line makes this probe likely. If you tracked anything to judge the plan, say what and what it showed. If nothing was measured, or it was measured by someone else, say so plainly and describe how you ran the plan | F2's thin bridge. The question presupposes measurement, and the slot allows that there was none |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already run a multi-site operation?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Pause, then three facts in your own words: seven years in warehouse and distribution ops, the pick-path redesign that cut the mis-pick rate 40%, and green belt certified. Do not claim multi-site work unless F1's slot gives you a true one. If they push on scale, hold once with the same facts, then concede specifically: "Twelve is four times the team I lead today." Then the ramp plan from B1 | The scale gap (F1, F4) invites a stress version of B1. Hold-then-concede, anchored only in what you stated |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use "we" for the team and "I" for your part. Answer slot: say exactly which part was yours. If the redesign was a team effort, say so, then say what you did. Do not round your share up under pressure, and do not drop the number to make the tension go away | Attribution probe on F8's figure. Rehearsing candour is the point |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc using only these: seven years in warehouse and distribution ops; senior shift manager over three supervisors today; the pick-path redesign and the 40% on mis-picks; the site's peak plan two years running; green belt certified. Answer slot for the close: say why this role, now, in your own words | The opener in almost every round. A tight arc sets the frame before the Skeptic arrives |
| E2 | "What do you know about Atlas Freight?" | CO | [generic] | Research could not run for this pack, so this one is your homework: their website, where the four terminals are, any recent news. Say only what you found and where. If you found little, say so and turn it into a question about the sites | Every round has a homework check. `[generic]` because no company facts were established here |
| E3 | "Do you still use Lean day to day?" | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | "I'm green belt certified," in your words. Answer slot: if the pick-path redesign used green belt methods, say which and how. If it did not, keep the two separate, and say how you do or do not use Lean now | The JD's Lean "plus" (F8), asked casually but still scored. The trap is linking the certification to the redesign without a basis |

### V. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to hold a supervisor accountable for performance." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a time with one of the supervisors you lead. It needs a named issue, the conversation you had, and what changed after. Use "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's "lead a team of 12 supervisors" (F4) makes accountability the core behavioural theme. VAL with JD content |
| V2 | "Tell me about a time a change you pushed met resistance on the floor." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The pick-path redesign is a candidate. Answer slot: if there was pushback on it, say what it was and what you did. If there was none, say so and pick another time, or say plainly that none comes to mind and how you would handle it. Do not invent resistance to make the story land | The JD's "drive on-time performance and cost-per-shipment down" is a change mandate. F8's redesign is your one quoted change |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "If I'm one of your supervisors, what would you need from me in week one, and what would I get from you?" | CASE | [generic] | Lead with what they get: a clear weekly cadence, one shared report, decisions made fast and explained. Then what you need from them: honest numbers and early warnings. Ask what they would want from a new manager | A supervisor or site lead on the panel is pricing your effect on their work. Reciprocity scores here |
| P2 | "Two site supervisors both want the extra labour during a surge. How do you decide?" | CASE | [generic] | Clarify the facts: volume, service commitments, what slips at each site. Decide on a stated principle, for example service risk first, and make it visible. Explain it to both supervisors, and review afterwards. The question asks about no past, so the guidance makes no claim about yours | Cross-site trade-offs are built into a four-site role (F1). Tests disagreement style with equals |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| F1 own daily terminal operations across 4 sites | A3, A5, B3, D1, P2 |
| F2 drive on-time performance | A1, C3 |
| F3 drive cost-per-shipment down | A2 |
| F4 lead a team of 12 supervisors | B1, A3, V1, P1 |
| F5 build reporting in Excel | A4 |
| F6 build reporting in Power BI | A4, B4, B5 |
| F7 5+ years operations leadership required | B2 |
| F8 Lean/Six Sigma a plus | E3, C1 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Across the four sites, where is on-time performance today, and which site is furthest from target?" | It starts from their headline metric and shows you will begin with their numbers, not your assumptions |
| R2 | "How is cost-per-shipment calculated here, and what's in it?" | The definition decides which levers exist. Asking it signals rigour rather than inexperience (A2) |
| R3 | "How are the twelve supervisors spread across the sites, and how do they report today?" | It sizes the span you would inherit and makes the scale conversation concrete (B1) |
| R4 | "What reporting exists now, and how much is expected to move to Power BI?" | It turns your stated gap into a scoping question and tells you how steep the ramp is (F6) |
| R5 | "What would make the first six months a success, in your eyes?" | It gets the real scorecard, which may differ from the JD |
| R6 | "Is there Lean or continuous-improvement work underway at the terminals now?" | It ties the JD's "plus" to your green belt without overselling it (F8) |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has run operations across multiple sites or terminals | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution ops and "the site". F1's slot stays inside that scope |
| Has led a team of twelve supervisors, or managers at that scale | Inflated form of F4 | "Today I'm a senior shift manager over three supervisors." B1's slot asks only what is true for you |
| Designed or wrote the peak-season surge plan | Inflated form of "ran the site's peak-season surge plan two years running" | The quote's own verb, ran. A5's slot asks which parts, if any, were yours to design |
| Cut costs or errors overall by 40% | Inflated form of "cut mis-pick rate 40% by redesigning the pick path" | The 40% stays on the mis-pick rate. C1 and C2 defend it at that scope |
| Has built reporting in Excel | Inflated form of "solid Excel" | "Solid Excel", in your words. F5's slot asks whether you built recurring reports |
| Has used Power BI | Negative you stated, F6 | "I haven't used Power BI." No slot |
| Seven years of operations leadership | Inflated form of "7 years in warehouse and distribution ops" | Seven years in warehouse and distribution ops. B2's slot gives your real leadership count |
| Led a Lean or Six Sigma programme | Inflated form of "green belt certified" | "I'm green belt certified." E3's slot asks whether the pick-path work used it |

---

## Sources

- Provided: your message, including the JD text you quoted and your background.
- Searches sent, all refused by the host's permission settings:
  - "Atlas Freight regional logistics company values": refused
  - "Atlas Freight interview process operations manager": refused
  - "Atlas Freight terminals news 2026": refused
- No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. Published values would have themed the VAL questions by name |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. A documented loop would have replaced the Generic-archetype persona weights, and could have detected a values round |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have grounded a CO or CASE question in current priorities. E2 stays `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. There is no interviewer read |
| 5. representative Operations Manager JD | skipped | The JD text you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Who you're meeting (hiring manager, a site lead or supervisor, HR, a panel) → persona weights recomputed from that relationship instead of an assumption, and banks reweighted or replaced
- The interviewer's name → an interviewer read from their public professional footprint, plus a reverse question tied to their path
- Any recruiter or HR prep note (focus areas, a presentation or case to bring, number of rounds) → a build section for any pre-declared deliverable, and loop mode if there are several rounds
- Web search allowed → Atlas Freight's values, loop and recent news. Targets 1 to 3 move from `unavailable` to `yes`, and E2 and the CASE questions can use their real vocabulary
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the company and its sites, plus strategy-grounded case questions
- The full JD text, if a longer version exists → any lines missing from the summary get rows and questions
- Your answers to the answer slots in F1, F2, F3, F4, F5 and F7 → those rows regenerate with your words, and B1, B2, A2 and C3 stop being two-branch scaffolds
- The mis-pick report or the surge-plan document, if you can bring one → F8 and F1 move from `medium` toward `high`, because there is something an interviewer could inspect
- A `tuesday-dossier.md` → evidence already checked against this role, a named top objection instead of an inferred one, and a binding list of claims to avoid
