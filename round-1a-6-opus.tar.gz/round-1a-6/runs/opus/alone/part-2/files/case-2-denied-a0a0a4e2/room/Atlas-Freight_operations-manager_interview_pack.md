# Interview prep pack: Operations Manager, Atlas Freight

Regional logistics, 800 employees. Interviewer(s): not known. Round type: not known, so persona weights are flat (see the persona table).

## How to use this pack

- **Personas** describe how a question is asked: who is asking and in what style. **Types** describe what is being scored.
- Type key:
  - **JD**: can you do the listed job, gaps included
  - **EXP**: does your stated experience hold up when someone digs into it, and what was actually yours
  - **CASE**: a live problem from the role, scored on how you structure it
  - **VAL**: whether your past behaviour shows the values they care about
  - **CO**: company and strategy knowledge (none in this pack, because company research could not run)
- Provenance labels: `[grounded]` means traceable to your message or the JD. `[inferred]` means derived from them, with the derivation named. `[generic]` means a role-family pattern with no claim about you or Atlas.
- **An answer slot** is a place where only you know the answer. It names the probe you're likely to get and gives two honest branches. Fill it from memory in your own words. Never fill it with what sounds good.
- The guidance is scaffolding, not a script. Rehearse out loud, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops, and "the site's" plan. It does not mention freight terminals or more than one site. Keep the words at that scope: "Seven years in warehouse and distribution ops." Answer slot: the JD's "terminal operations across 4 sites" makes a probe on terminal or multi-site work likely. If any of your work was in a terminal or cross-dock, or spanned more than one site, say which and what was yours. If none was, say so plainly and stay with the operation you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (the on-time half) | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge plan touches on-time delivery but does not show whether on-time was measured or moved. Answer slot: if you tracked on-time or service levels, during peak or otherwise, say what was counted and what happened. If you didn't, say so plainly, then say how you would measure it first |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (the cost half) | none given | none | [grounded] | discovery | Strong evidence here would be a cost measure you owned or reported, and something you changed that moved it. Answer slot: if you have tracked or reduced a cost measure (labour hours, overtime, cost per unit or per order), say what it was and what part was yours. If not, say so plainly and set out how you would approach it (B2 is the rehearsal) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | You lead supervisors today, at three, not twelve. Say it at that size: "I'm a senior shift manager over three supervisors." Don't inflate it and don't apologise for it. Answer slot: if you have led a bigger team at any point, covered other shifts, or managed supervisors you didn't hire, say when and what was yours. If not, say so plainly and give the ramp plan as a plan (A1, B3) |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill. Your material does not show reports you have built. Answer slot: if you build recurring reports or trackers, say what they track, who uses them and what decisions they drive. If you don't, say so plainly and say what you do use Excel for |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | You stated this gap, and no wording closes it. Words: "I haven't used Power BI." Then give your plan for learning it, stated as a plan and never as something already done. Nothing added to make the gap feel smaller |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | The green belt reaches the "plus" directly. Expect a probe, because there is a cert line with nothing inspected behind it. The two quotes stay separate: the material does not say the pick-path redesign was a green-belt project. Answer slot: if it was, or another project used those methods, say which tools and what was yours. If not, say so plainly |
| F8 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in ops is not the same as seven years leading people, and the material does not say how many of the seven were in leadership roles. Answer slot: give your actual count of years leading people, with the roles. If it is five or more, say so with the roles. If it is fewer, say so plainly and don't round the seven up |

## Persona table

The round type is not known, and no source establishes Atlas Freight's interview loop. Research was refused, so the pack falls back to the **Generic archetype** (screen, then hiring manager, then panel) with **flat weights**. That is weaker than a pack tuned to a known round. Depth is adjusted only where the fit snapshot's gaps sit.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of scale, terminal experience, Power BI, "why now" | Flat, with 4 questions. F1, F4, F6 and F8 are where any interviewer will look first | Rehearse A1 until it bores you. Bridge only from what you stated, say limits plainly, and give the ramp plan as a plan |
| Case / Strategist (B) | Live problems on on-time performance, cost per shipment, onboarding and peak | Flat, with 4 questions. The JD names two metrics, which invites "diagnose this" and "fix that" | Clarify, then the objective, segment, approach, metrics and risks. Think aloud |
| Data-Driven Prober (C) | "How was the 40% counted?", "What's in your reports?" | Flat, with 3 questions. Your one figure is a magnet | Know what you can and can't say about how the figure was counted, and say plainly when you don't know |
| Pressure (D) | Interruptions, time-boxes, "how much was actually you" | Flat, with 3 questions | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede what's real |
| Conversational (E) | Friendly openers, a casual "how's Power BI going?" | Flat, with 3 questions | A 90-second arc ready. Treat casual questions about JD topics as scored |
| Values / Behavioral (F) | "Tell me about a time…" stories | Flat, with 2 questions. No values round is detected and Atlas's published values are not in hand | Pick real stories. "We" for context, "I" for your part |
| Peer (G) | Another site or ops lead pricing what you'd cost and bring them | Flat, with 2 questions. With four sites, peer seams are real | Lead with what you bring their site. Propose seam principles, not pretend knowledge |

## Question banks

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead 3 supervisors today. This role is 12 supervisors across 4 sites. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **This is the highest-ROI prep in the pack.** Open with what the quotes carry: "I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Name the limit before they do: twelve is four times the team I lead now. Answer slot: the JD's "4 sites" line makes a probe on multi-site or larger-team work likely. If you've covered other shifts or sites, or led a bigger team, say when and what was yours. If not, say so plainly. Then give the ramp plan as a plan: how you'd learn four sites and twelve supervisors in the first weeks (B3). Hold through two follow-ups by going back to the team you lead and the plan, never by adding to either | F4 and F1 are the widest gaps between your material and the JD, so this objection arrives in some form whoever asks. JD because it scores the stated scope |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "solid Excel" | Answer it straight, because dodging this question costs more than the gap does: "I haven't used Power BI. I'm solid in Excel." Answer slot: if you've started learning Power BI, say what you've done. If not, say so and give the plan you'd follow, as a plan. Don't name a second, softer weakness to dilute it | F6 is a gap you stated. Naming it first turns a likely gotcha into candour. JD because Power BI is a listed tool |
| A3 | "The role is terminal operations. Your background is warehouse and distribution. What's different, and how would you close that gap?" | JD | [grounded] "7 years in warehouse and distribution ops" | "Seven years in warehouse and distribution ops," at its own scope. Answer slot: if any of it was terminal or cross-dock work, say which. If none was, say so plainly. Then say what you understand the differences to be, in your own words, and ask how their terminals run. Don't present an understanding as experience | F1's transferability gap. The interviewer will test whether you know the difference exists. JD because it scores the headline requirement |
| A4 | "Why leave your current role now, and why Atlas?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: give your real reason for moving now, in your own words, and keep it forward-looking. For "why Atlas", the pack has no researched facts about Atlas, so cite nothing you haven't checked yourself. You can stay with the role: the JD lines that draw you (four sites, on-time and cost ownership, a larger team) and why | Motivation consistency is a standing Skeptic probe. EXP because it tests your story, not the JD |

### B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance dropped five points at one of our four terminals last month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is measured (pickup, delivery, appointment windows), over what period, and whether the other three sites moved too. Segment by lane, shift, customer, and inbound versus outbound. Hypotheses: late inbound arrivals, dock or labour capacity, sort or load errors, driver availability, or a change in how the data is counted. Check the data definition before blaming the floor. Close with the action, the metric you'd watch, and the risk: buying on-time back with overtime raises cost per shipment. The question needs no claim about your past | The JD's on-time line (F2's requirement), asked as a live problem. `[generic]` because it is a pattern for the problem, not a fact about Atlas |
| B2 | "You have 90 days to bring cost per shipment down. Where do you start?" | CASE | [generic] | Clarify what is in the cost and what counts as a shipment. Get the baseline by site and find the biggest buckets: labour hours, overtime, damage and claims, rehandling, equipment. Separate quick wins from structural changes, protect on-time while you cut, and say how you'd report progress weekly. Don't bring your own past into it unless you use a quote from C1 or B4 word for word | F3 has no evidence, so a well-structured live answer is the best available ground. CASE because it is scored on structure |
| B3 | "Your first 30 days with four sites and twelve supervisors. What do you do?" | CASE | [generic] | Visit every site and every shift. Hold one-to-ones with all twelve supervisors. Baseline on-time and cost per site. Learn the current reporting before changing it. Pick one visible quick win. Set a cadence (daily huddles, weekly review). Say what you would deliberately not change in month one | This is the ramp plan A1 points to. Rehearsing it makes the A1 concession land as a plan rather than a weakness |
| B4 | "Peak is coming at all four sites. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with the quote: you ran the site's surge plan, two years running. Answer slot: if parts of the plan were yours to set (staffing levels, shift patterns, temp labour, volume forecasts), say which and how you decided. If they were set for you, say so and describe how you ran it. If you tracked how peak went, say what was counted. If not, say so. Then scale it as a plan: what changes when it is four sites, not one | F2's quote is your strongest live material, and this is where to use it. CASE delivery, JD content |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as stated: you redesigned the pick path and the mis-pick rate fell 40%. Answer slots, each in your own words: how the figure was counted (what counted as a mis-pick, which periods were compared). What it is sensitive to. The assumption behind it you'd defend least, named before they ask. Which part was yours. "I don't know exactly how it was counted" is an honest answer. Keep the 40% attached to the mis-pick rate | Your one headline figure, so it will be probed. EXP because it tests the claim |
| C2 | "What did the pick-path redesign actually involve, and what part was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats the quote gives: the pick path, redesigned, and the mis-pick rate down 40%. Answer slot: what you changed, how you decided, and who else was involved. If others did parts of it, name their parts plainly. Don't describe steps you didn't take | Follows C1. Interviewers move from the number to the work. EXP because it tests attribution |
| C3 | "What reporting do you build today, and what decisions does it drive?" | JD | [inferred] "solid Excel" | Answer slot: if you build recurring reports or trackers in Excel, say what they track, who reads them and one decision they changed. If you don't, say so plainly and say what you do in Excel. Don't describe dashboards you haven't built | F5's discovery gap, against the JD's reporting line. JD because reporting is a listed duty |

### D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold: "I redesigned the pick path, and mis-picks fell 40%." Answer slot: if others contributed (pickers, engineers, a manager), say who did what, specifically. If it was yours, say so without heat. Hold through two follow-ups. Concede only what is real, and don't give away the core claim to ease the tension | The classic attribution stem, aimed at your one figure. EXP because attribution is what is scored |
| D2 | "The JD says five-plus years of operations leadership, required. Sixty seconds: do you have it?" | JD | [inferred] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give your actual count of years in roles leading people, with the roles, inside sixty seconds. If it is five or more, say it plainly. If it is fewer, say so, don't count the seven years of ops as leadership, and point to what you lead now. Hold the number you give through the follow-up | F8 is a "required" line your material doesn't settle. JD because it scores a stated requirement |
| D3 | "Sixty seconds: why you over an internal candidate who already knows our terminals?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Concede the obvious: an insider knows their terminals. Then give three facts in your own words: you ran the site's surge plan two years running, you cut the mis-pick rate 40% by redesigning the pick path, and you're green belt certified. Stop on time | Time-boxed composure test. JD because it compares you with the listed requirements |

### E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc: seven years in warehouse and distribution ops, senior shift manager over three supervisors now, the pick-path redesign and its 40%, the surge plan two years running, then why this role. Answer slot: your material doesn't give the roles before the current one. Fill them in briefly from memory, in your own words | Nearly every round opens with this. EXP because it frames everything after it |
| E2 | "Green belt, nice. What are you using it for these days?" | EXP | [grounded] "green belt certified" | Treat it as scored, because it's the JD's "plus". Answer slot: if you've applied green-belt methods to a project, the pick-path redesign included, say which tools and what was yours. If you haven't, say so plainly and say where you'd apply it here. Don't relabel a project as Lean or Six Sigma if it wasn't one | F7, asked casually. Casual questions on JD plus-skills are still scored |
| E3 | "How are you getting on with Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | The same honesty as A2, in a lighter register: "I haven't used Power BI. I'm solid in Excel." Then the plan, as a plan. Don't let the friendly tone turn it into "a bit" | F6 again. Gaps often come back casually later in the conversation. JD because it is a listed tool |

### F — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a real time. It needs a named stake, the moment you said it, and what happened next, told with "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | A standing behavioural stem. With no published Atlas values in hand, it stays role-generic |
| F2 | "Tell me about a time you had to hold a supervisor accountable for performance." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Pick a real case from leading your supervisors: the issue, the conversation, what you did and how it ended. If no such time comes to mind, say so plainly, then say how you would handle it. Keep the person anonymous | The JD's "lead a team of 12 supervisors" makes people leadership a likely theme. VAL because it is scored on behaviour |

### G — Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites share freight. Where's the seam between my terminal and yours, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than pretending to know their seam: one shared definition of on-time, agreed handoff points, escalation rules before conflict happens, and a regular joint review. Ask what currently breaks between sites | With four sites, peers price what you'd add to or take from their load. `[generic]` because the seam is unknown |
| G2 | "How do you handle credit when one site's fix came from another site's idea?" | VAL | [generic] | Give credit by name, spread the fix, and say how you'd make sharing ideas across sites normal. If you have a real example, use it in your own words. If not, say how you would handle it | Credit-sharing is a standard peer probe in multi-site roles |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B3, B4, G1 |
| "drive on-time performance" | B1, B4 |
| "cost-per-shipment down" | B2 |
| "lead a team of 12 supervisors" | A1, B3, F2 |
| "build reporting in Excel/Power BI" | A2, C3, E3 |
| "5+ years operations leadership required" | D2 |
| "Lean/Six Sigma a plus" | E2, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured here, and how do the four sites compare right now?" | Shows you think in the JD's metric and need the definition before promising to move it |
| R2 | "What goes into cost per shipment, and which bucket worries you most?" | Signals you'll look at what drives the number, not just the headline |
| R3 | "Tell me about the twelve supervisors: tenure, open roles, and who's ready for more?" | Shows you're already thinking about the team you'd inherit |
| R4 | "What does reporting look like today, and who built it?" | Shows you'll learn what exists first. It also shows how much Power BI work the role really involves |
| R5 | "What would make the first 90 days a success, in your eyes?" | Gets their scorecard in their words, which you can mirror back later |
| R6 | "How different are the four sites from each other in volume, freight mix and maturity?" | Shows multi-site thinking. It also prepares you for B3-style questions |

## Prohibited claims

Built from the fit snapshot. These are claims this pack will not coach, because each one stretches something you said.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a terminal or multi-site operation | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says warehouse and distribution ops and "the site's" plan. A1 and A3's slots stay inside that |
| Has led a team of twelve, or a large supervisory team | Inflated form of F4 | "currently a senior shift manager over 3 supervisors," at that size |
| Drove on-time performance through the surge plan | Inflated form of F2 | F2's quote at its own scope. B4's slot asks only what was tracked |
| Builds reporting or dashboards in Excel | Inflated form of F5 | "solid Excel". C3's slot asks what you actually build |
| Has used or built Power BI | A negative you stated (F6) | The plain acknowledgment F6 gives: "I haven't used Power BI." No slot |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form of F7, joining its two quotes | Each quote at its own scope. E2's slot asks whether it was |
| The 40% is a cost, productivity or on-time gain | Inflated form of F7's mis-pick quote (the number moved to another noun) | The 40% stays with the mis-pick rate |
| Seven years of operations leadership | Inflated form of F8's quotes (years in ops promoted to years leading) | Both quotes at their own scope. D2's slot asks for the real count |

## Sources

- Provided: the JD text and your background, both from your message.
- Searches sent (all three were refused, because web search permission was not granted in this session):
  - `Atlas Freight values`: refused
  - `Atlas Freight interview process operations manager`: refused
  - `Atlas Freight regional logistics news 2026`: refused
- Nothing in this pack comes from research. All company-specific content is absent, not assumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have themed VAL questions with Atlas's published values, and a values cheat sheet if a values round is confirmed |
| 2. `Atlas Freight interview process` | unavailable | The search was refused. It would have named the rounds and set the persona weights instead of the generic fallback |
| 3. `Atlas Freight` strategy / recent news | unavailable | The search was refused. It would have grounded CO questions and the "why Atlas" answer in A4 |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so no query could be formed |
| 5. representative Operations Manager JD | skipped | Your JD text already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you're meeting (manager, panel, HR, peers) → real persona weights, with banks re-ordered and resized instead of flat
- The recruiter's prep email or format notes → coverage of any presentation or exercise they've announced, and a confirmed loop
- Web search allowed → a rerun of targets 1–3: Atlas's published values, its interview process and recent news, plus grounded CO questions and a researched "why Atlas"
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, the org context and loop reports, for sharper case and differentiation questions
- Your answers to the answer slots in F2, F3, F5 and F8 → those rows upgraded, and guidance in B4, C3 and D2 story-mapped instead of slotted
- The reports behind your figures (your mis-pick tracking, the surge plan document, your green belt certificate or project charter) → confidence on F7 and the C1 figure raised from medium
- How much prep time you have → a prioritised prep schedule
- A `tuesday-dossier.md` from job-underwriter → an evidence-checked objection and a prohibited-claims list from a verified evidence map, rather than one inferred here
