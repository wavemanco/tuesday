# Interview Prep Pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy, a **peer** (both report to the same VP) · **Format:** one 60-minute conversation

---

## How to use this pack

Questions are sorted on two axes:

- **Personas** describe *how* a question is asked: who is asking and in what tone. Each persona has its own bank, ordered by how likely it is in this conversation.
- **Types** describe *what is being scored*:

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the values being probed, not generic virtue |
| EXP | Experience deep-dive | Whether the claims in your background hold up under scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company & strategy | Whether you can think at Northwind's level: Compass, expansion, profitability, the bundling threat |
| CASE | Live problem | Structure and reasoning on a problem from the role, worked out loud |

Question IDs go by persona: **A** Prober, **B** Peer Evaluator, **C** Case/Strategist, **D** Skeptic, **E** Pressure, **R** Rapport/Conversational, **V** Values. **F1–F7** are rows of the fit snapshot.

**Provenance labels:** `[grounded]` means it traces to the material the coach provided. `[inferred]` means it is derived from that material, and the derivation is named. `[generic]` means it is a role-family pattern that makes no claim about Northwind or Priya.

**Answer slots** are spots where the pack can't know the answer. Each one gives two honest branches, and Priya picks whichever is true, in her own words. The guidance is scaffolding, not a script.

---

## Fit snapshot

Requirements are quoted from the coach's JD highlights. Evidence is quoted from the coach's summary of Priya's background, since no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy & ops in consumer tech. It does not show GTM ownership for a B2B product line, and the words stay at that scope: "Nine years in product strategy and ops at a large consumer-tech company, after two in strategy consulting." Answer slot: the JD's GTM-ownership line makes a probe on launch or GTM decisions likely. If any were yours to make, say which and how you decided. If none were, say so plainly and stay with the product-strategy work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | The material is silent here. It does not say this was never done. Strong evidence looks like a time you segmented an installed base or a customer or partner population by stage and found where growth was being left on the table. Answer slot: if you have done anything like that, consumer or B2B, say what you looked at and what you found. If not, say so plainly and say how you would approach it here (see C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but nothing inspected stands behind it, and this interviewer self-describes as "relentlessly data-driven", so expect a live probe (A4). Say it in the quote's own terms: you're skilled in SQL and Tableau. Let the live answer show the skill rather than describing it |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A partner-level revenue model is adjacent to partner-motion design but is not the same thing. The words stay at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "required" makes a probe on motion design likely, meaning partner types, incentives and how deals are worked. If any of that was yours to shape, say which and how. If not, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already reaches the requirement: you set annual volume targets with cross-org consensus. Expect a probe on how the consensus was reached (A5). What the "volume" counted isn't in the material. Say it in your own words and don't upgrade it to revenue or quota |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Using AI tools daily touches the requirement, but the material doesn't show whether it reaches "AI experience" in the sense of building, pricing or selling AI products. Answer slot: say which tools you use and for what work. If any of it touched an AI product's strategy or launch, say what. If none did, say so plainly and keep it to your own use |
| F7 | Working fluently alongside sales-strategy conventions such as quota, territory and capacity planning. This is a role-family pattern for a peer of Sales Strategy and is not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [generic] | capability | A gap wording cannot close, and the coach has stated it. Words: "I haven't done classic sales-ops or quota-setting." Then how you'd learn it, said as a plan and never as a past. Never relabel the volume targets in F5 as quotas |

**Requirement coverage:**

| Requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, C3, D2 |
| "identify whitespace across land/adopt/expand/renew" | C3, A4 |
| "run independent analysis in SQL and Tableau" | A4, B4 |
| "partner-motion design experience required" | C4, A3, B5 |
| "strong cross-functional influence" | A5, B1, B3 |
| "AI experience a plus" | R2, C1 |
| Sales-strategy conventions (F7, role-family) | D1, B2, E1 |

---

## Reading the interviewer

Source: the coach's description of Dan's profile. Public-footprint research was attempted and refused by the host (see Sources), so none of it is independently checked.

| Signal | Source | Provenance | Practical implication |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | the coach's notes | [grounded] | Every number Priya says will be probed down to how it was counted. The ~$400M is the magnet (A1, E2). Saying "I don't know how finance counted it" calmly beats a reconstructed method |
| "career spine is pricing and monetization roles" | the coach's notes | [grounded] | Case questions are likely to lean on pricing, packaging and unit economics (C1, C2). It's their native language, so state the price metric and the margin logic out loud |
| "one early-stage-startup chapter" | the coach's notes | [grounded] | Builder-pace stories tend to land, and big-company pace may draw a scrappiness probe (D3, B4). The material carries no startup work for Priya, so this is not a shared jump and isn't offered as one |
| Peer of Priya, same VP | the coach's notes | [grounded] | Dan is assessing what this hire adds to or takes from their team. Expect seam and credit questions (bank B), with objections from other banks coming back in collegial packaging |

**Mirror opportunity, shared vocabulary rather than a shared jump:** Dan's pricing and monetization background meets F4: "built a partner-level revenue model used in carrier negotiations". Talking about that model in revenue-model terms (drivers, partner economics) speaks Dan's language. Keep the claim at the model's scope.

---

## Persona weights

The prior for a peer conversation is Peer Evaluator plus Data-Driven Prober. Dan's signals move them as follows: "relentlessly data-driven" raises the Prober, the pricing spine tilts Case toward monetization, and the startup chapter raises scrappiness skepticism a little. The coach's description of a single 60-minute conversation with Dan sets the format. No values round is documented, so there is no values cheat sheet, and Values gets light coverage only.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | "How was that counted?", denominators, two follow-ups deep | **Highest.** Peer prior, plus the self-description "relentlessly data-driven" | Know what you can and can't say about how each figure was counted. Name your weakest assumption first. Offer to talk through the queries live |
| B. Peer Evaluator | Seam, credit, "what do you need from me" | **Highest.** Same VP, adjacent team, and the role touches Sales Strategy's turf | Reciprocity first. Propose seam principles rather than claiming to know the seam |
| C. Case/Strategist | Compass pricing, bundling response, partner design | **High.** The pricing spine makes monetization cases natural, and the JD's partner requirement invites a design question | Clarify, then objective, segments, approach, metrics, risks. Say the price metric out loud |
| D. Skeptic | "No quota background", "consumer, not B2B" | **Medium-high.** F7 and F1 are gaps that sit squarely in Dan's world | Rehearse D1 until it's boring. Give the acknowledgment, then adjacent quotes, then a ramp plan |
| E. Pressure | Time-boxed "why you", "how much was you" | **Medium.** Peers rarely run stress interviews, but data-driven probing can feel like one | Pause, restate, hold through two follow-ups, then make a specific concession |
| R. Conversational | Opener, AI-tools chat | **Medium.** Almost every hour opens this way, and AI is a JD plus asked casually | A 90-second arc. Treat casual AI questions as scored |
| V. Values | Disagreement, unpopular-truth stories | **Low.** No values round is documented, but peers probe working style | A selection scaffold for each, with an honest branch |

---

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift from the store-surface change was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the quote's own two verbs: you proposed the change, and the uplift was credited to it. Keep the "~". Answer slots, in your own words: how the figure was counted (if you don't know how it was attributed, say "I don't know exactly how it was counted"), what it's sensitive to, the assumption behind it you'd defend least (name it before Dan does), and which part was yours. Never supply a baseline or attribution method you can't repeat under a second question | F1's headline figure is the first thing a self-described data-driven interviewer will pull on. EXP because it tests whether the claim survives scrutiny |
| A2 | "You proposed it. Who decided to ship it, who built it, and who did the crediting?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: say who decided, who built it and how the credit was assigned, as far as you know, in your own words. If you don't know how the crediting worked, say so. If some of it was yours beyond proposing, say which part. If none was, say so plainly: proposing a change that later gets credited is a complete, honest story | Attribution is the follow-up to A1, and peers listen hard for credit-taking. EXP because it is the "what was actually you" test |
| A3 | "Tell me about the partner-level revenue model. What went in, what came out, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built the model, it was partner-level, and it was used in carrier negotiations. Those are the beats the quote states. Answer slot: the JD's partner-motion requirement makes a probe on the model's drivers likely. If you can describe its inputs and outputs, do so in your own words. Say how it was used and by whom. If you weren't in the negotiations, say so plainly: the model was used in them | F4 is Priya's closest evidence for the one requirement marked "required", and Dan's pricing background makes revenue models native ground. EXP because the scope of "used in" is exactly what gets probed |
| A4 | "Say you have an accounts table, a product-usage table and contract dates. What's the first query you'd write to find expansion whitespace?" | CASE | [generic] | Think out loud. Set the grain (one row per account), join usage to contracts, then segment by size or industry. Next, flag accounts with low adoption of a new product line compared with similar accounts, and accounts with renewals coming up that haven't adopted it. Say what you'd check for data quality before trusting the output. Then say how you'd show it in Tableau: a ranked list for Sales, not a pretty map. The question makes no claim about your past, and neither does the answer | A live test of F3 and of the land/adopt/expand/renew line (F2). CASE because it scores live reasoning. `[generic]` because the approach is a pattern, not a Northwind fact |
| A5 | "You set annual volume targets with cross-org consensus. How did you actually get the consensus?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: annual volume targets, set by you, with cross-org consensus. Say in your own words what the volume counted, and don't upgrade it to revenue or quota. Answer slot: the JD's "strong cross-functional influence" line makes a probe on how the consensus was reached likely. Say who had to agree and what moved them, in your own words. If a group pushed back, say what happened. If the consensus came easily, say that plainly and describe the process | F5 is the influence evidence, and it sits right next to quota-setting (F7). The answer must keep the two separate. EXP because the scope of "volume targets" is what's tested |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams would sit side by side. Where's the seam between Sales Strategy and GTM Strategy for Emerging Products, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know the seam. Propose principles: one shared source of truth for the numbers, clear decision rights (who owns what for new lines versus the core), disagreements settled on data first and taken to the shared VP only as a last resort, with a recommendation you both wrote. End by asking how Dan sees the seam today | The core question for a peer hire. CASE in delivery, scored on partnership judgment. `[generic]` because the seam principles are a pattern |
| B2 | "When a new product line launches, who should own its targets, your team or mine?" | CASE | [generic] | Reciprocity framing: a GTM lead would bring the market and whitespace view, and Sales Strategy owns how targets turn into quota, territory and capacity. Propose a joint first year with a hand-off point. Make no claim to have set quotas yourself (F7). The pack lists that as something not to coach | Turf is what the peer seat is most sensitive about, and F7 makes it easy to overreach here. CASE, scored on turf awareness |
| B3 | "Tell me about a time you disagreed with a peer at your level and it didn't go your way." | VAL | [generic] | Selection scaffold: pick a disagreement with an equal where you made your case with data, lost, and the relationship survived. It needs a named stake, what you argued, what you did after the decision, and what you learned. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers check how you disagree with equals. VAL (working style), and an open prompt because no quote carries a disagreement story |
| B4 | "What would you need from my team in your first 90 days, and what would you give us back?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with what you'd give back. You're skilled in SQL and Tableau, so offer to run your own analysis on the new lines instead of queuing requests with Dan's analysts, and to share what you build. Then ask for a small number of things: access to pipeline and bookings data, and a walkthrough of how quota and territory work, which is a learning ask tied to F7. Keep the ask list shorter than the give list | The "independent analysis" requirement (F3) framed as reciprocity, which is what a peer is scoring. JD because it tests a stated requirement in peer packaging |
| B5 | "How would you handle credit on a partner-sourced deal that one of my reps closes?" | CASE | [generic] | Structure it: define partner-sourced versus partner-influenced before the motion launches, credit both sides openly (for example, rep credit plus partner attribution reported separately) so neither team is pitted against the other, and review the rules after a quarter of data. Propose it as a joint design. The question asks about no past, so don't invent a crediting system you've run | Partner credit is a well-known conflict point between partner and sales teams, and it touches the partner requirement (F4). CASE, scored on fairness and design |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass, our AI copilot: standalone SKU, bundled, or usage-based? How would you decide?" | CO | [grounded] coach's research note: "an AI copilot launch ('Compass')" and "reaching profitability" | Clarify first: who uses it, and is it attached to the core platform. Objective: profitability is a stated priority, so inference cost sets a margin floor. Options: bundled (drives adoption, protects renewals, eats margin), add-on (clean revenue, adoption risk), usage-based (matches cost but makes spend hard for buyers to predict). Metrics: attach rate, effect on net revenue retention, gross margin. Name the risk: a larger vendor bundling makes "free" the comparison point. Give a recommendation and say what data would change it | Pricing is Dan's native language and Compass is a stated priority. CO first (homework on the launch) with CASE delivery |
| C2 | "A much bigger platform vendor bundles a good-enough version of one of our new products for free. What's your GTM response?" | CO | [grounded] coach's research note: "bundling by a much larger platform vendor" | Don't race to zero. Clarify where "good enough" fails: depth, performance, neutrality across clouds, support. Segment: aim at accounts where the bundle's gaps hurt, and defend the installed base through renewal and expansion bundling of your own. Partners can carry reach the bundle has. Metrics: win rate against the bundle, discounting, retention among exposed accounts. Concede the cost: some low-end segments are lost, and that's acceptable under the profitability priority | The named competitive threat is the most likely strategy question. CO, CASE delivery |
| C3 | "Size the whitespace for one of the two new product lines inside our existing enterprise base. What do you need first?" | JD | [grounded] JD highlights: "identify whitespace across land/adopt/expand/renew" | Clarify the product's buyer and its prerequisites. Segment the base by fit (has the prerequisites) and stage: land (no product), adopt (bought, low usage), expand (healthy usage, room to grow), renew (renewal coming up). For each stage give an accounts count times a realistic deal size, and say which inputs you'd query yourself. Name the weakest assumption in your own sizing, the deal-size estimate, before Dan does. Close with which stage you'd go after first and why, tied to the enterprise-expansion priority | The JD's whitespace line (F2) asked as a live case. JD first because it scores a stated responsibility, with CASE delivery |
| C4 | "Design a partner motion for one of the new product lines: which partner types, what economics, and how would you know it's working?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Partner types to weigh: systems integrators, cloud marketplaces, resellers, technology alliances. Choose based on where buyers already buy. Economics: margin or referral fee against the cost of selling direct, and the conflict rules with direct sales (see B5). Signals it's working: partner-sourced pipeline, time to first deal, net margin after partner fees. If you bring in your own past, keep it at the quote: "I built a partner-level revenue model that was used in carrier negotiations." Let Dan draw the connection, and don't present it as having designed a motion | The one requirement marked "required", and F4 is a transferability gap. A live design shows the capability without overstating the past. JD, CASE delivery |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **HIGHEST-ROI PREP.** "I don't see sales-ops or quota-setting in your background, and that's most of what my team does. Why should Sales trust a GTM model from someone who hasn't set quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Open with the limit, before it's pushed:** "That's right. I haven't done classic sales-ops or quota-setting." **Then the adjacent evidence, at its own scope:** "I set annual volume targets with cross-org consensus, and I built a partner-level revenue model that was used in carrier negotiations." **Then a plan, said as a plan:** in the first 30 days, learn how Dan's team builds quota and capacity, and build new-line targets with them rather than alongside them. **Follow-up 1:** "Volume targets are basically quota, right?" Hold: say in your own words what the volume counted, and that it wasn't quota. Don't let the two merge. **Follow-up 2:** "So we'd be training you?" Concede the specific thing: yes, on quota mechanics. Hold the rest: the analysis and partner economics are where you start contributing | The single most predictable objection. F7 is a stated gap that sits inside Dan's own function, and the peer seat makes it personal. JD because it tests fit to the role's working reality. This gets the most follow-up rehearsal in the pack |
| D2 | "Your last nine years were in consumer tech. What breaks when you take that into B2B enterprise data infrastructure?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Name what changes, as analysis rather than as your past: buying committees, longer cycles, land-and-expand economics, renewals as the revenue engine, partners in the deal. Then say what carries over: analysis, structure and revenue modeling. Answer slot: if any of your consulting work touched B2B or enterprise clients, say what, in your own words. If not, say so plainly. Don't claim B2B GTM experience | F1's transferability gap, in the domain direction. JD because it scores whether the stated role can be done from this background |
| D3 | "Why move from product strategy into GTM, and why now?" | EXP | [generic] | Selection scaffold: one honest reason for the move, one reason for Northwind specifically (Compass, two new lines, the bundling fight), and one reason for now. It has to match what you told the recruiter. If the "why GTM" reason isn't clear in your own mind yet, work it out before the interview. Don't make up a narrative | The motivation probe from the Skeptic persona. EXP because it tests consistency of the career story, and `[generic]` because no stated motive is in the material |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's run sales strategy at a SaaS company?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause, then three beats in about 45 seconds: independent analysis (you're skilled in SQL and Tableau), partner economics (you built a partner-level revenue model used in carrier negotiations), and influence (you set annual volume targets with cross-org consensus). **Hold** through two pushes by coming back to those three. **Concede specifically:** "Someone from SaaS sales strategy knows quota mechanics better than I do today. I haven't done classic sales-ops or quota-setting." Don't run the other candidate down | Time-boxed comparison is the classic pressure move, and F7 is the obvious lever. JD because it scores fit, with the hold-then-concede structure |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the quote's exact shape: "I proposed the change, and it was credited with roughly $400M ARR uplift." Answer slot: if you did more than propose, say what, in your own words. If not, say so plainly. If pushed a second time, don't add to the claim and don't shrink it below the quote. Concede only what you don't know, such as how the credit was calculated | The attribution stress test on F1's headline figure. EXP, and a pressure delivery of A1 and A2 |

### R. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "proposed a store-surface change credited with a ~$400M ARR uplift"; "built a partner-level revenue model used in carrier negotiations" | A 90-second arc: two years of strategy consulting, then nine in product strategy & ops at a large consumer-tech company. Two highlights at their own scope: the partner-level revenue model used in carrier negotiations, and the store-surface change you proposed that was credited with roughly $400M ARR uplift. Close with why this role, in your own words (see D3). Don't call either highlight GTM ownership | Almost every peer hour opens this way, and the casual register is still scored. EXP because it previews the claims the Prober will test |
| R2 | "What are you actually doing with AI tools these days?" | JD | [inferred] "uses AI tools daily" | Answer slot: name the tools and the work you use them for, in your own words. Concrete beats broad. If any of it involved an AI product's strategy or launch, say what. If none did, say so plainly and keep it to your own use. Then connect to Compass with a question rather than a claim: what you'd want to know about how analysts would use it | "AI experience a plus" asked casually. F6 is low-confidence, so the guidance stays a slot. JD because it scores a listed plus |

### V. Values / working style

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a time you brought leadership a finding they didn't want, backed by data, and it changed something. It needs the stakes, what you said, how it landed, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Data-driven peers want to know you'll bring bad news with numbers. VAL, open prompt, `[generic]` because no quote carries the story |
| V2 | "When did you put a partner relationship ahead of a short-term number?" | VAL | [generic] | Selection scaffold: a decision where you gave up a near-term gain to protect a partner or customer relationship. It needs the trade, who disagreed, and how it played out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the JD's partner-motion requirement. VAL because it scores judgment, and an open prompt because no story is in the material |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| 1 | "Coming from pricing and monetization, where do you think packaging for the new product lines is most likely to clash with how your reps sell today?" | Tied to Dan's career spine. It invites them to teach their native subject and shows Priya researched them, not only the role |
| 2 | "You've been at an early-stage startup. Do these two product lines feel more like startups inside Northwind, or extensions of the core motion? What would that mean for how our teams work together?" | Tied to Dan's startup chapter. It turns the pace question into a peer conversation |
| 3 | "What could a new person in this seat do in the first month that would genuinely take load off your team?" | The reciprocity question a peer listens for. It signals Priya will add capacity, not take it |
| 4 | "Where do the numbers for emerging products live today? Is there a shared source of truth with Sales Strategy, or is that something we'd build together?" | Speaks to "relentlessly data-driven" directly, and opens the seam conversation from B1 |
| 5 | "How is Compass expected to show up in enterprise expansion: attached at renewal, sold as a standalone land, or something else?" | Connects two stated priorities, and shows Priya is thinking at Northwind's level rather than reciting it |
| 6 | "With profitability a stated priority, how does our VP weigh growth on the new lines against margin?" | It shows Priya how the shared boss decides, which is the context both peers work within |

---

## Prohibited claims

What this pack will not coach, and why. These are built from the fit snapshot because they're the claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered $400M ARR | Inflated form of F1 | F1's quote at its own scope: proposed the change, which was credited with roughly $400M ARR uplift. The material says "proposed" and "credited", not "drove" |
| Has set quotas or run sales ops | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting." No slot |
| The volume targets were quotas or revenue targets | Inflated form of F5 | F5's quote at its own scope: annual volume targets with cross-org consensus. What they counted is said in Priya's own words |
| Has designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: built a partner-level revenue model used in carrier negotiations. The material says the model, not the motion |
| Negotiated the carrier deals | Inflated form of F4 | The model was "used in carrier negotiations". Who negotiated is an answer slot (A3) |
| Has owned B2B GTM for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy & ops in consumer tech. The material says product strategy, not GTM ownership |
| Has built, launched or priced AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. R2's slot stays inside that |

---

## Sources

**Provided material:** the coach's message, including the JD highlights, Priya's background summary, Dan Kovac's profile summary, and the coach's research note on Northwind's priorities and competitive threat. No dossier was consumed.

**Searches sent:**

- `Northwind Data company values`: refused (search permission not granted)
- `Northwind Data interview process strategy`: refused
- `Dan Kovac Northwind Data sales strategy`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. Would have supplied official value names to theme the V bank. With no values round documented, there would still be no cheat sheet |
| 2. `Northwind Data interview process` | unavailable | The search was refused. This session's format is set by the coach's words. It would have shown the other rounds and whether a values round exists elsewhere in the loop |
| 3. `Northwind Data strategy` / recent news | skipped | The coach's research note supplies the three priorities and the bundling threat behind C1, C2 and the reverse questions. Its age isn't stated, so check it's current |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. Would have checked the profile summary and surfaced any talks or writing for the interviewer read and reverse questions |
| 5. Representative role JD | skipped | The coach supplied the JD highlights, which set the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Full JD text** → mid-list requirements that the highlights left out get their own fit rows and JD questions, and the coverage table becomes complete
- **Priya's CV** → evidence cells quote her own CV lines instead of a summary, and V1, V2, B3 and D3 can become story-mapped instead of scaffolds
- **Priya's answers to the answer slots in A1, A2, A3, A5, D2 and R2** → those rows become story-mapped guidance with her own beats
- **Granting search permission** → targets 1, 2 and 4 run: official values, loop structure, and a check of Dan's public footprint
- **Deep research (up to 6 more searches and 2 more fetches, several more minutes)** → a grounding brief on Compass, the two new product lines and the bundling competitor, which sharpens C1 and C2
- **Recruiter or HR guidance** → coverage of any focus areas or pre-declared deliverable, such as a case or presentation
- **Prep time available** → a prioritized prep schedule sized to it
- **Anything inspectable behind the ~$400M or the partner revenue model, such as a redacted deck or memo Priya can describe** → F1 and F4 evidence moves from claimed toward inspected, and A1 and A3 get firmer holds
- **A tuesday-dossier.md** → verified evidence and an evidence-derived prohibited-claims list, in place of the ones this pack built from the summary
