I've written your prep pack: 20 practice questions, each with answer guidance built only from what you told me. Saltmarsh's careers page describes its 60-minute interview, which it calls the "Outage Hour", as a session with the hiring manager in two halves:

1. **A live tabletop exercise.** You're walked through a simulated server outage during a live event and talk through how you'd handle it.
2. **A values conversation** about the company's three published values: *Players Before Plans*, *Ship the Patch Not the Promise* and *Leave the Build Greener*.

I built the pack on the assumption that your Friday interview is this session and that Tobias is the hiring manager. Your note didn't confirm either.

**What's likely to matter most:**
- **The question most worth rehearsing (C1):** "I don't see in-app purchases in your background." In September Saltmarsh announced Project Larkspur. It moves two of its games, Tidepool Tactics and Lantern Row, to a season pass with one shared events calendar from February 2027. That puts your in-app purchase gap right at the centre of this job's next year. The pack has you name the gap first, in your own words ("I haven't worked on a game with in-app purchases"). Then you hold to the content calendar you did run, and offer a plan for learning the season-pass side.
- **Tobias:** he was a QA lead before live ops, and his GDC 2026 talk "Patch Notes Are a Promise" argues that a live team is judged by whether its patch notes match what actually shipped. Two things follow:
  - Expect detailed questions on the release checklist you wrote.
  - Overclaiming will probably cost you more with him than an honest gap.
- **Your strongest material:** two years running the weekly content-drop calendar, and the release checklist QA still uses. The checklist lines up almost word for word with the value *Leave the Build Greener*.
- **Words to keep out of your answers:** the pack has a short "Prohibited claims" list, such as saying you ran "live events" rather than content drops, or that you "managed" releases rather than wrote the checklist. Each one is a small stretch an interviewer could catch.

The pack also has a table matching your background to each JD line, five more tabletop questions, a values cheat sheet, and six questions to ask Tobias.

I can play Tobias and run C1 with live follow-ups, then give you feedback.
I can also save a `tuesday-dossier.md` file recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter tell you anything about the tabletop scenario, or confirm that Tobias is the hiring manager? If they named the scenario, I'd rebuild the tabletop questions around it.

Do you want a deeper research pass? It's up to 6 more searches and 2 more page fetches, and takes a few more minutes. It would add a company briefing and a closer read of Tobias's talk.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/alone/part-2/rooms/case-7-canned-dd714499:
- saltmarsh-games_live-operations-producer_interview_pack.md

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer at Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Session:** 60 minutes, Friday 27 November 2026
**Round, as Saltmarsh describes it:** Saltmarsh's interviewing page says every loop is a recruiter call followed by "the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation." This pack assumes your 60 minutes is that session and that Tobias is the hiring manager. Both are readings of that page plus your note, not something you've confirmed.

---

## How to use this pack

- **Personas** are *how* a question is asked: the interviewer's style and pressure. **Types** are *what* is being scored. One persona can ask any type.
- **Type key:**
  - **CASE**: a live problem from the role, scored on structure and reasoning. The Outage Hour tabletop is entirely this.
  - **VAL**: whether your past behaviour shows Saltmarsh's *published* values.
  - **JD**: whether you can do the job as the posting lists it, gaps included.
  - **EXP**: whether what you've said about your work holds up when someone digs into it.
  - **CO**: company and strategy knowledge, here mainly Project Larkspur.
- **Provenance labels:** `[grounded]` = traceable to your message, the JD, or a source listed under Sources. `[inferred]` = derived, with the derivation named. `[generic]` = a common pattern for this kind of role, with no claim about Saltmarsh or about you.
- **Answer slots** mark places where the pack doesn't know what you did. Each has two honest branches: what you actually did, or a plain "that wasn't part of my role". Either branch is a good answer. Inventing a third one isn't.
- The guidance is scaffolding, not a script. Say it in your own words.
- Question IDs go A, B, C, D, E, G by persona. The letter F is kept for fit-snapshot rows (F1 to F9).

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes content drops on one title. It doesn't mention live events or two titles, so keep your words at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on events likely. If any of those drops were events, say what they were, in your own words. If none were, say so plainly and stay with the drops you scheduled |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | The JD asks you to coordinate teams, not lead one, and your statement is about leading. Your material doesn't say either way whether you coordinated across teams. Answer slot: if your calendar work meant working with design, art, engineering or community, say who and how, in your own words. If it didn't, say so plainly and stay with the calendar. If you're asked about leading a team, the words are yours: "I haven't led a team" |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly retention numbers sits next to a post-event review but isn't one, and the words stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you ever reviewed a specific drop after it went out, say what you looked at, in your own words. If not, say so plainly and say what you would put in one |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. It's a statement with nothing inspected behind it, so expect a probe, especially from an interviewer with a QA background (see the interviewer read). Lead with it in its own terms: you wrote it, and QA still uses it. Answer slot: the JD's "manage" makes a probe on running it release by release likely. If you did, say how, in your own words. If running it wasn't yours, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are covered. Your material doesn't say whether the main title was run as a live service. Answer slot: if it was, describe how it ran, in your own words. If it wasn't, say so plainly and stay with the weekly content drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. This is your strongest row. Say it as written: weekly, the main title, two years, and you ran it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect a probe into the numbers themselves. Answer slot: the JD's "comfortable with" makes questions about which metrics they were, and what moved them, likely. Answer from what you actually know. If you didn't produce the numbers or analyse them, say so plainly and stay with presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist another team still uses is a piece of written work. Keep the claim to that, and let the interviewer draw the conclusion. In the tabletop, A3 is where this requirement gets scored live |
| F9 | "moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh, Project Larkspur announcement | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap that wording can't close, and you've said so yourself. The words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, framed as a plan and never as something in your past. Don't add anything to make the gap sound smaller. (That a season pass involves in-app purchases is the pack's reading of the announcement, and it is `[inferred]`.) |

---

## Reading the interviewer

| Point | What it means for Friday | Provenance |
|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh and was previously a QA lead at a console studio, according to his GDC 2026 talk listing | His path into live ops ran through QA, so release checklists are his home ground. Expect D3 and E2 to go deep. Keep "wrote" at its scope (F4) | [grounded] |
| His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped | This is the theme he chose to speak on publicly. It lines up with the Saltmarsh value "Ship the Patch Not the Promise". In the tabletop's player messages (A3), say only what is known and built | [grounded] |
| Reading: a talk about claims matching reality suggests that overclaiming will cost more with him than an honest gap | The candour in C1 and C3 is likely to land, not just to be survivable. This is reasoning from his talk's stated argument, not something he has said about candidates | [inferred] |
| Shared vocabulary: the release checklist. Your side of it is F4: "Wrote the release checklist our QA team still uses." | One shared reference point, used once and naturally. It's not a shared career jump: your material doesn't show a QA-to-live-ops move, so don't offer one | [grounded] |

---

## Persona table

| Persona | How it shows up in the Outage Hour | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event, run live | **Very high.** Saltmarsh's interviewing page names the tabletop as half the session, and hiring managers lean toward live problems anyway | Clarify, then objective, then sequence, then comms, then metrics, then risks. Think aloud, and question one premise respectfully |
| Values / Behavioral | The second half: the values conversation | **High.** The page names it, and Saltmarsh publishes three values by name | One story or one honest scaffold per value, using the value names exactly. "We" for context, "I" for your own part |
| Skeptic | Probes on your gaps: in-app purchases, one title versus two, coordination | **High.** Hiring managers derisk gaps, and Project Larkspur puts the in-app purchase gap (F9) at the centre of the role's next year | Rehearse C1 until it bores you. Bridge only from what your quotes carry, and pair it with a concrete plan for learning |
| Data-Driven Prober | Digs into the retention numbers and the checklist | **Medium.** The JD names retention metrics and KPIs, and his QA background points to checklist depth | Know what you can and can't say about how the numbers were counted, and say "I don't know" where that's the truth |
| Pressure | Time-boxed "why you" questions, or a challenge on attribution | **Low to medium.** Nothing in the sources points to a stress style, but a 60-minute two-part session leaves little room, so expect some time-boxing | Pause, restate the question, hold what you actually said, and concede only what's real |
| Conversational | The opener and the warm-up | **Low.** The session is short and structured, but most interviews still open with "tell me about yourself" | A 90-second biography arc built only from your own sentences |
| Peer Evaluator | Not expected | **Omitted.** The page describes a single interview with the hiring manager, so there's no peer round to prepare for | None needed |

---

## Question banks

### A — Case / Strategist: the tabletop (weight: very high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're mid-event and the event servers go down. Talk me through your first thirty minutes." | CASE | [grounded] | Clarify first: what exactly is down, on which title, since when, and who's on call. State the objective: limit harm to players and protect the event's fairness. Then sequence it: confirm and declare the incident, name the owner of each strand, get first player comms out, decide what happens to the event (pause, extend or compensate), then log decisions as you go. Use the value names where they fit: Players Before Plans is why extending the event is on the table, and Ship the Patch Not the Promise is why comms give no fix time you don't actually have. Question one premise, for example by asking whether the outage affects everyone or one platform. The question needs no claim about your past, and the guidance makes none | The page names a simulated outage during a live event as the session's core. CASE because it scores live structure, not your history |
| A2 | "Who do you pull in, and who talks to whom?" | JD | [grounded] | Map it to the JD's four teams: engineering on the fix, community on player channels, design on what the event outage does to rewards and progression, art only if assets must change. Say who decides and who's informed, and how often updates go round. Keep it as a plan for this scenario, not a description of past coordination (F2's slot covers that if it's asked) | Covers the JD's coordination requirement live. JD-tagged because it scores a listed responsibility, delivered as a case |
| A3 | "Draft the first player-facing message, out loud." | JD | [grounded] | Short: what's affected, that the team is on it, what happens to event progress, and when the *next update* comes, not when the fix comes. Saltmarsh's value says "we announce what is built, not what is hoped", and Tobias's talk is about notes matching reality, so a promised fix time is the trap here. Then say what the second message would add | Scores "clear written communication" in the setting most likely to test it. JD because written communication is a listed requirement |
| A4 | "It's fixed. What goes in the post-event review, and which KPIs does it report?" | JD | [grounded] | Structure: timeline, impact (who was affected and for how long, event participation, and retention for affected players against unaffected ones), cause, decisions made and whether they held up, and what changes. Close on Leave the Build Greener: the review should leave the release checklist better than it found it. Speak as a plan for this incident. Whether you've run one before is F3's slot, if it's asked | The JD makes owning the review and its KPIs a core duty. JD-tagged, delivered as a case |
| A5 | "From February both titles run on one shared events calendar. What would you plan for first?" | CO | [grounded] | Show you've read the Project Larkspur announcement: shared calendar, season-pass model, one live-ops group. Then think aloud about likely collision points: two titles' events competing for the same players' time, a shared QA and release cadence, and season-pass beats needing to land on the calendar. End with a question back, such as what the team has already decided. Make no claim about season-pass experience (F9); if it comes up, see C1 | The required strategy-grounded question. CO for the homework, with CASE delivery, and the most current thing you can show you know |

### B — Values / Behavioral: the values conversation (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: choose a moment from running that calendar when something planned changed, or should have changed, because of what players were doing. It needs the plan, what players were showing you, what you decided or recommended, and what happened. If no such time comes to mind, say so plainly, then say how you would decide when the calendar and the players pull apart | Saltmarsh's first published value, defined as "when the calendar and the players disagree, the players win". F1 and F6 are the nearest material, but they don't carry the story, so this is a scaffold |
| B2 | "Ship the Patch Not the Promise: when have you had to announce only what was actually built?" | VAL | [generic] | Selection scaffold: a time an announcement, note or update had to be cut back to what was ready. It needs what was hoped for, what was actually ready, and what you said. If no such time comes to mind, say so plainly, then say how you would handle a drop where content slips the day before it's announced | The second value, and the theme of Tobias's talk, so likely to be pressed hard. Nothing you've told me carries this story, so it's a scaffold |
| B3 | "Leave the Build Greener: tell me about leaving a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. The beats are what the sentence states: you wrote it, and QA still uses it. Answer slot: the value says every release should leave "the checklist better than it found them", so expect a probe on whether you changed it after a release. If you did, say what changed and why, in your own words. If not, say so plainly and stay with writing it and its continued use | The third value names the checklist outright, and this is your strongest match. VAL first, and it also covers the JD's release-checklist line |
| B4 | "Tell me about a time you delivered an unwelcome truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. Your nearest material is presenting the monthly retention numbers to the studio head, but whether any month carried bad news is something only you know. If one did, tell what the numbers showed, what you said and what happened next. If none did, or nothing like this comes to mind, say so plainly, then say how you would deliver a poor post-event result | A standard values prompt that tests candour, which lands with this interviewer. F3 and F7 are adjacent material; the pack supplies no story |

### C — Skeptic (weight: high)

**C1 is the highest-return prep in this pack.** Rehearse it out loud more than once.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases in your background, and we're moving both titles to a season pass. How would you handle that side of the job?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years." | Name the limit before you're pushed: "I haven't worked on a game with in-app purchases." Don't apologise or shrink it. Then the adjacent fact at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then a plan, framed as a plan: what you'd learn first (how the pass's rewards sit on the calendar, which pass KPIs the team reads, and who owns pricing decisions) and who you'd learn it from. **Follow-up 1:** "So you'd be learning monetisation on our live games?" Hold: yes, on that side, while the calendar side is work you've done. **Follow-up 2:** "Why take that risk?" Concede exactly: "The season-pass side would be new to me." Hold: the two years on the weekly calendar. Never suggest the puzzle title had monetisation, or that a content drop is the same as a pass | F9 is the gap that Project Larkspur puts at the centre of this team's next year, and you've stated it yourself. That makes it the most predictable objection. JD-tagged because it scores fit to the role as it is about to become |
| C2 | "You've run the calendar for your main title. This role runs two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Don't claim two titles. Restate F1 as it is, then reason forward: what doubling the calendar does to clashes, to QA load and to shared resources. With a shared calendar from February (A5), it's one calendar across two games, and you can say that's what you'd plan for. Answer slot: if your studio's other titles ever touched your calendar, say how, in your own words. If they didn't, say so plainly and stay with the main title | F1's scope gap against the JD's "two of our mobile titles". JD because it scores a listed requirement head-on |
| C3 | "Have you led a team? This role pulls four disciplines together on every update." | JD | [grounded] "Never led a team" | Plain acknowledgment, in your own words: "I haven't led a team." Then the distinction, stated as what the JD says rather than as a claim about yourself: the posting asks for coordination. Answer slot: if your calendar work meant working with design, art, engineering or community, say who and how. If it didn't, say so plainly and describe how you would set up coordination for an update (A2 is your rehearsal for that) | The Skeptic will press F2. JD because coordination is a listed requirement. Your stated negative gives the acknowledgment a source |
| C4 | "Your four years were at a puzzle studio. Was that a live-service game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if the main title ran as a live service, describe how, in your own words. If it didn't, say so plainly and stay with the weekly content drops you ran the calendar for. Don't stretch "content drops" into "live events" (F1) | F5's discovery gap against "3+ years producing live-service games or apps". JD because it's a stated requirement with a number attached |

### D — Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. Which metrics, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slots, in your own words: which metrics they were; how they were counted; what they were sensitive to; and the assumption behind them you would defend least. Name that assumption before you're asked. Say which part was yours: producing them, analysing them, or presenting them. "I didn't build the numbers; I presented them" is an honest branch, and so is "I don't know how that was counted" | F7 and F3: the JD's retention line makes these numbers the Prober's first target. EXP because it tests what was actually yours |
| D2 | "How did you know whether a content drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you judged drops against a measure, say which one and what you did with the result, in your own words. If that wasn't part of your role, say so plainly and say what you would measure on a Saltmarsh event (A4 gives you the shape) | Connects F6 to the JD's post-event review and KPIs (F3). EXP because it probes what running the calendar actually included |
| D3 | "Talk me through the checklist QA still uses. What's on it, and what would you change now?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Describe it from memory, in your own words: its sections and its order. Then one thing you'd change today, framed as a plan. Answer slot: if you've revised it since you wrote it, say what and why. If not, say so plainly. Don't describe sign-off powers, gates or processes it doesn't actually have | F4 is your strongest artifact, in front of an interviewer whose path ran through QA. EXP because depth of recall is what's being scored |

### E — Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live events on a game like ours?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "never worked on a game with in-app purchases" | Pause, then answer in three beats and stop: the calendar (F6, as quoted), the checklist (F4, as quoted), and what you'd do in your first month. If they push, concede what's real, in C1's words: "I haven't worked on a game with in-app purchases." Hold the two quoted facts through a second push. Don't fill the silence with extra claims | A time-boxed "why you" is standard pressure. JD because it scores fit against the posting |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the sentence as it stands: you wrote it. Answer slot: if others contributed sections or reviewed it, say who and what, in your own words, because precise credit holds up better than full credit. If no one did, say so plainly. The second push often comes as "so QA didn't shape it?" Hold what's true, and concede only what's real | The pressure stem on attribution, aimed at F4, your headline artifact. EXP because attribution is what's scored |

### G — Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from these four sentences: the role and studio, the calendar, the checklist, the retention numbers. End on why live ops at Saltmarsh, in your own words. Don't use "led", "owned" or "managed" anywhere in it | Almost every session opens this way, and in a 60-minute two-part format a tight opener buys time for the tabletop. EXP because the biography is itself a set of claims |
| G2 | "Why Saltmarsh, and why now?" | CO | [grounded] | Answer slot: your actual reason for moving, in your own words. The pack has none from you, so it supplies none. Then something specific about Saltmarsh: a value by name, or Project Larkspur's shared calendar (A5). Don't say anything negative about your current studio | Motivation is checked in casual register. CO because the "why here" half scores homework |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | C2, A5, B1 |
| Coordinate design, art, engineering and community | A2, C3 |
| Own the post-event review and its KPIs | A4, D2 |
| Manage the release checklist with QA | B3, D3, E2 |
| 3+ years producing live-service games or apps | C4 |
| Experience running a content calendar | C2, E1, G1 |
| Comfortable with player-retention metrics | D1, A4 |
| Clear written communication | A3 |

---

## Values cheat sheet

Saltmarsh's three published values, with names exactly as the values page gives them.

| Value (official name) | Working meaning (paraphrased) | Your mapped story | Questions |
|---|---|---|---|
| Players Before Plans | When the schedule and what players are doing pull in different directions, the players win | Selection scaffold. F1 is the nearest material: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a real moment from it if one exists. If none does, say so plainly and say how you would make that call | B1, A1 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold: a time an announcement had to shrink to what was ready. If none comes to mind, say so plainly and say how you would handle a late slip | B2, A3 |
| Leave the Build Greener | Every release should leave the code and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." | B3, A4 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argued that a live team is judged by how often its patch notes describe what actually shipped. How does the team here keep track of that?" | Tied to his own published work. It shows you prepared for *him*, and it invites him to talk about something he cares about |
| R2 | "You came to live ops from QA. What did that background change about how releases are run here?" | Tied to his career path, and it sits right next to F4, so the conversation turns to checklists on your strongest ground |
| R3 | "With Project Larkspur putting both titles on one calendar from February, what would this producer own in the first ninety days?" | Shows you've read the announcement, and the answer tells you what the job really is next year |
| R4 | "Who reads the post-event review, and what gets decided from it?" | The JD makes the review yours. The answer tells you whether it's a report or a decision tool |
| R5 | "When the calendar and the players disagree, who makes the call to change an event mid-run?" | Uses the value's own words, and the answer shows how much authority this role carries |
| R6 | "What would a strong first post-event review from a new producer look like to you?" | Shifts the conversation to what good looks like, and gives you a concrete target if you're hired |

---

## Prohibited claims

This pack won't coach these claims, in any cell, drill or follow-up.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar | Inflated form of F1 | F1's quote at its own scope. As the pack reads it, your material says content drops, not live events. C4's slot stays inside the drops |
| Ran calendars across several titles | Inflated form of F1 | F1's quote: "for our main title". C2 reasons forward rather than claiming the past |
| Managed releases with QA, or ran QA sign-off | Inflated form of F4 | F4's quote: you wrote the checklist, and QA still uses it. D3 and E2's slots stay inside that |
| Owned or analysed the retention KPIs | Inflated form of F3 and F7 | The quote at its own scope: you presented the monthly retention numbers. D1's slots ask only what you know about how they were counted |
| Has led a team | A negative you stated, F2 | "I haven't led a team." C3 separates that from coordination, and coordination stays an answer slot |
| Has worked with in-app purchases, monetised events or a season pass | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." Then a learning plan, framed as a plan |

---

## Sources

**Provided:** the JD and your background, both pasted in your message.

**Searches and fetches sent:**

- Search "Saltmarsh Games values": returned https://saltmarshgames.com/values
- Search "Saltmarsh Games interview process producer": returned https://saltmarshgames.com/careers/interviewing
- Search "Saltmarsh Games mobile studio news": returned https://saltmarshgames.com/news/project-larkspur
- Search "Tobias Wrenfield Saltmarsh Games": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search result listing only; the talk itself wasn't fetched)
- Fetch https://saltmarshgames.com/values: the three values with their definitions
- Fetch https://saltmarshgames.com/news/project-larkspur: the September 2026 Project Larkspur announcement

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and bank B: three values by name, with definitions from the official page |
| 2. `Saltmarsh Games interview process` | yes | Established the loop: one 60-minute session with the hiring manager, a tabletop then a values conversation. Set persona weights, bank A, and the values-round detection |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur: fit row F9, questions A5, C1 and R3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, R1, R2, and the Prober's checklist focus |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Anything the recruiter told you about the Outage Hour** → if they named the outage scenario, the titles involved or the scoring focus, bank A gets rebuilt around that scenario
- **Your answers to the answer slots in F1, F2, F3, F5 and F7** → those rows upgrade, and C2, C3, C4, D1 and D2 become story-mapped instead of scaffolded
- **The release checklist itself, or a sanitised copy** → the one artifact in your field that can be inspected, which raises F4 and F8 from `medium` to `high` and sharpens D3
- **Your CV text** → more of your own sentences to map stories from, especially for B1, B2 and B4
- **How much prep time you have before Friday** → a prioritised prep schedule sized to it
- **A `tuesday-dossier.md`** → would carry checked evidence and pre-set limits on what to claim into this pack, instead of the pack building them locally
