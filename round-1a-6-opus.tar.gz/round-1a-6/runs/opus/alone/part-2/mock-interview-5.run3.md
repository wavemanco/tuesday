Web search was refused for all six lookups (permissions), so I'm building the pack from your message and the recruiter's brief alone. Writing it now.
Using Edit instead.
I've built your prep pack and saved it as `kelverton-rail_senior-partnerships-manager_interview_pack.md` in the working folder. The web searches were all refused by permissions, so everything rests on your message and the recruiter's email. Anything about Kelverton beyond that is marked generic, and nothing claims to know what the market report says.

Most of your four hours should go on three things:

- **The 15-minute POV (90 minutes):** open by saying how you're reading "operator partnerships". It could mean partnering *with* operators, or partners who help Kelverton *serve* them.
  - Pick two of the three themes in the pack: an integration ecosystem, operators as design partners, or what you'd deliberately not pursue.
  - Take one point from the report, credited to the report. Push back on one other point and give your reason.
  - Close with one benefit to operators for each move, as the recruiter asked. Give each move a line on money as well, because Ross will be listening for it.
- **The quota objection (B1, 40 minutes):** this is the most valuable thing to rehearse. Say it before Ross can: "I haven't carried a direct quota. My number was influenced revenue: roughly £4M, and I took the channel from 6 partners to 40." Then hold that line through two follow-ups without making it sound bigger.
- **Ross's commercial cases (30 minutes):** C3 asks how you'd structure a partner deal (referral, resell or revenue share). C4 asks what a partner costs and when it pays back. B3 asks what the plan returns in year one.

Two things to be honest with yourself about:

- **"Influenced" and "roughly" stay attached to the £4M.** You'll be asked how it was counted and how much was yours. The pack leaves those for you to answer, and "I don't know exactly" is an acceptable answer.
- **"From the other side" stays your phrase.** Bus and light rail planning is close to rail, not the same thing. Don't name a side your background doesn't say.

I can play Ross on B1, the quota objection, with real follow-ups that react to your answers.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, for later sessions.
If you want the pack as a Word document, I'll convert it.

Can you paste the job description, and your CV if it's handy? The four requirements I had to guess would become ones quoted from the posting, and it might show terms like location or travel. I'll keep going without them if not.

Would you like to allow web search? A standard pass would add Kelverton's published values, the panellists' public profiles and current operator-market context. A deeper pass would add up to 6 more searches and 2 page fetches, and take several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, Tuesday. 60-minute panel: **Deepa** (VP Partnerships, your future manager) and **Ross** (Commercial Director).
**Format, in the recruiter's words:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."

---

## 1. How to use this pack

- **Personas** describe *how* a question gets asked: who asks, and in what style. **Types** describe *what* it scores.
- Type key:
  - **CASE**: a live problem from the role. Scores structure and reasoning.
  - **JD**: a requirement of the role. Scores whether you can do the listed job, gaps included.
  - **EXP**: a deep-dive on your experience. Scores what was actually yours.
  - **CO**: company and strategy knowledge. Scores homework and altitude.
  - **VAL**: values and behaviour. Scores what you did, not generic virtue.
- Provenance labels: `[grounded]` means traceable to your message or the recruiter's email. `[inferred]` means derived from those, with the derivation named. `[generic]` means a role-family pattern that claims nothing about Kelverton.
- **The guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted. Where the pack needs a detail it doesn't have, it leaves an **answer slot**: an instruction for the interview with two honest branches. Fill it from memory, or take the "say so plainly" branch.
- No JD was supplied and web research was blocked. Every requirement here is either the recruiter's own words or a role-family pattern, labelled as such.

## 2. Prep triage: four hours

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV. Rehearse it **aloud twice**, timed to 13 minutes so you leave room for interruption | Section 3 |
| 2 | 40 min | The quota objection, rehearsed until it's boring: B1, then B2 and C1 | Section 6, highest-ROI |
| 3 | 30 min | Ross's commercial cases: C3, C4, B3 | Section 6 |
| 4 | 30 min | Re-read the market report with one job: pick the **one** finding you'll build on and the **one** you'll respectfully push against | Section 3, A5 |
| 5 | 20 min | Skeptic bank D1 to D4, out loud, 90 seconds each | Section 6 |
| 6 | 10 min | Choose three reverse questions, one for each panellist and one spare | Section 7 |

**Everything else in this pack is insurance.** If time runs short, cut from the bottom of this table, never from the top two rows.

---

## 3. Graded deliverable: the 15-minute POV

### What you're building on

| Fact | Source | Provenance |
|---|---|---|
| The brief: "where you'd take our operator partnerships over the next 18 months" | Recruiter's email | [grounded] |
| The close they asked for: "land on what it means for the operators themselves" | Recruiter's email | [grounded] |
| The format: "no slides needed, just talk us through it" | Recruiter's email | [grounded] |
| Your channel work, F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Your message | [grounded] |
| Your operator-side years, F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your message | [grounded] |
| The market report. You've read it and I haven't, so nothing in this pack rests on its content | Recruiter's attachment | [grounded] |
| The panel wrote or circulated that report internally, so its conclusions are the consensus answer in the room. Reciting it scores as homework. Building on one point and departing from another, with reasons, scores as judgment | Reasoning over the recruiter's email | [inferred] |
| Who the operator's buyer is, and whether that changes in the next 18 months, decides most partnership plans in a regulated, contract-driven sector. Check what the report says about the operator landscape and its contracting outlook before Tuesday. I couldn't research the current state | Role-family pattern | [generic] |

### Opening move: define the term

"Operator partnerships" could mean partnering **with** operators (joint roadmaps, co-development, design partners). It could also mean partners who help Kelverton **serve** operators (integration, consulting and implementation partners). Spend one sentence saying which reading you're presenting, using the report's own usage if it has one: "I'm reading operator partnerships as X, and here's why." If the panel meant the other reading, that costs you ten seconds. Guessing silently costs you the whole talk.

### Shape for 13 spoken minutes

| Minutes | Beat |
|---|---|
| 0 to 1 | Framing: your reading of the brief, and the one-line answer up front |
| 1 to 3 | Where things stand: **one** point from the report, named as the report's ("your strategy team's report makes the point that…"), never presented as your own research |
| 3 to 9 | Three moves across 18 months: 0 to 6, 6 to 12, 12 to 18. Each move gets what you'd do, what it costs, and how you'd know it's working |
| 9 to 12 | **What it means for the operators themselves**: the requested close, one operator outcome per move |
| 12 to 13 | Risks, and what you'd need from Deepa and Ross |

### Thesis options: choose two, and keep the third as an answer to "what else did you consider?"

| Thesis | The case | Mandatory concession | Provenance |
|---|---|---|---|
| T1. From products to an ecosystem: partners who connect Kelverton's scheduling to the operator's other systems, so a plan made once flows to where it is used | Builds on the channel pattern in F1: "took it from 6 partners to 40". Name that number once as your experience. Don't claim it maps one-to-one onto rail | An ecosystem takes longer than 18 months to mature. Say what month 18 realistically looks like: a first wave, not a finished network | [generic] |
| T2. Operators as design partners: a small number of operators with a structured partnership (shared roadmap input, agreed success measures), not only a supplier contract | Answers the brief's close directly: the operator's benefit is the headline, not a by-product | Operators' contracting and procurement may limit how far a partnership can go. Ross will also ask what Kelverton gives away. Name both before he does | [generic] |
| T3. Depth over breadth, the anti-pick: name what you would **not** pursue in 18 months, and why | Saying no is part of a senior partnerships job, and a candidate who says no with reasons stands out from one who lists everything | Focus concentrates risk: if the chosen few stall, the plan stalls. Say what would make you widen the net | [generic] |

### Differentiation

Most prepared candidates will summarise the report. Do three things instead:
1. **Ground** yourself: one point from the report, attributed to it.
2. **Diverge** once: one thing you'd weight differently, with your reason.
3. **Anti-pick**: one thing you'd deliberately not do yet (T3).

If you can't find a genuine divergence, don't invent one. Say what you'd want to test first instead.

### The close: what it means for operators

- Give each move one operator outcome, stated in operator terms (their planning effort, their day-of-operation disruption, their contract obligations) rather than in Kelverton's terms (partners signed, ARR). Which outcomes the report highlights for operators is yours to pick from your reading.
- Your bridge line is F2's own words, kept at their scope: "I spent five years in transport consulting, on bus and light rail network planning." The phrase "from the other side" is yours. Leave it unspecified rather than naming a side your material doesn't state.
- Answer slot: if those consulting years put you close to an operator decision you can describe briefly, one example lands the close well. Say it in your own words. If none comes to mind, or the work didn't put you close to operators' decisions, say so plainly and close instead on what you'd go and ask operators in your first 90 days.

### The commercial thread, because Ross is listening

Every move in the POV needs one sentence on how it makes or protects money, and what you'd measure. Don't save commercials for the Q&A. Ross is told to push, so give him something to push on. Never present a revenue figure for Kelverton that you can't source.

---

## 4. Fit snapshot

Requirements come from the recruiter's words where they exist (`[grounded]`). The rest are role-family patterns (`[generic]`), because no JD was supplied and the representative-JD search was refused.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material describes a partner channel at a payments company, not partnerships with or for rail operators, and the words stay at that scope: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: an 18-month brief invites "what did your first 18 months there look like". If you can say what you changed early on, say it in your own words. If the early period wasn't yours to shape, or the growth came later, say so plainly and stay with the 6 to 40 |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Bus and light rail network planning is adjacent to train operation, not the same thing. Words: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: expect "what did you see operators care about". If the work put you close to operators, say what you saw them weigh, in your own words. If it didn't, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Keep both qualifiers, "roughly" and "influenced": "Roughly £4M of influenced revenue." Defend-the-number slots, each in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. "I don't know exactly how it was counted" is an honest branch |
| F4 | Senior partnerships roles in B2B software commonly carry a direct or partner-sourced revenue target | "never carried a direct quota, only influenced revenue" — your message | none | [generic] | capability | You stated this, so the words are yours: "I haven't carried a direct quota. My number was influenced revenue." Then say how you'd take one on, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F5 | Selling into, or partnering with, rail operators | "Never sold into rail specifically" — your message | none | [generic] | capability | Your words: "I haven't sold into rail." The adjacent evidence is F2's, at F2's scope. Then a ramp plan, said as a plan |
| F6 | Building and scaling a partner programme | "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap, but a figure you stated with nothing inspected behind it, so expect a probe. Lead with the number in the quote's own terms. Defend-the-number slots: how the 40 were counted, which part of the growth was yours, and the assumption you'd defend least |
| F7 | Senior stakeholder management across partners, customers and internal commercial teams | none given | none | [generic] | discovery | Strong evidence here is a named, senior counterpart, a point where your interests and theirs diverged, and an outcome you can describe. Selection scaffold: pick a time from the ISV channel or your consulting years that has all three. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| F1 18-month POV on operator partnerships | Section 3, A1, A2, A4, A5 |
| F2 What it means for operators | Section 3 close, A3, D2 |
| F3 Commercials | B2, B3, C1, C3, C4 |
| F4 Revenue accountability | B1, D3, P2 |
| F5 Rail market | D1, D3, A3 |
| F6 Scaling a partner programme | C2, E1 |
| F7 Senior stakeholder management | B4, P1, G1 |

## 5. Persona table

Weights come from the recruiter's description of the panel, not from public profiles, because the interviewer searches were refused.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa interrogating your POV: sequencing, choices, the first 90 days | Highest. She's your future manager, and the round opens with a strategy presentation, so the Q&A will start from it | Clarify, then objective, then structure, then metrics, then risks. Think aloud, and challenge one premise respectfully |
| Pressure | Ross, "push on commercials": interruptions, devil's advocate on cost and your quota gap | High. The recruiter named it in advance | Pause, restate the question, concede the stated gap in your first sentence, then hold on what your quotes carry through two follow-ups |
| Data-Driven Prober | Ross on your numbers: the £4M and the 6 to 40 | High. Commercial directors test figures, and you have two | Know what you can and can't say about how each figure was counted. Name your weakest assumption first |
| Skeptic | Deepa on fit: no rail, no quota, why switch | High. These are the visible gaps in F4 and F5, and a hiring manager de-risks gaps | The concession is already in your own words, so say it calmly, then bridge only to adjacent evidence you stated |
| Conversational | Opening small talk and "walk us through your background" | Medium. It's likely in the first minutes, before the POV | A 90-second arc built from your three quoted sentences |
| Peer Evaluator | Seams with direct sales and product | Lower. No peer is on the panel, but Deepa will ask how you'd work with her other teams | Propose seam principles. Don't pretend to know Kelverton's seams |
| Values / Behavioral | One or two "tell me about a time" questions | Lower. The recruiter named no values round, and Kelverton's published values weren't retrievable | Selection scaffolds with an honest branch |

---

## 6. Question banks

### A. Case / Strategist, mostly Deepa

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've given us 18 months. What happens in the first 90 days?" | CASE | [generic] | Structure: listen (which operators and partners you'd meet, and what you'd ask), audit (which current partnerships produce value and which don't), decide (the two or three bets you'd commit to by day 90), and report back (what you'd show Deepa and Ross). Make it the first phase of your POV, so the talk and the answer agree. No claim about your past is needed | The most natural follow-up to any 18-month plan. CASE because it tests sequencing, not history |
| A2 | "Which operator partnerships would you deliberately not pursue?" | CASE | [generic] | Your T3 anti-pick. Name a category, not a company, and give the reason: cost to serve, time to value, or a weak operator outcome. Then say what would change your mind | Tests whether you can say no, which is half of a senior partnerships job. CASE because it's a live choice |
| A3 | "How does the way operators buy change your plan?" | CASE | [generic] | Clarify first: ask what Deepa sees as the binding constraint, contract cycles or procurement rules. Then say how your sequencing bends to it: which moves wait for a contract window and which don't. Your F2 words, at scope, can frame it: "I spent five years in transport consulting on bus and light rail network planning." Don't describe rail procurement as fact. Ask instead | Rail buying constraints are the classic hole in an outsider's plan, and F5 makes you an outsider to rail. CASE because it's reasoning, not recall |
| A4 | "At month 18, how do we know this worked?" | CASE | [generic] | Three measures: one operator outcome (from your close), one commercial (revenue sourced or influenced through partners, which leads Ross straight to B1, so be ready), and one partner-health measure (active versus signed). Say which you'd weight most and why | Ties the POV to measurement. CASE because the panel scores the metric design |
| A5 | "What in our market report would you push back on?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | One point you'd build on, named as the report's. Then one you'd weight differently, with your reason, framed as a question you'd want to test, not a correction of their team. Answer slot: if your reading surfaced a genuine divergence, give it in your own words. If it didn't, say so plainly and name what you'd test first instead | The report came from inside their company, so engaging with it is the clearest homework signal available. CO because it scores strategic altitude |

### B. Pressure, Ross

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota. Sixty seconds: why should I trust you with a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue"; "took it from 6 partners to 40" | **The highest-ROI rehearsal in this pack.** Name the limit before he finishes: "I haven't carried a direct quota. My number was influenced revenue: roughly £4M, and I took the channel from 6 partners to 40." Then stop and let him come back. Follow-up 1, "influenced is soft": use the defend-the-number slots from C1 (how it was counted, which part was yours), in your own words. "I don't know exactly how it was counted" is an honest branch. Follow-up 2, "so what number would you take here?": answer as a plan. Say what you'd propose to be measured on in year one, and that you'd want to agree how partner-sourced and influenced revenue get counted. Hold through both follow-ups by returning to the quote, never by enlarging it. Never "effectively a quota" or "I was basically accountable for". The concession is the strength | F4 is the gap Ross is best placed to press, and the recruiter said he will. JD because it scores a commercial requirement, with Pressure delivery |
| B2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: which part was yours. If you can say what you did that moved deals (partners recruited, deals supported, programmes run), say it in your own words. If the attribution was shared or you can't separate your part, say so plainly and return to "roughly £4M of influenced revenue." Keep "roughly" and "influenced" | The standard attribution probe on any headline figure. EXP because it tests what was yours |
| B3 | "Your plan costs money before it earns any. What do I get in year one?" | CASE | [generic] | Treat it as an investment case: what you'd spend (people, partner incentives, integration effort), what comes back early (one or two proof points), and the decision point where you'd stop or double down. Offer him the kill criteria before he asks | Commercial directors test whether a partnerships plan has a P&L. CASE because it's live reasoning |
| B4 | "A partner's product fails at an operator, the partner blames us, and the operator's on the phone in ten minutes. Go." | CASE | [generic] | Operator first: acknowledge, contain, give a time for the next update. Then establish facts with the partner privately, agree who owns the fix, and review terms afterwards. Keep blame out of the operator call | A partnerships role sits between partner and customer when things break. CASE with Pressure delivery |

### C. Data-Driven Prober, Ross

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Four defend-the-number slots, each in your own words: how it was counted, what it's sensitive to, the assumption behind it you'd defend least (name it before he does), and which part was yours. If you don't know how it was counted, say so plainly. That's better than a method you can't repeat under a second question | F3's figure is the most probe-able number you have. EXP because it scores attribution precision |
| C2 | "Six to forty partners. How many of the forty actually produced revenue?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you know how revenue was spread across the 40, say it in your own words. If you don't, or it wasn't tracked that way, say so plainly and stay with "from 6 partners to 40". Don't estimate on the spot | Partner counts invite the active-versus-signed question. EXP because it tests the figure behind the headline |
| C3 | "How would you structure commercials with a partner here: referral, resell, revenue share?" | CASE | [generic] | Lay out the trade-off: who owns the operator relationship, who carries delivery risk, margin against control, and how each choice fits a buyer like an operator. Then pick one for your T1 or T2 and say why. Answer slot: if the ISV channel used one of these models and you can say why, say it in your own words. If you don't know, or it wasn't your call, say so plainly and stay with the trade-off | Ross's home ground. CASE because it's a live design choice |
| C4 | "What does a partner cost us to sign and support, and when does it pay back?" | CASE | [generic] | Structure it: acquisition cost, enablement and integration cost, ongoing support, then the revenue or retention it drives and the payback period. Say which inputs you'd need from Kelverton's own data. Don't invent figures | Unit economics is the Prober's test of commercial thinking. CASE because it scores structure |

### D. Skeptic, Deepa

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't sold into rail. Why would payments partnerships translate?" | JD | [grounded] "Never sold into rail specifically"; "running the ISV channel — took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning" | Concede plainly: "I haven't sold into rail." Then describe both stretches of work at their own scope (the channel, 6 to 40, and the network-planning years) and let her draw the inference. Don't call either one proof that you can do this. Close with a ramp plan: who you'd learn from and what you'd read | F5 is the most visible gap to a VP who knows rail. JD because it scores market fit |
| D2 | "Bus and light rail aren't heavy rail. What from your consulting years actually carries over?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: if you can name what from network planning you'd use here, say it in your own words. If you're not sure it carries over, say so plainly and say what you'd need to learn. Keep "the other side" as your own phrase. Don't name a side your material doesn't state | Tests whether F2 is a real bridge or a talking point. EXP because it scores what you actually did |
| D3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "Never sold into rail specifically" | Pick one, honestly: F4 or F5. Say it in your own words, then give the plan. Don't pick a fake weakness. Deepa will already have spotted both | The Skeptic's classic stem. Answering it with a gap she has already seen builds credibility |
| D4 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Selection scaffold: give your actual reason, in your own words, with one pull towards Kelverton and nothing negative about your current employer. If the honest answer is mixed, say the part that's about this role | Motivation consistency is a Skeptic staple. EXP because it scores your own story. Nothing in your message states a reason, so the pack supplies none |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your background." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"; "Before that, 5 years in transport consulting (bus and light rail network planning" | A 90-second arc in time order: consulting (bus and light rail network planning), then the ISV channel (6 to 40, roughly £4M influenced), then why this role, in your own words. End on the role, not the past | Almost certain to open the hour. Scored even though it's casual |
| E2 | "What drew you to Kelverton specifically?" | CO | [generic] | Selection scaffold: one specific thing from the report or the recruiter's brief, and why it matters to you. If you can't name one beyond the role itself, say what drew you to the role. Don't invent company facts | A homework check disguised as small talk |

### P. Peer Evaluator, Deepa on working across teams

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "A partner and one of our account execs both want to lead with the same operator. What do you do?" | CASE | [generic] | Propose principles, not answers: whoever is closest to the operator's outcome leads, credit rules are agreed before the deal and not after, and conflicts go to a named tie-breaker. Ask how Kelverton handles it today | Channel conflict is the most common seam in partnerships. CASE because it's a live judgment |
| P2 | "How do you handle credit when partners and sales both touched the revenue?" | EXP | [grounded] "only influenced revenue" | Answer slot: if you had to settle credit for influenced revenue in the ISV channel, say how it worked, in your own words. If you didn't, or it wasn't yours to settle, say so plainly and give the principle you'd propose here | Your number is influenced revenue, so credit attribution is a natural probe. EXP because it scores what you did |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you told a partner or leadership something they didn't want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you said it, and what happened to the relationship afterwards. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A partnerships role means delivering hard news to both sides. VAL themed by the persona stem, because Kelverton's values weren't retrievable |
| G2 | "When did you put a customer's interest ahead of a short-term number?" | VAL | [generic] | Selection scaffold: the number at stake, the customer's interest, your choice and its cost. If none comes to mind, say so plainly and say how you'd handle it | Echoes the brief's operator-first close. VAL from the persona stem |

---

## 7. Reverse questions

| For | Question | Why it lands |
|---|---|---|
| Deepa | "If this role works, what's different for the operators at month 18?" | It mirrors her own brief and shows you heard "what it means for the operators themselves" |
| Ross | "How do you want partnership value counted here (sourced, influenced, something else), and what would you hold this role to in year one?" | It meets the quota question head-on and shows you'd rather agree the measure than avoid it |
| Either | "What did the strategy team's report get most right, and where do you think it's still open?" | It invites their view rather than testing yours, and you'll learn which way they lean |
| Deepa | "Where do partnerships and direct sales collide today?" | It tells you where the real seam is, and shows you're thinking about F1 before you need to |
| Ross | "What's the commercial decision about partnerships you'd most like to have made already?" | It tells you his priority, in his terms |
| Either | "What's been hardest about operator partnerships so far?" | An honest answer tells you what the job really is |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried or hit a revenue quota | A negative you stated (F4) | "I haven't carried a direct quota. My number was influenced revenue." |
| Generated, sourced or closed £4M | Inflated form of F3 | "Roughly £4M of influenced revenue", with both qualifiers kept. The limit is the pack's observation: influenced is not sourced |
| Has sold into rail, or worked with train operating companies | A negative you stated (F5) | "I haven't sold into rail." |
| Knows rail operations or heavy rail | Inflated form of F2 | F2's quote at its scope: bus and light rail network planning. "From the other side" stays your phrase, unspecified |
| Built or founded the ISV channel | Inflated form of F1 | "Running the ISV channel", "from 6 partners to 40". The channel existed at 6 |

## 9. Sources

- Your message, including the recruiter's email as you quoted it.
- The internal market report: read by you, not shared in this session. Nothing in the pack rests on its content.
- Searches sent, all refused by the host's permissions: "Kelverton Rail values"; "Kelverton Rail interview process partnerships"; "Kelverton Rail scheduling software train operating companies news 2026"; "Deepa VP Partnerships Kelverton Rail"; "Ross Commercial Director Kelverton Rail"; "Senior Partnerships Manager rail software job description UK". No fetches.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused. It would have themed the VAL questions G1 and G2 with Kelverton's published values instead of persona stems |
| 2. Kelverton Rail interview process | unavailable | Refused. The loop is still established by the recruiter's words, so persona weights rest on them. Research could have added nothing beyond confirming them |
| 3. Kelverton Rail strategy and recent news | unavailable | Refused. It would have grounded A5, E2 and the POV's operator-landscape check with current facts. The report you read isn't in hand here, so it couldn't stand in |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Two searches, both refused. They would have added an interviewer read and reverse questions tied to each panellist's career path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Refused. It would have turned the `[generic]` requirements in F4 to F7 into quoted `[inferred]` ones, and might have surfaced gate terms such as location or travel |

## 10. Upgrade menu

- **The JD text** → F4 to F7 become quoted requirements, any gate terms (location, travel, office pattern) get their own rows, and the coverage table checks against the real list.
- **Your CV** → evidence beyond the three sentences in your message, so more answer slots become story-mapped answers, especially G1, G2 and F7.
- **The report's headline findings, in your own words** (only what you're comfortable sharing from an internal document) → POV theses built on its actual content, and a concrete divergence for A5.
- **Web search allowed** → Kelverton's values (G bank), current context on the operator market (A3 and the POV), the panellists' public profiles (persona weights and reverse questions), and a representative JD.
- **What you can say about how the £4M was counted and which part was yours** → B1, B2, C1 and P2 move from answer slots to rehearsed lines.
- **A `tuesday-dossier.md` from an earlier evaluation** → verified evidence and a prohibited-claims list carried in. The pack is complete without it.
