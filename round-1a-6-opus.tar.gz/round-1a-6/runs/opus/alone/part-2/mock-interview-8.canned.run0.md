I'm reading the prep-kit's rules, and then I'll build your pack for the three rounds on 5 December.
I've saved your prep pack for all three rounds on 5 December. It's built only from what you sent me (the job description, the values, the recruiter's email, the strategy brief and your background), with no web research, because that already covered everything.

**Rehearse C1 first.** It's the one objection you're most likely to face, probably in the Round 2 interview with the Head of Member Services: "You handled one branch's complaints log, haven't worked in a contact centre, and haven't presented above regional level. Why are you ready for a role that covers all three?"
- **Concede plainly:** "I haven't worked in a contact centre, and I haven't presented to anyone above regional level."
- **Hold:** stick to the three things you have done (the complaints log, training tellers on the escalation script, the monthly spreadsheet).
- **Plan:** give a first-weeks plan, said as a plan, not as experience.

What's in the pack:
- **Your background against the job description:** each requirement is matched to your own words, quoted exactly. Contact-centre work and presenting to senior leaders are gaps you've stated, so the pack doesn't try to bridge them. For whether your complaints were regulated and what your spreadsheet tracks, the pack gives you two honest answers to choose between when you're asked. It doesn't assume either.
- **The 20-minute escalation case:** a minute-by-minute shape, three positions to lead with (each with a concession you must say), and how to go beyond the standard apologise-and-escalate answer.
- **Strategy talking points** from the brief. One caution: closing branches into hubs sits awkwardly next to "Neighbours, Not Numbers", and two branch managers are on your panel. If it comes up, acknowledge it respectfully rather than treating it as a flaw you've spotted.
- **Each round's questions and the questions to ask back:**
  - Recruiter: 8 questions, including pay, notice and travel. The pack gives no figures; those answers have to be yours.
  - Head of Member Services: 11 questions.
  - Branch-manager panel: 10 questions, plus a one-page sheet matching a story to each of the four values. For "Members First, Always" and "Neighbours, Not Numbers", your background doesn't contain a story yet, so the pack tells you what kind of story to pick.
- **Claims not to make,** such as "coached supervisors" or "wrote the escalation script".

The pack ends with a list of what would make it stronger, such as the interviewers' names once they're assigned.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/alone/part-2/rooms/case-8-canned-552228f8:
- ashgrove-credit-union_member-experience-lead_interview_pack.md

Say the word and I'll play the sceptical interviewer on C1, the most valuable question to rehearse.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop (from the recruiter's email):** three rounds on 5 December 2026
- **Round 1:** recruiter, 30 minutes
- **Round 2:** Head of Member Services, who would be your manager, 45 minutes, "mostly behavioural"
- **Round 3:** panel of two branch managers, 60 minutes, including a 20-minute case on a complaint escalation. This is also the values round, scored against the four values.

**Interviewers:** names not yet assigned, so the pack has no interviewer read and the persona weights come from each round's role.
**Mode:** loop. One shared fit snapshot, one build section for the case and one grounding brief, then a mini-pack per round.

---

## How to use this pack

- **Personas** describe how a question is asked: the interviewer's style and register. **Types** describe what is being scored. Every question has both.
- **Type key**
  - **VAL**: whether your past behaviour shows Ashgrove's published values
  - **EXP**: deep-dive on your own experience, and what was actually you
  - **JD**: can you do the listed job, gaps included
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role, reasoned aloud
- **Provenance labels**
  - `[grounded]`: traceable to something you gave me
  - `[inferred]`: derived, with the derivation named
  - `[generic]`: a common pattern with no claim about Ashgrove or you
- **Answer slots** are marked "Answer slot:". They are places where only you know the answer. Each has two honest branches, and either one is a good answer.
- **The guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past in this pack comes from one of your four sentences, quoted exactly.

---

## Fit snapshot

Your four sentences (all from your message):
- "6 years in retail banking, the last 3 as a branch supervisor."
- "I handled the branch's formal complaints log and trained new tellers on our escalation script."
- "I built the monthly complaints spreadsheet our regional manager uses."
- "Never worked in a contact centre, and I've never presented to anyone above regional level."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's formal complaints log, not a process across branches, and nothing has been inspected behind it, so expect a probe. Words at the quote's own scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe on the stages of a complaint likely. If you did any part beyond the log (looking into a complaint, replying to the member, closing it), say which, in your own words. If the log was the record and others did the rest, say so plainly and stay with the log |
| F2 | "…and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you have stated, and wording can't close it. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make it feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | A monthly complaints spreadsheet sits close to this, but your material doesn't say what it counts. Answer slot: if it tracks volumes or resolution times, say how each is counted, in your own words. If it tracks other things, say what they are. If you don't know how a field is captured, say so |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the script. It does not say you coached supervisors. Words at the quote's own scope: "I trained new tellers on our escalation script." Answer slot: if your training went past the script into live cases, say how, in your own words. If the training was the script, say so plainly |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence would be a named journey (a form, an app flow, a member guide) and the part of it that was yours. Answer slot: if you have worked with a digital or online-banking team on anything like this, say what it was and what your part was. If you haven't, say so plainly and move to how you would use complaint data to pick the first journey to fix |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Say it in your own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer map it onto "customer operations" rather than relabelling your history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal complaints" touches this requirement, but your material doesn't say whether those complaints were regulated. Answer slot: if they fell under a regulator's complaint-handling rules, say which rules and what they meant for how you logged and closed complaints, in your own words. If they didn't, or you aren't sure, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you have stated. Words: "I haven't presented to anyone above regional level." Your sentence doesn't say whether you have presented at regional level, so the pack doesn't assume it. Answer slot: if you have presented to your regional manager or at a regional meeting, say what it was and how it went. If you haven't, say so plainly. Then give the preparation plan, said as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material doesn't name the tool. Answer slot: if the spreadsheet is in Excel, say so and name what you built in it (formulas, pivot tables, charts) only if you built them. If it's in another tool, name that tool |

**Requirement coverage**

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own complaints end to end across branches | F1 | C1, D1, I1, I2 |
| …and the contact centre | F2 | B2, C1, C4 |
| Monthly reporting on volumes and resolution times | F3 | G1, G2, J3 |
| Coach branch supervisors on escalations | F4 | D2, J1, J2, K1 |
| Digital teams and self-service journeys | F5 | E1 |
| 4+ years in financial-services customer operations | F6 | A1 |
| Regulated complaints | F7 | B1, I1 |
| Presenting to senior leaders | F8 | C1, C3, G2 |
| Excel reporting | F9 | G1 |

**Highest-ROI prep in this pack: C1**, the scope-jump objection. It combines F1, F2 and F8: one branch's log, no contact centre, no presenting above regional level, set against a role that spans all of those. Expect it in some form in Round 2, and possibly again in Round 3.

---

## Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced this, so treat it as graded. Nothing about the case itself is known yet. The material below is a way of working through it, not a predicted scenario.

**Grounded facts to build on**

| Fact | Source |
|---|---|
| The role owns "the member complaints process end to end across branches and the contact centre" and coaches "branch supervisors on escalations" | JD |
| The panel scores against Members First, Always; Plain Words; Neighbours, Not Numbers; and Own the Fix | Recruiter email; values page |
| Eight branches consolidate into five hubs over 2027, and 40% of member service moves to digital by 2028 | Strategy brief, as you summarised it |
| F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your message |

**A 20-minute shape** `[generic]`

1. **Clarify (2–3 min).** Ask:
   - What has the member been told or promised so far?
   - Which channel did the complaint come through?
   - How long has it been open?
   - Is there any sign the member is vulnerable?
   - Which complaint-handling rules and deadlines apply?

   Don't state a regulatory deadline from memory. Ask the panel, or say you would confirm it.
2. **The member first (4 min).** What you would do today for this member, who contacts them, and what you would say, in plain words.
3. **Contain and own (4 min).** Who keeps hold of the case. Under Own the Fix, that is whoever found the problem, with your support. Say when you would step in yourself.
4. **Root cause (4 min).** Is this a one-off or a pattern? How you would check it across branches and the contact centre.
5. **Record, report, close the loop (3 min).** What goes in the log, how it shows up in the monthly report, and what changes for the next member.
6. **Close (1 min).** Name which value each main decision served, in one line each, without reciting slogans.

**Theses (pick one to lead with). Each has a concession you must say.**

| Thesis | Concession you must say |
|---|---|
| T1: Fix the member's problem first, then fix the process | Speed for the member can't skip the record or the response the rules require. Both have to happen |
| T2: An escalation is data. Every one should feed the monthly report and a root-cause check | One complaint isn't a trend, so you wouldn't redesign a process from a single case |
| T3: Coach the supervisor; don't take the case off them (Own the Fix) | Some cases need the lead to step in: a vulnerable member, a possible rule breach, or a supervisor who is part of the problem |

**Beating the consensus answer.**
- *The consensus answer* `[generic]`: an apology-and-escalate script (listen, apologise, escalate, follow up). Any prepared candidate will give it.
- *How to go past it:* use that structure briefly to show you know it, then add one thing it misses. One option is the case's link to the 2027 consolidation, or the step where the supervisor keeps hold of the fix.
- *The anti-pick* (what you would refuse to do): promising the member an outcome or payment before the facts are established, and blaming branch staff in front of the member.

---

## Grounding brief

| Item | What it says | Where to use it | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | E1, Round 2 reverse questions | [grounded] strategy brief, as you summarised it |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | E2, I2, Round 3 reverse questions | [grounded] strategy brief, as you summarised it |
| New product | "launch a small-business lending product in Q1 2027" | Round 2 reverse questions | [grounded] strategy brief, as you summarised it |
| Competitive frame | "the main competitive pressure is app-only banks" | E1 | [grounded] strategy brief, as you summarised it |
| Size and model | "member-owned, about 900 staff" | A2, framing | [grounded] JD |
| Vocabulary | "member", not "customer"; "hubs"; "self-service journeys"; "the member's side of the counter" | Every round | [grounded] JD, values page, brief |
| A tension worth handling with care | Consolidating branches into hubs and "every branch is part of its town" can pull against each other, and two branch managers will be on your panel. Acknowledge the tension respectfully if it comes up. Don't present it as a flaw you've spotted | Round 3, I2 | [inferred] reading of the brief beside the values page |

The brief is from July 2026, about four months old, so nothing in it is flagged as out of date.

---

## Round 1: Recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | High: the standard shape of a recruiter screen, and the recruiter runs it | A 90-second biography arc built only from your four sentences. Treat casual questions as scored. Have logistics answers ready |
| Skeptic (light) | Knockout checks against the JD's requirements | Medium: recruiters screen on stated requirements, and F2 and F7 sit right on them | State the F2 gap plainly before it becomes a surprise. Keep F7 inside its answer slot |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, three beats from your own sentences: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. End with one line on why complaints work is the thread you want to follow, in your own words | F6 clears the years requirement, and F1, F3 and F4 are the relevant beats. EXP because the recruiter is checking the story against the JD |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Answer slot: give your own reason, in your own words. If it is mainly the step up to leading complaints work, say that plainly. You can accurately name: member-owned, about 900 staff, and the four values by name. Name one value that genuinely matters to you, not all four | Motivation is always asked in a screen. CO because naming published facts accurately shows homework |
| A3 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | A standard screen question. Nothing in your message covers it, so the only safe answer is your own |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | Standard screen logistics. JD because it concerns the job's terms |
| A5 | "The role spans branches and the contact centre. How do you feel about moving between sites?" | JD | [grounded] | Logistics slot: say what travel between sites you can do, in your own words | The JD's "across branches and the contact centre" and the brief's hub plan make site coverage a likely check |
| A6 | "Why are you looking to move on?" | EXP | [generic] | Logistics slot: give your own reason, in your own words, kept short and forward-looking | A reliable screen question. EXP because it is about your history |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for regulated complaints experience. Tell me about the complaints you've handled." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the quote's own terms: you handled the branch's formal complaints log. Answer slot: if those complaints fell under a regulator's complaint-handling rules, say which rules and what they meant for how you logged them. If they didn't, or you aren't sure, say so plainly and stay with the log | F7 is a stated requirement your material only touches. `[inferred]` because whether "formal" means "regulated" is exactly what is unknown |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain and early: "I haven't worked in a contact centre." Then one sentence of plan, for example spending your first weeks alongside the contact-centre team handling complaints. Don't apologise twice | F2 is a knockout-style check that a recruiter can ask directly. A calm answer here makes C1 easier later |

### Reverse questions (Round 1)

| Question | Why it lands |
|---|---|
| "What would make someone stand out in the Head of Member Services round?" | Gets prep information directly and shows you take that round seriously |
| "For the 20-minute case, will I get the scenario on the day, and is there reading time?" | It is a graded deliverable, and the format changes how you prepare |
| "How does the panel score against the four values? Is it one score per value?" | The recruiter said the panel scores against the values, so knowing the shape helps you aim each story |
| "Is this a new role, or am I replacing someone?" | Tells you whether you'd inherit a process or build one, which reshapes C1 |
| "What's the timeline for a decision after 5 December?" | Practical, and you need it |

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F1, F2 and F8 | High: a manager buying capability tests the gaps. F2 and F8 are stated gaps, and F1 is a scope stretch | Rehearse C1 until it's boring. Concede first, then hold only on your quotes, then give a ramp plan |
| Values / Behavioral | "Tell me about a time…" stories | High: the recruiter said this round is "mostly behavioural" | Use your quoted material where it carries a story. Where it doesn't, use the selection scaffolds with their honest branch. "We" for context, "I" for your part |
| Case / Strategist | Live problems from the strategy | Medium: a manager often tests whether you can think at the role's level, and the brief gives obvious material | Clarify, then structure, then answer. Use Ashgrove's own vocabulary |
| Data-Driven Prober | The spreadsheet and the monthly report | Medium: monthly reporting is a core duty, and F3 and F9 are thin | Know exactly what your spreadsheet does and doesn't do, and say plainly what you don't know |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You handled your branch's complaints log, and you've told us you've never worked in a contact centre or presented above regional level. This role owns complaints across every branch and the contact centre and reports to senior leaders. Why are you ready for that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in the pack.** 1. **Concede first, exactly:** "That's fair. I haven't worked in a contact centre, and I haven't presented to anyone above regional level." 2. **Hold only on what you said:** "What I have done is handle the branch's formal complaints log, train new tellers on our escalation script, and build the monthly complaints spreadsheet our regional manager uses." 3. **Ramp plan, said as a plan:** in the first weeks, sit with the contact-centre team on complaints; read recent complaint data from every branch and the contact centre; ask your manager what senior leaders need from the monthly report and get feedback on a first draft before it goes up. **Follow-up 1** ("Presenting to executives is a different game"): agree, and don't stretch. Say how you'd prepare: a dry run with your manager, short slides, numbers you can explain. **Follow-up 2** ("So we'd be training you on the job?"): hold, without adding to your past. Repeat the three things you have done and the plan. Don't claim the log covered more than one branch | F1, F2 and F8 together are the most predictable objection to this candidacy, and the negatives in the question are ones you stated. JD because it tests the role's three biggest requirements at once |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of your stated gaps. Don't pick a fake weakness. "I haven't worked in a contact centre" pairs well with the C4 plan. Name the gap, then the plan, in under a minute | Skeptic's standard stem. Answering it with F2 or F8 shows candour, because you name the gap yourself |
| C3 | "What's the most senior audience you've presented to?" | EXP | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you have presented to your regional manager or at a regional meeting, say what it was and how it went, in your own words. If you haven't, say so plainly. Then the preparation plan from C1 | F8 is a stated requirement and a stated gap. EXP because it asks about your actual history |
| C4 | "How would you get to grips with complaints in the contact centre in your first 90 days?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | You may open with "I haven't worked in a contact centre, so I'd start by learning it." Structure: sit with agents taking complaints; map how a complaint is logged there compared with in branches; find where cases get handed between branch and contact centre; compare the two sets of figures; agree one early fix with the contact-centre lead. Make no claim about contact-centre practice | F2 turned into a plan. CASE because it is a live problem in the role |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you handled a complaint that needed escalating." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick a complaint from your work with the branch's formal complaints log that went beyond the branch. It needs: what the member raised, what you did, who it went to and why, how it closed, and what changed afterwards. "I" for your part. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 and F7 are probed through stories. EXP because the story's detail is what gets tested |
| D2 | "Tell me how you trained new tellers on escalations." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4. The beats your sentence states: new tellers, our escalation script, you trained them. Tell those in your own words. Answer slot: the JD's "coach branch supervisors on escalations" line makes a probe on what came after training likely. If you checked how tellers used the script on live cases, or helped them with one, say how. If the training was the script itself, say so plainly and stay with the training | F4 is the evidence for the coaching requirement. EXP because it tests what was actually yours |
| D3 | "Tell me about a time you had to tell a manager something they didn't want to hear." | VAL | [generic] | Selection scaffold. It needs a named stake, what you said and how, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Monthly reports to senior leaders sometimes carry bad news, so this is a likely theme. A persona stem, not an Ashgrove fact |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and where would you work with the digital teams?" | CO | [grounded] | Clarify: which services move first? Structure: (1) complaints that move channel, and (2) new complaints about the digital journeys themselves. Measure complaints per journey and repeat contacts. Pick the first self-service journey to fix from the top complaint drivers. Keep a human route for members who need one. Write member-facing text that passes "Plain Words". Mention app-only banks once, as the competitive frame | The brief's headline goal plus F5. CO content, CASE delivery |
| E2 | "We're consolidating eight branches into five hubs over 2027. How would you keep the complaints process steady through that?" | CASE | [grounded] | Clarify the timeline and which branches go first. Expect more complaints and new types (access, distance, change of contact). Brief branch staff with plain wording before each change. Track complaints by branch and hub through the transition. Feed patterns back to the consolidation project quickly | The brief's 2027 consolidation is the role's most predictable live problem. CASE because it is asked as a plan |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | What your sentence carries: you built it, it's monthly, it's about complaints, and your regional manager uses it. Answer slot: if it tracks volumes or resolution times, say how each is counted, in your own words. If it tracks other things, say what. Name the tool. Say what the regional manager uses it for only if you know. **Weakest-assumption move:** name the field you'd defend least, or say plainly you don't know how one is captured | F3 and F9 both rest on this sentence. `[inferred]` because what it contains is not in your material |
| G2 | "What would your monthly report to senior leaders show, and how would you know the numbers are right?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Contents: volumes by channel and by branch or hub; resolution times (the typical time and the slowest cases); top root causes; repeat complainants; actions taken and whether they worked. Checks: reconcile against the logs, define "resolved" once, spot-check cases. You may mention the spreadsheet in your sentence's words, without describing what it contains unless G1's slot settled that | F3 and F8 meet here: the report goes to senior leaders. JD because it is a listed duty |

### Reverse questions (Round 2)

| Question | Why it lands |
|---|---|
| "What would the first monthly report you'd want from me look like, and who reads it?" | Shows you're already thinking about the F8 duty, and the answer feeds your ramp plan |
| "How do complaints move between branches and the contact centre today, and where do they get stuck?" | Lets you learn the contact-centre side (F2) from the person who owns it |
| "How will the small-business lending launch in Q1 2027 change complaint handling?" | Grounded in the brief, and a new product means new complaint types |
| "What does success look like for this role by the end of 2027, given the hub consolidation?" | Ties the role to the strategy timeline and shows how you'll be judged |
| "How do you like to be told about bad news: early and rough, or later and polished?" | A manager-relationship question that also supports D3 |

---

## Round 3: Panel of two branch managers, values round plus 20-minute case (60 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One or more questions per value | High: the recruiter said the panel scores against the four values | One story per value, from the cheat sheet below. Use the honest branch where your material has no story |
| Case / Strategist | The 20-minute escalation case | High: announced by the recruiter | Use the graded-deliverable section. Clarify before structuring |
| Peer Evaluator | "What would you need from us?" "What if we disagree?" | Medium: you would coach their supervisors (JD), so they are pricing what you add to their branches | Frame it as reciprocity. Propose principles for disagreements rather than claiming you already know how the branches work together |
| Pressure | "Why would my supervisors listen to you?" | Low to medium: a likely test of the F4 stretch from people whose staff you'd coach | Hold, then concede. Hold only on F6 and F4's quotes |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's point of view | Selection scaffold: a time a member's interest pulled against the branch's convenience or a rule. It needs the member's situation, your choice, and what it cost or changed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | H1 |
| Plain Words | If it needs explaining twice, the wording was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you changed how you explained the script after someone didn't follow it the first time, say what you changed. If not, use the scaffold in H2 | H2 |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold: a time you treated a member as part of the local community rather than a case. It needs the person, the local context and what you did. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | H3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it because you spotted a gap, say what the gap was and how you saw it through. If it was asked of you, say so plainly and tell it as work you delivered, or choose another story | H4 |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold, as in the cheat sheet. Make it a decision, not a general attitude. "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes straight from the value's own wording, which panels often use. VAL because it is scored against Members First |
| H2 | "Tell me about a time you explained something so it didn't need explaining twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Option: the teller training, in your sentence's terms. Answer slot: if you changed how you explained it after it didn't land, say what you changed and why. If not, pick another time when your explanation landed the first time, with what you said and who it was for. If none comes to mind, say so plainly | Plain Words, mapped to F4. VAL |
| H3 | "Tell me about a time you treated a member as a neighbour, not a number." | VAL | [grounded] | Selection scaffold, as in the cheat sheet. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers. Branch managers on the panel will weigh this one heavily, especially with consolidation coming |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Option: the spreadsheet, kept in your sentence's terms, using the cheat sheet's answer slot. Or pick another problem you found and saw through: the problem, how you noticed it, what you did, and when it was solved. If none comes to mind, say so plainly | Own the Fix, mapped to F3. VAL |

### Bank I: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Here's an escalated complaint. Take us through how you'd handle it." (the 20-minute case) | CASE | [grounded] | Use the graded-deliverable section: clarify, the member first, contain and own, root cause, record and report, then close on the values. Lead with one thesis and say its concession | Announced by the recruiter. It tests F1, F7 and the values at once |
| I2 | "A long-standing member writes in angry that the branch near them is closing into a hub, and says nobody explained it. What do you do?" | CASE | [grounded] | Contact them personally and in plain words; listen first. Check what they were actually told. Give real options (the nearest hub, digital help, a named contact). Log it and look for a pattern across that town. Feed it back to the consolidation team. Acknowledge that the change is hard for members without criticising the decision | The brief's consolidation and Neighbours, Not Numbers meet here. Asked as a live problem, so it presupposes nothing about your past |

### Bank J: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd be coaching our supervisors on escalations. What would you need from us, and what would you bring?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Bring: three years in the supervisor's seat, and the experience of training new tellers on an escalation script, both in your sentences' terms. Need: their supervisors' time, real recent cases, and their view of what gets in the way. Offer something back, for example monthly figures that are useful to each branch | F4 and F6 framed as reciprocity. JD because it is the coaching duty |
| J2 | "If one of my supervisors handled an escalation in a way you'd have done differently, what happens next?" | CASE | [generic] | Talk to the supervisor first, in private. Leave the fix with them (Own the Fix). Keep their branch manager informed rather than going around them. Say when you would step in directly: harm to a member or a possible rule breach | Turf and disagreement style, which is the peer's real question. CASE because it is hypothetical |
| J3 | "How would you make the monthly complaints numbers useful to a branch manager like me, not just to senior leaders?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Per-branch view; top three causes for that branch; how fast its cases close compared with the network; one suggested action. You may mention the spreadsheet in your sentence's terms. Say what your regional manager uses it for only if you know | F3 from the branch side. `[inferred]` because the spreadsheet's contents aren't in your material |

### Bank K: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You've been a supervisor for three years. Why would my supervisors take coaching from someone who's been at their level?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, then hold on what you said: three years as a branch supervisor, so you know the job from the inside, and you trained new tellers on the escalation script. Hold through two follow-ups by returning to those two facts, never by adding to them. Then concede about the role rather than your past: "This would be a new relationship, and I'd expect to earn it by being useful on their real cases." | The F4 stretch, put by the people whose staff you'd coach. JD because it tests the coaching requirement under pressure |

### Reverse questions (Round 3)

| Question | Why it lands |
|---|---|
| "What would a new complaints lead do in the first month that would genuinely help your branch?" | A reciprocity question for the people whose supervisors you'd coach |
| "How are members in your towns reacting to the hub plans so far?" | Neighbours, Not Numbers in practice, asked as interest rather than judgment |
| "Where do escalations from your branch tend to get stuck today?" | Practical, and it shows you'd start from their reality |
| "What would you want the monthly complaints report to tell you that it doesn't now?" | Lets them shape J3 and shows you'd build it for them too |
| "When a value like Own the Fix pulls against a busy day in branch, how does that usually play out here?" | Shows you've read the values as working rules, not slogans |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says the branch's log, not a process across branches. Answer slots stay inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. Your material says you trained new tellers. Slots ask only about what followed the teller training |
| Designed or wrote the escalation script | Inflated form of F4 ("trained new tellers on our escalation script") | F4's quote at its own scope. No slot asks about authorship |
| Reported monthly to leadership on volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. G1's slot asks only what the spreadsheet counts |
| Has worked in a contact centre | A negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | "I haven't presented to anyone above regional level." C3's slot covers only regional level |

---

## Sources

**Provided documents**
- The JD (pasted)
- Ashgrove's values (text you copied on 26 November 2026 from ashgrovecu.org/about/values; not fetched)
- The recruiter's email about the process
- The 2026 strategy brief, as you summarised it (published July 2026)
- Your background, from your message

**Searches and fetches:** none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you copied this morning settles the cheat sheet and the H bank |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email sets out all three rounds, the case and the values scoring, which settles the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 strategy brief is under six months old and settles the CO and CASE questions and the grounding brief |
| 4. Interviewer names | n/a | No names have been assigned, so there was no query to form. There is no interviewer read, and the upgrade menu says what names would add |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied settles the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names, when assigned:** a public-footprint read per interviewer, persona weights tuned per person, and at least one reverse question tied to their own path in each round.
- **Your answers to the answer slots in F1, F3, F7, F8 and F9:** what the spreadsheet counts and which tool it uses, whether the formal complaints were regulated, whether you've presented at regional level, and what you did beyond the log. Those rows, and G1, B1, C3 and D1, would get stronger, more specific guidance.
- **Your CV:** more sentences to map stories from, especially for H1 and H3, which are scaffolds now.
- **The full strategy brief text:** the grounding brief would quote the brief directly rather than your summary, and might add complaint- or member-satisfaction figures for E1 and G2.
- **Case format from the recruiter** (scenario in advance or on the day, reading time, written or spoken): a tighter 20-minute plan.
- **How much prep time you have:** a prioritised prep schedule sized to it.
- **Deeper research pass:** up to 6 more searches and 2 more fetches, several more minutes. It covers Ashgrove's recent org changes (leadership, restructuring, hiring), reports from people who've interviewed for similar roles there, and the interviewers' talks and writing once you have their names. These feed the CO questions, the persona weights and the reverse questions.
- **A tuesday-dossier.md:** verified evidence and a named top objection would sharpen the fit snapshot and C1. Not needed for this pack.
