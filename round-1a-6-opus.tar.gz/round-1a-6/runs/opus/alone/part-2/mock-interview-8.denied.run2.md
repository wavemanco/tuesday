I've written your prep pack, saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. It follows the three rounds in the recruiter's email, with separate questions for each round.

- **Your background:** a table maps each job requirement to your own sentences. The two gaps you named yourself, the contact centre and presenting above regional level, each come with words you can say honestly.
- **The 20-minute case:** a structure that works for any complaint escalation, built around the four values. You also get three positions to pick from, each with a weakness you should say aloud.
- **Questions:** 31 practice questions across the three rounds, each with notes on how to answer. Round 3 includes a values table covering all four values by their official names. Your message didn't describe a full story for any value, so each one gets a guide for choosing a real example, plus what to say if none comes to mind.
- **What to rehearse most:** C1 in Round 2. The likely objection is that you've handled one branch's complaints log, have never worked in a contact centre, and this role covers the whole organisation. That's where rehearsal pays off most.

**Two things to know:**
- I didn't search the web. The values you pasted this morning, the recruiter's email and the July strategy brief already covered what a search would have checked.
- Several requirements, like what your spreadsheet tracks and which rules your complaints log followed, aren't covered by what you told me. The pack leaves those as blanks with two honest options rather than filling them in. If you tell me the answers, I'll rebuild those questions around your real details.

If you'd like to practise, I can play the skeptical manager and run you through C1.
I can also save a `tuesday-dossier.md` file listing the gaps this prep exposed, so you can use it in later sessions.
If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop (from the recruiter's email):** three rounds on 5 December 2026
- Round 1: 30 minutes with the recruiter
- Round 2: 45 minutes with the Head of Member Services (your would-be manager), mostly behavioural
- Round 3: 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case. This is also the values round, scored against the four values

**Interviewers:** no names assigned yet. Personas are weighted from each round's role and the recruiter's description.

---

## How to use this pack

- **Personas** describe *how* a question is asked: friendly chat, skeptical probing, a live case. **Types** describe *what* is being scored. Rehearse both. The same question sounds very different from a recruiter and from a skeptic.
- **Type key**
  - **VAL**: whether your past behaviour shows Ashgrove's *published* values
  - **EXP**: whether what you say about your experience holds up when probed; what was actually you
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: whether you know Ashgrove's strategy and can think about it at their level
  - **CASE**: how you structure a live problem from the role
- **Provenance labels**
  - `[grounded]`: traceable to what you or the recruiter gave me
  - `[inferred]`: this pack's own reasoning from that material
  - `[generic]`: a pattern for this kind of role, with no claim about Ashgrove or about you
- **Answer slots** mark places where your material is silent. Each slot gives you two honest branches. Answer whichever one is true. The pack never fills in the middle for you.
- Guidance is scaffolding, not a script. Say it in your own words.

---

## 1. Fit snapshot (shared across all three rounds)

Every claim this pack makes about your past comes from these four sentences in your message, and from nothing else:

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material describes one branch's formal complaints log, not an organisation-wide process, and your words should stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe likely on what happened to a complaint after it reached the log. If any step beyond keeping the log was yours, say which and how, in your own words. If those steps sat with someone else, or the log was the whole of your part, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | This is a gap that wording can't close, and you have already said so. Your words: "I haven't worked in a contact centre." Then say how you would learn it, framed as a plan and never as something you've done. Don't claim contact-centre work, and don't add anything to make the gap feel smaller |
| F3 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material describes training new tellers on the branch's escalation script, not coaching supervisors: "I trained new tellers on our escalation script." It says "our" script and doesn't say who wrote it. The supervisor job is one you held: "the last 3 as a branch supervisor." Answer slot: the JD's coaching line makes a probe likely on how you trained. If you shaped how the training ran, say how, in your own words. If you delivered it as it was given to you, say so plainly and stay with the training you did |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your words: "I built the monthly complaints spreadsheet our regional manager uses." Your material doesn't say what the spreadsheet counts. Answer slot: the JD makes a probe on volumes and resolution times likely. If the spreadsheet tracks either, say how it counts them, in your own words. If it doesn't, say so plainly and say what it does track. Only describe what your regional manager does with it if you actually know |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if you have worked with a digital or online-banking team, or on a customer's digital journey, say what part was yours, in your own words. If you haven't, say so plainly, then explain how you would approach the work |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your words: "I handled the branch's formal complaints log." Your material doesn't say which rules the log ran under. Answer slot: the JD's regulated-complaints line makes a probe on those rules likely. If the log worked to set rules or deadlines, say what they were and which parts you kept to, in your own words. If you don't know, or there were none, say so plainly and stay with the log you handled |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | This is a gap you have stated yourself. Your words: "I haven't presented above regional level." Answer slot: the JD makes a probe likely on what you *have* presented. If you have presented at regional level or below, say to whom and on what, in your own words. If you haven't presented at all, say so plainly. Then give a plan for building the skill, framed as a plan |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says "spreadsheet" and doesn't name the tool. Answer slot: if it's in Excel, say which features you built it with, in your own words. If it's in another tool, say so plainly and name the tool |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already meets this requirement in its own terms, so say it as it is: "Six years in retail banking, the last three as a branch supervisor." Don't relabel it in the JD's vocabulary. Describe the work and let the interviewer make the match |

How to read the table: F2 and F7 are the gaps you stated yourself. F1 and F3 are adjacent work at a smaller scope. F4, F5, F6 and F8 are silences, and only you can fill them, in the interview, through the answer slots. None of the requirements is an eligibility gate.

---

## 2. Graded deliverable: the 20-minute complaint-escalation case (Round 3)

The recruiter announced this case, so treat it as graded. You don't know the scenario yet. Build a structure you can bring to any escalation.

**Facts you can build on**

| Fact | Source | Provenance |
|---|---|---|
| A 20-minute case on a complaint escalation, run by two branch managers who also score the four values | Recruiter's email | [grounded] |
| Values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Values page as you pasted it | [grounded] |
| Eight branches consolidating into five hubs over 2027; 40% of member service moving to digital by 2028 | 2026 strategy brief, as you summarised it | [grounded] |
| Your own base: F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Fit snapshot F1 | [grounded] |

**A structure for any escalation** `[generic]`

1. **Clarify (about 2 minutes).** Ask who the member is, what they want, how long the complaint has been open, what has already been said to them, and whether anything suggests the member is vulnerable.
2. **Member first.** Settle what the member needs today, before root cause.
3. **Rules check.** Ask the panel which complaint rules or deadlines apply here. Don't name a regulator or a deadline you haven't checked.
4. **Own the Fix.** Say who keeps hold of the complaint from now until it is solved. In the role, that would be you.
5. **Plain Words.** Explain what the member will be told, and how, in words they won't need explained twice.
6. **Neighbours.** Say how the branch manager and supervisor stay involved, because the member's branch is part of their town.
7. **Root cause and loop back.** Decide whether this is one case or a pattern. If it's a pattern, it goes into the monthly report, and the supervisor gets coached on it.

**Three theses to choose from (each has a concession you must say aloud)**

| Thesis | Concession |
|---|---|
| Resolve for the member first and investigate the root cause second | Some cases can't be fixed until the facts are in. Then the member is told what is happening, and when |
| An escalation is a coaching moment for the supervisor, not just a handoff upward | Some escalations go straight up: anything with a rules deadline, a vulnerable member, or suspected fraud |
| Every escalation is data, so log it, trend it and report it monthly | Logging must never slow the member's resolution |

**How to stand out** `[inferred]`

Most candidates will answer "apologise, investigate, resolve, follow up". Use that as your spine. Then go further in two ways:
- Name the values by their official names at the step where each one decides something.
- Ask one strategy question, for example: did this complaint come from a channel change, such as a member pushed to digital, or a branch moving into a hub?

**What not to do.** Don't promise a goodwill payment or an outcome before you have the facts. Don't go around the branch manager. The two people scoring you are branch managers.

---

## 3. Grounding brief (from the strategy brief you received)

| # | Fact | Source | Provenance | How to use it |
|---|---|---|---|---|
| S1 | Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026, as you summarised it | [grounded] | G1 and G2. The JD's self-service line sits here |
| S2 | Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | [grounded] | K2 and the case. Handle it with care in front of branch managers |
| S3 | Launch a small-business lending product in Q1 2027 | Strategy brief, July 2026 | [grounded] | A reverse question on whether complaints from business members will sit in this role |
| S4 | The main competitive pressure is app-only banks | Strategy brief, July 2026 | [grounded] | Why the member experience and the complaints journey matter to strategy |
| S5 | Member-owned, about 900 staff | JD | [grounded] | Use "members", never "customers", for Ashgrove's people |
| S6 | Panel members may run branches that the 2027 consolidation affects. This isn't known | This pack's reasoning from S2 and the recruiter's email | [inferred] | Talk about hubs in terms of members and towns. Don't speculate about whose branch is affected |

The brief dates from July 2026, so it is about four months old. Listen for newer framing on the day and follow it without correcting anyone.

---

## 4. Requirement coverage

| JD requirement | Fit row | Covered by |
|---|---|---|
| Own the complaints process end to end | F1 | C1, H1 |
| Across branches and the contact centre | F2 | B3, C1 |
| Coach branch supervisors on escalations | F3 | C3, D4, K1 |
| Report monthly on volumes and resolution times | F4 | E1, E2 |
| Work with digital teams on self-service | F5 | G2, G1 |
| Regulated complaints | F6 | E3, H1 |
| Presenting to senior leaders | F7 | B4, L1 |
| Excel reporting | F8 | E1, L2 |
| 4+ years in financial-services customer operations | F9 | B2, A1 |

---

## 5. Highest-ROI prep: C1

**C1** (Round 2, Skeptic) is the objection most likely to come up in some form: one branch's log and no contact-centre experience, set against an organisation-wide role. Rehearse it until it's boring. Its concession wording is already written for you in the C1 row.

---

## Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through your background", logistics | High. A recruiter screen is conversational by default, and 30 minutes leaves room for little else | Prepare a 90-second arc. Treat casual questions as scored |
| Skeptic (light) | Knockout checks against the JD's requirements | Medium. Recruiters screen on the stated requirements before handing you on | Short, plain answers on the stated gaps. Save depth for Round 2 |

### Question bank

**A. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc on exactly these beats: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on our escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Add no outcomes, numbers or titles that these sentences don't carry | Almost certainly the opener. F9, F1 and F4 in one breath. EXP because it sets up everything later probes will test |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Give your real reason, in your own words. If it fits, connect one value by its official name, or the JD's "end to end" line, to the log you handled. Don't recite the strategy. One fact (S1 or S2) shows you've done the homework | Motivation consistency is the recruiter's core check. CO because Ashgrove-specific knowledge is what's scored |
| A3 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: either give your own number or ask for the role's band first. Choose before the call. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is standard in a recruiter screen. JD because it's the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | Standard logistics. JD for the same reason |
| A5 | "The role spans branches and the contact centre. Where are you based, and how do you feel about moving between sites?" | JD | [grounded] | Logistics slot: say plainly where you can work and how much travel between sites you can take on, in your own terms. Commit to nothing you can't keep | The JD's "across branches and the contact centre" raises location. With hubs coming (S2), sites may change |

**B. Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give your actual reason in a sentence or two, in your own words. You don't need to say anything negative about your current employer | One of the four standard recruiter logistics. EXP because it's about your history |
| B2 | "The JD asks for 4+ years in financial-services customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say F9's line as it is: "Six years in retail banking, the last three as a branch supervisor." If they ask how it maps, describe what the work was and let them make the match | F9 is the likeliest literal screen. JD because it's a stated requirement |
| B3 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't worked in a contact centre." Then one sentence of plan, framed as a plan, for example how you would learn it in your first weeks. Keep it short here. The full rehearsal is C1 | F2, asked as a knockout. JD because the JD names the contact centre |
| B4 | "The role presents to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented above regional level." Answer slot (F7): if you have presented at regional level or below, say to whom and on what. If you haven't presented at all, say so plainly. Then one sentence of plan | F7 is a stated gap against a stated requirement, so expect a knockout check |

### Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "Is there anything I should prepare for the 20-minute case, or is it fully live?" | It may unlock material for section 2 and shows you take the case seriously |
| "Will I know the names of the Head of Member Services and the panel before the day?" | Names let you tailor rounds 2 and 3 (see the upgrade menu) |
| "Is this a people-management role, or a lead without direct reports?" | The JD says "Lead" but never names a team. The answer shapes how you pitch coaching |
| "How is the role's time split between branches, the contact centre and head office?" | Turns the location question into something you can plan around |
| "What made the Head of Member Services open this role now?" | Gives you the problem Round 2 will want you to solve |

---

## Round 2: Head of Member Services, 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | "Tell me about a time…" on complaints, escalation and coaching | Highest. The recruiter said "mostly behavioural" | STAR-shaped stories. "We" for context, "I" for your part. Each story has a clear end |
| Skeptic | Your scope against the role's scope; the contact centre; seniority | High. A hiring manager is reducing risk on the gaps in F1, F2 and F7 | The rehearsed concession in C1. Hold what you did, concede what you didn't, give a plan |
| Data-Driven Prober | The monthly spreadsheet, resolution times, what was counted | Medium. The role reports monthly, and your spreadsheet (F4) is the obvious thread to pull | Know what you can and can't say about the spreadsheet, and say plainly what you don't know |
| Case / Strategist | Digital shift, self-service, the monthly report | Lower. "Mostly behavioural" leaves some room for these | Clarify, structure, then the risks. Use Ashgrove's own words: members, hubs |

### Question bank

**D. Values / Behavioural**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a complaint that was hard to resolve." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one complaint from the log you handled. It needs what the member raised, what *you* did, and how it ended. If no single case comes to mind, say so plainly, then describe how the log worked and your part in it | The JD's complaints line raises this, and F1 is your closest material. EXP because it tests what you actually did |
| D2 | "Tell me about a time you escalated something above your level." | EXP | [generic] | Selection scaffold: it needs what you escalated, why it was beyond you, who you took it to, and what happened. If no such time comes to mind, say so plainly, then say how you would decide when to escalate | The JD's "escalations" line raises this. It's the panel case's theme as well |
| D3 | "Tell me about a problem you found and kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold for Own the Fix: a problem you noticed, that you kept, and that got solved. Answer slot: if you built the spreadsheet because something was missing, say what was missing, in your own words. If it was asked of you, say so plainly and choose another story, or say none comes to mind | The manager may preview the panel's values. Own the Fix is the value closest to the job. VAL because it scores a published value |
| D4 | "Tell me about a time you helped a colleague handle an escalation better." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: a time you trained or helped a colleague with an escalation. The nearest material you have is training new tellers on our escalation script. Tell only what happened. If no single occasion stands out, say so plainly and describe how the training ran (F3's answer slot) | F3's coaching requirement, asked behaviourally. JD because it scores a listed duty |

**C. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints across every branch and the contact centre. You've handled one branch's log and you've never worked in a contact centre. Why should I believe you can own the whole thing?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** *Hold:* "I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." *Concede first, before you're asked:* "I haven't worked in a contact centre, and the log was one branch's." Answer slot (F1): if any step beyond keeping the log was yours, say which. If not, say so plainly. *Plan, framed as a plan:* what you would do in your first weeks to learn the contact-centre side, for example sitting in on its complaint calls. *Follow-up 1* ("A contact centre is a different beast"): agree that it's different, then come back to the log, the spreadsheet and the plan. Don't argue. *Follow-up 2* ("So you'd be learning on the job?"): "On the contact centre, yes, and I'd say so to the team there too." Never fold on what you did, and never add to it | F1 and F2 together are the widest gap between your material and the role's headline line. A hiring manager will press here. JD because it scores the headline requirement |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name one of your two stated gaps, either the contact centre or presenting above regional level, in its plain-acknowledgment words, then a plan. Don't offer a disguised strength | F2 and F7 are both on record. The candid answer is already written for you |
| C3 | "The role coaches branch supervisors. You've trained tellers. What's different about coaching supervisors?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Hold the scope: "I trained new tellers on our escalation script," and "the last three years" you were a branch supervisor yourself. Answer slot (F3): if you shaped how the training ran, say how. If not, say so. Then reason forward about what differs for supervisors, framed as your view of the role, not your history | F3 is adjacent work at a smaller scope. JD for the coaching line |

**E. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The JD asks for Excel reporting. Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats from the quote: you built it, it's monthly, and your regional manager uses it. Answer slot (F4): if it tracks complaint volumes or resolution times, say how it counts them. If not, say what it does track. Answer slot (F8): if it's in Excel, say which features you used. If it's in another tool, name the tool. Mention what your manager does with it only if you know | Your one reporting artifact, against two JD lines (F4 and F8). JD because those lines are what's scored |
| E2 | "Our monthly report goes to senior leaders. How would you measure resolution time, and what would make you distrust the number?" | CASE | [generic] | Structure it: when the clock starts and stops; average against median; split by branch and channel; complaints still open past a threshold. Then name the assumption you would trust least, for example whether every channel records when a complaint started in the same way | F4's requirement, asked as a live problem. CASE because it tests your reasoning, not your history |
| E3 | "The role involves regulated complaints. Tell me about your experience with them." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "I handled the branch's formal complaints log." Answer slot (F6): if the log worked to set rules or deadlines, say what they were and which parts you kept to. If you don't know, or there were none, say so plainly and stay with the log you handled | F6 is a stated requirement that your material is silent on. JD because it scores it |

**G. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We're moving 40% of member service to digital by 2028. What does that do to complaints, and what would you do about it?" | CO | [grounded] | Clarify which journeys move first. Expect the mix of complaints to shift toward digital journeys. Route complaint themes to the digital teams. Watch the members who can't or won't move, and name Members First, Always, there. Concede that you'd need the data before predicting volumes | S1 is a headline strategy item, and the role sits on it. CO because it scores knowledge of the strategy |
| G2 | "How would you work with a digital team building a self-service journey?" | JD | [grounded] | Answer slot (F5): if you have worked with a digital team, say what part was yours. If not, say so plainly. Then the approach: bring complaint themes early, test the wording against Plain Words, and agree what counts as success | F5 is a listed duty with no material behind it. JD for that reason |

### Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "Where does the complaints process break most often today: in branch, in the contact centre, or at the handoff between them?" | Shows you're thinking end to end, the JD's own phrase |
| "Who reads the monthly complaints report now, and what's the last decision that came out of it?" | Tells you how the reporting is really used before you inherit it |
| "How do complaints feed the digital self-service work today? Is there a standing link to the digital teams?" | Ties the JD's digital line to S1 |
| "What would a strong first 90 days look like to you?" | Gives you their measure of success, which you can reflect back in your thank-you note |
| "Will complaints from the new small-business lending product sit with this role?" | Shows you read S3, and it's a real scope question |

---

## Round 3: Panel of two branch managers, 60 minutes (values round plus the case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | One or more questions per value, scored against the four values | Highest. The recruiter said they score against all four | Name each value by its official name. Tell stories that end with something decided |
| Case / Strategist | The 20-minute escalation case | Certain. It was announced | Section 2's structure |
| Peer Evaluator | "How would you work with my supervisors?" | High. You'd be coaching the supervisors who report to them | Reciprocity: what you bring their branch, not just what you need |
| Pressure | Time-boxed pushes on your gaps | Medium. Two scorers and a case leave room for challenge | Pause, restate the question, hold, concede specifically |

### Values cheat sheet

No sentence in your message carries a full values story, so each value gets a selection scaffold. The nearest row is named, and you tell only what actually happened.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide as if you were the member | Scaffold: a time you made a call from the member's side, when an easier internal route existed. Nearest row: F1, "I handled the branch's formal complaints log." If no such time comes to mind, say so plainly and say how you would decide |
| Plain Words | If it needs explaining twice, the explanation was wrong | Scaffold: a time you made something simpler for a member or a colleague. Nearest row: F3, "trained new tellers on our escalation script." If none comes to mind, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town | Scaffold: a time local knowledge of a member or the town changed what you did. Nearest row: F9, "the last 3 as a branch supervisor." If none comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps it until it's solved | Scaffold: a problem you found and kept until it was solved. Nearest row: F4, "I built the monthly complaints spreadsheet our regional manager uses." Use it only if the D3 slot's first branch is true. If none comes to mind, say so plainly |

### Question bank

**J. Values**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Use the Members First scaffold above. It needs the decision, the easier option you turned down, and what the member got. If nothing comes to mind, say so plainly, then say how you'd decide | Members First uses this exact phrase. Expect it nearly verbatim |
| J2 | "Tell me about a time you had to explain something more simply." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use the Plain Words scaffold. The teller training is your nearest material. Tell what you actually explained and how, without inventing a moment. If no instance comes to mind, say so plainly | Plain Words is scored, and F3 is the closest row |
| J3 | "Tell me about a time you treated a member as a person, not a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Use the Neighbours scaffold. It needs a specific member or local situation and what you did differently because of it. If none comes to mind, say so plainly | The name of the value invites this wording. Branch managers will listen closely |
| J4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] | Use the Own the Fix scaffold. Say who else could have let it drop, and the moment you kept hold. If it's the same story as D3, tell it again consistently | Own the Fix's own definition. The panel may repeat Round 2's question on purpose |

**H. Case**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | The 20-minute case: "A complaint has been escalated from one of our branches to you. Talk us through what you'd do." | CASE | [grounded] | Section 2: clarify, member first, rules check, Own the Fix, Plain Words, Neighbours, then root cause. Pick one thesis and say its concession. Ask the panel which complaint rules apply rather than assuming | The recruiter announced it. CASE by definition |
| H2 | "One of our supervisors resolved a complaint in a way you disagree with. What do you do?" | CASE | [generic] | Clarify what was done and why. Check the member outcome first. Talk to the branch manager before the supervisor. Coach the pattern, not the person. Record it if it's a theme | A natural follow-up to the case from people who manage those supervisors |

**K. Peer**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "If you're coaching my supervisors on escalations, how do we make sure that helps me rather than undermines me?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | You were a branch supervisor for the last three years, so you've held the job they're in. Propose principles: agree the approach with the manager first, coach on patterns, report back to the manager, and never overrule them in front of their team | F3's requirement, seen from the branch manager's side. JD for the coaching line |
| K2 | "We're consolidating eight branches into five hubs over 2027. What does that mean for complaints and for branches?" | CO | [grounded] | Treat it as a member question first. Expect complaints about access and change during the move. Track them as their own theme. Keep Neighbours, Not Numbers, visible. Don't speculate about which branches are affected (S6) | S2 is live for these interviewers. CO because it scores strategy knowledge |

**L. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You've never presented above regional level. Sixty seconds: why should we trust you in front of senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause. "I haven't presented above regional level." Answer slot (F7): if you have presented at regional level, say to whom and on what. Then a plan framed as a plan, for example asking to present the monthly report early with your manager there. Hold through a second push. Don't upgrade the experience | F7 is your stated gap, and a pressure-style push on it is likely. JD for the presenting line |
| L2 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built it." Answer slot: if someone else set what it should contain, say so plainly and say which part was yours. If the design was yours, say how you decided it, in your own words | Your one built artifact draws the attribution probe. EXP by type |

### Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What does a good escalation from your branch look like today, and what does a bad one look like?" | Reciprocity. It shows you'll work from their reality |
| "What could I do in my first month that would genuinely help your supervisors?" | The peer reciprocity question, about what you'd bring them |
| "How are your branches thinking about members through the move to hubs?" | Neighbours, Not Numbers, asked with care |
| "When a complaint crosses from a branch to the contact centre, who keeps hold of it today?" | Own the Fix, in the values' own words |
| "Where do members in your town still need the branch most?" | Neighbours again, and it informs how you'd shape digital journeys |

---

## Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." My observation: the material describes one branch's log, not an organisation-wide process. C1's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Coached supervisors | Inflated form of F3 | "I trained new tellers on our escalation script." C3's slot asks only how the training ran |
| Wrote or designed the escalation script | Inflated form of F3 | The same quote. My observation: the material says "our" script and doesn't say who wrote it |
| Reports on complaint volumes and resolution times | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." E1's slot asks only what it counts |
| Handled regulated complaints | Inflated form of F6 | "I handled the branch's formal complaints log." E3's slot asks only which rules the log worked to |
| Has presented to senior leaders | Negative you stated, F7 | "I haven't presented above regional level." |
| Advanced in Excel | Inflated form of F8 | F8's quote. E1's slot asks only which tool and features |

---

## Sources

**Provided documents**
- The JD, pasted
- The values text, which you say you copied on 26 November 2026 from ashgrovecu.org/about/values, pasted
- The recruiter's email on the process, pasted
- Your summary of the 2026 strategy brief (published July 2026)
- Your background, from your message

**Searches and fetches:** none sent. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted this morning already fix the values cheat sheet and J1 to J4 |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email already fixes the three rounds, the case and the values round |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief (under six months old) already fixes the grounding brief, G1, K2 and the CO reverse questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names have been assigned, so no query could be formed |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Interviewer names (Head of Member Services, panel members)** → a reading of each interviewer's public profile, per-person persona weights and a reverse question tailored to their career path
- **Your answers to the answer slots in F1, F3, F4, F6 and F8** (what the spreadsheet counts and what it's built in; which rules the log worked to; any step beyond the log; how the training ran) → those rows become story-mapped, and C1, C3, E1, E3 and L2 are regenerated around your actual words
- **Your CV** → more sentences to map. J1 to J4 and D1 to D4 could move from scaffolds to mapped stories
- **The strategy brief itself, not just the summary** → a fuller grounding brief and sharper G1 and K2
- **How many hours you have before 5 December** → a prioritised prep schedule
- **Whether any case material comes in advance** (one email to the recruiter) → section 2 rebuilt around the actual scenario
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → recent organisational context and candidate reports on Ashgrove's interviews
- **A `tuesday-dossier.md` from an earlier evaluation of this role** → an objection derived from evidence and a prohibited-claims list from verified evidence. Not required
