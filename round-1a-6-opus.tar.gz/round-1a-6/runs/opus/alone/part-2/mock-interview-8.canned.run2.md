I've built your prep pack: **ashgrove-credit-union_member-experience-lead_interview_pack.md**. It has a separate section for each of your three rounds on 5 December, all working from one shared table that compares your background with the job description. I did no web searches, because your notes already covered Ashgrove's values, how the interviews will run and its strategy.

- **Shared section:** each job requirement is matched against your own words, rated honestly, with the gaps marked and how to talk about them.
- **Round 1, the recruiter:** your background in 90 seconds, why Ashgrove, and the practical questions (pay, notice, location, why you're leaving). It also covers quick checks on the requirements, like regulated complaints, contact-centre experience and Excel.
- **Round 2, the Head of Member Services:** this is where the doubting questions land. The most valuable thing to rehearse in the whole pack is question **B4**: "You haven't worked in a contact centre, so how would you own that half?" The pack gives you a plain admission, a learning plan, and answers to three follow-ups. Presenting to senior leaders and coaching supervisors come next.
- **Round 3, the branch managers:** one question for each of the four values, using their exact names. There's also a ready-made structure for the 20-minute case: a time plan, three positions you could take (each with the downside you should admit), and what not to do. A few questions tie the strategy in, like the move to five hubs, the new small-business lending product and app-only banks.
- **Claims the pack won't coach:** for example, saying you ran complaints across branches, wrote the escalation script, or have contact-centre experience.

In some places your notes don't say enough, such as what the spreadsheet tracks, or whether those complaints fell under regulatory rules. There the pack gives you two honest ways to answer rather than filling in details for you.

Say the word and I'll play the doubting interviewer on B4 as a live practice run.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date:** all three rounds on 5 December 2026
**Format:** loop mode, three rounds, built from the recruiter's email:

| Round | Length | Who | What it holds |
|---|---|---|---|
| 1 | 30 min | The recruiter | Screen |
| 2 | 45 min | Head of Member Services, your would-be manager | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | Values round, scored "against the four values", plus a 20-minute complaint-escalation case |

No interviewer names have been given yet, so this pack has no interviewer read.

---

## How to use this pack

- **Personas** describe how a question is asked: who asks it and in what style. **Types** describe what the answer is scored on. Rehearse both.
- **Type key**
  - **VAL**: whether your past behaviour shows Ashgrove's *published* values.
  - **EXP**: whether your background holds up under scrutiny, including what was actually you.
  - **JD**: whether you can do the listed job, gaps included.
  - **CO**: company and strategy knowledge.
  - **CASE**: a live problem from the role.
- **Provenance labels**
  - `[grounded]`: traces to something you or Ashgrove supplied.
  - `[inferred]`: derived by this pack, with the derivation named.
  - `[generic]`: a role-family pattern that claims nothing about Ashgrove or you.
- **Answer slots** are instructions for the interview, not questions for you to answer here. Each one has two honest branches. Either branch is a good answer.
- **Language.** Ashgrove says "member". Your past bank had customers. When you talk about Ashgrove, say "members". When you describe your own past, say "customers", because that's who they were.
- The guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- Question IDs use one letter per persona. F is reserved for fit-snapshot rows.
  - A: Conversational
  - B: Skeptic
  - C: Values/Behavioural
  - D: Case/Strategist
  - E: Data-Driven Prober
  - G: Pressure
  - H: Peer Evaluator
- **Highest-ROI prep in this pack: B4**, the contact-centre objection in Round 2.

---

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material describes one branch's log, not a process across branches, so keep your words at that scope: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on your part in those complaints likely. If some steps in handling the complaints in that log were yours to decide, say which ones and how you decided, in your own words. If your part was keeping the log, or those steps sat with someone else, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You have said this yourself, and no wording closes it. Words: "I haven't worked in a contact centre." Then say how you would learn that side, as a plan and never as a past. Add nothing to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote covers monthly complaints work. It doesn't show what the spreadsheet measures, or who reports from it. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracks volumes or resolution times, say which, in your own words. If it tracks other things, say what. How the regional manager uses it is theirs to describe, so say only what you know |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and "our" script, not one it says you wrote. Words: "I trained new tellers on our escalation script." Answer slot: if any part of how that training was run was yours to shape, say which part, in your own words. If you delivered it as it was given to you, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if you've worked with an online or app team, or on a change to how customers serve themselves, say what part was yours, in your own words. If not, say so plainly, then say how you would start: what complaints would tell a digital team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms and let them make the match: "Six years in retail banking, the last three as a branch supervisor." Don't relabel it "customer operations" yourself |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" doesn't show whether those complaints fell under regulatory rules. Answer slot: if they did, say which rules applied and what that meant for how you handled them, in your own words. If you aren't sure, or they didn't, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this yourself. Words: "I haven't presented to anyone above regional level." Your sentence doesn't say whether you have presented *at* regional level. Answer slot: if you have, say to whom and about what, in your own words. If not, say so plainly. Then say how you would prepare, as a plan |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says "spreadsheet" but not which tool. Answer slot: if it's in Excel, say so and name what you use in it, in your own words. If it's another tool, name that tool |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Own complaints process end to end across branches (F1) | A1, C1, D3, H3 |
| …and the contact centre (F2) | B2, B4, G1, H3 |
| Report monthly on volumes and resolution times (F3) | E1, E2, D2 |
| Coach branch supervisors on escalations (F4) | B6, H1, H2 |
| Work with digital teams on self-service journeys (F5) | D1, G2 |
| 4+ years financial-services customer operations (F6) | A1 |
| Regulated complaints (F7) | B1, D3 |
| Presenting to senior leaders (F8) | B5 |
| Excel reporting (F9) | B3, E1 |

---

## Grounding brief: sound current, not archival

Everything here comes from what you supplied: the JD, the values text you copied on 26 November 2026, and the July 2026 strategy brief as you summarised it.

- **Vocabulary**
  - "member-owned"
  - "members", never "customers", for Ashgrove's people
  - "member's side of the counter"
  - "self-service journeys"
  - "hubs"
  - "digital channels"
- **Headline numbers**
  - Move 40% of member service to digital channels by 2028.
  - Consolidate eight branches into five hubs over 2027.
  - Launch a small-business lending product in Q1 2027.
  - About 900 staff.
- **Competitive frame:** the brief names app-only banks as the main pressure.
- **How these touch this role**
  - Hub consolidation changes where complaints arise and who handles them.
  - The digital shift is the JD's "self-service journeys" line.
  - A new lending product means new kinds of complaint.

  These links are this pack's reading of the brief, not something it states.
- **Freshness:** the brief is from July 2026. Timelines may have moved since then. If an interviewer frames something differently, follow their framing and ask about it. Don't correct them from the brief.

---

## Round 1: Recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | High. The recruiter-screen prior is mostly logistics and motivation in a relaxed tone, and it is still scored | A rehearsed 90-second arc (A1). Treat every casual question as scored |
| Skeptic (light) | Knockout checks against the JD's listed requirements | Medium. Recruiters screen the requirement list, and F2 and F7 are the lines most likely to be checked | Short, plain answers. Don't over-explain a gap at this stage, and save the depth for Round 2 |
| Values / Behavioural | One "why Ashgrove" values-tinged question | Low. The values round is Round 3, but a values page this fresh is easy for a recruiter to reference | Know the four value names exactly |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | 90 seconds, built only from these sentences: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words. Don't add titles, team sizes or results these sentences don't state | The biography question opens most screens, and A1 sets the frame every later round inherits; EXP because it fixes what you'll be held to |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Name one thing Ashgrove has published that genuinely matters to you, such as a value by its exact name or a strategy line, and say why in your own words. Make no claim to credit-union experience. Your motive is the answer slot: give your real reason | Motivation consistency is the recruiter's main screen; CO because the answer should show you read the values and the brief |
| A3 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your real reason in your own words, framed toward what this role offers rather than against your current employer | One of the four logistics a screen covers; the only safe answer is your own |
| A4 | "What salary are you looking for?" | JD | [generic] | Give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Standard screen logistics; JD because it concerns the listed job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Give your actual notice period | Screen logistics; sets the start-date conversation |
| A6 | "Where are you based? The role covers branches and the contact centre." | JD | [grounded] | Give your actual location and the travel you can genuinely do. Make no promise you'd need to walk back | The JD's "across branches and the contact centre" line makes location and travel a likely screen point, and the branch-to-hub change raises where the role sits |
| B1 | "The role asks for regulated complaints experience. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log" | Lead with the quote: "I handled the branch's formal complaints log." Answer slot: if those complaints fell under regulatory rules, say which rules applied and what that meant for how you handled them, in your own words. If you aren't sure, or they didn't, say so plainly and stay with the log | F7 is a listed requirement the recruiter can tick or not; JD because it scores the stated line |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "No, I haven't worked in a contact centre." Then one sentence on what you bring, using A1's sentences, and one on how you'd learn the contact-centre side, as a plan. Keep it short; B4 is the full rehearsal | F2 is a JD headline line, and a recruiter may check it as a knockout; a calm, short answer here protects Round 2 |
| B3 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it's in Excel, say so and name what you use in it. If it's another tool, name that and say how quickly you'd adapt | F9 is a listed requirement; JD because it is a tick-box item |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does the Head of Member Services most want this person to fix in the first six months?" | It tunes your Round 2 answers to the manager's real priority |
| "Is the 20-minute case given in advance or on the day, and is it a discussion or a presentation?" | It lets you fit the case build in Round 3 to the actual format |
| "Could you share the panel members' names before 5 December?" | Names allow a proper interviewer read; it is a normal request |
| "Does complaints handling in the contact centre already sit in Member Services, or would this role bring it together?" | It tells you how much of F2 is the job's centre of gravity |
| "What happens after 5 December, and when would I hear?" | Basic process clarity, and it signals you're organised |

---

## Round 2: Head of Member Services (45 minutes, "mostly behavioural")

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the contact-centre, senior-presenting and coaching gaps | Highest. The hiring-manager prior, plus F2 and F8 both being stated gaps against JD headline lines. Your manager is the one buying the risk | Rehearse B4 until it's boring. Give plain acknowledgments, use only adjacent evidence you stated, and offer a concrete ramp plan |
| Values / Behavioural | "Tell me about a time…" questions | High. The recruiter called this round "mostly behavioural" | Answer with real stories in "we for context, I for contribution" form. Use the selection scaffolds where your material carries no story |
| Case / Strategist | Short live problems on the report and the strategy | Medium. The hiring-manager prior, reduced by the behavioural framing | Clarify, structure, then answer, using Ashgrove's own vocabulary |
| Data-Driven Prober | Your spreadsheet, and how resolution time gets measured | Low to medium. F3 is the evidence nearest to the reporting duty | Know what the spreadsheet actually tracks. Say "I don't know" where you don't |
| Pressure | One time-boxed challenge | Low. A possible test of composure | Pause, restate the question, hold, then concede specifically |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "This role owns complaints across the contact centre as well as branches. You haven't worked in one, so how would you own that half?" ★ **Highest-ROI prep in this pack** | JD | [grounded] "Never worked in a contact centre" "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | **Open (hold only what the quotes carry):** "That's right, I haven't worked in a contact centre. I've had six years in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log and trained new tellers on our escalation script." **Then the plan, said as a plan:** what you'd do first to learn that side (time with handlers, following complaints through both channels, asking where they stall between them). **Follow-up 1:** "Your team there would know it better than you." Agree, and say you'd learn their process from them, not pretend otherwise. **Follow-up 2:** "Why would branch experience transfer?" Describe what you did and let them draw the inference; don't call your work proof. Answer slot: if complaints in your log came in by phone or other channels as well as in person, say so; if they didn't, say so plainly. **Follow-up 3, if pressed, concede specifically:** "You'd be betting on how fast I learn that side; here's how I'd make that bet small", then the plan again with a 90-day shape. Never call a contact centre "basically the same as a branch" | F2 is a stated gap against a JD headline line, and the manager owns this risk, so some version of this is close to certain; JD because it scores the stated responsibility |
| B5 | "You'll present complaint trends to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words; if not, say so plainly. Then a plan for the first senior-leader report: what you'd lead with, how you'd keep it to plain words, and who you'd rehearse it with. Hold the plain acknowledgment; don't backfill | F8 is a stated gap against "confident presenting to senior leaders"; the second most likely objection |
| B6 | "You'd be coaching branch supervisors, people at the level you're at now. How would you do that?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor." | Answer mostly as a plan: start from their real escalations, agree what "good" looks like, then follow up. Your evidence, at its scope: "I trained new tellers on our escalation script." Answer slot: if any part of how that training ran was yours to shape, say which; if you delivered it as given, say so plainly. Don't present teller training as coaching supervisors; the pack's observation is that it was tellers | F4 is transferability against a JD duty; JD because coaching supervisors is a named responsibility |
| B7 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Pick one stated gap, not a fake weakness: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Name it plainly and give the plan. Choosing a real gap scores higher than a dodge | The Skeptic's classic stem; F2 and F8 make an honest answer ready-made |
| C1 | "Tell me about a time a complaint escalated and you had to step in." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one specific complaint, with a named customer situation (no personal details), what you did, and how it ended. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries ("I handled the branch's formal complaints log") or how you would handle one | Escalations are the JD's core; behavioural framing matches the recruiter's "mostly behavioural"; VAL because Members First and Own the Fix are both in play |
| C2 | "Tell me about a time you told a manager something they didn't want to hear." | VAL | [generic] | Selection scaffold: a named stake, the moment you said it, what happened, and a relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard behavioural probe for a role that reports upward; nothing in your material carries it yet |
| C3 | "Tell me about something you built because the existing way wasn't working." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The nearest candidate is the spreadsheet. Answer slot: if you built it because something wasn't working, say what wasn't and what changed; if it was a request rather than a fix, say so plainly and pick another example, or use it as what it is: "I built the monthly complaints spreadsheet our regional manager uses." | Echoes "Own the Fix"; F3 is your strongest artefact, but the quote doesn't say why it was built |
| D1 | "We plan to move 40% of member service to digital by 2028. How would complaints help the digital team?" | CASE | [grounded] | Structure: what complaints reveal (where members get stuck, what they ask twice), how you'd hand it over (a regular theme summary, examples in members' own words), and how you'd know it helped (fewer repeat complaints on that journey). Answer slot for F5: if you have worked with an online or app team, say what part was yours; if not, say so plainly and stay with the plan | The JD's digital line plus the brief's 40% target; CASE delivery on JD content (F5) |
| D2 | "One month's report shows resolution times up sharply at one branch. What do you do?" | CASE | [generic] | Clarify first: is it volume, mix, staffing, one big case, or a counting change? Then check the log, talk to the branch supervisor before judging, fix the cause or support the branch, and report what you found in plain words | A live problem straight from the JD's reporting duty; tests diagnosis before blame |
| E1 | "Walk me through the monthly complaints spreadsheet you built: what's in it, and how is it used?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe it as you built it: what goes in, what comes out, how often. Answer slot: if it tracks volumes or resolution times, say which and how each is counted; if you don't know how a figure is counted, say so. For how the regional manager uses it, say only what you know first-hand. Don't inflate "uses" into "reports to the board" or similar | F3 is your nearest evidence to the reporting duty and the most inspectable thing you have; EXP because a prober will go line by line |
| E2 | "How would you measure resolution time, and what would make the number misleading?" | CASE | [generic] | Define the clock: when it starts and stops, and whether reopened complaints count. Then the traps: averages hiding a long tail (offer the median alongside), changes in complaint mix, and counting changes between months. Name the assumption you'd defend least | The JD names "resolution times"; a manager will test whether you can own that number |
| G1 | "Sixty seconds: why you over someone who's already run a contact-centre complaints team?" | JD | [grounded] "Never worked in a contact centre" "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" | Pause, then: "I haven't worked in a contact centre, and someone who has would know that side faster." Then the branch side, from A1's sentences, and the plan. Hold: don't claim the gap away. Concede specifically: they'd ramp faster on the phone side; you'd still have to learn it | A Pressure version of B4; rehearsing it time-boxed makes the calm version automatic |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does the monthly complaints report look like today, and who reads it?" | It shows you're already thinking about the reporting duty and the senior audience, and it feeds your F3 and F8 plan |
| "Where do escalations get stuck today: in branches, in the contact centre, or between them?" | It shows "Own the Fix" thinking and gives you the real problem for your first 90 days |
| "How do you expect complaints to change as the hubs open and more service moves to digital?" | It ties the role to the published strategy, at the manager's level |
| "How much of the role is coaching supervisors, and how much is handling complaints directly?" | It clarifies the F4 balance and shows you care about doing the coaching well |
| "A year in, what would tell you this hire worked?" | It invites your future manager to set the bar, which you can then speak to |

---

## Round 3: Panel of two branch managers (60 minutes: values round + 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scored questions on each of the four values | Highest. The recruiter: "they score against the four values" | Prepare one story per value, using the cheat sheet below, and name the value naturally |
| Case / Strategist | The 20-minute escalation case, plus strategy questions | High. The case is pre-declared | Use the case build below. Clarify first and say the structure out loud |
| Peer Evaluator | "What would you need from us?" and branch-side seams | Medium. This role would coach their supervisors, so they're pricing what you'd add to or take from their branches. That reading of the role is `[inferred]` from the JD | Reciprocity framing: what you bring their branches. Propose principles, not a seam you can't know yet |
| Pressure | One devil's-advocate push on branches versus app-only banks | Low | Hold, then concede specifically |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Members First, Always. Tell me about a time you decided something from the customer's side of the counter, even when it was harder for the branch." | VAL | [grounded] | Selection scaffold: a specific decision, a named cost to the branch or to you, and what the customer got. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it here | The panel scores this value by name; nothing in your material yet carries a story, so a scaffold |
| C5 | "Plain Words. Tell me about a time you explained something so it landed first time." | VAL | [grounded] "trained new tellers on our escalation script" | Nearest material: "I trained new tellers on our escalation script." Answer slot: if you changed how you explained the script so it landed first time, say what you changed; if not, say so plainly and pick another moment, perhaps a customer letter or conversation, or say how you'd apply it to a complaint response | Value scored by name; F4 is the nearest teaching evidence, though the quote doesn't show a plain-words moment |
| C6 | "Neighbours, Not Numbers. Tell me about a time you treated someone as part of the community, not just a case." | VAL | [grounded] | Selection scaffold: a specific person (no personal details), what made it local or personal, and what you did differently because of it. If no such time comes to mind, say so plainly, then say how you'd keep the town in view as branches become hubs | Value scored by name; especially live for branch managers during a hub consolidation |
| C7 | "Own the Fix. Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Candidate story: the spreadsheet. Answer slot: if you built it because you found a problem, say what it was, how you kept hold of it, and what changed; if it was a request rather than a problem you found, say so plainly and choose another example, or give the scaffold version: what you found, who you told, how you kept hold, and the end state | Value scored by name; F3 is the likeliest fit, but the quote doesn't say it began as a problem |
| D3 | The 20-minute complaint-escalation case | CASE | [grounded] | Use the build section below | Pre-declared by the recruiter; a graded deliverable |
| D4 | "Over 2027, eight branches become five hubs. What happens to complaints during that, and what would you do?" | CASE | [grounded] | Structure: what is likely to rise (access, travel, changes of familiar staff), how you'd spot it early (theme tracking by town, not only by hub), what you'd do (plain-words notices, a named owner per town, supervisor coaching ahead of each move), and what you'd report. Show you know it affects their branches, and don't speculate about their own roles | The consolidation is in the brief and lands directly on branch managers; CASE on CO content |
| D5 | "Small-business lending launches in Q1 2027. What would you put in place for complaints before launch?" | CASE | [grounded] | Clarify what's new about it (new members, new staff, new rules). Then: how complaints will be logged and categorised from day one, who handles them, how quickly themes reach the product team, and a 90-day review | A named Q1 2027 launch; tests forward planning at the role's altitude |
| H1 | "You'd be coaching our supervisors on escalations. What would you need from us?" | JD | [generic] | Reciprocity first: what you'd bring their branches (consistent handling, fewer escalations bouncing back, plain reporting), then what you'd ask for (time with supervisors, real cases, honest feedback). Propose principles rather than a process you haven't seen | The reciprocity probe a peer-ish panel weights; JD because it is the coaching duty (F4's requirement) |
| H2 | "A supervisor in my branch disagrees with how you've asked them to handle an escalation. What happens?" | CASE | [generic] | Listen first, then go back to the member outcome and the rule, decide together where you can, and be clear who owns the fix. Bring in the branch manager early, without going over their head | Tests spine and tact with the panel's own people |
| H3 | "How would you make sure branch and contact-centre complaints are handled and reported the same way?" | JD | [grounded] "Never worked in a contact centre" | As a plan: one set of categories and clocks, a shared log, joint case reviews, and learning the contact-centre side from its people. If they ask about your own contact-centre experience: "I haven't worked in a contact centre." | The JD's end-to-end line across both channels (F1 and F2); the panel may test the seam from the branch side |
| G2 | "App-only banks don't have branches. Why should a member put up with a branch complaints process at all?" | CO | [grounded] | Hold: a branch is a choice members value. Answer with Ashgrove's own words ("Neighbours, Not Numbers", "every branch is part of its town"), then concede specifically that digital has to be as good as the branch, which is why complaints feed the self-service journeys. Don't trash app-only banks | The brief names app-only banks as the main pressure; a Pressure-style CO probe |

### Values cheat sheet (Round 3 scores against these)

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide by what's right for the member, not what's easy for the branch | Selection scaffold: a decision made for the customer, with a named cost and an outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, such as F1's "I handled the branch's formal complaints log", or how you would handle it |
| Plain Words | If it needs explaining twice, rewrite it | F4: "trained new tellers on our escalation script". Answer slot: if you changed how you explained it so it landed, that's the story; if not, say so plainly and choose another moment |
| Neighbours, Not Numbers | Each branch belongs to its town, and members are people, not case numbers | Selection scaffold: a specific person and a local detail that changed what you did. If no such time comes to mind, say so plainly, then say how you would apply it as branches become hubs |
| Own the Fix | Whoever finds a problem keeps hold of it until it's solved | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it started as a problem you found, tell that; if it was a request, say so plainly and choose another example |

### Graded deliverable: the 20-minute complaint-escalation case

**What's declared:** "a 20-minute case on a complaint escalation", from the recruiter. The content isn't known, so build a structure you can carry into any version.

**Grounded facts to build on**
- **Ashgrove's own words:** "Own the member complaints process end to end across branches and the contact centre" and "coach branch supervisors on escalations" (JD); the four values by name; hubs, the 40% digital target, and app-only bank pressure (brief).
- **You, at your own scope:**
  - F1: "I handled the branch's formal complaints log"
  - F4: "trained new tellers on our escalation script"
  - F3: "I built the monthly complaints spreadsheet our regional manager uses."

  Use these only for what they say, for example "when I handled the branch's formal complaints log…".

**A 20-minute shape**

| Time | What you do |
|---|---|
| 2 min | Clarify: what happened, what's been promised already, what channel it came through, whether it's a repeat, whether the member may be vulnerable, and which rules and deadlines apply. Ask rather than assume Ashgrove's specific rules |
| 3 min | The member now: acknowledge, contain, and name one owner |
| 5 min | Resolve: options, the decision, and plain-words communication of the outcome |
| 4 min | Root cause: one-off or pattern? Check the log before you call it a trend |
| 3 min | Coach and report: what the supervisor learns, and what goes in the monthly report or to the digital team |
| 3 min | Buffer for their challenges |

**Theses to choose from, each with its concession**

1. **"Fix it for the member first, then fix the cause."** (Members First, Own the Fix)
   - Concession: formal regulated steps and deadlines run in parallel, not after. You'd confirm Ashgrove's rules rather than guess them.
2. **"One named owner from first contact to close."** (Own the Fix)
   - Concession: a single owner needs cover and a clean handover, or the complaint stalls when they're away.
3. **"Every escalation is a coaching moment and a data point."** (F4's requirement, F3's requirement)
   - Concession: one complaint is not a trend, so you'd check the log before changing a process.

**Differentiation**
- **The consensus answer** is a generic "apologise, listen, resolve" routine.
- **Diverge:** use Ashgrove's values by name and say "members". If the case allows, link the fix to the hub move or a self-service journey, and end with what changes so the complaint doesn't recur.

**Anti-picks**
- Don't invent compensation amounts, timescales or regulatory outcomes the case doesn't give you.
- Don't blame front-line staff. "Own the Fix" means whoever finds the problem keeps hold of it.

**Close:** no close was named. A strong one is three lines: what the member hears, what changes, and how you'll know it worked.

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could the new lead do in the first month that would genuinely help your branches?" | Reciprocity; it shows you see them as partners, not as people to be coached around |
| "When an escalation goes well in your branch today, what does that look like?" | It lets you build on what already works instead of arriving with a script |
| "What do members in your towns complain about that a head-office view might miss?" | It puts "Neighbours, Not Numbers" into practice in the room |
| "Which of the four values is hardest to live on a busy day in branch?" | It's a values-round question that invites honesty and shows you've thought past the slogans |
| "As branches move into hubs, how are your teams thinking about complaints during the change?" | It shows you've read the strategy and care about its effect on their teams. Ask it gently, and as a question, not a prediction |

---

## Prohibited claims: what this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation: one branch's log, not a multi-branch process |
| Wrote or designed the escalation script | Inflated form of F4 ("our escalation script") | "I trained new tellers on our escalation script." |
| Has coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its scope. The B6 answer slot stays inside how the teller training was run |
| Produces the regional complaints report, or reports to senior management | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." How it is used beyond that is the regional manager's to describe |
| Six years in complaints | Inflated form of F6 | "Six years in retail banking, the last three as a branch supervisor." |
| Contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." |

---

## Sources

**Provided documents**
- The JD, pasted.
- Ashgrove's values, which you copied on 26 November 2026 from ashgrovecu.org/about/values. Pasted, not fetched.
- The recruiter's email describing the three rounds.
- Your summary of the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent you.
- Your background, as written in your message.

**Searches and fetches sent:** none. No dossier was consumed.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted this morning fixes the cheat sheet and C4–C7 |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email establishes all three rounds, the case and the values scoring, so it fixes the persona weights and the loop structure |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief is under six months old and supplies the priorities behind D1, D4, D5 and G2 |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. The interviewer read is absent, and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Panel and manager names:** an interviewer read for each person, personas assigned per panel member, and a reverse question tied to each one's career path.
- **Your answers to the answer slots in F1, F3, F4, F5, F7, F8 and F9:** those rows' bridges become story-mapped, and the guidance for B1, B3, B5, B6, C3, C5, C7 and E1 stops being conditional.
- **A redacted copy or screenshot of the monthly complaints spreadsheet's layout, with no member or customer data:** F3 and F9 can move from medium to high confidence, and E1 gets specifics you can stand behind.
- **Your CV:** more of your history quoted, so more VAL rows get mapped stories instead of selection scaffolds.
- **How much prep time you have before 5 December:** a prioritised prep schedule fitted to that time.
- **Whether the case is sent in advance, and whether it's a discussion or a presentation (one email to the recruiter):** the case build can be fitted to the real format.
- **The full strategy brief, not just your summary:** sharper vocabulary and numbers in the grounding brief and in D1, D4 and D5.
- **A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes:** Ashgrove news and organisational context since July, any published complaints information, and candidate reports on its interviews, making the CO questions more current.
- **A `tuesday-dossier.md` from an evaluation of this role:** evidence-graded rows and a prohibited-claims list from that evaluation, in place of the ones built locally here.
