Web search was refused, so I'm building the pack from your notes only. I'll record the refused searches in its Sources section.
I've built Priya's prep pack for the hour with Dan, but only from your notes. The three web searches were refused in this session, so nothing in it has been checked against outside sources. That includes Compass, Northwind's three priorities and Dan's profile.

It's saved as `/var/tmp/tuesday-measure/1a6/runs/opus/alone/part-2/rooms/case-1-denied-c4302635/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

- **Questions:** 21, in seven tables, one per interviewer style. Each row has the question, its type, the line from your notes it relies on, answer guidance, and why it's included and categorized that way. Most of them come from Dan as a peer and as someone who will check every number.
- **Highest-priority prep:** question C1, the objection Dan is best placed to raise: no quota-setting experience and a consumer-tech background, put to her by the person who owns sales strategy. It has scripted follow-ups and exact wording for what to concede.
- **The $400M figure:** three questions test it. The guidance keeps her to your notes' wording: she *proposed* the change, and it was *credited with* about $400M. Where only Priya knows how it was counted or what her part was, the guidance leaves her to answer from her own experience rather than supplying a method.
- **Claims to avoid:** a table of what the pack won't coach, such as calling the volume targets quotas or saying she negotiated the carrier deals.

There's no values section: no values round was named, and Northwind's published values couldn't be looked up. The pack ends with a list of what would strengthen it, starting with turning on search.

If you'd like, I can play Dan and run Priya through C1 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep found, to carry into later sessions.
If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. He would be a **peer**: both roles report to the same VP. **Format:** a single 60-minute conversation.

---

## How to use this pack

Each question has two labels. **Personas** describe how a question is asked: the register, the pressure, who is asking. **Types** describe what the answer is scored on. Dan is one person, but in one hour he will switch between several personas. The banks are sorted by how likely each persona is for him.

| Type | What it scores |
|---|---|
| VAL | Behavioral or values fit. Do past actions show the values being asked about? |
| EXP | Experience deep-dive. Do the claims hold up, and what was actually hers? |
| JD | Role fit. Can she do the job as listed, including the gaps? |
| CO | Company knowledge. Can she think at Northwind's level about its strategy and competition? |
| CASE | Live problem. How she structures and reasons through a problem from the actual role |

The guidance is scaffolding, not a script. Each guidance cell names the beats and leaves an **answer slot** wherever only Priya knows the answer. An answer slot gives two honest branches: answer it from her own experience, or say plainly that the thing didn't happen or wasn't hers. Both branches are good answers. An answer she invents is not.

Provenance labels, used in every table: **[grounded]** traces to your notes; **[inferred]** is this pack's own derivation, which is named; **[generic]** is a role-family pattern with no claim about Northwind or Priya.

In 60 minutes Dan will probably ask 8–12 of the 21 questions below. A rehearsed answer to the top three to five matters more than a light pass over all 21.

---

## Fit snapshot

The requirements are quoted from your JD highlights. Evidence is quoted from your notes on Priya. Her CV wasn't supplied, so every evidence cell is in your words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your note | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows product strategy and ops, plus one proposed change. It does not show GTM ownership of a product line, so the words stay at that scope: "Nine years in product strategy and ops at a large consumer-tech company. I proposed a store-surface change that was credited with a roughly $400M ARR uplift." Answer slot: the "own GTM strategy" line makes a probe on go-to-market decisions likely (who to sell to, how to package or price, which channel). If any such decision was hers to make or recommend, she says which one and how she decided, in her own words. If none was, she says so plainly and stays with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your note | none given | none | [grounded] | discovery | The material doesn't show whitespace analysis across the customer lifecycle. Answer slot: if she has sized an untapped segment, or an expansion or retention opportunity inside an existing user or partner base, she says what she sized, how, and what happened next. If she hasn't, she says so plainly, then explains how she would build the land/adopt/expand/renew view at Northwind (see D3) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your note | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap. But it's a one-line claim with nothing inspected behind it, and Dan is "relentlessly data-driven," so expect him to probe it. She names the tools in the quote's own terms. Answer slot: the word "independent" makes an end-to-end walkthrough likely. If a specific analysis she built herself fed a decision, she names it and walks through it. If her SQL and Tableau work sat elsewhere, she says so and picks the analysis she knows best |
| F4 | "partner-motion design experience required" — JD highlights, your note | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material shows a revenue model, at partner level, used in carrier negotiations. It doesn't show the design of a partner motion. Words at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "partner-motion design … required" line makes a probe on the partnership structure likely (terms, incentives, tiers, how partners were engaged). If she shaped or recommended any part of how the carrier arrangement was structured, she says which part and how the model informed it. If the model's job ended at informing the negotiators, she says so plainly and stays with what the model showed |
| F5 | "strong cross-functional influence" — JD highlights, your note | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement, in different words. Reworded only: "I set the annual volume targets, with consensus across orgs." Volume targets stay volume targets. They are not quotas (see F7) |
| F6 | "AI experience a plus" — JD highlights, your note | "uses AI tools daily" — the coach's notes | medium | [grounded] | discovery | Daily use of AI tools touches the requirement but doesn't show whether it reaches AI product or GTM experience. Words: "I use AI tools daily." Answer slot: if that use changed how she does analysis or strategy work, she says what changed and how. If it's personal productivity, she says so plainly and turns to what she'd want to learn about Compass's buyers |
| F7 | B2B sales-motion fluency. Not in the JD; inferred from the interviewer's lane, "Director of Sales Strategy" (your note) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [inferred] | capability | A gap that wording can't close, and one already stated. Words: "I haven't done classic sales ops or set quotas." Then a plan for how she'd learn Northwind's motion, said as a plan and never as past experience. Nothing gets added to make the gap feel smaller, and the volume targets in F5 are never offered as quota-setting |
| F8 | Context: "B2B data-infrastructure SaaS" (your note on the company) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material shows consulting and consumer tech, and says nothing about selling to businesses. Answer slot: if a consulting engagement or the partner-level work had business buyers, she names which. If not, she says so plainly and stays with what carries over: the partner-level model and the cross-org targets |

**Reading the snapshot:** F7 and F8 together produce the objection Dan is best placed to raise: no quota experience, a consumer background, interviewed by the person who owns sales strategy. That objection is C1, and it is **the highest-ROI rehearsal in this pack.**

---

## Reading the interviewer

Public-footprint research couldn't run (the searches were refused; see Sources), so this section rests only on what your note says about Dan.

| Signal | Implication for Priya | Provenance |
|---|---|---|
| Self-described "relentlessly data-driven" | Every number she offers will be probed for its denominator, its method and its weakest assumption. The $400M figure (A1, A2, E1) is the obvious target. "I don't know how that was counted" is a safer answer than a reconstructed method | [grounded] |
| "Career spine is pricing and monetization roles" | Case questions will tilt toward pricing, packaging and unit economics. Compass pricing (D1) is native territory for him, so she should expect him to know more than she does there and say so where it's true | [grounded] |
| "One early-stage-startup chapter" | Builder stories tend to land with someone like this. Expect a probe on whether she can move at emerging-product pace after nine years at a large company (C3) | [inferred] |
| Peer, same VP, Director of Sales Strategy | He is weighing whether she adds to or reduces his team's load, and where the line falls between her emerging-products GTM and his sales strategy (B1, B3). Coverage, quota and comp mechanics probably sit near his remit; that's an inference, so she should ask rather than assert | [inferred] |
| Shared vocabulary | Revenue modelling is his language and appears in her material: "built a partner-level revenue model used in carrier negotiations" (F4). This is shared vocabulary, not a shared career jump, so she doesn't present it as one | [grounded] |

---

## Persona table

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | "How was that counted?" followed by two more levels of "and how do you know?" | **High (5 questions).** The peer prior already puts the Prober in the top two, and his "relentlessly data-driven" self-description raises it further | For each number, know what she can and can't say about how it was counted. Name the assumption she'd defend least before he does. Offer to walk through an analysis she built herself |
| Peer Evaluator | "Where's the seam between us? What do you need from my team?" | **High (4).** The peer relationship makes this a dominant persona, and the shared VP makes the seam question nearly certain | Frame it as reciprocity. Propose principles for the seam rather than pretending to know where it is. Ask him how it works today |
| Skeptic | A quiet "I don't see sales ops in your background" | **Mid (3).** The F7 and F8 gaps sit right in his lane, so the objection will come, probably in collegial packaging | Rehearse C1 until it's boring. Acknowledge first, then the material at its own scope, then a ramp plan |
| Case / Strategist | "How would you price Compass?" "How should we respond to the bundle?" | **Mid (3).** Not a dominant persona for a peer round, but his pricing background tilts live problems toward monetization, and your research note gives him the topics | Clarify, set the objective, segment, propose an approach, name metrics and risks. Challenge one premise respectfully |
| Pressure | "How much of that was actually you?" | **Low (2).** Nothing in the peer prior or his signals points to a stress style, but attribution probes come naturally from a data-first interviewer | Pause and restate the question. Hold what the quote carries through two follow-ups, then concede the specific thing that's true |
| Conversational | "So, walk me through your journey." | **Low (2).** He'll almost certainly open this way, and it's still scored | A pre-built 90-second arc. Treat casual AI questions as scored, because the JD lists AI as a plus |
| Values / Behavioral | "Tell me about a time you…" | **Low (2).** No values round was named, and Northwind's values couldn't be fetched | Selection scaffolds, each with an honest branch |

---

## Question banks

### A. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR uplift on the store-surface change: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's three exact words: she *proposed* the change, the change was *credited* with the uplift, and the figure is *approximate* ("~"). None of those gets upgraded. Answer slot, how it was counted: if she knows the method, she gives it in her own words. If another team measured it, she says who and that she didn't build the count. "I don't know exactly how it was counted" is an honest branch, and she doesn't reconstruct a method. Answer slot, her part: if she did anything after proposing it (built the case, tested, implemented), she says which, and if not, she stays with "I proposed it" | This is her headline metric, and Dan is both data-driven and from monetization, so it's the likeliest probe target in the pack. EXP because it tests attribution and counting. "Credited with" is exactly where an interviewer asks "by whom?" |
| A2 | "What's that figure most sensitive to, and which assumption behind it would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move. Answer slot: if she knows what the figure depends on, she names the one assumption she'd defend least, in her own words, before he finds it. If she doesn't know the assumptions, she says plainly that she didn't build the attribution, says what she does know about the change itself, and offers what she'd want to see to trust the number. The pack doesn't supply an assumption or a baseline | This is Dan's second level of follow-up on A1, rehearsed separately because it's the level that breaks unprepared answers. EXP because it scores whether she knows the limits of her own claim |
| A3 | "Tell me about the partner-level revenue model. What went into it, and how did the negotiators use it?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4. The beats the quote states: she built it, it was at partner level, and it was used in carrier negotiations. Answer slot, inputs: she describes the model's structure and inputs in her own words. If revenue per partner or unit economics were in it, she says so, and if not, she doesn't add them. Answer slot, use: if she was in the negotiations or briefed the negotiators, she says which. If her part ended when she handed the model over, she says that plainly | F4 is her closest evidence for the one requirement the JD marks "required", and modelling is Dan's own language. EXP because the probe targets what the model did and what was hers. "Used in" is where attribution drifts toward "negotiated" |
| A4 | "Pick one analysis you built yourself, end to end, in SQL and Tableau, and walk me through it: the question, the data, and the call it informed." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick an analysis she personally queried and visualized, with a clear question and a decision someone made from it. Walk the question, the data sources, one join or cleaning problem, the view she built, and what changed because of it. If the analysis she knows best wasn't one she built alone, she says who did what. If no single analysis fits, she says so plainly and walks through how she'd build the whitespace view in D3 | The JD says "independent analysis," and Dan will check it directly. JD content with EXP delivery. Tagged JD because the requirement is the thing being scored |
| A5 | "How did you arrive at the annual volume targets? What was the method, and how did you know they were right?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: she set them, they were annual, and they had cross-org consensus. Answer slot, method: she says how she built them, in her own words. If they were built from someone else's forecast, she says so. Answer slot, "right": if she knows how actuals compared to target, she says so, and if not, she says she doesn't know. Never call these quotas. If Dan asks whether they're the same thing, she gives the F7 acknowledgment and lets him draw the comparison | The nearest thing in her material to his quota world, so he'll test it twice: how she built them, and whether they map to quotas. EXP because it probes method and outcome |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your role and mine would sit side by side under the same VP. Where's the seam between emerging-products GTM and sales strategy, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, not a map of it. One principle: the new product lines' GTM thesis (target segments, motion, partner role) sits with this role, and the mechanics of the core sales machine sit with his team. Say that as a hypothesis and ask him how it works today. On disagreement: settle it on data first, with a shared dataset rather than dueling spreadsheets. If they still disagree, go to the VP together with one framed choice, rarely. No claim about her past is needed here | A peer with the same VP will almost certainly test turf awareness. JD because it scores "strong cross-functional influence," with CASE delivery. [generic] because nothing public describes how Northwind splits these roles |
| B2 | "Tell me about a time you got a number agreed across orgs that didn't all want the same thing." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, which she set, and the cross-org consensus. Answer slot: the JD's cross-functional influence line makes a probe on the disagreement likely. If the orgs wanted different numbers, she says which wanted what, what she did, and how consensus formed, in her own words. If there wasn't real disagreement, she says so plainly and stays with how she set the targets | F5 is the best evidence for the influence requirement. Dan is a likely future counterparty in exactly this kind of negotiation. JD primary, EXP secondary |
| B3 | "New product lines need sellers' time, and that's capacity my team plans around. How would you get them into the sales motion without wrecking the core number?" | CASE | [generic] | Clarify first: who sells today, how reps are paid on new products, and what's sacred in the core plan. Options: a specialist overlay for the first year, a pilot cohort of core reps with protected targets, or partner-led for some segments (this links to F4). Measure attach rate, cycle time and impact on core productivity. Close by giving him the comp mechanics: "I'd want your team's view on the incentive design; that's your craft, not mine." No claim about her past | A pressure point between the two roles, and it gives her room to concede the F7 gap gracefully instead of defensively. CASE because it's a live problem from the role |
| B4 | "What would you need from my team in your first 90 days, and what would you give us back?" | JD | [grounded] "skilled in SQL/Tableau" | Needs: access to pipeline and bookings data, the current segmentation and territory logic, and the pricing history. Gives back: whitespace analysis on the new lines shared with his team, and one common dataset or dashboard both teams use. Her own part rests on the quote: SQL and Tableau, so she doesn't need analyst capacity from him. No further claims | The reciprocity question a peer asks to find out whether she adds to his load or takes from it. JD because it scores influence and independent analysis |

### C. Skeptic (weight: mid; contains the highest-ROI rehearsal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't done classic sales ops or quota setting, and your background is consumer tech. Why should I believe you can build land-and-expand GTM for enterprise data infrastructure?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | **The highest-ROI prep in this pack.** (1) Acknowledge first, with no defensiveness: "That's right. I haven't done classic sales ops or set quotas, and my nine years were in consumer tech." (2) What carries over, at its own scope, as plain facts: "I built a partner-level revenue model that was used in carrier negotiations, and I set annual volume targets with consensus across orgs." Let him draw the inference. (3) Position the role, not herself: the JD asks for GTM strategy and whitespace analysis, and she'd partner with his team on quota mechanics rather than claim them. (4) Ramp plan, said as a plan: shadow deal reviews, read win/loss notes, and pull bookings by lifecycle stage herself in the first month. **Follow-up 1** ("But GTM is the sales motion"): hold. She isn't claiming the quota craft; the segmentation, modelling and target-setting she has done are what she'd build on. **Follow-up 2** ("Name one B2B thing you've done"): answer slot from F8. If a consulting engagement or the partner work had business buyers, she names it. If not, she says plainly "not as a seller" and returns to the model. **Concede specifically:** "Where I'll be slowest is quota and comp mechanics." Never offer the volume targets as quotas | F7 and F8 sit in Dan's own lane, so this objection will come in some form. It gets the most follow-up levels, the exact concession wording, and the limit stated before he asks. JD because it scores the role's core requirements |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience." | Pick a real one, not a humble-brag. The likely honest pick is partner-motion design: "The JD says partner-motion design is required. What I've done is build a partner-level revenue model that was used in carrier negotiations." Then how she'd close it: study Northwind's existing partner tiers and economics in the first 30 days. If he pushes on sales ops, give the F7 words. Answer slot: if a different requirement honestly feels weakest to her, she names that one instead, in her own words | A standard Skeptic question, but with this JD the honest answer points at a *required* item. Rehearsed so she can name it calmly. JD because it scores self-assessment against the listed role |
| C3 | "Why leave a large consumer-tech company, after nine years, for emerging products at a 3,000-person B2B company? Why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Context from the quote: nine years at a large consumer-tech company. Answer slot: she gives her actual reasons, in her own words. The pack has none from her and supplies none. Expect a follow-up from his startup chapter about pace. Answer slot: if she has worked on something small or fast-moving inside the big company, she names it; if not, she says so and says what she expects to change in how she works | Motivation consistency is the Skeptic's core test, and the startup signal makes the pace probe likely. EXP because it tests her own story |

### D. Case / Strategist (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass is our AI copilot. How would you price and package it: standalone SKU, add-on, or bundled into existing tiers?" | CASE | [grounded] | Clarify: who buys and who uses, what each query costs Northwind to serve, and the current tier structure. Objective: profitability is a stated priority, so margin matters as much as adoption. Options: bundle into the top tier to drive upgrades; a paid add-on per seat or per usage; or included with a usage cap that pushes expansion. Name the bundling threat: the larger vendor can give AI away, so Northwind shouldn't try to win on free. Metrics: attach rate, expansion ARR, gross margin per account, net revenue retention. Challenge one premise: maybe Compass is a retention tool first. Admit where he knows more: "You've lived pricing, so I'd want to pressure-test this with you" | Grounded in your research note (Compass, profitability, the bundling threat), and squarely in Dan's pricing lane. CASE primary, CO secondary. It's the differentiator question in this pack |
| D2 | "A much bigger platform vendor bundles a good-enough version of what we sell. How should GTM for our new lines respond?" | CO | [grounded] | Segment where the bundle is good enough and where depth matters, and defend the second. For renewals: score renewal risk where the bundle overlaps and get ahead of it. For land: go after use cases the bundle can't reach. For partners: where the platform's own ecosystem matters, a partner motion can turn a threat into a channel. That's a hypothesis, labelled as one. On price: compete on value, not on matching free. Metrics: win rate against the bundled competitor, and churn reasons tagged to the bundle | Your note names bundling as the main threat, so a strategy-fluent peer will likely raise it. CO because it scores whether she can think at Northwind's level, with CASE delivery |
| D3 | "Sketch how you'd find whitespace for one of the new product lines across land, adopt, expand and renew. What data would you pull first?" | CASE | [grounded] | Clarify the product and who it's for. Frame: a matrix of the installed base against adoption of each product. Data first: an accounts table joined to product usage and opportunity history (SQL), then a propensity view using firmographics, current spend and depth of use (Tableau). Validate with a few sellers, size each cell, and prioritize by size times likelihood. Each motion gets its own metric: land is new logos in the ICP, adopt is activation, expand is attach and seats, renew is gross retention. All of this is a plan, not a claim about her past | The JD's whitespace line (F2) has no evidence behind it, so a live case is where she can show the skill. CASE with JD content |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause. Hold what the quote carries: "I proposed the change, and it was credited with roughly $400M in ARR uplift." Hold it through two follow-ups without growing it or shrinking it. Then concede specifically. Answer slot: if other people built, tested or shipped the change, she says so and names her part. If she doesn't know how the credit was assigned, she says that. Never "I drove $400M" | The attribution stem is the most likely Pressure moment from a data-first interviewer. EXP because it scores honesty about attribution. It's rehearsed separately from A1 because the register differs: challenge, not curiosity |
| E2 | "Sixty seconds: why you over an internal candidate who already knows our sales motion?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Concede first: an insider knows the motion, and she hasn't done classic sales ops. Then what carries over: the partner-level revenue model used in carrier negotiations (the JD requires partner-motion experience), and SQL and Tableau for independent analysis. Then an outside view of a bundling threat, offered as a perspective, not a claim. Stop at 60 seconds | Time-boxing is the Pressure persona's main tool, and the internal-candidate comparison sharpens F7. JD because it scores fit against the role |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc: two years of consulting, then nine in product strategy and ops, with three markers given at the quotes' own scope (the model, the targets, the proposed change). Close on why this role. Answer slot: that closing reason is hers, in her own words | Nearly certain as an opener, and it sets the frame for everything after. EXP because it tells the CV story. It's scored even though it feels casual |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | "I use AI tools daily." Answer slot: she names the tools and what she uses them for. If any of that changed how she does analysis, she says how, and if it's personal productivity, she says that. Then she turns it to Northwind with a question back: how do Compass's early users actually use it? | The JD lists AI as a plus, and Compass is a stated priority, so this casual question is scored. JD because it tests a listed plus |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Selection scaffold: a named stake, a moment she didn't back down, the truth actually landing, and the relationship intact afterwards. One place to check is the store-surface change she proposed. If it met resistance before it was adopted, it may fit. If it didn't, she doesn't force it. If no such time comes to mind, she says so plainly and gives the nearest thing her material does carry, or how she would handle it | A common behavioral stem. A peer uses it to test whether she'll push back on a shared VP. VAL, [generic] in theme, because Northwind's published values couldn't be fetched |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a real metric she gave up, a customer reason, and what happened to the metric afterwards. With a data-first interviewer, the story is stronger if she can say what the tradeoff cost in numbers she actually knows. If no such time comes to mind, she says so plainly and says how she'd weigh that tradeoff | It tests judgment beyond the numbers, which matters to a data-driven peer. VAL, [generic] because no published values were in hand |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines (F1) | C1, D1, D2, F1 |
| Whitespace across land/adopt/expand/renew (F2) | D3, A4 |
| Independent analysis in SQL and Tableau (F3) | A4, B4, D3 |
| Partner-motion design, required (F4) | A3, C2, E2 |
| Strong cross-functional influence (F5) | B1, B2, B3, A5 |
| AI experience a plus (F6) | F2, D1 |
| Interviewer's lane: sales motion and quota (F7, inferred) | C1, B3, A5, E2 |

---

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "You've spent most of your career in pricing and monetization, with an early-stage startup in the middle. What from the startup chapter still applies inside a 3,000-person company?" | It's about his own path, which shows she prepared for him specifically, and it turns the pace question (C3) into a conversation |
| R2 | "What could someone in my seat do in the first month that would genuinely help your team?" | The peer reciprocity question. It signals she'll take load off his team, not add to it |
| R3 | "Where does sales strategy end and emerging-products GTM begin today, and where has that line caused friction?" | It surfaces the seam before it becomes a conflict, and his answer is real information about the job |
| R4 | "How is Compass expected to show up in the numbers your team tracks: new lands, expansion, or retention?" | It speaks his data language and connects a stated priority to his scorecard |
| R5 | "With profitability as a stated priority, how does the team decide when a new product line has earned more seller capacity?" | A real tension between growth and margin. His answer shows how decisions are made under the shared VP |
| R6 | "What data would I have to build myself versus inherit? What do pipeline and usage data look like today?" | It shows she plans to run her own analysis and tells her how much of the first 90 days goes into data plumbing |

---

## Prohibited claims

Claims this pack will not coach, whatever the follow-up.

| Not coached | Basis | Honest form |
|---|---|---|
| Has set sales quotas or run sales ops | A negative stated in the coach's notes, F7 | The plain acknowledgment: "I haven't done classic sales ops or set quotas." No slot |
| The volume targets were quotas | Inflated form of F5 (a different kind of work) | F5's quote at its own scope: annual volume targets, with cross-org consensus. The pack's own observation: the material says volume targets, not quotas |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1's second quote | "I proposed a store-surface change that was credited with a roughly $400M ARR uplift." A1 and E1 keep the slots inside what she proposed |
| Negotiated carrier deals | Inflated form of F4 | "I built a partner-level revenue model that was used in carrier negotiations." A3's slot asks only whether she was in the room or briefed the negotiators |
| Designed a partner program or partner motion | Inflated form of F4 | F4's quote at its own scope. The pack's own observation: the material says a model, not a motion design |
| Owned GTM for a product line | Inflated form of F1 | F1's quotes at their own scope: product strategy and ops, and a proposed change |
| Built or launched AI products | Inflated form of F6 | "I use AI tools daily." F2's slot stays with how she uses them |

---

## Sources

**Provided material:** your notes on the role and JD highlights, on Priya's background, on Dan Kovac's profile, and your research note on Northwind's priorities and competitive threat. No dossier was supplied.

**Searches sent:**
- "Northwind Data company values": refused (no search permission in this session)
- "Northwind Data Compass AI copilot launch" (a check that your research note is current): refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The call was refused. It would have themed G1 and G2 on Northwind's published values. No values cheat sheet either way, because no values round was named for this session |
| 2. Northwind Data interview process, GTM strategy | skipped | Your note already fixes the one session: a single 60-minute conversation with Dan, a peer |
| 3. Northwind Data strategy and recent news | unavailable | The call was refused. It was a check of your research note. D1, D2 and R4–R5 rest on the note without that check: Compass, the three priorities and the bundling threat are unverified |
| 4. Dan Kovac, Northwind Data | unavailable | The call was refused. It would have checked and extended his profile, and maybe surfaced talks or posts as question themes. The interviewer read rests on your note alone |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied are Northwind's own and fix the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- **Allow web search for this session** → targets 1, 3 and 4 run. G1 and G2 get themed on Northwind's published values, Compass and the priorities get a freshness check, and the interviewer read gets checked against Dan's public footprint
- **Deeper research pass (L2)**: up to 6 more searches and 2 more fetches, several more minutes, and it also needs search permission → a strategy brief (financial trajectory, competitive set), Dan's talks or writing as question themes, and recent org context on what this role is for
- **Full JD text** → covers mid-list requirements the highlights may have left out. Each new requirement gets a fit-snapshot row and a JD question
- **Priya's CV** → evidence quoted from her own lines instead of your summary, and more story maps where the snapshot now uses selection scaffolds (A4, G1, G2)
- **Priya's answers to the answer slots, outside a drill** → especially how the $400M was counted and what her part was (upgrades A1, A2, E1), whether she shaped the carrier arrangement (upgrades F4, A3, C2), and any B2B or business-buyer work (upgrades F8, C1 follow-up 2)
- **Recruiter guidance** (focus areas, anything to prepare) → reweights the banks and adds a build section for any pre-declared deliverable
- **Prep time available** → a prioritized prep schedule sized to it
- **A tuesday-dossier.md** → evidence-graded confidence for each claim, an objection derived from evidence rather than inferred, and a prohibited-claims list confirmed with Priya rather than built here
