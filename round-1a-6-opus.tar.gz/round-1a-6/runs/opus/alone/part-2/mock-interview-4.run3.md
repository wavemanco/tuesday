Reading the skill's research checklist and evidence rules next, then I'll write the pack.
Writing done; fixing an ID clash (reverse questions reused R1–R6, which are already requirement IDs), then presenting.
I've saved your prep pack as `Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for one 45-minute conversation with the hiring manager, and it uses your dossier as both the job description and your CV.

- **Most important: B1.** This is the objection your dossier said was most likely: you haven't held the PM title or owned a roadmap. The pack scripts your answer. Admit it plainly first. Then describe your three verified pieces of work in their own words. Then give a plan for getting up to speed. It also covers three follow-ups, including what you can't say, like "basically a PM".
- **Your dossier's limits apply everywhere.** No guidance claims or hints that you held the PM title, owned a roadmap or set priorities for a squad. I also kept two exaggerated versions out of your answers:
  - that you shipped API products, when your evidence says you integrated clients onto the vendor's APIs;
  - that your roadmap-input sessions shaped the roadmap, when they fed client evidence to product.
- **One line from the dossier isn't usable.** Its summary says "seven years of integration leadership", but none of your verified evidence states that. So the pack doesn't say it for you. Where years come up, it tells you to give your actual years and call them integration work.
- **There's no company research in the pack.** My three searches (Quartzline's values, interview process and recent news) were blocked by permissions. So the company-knowledge question (A5) and the values questions are general, not specific to Quartzline.
- **Which Thursday:** today is Thursday, November 26, so I assumed you mean December 3. If the interview is today, rehearse B1 out loud, then B2, then the reverse questions Q1 and Q2.

The pack has 23 questions across seven interviewer styles, six questions for you to ask, and the full list of claims you shouldn't make. Its last section lists what would make it stronger, starting with letting me search.

If you want to practise, I'll play the sceptical interviewer on B1, with live follow-ups.
I can also add a section to your `tuesday-dossier.md` recording the gaps this prep turned up, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview Prep Pack — Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Interviewer name not given.
**Built on:** your underwriting dossier (v1.1, dated 2026-08-14) — its role profile stands in for the JD and its verified evidence stands in for your CV.

---

## How to use this pack

Two axes. **Personas** describe how a question will arrive: who is asking and in what register. **Types** describe what is being scored:

| Tag | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's values |
| EXP | Whether your stated experience survives close questioning, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy homework |
| CASE | Live reasoning on a problem from the role |

Provenance labels: `[grounded]` traces to your dossier or something you said; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about Quartzline or about you.

An **answer slot** is an instruction for the interview, not a question for you now: it names what the interviewer may probe and gives you two honest branches — if you did it, say how in your own words; if it wasn't a thing, or wasn't yours, say so plainly.

Guidance is scaffolding, not a script. Every sentence about your past in this pack is one of three sentences from your dossier's verified evidence, a plain acknowledgment the dossier records, or a slot for your own words.

**Highest-ROI prep in this pack: B1.** Your underwriting named it as the objection most likely to come; rehearse it until it is boring.

---

## Fit snapshot

Requirements are quoted from the dossier's role profile. Evidence is quoted from the dossier's verified evidence, exactly; its confidence notes went into the Confidence column and the bridge, not into the quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | low | [inferred] | transferability | The dossier's strategy is bridge, positioned as adjacent and never as PM experience. Words: "I haven't held a product manager title" (dossier prohibited_claims: "Having held a product manager title or role"), then the integrations at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Let the interviewer draw the inference; never call it PM work. Answer slot: R1 makes a probe on years likely. Give your actual years in integration work, in your own words, and name it as integration work |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role profile; dossier R1 sub-claim "Owning a roadmap and prioritization authority" | none given | none | [grounded] | capability | The dossier records this as acknowledge_gap: no bridge and no slot. Words: "I haven't owned a product roadmap" (dossier prohibited_claims: "Having owned a product roadmap"). Then a ramp plan, said as a plan and never as a past — what you would learn first, from whom, and by when |
| F3 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | high | [grounded] | transferability | High as a claim about the integrations (the dossier notes the playbook was provided for inspection). Your material shows integrations of the vendor's APIs, not shipping the API product, and the words stay there. Answer slot: R2 makes a probe on shipping likely. If any change to the API itself came out of an integration you led, say what it was and which part was yours, in your own words; if none did, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence | low | [inferred] | discovery | The quote touches REST APIs and architecture but does not show docs or schemas. Answer slot: if reading or writing API docs or schemas was part of that scoping or architecture work, say which and how, in your own words; if it wasn't, say so plainly and say what you did work from |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important (customers and product side) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | medium | [grounded] | none | The client side is in the quotes' own terms. The second quote is confirmed with limited inspectable proof, so expect a probe on it and volunteer what you can and cannot show before you're asked |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier R4, important (engineering and sales side) | none given | none | [grounded] | discovery | Your material does not show work with engineering or sales teams. Answer slot: if you worked with engineering or sales on those integrations, say how, in your own words; if you didn't, say so plainly and stay with clients and product |
| F7 | "Agile delivery experience" — dossier R5, preferred (dossier area: "Agile delivery inside a product org") | none given | low | [grounded] | discovery | The dossier's strategy is clarify. Answer slot: R5 makes a probe on agile delivery likely. If you worked in agile delivery, say how, in your own words; if you never worked that way, say so plainly. Either way: "Here's what I'd want to confirm about how your squads define it" |
| F8 | "Run discovery with integration partners" — dossier role profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence | medium | [inferred] | transferability | Scoping and requirements for an integration are not product discovery, and the bridge should not be stretched. Answer slot: if your scoping went into partners' problems beyond the integration itself, say how, in your own words; if it didn't, say so plainly and stay with the scoping |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence; "Wrote the internal integration playbook her team uses" — dossier verified evidence | high | [inferred] | transferability | Requirements for integrations, and a playbook a team uses, at their own scope. Limit: "I haven't set prioritization for an engineering squad" (dossier prohibited_claims: "Having set prioritization for an engineering squad"). Answer slot: if requirements you wrote went to an engineering team to build from, say how that worked, in your own words; if they didn't, say so plainly |
| F10 | "Define and track adoption metrics" — dossier role profile | none given | none | [grounded] | discovery | Your material does not show adoption tracking. Answer slot: if you tracked anything about integration usage after go-live, say what, in your own words; if you didn't, say so plainly and say what you would measure first |

---

## Persona table

The loop for this session is established by your own words: one 45-minute conversation, with the hiring manager. No interviewer profile, so weights rest on the hiring-manager prior plus the dossier.

| Persona | How it shows up here | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on the partner API roadmap, adoption, squad trade-offs | High — the hiring-manager prior; the role profile's four responsibilities are all case material | Clarify, objective, options, metrics, risks; think aloud; say where you'd check your decision rights |
| Skeptic | The PM-title gap, roadmap ownership, "why now" | High — the hiring-manager prior, and the dossier named this objection | B1 until it's boring; concede plainly, hold only what your quotes carry, then a ramp plan |
| Data-Driven Prober | "30+ — how counted?", the playbook, the roadmap-input sessions | Medium — a 45-minute HM chat leaves less time for line-by-line depth, but the one figure in your evidence will draw it | Know how the figure was counted and say plainly what you don't know |
| Conversational | The opener, agile, "why APIs" | Medium — HM conversations usually open this way and the casual R5 question is still scored | A rehearsed 90-second arc built only on your three verified sentences |
| Pressure | A compressed version of B1; "how much was you" | Low — nothing points to a stress style, but the objection can arrive sharply | Pause, restate, hold through two follow-ups |
| Peer Evaluator | Squad-lead disagreement; cross-team stakeholders | Low — not a peer round, but the manager will test how you'd work with the two squad leads | Propose decision-rights principles; don't pretend to know the seam |
| Values / Behavioral | Generic behavioural prompts | Low — your words establish one conversation with no values segment; no values page could be read | Selection scaffolds with honest branches |

---

## Question banks

### A — Case / Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of our biggest partners want conflicting changes to the same endpoint, and both squads are full. How do you decide?" | CASE | [generic] | Clarify first: what each partner uses it for, what's committed, what usage data exists. State the objective. Lay out options — sequence, version, decline one, find a shape that serves both. Say aloud that you'd confirm which part of this call is yours and which belongs to the squad leads. Close with the metric you'd watch and the risk you'd accept. The question asks about no past, so the guidance makes none | The roadmap responsibility (F2) asked as a decision rather than a record — the safest ground for a gap you can't bridge; CASE because it scores structure |
| A2 | "How would you run discovery with integration partners in your first quarter?" | CASE | [generic] | A plan, not a history: who you'd talk to, what you'd ask (their goals, not just their tickets), how you'd record and share it, and what decision it would feed. If you reach for your past, use only F8's quotes at their scope | F8 is a transferability row; asking it forward lets you show method without stretching the bridge; CASE, JD content |
| A3 | "How would you measure partner API adoption — and what do you do in month one if there's no baseline?" | CASE | [generic] | Define a funnel from first access to steady production use, name the one number you'd report upward, and say which assumption in it you'd defend least before they ask. Month one: instrument and establish the baseline before setting targets. Ask how they measure it today | F10 is silent in your material and the dossier flags no stated baseline; CASE because the scored thing is reasoning on an open metric |
| A4 | "A partner's integration is stuck three weeks before their launch. Walk me through what you do." | CASE | [generic] | Triage: what's blocking, whose it is, what can move, who to tell and when. If you bring an example, use an integration you led and only what you actually did there, in your own words | The likeliest place for your strongest material to come up naturally; CASE, and the one row where your past fits the problem's shape |
| A5 | "What do you know about our partner API platform?" | CO | [generic] | This pack holds no researched facts about Quartzline — the searches were refused. Do your own homework from Quartzline's public material and say what you read and where. Don't guess at numbers or customers | Hiring managers test homework; CO, and `[generic]` because nothing here is entity-specific |

### B — Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier prohibited_claims: "Having held a product manager title or role"; dossier prohibited_claims: "Having owned a product roadmap"; dossier prohibited_claims: "Having set prioritization for an engineering squad" | **The highest-ROI rehearsal in this pack, named by your underwriting.** (1) Concede first, without hedging: "That's right — I haven't held a product manager title, and I haven't owned a product roadmap." (2) Hold, at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. And I ran quarterly roadmap-input sessions feeding client evidence to product." Stop there and let them draw the inference — don't say what it proves. (3) A ramp plan, as a plan: what you'd learn first about how roadmap decisions are made here, and from whom. **Follow-up 1** — "Those input sessions — you were shaping the roadmap, weren't you?" Hold: "I fed client evidence to product. I haven't owned a product roadmap." There's less you can show for the sessions than for the playbook; say so before they find it. **Follow-up 2** — "Have you decided what an engineering team builds next?" "I haven't set prioritization for an engineering squad." Return to the integrations. **Follow-up 3** — "So why take the risk?" Don't fold and don't inflate: one sentence of concession, one of what you did, one of plan; then concede plainly that roadmap ownership is real ramp for you. Never: "basically a PM", "PM in all but name", "product owner for integrations" | The dossier's named objection; every negative in it is sourced by a prohibited_claims item, so it is asked as written. F1 and F2 are the snapshot's two biggest gaps; JD because it scores R1 directly |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] dossier prohibited_claims: "Having owned a product roadmap" | Don't pick a safe fake weakness. Name the real one: "Owning the roadmap — I haven't owned a product roadmap." Then the ramp plan: how you'd learn the prioritization model, who you'd learn it from, what you'd want in place by month three | F2 is the dossier's acknowledge_gap area; a candid answer here defuses B1 if it comes later; JD |
| B3 | "Why move into product management now?" | EXP | [generic] | Answer slot: give your actual reason, in your own words. If you mention your current work, use only your verified sentences at their scope. Don't frame it as "I've been doing PM already" | Motivation consistency is the Skeptic's other lever; EXP because it tests your own account |
| B4 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Don't answer "yes". Give the integrations in the quote's terms. Answer slot: if any change to the API itself came out of an integration you led, say what it was and which part was yours, in your own words; if none did, say so plainly and stay with the integrations | F3 is a must-have with a transferability gap; the pull to say "yes, sort of" is strong, which is why it's rehearsed; JD |
| B5 | "What's the difference between leading an integration and owning a platform roadmap — and how would you close that gap?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier prohibited_claims: "Having owned a product roadmap" | Show you see the difference — one customer's outcome versus many partners' trade-offs over time — reasoning about the role, not your past. Then: "I've led integrations; I haven't owned a product roadmap." Close with how you'd close it | A thoughtful skeptic asks this instead of B1; naming the gap yourself reads as judgment; JD content, CASE delivery |

### C — Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations — how are you counting those, and which were yours end to end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The verb is "led" — hold it; don't trade up to "owned" or "built". Answer slot, in your own words: how the 30+ was counted, what would change it, the assumption behind it you'd defend least, and which part was yours. If you don't know exactly how it was counted, say so | The only figure in your evidence; defend-the-number EXP |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Two beats the quote states: you wrote it, and your team uses it. Describe what's in it in your own words. If it's shareable with nothing confidential in it, you could offer a redacted look. Don't widen "her team" into wider adoption | Your most inspectable item (the dossier notes it was provided); EXP |
| C3 | "Those quarterly roadmap-input sessions — what came out of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed, limited inspectable proof — volunteer that before you're asked. Beats: quarterly, you ran them, client evidence to product. Answer slot: if you know what product did with the evidence you brought, say what and how you know; if you don't know, or nothing came of it, say so plainly | The dossier flags this one as the probe magnet; EXP |
| C4 | "How hands-on are you with API docs and schemas? Give me an example." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if reading or writing API docs or schemas was part of that scoping or architecture work, say which and how, with one example, in your own words; if it wasn't, say so plainly and say what you did work from | F4 is a discovery row against R3; JD |

### D — Conversational (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your background." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: integrations, playbook, input sessions, in that order and in the quotes' own terms; then why this role (B3, your own words). Answer slot: give your actual years and titles, in your own words, with no PM title anywhere in it | Almost certain opener; it sets the frame B1 lands in; EXP |
| D2 | "How have you worked with agile teams?" | JD | [grounded] | Clarify strategy. Answer slot: if you worked in agile delivery, say how, in your own words; if you never worked that way, say so plainly. Either way: "Here's what I'd want to confirm about how your squads define it" | F7, R5 asked casually is still scored; JD |
| D3 | "What's drawn you to platform APIs specifically?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: your real reason, in your own words. You can anchor it in the integrations at their scope | Genuine-interest probe; EXP |

### E — Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier prohibited_claims: "Having held a product manager title or role" | B1 compressed: one sentence of concession ("I haven't held a product manager title"), the integrations quote, one sentence of plan. Pause before you start. Don't run down the other candidate | Same objection, sharper register; JD |
| E2 | "Thirty integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led" through two follow-ups. Answer slot: which part of the integrations was yours, in your own words; where others did parts, say so | Attribution probe; EXP |

### F — Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "You've written a spec and a squad lead says it's the wrong priority. What happens?" | CASE | [generic] | Listen for their reason, separate the facts from the priority call, and say who you'd expect decides — then say you'd want that settled up front (reverse question Q1). The question asks about no past; don't import one | The dossier's open risk on decision authority; F9's limit makes this forward-looking; CASE |
| F-2 | "Tell me how you manage stakeholders across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Clients and product from the quotes, at their scope. Answer slot: if you worked with engineering or sales on those integrations, say how, in your own words; if you didn't, say so plainly and stay with clients and product | F5 and F6 against R4; JD |

### G — Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time it needed a named stake, a moment you didn't fold, and the relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem; no values round detected and no values page read; VAL |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a real trade-off and a decision you made. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem; platform-PM roles live on this trade-off; VAL |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management | B1, B2, B5, E1, D1 |
| R2 Shipped API or platform products | B4 |
| R3 Technical fluency: API docs, schemas | C4 |
| R4 Stakeholder management | F-2, C3 |
| R5 Agile delivery | D2 |
| Own the roadmap | B1, B2, A1 |
| Run discovery with partners | A2 |
| Specs and delivery with two squads | F-1, A1 |
| Adoption metrics | A3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| Q1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier: decision authority is asserted in the role profile but not evidenced. It reads as diligence and tells you whether you'd own anything |
| Q2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier: adoption is a stated responsibility with no baseline given. You learn whether you inherit a number or build one |
| Q3 | "What would make the first six months a clear success from where you sit?" | Turns a vague mandate into the bar you'll be judged against |
| Q4 | "When a squad lead and the PM disagree on priority, how has that been resolved here?" | Tests Q1's answer against practice rather than design |
| Q5 | "What do partners complain about most right now?" | Shows you think from the partner side, and tells you where the first quarter goes |
| Q6 | "Is there anything in my background you'd want me to address before we finish?" | Surfaces B1 on your terms, with time left to answer it |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held a product manager title." Then the integrations quote at its own scope. No "de facto PM" framing |
| Having owned a product roadmap | Dossier prohibited_claims; dossier acknowledge_gap area | "I haven't owned a product roadmap." A ramp plan, as a plan. No slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Then F9's quotes at their scope |
| Shipped API or platform products | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: your material says integrations of the vendor's APIs, not shipping the API product. B4's slot stays inside the integrations |
| Shaped the roadmap through the input sessions | Inflated form of the roadmap-input quote (F5) | The quote at its own scope: you ran the sessions and fed client evidence to product. C3's slot asks only what you know product did with it |

---

## Sources

- **Provided:** `tuesday-dossier.md`, envelope v1.1, generated 2026-08-14. Sections supplied: `role_profile` (the JD equivalent: requirements R1 to R5, responsibilities, unknowns), `decision` (context only), `handoff_to_mock_interview` (verified evidence, weak areas with strategies, the named objection, risks, employer questions, prohibited claims). No `evidence_map`, `evidence_state` or `risk_register` section was present. The dossier is about three and a half months old; nothing in this pack checks whether the posting has changed since.
- **Searches sent:** "Quartzline company values" — refused. "Quartzline interview process product manager" — refused. "Quartzline partner API platform news 2026" — refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Refused. Would have supplied official value names to theme VAL questions G1 and G2; no values cheat sheet either way, since no values round is detected |
| 2. `Quartzline interview process product manager` | unavailable | Refused. Your own words already establish this session; it could have added any documented case format to the A bank |
| 3. `Quartzline strategy` / recent news | unavailable | Refused. Would have grounded A5 and one CASE question in current strategy; both stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role profile fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Search permission → Quartzline's values, current strategy and any documented interview format; A5 and a strategy CASE question become `[grounded]`. With it, a deeper pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- The hiring manager's name → a read of their public professional background, persona weights from it, and a reverse question tied to their own path
- The current posting text → confirms the August role profile still matches, and any new line becomes a fit-snapshot row
- Your own answers to the slots in F4, F6, F7, F8, F9 and F10 → those rows gain quotes, and C4, D2, F-2, A2 and A3 become story-mapped
- Your prep time → a prioritized triage of what to rehearse first
