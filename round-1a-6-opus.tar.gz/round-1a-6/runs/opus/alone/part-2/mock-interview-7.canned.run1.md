Reading the skill's evidence rules, then doing a small research pass on Saltmarsh Games and Tobias Wrenfield before I write the pack.
I've built your prep pack for Friday's hour with Tobias. It assumes he's the hiring manager for this role, because Saltmarsh's careers page says the 60-minute interview is with the hiring manager.

**What Friday looks like.** Saltmarsh's interviewing page calls this session the "Outage Hour". It's one 60-minute interview: first a tabletop exercise on a simulated outage during a live event, then a conversation about their values. There's no take-home.

**What the pack covers:**
- **Your fit against the JD.** Content calendar and release checklist are strong matches. Running two titles, coordinating teams, owning the post-event review and retention metrics are partial. In-app purchases is a gap you've stated yourself.
- **23 practice questions**, weighted towards the outage exercise and the values conversation.
- **Saltmarsh's three values** (Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener), each paired with a story or an honest way to answer.
- **Background on Tobias.** He was previously a QA lead, and his GDC 2026 talk "Patch Notes Are a Promise" argues that a live team is judged by whether its patch notes describe what actually shipped. So don't promise an ETA or fix you don't have during the outage exercise.
- **Project Larkspur.** From February 2027 both titles move to a season pass with one shared events calendar, which makes the in-app purchases question likely.
- **Questions to ask him**, and a list of claims the pack deliberately won't coach you to make.

**Most worth practising (B1):** "This role runs two titles and coordinates four disciplines. Your background is one title's calendar. Why are you ready?" Answer with what you actually did. If asked whether you've led a team, say plainly that you haven't. But don't offer that unprompted when the question is about coordinating teams, because coordinating isn't leading.

If you only have this evening, the pack has a five-step plan at the top.

Files are in /var/tmp/tuesday-measure/1a6/runs/opus/alone/part-2/rooms/case-7-canned-d3f60dd7:
- saltmarsh-games_live-operations-producer_interview_pack.md

Say the word and I'll play Tobias on B1, with follow-ups that react to what you say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I can convert it.

Is Tobias the person you'd report to, or is someone else your manager? The answer changes which question types get the most weight.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built on the assumption that he is the hiring manager for this role. Saltmarsh's interviewing page says the 60-minute interview is "with the hiring manager".
**Session:** Friday, 60 minutes. Per Saltmarsh's interviewing page, this is the "Outage Hour": "a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home."

---

## How to use this pack

- **Personas** describe *how* a question is asked. **Types** describe *what* it scores:
  - **VAL**: whether your past behaviour shows Saltmarsh's published values
  - **EXP**: whether what you say about your experience holds up under scrutiny, and what was actually you
  - **JD**: whether you can do the listed job, gaps included
  - **CO**: company and strategy knowledge (here, Project Larkspur)
  - **CASE**: a live problem from the role, worked out loud (here, the outage tabletop)
- **Provenance labels:** `[grounded]` = traces to your message, the JD or a cited source. `[inferred]` = derived, with the derivation named. `[generic]` = a role-family pattern, not a claim about Saltmarsh.
- **Answer slots** are instructions for the interview, not questions for you to answer now. Each has two honest branches. Either one is a good answer.
- The guidance is scaffolding, not a script. Say it in your own words.
- Question IDs skip the letter F so they don't clash with the fit-snapshot rows F1–F9.

## Prep triage (one evening, interview tomorrow)

1. **B1**: the highest-ROI rehearsal in this pack. Say it out loud three times, follow-ups included.
2. **A1 → A2 → A3**: the outage tabletop is half the hour. Practise the structure until you can say it without notes.
3. **The values cheat sheet**: pick an answer or an honest branch for each of the three values, and know their names exactly.
4. **B2**: the in-app purchases answer, plain and short.
5. **Reverse questions**: choose three.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, not live events across two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title line makes a probe likely on what running it involved. If any of it involved planning around other work or other titles, say how, in your own words. If it didn't, say so plainly and stay with the calendar you ran. Speak about two titles only as a plan |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Running the calendar touches this requirement, but your material doesn't show whether it involved coordinating those disciplines. Answer slot: if getting design, art, engineering or community to hit a drop date was part of running it, say who and how, in your own words. If it wasn't, say so plainly and describe how you would set it up. Coordinating is not leading. "Never led a team" answers a question about leadership, not this one |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review, not the same work. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you also chose what went into that report, or reviewed drops after they shipped, say how. If not, say so and stay with presenting. Describe owning the review only as how you would run it |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. It's a claim from your message with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms: you wrote it, and QA still uses it. A named artifact still in use beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material gives four years producing and a weekly content cadence, but it doesn't say whether the title was live-service. Answer slot: if it was run as a live service, say so in your own words and how. If not, say so plainly and point to the weekly drops you ran. Keep the title as "associate producer" |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote meets the requirement. Lead with it as stated: weekly, main title, two years. Expect a probe on how the calendar actually ran |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [inferred] | discovery | Presenting the numbers touches this requirement, but your material doesn't show what you did with them. Answer slot: if you prepared or interpreted the numbers, say which measures and how, in your own words. If someone else produced them and you presented them, say so plainly and stay with the presenting |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already shows written work in other terms. Reword it, adding nothing: a checklist you wrote that QA still uses |
| F9 | "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" — Saltmarsh news, Project Larkspur | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You have stated this gap, and no wording closes it. Words: "I haven't worked on a game with in-app purchases." Then say how you would learn it, as a plan and never as a past. This isn't a JD line, but the studio's own announcement makes the topic likely |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A4, A5, B1 |
| Coordinate design, art, engineering and community (F2) | B1, H1, A1 |
| Own the post-event review and its KPIs (F3) | A3, D3, E2 |
| Manage the release checklist with QA (F4) | C3, D2, E1, H2 |
| 3+ years producing live-service games or apps (F5) | B4, B3, G1 |
| Experience running a content calendar (F6) | A4, B1, E3 |
| Comfortable with player-retention metrics (F7) | E2, D3, C4, A3 |
| Clear written communication (F8) | A2, D1, C3 |
| Season-pass move, from the news page (F9) | B2, A4, G2 |

---

## Reading the interviewer

Public professional footprint only, from one search result (the talk page itself wasn't fetched).

| Signal | Source | Implication for you |
|---|---|---|
| Head of Live Operations at Saltmarsh, previously a QA lead at a console studio | GDC 2026 talk listing | Release discipline is his native ground, so expect E1 and D2 to go deep. F4 is the strongest evidence you have. Lead with it, at its own scope: "Wrote the release checklist our QA team still uses." |
| GDC 2026 talk "Patch Notes Are a Promise": "a live team is judged by how often its patch notes describe what actually shipped" | GDC 2026 talk listing | In the tabletop, never promise an ETA or fix you don't have. Say what is known and when the next update will come. E3 rehearses his theme directly |
| Shared vocabulary, QA and release process | F4 | You don't share his career jump; the overlap is the checklist, said exactly as F4's quote says it. Don't add to it |

## Persona table

The weights come from the documented loop. Saltmarsh's interviewing page names the session (tabletop, then values) and the interviewer's signals adjust it.

| Persona | How it shows up Friday | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A, 5 Qs) | The simulated outage during a live event | **Highest.** The interviewing page puts a live-incident tabletop first. Hiring-manager prior: Case + Skeptic | Clarify, then stabilise, communicate, decide and review. Think aloud and use Saltmarsh's own words (live event, Larkspur, shared calendar) |
| Values / Behavioral (C, 4 Qs) | The second half of the hour | **High.** The interviewing page names a values conversation, and there are three published values | One answer or honest branch per value; "we" for context, "I" for your part |
| Skeptic (B, 4 Qs) | Gaps against the JD and Larkspur: one title vs two, in-app purchases, title level | **High.** Hiring-manager prior, plus F1, F2 and F9 | B1 rehearsed until it's boring. Bridges built only from F1 and F4's quotes, plus a ramp plan |
| Pressure (D, 3 Qs) | Time-boxing inside the outage, "how much was you?" | **Medium.** A simulated outage invites interruptions and time-boxes | Pause, restate the question, hold on what the quote carries through two follow-ups, then concede specifically |
| Data-Driven Prober (E, 3 Qs) | Checklist detail, how retention was counted, whether drops shipped as announced | **Medium.** QA background and a talk about patch notes matching what shipped | Know what you can and can't say about each item. "I don't know how it was counted" is an honest answer |
| Conversational (G, 2 Qs) | The opener | **Low.** One-hour sessions usually still open with the journey question `[generic]` | A 90-second arc made only of your quotes |
| Peer Evaluator (H, 2 Qs) | Cross-discipline coordination | **Low.** This isn't a peer round, but the role is coordination-heavy | Seam principles, not invented history |

---

## Question banks

### A. Case / Strategist: the outage tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day three of a week-long event on Tidepool Tactics and players can't connect. Walk me through your first 30 minutes." | CASE | [generic] | **Clarify first:** which title, all players or a region, is it the event or the whole game, and did a release just go out. **Stabilise:** get engineering on a call, name who decides, and decide whether rolling back the last release is on the table. **Communicate:** agree a first player-facing message with community fast, saying what's known and when the next update comes, not a fix time. **Decide** what happens to the event: pause the timer, extend it, or leave it. **Record** everything for the post-event review. Say the structure out loud before filling it in. The question needs no claim about your past, so the guidance makes none | The interviewing page documents this exact format, and the title is from the Larkspur announcement. `[generic]` because the structure is a role-family pattern, not Saltmarsh's runbook |
| A2 | "Engineering says maybe four hours. Community wants to post an ETA now. What goes out?" | CASE | [generic] | Hold the line on what's actually known. Post the problem and the next update time, not "four hours". Explain why: a missed ETA costs more trust than no ETA. Offer to draft the post yourself in two sentences, then say them aloud. That sentence is the written-communication evidence the JD asks for, produced live | Direct pressure on the Ship the Patch Not the Promise value and the interviewer's talk theme. CASE delivery, and it covers F8's written-communication requirement |
| A3 | "The event's over. What goes in your post-event review, and which KPIs do you report?" | CASE | [generic] | A timeline of the incident, the player impact, what was decided and why, and what changes. Name example KPIs as what you would look at, not as Saltmarsh's: event participation, retention around the outage window, support contacts, player sentiment. Close on what changes in the release checklist, which ties to Leave the Build Greener. Speak about owning the review only as how you would run it | The JD says "own the post-event review and the KPIs it reports" (F3), and the tabletop leads naturally there |
| A4 | "From February both titles share one events calendar. How would you build it?" | CASE | [grounded] | Clarify: the season-pass rhythm, team capacity, and which disciplines are shared. Then structure: one cadence, rules for when events on the two titles collide, art and engineering dependencies mapped per update, QA capacity as the hard constraint, and a review loop. Where the season-pass economics come in, say it plainly: "I haven't worked on a game with in-app purchases." Then say how you'd learn it. Any experience you mention stays at F1's scope | Grounded in the Larkspur announcement, which is the strategy question that sets you apart. CASE delivery on CO content. It covers F1, F6 and F9 |
| A5 | "Design wants to slip an update a week, but the event is already announced. What do you do?" | CASE | [generic] | Clarify what's really at risk: the content, or quality. Lay out the options (ship less, slip and tell players early, swap in other content) and recommend one with its cost. Tie it to Players Before Plans and Ship the Patch Not the Promise by name | This plans and runs the calendar under strain (F1), and it tests both values in one decision |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role runs two titles and coordinates design, art, engineering and community. Your background is one title's calendar. Why are you ready?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | **The highest-ROI rehearsal in this pack.** **Hold:** "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." **Limit, said before it's asked:** it was one title. **Answer slot:** if running that calendar meant getting other disciplines to hit drop dates, say who and how, in your own words. If it didn't, say so plainly and stay with the calendar. **Then a plan, said as a plan:** how you'd approach a second title and four disciplines. **Follow-up 1** ("Who did the art team answer to?"): give your actual answer, and don't claim authority you didn't have. **Follow-up 2** ("Have you led a team?"): "I've never led a team." Then return to the calendar. Don't volunteer that line in answer to a coordination question | F1 and F2 are where the JD presses hardest, so this objection will come in some form. JD because it scores the stated requirements. Deepest rehearsal because the material is thinnest here |
| B2 | "We're moving to a season pass. Have you worked with in-app purchases?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | "I haven't worked on a game with in-app purchases." Stop there, without apology. Then say how you'd learn it, as a plan: who you'd sit with, and what you'd read first. Hold the plan through one push, then concede specifically: "I'd be learning that part on the job." Don't soften the negative with nearby experience | F9: a gap you stated, made likely by the Larkspur announcement. CO because it tests whether you've read the strategy |
| B3 | "You've been an associate producer. Why is this the right step rather than a stretch?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Use the title as it is: four years as an associate producer at a puzzle-game studio, and for the last two you ran the weekly content-drop calendar for the main title. Let the interviewer draw the conclusion. Answer slot: if you have a reason of your own for why now, give it in your own words. If you don't, say so honestly | Title level is the second most visible gap (F5). EXP because it tests whether you size your own experience accurately |
| B4 | "Your title had weekly content drops. Was it run as a live-service game?" | JD | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if it was live-service, say so and what that meant day to day, in your own words. If not, say so plainly and point to the weekly drops you ran. Don't adopt the JD's words for your title unless they are true | The JD's "3+ years producing live-service games or apps" against F5's silence. `[inferred]` because the live-service reading comes from the JD, not your material |

### C. Values conversation

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our first value is Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] | Selection scaffold: pick a time a drop or plan changed because of how players responded. It needs a named plan, the player signal, what changed and your part in it. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, the weekly calendar (F1), or how you'd handle it | Value 1, worded from the values page. No quote of yours carries a story here, so this is a scaffold |
| C2 | "Ship the Patch Not the Promise. When have you held back from announcing something that wasn't built yet?" | VAL | [grounded] | Selection scaffold: a time something was announced, or nearly announced, before it was ready. It needs what was at stake, what you said or held back, and what happened. If no such time comes to mind, say so plainly, then say how you'd handle it, as in A2 | Value 2. It's also the interviewer's talk theme, so it's likely to be pushed |
| C3 | "Leave the Build Greener: every release leaves the checklist better. Tell me about the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story on F4: you wrote it, and QA still uses it. Those are the two beats the quote states. Answer slot: the value names leaving the checklist better, so expect a probe on whether it changed over time. If you revised it after releases, say what changed and why, in your own words. If you didn't, say so plainly and stay with the fact that it's still in use | Value 3 maps onto your strongest quote. VAL first, with EXP depth from a QA-background interviewer |
| C4 | "Tell me about a time you had to give leadership numbers they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a month's retention numbers you presented to the studio head were bad news, say what you presented, how you framed it and what happened, in your own words. If none were, or none comes to mind, say so plainly and describe how you prepared those presentations | An unpopular-truth stem on F3 and F7. VAL because values conversations usually include a hard-truth story `[generic]` |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. The event's down and players are angry online. Read me your first post." | CASE | [generic] | Pause, then say two sentences: what's happening, and when the next update comes. No ETA and no blame. If interrupted, finish the sentence, then answer the interruption | Time-boxing is likely inside a simulated outage. It covers written communication (F8) under pressure |
| D2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | **Hold:** you wrote it, and QA still uses it. Answer slot: if others contributed items or reviewed it, say who and what, plainly. If not, say so. Hold through two follow-ups, then concede only what's true and specific | F4 is the claim a QA-background interviewer is likeliest to test. EXP because it tests attribution |
| D3 | "You presented retention numbers. Did you build them, or just present them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the verb: you presented them. Answer slot: if you prepared or analysed them too, say how. If someone else did, say so plainly, with no apology, and say what presenting involved. Don't upgrade "presented" | F3 and F7. The JD says "own", and your quote says "presented", so this gap will be tested |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through what's on your release checklist, and something it caught." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Walk through the sections you actually wrote, in your own words. Answer slot: if the checklist caught a problem before release, describe it. If you can't point to one, say so plainly and describe what it's designed to check | Expect this from the interviewer's QA background (F4). "Something it caught" presupposes an event, so the second branch lets it not exist |
| E2 | "Which retention measure did you present, and how was it counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the measure you presented, in your own words. Say how it was counted if you know. If you don't know, say so plainly. Then name the assumption behind it you'd defend least, or say you don't know which that is | The defend-the-number move on F7, for an interviewer who will probe any metric |
| E3 | "How often did your content drops ship exactly what was announced?" | EXP | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if drops were announced ahead and you know how often they matched, say so in your own words. If they weren't announced, or you didn't track it, say so plainly and describe how you'd measure it here | The interviewer's talk theme applied to F1. `[inferred]` because the premise is his, not yours |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of these four facts: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title for the last two, the release checklist QA still uses, and presenting the monthly retention numbers to the studio head. End on why live ops at Saltmarsh, in your own words | The casual opener is still scored. EXP because each line will be followed up |
| G2 | "Why Saltmarsh, and why now?" | CO | [grounded] | Show you know Larkspur: two titles, a season pass, one shared calendar from February 2027, and a single live-ops group. Answer slot: give your own real reason for wanting this. If Larkspur is part of it, say why. If it isn't, don't pretend it is | Motivation, plus evidence of homework on the current strategy. CO type |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "An art lead says the event banner will be a week late. You don't manage them. What do you do?" | CASE | [generic] | Clarify the cause and what's actually needed by the date. Options: reuse or cut scope, move the slot, or bring in more help. Escalate to whoever owns the trade-off if needed. Credit stays with the team. Seam principle: agree dates with them, don't set dates for them | "Coordinate design, art, engineering and community" (F2), asked as a live problem with no claim about your past |
| H2 | "How did you work with QA on releases?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Start from the quote: you wrote the checklist, and they still use it. Answer slot: if you worked alongside QA on releases, say how, in your own words. If the checklist was the main contact, say so plainly | "Manage the release checklist with QA" (F4). This is the side of the work the interviewer comes from |

---

## Values cheat sheet

From saltmarshgames.com/values. Know the names exactly.

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (C1): a plan changed because of the players' response. If none comes to mind, say so plainly and give how you'd handle it |
| Ship the Patch Not the Promise | Announce what's built, not what's hoped | Selection scaffold (C2): a time you held back an announcement. If none comes to mind, say so plainly and walk through how you would, as in A2 |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Whether you revised it is C3's answer slot |

## Reverse questions

| Question | Why it lands |
|---|---|
| "In your GDC talk you said a live team is judged by how often its patch notes describe what actually shipped. How do you track that here?" | It's his own published theme, and it shows you researched him, not just the company |
| "Coming from QA into live ops, what was the first thing you changed about how releases run?" | It's tied to his career path and turns the interview into a conversation about the work you share (F4) |
| "With one shared calendar from February, where do you expect Tidepool Tactics and Lantern Row to collide hardest?" | It shows strategy fluency, and the answer tells you what the first quarter of the job really is |
| "Is this producer role new to the single live-ops group, or replacing per-title roles?" | Larkspur retires per-title teams, so this asks what the role is really for |
| "What does a post-event review look like here today, and who reads it?" | It's the JD's ownership line, and the answer tells you how high the bar is |
| "What would make the first 90 days a success for this hire?" | It ends on concrete expectations you can answer back to, in a follow-up note or a later round |

## Prohibited claims

What this pack won't coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The material says one title's weekly content-drop calendar. Two titles are spoken of only as a plan |
| Led or managed a team | Negative you stated, in your message | "I've never led a team." |
| Owned post-event reviews or KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. Owning a review is described only as how you would run it |
| Built or analysed the retention numbers | Inflated form of F7 | "Presented the monthly retention numbers to the studio head." Anything more is D3's and E2's answer slot |
| Experience with in-app purchases, monetisation or season passes | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." |
| Producer, without "associate" | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Ran or managed QA | Inflated form of F4 | "Wrote the release checklist our QA team still uses." |
| A live-service title, said as fact | Silence in F5, not stated | B4's answer slot, never an assertion |

## Sources

- **Provided:** the JD and your background, both pasted in your message.
- **Search** "Saltmarsh Games values" returned https://saltmarshgames.com/values
- **Search** "Saltmarsh Games interview process producer" returned https://saltmarshgames.com/careers/interviewing
- **Search** "Saltmarsh Games mobile studio news 2026" returned https://saltmarshgames.com/news/project-larkspur
- **Search** "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise
- **Fetch** https://saltmarshgames.com/values: the three values and their definitions
- **Fetch** https://saltmarshgames.com/careers/interviewing: the Outage Hour format

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and C1–C3: three values by name and definition |
| 2. Saltmarsh Games interview process | yes | The loop: one 60-minute session, a tabletop then values. Persona weights, bank A and the cheat sheet follow from it |
| 3. Saltmarsh strategy / recent news | yes | Project Larkspur: A4, B2, G2, F9 and two reverse questions |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read: QA background and his GDC 2026 talk. This tilted the Prober bank and A2, and gave two reverse questions |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirm whether Tobias is your would-be manager → if he isn't, the Case/Skeptic weighting is reweighted and the reverse questions retuned
- The recruiter's prep notes, if any → coverage of any stated focus areas for the tabletop
- Your own answers to the answer slots in F2, F5 and F7 (coordination, live-service, what you did with the retention numbers) → those rows move from discovery to story-mapped guidance in B1, B4, E2 and D3
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → his full talk, reports from candidates who've done the Outage Hour, and more detail on Larkspur for A4
- A tuesday-dossier.md, if you have one → verified evidence and an evidence-derived objection in place of the inferred one in B1
