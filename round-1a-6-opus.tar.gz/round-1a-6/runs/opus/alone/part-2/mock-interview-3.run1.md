Building your pack now. I've read the prep framework and I'm moving on to research Stripe.
I've built a prep pack you can rehearse from tonight, saved as `stripe_product-operations-manager_interview_pack.md`. You only told me the company and role, and my web searches were blocked in this session. So the pack is built from what product operations roles typically ask for and contains nothing specific about Stripe. It doesn't put words about your past in your mouth: where a question asks about your experience, it tells you what kind of story to pick and what to say if you don't have one.

What's in it:
- **A fill-in table:** eight typical product operations requirements, such as launch readiness, metrics, working across teams and prioritizing. For each, it says what a strong answer looks like and which of your own stories to pick.
- **22 practice questions:** grouped by interviewer style (case, skeptic, numbers-heavy, future peer, behavioral, pressure, casual), each with answer guidance. All seven styles get equal weight because I don't know who you're meeting.
- **Six questions to ask your interviewers.**
- **A list of what adding your job description, CV or session schedule would unlock.**

**Most worth your time:** question B1, "Which part of this role would you be weakest at on day one?" Pick one real gap, say it plainly and follow it with a 30–60 day plan. Then practise holding that answer through three follow-ups.

Two answers rely on Stripe knowledge the pack couldn't provide. For "Why Stripe?" (B2) and "What has Stripe been building lately?" (H2), use only things you've actually read or used yourself.

If you'd like to practise, I'll play the skeptic and ask you B1, then follow up based on what you actually say. I can also save a `tuesday-dossier.md` file listing the gaps this prep turned up, so you can use it in later sessions. And if you want the pack as a Word document, I'll convert it.

1. Who are you meeting in the final round: the hiring manager, peers, someone more senior, or people from other teams? And did the recruiter mention focus areas or anything to prepare, like a presentation, a case or a written exercise? This would reweight every question group and could add a section for that task.
2. Can you paste the job description and your CV, or a short summary of your background? Without them the pack still works, but with them your real stories replace the "pick a story" prompts.
3. Web search was blocked here. If you allow it, should I look up Stripe's published values, its interview process and recent news to make the Stripe-specific questions concrete?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final-round prep pack

**Round:** final round. Interviewers and the format of each session are not known yet.
**Built on:** the role title and company only. There is no job description or CV, and research was refused in this session (see Sources). So every requirement below is a role-family pattern labeled `[generic]`, and the fit snapshot is a worksheet for you to fill in.

---

## How to use this pack

- **Personas** describe *how* a question is asked: who asks it and in what style. **Types** describe *what* is being scored.
- **Type key:**
  - **VAL**: behavioral or values fit. Does your past behavior show the company's published values, beyond generic virtue?
  - **EXP**: work-experience deep-dive. Does what you say you did hold up, and what was actually yours?
  - **JD**: role-driven. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge. How deep did you go, and can you think at the company's level?
  - **CASE**: a live problem from the role. Scored on structure and reasoning, not on a "right" answer.
- **Provenance labels:** `[grounded]` means traceable to something you gave me or to cited research. `[inferred]` means derived from a representative source. `[generic]` means a role-family pattern with no claim about Stripe or about you. Every row here is `[generic]` for now. The upgrade menu says what changes that.
- Question IDs use one letter per persona. **F is skipped** because F1–F8 are the fit-snapshot rows.
- **The guidance is scaffolding, not a script.** Say it in your own words, using only what you actually did.

---

## Fit snapshot (worksheet)

No CV or background was provided, so every evidence cell reads `none given`. Each bridge cell says what strong evidence looks like, then gives you a selection scaffold so you can pick your own story before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Turning a product launch into operational readiness: processes, enablement and support in place across teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one launch where you can say what had to be ready, who needed what, and what you personally did to get it there. Selection scaffold: pick a launch or rollout where you can name your own part and one thing that went wrong or nearly did. If no such time comes to mind, say so plainly, then give the nearest thing your work does include, or how you would handle it |
| F2 | Building feedback loops from users and frontline teams into product decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one time feedback you gathered or routed changed a decision, and you can say what changed. Selection scaffold: pick a case where you can name the source of the signal, who you took it to, and what happened next, including if nothing changed. If no such time comes to mind, say so plainly, then give the nearest thing your work does include, or how you would handle it |
| F3 | Defining and tracking operational metrics; pulling and checking data yourself (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a number you can defend: how it was counted, what it is sensitive to, and the assumption you would defend least. Selection scaffold: pick one figure from your own work and rehearse those three things in your own words. If you don't know how it was counted, say so plainly |
| F4 | Designing processes that scale: documentation, tooling, automation (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process you introduced or changed, plus how you knew whether it worked. Selection scaffold: pick one where you can say what existed before, what you changed, and what you checked afterward. If nothing fits, say so plainly and describe how you would approach it |
| F5 | Influencing product, engineering, support, sales and risk teams without formal authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team that ended in a decision and an intact relationship. Selection scaffold: pick one with a named stake, the point where you held or changed your view, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your work does include, or how you would handle it |
| F6 | Prioritizing under ambiguity and too many requests (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a time you said no or "not yet" to someone and can explain the basis. Selection scaffold: pick one where you can name what you dropped and why. If no such time comes to mind, say so plainly and walk through how you would decide |
| F7 | Clear written communication: docs, launch notes, proposals (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a document you wrote that others acted on. Selection scaffold: pick one you could describe in two sentences, including who read it and what they did with it. If nothing fits, say so plainly |
| F8 | Judgment on risk, compliance or user-harm trade-offs, common in payments and financial-infrastructure roles (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a time you slowed something down, or raised a risk, and can say why. Selection scaffold: pick one where the stake for users is clear. If no such time comes to mind, say so plainly and describe how you would weigh it |

---

## Persona table

**Weighting basis:** I don't know who you're meeting, and no source I could read describes Stripe's final-round structure. So the weights below are flat, using the generic archetype as a fallback. They rest on a pattern, not on Stripe's documented process. If your final is several back-to-back sessions, send the schedule and I'll build a mini-pack for each session.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live operational problems: plan a launch, diagnose a metric, triage requests | Flat. Plausible in any final round that includes a hiring manager | Clarify, then state the objective, segment, give your approach, metrics and risks. Think aloud. Challenge one premise per case |
| B. Skeptic | Quiet probing of gaps and motivation: why here, why now, what you're weakest at | Flat. The highest-ROI question (B1) lives here because it arrives in almost every final in some form | Rehearse B1 until it's boring. Name a real limit plainly, then a concrete ramp plan |
| C. Data-Driven Prober | Picks a number you mention and goes two levels down | Flat. Ops roles get metric probes, but nothing on a CV is known to target yet | Know how each figure you'll mention was counted, or say plainly that you don't know |
| D. Peer Evaluator | Seams between product ops and adjacent teams, disagreement, credit | Flat. Finals often include a future peer | Reciprocity framing. Propose seam principles rather than claiming to know the seam |
| E. Values / Behavioral | STAR-style stories about hard truths and customer trade-offs | Flat. No values round is established for this loop, so VAL questions here use generic persona themes | "We" for context, "I" for your part. Pick stories where the hard truth actually landed |
| G. Pressure | Time-boxed answers, devil's advocate, "how much was actually you?" | Flat. Lower prior for ops roles, but rehearsing it costs little | Pause, restate the question, anchor in what you actually did. Hold through two follow-ups before conceding |
| H. Conversational | Friendly openers, "walk me through the journey", the reverse-question slot | Flat. Opens and closes most sessions, and is scored even though it feels casual | A pre-built 90-second arc. Treat casual questions as scored |

---

## Question banks

**Highest-ROI prep in this pack: B1.** It asks which part of the role you'd be weakest at on day one. It arrives in some form in nearly every final, and a rehearsed, non-defensive answer changes how everything after it is read.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're launching a new feature to a subset of users next quarter. What has to be true operationally on launch day, and how would you get there?" | CASE | [generic] | Clarify first: who the users are, what's changing for them, and what "launch" means (a beta or general availability). Then structure: who is affected (users, support, sales, risk), what each needs to be ready (docs, training, escalation paths, monitoring), sequencing back from the date, and how you'd know on day one that it's working. End with the one risk you'd watch hardest. The question needs no claim about your past, so this guidance makes none | Tests F1 directly as a live problem. CASE because it scores structure, not history |
| A2 | "An operational metric tied to one product, say time to resolve user issues, got 20% worse over a month. Diagnose it." | CASE | [generic] | Clarify the definition and whether the measurement changed. Then segment: by issue type, user segment, channel, team, and the date it started. Pair the timing with what shipped or changed. Form a hypothesis, then name the one check that would kill it. Say what you'd do this week and what you'd report | Tests F3 under time pressure. A persona stem applied to an ops metric |
| A3 | "Five teams want product ops help this quarter and you have capacity for two. How do you decide?" | CASE | [generic] | Name your criteria aloud before ranking: user impact, risk, reversibility, and whether anyone else can do it. Say how you'd tell the three teams that aren't picked, and what you'd give them instead. Expect a follow-up that challenges your top pick, which G3 rehearses | Tests F6. The "no" half of the answer is what's scored |
| A4 | "Support is seeing a spike in confusion about one feature. The product team says it's working as designed. What do you do?" | CASE | [generic] | Separate the facts (volume, what users are actually trying to do) from the framing. Bring evidence, not opinion, to the product team. Propose the smallest fix on each side (a help article, a UI change, a support macro) and decide who owns which. Close the loop with support | Tests F2 and F5 together. A realistic seam problem for the role |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Deepest rehearsal in the pack.** Choose one real gap before the interview and say it in one plain sentence, in your own words. No "strength in disguise". Then give what you'd do about it in your first 30–60 days, as a plan and never as a past. **Expect three follow-ups:** (1) "Why that one and not something else?" Hold it by giving your reason, and don't swap gaps. (2) "How long until it isn't a gap?" Give your honest estimate and the signal you'd use to know. (3) "What would you need from us?" Name one concrete thing. **Concede specifically and only once:** you can't know how big the gap is here until you see how the team works. Never shrink the gap to restore the mood | Every final probes self-assessment, and with no CV in hand the likeliest objection can't be predicted from your material, so the universal one gets the depth. JD because it scores fit against the listed job |
| B2 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | Three short parts in your own words. Why product ops: what in your work draws you to it. Why Stripe: rest this only on something you have actually read or used yourself; I couldn't research Stripe in this session, so don't borrow anyone else's lines. Why now: your real reason, said plainly. Keep the three parts consistent with each other, because this persona checks consistency | Motivation consistency is the Skeptic's core probe. EXP because it tests your own story |
| B3 | "How would you handle the analytical side of this role: pulling and checking your own data?" | JD | [generic] | If you've done this, pick one specific example: what you pulled, how you checked it, and what it changed. If you haven't, say so plainly, then say how you'd get up to speed and who you'd lean on while you do. Don't name tools you haven't used | Tests F3. A predictable probe on ops-candidate fit |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick one number from your own work you're proud of. Walk me through how that number was counted." | EXP | [generic] | Pick the figure before the interview. Rehearse four things in your own words: how it was counted, what it's sensitive to, the assumption you'd defend least, and exactly which part was yours. If you don't know how it was counted, say so plainly. That beats a method you can't repeat under a second question | Tests F3 as a defend-the-number probe. You choose the figure, so the question presupposes nothing |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they do, in one sentence, then say what would change if it were wrong. If you can't name one, say you'd need to recheck how it was counted. Don't invent an assumption | The standard second level after C1. Naming your weakest assumption first turns a trap into credibility |
| C3 | "How would you know if a process you introduced was actually working six months later?" | CASE | [generic] | Define "working" before you measure it: the outcome it was meant to change, a baseline, one leading and one lagging signal, and a check for side effects (who it slowed down). Say when you'd retire it | Tests F3 and F4 together. CASE because it's forward-looking |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam between product ops and product management, and what happens when we disagree?" | CASE | [generic] | Don't pretend to know their seam. Propose principles instead: who decides what ships, who decides how it's operated, and how disagreements escalate. Then ask how it actually works here | Tests F5. A peer is pricing how much the hire adds to or takes off their load |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Give your actual practice in your own words. If a story fits, pick one where you can name your part and the other team's part plainly. If none comes to mind, say how you'd handle it | Tests F5. Credit-sharing is the peer's partnership test |
| D3 | "What would you need from me in your first month, and what would you give back?" | CASE | [generic] | Answer both halves. One concrete ask (context, access, an intro), and one concrete thing you'd offer the peer's team early on | A reciprocity probe on F5. Answering only the first half is the common miss |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a point where you said the hard thing, and an outcome where the truth actually landed, or didn't, stated honestly. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your work does include, or how you would handle it | Persona stem. Tests F5 and F8 judgment |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where the trade-off was real and you can name what the metric cost. Don't supply an ending your story doesn't have. If no such time comes to mind, say so plainly and describe how you'd weigh it | Persona stem. Tests F2 |
| E3 | "A product team wants to launch on a date your readiness checks say isn't safe for users. What do you do?" | CASE | [generic] | Structure it: what specifically isn't ready, and the user harm if you launch anyway. Then the options: delay, a smaller rollout, mitigations. Then who decides and how you'd escalate without blocking for the sake of it. Make the trade-off explicit | Tests F8 as a live decision. CASE content with a VAL edge |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give three points from your own work, each one sentence. Concede that an insider has context you'd need to build, and say how you'd build it fast. Stop at sixty seconds | Persona stem. Tests composure, and B2's consistency under a time limit |
| G2 | "That story you just told: how much of it was actually you?" | EXP | [generic] | Hold-then-concede. Restate your part in "I" sentences that match what you actually did. Through two follow-ups, return to the same part and don't add to it. Then concede what wasn't yours, specifically. A smaller true claim survives this question and a bigger one doesn't | Applies to any story you tell. Rehearse it on your E1 and E2 picks |
| G3 | "Your prioritization in A3 assumed impact was the deciding factor. Convince me you're not just guessing." | CASE | [generic] | Hold: restate your criteria and why you'd weigh them that way. Second push: say what data would change your ranking. Concede specifically that you'd validate the impact estimates in week one. Don't abandon the framework just because you were pushed | Tests whether F6 reasoning holds under challenge |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three turns told only with what you actually did, and why this role is the next step. Rehearse it out loud with a timer | The opener in most sessions. Scored for economy even when it feels casual |
| H2 | "What's something about what Stripe is building that you've been curious about lately?" | CO | [generic] | Rest this only on something you have actually read or used from Stripe yourself. Name it, say why it interests you, and ask one real question about it. I couldn't research Stripe in this session, so this cell has no Stripe specifics for you to repeat | A casual question that scores homework. Generic because research was refused |
| H3 | "Any questions for me?" | CO | [generic] | Never "I think you've covered everything." Use two questions from the reverse-question list below, picked for who you're talking to | Rapport-style interviewers weight this slot heavily as a sign of preparation |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch readiness | A1 |
| F2 Feedback loops | A4, E2 |
| F3 Metrics and data | A2, B3, C1, C2, C3 |
| F4 Scalable processes | C3 |
| F5 Cross-functional influence | A4, D1, D2, D3, E1 |
| F6 Prioritization | A3, G3 |
| F7 Written communication | None. It's a generic requirement with no source. If the JD lists writing, or the recruiter mentions a written exercise, it gets a question |
| F8 Risk and user-harm judgment | E1, E3 |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first 90 days look like in this role, and what would make you say the hire wasn't working?" | It surfaces the real scorecard, and you can mirror it in your follow-up note |
| R2 | "Where does product ops sit relative to product and engineering here, and who sets its priorities?" | It shows you're already thinking about the seam (D1) and tells you who you'd answer to in practice |
| R3 | "Can you tell me about a recent launch where operations went well or badly, and what changed afterward?" | It invites a concrete story instead of a pitch, and shows how the team learns |
| R4 | "Which teams would I work with most, and which of those relationships needs the most investment right now?" | It signals you think in partnerships, and gives you material for a peer conversation |
| R5 | "How is product ops' impact measured here?" | It connects to C3 and shows you expect to be held to outcomes |
| R6 | "What are the next steps after today, and when should I expect to hear?" | A clean close that gets you the timeline without pressure |

---

## Prohibited claims

There are no entries yet. This pack holds none of your own sentences, so there is no wording of yours that could be stretched. The standing rule still binds every cell. Once you share your CV or background, any requirement that widens one of your sentences (for example, "ran" against "owned") will be listed here with its honest form, and the banks will be rewritten against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Any practice, figure, tool or outcome you haven't stated | No candidate material provided | Selection scaffolds with honest branches, as in every bank above |

---

## Sources

No documents were provided. Four searches were sent. The host refused all four, and none returned anything:

- `Stripe operating principles values`: refused
- `Stripe interview process product operations final round`: refused
- `Stripe strategy news 2026`: refused
- `Stripe "Product Operations Manager" job description`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The search was refused. It would have supplied Stripe's published values by name, values-themed VAL questions, and a values cheat sheet if a values round is confirmed |
| 2. `Stripe interview process product operations` | unavailable | The search was refused. It would have named the final round's sessions and replaced the flat persona weights |
| 3. `Stripe strategy` / recent news | unavailable | The search was refused. It would have grounded B2, H2 and at least one CO or CASE question in Stripe's current priorities |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative `Product Operations Manager` JD | unavailable | The search was refused. It would have turned F1–F8 into quoted `[inferred]` requirements |

---

## Upgrade menu

- **The job description text:** F1–F8 become the JD's own quoted requirements, `[grounded]`. JD-tagged questions get rebuilt against the real list, and F7 gets a question if writing is listed.
- **Your CV or a summary of your background:** the worksheet becomes a real fit snapshot. Story-mapped guidance replaces the selection scaffolds, the highest-ROI objection gets drawn from your actual gaps, and the prohibited list gets real entries.
- **Who you're meeting and the session schedule:** persona weights tuned to the real interviewers. If your final is several sessions, you get a mini-pack per session.
- **The recruiter's prep email, or any stated focus areas:** coverage of a presentation, case or written exercise, with its own build section.
- **Interviewer names:** a read of their public professional footprint, and a reverse question tied to their path.
- **Allowing web search:** Stripe's published values, its documented interview process, and recent strategy get pulled in. That makes B2, H2 and the CO questions specific instead of generic.
- **Deep research:** up to 6 more searches and 2 more fetches, several more minutes. It adds a strategy brief, a grounding brief section, and sharper CASE questions on Stripe's current priorities.
- **A work sample you can point to (a launch checklist, process doc or metrics dashboard you built):** strong rows could move from `medium` to `high` confidence once you've shared your background.
- **A `tuesday-dossier.md`, if you have one:** verified evidence and an evidence-derived top objection in place of the generic one in B1.
