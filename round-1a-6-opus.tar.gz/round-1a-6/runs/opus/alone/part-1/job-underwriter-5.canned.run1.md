Both checks came back: the posting is live and matches what you pasted, and the About page matches too. Here's the assessment.

## Decision snapshot

**Yes, it's worth applying, as long as the one location question below checks out. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote within the US, or the Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (Working in BigQuery) · unclear: R9 (Ingestion from the app and CRM), R10 (Data contracts analysts depend on)

R6: Snowflake is a credible bridge, but its limit needs saying. R9 and R10: your background doesn't mention either, so each is worth one question.

**Opportunity ledger.** The role looks sound and open about its terms. The posting is live and matches your copy (RR1). The company exists as described (RR2). The pay is stated and sits in the market band (RR3). Three things are still unknown: who you'd report to (RR4), whether this is one domain or the whole data platform (RR5), and what the equity is (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote within the US, or the Denver office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remotely from the US or from Denver (R1); (2) your pay floor and any other non-negotiables fit the stated terms (R1, RR3); (3) you describe BigQuery honestly as new to you, never as experience you have (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016, based in Denver, 264 employees, raised a $52M Series C in February 2026 | `[grounded]` About page, confirmed by search |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt warehouse in BigQuery, and the data contracts the analysts rely on | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 base plus equity | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | The job may cover the whole reporting stack, from ingestion through warehouse to contracts, not a single domain. Nothing in the posting mentions direct reports | `[inferred]` from the mandate listing all three layers, set against the report's "one domain's pipelines" norm |
| Market calibration | "Senior" usually means 5–8 years, owning one domain's pipelines, with no direct reports. Typical base pay: median $151,000, middle half $139,000–$163,500. This posting's band runs from $3,000 below the median to $2,500 above the top of that middle half. That's the going rate, not this employer's offer | `[generic]` Datawright 2026 report (US, n=2,310, Series B–D) that your recruiter sent; `[grounded]` JD for the posted band |
| Unknowns | Hiring manager and team size; whether the job covers one domain or the whole platform; equity terms | — |
| Contradictions | None. The live posting matches your pasted copy word for word | `[grounded]` posting fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote within the US, or the Denver office | hard_gate | unclear | none | hard_gate | The JD states the terms. You haven't said where you're based or whether you're authorized to work in the US | `[grounded]` JD; background silent | Q1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, specific and self-reported. Nothing to inspect yet, so expect it to be probed | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" will be tested in technical rounds | `[grounded]` your background; `[generic]` that this role family checks it with a live exercise | none |
| R4 | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models | `[grounded]` your background | none |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake. The JD asks for "a cloud warehouse", not BigQuery specifically | `[grounded]` JD wording and your background | none |
| R6 | Working in BigQuery (their warehouse) | important | adjacent | medium | transferability | Implied by "a dbt-modelled warehouse in BigQuery". dbt modelling, testing and warehouse SQL carry over. What doesn't: you've never used BigQuery, so its cost model, partitioning and clustering, and SQL dialect are new | `[inferred]` requirement from the JD's stack line; `[generic]` that these are where warehouses differ | see G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background | `[grounded]` | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your background | none |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | The JD names this as a core part of the job. Your background doesn't mention what sources you've ingested | `[grounded]` background silent | see G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The JD names contracts. Your background mentions tests but no contracts or agreed schemas with downstream users | `[grounded]` background silent | Q3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Deep dbt-on-Snowflake work, no BigQuery | This is the one visible difference between your stack and theirs, so it's the obvious thing to ask about | Any time you tuned warehouse cost or performance in Snowflake (clustering keys, warehouse sizing); dbt work written to run on more than one warehouse | A small personal dbt project running on BigQuery, or a short write-up on moving from Snowflake to BigQuery | `[inferred]` bridge from your dbt/Snowflake work; `[generic]` that this is the likeliest objection |
| G2 | Ingestion from the app and CRM (R9, important) | discovery | Nothing yet on what you've loaded data from | It's a named part of the job, and having done it changes what you lead with | Loading product or app event data; pulling from a CRM or HRIS through an API; building or running loaders (Fivetran-type tools or custom Python) | A pipeline diagram or README, with confidential details removed | `[grounded]` background silent |
| G3 | Data contracts (R10, important) | discovery | GE tests are there; contracts with analysts aren't | It's a named part of the job, and it's the part closest to what the analysts see | dbt model contracts or enforced schemas; schema checks that blocked bad loads; written agreements with analysts on freshness or fields | A dbt contract config, a schema-change policy, or a freshness SLA document | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The posting is live and matches your copy | positive_signal | — | "Accepting applications." | The role is open now | `[grounded]` posting fetched | — | noted |
| RR2 | The company exists as described | positive_signal | — | "264 employees. Series C ($52M, February 2026)." | A funded, established employer, not a thin-footprint unknown | `[grounded]` About page via search | What are the data team's priorities after the Series C? | noted |
| RR3 | Pay is stated and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band runs from just below the report's median to just above the top of its middle half. Fair for a senior role at 6 years | `[grounded]` JD; `[generic]` Datawright band | Where in the band do you expect to place someone with 6 years? | noted |
| RR4 | No hiring manager named | unknown | — | Posting names no hiring manager | Who you'd report to and how big the team is are both unknown | `[grounded]` posting silent | Who does this role report to, and how many data engineers are on the team? | unresolved |
| RR5 | The mandate may be broader than the senior norm | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | This could be the whole reporting platform rather than one domain's pipelines | `[inferred]` from the three listed layers against the report's scope norm | Is this role the owner of the whole reporting pipeline, or one part of it alongside other engineers? | unresolved |
| RR6 | Equity terms unstated | unknown | — | "plus equity" | Its size and vesting can't be valued yet | `[grounded]` JD | What form does the equity take, and what's the vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open with what you built: "Built our dbt project on Snowflake, about 180 models; set up our Great Expectations test suite; Airflow orchestration." Don't call it "data contracts" unless Q3 confirms you did that | R4, R7, R8, R10 | `[grounded]` your own wording | pending your approval |
| A2 | Say plainly: "dbt on Snowflake; no production BigQuery yet." Optionally back it with a small dbt project on BigQuery (W1) | R6, G1 | `[grounded]` R6 | pending your approval |
| A3 | Ask the RR3 to RR6 questions as written, at the recruiter screen or first call | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A4 | Aim for the middle to upper part of the posted band, not above $166,000 | RR3 | `[grounded]` JD band; `[generic]` Datawright band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, matches your copy. Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching your copy. This checked your pasted material and fed RR1, RR2 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you pasted already sets the market calibration and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can produce a `tuesday-dossier.md` of this assessment to carry into later steps. Say the word if you want one.

**Upgrade menu**
- Your location, work authorization and pay floor: closes R1 and the conditions, so the status likely becomes `go` or `no_go`.
- Answers on G2 and G3: R9 and R10 move to `direct` or stay as named gaps, which changes what A1 leads with.
- An inspectable artifact (a dbt repo excerpt or a pipeline README with confidential details removed): raises R4 and R8 from `medium` to `high`.
- The hiring manager's name: sharpens the scope read and tells A1 which story to lead with.
- A deeper research pass on Pellucid Learning (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

Q1 (R1): Are you based in the US and authorized to work here, or able to work from the Denver office?

Q2 (R1, RR3): Do you have a base-pay floor, or any other non-negotiables like remote-only or equity expectations?

Q3 (G3, R10): Have you set up data contracts or enforced schemas that analysts or other teams relied on, such as dbt model contracts or checks that blocked bad loads? What part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.