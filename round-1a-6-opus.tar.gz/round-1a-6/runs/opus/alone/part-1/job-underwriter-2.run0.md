Quick status: I've read the evaluation framework, and next I'm checking whether Quartzline exists as described and what this role usually pays.
## Decision snapshot

**No, you're not wasting your time. But this is a stretch on the one requirement no rewording can fix: R1b, the 3+ years of PM experience the posting marks as must-have. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (PM-shaped work behind the 3+ years), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1b (3+ years titled PM experience)
- `important`: direct: R6 · adjacent: R7 (Write specs and drive delivery), R9 (Own the roadmap), R10 (Coordinate launches with sales and support) · unclear: R8 (Define and track adoption metrics)

R1b: you can't reword titled years, only route around them; R2: a real bridge with a named limit; R8: the memory lead worth confirming.

**Opportunity ledger.** I couldn't confirm the employer or the posting (RR1), and the pay isn't stated (RR2). The mandate has real resources behind it (RR3). Whether you'd inherit a platform or start one from nothing is still open (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the live posting check out (RR1); (2) your application reaches a person rather than relying on a cold keyword screen, because R1b is absent; (3) R2 and R9 are framed as adjacent work, never as API products you owned or a roadmap you held.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header only; not checked against the company's own site (see Evidence status) |
| Mandate | Own the roadmap for a partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| First-90-days outcomes | Likely a partner discovery round and a first roadmap, plus baseline adoption metrics | `[inferred]` from "own the roadmap" and "define and track adoption metrics"; the JD states no timeline |
| Scope read | A full PM seat with no associate or junior framing: two squads, external partners, cross-functional launches | `[inferred]` from the squad count and the responsibility list |
| Market calibration | Not established, because the role-family sweep didn't run | — |
| Compensation | Not stated in the posting | `[grounded]` JD silence |
| Unknowns | Pay; whether a PM already owns this platform; who decides partner commercial terms; how agile delivery is run | — |
| Contradictions | None between the JD and your background as given; the careers page wasn't checked | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | PM-shaped work behind "3+ years product management experience" | must_have | adjacent | medium | transferability | Seven years of requirements documents, scoping workshops, cross-team coordination and roadmap-input sessions. That is product-adjacent work, done from the delivery side rather than with product ownership. Self-reported and unprobed, so it caps at `medium` | `[grounded]` resume; `[inferred]` adjacency | See gap queue G5 |
| R1b | 3+ years titled PM experience | must_have | absent | none | capability | You stated you've never held a PM title. Not a gate under the rules (it is a length of experience), but no wording closes it. `[generic]` A titled-years line is often screened literally at application stage | `[grounded]` your statement; `[generic]` screening pattern | Closure path in G5; routing in A1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ client integrations of "our REST APIs" end to end. That is deep experience with an API product from the integration side. Limit: nothing yet shows you owned what the API was or shipped changes to it | `[grounded]` resume | G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | "Comfortable in Postman and SQL and reading OpenAPI specs", plus integration architecture across 30+ integrations. Specific, but nothing inspectable yet | `[grounded]` resume | Optional: a sanitized integration architecture doc would raise this |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | "Coordinated our engineers, the client's engineers, and product managers on custom builds" | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume doesn't mention sales | `[grounded]` resume silence | G3 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | The resume doesn't say how the builds were run (sprints, backlog, ceremonies) | `[grounded]` resume silence | G4 |
| R6 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and "quarterly roadmap-input sessions collecting client feedback for product" are customer discovery. The resume frames them as implementation work | `[grounded]` resume | Edit E1 |
| R7 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: these specs were for client builds, not a product backlog you prioritized | `[grounded]` resume | Work sample W1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent. A memory lead says you built an internal request-triage tool that support agents adopted; that is unconfirmed and isn't evidence | `[grounded]` resume silence; memory lead only | G2 |
| R9 | Own the platform roadmap | important | adjacent | medium | transferability | You fed client input into product's roadmap. Limit: you supplied input, you didn't own the decisions | `[grounded]` resume | Frame honestly; see A1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | 30+ go-lives are launches of a kind. Limit: client go-lives, not market launches with sales and support enablement | `[grounded]` resume | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform products (R2, must_have) | transferability | Deep integration work on the vendor's REST APIs; no sign that anything you scoped became part of the standard product | R2 is a must-have at `adjacent`. A productized build would be the strongest answer to R1b's absence | A custom endpoint or connector you specced that product later made standard; an API change requested from your client feedback that shipped; deprecation or versioning work you coordinated | A requirements doc (sanitized), a release note or changelog entry, the internal playbook | `[grounded]` resume; `[inferred]` that a productized build would move R2 |
| G2 | Adoption metrics (R8, important) | discovery | Only an unconfirmed memory lead about a triage tool | If confirmed, this is the one piece of product-builder evidence: something you built, with users and adoption | Building the triage tool; deciding who it was for; counting usage or time saved; iterating on support agents' feedback | Screenshots, a usage count, a short write-up | `[grounded]` resume silence; `[inferred]` from the memory lead, unconfirmed |
| G3 | Sales stakeholders and launches (R4b, R10) | discovery | The resume doesn't mention sales or support enablement | R4b is a must-have | Pre-sale technical scoping with account executives; handing over to support at go-live; a playbook section written for sales | Playbook excerpt, an enablement doc | `[grounded]` resume silence |
| G4 | Agile delivery (R5, must_have) | discovery | The delivery method isn't stated | A must-have that's cheap to close if true | Sprint planning with engineering on custom builds; writing tickets or acceptance criteria; UAT run inside sprints | A sanitized ticket or acceptance-criteria example | `[grounded]` resume silence |
| G5 | Titled PM years (R1b, must_have) | capability | None, confirmed by you | It can't be reworded. The closure paths: routing around the screen (A1), an internal PM move, or a "Technical PM" or "Solutions PM" title elsewhere | — | — | `[grounded]` your statement; `[generic]` that these titles are common bridge routes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | (the posting gives no figure) | The figure may sit below what a 3+-year PM seat usually pays, or the company may just not publish pay | `[inferred]` from the posting's silence | What pay range is budgeted for this role? | unresolved |
| RR3 | The mandate comes with resources | positive_signal | — | "drive delivery with two engineering squads" | Real delivery capacity sits behind the roadmap mandate | `[grounded]` JD | How are the two squads split across the platform today? | noted |
| RR4 | Inherited platform or first PM on it | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may be the first product owner of a platform engineering has run so far, which is a harder first PM seat | `[inferred]` from the ownership language against silence on a prior PM | Has a PM owned this platform before, and what roadmap exists today? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Change "Ran quarterly roadmap-input sessions collecting client feedback for product" to "Ran quarterly roadmap-input sessions with clients; collected their feedback for the product team" and put it under a discovery-focused heading | R6 | `[grounded]` your resume line; audited for scope, verb and kind: "for product" stays "for the product team", not "shaped the roadmap" | resume_edits_pending_approval |
| E2 | Lead the resume with "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live" and "Wrote the internal integration playbook the whole team uses", both kept verbatim | R2, R3, R7 | `[grounded]` your lines, unchanged | resume_edits_pending_approval |
| P1 | Position yourself as "a solutions engineer moving into platform product". Never use "Product Manager" as a past title, "owned the roadmap" or "shipped API products" | R1b, R2, R9 | `[grounded]` your statement that you've never held a PM title | pending your approval |
| A1 | Get a referral or write to the hiring manager instead of relying only on the application form | R1b | `[generic]` literal screening of titled years, not a fact about Quartzline | pending your approval |
| W1 | A one-page partner-API spec or teardown, built on Quartzline's public API docs if they exist | R7, R2 | `[inferred]` that a work sample narrows the spec-ownership limit | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3 and RR4 word for word | Register as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the request-triage tool from earlier memory, unconfirmed; it is the basis for G2 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics API platform careers Product Manager" was refused because web search permission isn't granted. It would have confirmed the organization row and the live posting, and could clear RR1 |
| 2. Role-family sweep | unavailable | The search "platform API product manager salary Series B B2B SaaS 2026" was refused for the same reason. It would have filled in market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | You didn't give a name, so there was nothing to search for |

I can save this as `tuesday-dossier.md` if you want to carry it into later sessions.

**Upgrade menu**
- **Allow web search, or send a link to the live posting or Quartzline's careers page:** confirms the organization row, could clear RR1, and adds a pay band for RR2.
- **Your non-negotiables (pay floor, location or remote, work authorization):** adds hard-gate rows and removes the "unknown" flag on the hard-gates line.
- **A sanitized requirements doc or playbook excerpt:** could raise R3, R6 and R7 above `medium`.
- **Evidence for the triage tool (screenshots, usage numbers):** could close G2 and give R8 a real product-builder story.
- **The hiring manager's name:** lets me tailor the scope read and the A1 outreach to that person.
- **A deeper research pass on Quartzline** (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

G1: Did any custom build, endpoint or integration pattern you scoped become part of the standard API product, and what part of that was yours?

G2: Did you build an internal request-triage tool that support agents adopted, and if so, who used it and how did you know it was working?

C1: What are your non-negotiables for a move: pay floor, location or remote, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.