Reading the skill's research and reframing rules next, then I'll run the company check and write the assessment.
**No, you're not wasting your time, but this is a stretch application. You'd be applying as someone moving into PM, not as a match for the posting. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (product-shaped work toward the 3+ years), R2 (shipped API or platform products) · unclear: R4b (stakeholder management with sales), R5 (agile delivery) · absent: R1b (3+ years titled PM experience)
- `important`: adjacent: R6 (discovery with integration partners), R7 (write specs, drive two squads), R10 (coordinate launches with sales and support) · unclear: R8 (own the roadmap), R9 (define and track adoption metrics)

R1b: the posting's first must-have, which wording can't fix; R1a, R2, R6, R7 and R10: real bridges, each with a named limit; R3 and R4a: already strong on your CV; R5, R8 and R9: open, and your questions below could move them.

**Opportunity ledger.** The mandate is concrete: two squads, partner-facing, adoption metrics (RR4). But I couldn't confirm the employer or the posting, because my searches were refused (RR1). Pay (RR2) and location or work arrangement (RR3) aren't stated.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Quartzline and the live posting verify (RR1).
  2. Every line you send presents R1a, R2, R6, R7 and R10 as adjacent work. None of it claims PM years or a PM title (R1b).
  3. Pay and location clear your own limits once you tell me them (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked, research refused (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform. Run discovery with integration partners, write specs, deliver with two engineering squads, track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A mid-level individual PM with one platform area and two squads, not a head of product | `[inferred]` from "two engineering squads" and "3+ years" against the company's stated size |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established, because the role-family sweep couldn't run. No band is given, since a figure from memory would be invented | — |
| Compensation | Not stated in the posting (RR2) | `[grounded]` JD silent |
| Unknowns | Pay; location and remote policy; who the role reports to; whether "3+ years product management" is screened on title or on substance | — |
| Contradictions | None inside the JD. Couldn't check against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: product-shaped work | must_have | adjacent | medium | transferability | 7 years of requirements documents, quarterly roadmap-input sessions for product, and coordinating with PMs on custom builds. That's work next to PM. Limit: none of it shows you deciding what the product builds | `[grounded]` your resume text | see G1 |
| R1b | 3+ years PM experience: the titled years | must_have | absent | none | capability | You said directly: "I have never held a PM title." This is a fact about your title, not a judgment of your skill. Only time in a PM role closes it | `[grounded]` your statement; `[generic]` that a must-have years line is often screened on title | carried as the main risk; see A1, A2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations, end to end. You stood on the integration side, not on the side that shipped the API. Closer than most PM switchers get, but a different relationship to the product | `[grounded]` your resume text | see G2 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, integration architecture. Stated clearly on the CV. Medium until something inspectable exists | `[grounded]` your resume text | none |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | Coordinated your engineers, the client's engineers and PMs, and led client workshops and UAT (user acceptance testing) | `[grounded]` your resume text | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The CV doesn't mention sales | `[grounded]` CV silence; `[generic]` that solutions roles often sit next to sales, which says nothing about yours | see G5 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The CV doesn't say how your engineering teams ran their work | `[grounded]` CV silence | see G3 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly sessions collecting client feedback for product. Limit: you gathered input and others decided | `[grounded]` your resume text | see G1 |
| R7 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents, integration architecture, and coordinating engineers on custom builds. Limit: work scoped per client, not a shared roadmap across standing squads | `[grounded]` your resume text | see G1 |
| R8 | Own the roadmap | important | unclear | low | discovery | The CV shows roadmap input, not roadmap ownership. Agent memory hints at an internal tool you built, which might show you prioritizing. Unconfirmed, so not evidence | `[grounded]` CV; memory lead, unconfirmed | see G4 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The playbook is used by "the whole team", which is adoption but no metric. The triage tool's adoption by support agents is a memory lead only | `[grounded]` your resume text; memory lead, unconfirmed | see G4 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | 30+ go-lives you ran. Limit: each was one client's go-live, not a product launch for the whole market | `[grounded]` your resume text | see G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM-shaped work in place of the titled years (R1a, R1b, R6, R7, R10) | transferability | **Carries over:** requirements, partner workshops, cross-team delivery, go-lives. **Limit:** others made the product calls. **Strengthener:** a work sample showing you making a product call | R1b can't be closed. R1a is your whole case, so it has to be concrete | A feature request from your roadmap sessions that product actually built; a custom build that became part of the standard product; a scoping decision you made that changed what got built | A sanitized requirements doc, playbook excerpt, or a roadmap-input summary | `[grounded]` resume text; `[generic]` that hiring managers weigh adjacent work against titled years |
| G2 | API product, integration side versus product side (R2) | transferability | You consumed and implemented the vendor's APIs. You didn't own their design | This is the gap between "knows APIs" and "shipped an API product" | Pushing for a change to an API endpoint or schema that shipped; writing the docs or examples partners used; finding a recurring integration failure that product then fixed | An API change request you wrote, docs you authored | `[grounded]` resume text |
| G3 | Agile delivery (R5) | discovery | The CV is silent | A must-have, and the answer is probably cheap to get | Working sprints with your engineers; writing tickets or user stories; sitting in sprint reviews or backlog grooming for custom builds | Jira tickets or epics you wrote, sanitized | `[grounded]` CV silence |
| G4 | Owned a product, prioritized it, tracked adoption (R8, R9) | discovery | Only a memory lead: an internal request-triage tool support agents adopted. Unconfirmed | If it's real and yours, it's your closest thing to PM evidence: something you built, people chose to use it, and you decided what went into it | Deciding what the tool did first; changing it based on agent feedback; counting how many agents used it or how volume changed | Screenshots, usage numbers, a launch note to the support team | `[grounded]` memory lead, unconfirmed |
| G5 | Working with sales (R4b) | discovery | The CV is silent | A must-have line; probably easy to resolve | Supporting deals before signing; scoping for sales handoffs; sales-to-implementation handoff process | A handoff template or a scoping doc for sales | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (searches refused) | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too small or new to have much public footprint, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. These are possibilities side by side, none ranked as likely | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (posting silent) | The figure may or may not meet your floor. Your floor isn't given either | `[grounded]` JD silent | What's the budgeted salary range and equity for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | (posting silent) | Could be remote, hybrid or on-site | `[grounded]` JD silent | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Concrete mandate and resources | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | Real teams and a measure of success are named, not responsibility with no resources | `[grounded]` JD | Which adoption metrics matter most today, and what do they show? | noted |
| RR5 | Years requirement may be screened on title | unknown | — | "3+ years product management experience (must-have)" | A recruiter screen could filter on the title before anyone reads your substance | `[generic]` pattern for must-have years lines | Would a solutions engineer with 7 years of API integration work and no PM title be considered for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open the CV summary with your own words: "7 years as a solutions engineer / implementation lead … Led 30+ client integrations of our REST APIs end to end." Don't call yourself a product manager anywhere | R2, R3; R1b can't be worded around | `[grounded]` your resume text | resume_edits_pending_approval |
| E2 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses" up into the top three bullets, with their scope exactly as written | R1a, R6, R9 | `[grounded]` your resume text | resume_edits_pending_approval |
| W1 | A one-page sample spec for a partner-API improvement, drawn from integration pain points you've seen, with nothing confidential | Gives R1a, R2 and R7 something inspectable | `[grounded]` R1a, R2, R7 rows | pending your approval |
| A1 | Look for a warm referral into Quartzline before applying cold | A referral is the most likely way past a screen that filters on title | `[generic]` hiring pattern, not a fact about this employer | pending your approval |
| A2 | In the cover note, say plainly that you've never held a PM title, then point to R1a and R2 | Saying it first beats being found out at the screen | `[generic]` hiring pattern | pending your approval |
| Q1 | Ask the RR1–RR5 verification questions word for word at the screen | Settles pay, location, the employer, and how the years line is read | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the internal request-triage tool adopted by support agents, from agent memory. It's the basis for G4's question and nothing more.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform careers"; the search permission was refused. It would have confirmed Quartzline exists as described and that the posting is live (RR1), and filled the contradictions row |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs salary scope Series B B2B SaaS 2026"; refused. It would have given the market calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name given, so there was nothing to search for |

I can save all of this as a `tuesday-dossier.md` file to carry into later steps, if you'd like.

**Upgrade menu**
- **Allow web search:** runs targets 1 and 2. It could clear RR1, which would lift the cap on a full `go`, and adds a pay band to compare with RR2.
- **A deeper research pass on Quartzline** (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.
- **Your answer on G4, with screenshots or usage numbers:** R8 and R9 could move to `adjacent` or better, and W1 gets a real story behind it.
- **A sanitized requirements doc or playbook excerpt:** R1a, R6 and R7 could move from `medium` to `high`.
- **Your pay floor and location limits:** RR2 and RR3 get checked against your actual limits.
- **The hiring manager's name:** tells you which of your stories to lead with for that reader.

**Questions**

G4: Did you build an internal request-triage tool that support agents adopted? If so, what did you decide about what it did, how many people used it, and did you track that?

G3: Did your engineering teams work in sprints, and did you write tickets or user stories or join their planning?

Constraints: What's your pay floor, and do you need remote, hybrid or a particular location?

For any of these, answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.