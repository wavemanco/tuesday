Yes, it's worth applying, on the three conditions below. **Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7
- `important`: adjacent: R5b (BigQuery as the warehouse) · unclear: R8 (Ingestion from our app and CRM), R9 (Data contracts our analysts depend on)

R5b: a credible move from Snowflake to BigQuery, with its limit stated; R8, R9: your background doesn't mention them yet, so one question each; R2–R7: everything you stated, at `medium` until there's something to inspect.

**Opportunity ledger.** The role looks sound on what you pasted. The pay is stated and sits at or above the report's band (RR2), and the about page reports a recent Series C (RR6). Three things are open: I couldn't check the posting is live (RR1), the team size and scope aren't stated (RR3), and nobody is named as the hiring manager (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); you haven't told me your constraints, so I couldn't check the role against them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Pellucid's own careers page (RR1); (2) you can work remote from the US or from Denver (R1); (3) you present BigQuery honestly as new to you, with Snowflake as the basis (R5b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page as you pasted it; not checked live |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years of data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity (equity terms not stated) | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | Reporting pipelines end to end. This could be one domain, which is normal for the title, or the whole data platform. It depends on team size, which isn't stated (RR3) | `[inferred]` from the JD's list of responsibilities and its silence on team |
| Market calibration | Senior data engineers at Series B–D companies: base median $151,000, middle half $139,000–$163,500, typically 5–8 years of experience, owning one domain with no direct reports. The posting's floor is above the middle-half low, its top is above the middle-half high, and its 5+ years matches. This is the market band, not Pellucid's offer to you | `[generic]` Datawright 2026 report (US, n=2,310) as you pasted it; `[grounded]` JD for the posting's figures |
| Unknowns | Team size and reporting line; hiring manager; equity terms; whether the "data contracts" already exist or you'd create them | — |
| Contradictions | None between the JD and the about page as pasted. Not checked against the live site (RR1) | `[grounded]` both pastes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | Your background doesn't say where you're based | `[grounded]` JD; your background is silent | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated "6 years of data engineering". This is self-report with nothing inspected yet, so `medium` is the most a first pass allows | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated "Python and SQL daily" | `[grounded]` your background | Upgrade menu: a repo or code sample |
| R4 | dbt | must_have | direct | medium | none | You stated "Built our dbt project… about 180 models": specific, and it was yours | `[grounded]` your background | Upgrade menu: a sanitized dbt docs page or lineage graph |
| R5a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement is worded generically | `[grounded]` JD wording and your background | none |
| R5b | BigQuery as the warehouse | important | adjacent | medium | transferability | Your dbt-on-Snowflake modelling carries over. The limit: you have no hands-on BigQuery work, and its cost model, partitioning/clustering and IAM differ from Snowflake's | `[grounded]` you said "Never used BigQuery"; `[inferred]` that BigQuery is the working stack, from "a dbt-modelled warehouse in BigQuery"; `[generic]` that those areas are where the two warehouses differ | See G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated "Airflow for orchestration" | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You stated "I set up our Great Expectations test suite", and the setup was yours | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | important | unclear | low | discovery | It's a stated responsibility and your background doesn't cover ingestion sources | `[grounded]` JD; your background is silent | G2 |
| R9 | Data contracts our analysts depend on | important | unclear | low | discovery | It's a stated responsibility and your background doesn't mention contracts or analyst-facing interfaces | `[grounded]` JD; your background is silent | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5b, important) | transferability | Strong dbt and Snowflake evidence, no BigQuery | It's the working stack, so it's the gap most likely to be probed | Any Snowflake cost or warehouse-sizing work; dbt adapter-specific config; a small BigQuery sandbox build with dbt (free tier) | A public repo running the dbt project against BigQuery | `[grounded]` your background; `[generic]` that a stack mismatch draws questions |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Your background starts at dbt and doesn't say where the data came from | It's a core part of the mandate | Loading payroll app databases (CDC, Fivetran/Airbyte, custom Python extractors); pulling from Salesforce/HubSpot or a billing system's API; Airflow DAGs that land raw data | A DAG or extractor sample, an architecture diagram | `[grounded]` JD and your background |
| G3 | Data contracts (R9, important) | discovery | Your Great Expectations suite suggests analyst-facing quality guarantees, but you didn't describe it that way | Contracts are named as something analysts depend on | Agreeing schemas or SLAs with analysts; dbt model contracts or exposures; tests that block a broken model before it reaches dashboards | A contract YAML, an SLA doc, a test-failure runbook | `[grounded]` JD; `[inferred]` the link from the Great Expectations work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (the search was declined, so the pasted pages weren't checked live) | risk_signal | medium | "Senior Data Engineer — Pellucid Learning" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated, and at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The pay is transparent and competitive for the title | `[grounded]` JD; `[generic]` band from the pasted report | How is the offer placed within the $148k–$166k range? | noted |
| RR3 | Breadth of the mandate, with no team stated | unknown | — | "Build and run the pipelines… ingestion… a dbt-modelled warehouse… and the data contracts" | This may be one domain, as is typical, or the whole platform with you as the only data engineer | `[inferred]` from the JD's scope against its silence on team; `[generic]` the one-domain norm from the report | How many data engineers are on the team, and which pipelines would this role own alone? | unresolved |
| RR4 | No hiring manager named | unknown | — | the posting names no hiring manager | The reporting line (data lead, analytics, engineering) is unknown, and it shapes scope | `[inferred]` from the posting's silence | Who does this role report to, and where does the data team sit? | unresolved |
| RR5 | Equity terms not stated | unknown | — | "plus equity" | Equity at Series C varies widely in form and value | `[generic]` role-family pattern | What form does the equity take (options or RSUs), how much, and on what vesting schedule? | unresolved |
| RR6 | Recent Series C | positive_signal | — | "Series C ($52M, February 2026)" | Funding raised about nine months ago suggests runway for the data function | `[inferred]` from the pasted about page, not checked | What is the data team expected to deliver in the next 12 months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own words: "Built our dbt project on Snowflake — about 180 models", Airflow for orchestration, and "set up our Great Expectations test suite" | Covers R4, R5a, R6 and R7 with no reframing needed | `[grounded]` your background | pending your approval |
| P2 | Name BigQuery plainly as new to you, e.g. "Snowflake in production; BigQuery not yet used" | R5b: stating the limit yourself holds up better than having it found | `[grounded]` you said "Never used BigQuery" | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery repo before applying | Moves R5b's limit and gives R3/R4 something inspectable | `[grounded]` R5b and G1 | pending your approval |
| A1 | Confirm the posting on pellucidlearning.com's own careers page before you put effort in | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions for RR3, RR4 and RR5 in the recruiter screen | Settles scope and equity before the main interviews | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Pellucid Learning senior data engineer careers" was refused permission, so the pasted JD and about page weren't checked live. It would have cleared or confirmed RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you pasted already settles the market calibration line and the pay comparison (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

---

I can save all of this as a `tuesday-dossier.md` file you can keep or carry into later steps, whenever you want it.

**Upgrade menu**

- **Allow web search, or send the live posting's link:** target 1 runs, which clears or confirms RR1 and may lift the cap on `go`.
- **Your location and any non-negotiables (pay floor, schedule):** R1 resolves, and I can check the role against your constraints.
- **A repo, a sanitized dbt docs page or a lineage graph:** R3/R4 can rise to `high`.
- **The hiring manager's name:** target 3 runs, which informs the scope read and which story to lead with.
- **A deeper research pass on Pellucid** (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R1: Are you based in the US, able to work remote or from Denver, and is there any term (pay floor, location, schedule) you won't trade?

G2 / G3: Where did the data in your Snowflake warehouse come from, and did you build any of that ingestion? Separately, did you agree schemas, tests or SLAs with analysts? Which parts were yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.