Reading the last two reference files, then I'll run the company research.
Now the L1 research: company, role-family band, and the hiring manager's public footprint.
Yes, go for it. The one thing to sort out first is where you'd work: the JD says "fully remote (UK)", but Brindlemoor's own careers page says Leeds four days a week.

## Decision snapshot

**Yes, apply, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based and eligible to work in the UK), R2 (Working pattern: fully remote versus Leeds four days a week)
- `must_have`: direct: R3, R4, R5, R6a, R7, R8 · unclear: R6b (Monitor rating models)
- `important`: unclear: R9 (Recommendations for product teams)
- `preferred`: direct: R10 · adjacent: R11 (Pet-insurance pricing)

R11: you've never done pet insurance, but motor pricing is close enough to argue from, as long as you say what it doesn't cover; R6b: the model monitoring is the HM's (hiring manager's) public topic, and your CV doesn't show it yet; R9: none of your evidence shows recommendations to product teams yet.

**Opportunity ledger.** The posting is live on Brindlemoor's own careers page and reports to the Director of Pricing, as the JD says (RR4). But the careers page and the JD disagree on where you'd work (RR1). Pay isn't stated (RR2). And how many people sit behind "own pricing analytics" isn't stated either (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based and eligible to work in the UK), R2 (Working pattern: fully remote versus Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 settles on a working pattern you can accept (R2); (2) the pay meets your floor (RR2); (3) you present the pet-insurance gap honestly as adjacent motor experience, never as pet experience (R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched. Its stage and size aren't established: a search for the company name alone returned nothing |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` JD and careers page agree |
| Line management | Neither the JD nor the careers page mentions any direct reports. Your "never managed anyone" isn't a requirement here | `[grounded]` JD and careers page silent |
| Scope read | A senior individual-contributor post that runs the whole pricing cycle on one product line | `[inferred]` from the mandate's verbs and the absence of any reports |
| Hiring manager | Director of Pricing; spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile snippet |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median base £58,400, middle half £52,100–£64,900 (n=612). The sweep gave a pay band but no norm for scope. The posting gives no figure, so this is what to expect, not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 survey, search snippet; `[grounded]` JD, for the missing figure |
| Unknowns | Pay; team size; which working pattern is current; whether the product side has its own analysts | — |
| Contradictions | The JD says "Fully remote (UK)"; the careers page says "Leeds office four days a week" | `[grounded]` JD versus careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based and eligible to work in the UK, implied by "Fully remote (UK)" | hard_gate | unclear | none | hard_gate | You haven't said where you live or what your right-to-work status is. You work at a UK insurer, which points to yes but doesn't settle it | `[inferred]` gate read from "(UK)"; `[grounded]` your background is silent on it | Confirm it yourself; a one-word answer closes it |
| R2 | Working pattern: "Fully remote (UK)" in the JD, "Leeds office four days a week" on the careers page | hard_gate | unclear | none | hard_gate | The employer's two sources conflict, and you haven't said whether the Leeds pattern would work for you | `[grounded]` JD and careers page | Closing question 1; RR1's question to the employer |
| R3 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. Specific, but nothing inspectable yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Expect a technical probe | `[grounded]` your background | none |
| R5 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for your young-driver book. Your scope was that book, not the whole motor portfolio | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM: you built it | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may cover monitoring (actual-versus-expected checks, drift, recalibration triggers), but you haven't said so. The HM has spoken publicly on this exact topic | `[grounded]` your background is silent on monitoring; `[grounded]` the HM's talk | G1; closing question 3 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" doesn't say how much of the test design was yours. Keep the claim at "ran" until you confirm the design part | `[grounded]` your background | Keep "ran" wherever this claim is used |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Recommendations for product teams (the product half of "underwriting and product") | important | unclear | none | discovery | Your evidence covers underwriting; nothing mentions product teams | `[grounded]` your background is silent on product | G2 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R11 | Pet-insurance pricing | preferred | adjacent | medium | transferability | The methods carry over: GLM rating, price tests, the underwriting relationship. Limit: pet risk factors and product features are different, and none of your stated work touches them | `[inferred]` requirement read from "our pet-insurance product" (the JD doesn't require it); `[generic]` that pet pricing turns on factors such as breed, pet age, vet-cost inflation and cover type | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | You built and maintained the young-driver GLM; you didn't say how you tracked whether it was still performing | A `must_have` row, and the HM's public topic, so it's your strongest possible lead story for this reader | Actual-versus-expected reports on the young-driver book; spotting drift or a segment going wrong and recalibrating; monitoring done for the quarterly review | A sanitized monitoring pack, an actual-versus-expected chart, or recalibration notes | `[grounded]` your background is silent; `[grounded]` the HM's talk topic |
| G2 | Recommendations for product teams (R9, important) | discovery | Your recommendations go to underwriting; there's no sign of product or proposition teams | Product is half of the JD's recommendation line | A price test that changed a cover option, an excess or a discount; work with a product or marketing team on a launch | A sanitized test readout or a recommendation paper | `[grounded]` JD's "underwriting and product"; your background is silent |
| G3 | Pet-insurance pricing (R11, preferred) | transferability | Motor pricing only, which you've said yourself | It's the gap a screener sees first | Young-driver pricing as a thin-data, high-variance segment, if that's true of your book; any work where claims inflation moved your rates | A short write-up of what you'd look at first in a pet book | `[inferred]` bridge from your motor work; `[generic]` that this objection comes first |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The JD and the careers page give conflicting working patterns (R2) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source is out of date, or the pattern changed after the JD was written | `[grounded]` both sources quoted; `[inferred]` why they differ | Is this role fully remote, or based in Leeds four days a week, and could that change? | unresolved |
| RR2 | Pay isn't stated | unknown | — | (neither the JD nor the careers page gives a figure) | The budget could sit anywhere around the £52–65k middle band, or the company may just not publish pay | `[inferred]` from the missing figure, set against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Team behind "own pricing analytics" isn't stated | unknown | — | "Own pricing analytics for our pet-insurance product" | You could be the only pricing analyst, covering the whole product end to end | `[inferred]` from "own" and no mention of a team | How many people work in pricing, and what does this role own versus share? | unresolved |
| RR4 | Posting is live on the company's own site, and its reporting line matches the JD | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The posting comes from the employer, not an aggregator | `[grounded]` careers page fetched | What would success look like in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle RR1 with the employer before you put serious effort into the application | see R2, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the young-driver GLM, in your own words: "built and maintained the GLM rating model for our young-driver book". If G1 confirms monitoring work, put that story first for this reader | see R5, R6a, R6b, and the HM's talk topic | `[grounded]` your background; HM's talk | pending your approval |
| P2 | Describe the testing as "ran 14 price tests last year with the underwriting team". Don't write "designed" until you've confirmed the design was yours | see R7 | `[grounded]` your background | pending your approval |
| P3 | Name the pet gap yourself in your note, along these lines: "I haven't priced pet insurance; my rating-model and price-test work is in motor." | see R11 | `[grounded]` your own statement | pending your approval |
| Q1 | Ask the verification questions for RR1, RR2 and RR3 word for word in your first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" (no results) and "Brindlemoor insurtech careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It moved role reality's contradictions row, RR1 and RR4. Company stage and size not established |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from the snippet. It gave the market calibration pay band; no norm for scope |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from the snippet. It moved role reality's hiring-manager row, G1 and P1 |

If you'd like, I can save all of this as a `tuesday-dossier.md` file you can keep or bring back later.

## Upgrade menu

- **Whether you can work from Leeds four days a week, and the employer's answer to RR1:** settles R2 and RR1, and it's the condition most likely to change the decision.
- **Your pay floor:** turns RR2 into a pass or a fail against the £52–65k band.
- **Where you live and your right to work:** settles R1.
- **Sanitized pricing material:** a GLM monitoring pack, a price-test readout, or quarterly review slides. These would let R5, R6a, R7 and R8 move up to `high`.
- **Answers to G2 or G3:** firms up R9 and strengthens the R11 bridge.
- **A deeper research pass on Brindlemoor:** funding, leadership changes, hiring patterns, staff reviews and recent news, using up to 5 more searches and 2 more fetches. Say the word and I'll run it.

## Questions

**R2 / RR1:** Would Leeds four days a week work for you, or does this only work if the role is fully remote?

**RR2:** What's the lowest base salary you'd accept for a move?

**G1:** On the young-driver GLM, how did you check it was still performing once it was live? For example, actual-versus-expected tracking, drift checks, or deciding when to recalibrate. Which parts of that were yours?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.