I've read the skill's rules; now running one quick check that the Pellucid posting is live, then writing the assessment.
## Decision snapshot

**Yes, it's worth applying, provided the location condition below holds. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or our Denver office)
- `must_have`: direct: R1, R2, R3, R4a, R5, R6
- `important`: adjacent: R4b (a dbt-modelled warehouse in BigQuery) · unclear: R7 (ingestion from our app and CRM), R8 (the data contracts our analysts depend on)

R4b: a real bridge from Snowflake, with its limit stated; R7, R8: your background doesn't mention them yet.

**Opportunity ledger.** The role looks sound and open about its terms. The posting is live and matches what you pasted (RR5), and pay is stated and set against the market band (RR1). Still unknown: the equity terms (RR2), who you'd report to (RR3) and what "run the pipelines" means for on-call (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R9: you live in the US and can work here, or you'd work from Denver; (2) R4b: you present BigQuery as a move from Snowflake, never as experience you have (G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` pasted /about page |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar" | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | You'd own one area's pipelines (reporting) end to end. The JD mentions no direct reports | `[inferred]` from the JD's mandate, and from its silence on managing anyone |
| Market calibration | At Series B–D companies, "Senior" usually means 5–8 years and owning one area's pipelines with no reports, so this JD's 5+ years and scope fit the norm. Base pay median is $151,000, with the middle half of salaries between $139,000 and $163,500. The posting's $148k–$166k starts just under the median and ends above the top of that middle range, with a midpoint of $157k. That band is what the market pays, not a promise of Pellucid's offer | `[generic]` Datawright 2026 report (n=2,310), from your recruiter; `[grounded]` JD figures |
| Unknowns | Hiring manager and team size; equity form and size; on-call load; whether the posted range is base salary | — |
| Contradictions | None. The live careers page matches the pasted JD | `[grounded]` search result for the careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, which is above the floor. You stated it but there's no CV to check, so it can't go higher than `medium` yet | `[grounded]` your intake message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily." Specific and in your words, but nothing to inspect yet | `[grounded]` intake | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. That's ownership, not just using it | `[grounded]` intake | a sanitized model DAG or project README would raise this to `high` |
| R4a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement names none in particular | `[grounded]` JD wording, intake | none |
| R4b | BigQuery as the warehouse | important | adjacent | medium | transferability | "Never used BigQuery." What carries over: dbt modelling and warehouse SQL. The limit: no hands-on BigQuery cost model, partitioning/clustering or BigQuery SQL dialect. It's tiered `important`, not `must_have`, because the requirements list only "a cloud warehouse" | `[grounded]` intake and JD; `[generic]` that what transfers is the dbt layer and what doesn't is the platform specifics | see G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" | `[grounded]` intake | none |
| R6 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite." Ownership is stated | `[grounded]` intake | a suite config or a test-coverage summary would raise this to `high` |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | The JD lists it as a responsibility; your background doesn't mention ingestion sources | `[grounded]` background silent on it | see G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | The JD lists it as a responsibility; your background doesn't mention contracts or analyst-facing interfaces. The GE suite may be part of the story | `[grounded]` background silent; `[inferred]` that GE work may be related | see G3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US, so the gate isn't established yet | `[grounded]` JD; intake silent | ask: question 1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4b, important) | transferability | Deep dbt and Snowflake work; no BigQuery | The JD names BigQuery, so expect a probe on what you'd need to learn | Snowflake cost or warehouse tuning you did; dbt adapter-agnostic patterns you wrote; any time you ran dbt on a second adapter | A small public dbt-on-BigQuery project (W1) | `[grounded]` intake; `[generic]` that a named-stack gap draws an interview probe |
| G2 | App and CRM ingestion (R7, important) | discovery | Not mentioned | It's one of the JD's three named responsibilities | Pulling payroll-app event or database data into Snowflake; CRM syncs (Salesforce, HubSpot) through Fivetran/Airbyte or custom Python loaders; CDC from a product database | A pipeline diagram or a sanitized DAG | `[grounded]` JD and intake silence |
| G3 | Data contracts (R8, important) | discovery | Not mentioned. The GE suite is nearby | Another named responsibility | Schema or freshness agreements with analysts; GE expectations used as an interface promise; dbt model contracts, exposures or versioned models | A contract doc, a dbt `contract:` config, a GE expectation suite | `[grounded]` JD; `[inferred]` that GE work may overlap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay is stated and sits around the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | No sign of a seniority-pay mismatch. The midpoint is above the report's median | `[grounded]` JD figures; `[generic]` report band | Is the range base salary, and where in it do 6 years usually land? | noted |
| RR2 | Equity is unspecified | unknown | — | "plus equity" | Could be options or RSUs, and any size | `[inferred]` from the JD's silence on terms | What form is the equity, how much, and on what vesting schedule? | unresolved |
| RR3 | No hiring manager or team named | unknown | — | (posting names no hiring manager) | The reporting line and the data team's size are unknown | `[grounded]` posting silent | Who would I report to, and how big is the data team? | unresolved |
| RR4 | "Build and run" may include on-call | unknown | — | "Build and run the pipelines" | Running reporting pipelines may come with an on-call rotation | `[inferred]` from "run" in the mandate | What does on-call look like for this role? | unresolved |
| RR5 | The posting is live, and the company facts are concrete and recent | positive_signal | — | "Series C ($52M, February 2026)" | The employer exists as described and is hiring for this role now | `[grounded]` careers-page search result; pasted /about page | What does the data roadmap for the next year look like after the Series C? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your own lines: "Built our dbt project on Snowflake, about 180 models"; "set up our Great Expectations test suite"; "Airflow for orchestration" | R3, R5, R6 | `[grounded]` your intake wording, unchanged | pending your approval |
| E2 | State BigQuery plainly: dbt and Snowflake experience, no BigQuery yet. Don't list BigQuery as a skill | R4b | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery project on a public dataset, linked from your application | Narrows R4b's limit | `[generic]` a work sample is a common way to close a named-stack gap | pending your approval |
| Q1 | Ask the questions from RR1–RR4 word for word on the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | A quick check of the pasted JD: searched "Pellucid Learning senior data engineer careers". It returned "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), marked accepting applications, with text matching your paste. That fills RR5 and the contradictions row, and no failed-attribution entry is needed |
| 2. Role-family sweep | skipped | The Datawright report you pasted already gives the market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

If you'd like, I can save all of this as a `tuesday-dossier.md` file you can reuse later.

**Upgrade menu**
- Where you're based and whether you can work in the US → R9 resolves, and the status goes to `go` or `no_go`.
- Your pay floor → checked against the $148k–$166k range.
- Answers to G2 and G3 → R7 and R8 move off `unclear`.
- A sanitized DAG, project README or GE suite config → R3 and R6 rise to `high`.
- The hiring manager's name → a sharper scope read and a better choice of which story to lead with.
- A deeper research pass on Pellucid (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R9: Where are you based, and can you work in the US without sponsorship? Or would you work from the Denver office?

Pay floor: Is there a base salary below which you wouldn't move?

G2: Have you built ingestion from a product app or a CRM into Snowflake? What were the sources, how did you load them, and which part did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.