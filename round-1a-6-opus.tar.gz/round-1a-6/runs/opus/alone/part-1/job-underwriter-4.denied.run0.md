I'm running a short check on Brindlemoor and the market for this role, then I'll write up the assessment.
**Yes, apply, but check two things first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R7a · adjacent: R9 (Pricing the pet-insurance product) · unclear: R7b (Designing price tests), R8 (Recommendations to product)
- `preferred`: direct: R10

R9: a believable bridge from motor pricing, with its limit stated; R7b and R8: not yet shown by what you've told me; R6 and R7a: your strongest rows for leading the application.

**Opportunity ledger.** The role reads as a clear, realistic mandate (RR4). Two things are unresolved: whether Brindlemoor is established at all, because my searches were refused (RR1), and the salary, which isn't stated (RR2). The size of the pricing team is also unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting check out on its own careers site (RR1); (2) you're UK-based with UK right to work (R1); (3) you present pet insurance as a new line where your pricing methods carry over, never as experience you have (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Not checked, because research didn't run | `[grounded]` JD header only |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to / reader | Odile Varga, Director of Pricing | `[grounded]` your message |
| Line management | None stated. The JD lists no people management | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior individual-contributor pricing role for one product line. Its requirements (4+ years, GLMs, SQL/Python, presenting to underwriting) hang together and fit the title | `[inferred]` from the JD's requirements against its title |
| Market calibration | Not calibrated. The role-family sweep didn't run, so there's no salary or scope band | — |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Salary; team size and whether there's actuarial support; how mature the existing pet rating model is; who owns pricing decisions | — |
| Contradictions | None in the JD. It couldn't be checked against the careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): UK-based with UK right to work | hard_gate | unclear | low | hard_gate | A UK employer suggests a UK base, but you haven't said where you live or what your right-to-work status is. Candidate constraints weren't given | `[inferred]` from the UK employer; `[grounded]` JD | Closing question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. Specific, from your own account, nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Use is stated, depth isn't shown | `[grounded]` your background; `[generic]` that pricing teams often test this with a technical exercise | none |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Build and monitor rating models | important | direct | medium | none | Built and maintained a production rating model for one book | `[grounded]` your background | none |
| R7a | Run and read price tests | important | direct | medium | none | "Ran 14 price tests last year with the underwriting team" | `[grounded]` your background | none |
| R7b | Design price tests | important | unclear | low | discovery | "Ran" doesn't say whether you set the test design (cells, sample size, success metric) or someone else did | `[grounded]` the wording of your background | G2 |
| R8 | Recommendations to product, not only underwriting | important | unclear | low | discovery | Your underwriting audience is clear. Product, pricing-engine or digital-journey stakeholders aren't mentioned | `[grounded]` silence in your background | G3 |
| R9 | Pricing the pet-insurance product | important | adjacent | medium | transferability | You stated you have never worked on pet insurance. GLM rating, price testing and underwriting sign-off are the same craft in a different line | `[inferred]` requirement, from "our pet-insurance product"; `[generic]` that pet pricing differs from motor in rating factors and claims drivers | G1 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | **Carries over:** GLM build and maintenance, price testing, presenting to underwriting. **Limit:** no exposure to pet claims, rating factors or policy structures. **Strengthener:** a short, honest note on how you'd approach a pet rating model | The obvious objection to a motor candidate; handling it openly beats being asked about it | Any work on a non-motor line; claims-inflation or frequency/severity modelling; a new rating factor you introduced to the young-driver model | A one-page approach note (see W1) | `[grounded]` your stated absence of pet experience; `[generic]` that domain switch is the likeliest objection |
| G2 | Designing price tests (R7b, important) | discovery | 14 tests run with underwriting; your role in designing them isn't stated | The JD says "design and read". Which one you did decides how you can describe it | Choosing test cells or price points; setting sample size or run length; defining the success metric (conversion, loss ratio, margin); calling a test early | A sanitized test plan or readout | `[grounded]` the wording "ran" |
| G3 | Product stakeholders (R8, important) | discovery | Underwriting audience shown; no product audience | The JD names product as a second audience for recommendations | Working with a product owner on a pricing change; feeding a quote-journey or rating-engine change; aggregator or pricing-platform teams | A recommendation paper or deck (sanitized) | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to show up much online, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. My searches were refused, so this is unchecked rather than suspicious | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (no salary in the JD) | The figure may sit below a senior band, or the company may just not publish salaries. No band to compare against, because the sweep didn't run | `[inferred]` from the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Size of the pricing team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" could mean leading a mature model or being the only pricing analyst on the product | `[inferred]` from "own" against the JD's silence on team | Who else works on pet pricing, and is there actuarial support? | unresolved |
| RR4 | Clear, coherent mandate and requirements | positive_signal | — | "build and monitor rating models, design and read price tests" | The role is concrete and its requirements fit the title | `[grounded]` JD | How mature is the current pet rating model? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with: "Built and maintained the GLM rating model for our young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting." Your words, unchanged. Don't upgrade "ran" to "designed" until G2 is answered | R4, R6, R7a, R5 | `[grounded]` your background | pending your approval |
| P2 | Say directly: "I haven't priced pet insurance; the modelling, testing and underwriting work carries over, and here's how I'd approach it" | R9, G1 | `[grounded]` your stated absence | pending your approval |
| W1 | Optional one-page note on how you'd approach a pet rating model, framed as questions and an approach, not as experience | R9 | `[generic]` that a short work sample narrows a domain-switch objection | pending your approval |
| A1 | Before applying, find the role on Brindlemoor's own careers page | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3 and RR4 word for word | Interview prep | `[grounded]` register | pending your approval |
| N1 | Don't apologise for never managing anyone. The JD asks for none | Role reality, line management | `[grounded]` JD | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech"; the call was refused. It would have tested RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK insurance salary 2026"; the call was refused. It would have set the market band in role reality and the comparison for RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have shaped the scope read and which story P1 leads with |

I can save all of this as a `tuesday-dossier.md` to take into later steps if you'd like.

**Upgrade menu**
- **Allow web search, or paste the live posting link:** RR1 checked, a salary band in role reality, and Odile Varga's public profile to shape P1.
- **The budgeted salary or your floor:** RR2 closes and becomes a hard-gate check.
- **A sanitized price-test readout, model documentation, or quarterly-review slides:** raises R4, R6 and R7a toward `high`.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, hiring pattern, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R1: Are you UK-based with UK right to work, and do you have any non-negotiables, such as a salary floor?

G2: For those 14 price tests, which parts of the design were yours (cells, price points, sample size, success metric), and which did underwriting set?

G3: Have you ever taken a pricing recommendation to a product owner or a rating-engine or quote-journey team, rather than to underwriting? What was it, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.