I'm working through the skill's references; next is a quick check on Quartzline and the PM market, then the assessment.
# Quartzline — Product Manager, Platform APIs: underwriting for Nadia

## Decision snapshot

**No, applying isn't a waste of your time, but it is a reach. One must-have, R1a (3+ years of PM experience under that title), can't be closed by how you word things. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1b (Work equivalent to PM experience), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Experience with agile delivery) · absent: R1a (3+ years titled PM experience)
- `important`: direct: R6 · adjacent: R7 (Write specs and drive delivery with two squads), R8 (Own the roadmap), R10 (Coordinate launches with sales and support) · unclear: R9 (Define and track adoption metrics)

What matters: R1a is the title screen, and wording can't get past it; R1b, R2, R7, R8 and R10 are credible bridges, and each one's limit is named in its row; R4b, R5 and R9 are open, and one answer each could move them.

**Opportunity ledger.** The role is defined, not vague: it states its resources (two squads) and its own success measure (adoption) (RR4). But I couldn't confirm that Quartzline exists as described, because my searches were refused (RR1). Pay and location aren't stated (RR2, RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting checks out as live on Quartzline's own careers page (RR1); (2) you reach a person who can weigh R1b rather than relying on a cold screen of R1a (plan rows A1 and W1); (3) the R5 answer is something concrete, not "never".

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently confirmed (RR1) |
| Mandate | Own the roadmap for a partner-facing API platform; run discovery with integration partners; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A full-scope PM role: you'd own a roadmap with two squads, not assist a senior PM | `[inferred]` from "own the roadmap" plus "two engineering squads" |
| First-year outcomes | None stated | `[grounded]` JD is silent |
| Market calibration | Not established. The role-family sweep couldn't run (see Evidence status) | — |
| Unknowns | Pay; location or remote; reporting line; hiring manager; which agile practice the squads use | — |
| Contradictions | None inside the JD; not checked against the careers page | `[grounded]` JD read in full |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled years | must_have | absent | none | capability | You state you have never held a PM title. Requirements like this are often screened literally before a person reads further | `[grounded]` your own statement; `[generic]` that titled-years requirements are screened literally | No wording fix. Carry it as the main risk and route around the screen (A1) |
| R1b | Work equivalent to PM experience (requirements, feeding product input, cross-functional delivery) | must_have | adjacent | medium | transferability | 7 years writing requirements documents, running roadmap-input sessions, and coordinating engineers and PMs on custom builds. Limit: you fed product decisions but weren't accountable for prioritising or for outcomes. Specific, but nothing inspected yet | `[grounded]` your resume text | G4 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ client integrations of your company's REST APIs end to end. Limit: you implemented the product, you didn't own what it was. The triage tool lead could add a product you actually shipped (R9, G1) | `[grounded]` resume; memory lead unconfirmed | G4, G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, and integration architecture across 30+ builds. Already communicated well; nothing inspectable yet | `[grounded]` resume | none |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, the client's engineers, and PMs; ran scoping workshops and UAT | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your resume never mentions sales. Solutions roles often sit next to sales, but your text doesn't say you did | `[grounded]` resume silent; `[generic]` that solutions roles often work with sales | G3 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | Not mentioned anywhere | `[grounded]` resume silent | G2 |
| R6 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops plus quarterly roadmap-input sessions that collected client feedback for product. That is close to the JD's discovery work, but your resume presents it as implementation work | `[grounded]` resume | Edit E1, pending your approval |
| R7 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents, integration architecture, an internal integration playbook the whole team uses. Limit: these were specs for client builds, not product specs that set a squad's backlog | `[grounded]` resume | G4, W1 |
| R8 | Own the roadmap | important | adjacent | medium | transferability | You collected roadmap input for product. Limit: no evidence that you made the prioritisation calls | `[grounded]` resume | G4 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Nothing on your resume. A memory lead (an internal triage tool that support agents adopted) is unconfirmed and isn't evidence | memory lead only; `[grounded]` resume silent | G1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | 30+ client go-lives. Limit: those were single-client cutovers, not market launches with sales and support enablement | `[grounded]` resume | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics, and a product you shipped (R9, R2) | discovery | Only an unconfirmed memory lead about a triage tool | If confirmed, it's your one owned product with adoption data, and it moves R9 and strengthens R2 | You built a tool; you decided what it did; you tracked who used it or how much time it saved; you iterated on feedback | A screenshot, a usage count, a launch note, internal docs | Memory lead; `[inferred]` that it would move R9 |
| G2 | Agile delivery (R5, must_have) | discovery | Silent | A must-have with no evidence | Sprint ceremonies with your engineers; working from a backlog on custom builds; working from user stories in Jira | A sanitised ticket board, a sprint plan | `[grounded]` resume silent |
| G3 | Working with sales (R4b, must_have) | discovery | Silent | A must-have, and launches depend on sales | Pre-sales scoping; handing integration plans to account executives; deal-support calls | Notes from a deal you supported | `[grounded]` resume silent. The question is held for a later turn under the three-question budget |
| G4 | The PM bridge (R1b, R2, R7, R8, R10) | transferability | Strong adjacent work; no ownership of outcomes | These rows are what has to beat the R1a screen | The playbook as a product you owned internally; a roadmap-input session that changed what product built | The playbook itself; a product decision your input changed | `[grounded]` resume; `[generic]` that career-switchers are judged on ownership evidence |
| G5 | Titled PM years (R1a) | capability | You've never held the title | Wording can't close it | Closure paths: an internal move to PM at your current employer, or a referral route here (A1) | — | `[grounded]` your own statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from sources I could attribute | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. These are possibilities side by side, none ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Quartzline's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no compensation in the posting) | The figure isn't published; it may or may not fit your floor | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | (no location in the posting) | It may be on-site, hybrid, or remote | `[inferred]` from the posting's silence | Where is the role based, and how many office days are expected? | unresolved |
| RR4 | Resources and success measure stated | positive_signal | — | "drive delivery with two engineering squads"; "define and track adoption metrics" | The role has real resources and a measurable outcome | `[grounded]` JD | Which adoption metrics exist today, and who sets the targets? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the roadmap-input sessions and scoping workshops to your lead bullet (draft below) | See R6 | `[grounded]` your resume lines | resume_edits_pending_approval |
| P1 | Position yourself as someone who has run partner API integrations end to end and fed product decisions, and who wants roadmap ownership. Never claim you held PM accountability | See R1a, R1b | `[grounded]` your resume | pending your approval |
| A1 | Reach the hiring manager or a PM there through a referral or direct note, rather than only applying cold | See R1a | `[generic]` titled-years screens are often applied before a person reads | pending your approval |
| W1 | A one-page sample API product brief (problem, partner, spec outline, adoption metric) for a partner-facing integration. It's a sample, not shipped experience, and should be described that way | See R1b, R7, R8 | `[generic]` work samples narrow ownership doubts | pending your approval |
| A2 | Find the role on Quartzline's own careers page before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR1–RR4 questions word for word in the first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

**E1, resume_edits_pending_approval**

| Current framing | Proposed | Source |
|---|---|---|
| The roadmap-input sessions sit under implementation work | "Ran quarterly roadmap-input sessions collecting client feedback for product; led scoping workshops and requirements documents for 30+ client integrations of our REST APIs." | Your own lines, reordered. Nothing added |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused (permission not granted). It would have tested RR1 and role reality's Organization and Contradictions rows |
| 2. Role-family sweep | unavailable | Search refused (permission not granted). It would have set the market calibration and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so I had no query to run |

I can write all of this up as a `tuesday-dossier.md` file you can keep and reuse if you'd like.

**Upgrade menu**
- **Allow web search, or paste the live posting's link:** targets 1 and 2 run, which could clear RR1, add a pay band, and possibly lift the cap on the decision.
- **The triage tool details (G1):** could move R9 and strengthen R2.
- **The integration playbook or a sanitised requirements document:** could raise R3, R6 or R7 toward `high`.
- **The hiring manager's name:** tells me which proven story the plan should lead with.
- **Deeper research on Quartzline** (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: The internal request-triage tool that support agents adopted came up in an earlier conversation, but you haven't confirmed it here. Did you build it? What did you decide about what it did, how many agents used it, and did you measure anything?

G2: Have your integration builds run in sprints, from a backlog, or with user stories? What was your part in that?

Constraints: What are your non-negotiables for this move: a pay floor, location or remote, and work authorisation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.