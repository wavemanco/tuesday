I've read the skill's rules and am now running a few quick checks on the company and the posting before writing up the assessment.
**Yes, it's worth applying. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or our Denver office)
- `must_have`: direct: R1, R2, R3, R4a, R5, R6
- `important`: adjacent: R4b (BigQuery as the warehouse) · unclear: R7 (Ingestion from our app and CRM), R8 (Data contracts our analysts depend on)

R4b: a solid bridge from Snowflake, with its limit stated; R7, R8: probably in your history, but you haven't told me yet.

**Opportunity ledger.** The posted pay sits at or above the market band (RR1). The company recently raised a Series C and the posting is live on its own site (RR2). Three things are unknown: how wide the job really is (RR3), what the equity is (RR4), and who you'd report to (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R9 is met: you can work remotely from the US, or from Denver. (2) You present BigQuery honestly as a warehouse switch, not as experience you have (R4b). (3) The scope in RR3 turns out to be one person's job, not a whole data platform built alone.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring for schools in 31 US states. Founded 2016 in Denver, 264 employees, Series C of $52M in February 2026 | `[grounded]` the about page text you pasted; the careers posting confirmed live |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar", data quality testing | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | This covers the whole reporting path, from source to the contract with analysts. That may be wider than one domain's pipelines | `[inferred]` from the JD's three-part mandate against the pay report's scope line |
| Market calibration | Senior means 5–8 years and owning one domain's pipelines with no direct reports. Base median is $151,000, IQR $139,000–$163,500. The posting's $148,000–$166,000 starts just under the median and ends above the upper quartile | `[generic]` Datawright 2026 pay report, Series B–D, n=2,310; `[grounded]` JD for the posted range |
| Unknowns | Team size and who you'd report to; equity amount; on-call expectations; whether remote means anywhere in the US | — |
| Contradictions | None found between your pasted JD and the live careers page | `[grounded]` careers page search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated, which meets 5+. It's self-reported and nothing has been inspected | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" | `[grounded]` your background | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Specific, but no artifact inspected yet | `[grounded]` your background | Optional: sanitized dbt docs or a DAG screenshot would raise this to high |
| R4a | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse", and Snowflake is one | `[grounded]` JD wording and your background | none |
| R4b | BigQuery as the warehouse | important | adjacent | medium | transferability | The SQL-warehouse and dbt patterns carry over. You stated you've never used BigQuery. Limits: its specific cost model, partitioning and clustering, and SQL dialect. `[generic]` that a Snowflake-to-BigQuery switch is a common, learnable move for dbt engineers | `[grounded]` your background; `[inferred]` requirement from "a dbt-modelled warehouse in BigQuery" | See G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow, the tool the JD names | `[grounded]` your background | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your background | Optional: a sanitized suite config would raise this to high |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't mention which sources you ingested | `[grounded]` background silence | See G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | You haven't mentioned contracts, schemas you guaranteed to others, or analyst-facing SLAs | `[grounded]` background silence | See G3 |
| R9 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you're authorized to work in the US | `[grounded]` JD; background silent | Question R9 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4b, important) | transferability | Deep dbt-on-Snowflake work; no BigQuery | It's the one stack mismatch, so it's the obvious thing a screener will probe | Any GCP exposure; Snowflake cost or clustering tuning, which maps to BigQuery partitioning; a small dbt project run on BigQuery | A public repo of a small dbt-on-BigQuery project | `[grounded]` your background; `[generic]` that screeners probe stack mismatches |
| G2 | App and CRM ingestion (R7, important) | discovery | No sources named | Ingestion is a third of the mandate | Loading product event or app-database data; pulling from a CRM such as Salesforce or HubSpot; Fivetran, Airbyte or custom extractors | Sanitized pipeline diagram | `[grounded]` JD mandate; background silence |
| G3 | Data contracts (R8, important) | discovery | Nothing on contracts | It's a named deliverable | Schema agreements with upstream engineers; dbt model contracts or exposures; freshness or test SLAs analysts relied on | A sanitized contract spec or a dbt `contract: enforced` example | `[grounded]` JD; background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay is at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The pay buys the seniority asked for, with no seniority-pay mismatch | `[grounded]` JD; `[generic]` Datawright band | Where in the range do you expect to place someone with 6 years? | noted |
| RR2 | Recently funded, established company | positive_signal | — | "Series C ($52M, February 2026)" | The company has money to invest in the data platform | `[grounded]` about page you pasted | What does the data roadmap look like for the next year? | noted |
| RR3 | Scope breadth | unknown | — | "Build and run the pipelines … ingestion … warehouse … data contracts" | You may be the only data engineer for the whole reporting stack | `[inferred]` from the three-part mandate against the market's one-domain norm | How many data engineers are on the team, and which parts would I own? | unresolved |
| RR4 | Equity unspecified | unknown | — | "plus equity" | The grant size and vesting terms aren't known | `[grounded]` JD silence on terms | What's the equity grant size, and what are the vesting terms? | unresolved |
| RR5 | No hiring manager named | unknown | — | (no name in posting) | Reporting line unknown | `[grounded]` posting | Who would this role report to, and is it data or engineering leadership? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your own words: "Built our dbt project on Snowflake (about 180 models); set up our Great Expectations test suite; Airflow orchestration." Keep "built" and "set up", and don't upgrade either to "led" or "owned" | R3, R5, R6 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Say it plainly: "Snowflake warehouse, no BigQuery yet." Don't call yourself "warehouse-agnostic" | R4b | `[grounded]` your statement | pending your approval |
| W1 | A small public dbt-on-BigQuery project before or during the process | Narrows G1 | `[inferred]` from the R4b limit | pending your approval |
| Q1 | Ask the RR3–RR5 questions in the recruiter screen | The register doubles as screen prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers", which returned "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). That confirmed the posting is live, says "Accepting applications", and matches your text, which filled Role reality's contradictions row. I didn't check the about-page facts separately |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report) with the same figures your recruiter sent. That feeds the market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no one |

I can write all of this up as a `tuesday-dossier.md` file you can carry into later steps; just say if you want it.

**Upgrade menu**
- Your location and US work authorization: R9 closes, and the status could move to `go`.
- Answers to G2 and G3: R7 and R8 resolve, and the application has more to lead with.
- Sanitized dbt docs or a Great Expectations config: R3 and R6 move to `high`.
- Your pay floor: sets RR1 against your number instead of only the market's.
- The hiring manager's name, if the recruiter gives it: a scope read and which story to lead with.
- A deeper research pass on Pellucid (leadership changes, hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches. Say the word and I'll run it.

**R9:** Are you based in the US, or able to work from Denver, and are you authorized to work in the US?

**G2:** Which sources have you personally ingested, such as app databases, event streams or a CRM, and with what tooling?

**G3:** Have you defined or enforced schemas, SLAs or tests that analysts or other teams relied on? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.