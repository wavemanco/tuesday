Reading the underwriting method done; now running a quick check that the Pellucid posting is live, then writing the assessment.
Yes, it's worth applying. The posting is live, its pay range sits at or above the market report your recruiter sent, and you have direct evidence for every core requirement. Two things to check first: where you're based, and whether the range clears your own minimum. I made one search and one page fetch to confirm the posting and the company.

## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — adjacent: R7 (a dbt-modelled warehouse in BigQuery) · unclear: R8 (ingestion from our app and CRM), R9 (the data contracts our analysts depend on)

R7: a credible move from Snowflake, as long as you say plainly that you haven't used BigQuery. R8 and R9: nothing you've told me covers these yet.

**Opportunity ledger.** The posting is live and matches the company's About page (RR1). The pay range sits at or above the market band (RR2). Still open: who you'd report to (RR3), the equity terms (RR4), and what "run" means for on-call (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 is met: you can work from the US, or from the Denver office.
  2. $148,000–$166,000 clears your own minimum pay, which you haven't given me (RR2).
  3. R7 is presented as a Snowflake bridge, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016 in Denver, 264 employees, raised a $52M Series C in February 2026 | `[grounded]` About page, checked live |
| Mandate | "Build and run the pipelines behind our tutoring platform's reporting": ingestion from the app and CRM, a dbt warehouse in BigQuery, and the data contracts analysts rely on | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| First 90 days / first year | Not stated. Likely starting work is learning the existing BigQuery/dbt warehouse and its analyst consumers | `[inferred]` from "build and run" against an already-named stack |
| Scope read | One area's pipelines (reporting), with no team to manage mentioned | `[inferred]` from the JD's silence on direct reports |
| Market calibration | The report defines "Senior" as 5–8 years, owning one area's pipelines, with no direct reports. This posting asks for 5+ years and fits that pattern. Base pay at Series B–D companies: median $151,000, middle half of salaries $139,000–$163,500 | `[generic]` Datawright 2026 pay report (US, 2,310 responses), as pasted; `[grounded]` JD for the posting's figures |
| Unknowns | Hiring manager and team; equity terms; on-call duties; whether the data contracts already exist or you'd create them | — |
| Contradictions | None. The live careers page matches the JD you pasted | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US, so the gate isn't settled either way | `[grounded]` JD; your background is silent | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. That's specific, but nothing inspectable yet, so expect it to be checked | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily." Specific, nothing inspectable, so expect a technical screen | `[grounded]` your background; `[generic]` roles like this usually test it live | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so this meets the requirement as written | `[grounded]` your background, JD | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow, the tool the JD names | `[grounded]` your background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your background | none |
| R7 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | What carries over: dbt modelling and running a cloud warehouse. What doesn't: none of BigQuery's own features (partitioning, slot and cost model, its SQL dialect, project and dataset permissions) | `[grounded]` "Never used BigQuery"; `[generic]` what differs between warehouses | G1 |
| R8 | Ingestion from our app and CRM | important | unclear | low | discovery | You haven't described what your pipelines took data from | `[grounded]` your background is silent | G2 |
| R9 | The data contracts our analysts depend on | important | unclear | low | discovery | Great Expectations tests data. A contract is an agreement with analysts about what the data looks like. Related work, but not the same thing, and it isn't established yet | `[grounded]` your background; `[generic]` the difference between tests and contracts | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Strong dbt-on-Snowflake work, no BigQuery | It's the platform's warehouse, so the likeliest objection | Any work across more than one warehouse; dbt models written to run on more than one; tuning Snowflake costs or compute, which maps onto BigQuery's cost model | A small public repo running your dbt patterns on BigQuery's free sandbox | `[grounded]` your background; `[generic]` that this is the likely objection |
| G2 | App and CRM ingestion (R8, important) | discovery | Nothing yet on what your pipelines took data from | It's the first item in the mandate | Pulling in event data from the payroll product; syncing from Salesforce or HubSpot; using Fivetran or Airbyte, or writing your own API extractors in Python; change data capture from the app's database | A DAG or architecture diagram you can describe; a design doc with confidential details removed | `[grounded]` JD and your background |
| G3 | Data contracts (R9, important) | discovery | A test suite, but no agreed schemas with analysts or other consumers yet | It's named in the mandate, and it's the most distinctive part of the role | dbt model contracts or enforced schemas; agreements with the product team about event schemas; Great Expectations checks you set up with analysts to protect a report | A spec, a contract YAML, or a write-up of an incident a contract would have caught | `[grounded]` JD; `[generic]` that contracts and tests are different work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The posting is live and matches the company's own pages | positive_signal | — | "Accepting applications." | The role is real and open | `[grounded]` careers and About pages fetched | Where is the role in the hiring process right now? | noted |
| RR2 | Pay is stated and sits at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The midpoint ($157,000) is above the report's median ($151,000), and the top ($166,000) is above its 75th percentile ($163,500). Whether it clears *your* minimum is unknown | `[grounded]` JD; `[generic]` Datawright band | Where in the range do candidates with 6 years usually land? | noted |
| RR3 | No hiring manager or team named | unknown | — | "The posting names no hiring manager" (your note) | Who you'd report to, and how big the data team is, are open | `[inferred]` from what the JD leaves out | Who would this role report to, and how many data engineers and analysts are on the team? | unresolved |
| RR4 | Equity mentioned with no terms | unknown | — | "plus equity" | Value depends on the type, size, and vesting, none of which are stated | `[generic]` startup equity varies widely | What type and size of grant comes with this offer, and what's the vesting schedule? | unresolved |
| RR5 | "Run" suggests operational ownership | unknown | — | "Build and run the pipelines" | There may be an on-call rotation for pipelines that schools' reporting depends on | `[inferred]` from "run" | Is there an on-call rotation, and how often do pipeline incidents happen? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open your CV with three lines in your own words: "Built the dbt project on Snowflake (about 180 models)", "Orchestration in Airflow", "Set up the Great Expectations test suite" | R4, R5, R6 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Say it plainly in the cover note: "My warehouse work is on Snowflake; I haven't used BigQuery yet" | R7. Being honest about it up front heads off the objection | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Port a few dbt models to BigQuery's free sandbox and put it in a public repo | G1. Gives the R7 bridge something a reviewer can actually look at | `[generic]` reviewers weigh inspectable work | pending your approval |
| Q1 | Ask the RR2–RR5 questions word for word in interviews | They double as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both checked the text you pasted and match it word for word. Moved Role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already settles the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

If you'd like, I can save all of this as `tuesday-dossier.md` so you can carry it into later steps.

**What more input would change:**
- **Your minimum pay and any location limits:** settles condition 2, and turns R1's "unconfirmed" into met or failed.
- **A BigQuery sandbox repo (W1):** raises R7 toward a stronger bridge.
- **Answers to G2 and G3:** R8 and R9 become direct, or stay open as named risks.
- **The hiring manager's name:** tells us which of your stories to lead with for that reader.
- **A deeper research pass on Pellucid** (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions:**

**Q1 (R1):** Are you based in the US and authorized to work there, or able to work from Denver?

**G2:** What sources did your pipelines take data from (the payroll app's database or events, a CRM, other vendor APIs), and which parts did you build yourself?

**G3:** Did you ever agree a schema or contract with the analysts or product team who used your data, for example dbt contracts or an agreed event spec? If so, what did you personally own?

For any of these, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.