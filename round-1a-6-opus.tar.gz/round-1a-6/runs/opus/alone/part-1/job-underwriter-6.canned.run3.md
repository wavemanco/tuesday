Reading the skill's rules is done. Next I'll fetch the posting and run the background research.
# Revenue Operations Lead at Quillfield: should Joss apply?

## Decision snapshot

**Yes, it's worth going for, if the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two days a week in the office), R2 (Salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3a, R4, R5a · adjacent: R6 (Experience owning a forecast) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data)
- `important` — direct: R9 · absent: R8 (Own billing data)

R6 — your pipeline review is real nearby experience, but finance owned the number; R7 and R8 — the billing side, where your own account gives no direct evidence yet.

**Opportunity ledger.** The company exists as the posting describes (RR1). The pay is stated and sits in the market range (RR2). The hiring manager's public career runs through sales ops at a payments company (RR3). Against that, the posting doesn't appear on Quillfield's own site (RR4), the role bundles CRM, billing data and the CFO forecast into one job (RR5), and who owns the forecast number is unstated (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 fit your constraints; (2) the posting is confirmed live (RR4); (3) R6 is presented as nearby experience, never as owning a forecast; (4) G2 either turns up real work with finance on revenue data for R7, or you go in with billing data (R8) named as something you'll learn.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations; previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter, plus public profile snippet |
| Scope read | More than a CRM admin role. Billing data and the CFO forecast are finance-facing work, and those are exactly where your history is thinnest | `[inferred]` from the mandate's three verbs, set against your background |
| Market calibration | For a revenue operations lead at a UK B2B software company, the median base is £64,200 and the middle half runs £57,800–£70,400. This posting's range sits inside that and straddles the median. A "Lead" title asking for 4+ years is mid-senior for this role family | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide (n=438); `[grounded]` posting figure |
| First-year outcomes | Not stated. The quarterly forecast cycle with the CFO is probably what you'd be judged on | `[inferred]` from "run the quarterly revenue forecast with the CFO" |
| Unknowns | Who owns the forecast number today; the reporting line; the billing system; what the share options are worth | — |
| Contradictions | None between the posting and Quillfield's about page. The posting isn't on Quillfield's own site (RR4) | `[grounded]` about page read; careers page not found |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't said where you live or what office pattern works for you | `[grounded]` posting; you haven't stated this | Closing question on gates |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | You haven't stated a salary floor | `[grounded]` posting; you haven't stated this | Closing question on gates |
| R3a | 4+ years in revenue operations or sales operations | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. You've stated it but I haven't seen it on a CV | `[grounded]` your intake | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a "B2B payments company". Whether it counts as a software company depends on what it sells | `[grounded]` your wording | Your CV, or one line on what the company sells |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Certified Salesforce admin. The certificate is checkable | `[grounded]` your intake | Certificate verification link would raise this to high |
| R5a | Strong SQL | must_have | direct | medium | none | You write SQL weekly. You've said so specifically, but there's nothing to look at yet | `[grounded]` your intake | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" says you use it, not that you build models | `[grounded]` your wording | Upgrade menu: a model you built |
| R6 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, but "finance did" the company forecast. That's nearby work, and the gap is ownership of the number | `[grounded]` your own words on both points | G1 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. Revenue data is still open: renewal dashboards may have touched contract values or renewal revenue, but that's unconfirmed | `[grounded]` your statement on billing; `[inferred]` the possible thread through the renewal dashboards | G2 |
| R8 | Own billing data (alongside the CRM) | important | absent | none | capability | You said directly that you've never worked on billing data. No question needed | `[grounded]` your statement | Learning plan, application plan P4 |
| R9 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them isn't stated | `[grounded]` your intake | A screenshot would raise this to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | Monthly pipeline review with the sales director; finance owned the company forecast | It's a must-have, and it's the headline duty working with the CFO. How strong the bridge is decides how you present yourself | Calling a UK commit or quarter-end number; rolling up rep forecasts in Salesforce; explaining to finance why pipeline and their forecast differed | A forecast roll-up view or a sanitized review deck | `[grounded]` your own words; `[inferred]` that this row matters most to the decision |
| G2 | Working with finance on revenue data (R7, must_have) | discovery | No billing data. Whether revenue data was involved is unknown | A must-have. A real thread here narrows the billing gap in R8 | Matching renewal values to finance's ARR or bookings; churn or renewal figures finance used; settling CRM vs. finance numbers at month end | A reconciliation sheet or a renewal report finance used | `[grounded]` your statement on billing; `[inferred]` the renewal-dashboard thread |
| G3 | B2B software employer (R3b) and spreadsheet modelling (R5b) | discovery | Your wording doesn't settle either one | Both are lower ranked; your CV probably settles them without a question | What the payments company sells; any capacity, quota or territory model you built | Your CV | `[grounded]` your wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established as described | positive_signal | — | "invoicing and payments software… Founded 2018 in Bristol; 96 employees" | A real, funded company that matches the posting | `[grounded]` quillfield.co.uk/about | What has changed in the revenue team since the Series A? | noted |
| RR2 | Salary stated and at market | positive_signal | — | "£61,500–£67,000 plus share options" | The pay is in the market range for this title | `[grounded]` posting; `[generic]` Ledgerline band | How are the share options structured, and on what vesting? | noted |
| RR3 | Hiring manager's published path matches yours | positive_signal | — | "Previously sales operations manager at Corvane Payments for four years" | Your background maps onto a route the hiring manager has taken themselves | `[grounded]` public profile snippet | What did the forecast process look like when you joined, and what do you want this hire to take off your plate? | noted |
| RR4 | Posting not found on Quillfield's own site | unknown | — | Tallyboard listing "revenue-operations-lead-2291" | Quillfield may simply not host its own careers page, or the listing may be stale | `[generic]` common for companies of this size, not a finding about this one | Is this role still open, and is Tallyboard where you're running it? | unresolved |
| RR5 | Broad mandate for one role | risk_signal | low | "own our CRM and billing data… run the quarterly revenue forecast with the CFO" | CRM, billing data and the forecast may be three jobs at a 96-person company; low because none is unusual for RevOps at this stage | `[generic]` role-family pattern at this headcount | How is the role's time expected to split between the CRM, billing data and the forecast? | unresolved |
| RR6 | Forecast ownership and authority unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | Unclear whether the number would be yours or finance's, which also affects how big your R6 gap really is | `[inferred]` from "with the CFO" and the posting's silence on ownership | Who owns the quarterly forecast number today, and what would this role own of it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the office pattern and salary floor before applying | see R1, R2 | `[grounded]` posting terms | pending your approval |
| A2 | Ask the recruiter whether the role is live and how it's being run | see RR4 | `[grounded]` RR4 | pending your approval |
| P1 | Lead with your own two sentences: "I rebuilt our pipeline and renewal dashboards" and "I run the monthly pipeline review with our sales director" | see R9, R6 | `[grounded]` your intake wording | pending your approval |
| P2 | On forecasting, state both facts side by side: finance owned the company forecast; you ran the monthly pipeline review. Don't add a link between them (for example "fed the forecast") unless G1 confirms it | see R6 | `[grounded]` your own words | pending your approval |
| P3 | Name billing data as a gap you've thought about, not one you hide. Before interviews, learn how invoice, payment, credit-note and renewal data usually connect to revenue reporting | see R8 | `[generic]` role-family pattern for billing data | pending your approval |
| Q1 | In the loop, ask the verification questions for RR4, RR5 and RR6 word for word | the register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers: no page there. Searched "Quillfield careers revenue operations lead": no results. This fed the organization row, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B SaaS 2026", which returned the "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). This fed the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). This fed the hiring manager row, RR3 and P1 |

If it would help, I can save this whole assessment as `tuesday-dossier.md` so you can take it into later steps.

**Upgrade menu**
- Your CV: settles R3b and R5b, and checks every row against your own wording.
- Your Salesforce admin certificate verification link: raises R4 to `high`.
- A screenshot or sanitized export of the dashboards you rebuilt: raises R9 to `high`.
- A spreadsheet model you built: settles R5b.
- Your office-day limits and salary floor: settles R1 and R2.
- A deeper research pass on Quillfield (funding since the Series A, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1/R2 — Can you do two days a week in the Bristol office, and is £61,500–£67,000 at or above your salary floor?

G1 — In the monthly pipeline review, did you produce or call a UK number (a commit, a quarter-end call, a roll-up)? And once finance had it, what happened to your number?

G2 — Have you ever matched your renewal or pipeline figures against finance's revenue numbers (bookings, ARR, churn)? If so, what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.