I'm reading the skill's risk and decision rules before I put together your assessment.
Yes, this looks worth applying to. Your background lines up with every must-have in the posting, and the pay is at or above the market band your recruiter's report gives. A few things are still open, listed below.

## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office)
- `must_have`: direct: R2, R3, R4a, R4b, R6, R7
- `important`: adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R5 is a strong bridge with a known limit, since you've never used BigQuery; R8 and R9 are silent in your background, not missing; R2, R3, R4a, R4b, R6 and R7 are each at `medium`, which means you've stated them but there's nothing yet to show.

**Opportunity ledger.** The posting states its pay, and the range sits at or above the band in your recruiter's report (RR2). The equity is undefined (RR3), no hiring manager or team is named (RR4), and how much on-call "build and run" means is unstated (RR5). My one search of the employer's site was refused, so RR1 stays open until you open the live posting yourself.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on pellucidlearning.com/careers (RR1); (2) you can work remotely from the US or from Denver (R1); (3) the BigQuery bridge is presented as adjacent and never as BigQuery experience (R5, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about page as you pasted it; not checked live (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar", SQL, Python, data-quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated | `[grounded]` the JD is silent |
| Scope read | One person owning a single reporting domain end to end, from sources to warehouse to the analyst-facing contract. No reports are mentioned | `[inferred]` from the JD's three-part mandate and its silence on managing people |
| Market calibration | Your recruiter's report puts Senior Data Engineer at Series B–D companies at a $151,000 median base, with an interquartile range of $139,000–$163,500. It defines "Senior" as 5–8 years and the typical scope as one domain's pipelines with no reports. This title, seniority and scope match that norm, and the posted range runs from just under the median to above the upper quartile. The band is a market pattern, not this employer's offer | `[generic]` Datawright 2026 Data Engineering Pay Report (n=2,310), as you pasted it; `[grounded]` JD for the posted range |
| Unknowns | Equity terms; who you'd report to and how big the data team is; on-call expectations; how mature the data contracts are today | — |
| Contradictions | None between the pasted JD and the pasted about page | `[grounded]` both as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | The JD sets the location term. Your background doesn't say where you're based or that you can work in the US | `[grounded]` JD; your background is silent | Closing question on R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company, which clears the bar. It's stated, but nothing inspectable yet | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated "Python and SQL daily"; the dbt and Great Expectations work sits on both | `[grounded]` your stated background | Expect a live SQL or Python exercise; nothing to recover |
| R4a | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. That's specific and it's yours | `[grounded]` your stated background | none |
| R4b | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met. That BigQuery is the one they use is R5, a separate claim | `[grounded]` JD wording; your stated background | none |
| R5 | BigQuery as the warehouse | important | adjacent | medium | transferability | What carries over: warehouse modelling in dbt, and SQL on a columnar cloud warehouse. The limit: you've never used BigQuery, so its cost model, partitioning and clustering, SQL dialect and GCP permissions are untested. `[generic]` dbt work carries across warehouses more readily than warehouse-specific tuning does | `[grounded]` your "never used BigQuery"; `[inferred]` the bridge from Snowflake; `[generic]` the clause on how dbt work carries across | G1; W1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is the tool they name | `[grounded]` your stated background | none |
| R7 | Data-quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is ownership, not just use | `[grounded]` your stated background | none |
| R8 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your background covers modelling, orchestration and testing, not where the data came from or who built the ingestion | `[grounded]` your background is silent on ingestion | Closing question on G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby but isn't a contract. Whether you agreed schemas or SLAs with analysts isn't stated | `[grounded]` your background is silent; `[inferred]` that the test suite is nearby work | Closing question on G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, important) | transferability | 6 years on dbt plus Snowflake with Airflow; no BigQuery | It's the platform you'd run every day, and the most likely objection to your application. A small hands-on piece makes the bridge more than a claim | Rebuilding a slice of your dbt models on the BigQuery sandbox; any GCP exposure at all; Snowflake cost or performance tuning you did, which is the closest parallel to BigQuery's cost model | A public repo with a small dbt plus BigQuery project | `[inferred]` bridge from R4a and R4b; `[generic]` that a warehouse switch is the usual objection |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Your background starts at the warehouse | It's a third of the stated mandate | Loading product or app event data; pulling from a CRM such as Salesforce or HubSpot (a payroll company's sales CRM counts); building or maintaining Fivetran or Airbyte connectors, or custom Python extractors run from Airflow | A DAG you can describe, a design doc, a connector config | `[grounded]` your background is silent; `[inferred]` that payroll-company sources may count |
| G3 | Data contracts (R9, important) | discovery | A data-quality suite, but no stated agreement with the people who consume the data | The JD names contracts the analysts "depend on". Contract work is a different thing from testing | Agreeing schemas or freshness SLAs with analysts or finance; dbt model contracts or versioned models; Great Expectations checks you wrote because a downstream team asked for them; handling a breaking change in a source | A contract YAML, a schema-change runbook, an incident write-up | `[grounded]` JD wording; `[inferred]` the line between testing and contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from sources I could check (my search was refused) | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The company may be too new or small to have a footprint, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. These are possibilities side by side, none ranked as likely. Your pasted pages are internally consistent | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated, at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity." | The floor is $3k under the report's median and the top is $2.5k above its upper quartile, so publishing the range isn't hiding a low offer | `[grounded]` JD; `[generic]` Datawright band | For someone with six years, where in the $148k–$166k range would you expect to land? | noted |
| RR3 | Equity unspecified | unknown | — | "plus equity" | Its value can't be judged without the type, grant size, strike or preference terms, and vesting | `[generic]` how private-company equity is valued | What form does the equity take, how large is the grant, and what's the vesting schedule? | unresolved |
| RR4 | Reporting line and team unnamed | unknown | — | The posting names no hiring manager | You might be the only data engineer, or one of several, which changes what "senior" means day to day | `[inferred]` from the posting's silence | Who would this role report to, and how many data engineers and analysts are on the team today? | unresolved |
| RR5 | "Build and run" without on-call terms | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Running pipelines for school-facing reporting may come with on-call duty, and the posting doesn't say how much | `[inferred]` from "run" in the mandate | What does on-call look like for these pipelines, and how often does it fire? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open pellucidlearning.com/careers yourself and confirm the posting is live before you put effort in | Clears RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead your CV with the stack match in the JD's own terms, using only what you've stated: "Built and maintain the company's dbt project on Snowflake (~180 models), orchestrated in Airflow" and "Set up the data-quality test suite (Great Expectations)" | R4a, R6, R7 | `[grounded]` your stated background | pending your approval |
| E2 | Name Snowflake plainly and don't list BigQuery anywhere until W1 exists, and then only as a personal project | R5; anything else would overstate what you've done | `[grounded]` your "never used BigQuery" | pending your approval |
| W1 | A small public repo: a few of your model patterns, rebuilt on public data, in dbt on the BigQuery sandbox, with tests | Narrows G1 from a claim to something they can inspect | `[generic]` that a hands-on sample answers a warehouse-switch objection | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3, RR4 and RR5 word for word in your first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

My one search was refused, so I couldn't check the live posting or the company, and I didn't try again. Everything about Pellucid above comes from the text you pasted.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Sent "Pellucid Learning senior data engineer careers", which was refused. It would have confirmed the posting is live and the company is as described, clearing RR1 and the Organization row in role reality |
| 2. Role-family sweep | skipped | The pasted Datawright report already gives the band, the meaning of "Senior" and the typical scope, which together settle the market calibration and the RR2 comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search |

If you'd like, I can save this as `tuesday-dossier.md` so you can pick it up later or carry it into interview prep.

**What more input would unlock:**
- **Search permission, or a link to the live posting:** clears RR1, which lifts the cap that keeps this at `conditional_go`.
- **Your location and work authorization:** settles R1.
- **Your own non-negotiables (pay floor, office days, on-call tolerance):** turns "candidate constraints not given" into actual checks against R1, RR2 and RR5.
- **Answers to G2 and G3:** R8 and R9 move from `unclear` toward `direct` or `adjacent`.
- **A repo or design doc (dbt project excerpt, DAG, contract YAML):** raises any of R4a, R6, R7 or R9 from `medium` to `high`.
- **The hiring manager's name:** feeds the scope read and decides which of your stories to lead with.
- **A deeper research pass on Pellucid (funding and leadership churn, hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches:** say the word and it runs, though it needs search permission.

**R1:** Are you based in the US and able to work there without sponsorship, either remotely or from Denver?

**G2:** At the payroll company, did you build or run any ingestion, whether app or product events, a CRM, or connectors? What part was yours?

**G3:** Have you ever agreed a schema, a freshness target or a change process with analysts or another downstream team? This could be formal or informal, for example a check you added because they asked. What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.