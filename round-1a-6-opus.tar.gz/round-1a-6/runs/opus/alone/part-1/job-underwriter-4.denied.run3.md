Quick update: I've read the assessment rules, and now I'm running a few searches on Brindlemoor, pricing-analyst market norms and the hiring manager.
Yes, I think you should apply, but check a few things first. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Based in the UK, for a fully remote UK role)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: unclear: R8 (Recommendations for product); adjacent: R9 (Pet-insurance domain knowledge)
- `preferred`: direct: R10

What matters in that list: R2, R3, R4, R5, R6, R7 come straight from what you told me, but I haven't seen any documents behind them yet. R9 is a real bridge from motor to pet, with a limit you should say out loud. R8 is about product-side recommendations, and nothing you've told me shows that yet.

**Opportunity ledger.** I couldn't check that the employer and posting exist as described, because my searches were refused (RR1). The salary isn't stated (RR2), and the JD doesn't say who else works on pricing (RR4). On the plus side, the mandate and the hiring manager are both clearly named (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Based in the UK, for a fully remote UK role); candidate constraints not given, so checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you're based in the UK and can work there (R1); (2) the posting is live on Brindlemoor's own careers page (RR1); (3) the salary clears your floor (RR2); (4) you present pet insurance as a new domain you can bridge to, never as experience you have (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; that it exists as described is not checked (RR1) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Line management | The JD asks for none, so never having managed anyone isn't a gap for this role | `[grounded]` JD silent on reports |
| Scope read | A senior individual-contributor post that owns one product's pricing analytics and advises underwriting and product | `[inferred]` from "own pricing analytics" with no reports mentioned |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established: the role-family search was refused | — |
| Unknowns | Salary; pricing team size; who signs off rate changes; the modelling stack | — |
| Contradictions | None found within the JD; I couldn't compare it with the careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the UK, for a fully remote UK role | hard_gate | unclear | low | hard_gate | Working at a UK motor insurer suggests it but doesn't establish your location or right to work | `[inferred]` from your current employer | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics, the last 2 as senior analyst. It's specific but not inspected | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated "SQL and Python daily". Daily use is stated; depth will be tested | `[grounded]` your message | Expect a technical exercise |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your message | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building and ongoing upkeep; what monitoring involved isn't stated | `[grounded]` your message | Be ready to describe how you monitored the model |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Which part of the design was yours isn't stated, so don't claim more than you did | `[grounded]` your message | Prep: what part of the test design was yours |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R8 | Recommendations for product | important | unclear | low | discovery | Your underwriting-facing work is clear; nothing yet shows recommendations to a product team | `[grounded]` your message is silent on product | See G1 |
| R9 | Pet-insurance domain knowledge | important | adjacent | medium | transferability | GLM rating and price testing carry over directly. You have no pet-insurance exposure. Pet pricing typically uses different rating factors (species, breed, age) and different claims patterns from motor | `[inferred]` requirement, from "our pet-insurance product"; `[grounded]` that you've never worked on pet; `[generic]` how pet rating differs from motor | See G2 |
| R10 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R8, important) | discovery | Your recommendations clearly reach underwriting; nothing shows product | The JD names product as a second audience, and evidence there makes R8 direct | Test results that changed a product feature, cover option or excess level; working with marketing or product on a launch price; recommendations on discount or no-claims structures | An anonymised test readout or a review slide aimed at a non-underwriting audience | `[grounded]` your message is silent on product; `[inferred]` that this moves R8 |
| G2 | Pet-insurance domain (R9, important) | transferability | The method carries over (GLM rating, price tests); the domain doesn't | Interviewers are likely to ask how you would get up to speed | Motor work that looks like pet pricing: thin-data segments like a young-driver book, claims inflation, rating-factor selection. Plus any self-study of pet rating factors | A short note on how you'd approach a pet rating model, kept honest as a plan rather than experience | `[grounded]` your stated work; `[generic]` that domain ramp-up is a common probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this company; my searches were refused, not empty | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in the posting | The figure could be anywhere against your current pay; nothing in hand settles it | `[inferred]` from the posting's silence | What salary band is budgeted for this role? | unresolved |
| RR3 | Clear mandate and a named decision-maker | positive_signal | — | "turn the results into recommendations for underwriting and product" | The scope is defined and the reporting line is visible | `[grounded]` JD and the hiring manager's name | How are pricing recommendations taken forward today? | noted |
| RR4 | "Own" pricing with no team or support mentioned | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be a one-person function, or sit within a larger pricing team | `[inferred]` from "own" alongside the JD's silence on team | Who else works on pricing, and who signs off rate changes? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own words: "built and maintained the GLM rating model for our young-driver book", "ran 14 price tests last year with the underwriting team", "present the quarterly pricing review to the head of underwriting" | See R4, R6, R7 | `[grounded]` your message | pending your approval |
| P2 | Name pet insurance as a new domain: "I've priced motor, not pet; the GLM and price-testing method is what carries over" | See R9 | `[grounded]` your message | pending your approval |
| P3 | Don't claim pet-insurance experience, managing people, or designing tests beyond what you did | Truthfulness; the JD doesn't ask for management | `[grounded]` your message | pending your approval |
| P4 | Check the role on Brindlemoor's own careers page before you apply | See RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the questions from RR1, RR2, RR3 and RR4 word for word at the screening stage | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; refused by permissions. It would have settled RR1 and the Organization and Contradictions rows |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote 2026"; refused. It would have filled the Market calibration row and given RR2 a salary band |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have shaped the scope read and which story P1 leads with |

I can write this up as a `tuesday-dossier.md` file you can keep, if that's useful.

**Upgrade menu**
- Allow web search → RR1 can close, the Market calibration row gets a salary band, and the hiring manager's public background can shape P1.
- A link to the live posting or Brindlemoor's careers page → RR1 closes.
- Your salary floor → RR2 becomes a real check rather than an unknown.
- An anonymised price-test readout, GLM model documentation or a quarterly review deck → R4, R6 or R7 can rise to `high`.
- A deeper research pass (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds the register. Say the word and it runs.

R1: Are you UK-based with the right to work in the UK without sponsorship?

G1: Have any of your test results or reviews led to a recommendation that a product, marketing or distribution team acted on? What was it, and what part was yours?

RR2: What's the lowest salary you'd accept for this move?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.