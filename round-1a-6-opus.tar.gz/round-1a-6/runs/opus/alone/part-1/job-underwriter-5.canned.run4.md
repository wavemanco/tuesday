Reading the skill's rules is done. Next I'm checking Pellucid's own site and pay data for the role, then the assessment.
**Is it worth applying? Yes, on one condition: confirm R1. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (dbt-modelled warehouse in BigQuery) · unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R6: a real bridge from Snowflake, with its limit stated; R9, R10: your background doesn't mention them, so one question each.

**Opportunity ledger.** Pay is stated and sits at or above the market band (RR1). The posting is live and the company matches its own description (RR2). The reporting line (RR3), the equity terms (RR4) and how wide the ownership runs (RR5) are unknowns to ask about, not warning signs.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is met: you're based in the US, or will work from Denver; (2) the $148k–$166k range clears your own pay floor (RR1); (3) R6 is described as Snowflake experience moving to BigQuery, never as BigQuery experience; (4) the scope checks out as reasonable in interviews (RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` about page, confirmed by search |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Must-haves | 5+ yrs data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working terms | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | "Build and run" across ingestion, the warehouse and contracts reads as owning the whole reporting stack end to end, not one slice of it | `[inferred]` from the JD's three named areas, given that it names no team |
| Market calibration | Senior means 5–8 years, owning one domain's pipelines with no reports. Base median is $151,000, middle half $139,000–$163,500. The posting's $148k–$166k runs from just under the median to above the top of the middle half | `[generic]` Datawright 2026 report (US, n=2,310, Series B–D), confirmed by search; `[grounded]` JD figure |
| Unknowns | Hiring manager and team size; equity form and amount; on-call duties | — |
| Contradictions | None: the JD you pasted matches the live careers page, and the about page matches your copy | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or can work. The gate is a location term, so nothing else on this map can stand in for it | `[grounded]` JD; background silent | Question on R1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years. That's specific, but nothing inspectable yet. It also sits inside the report's 5–8-year "Senior" range | `[grounded]` your background; `[generic]` the range | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", as you stated. Expect a live probe | `[grounded]` your background | none |
| R4 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Specific and owned, but nothing inspectable | `[grounded]` your background | Upgrade menu: a docs site or lineage graph raises this |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the JD words it | `[grounded]` your background against JD wording | none |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt models and testing habits carry across. Limit: you've never used BigQuery itself. Its cost model, partitioning and clustering, and nested fields are new to you, and an interviewer can tell within a question | `[grounded]` "Never used BigQuery"; `[generic]` that those are the BigQuery-specific areas | See G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, as you stated | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite": specific and owned | `[grounded]` your background | Upgrade menu: suite config or screenshots |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background lists modelling, orchestration and testing, but not the sources you pulled data in from. The thread is that data engineering at a payroll company plausibly involved app or CRM sources | `[inferred]` from the role you described; `[grounded]` the silence | See G2 |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations suite is a lead, but tests aren't contracts unless they were agreed with the people consuming the data | `[inferred]` from R8's suite; `[grounded]` the silence | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G0 | Location (R1, hard_gate) | hard_gate | Nothing stated | The one open gate; it alone caps the status | — | — | `[grounded]` JD term |
| G1 | BigQuery (R6, important) | transferability | Snowflake and dbt are strong; no hands-on BigQuery | Adjacent, not direct. Being honest about it, plus a small proof, will read better than stretching it | Moving dbt models between adapters; cost tuning in Snowflake (warehouse sizing) as a parallel to BigQuery's cost model | A small public dbt project running on BigQuery (W1) | `[grounded]` your statement; `[generic]` that cost and partitioning are what get probed |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Nothing about ingestion sources | Ingestion is one of the three areas the JD names | Product-database replication into Snowflake; pulls from a CRM or HRIS API; event streams; Fivetran or Airbyte connectors you configured or replaced | A DAG list, a design doc, a connector inventory | `[grounded]` the silence |
| G3 | Data contracts (R10, important) | discovery | A test suite, not stated contracts | "The data contracts our analysts depend on" is named in the mandate | Agreed schemas or SLAs with analysts; dbt model contracts or exposures; Great Expectations checks that blocked a deploy and that analysts relied on | A contract YAML, a schema-change policy, a Slack or RFC thread | `[inferred]` R8 as the lead |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range runs from just under the median ($151k) to above the top of the middle half ($163.5k) | `[grounded]` JD; `[generic]` Datawright band | What decides where in the range an offer lands? | noted |
| RR2 | Posting live; company matches its description | positive_signal | — | "Accepting applications" | The role is open, and the company's stage and size match what you pasted | `[grounded]` careers and about pages, via search | — | noted |
| RR3 | No hiring manager or team named | unknown | — | (posting silent) | You might be the first or only data engineer, or one of several | `[inferred]` from the JD's silence | Who does this role report to, and how many data engineers are on the team? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Its value can't be compared without form, size and vesting | `[inferred]` from the wording | What form does the equity take, how many units, on what vesting schedule? | unresolved |
| RR5 | Ownership may run wider than the market norm | unknown | — | "Build and run the pipelines… ingestion… warehouse… data contracts" | The posting may cover the whole reporting stack plus on-call. The typical senior scope is one domain | `[inferred]` from the JD's three areas; `[generic]` the one-domain norm | Which parts of ingestion, warehouse and contracts would I own alone, and what does on-call look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with three lines in your own words: "Built our dbt project on Snowflake (about 180 models)"; "Orchestrated with Airflow"; "Set up our Great Expectations test suite" | R4, R7, R8: they match the JD's must-haves one-for-one | `[grounded]` your background | resume_edits_pending_approval |
| B1 | Say BigQuery is new to you, in one plain line ("dbt and Snowflake in production; haven't run BigQuery yet"). Never write "BigQuery" in a skills list | R6 is adjacent; an interviewer will probe it | `[grounded]` your statement | pending your approval |
| W1 | Build a small dbt-on-BigQuery project before the technical round, so the bridge has an inspectable artifact | G1 | `[generic]` that a work sample narrows an adjacent gap | pending your approval |
| Q1 | Ask the RR1, RR3, RR4 and RR5 questions word for word in your first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers", which returned "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer, "Accepting applications"). Searched "Pellucid Learning about live online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fed role reality's organization and contradictions rows, and RR2 |
| 2. Role-family sweep | yes | Searched "senior data engineer salary 2026 dbt BigQuery remote US", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report). It matches your recruiter's figures. Fed the market calibration line, RR1 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name given, so there was nothing to search |

I can save all of this as `tuesday-dossier.md` for you to carry to later sessions; just say so.

## Upgrade menu

- **Your actual CV:** lets the map read your own wording, not a summary of it.
- **A dbt docs site, lineage screenshot or repo (sanitized is fine):** raises R4 to `high`.
- **Your Great Expectations config or a check-results screenshot:** raises R8 to `high`, and may move R10.
- **Your location and pay floor:** settle R1 and set RR1 against your number.
- **The hiring manager's name:** opens research target 3, so the plan can choose which story to lead with for that reader.
- **A deeper research pass:** funding use, leadership changes, hiring patterns, employee reviews and recent news on Pellucid, up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

**G0 / R1:** Are you based in the US, or able to work from Denver?

**G2 / R9:** Where did your pipelines pull data from: a product database, a CRM or HR system's API, event streams, or connectors like Fivetran or Airbyte? Which of those did you build or own?

**G3 / R10:** Did any of your Great Expectations checks or dbt models come with an agreement with analysts, such as a schema they relied on, a freshness promise, or a rule that a breaking change blocks deploys?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.