Web search was blocked, so I've done the assessment from the JD and what you told me. The company, pay and hiring-manager facts below are unchecked.

## Decision snapshot

**Yes, go for it, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6 · unclear: R7 (Turn results into recommendations for product)
- `important`: direct: R8 · adjacent: R10 (Pricing a pet-insurance product)
- `preferred`: direct: R9

R10 is a real bridge from motor, but it has a stated limit. For R7, the underwriting side is covered and the product side is unseen.

**Opportunity ledger.** The role is well defined (RR4), but I couldn't confirm the employer or the posting from here (RR1). Pay isn't stated (RR2), and the size of the team behind "own pricing analytics" isn't either (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting check out (RR1). (2) You're UK-based with the right to work (R1). (3) Pay meets your floor (RR2). (4) You present the pet-insurance bridge honestly as adjacent, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD; not checked, see RR1 |
| Mandate | "Own pricing analytics for our pet-insurance product": build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Scope read | A senior individual-contributor role. The JD asks for no line management, so not having managed anyone doesn't count against you here | `[grounded]` JD has no management requirement; `[inferred]` IC scope from the title and the responsibilities listed |
| Market calibration | Not calibrated: the role-family sweep couldn't run, so I have no pay or scope band for this title | — |
| Unknowns | Pay; pricing team size; who signs off rate changes; contract basis | — |
| Contradictions | None in the JD itself. I couldn't compare it with a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK): based in the UK with the right to work | hard_gate | unclear | low | hard_gate | Your job at a UK insurer suggests this, but you haven't said where you're based or what your work status is | `[inferred]` from "UK motor insurer" | Question Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, the last 2 as senior. Specific, but not yet backed by an artifact; that's the ceiling for a first pass | `[grounded]` your background | none |
| R3 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book." Monitoring routines aren't stated; expect a probe on how you tracked model performance | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Same model as R3. It's specific, but a single book | `[grounded]` your background | none |
| R5 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." How much of the design was yours isn't stated, so don't claim more than "ran" until it is | `[grounded]` your background | none |
| R6 | Strong SQL and Python | must_have | direct | medium | none | Used daily, by your own account | `[grounded]` your background | none |
| R7 | Turn results into recommendations for product | must_have | unclear | low | discovery | Your recommendations to underwriting are covered under R8. Nothing yet shows work with product teams | `[grounded]` your background is silent on product | Question Q2, G1 |
| R8 | Presenting to underwriting or actuarial leads | important | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which is almost the JD's own wording | `[grounded]` your background | none |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pricing a pet-insurance product (the product this role owns) | important | adjacent | medium | transferability | The GLM, price-testing and underwriting-facing methods carry over. The limit: you've never priced pet, and its rating factors and claims drivers differ from motor | `[inferred]` requirement from "our pet-insurance product"; `[generic]` that pet and motor rating factors differ | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R7, must_have) | discovery | Underwriting-facing work is clear. Nothing yet on product | It's the one `must_have` row not yet at `direct` | Price-test results that changed a product feature, cover option, excess or discount; work with a product owner or pricing-engine team on a launch; renewal or channel decisions you fed | A sanitized test readout, a recommendation paper, or a deck slide | `[grounded]` your background is silent on product |
| G2 | Pet-insurance pricing (R10, important) | transferability | Motor GLM and price testing; no pet exposure | The obvious objection for this role, so state the bridge and its limit yourself before they raise it | Young-driver work as a specialist segment with sparse data; any non-motor line you touched; personal study of pet pricing | Nothing to collect yet. The fix is in how you frame it (plan P2) | `[inferred]` bridge from your young-driver GLM; `[generic]` that domain change is the likely objection |
| G3 | Fully remote (UK) (R1, hard_gate) | hard_gate | Not stated | A gate. Only your answer settles it | — | — | `[inferred]` from your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have much online presence, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; checks blocked this session | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | "Fully remote (UK)" (no salary given) | The figure may be below your floor, or they may simply not publish pay | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | "Own pricing analytics" with no team or sign-off stated | unknown | — | "Own pricing analytics for our pet-insurance product" | You might be the only pricing analyst, accountable for rates that someone else signs off | `[inferred]` from the ownership language and the silence on team size and authority | How big is the pricing team, and who approves rate changes? | unresolved |
| RR4 | Concrete mandate with a named senior manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is clear and matches what you already do | `[grounded]` JD; your message names the Director of Pricing | What would a strong first six months look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Open the CV and cover note with your own words: "Built and maintained the GLM rating model for our young-driver book" and "Ran 14 price tests last year with the underwriting team." Don't upgrade "ran" to "designed" unless you confirm it | see R3, R4, R5 | `[grounded]` your background | pending your approval |
| P2 | Name the pet gap yourself: "I haven't priced pet insurance; the GLM and price-testing methods are what I'd bring, and the pet-specific rating factors are what I'd need to learn" | see R10, G2 | `[grounded]` your background; `[generic]` that factors differ by line | pending your approval |
| P3 | With a pricing director as the reader, lead with the price tests and how you read them, then the GLM | see R5, R8 | `[inferred]` from the hiring manager's title only; their footprint couldn't be checked | pending your approval |
| P4 | Check that Brindlemoor and the posting are live on the company's own site before you put time into the application | see RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask the RR2 and RR3 questions in your first conversation | see RR2, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Brindlemoor pet insurance careers Senior Pricing Analyst" and the search was refused. It would have resolved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | I searched "senior pricing analyst insurance UK salary 2026" and the search was refused. It would have set the market calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | unavailable | I searched "Odile Varga Director of Pricing Brindlemoor" and the search was refused. It would have sharpened P3 |

I can write all of this up as a `tuesday-dossier.md` whenever you'd like one.

## Upgrade menu

- Allow web search → RR1 resolves either way, the market calibration line gets a pay band, and P3 is tailored to the hiring manager.
- Your UK base and any non-negotiables, such as a pay floor → R1 closes and RR2 can be checked against your floor.
- An answer to G1 → R7 moves to `direct`, or stays as a named gap.
- A sanitized price-test readout or pricing-review deck → R5 and R8 can rise to `high`.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring patterns, employee reviews, recent news; up to 5 more searches and 2 more fetches) → just say the word.

**Q1 (R1):** Are you UK-based with the right to work, and do you have any non-negotiables, such as a pay floor or contract type?

**Q2 (G1):** Have any of your price-test results or pricing reviews led to a product change, like a cover option, excess, discount or launch? Which part of that was yours?

**Q3:** Shall I run the company, salary and hiring-manager searches if you allow web search?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.