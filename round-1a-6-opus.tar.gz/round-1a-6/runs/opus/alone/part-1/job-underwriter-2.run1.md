Reading the skill's worked report template, then running a few targeted searches on Quartzline.
## Decision snapshot

**No, you're not wasting your time, but this is a stretch application rather than a clear fit. The one requirement you can't meet is R1a (3+ years with a PM title), and how you write your resume won't change that. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1b (Product-shaped work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1a (3+ years titled PM experience)
- `important`: adjacent: R6 (Own the API platform roadmap), R7 (Discovery with integration partners), R8 (Write specs, drive delivery with two squads), R10 (Coordinate launches with sales and support) · unclear: R9 (Define and track adoption metrics)

R1a: absent, and rewording won't close it; R2, R6, R7, R8, R10: credible bridges whose limits are named in each row; R3 (`medium`): your strongest match, still waiting on an inspectable artifact; R9: the row where an unconfirmed lead could recover the most.

**Opportunity ledger.** The mandate is concrete and staffed (RR4). I couldn't check that the employer exists as described (RR1). Pay (RR2) and location or working pattern (RR3) are not stated.

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Quartzline's own careers page (RR1). (2) You reach someone there through a referral or a direct note to the hiring team instead of applying cold, because of R1a (see A2). (3) R2 and R8 are always presented as adjacent work, never as having shipped API products or held a PM title (P1). (4) Pay and location turn out acceptable to you (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline: B2B logistics tech, about 150 people, Series B | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Resourcing | Two engineering squads are named as this role's delivery partners | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated. "Define … adoption metrics" suggests the metrics don't exist yet, so setting them is probably early work | `[inferred]` from the JD's "define and track" wording |
| Scope read | One platform, two squads, external partners: a normal remit for a mid-level PM | `[generic]` role-family pattern; not checked by research |
| Market calibration | Not established. The pay-band search was refused, and model memory is not a source for pay figures | none |
| Unknowns | Pay; location and remote policy; who the role reports to; whether the API platform is already live or still being built | none |
| Contradictions | None in the pasted JD. Not checked against the careers page (RR1) | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience, counted as years in the role | must_have | absent | none | capability | You say directly that you have never held a PM title. The JD marks this requirement "must-have", the only one it labels that way. Requirements like this are often screened literally at the resume stage. It is a material risk, not a gate | `[grounded]` your statement and the JD; `[generic]` that such requirements are screened literally | Carry it as the main risk. The way around it is a referral (A2), not wording |
| R1b | Product-shaped work: requirements, roadmap input, cross-functional delivery | must_have | adjacent | medium | transferability | Requirements documents, quarterly roadmap-input sessions for product, and coordination with PMs on custom builds. Limit: you fed the roadmap; you did not own prioritization or trade-offs | `[grounded]` your stated background | Bridge case in G4 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | "Led 30+ client integrations of our REST APIs end to end." This is on the same side as the role: vendor-side, partner-facing. Limit: you implemented an API someone else owned and did not decide what it does. The custom builds may be closer to shipping; that's unknown | `[grounded]` your stated background | G4 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, and integration architecture on more than 30 integrations. Self-reported and specific, with nothing inspectable yet. Expect to be tested on it | `[grounded]` your stated background | An integration architecture doc or playbook excerpt (sanitized) would raise this to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | "Coordinated our engineers, the client's engineers, and product managers on custom builds" | `[grounded]` your stated background | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Your background doesn't mention sales. Solutions engineering often sits next to sales, but that is a pattern and not your history | `[grounded]` background silent; `[generic]` that SE roles sit near sales | G3 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | Your background doesn't mention sprints, backlogs or delivery method | `[grounded]` background silent | G1 |
| R6 | Own the roadmap for the partner-facing API platform | important | adjacent | medium | transferability | Roadmap-input sessions put you on the feeding side of a roadmap. Limit: you didn't decide what was built or in what order | `[grounded]` your stated background | G4 |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions with clients. Limit: scoping defines one implementation, while product discovery decides what to build for many partners. The kind of work differs | `[grounded]` your stated background | Bridge case in the plan (P1) |
| R8 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and integration architecture, plus coordinating engineers through UAT and go-live. Limit: project delivery for one client, not continuous ownership of a squad's backlog | `[grounded]` your stated background | W1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Your background doesn't mention metrics. A prior-conversation lead says you built an internal request-triage tool that support agents adopted. It is unconfirmed, so it only prompts a question | `[grounded]` background silent; lead from memory only | G2 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | More than 30 go-lives, plus "the internal integration playbook the whole team uses". Limit: client go-lives, not product launches with sales and support enablement | `[grounded]` your stated background | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Agile delivery (R5, must_have) | discovery | Nothing about delivery method | One of the cheaper requirement rows to close, and it sits in the requirements list | Working in your engineers' sprints on custom builds; writing tickets or acceptance criteria; joining backlog grooming for integration work | A sanitized Jira or Linear epic you wrote, or acceptance criteria from a UAT plan | `[grounded]` background silent |
| G2 | Adoption metrics (R9, important), via the triage-tool lead | discovery | An unconfirmed lead from memory only | If it's true, a tool you built that others chose to use is the closest thing you have to product evidence: a user problem, something shipped, adoption. It could strengthen R1b and R9 together | Spotting the support team's triage problem; building or speccing the tool; counting how many agents used it, or how response times changed | A screenshot, a usage count, an announcement message, the tool's doc | Lead from memory; `[inferred]` that it would strengthen R1b and R9 if confirmed |
| G3 | Sales collaboration and launches (R4b, R10) | discovery | Sales isn't mentioned anywhere | R4b sits in the requirements list, and R10 names sales directly | Pre-sales scoping calls; technical sections of RFPs; handing implementation status to account execs; briefing support at go-live | A playbook section aimed at sales or support | `[grounded]` background silent |
| G4 | API product ownership (R2, R6, R1b) | transferability | Implementation leadership on someone else's API; custom builds where ownership is unclear | It decides whether R2 is a near-miss or real product experience | A custom build that became a general feature; an endpoint or schema change you specified; client feedback from your sessions that shipped | A spec you wrote, a release note naming the change | `[grounded]` background; `[inferred]` that custom builds may be closer to product ownership |
| G5 | Titled PM years (R1a) | capability | You confirm you've never held a PM title | Wording can't close it | No question. The ways forward are a referral (A2), an internal transfer to PM at your current employer, or roles titled "Technical PM" or "Associate PM" that don't ask for titled years | none | `[generic]` common routes into PM from solutions engineering |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. The search was refused, so none of these was tested | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | Posting gives no figure | The figure may sit anywhere relative to market. No band was established | `[grounded]` JD silent | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and working pattern unstated | unknown | — | Posting gives no location | Could be remote, hybrid or on-site | `[grounded]` JD silent | Where is this role based, and how many office days are expected? | unresolved |
| RR4 | Concrete mandate with named resourcing | positive_signal | — | "drive delivery with two engineering squads" | The role has people to deliver through, not just responsibility | `[grounded]` JD | Is the API platform live with partners today, or still being built? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Quartzline's own careers page before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Look for a referral or a direct line to the hiring PM or head of product instead of applying cold | R1a. A person can weigh adjacent evidence that a literal screen can't | `[generic]` how screening of titled-years requirements tends to work | pending your approval |
| P1 | Positioning: start with the 30+ REST API integrations and the roadmap-input sessions, presented as a solutions engineer moving into product. Never say you shipped API products or have PM years. Present discovery as "scoping and client feedback for product" | R2, R7, R1b | `[grounded]` your own phrasing | pending your approval |
| E1 | Summary line: "Solutions engineer and implementation lead, 7 years; led 30+ client integrations of our REST APIs end to end; moving into product management." Every phrase comes from your own description | R2, R3 | `[grounded]` your background, checked phrase by phrase against your sentences | resume_edits_pending_approval |
| W1 | A one-page sample spec for a partner-facing logistics API feature (problem, partner need, schema sketch, adoption metric) to attach or bring to interviews | R8, R9: narrows both limits with something they can inspect | `[inferred]` from the transferability recovery pattern | pending your approval |
| Q1 | Ask the verification questions for RR1–RR4 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

All language in P1, E1 and W1 is a proposal. None of it is final until you approve it.

## Evidence status

Verified: none yet. Unverified lead: the triage tool support agents adopted (from prior-conversation memory, unconfirmed; G2).

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B careers"; the web-search permission was refused. It would have checked company stage and size, whether the posting is live, and the contradictions row, and could have cleared RR1 |
| 2. Role-family sweep | unavailable | Searched "Product Manager Platform API salary Series B B2B SaaS 2026"; the permission was refused. It would have set the market-calibration row and given a band for RR2 |
| 3. Hiring manager's public footprint | n/a | You didn't give a name, so there was nothing to search |

I can save this as `tuesday-dossier.md` if you'd like a file to carry between sessions.

## Upgrade menu

- **Allow web search:** targets 1 and 2 run. That could clear RR1 and gives a pay band for RR2. A deeper pass (funding, leadership churn, recent news) is also available for up to 5 more searches and 2 more fetches.
- **An answer to G2 with a usage count or screenshot:** R9 and R1b could move up; this is the biggest upgrade available.
- **An answer to G4:** R2 is settled as either a near-miss or real product work.
- **A sanitized integration architecture doc or playbook excerpt:** R3 rises to `high`.
- **Your pay floor, location needs and work authorization:** these become hard-gate rows, so the hard-gates line stops reading "unknown".
- **The hiring manager's name:** target 3 runs, and you'll know which story to lead with for that reader.

**Questions**

G2: Did you build an internal request-triage tool that support agents adopted? If so, what part was yours (spotting the problem, the spec, the build), how many people used it, and did anything measurably change?

G4: Did any of your custom builds or client feedback turn into something the core product shipped? If so, what exactly did you specify or decide?

Constraints: what are your non-negotiables on pay, location or remote work, and work authorization? And are you just evaluating, or already applying?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.