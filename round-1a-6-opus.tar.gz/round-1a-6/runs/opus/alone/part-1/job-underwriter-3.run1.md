I've read the skill's rules. Next I'll run a few quick searches to check the company and the usual pay for this role.
# Novaline, Head of Growth: should you pursue it?

## Decision snapshot

**No, this posting isn't worth pursuing as written. R1 and R2 are both hard gates, and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R3 (Evenings and weekends when it matters) · hard_gate_fail: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland)
- `must_have`: direct: R4, R5, R6, R11 · unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops)
- `important`: adjacent: R12 (E-commerce enablement customer base), R13 (Team of one, hands-on execution)

R1, R2: each one decides this alone; R4, R5, R6, R11 (`medium`): a strong fit on paper, waiting on proof; R7, R8, R9, R10: worth recovering only if the terms change.

**Opportunity ledger.** RR1 and RR2 are the two gate conflicts. The posting also has several warning signs, and these are probably the "something feels off" you noticed. It bundles seven functions into a team of one (RR4). It asks for 8+ years of leadership at a price set far below that mandate (RR3). It expects evenings and weekends (RR5). It doesn't define success (RR6). It names no budget or resources (RR7). I couldn't confirm the employer from here (RR8). The one stated upside is that it says it has been profitable since day one (RR9).

- **Hard gates:** failed: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland); unconfirmed: R3 (Evenings and weekends when it matters).
- **Severe red flags:** none found.
- **What would have to be different:** R1 would need a base of at least $150k, about double the posted $70–85k top. R2 would need fully remote work, where the posting says on-site in Austin "5 days a week — no exceptions." The first is a large gap and the second is stated as final, so wording can't fix either one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline: e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not confirmed from outside, see RR8 |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "Team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| First-year outcomes | Not stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` JD |
| Scope read | Seven functions usually split across several roles, given to a single executive with no team | `[inferred]` from the JD's function list against "team of one"; `[generic]` that these are normally separate roles |
| Market calibration | Not established: the role-family search was refused in this session, so I have no sourced band to compare the $70–85k against | — |
| Unknowns | Growth budget; whether a team hire is planned and when; how success will be judged; equity terms (percentage, vesting, strike) | — |
| Contradictions | A "Head of" title next to "team of one"; an 8+ year senior requirement next to a base that reads far more junior | `[inferred]` from the JD's own terms set side by side |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your hard constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor, which is specific. It fails because the posted range tops out at $85k | `[grounded]` JD range; your stated constraint | Surfaced in the snapshot; only the employer changing its terms resolves it |
| R2 | Remote-only, from Portland (your hard constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint. It fails because the JD requires on-site Austin 5 days a week, "no exceptions" | `[grounded]` JD; your stated constraint | Surfaced in the snapshot; the JD rules out an exception |
| R3 | "Evenings and weekends when it matters" | hard_gate | unclear | none | hard_gate | The JD states it as a schedule term. You stated no constraint on hours, so nothing settles it | `[grounded]` JD quote; no candidate statement | Moot while R1 and R2 fail |
| R4 | 8+ years of growth leadership | must_have | direct | medium | none | You report 9 years: growth lead, then Head of Growth, at two companies. It stays at `medium` because it's self-reported with nothing inspectable yet | `[grounded]` your stated background | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You say you owned paid. Self-reported | `[grounded]` your stated background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and have deep Braze experience. Self-reported | `[grounded]` your stated background | none |
| R7 | SEO/content | must_have | unclear | low | discovery | Your background is silent on it. That isn't the same as absent | `[grounded]` silence in your background | G1 |
| R8 | Brand and PR | must_have | unclear | low | discovery | Your background is silent on it | `[grounded]` silence in your background | G2 |
| R9 | Partnerships | must_have | unclear | low | discovery | Your background is silent on it | `[grounded]` silence in your background | G3 |
| R10 | Sales ops | must_have | unclear | low | discovery | Your background is silent on it. Your companies were B2C subscription businesses | `[grounded]` silence in your background; `[generic]` that sales ops is more common in B2B | G4 |
| R11 | Own revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. That is revenue ownership, though across the channels you named rather than all seven | `[grounded]` your stated background | none |
| R12 | Selling to e-commerce merchants (enablement implies business customers) | important | adjacent | medium | transferability | Subscription growth mechanics carry over. The limit is that both of your companies sold to consumers, not merchants | `[inferred]` that "enablement" means business customers, from the JD header | G5 |
| R13 | Team of one: doing the hands-on work yourself | important | adjacent | medium | transferability | Your SQL, GA4 and Braze depth shows hands-on skill. The limit is that you led teams of 3–7, and nothing says whether you ran every channel alone | `[grounded]` your stated background | G6 |

## Gap recovery queue

These rows only matter if Novaline changes R1 and R2.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | Nothing either way | A `must_have` row; would round out the "end to end" claim | Content-led acquisition programs, SEO work on landing pages or app-store listings, editorial calendars your team ran | A traffic or ranking dashboard, a content plan | `[grounded]` silence in your background |
| G2 | Brand and PR (R8, must_have) | discovery | Nothing either way | A `must_have` row | Launch campaigns, agency management, press for a funding round or milestone | A campaign brief, press coverage | `[grounded]` silence in your background |
| G3 | Partnerships (R9, must_have) | discovery | Nothing either way | A `must_have` row | Co-marketing, affiliate or referral programs, distribution or bundling deals | A partner agreement summary, program results | `[grounded]` silence in your background |
| G4 | Sales ops (R10, must_have) | discovery | Nothing either way | A `must_have` row | CRM pipeline setup, B2B or team plans inside a B2C product, revenue reporting | A pipeline dashboard, a process doc | `[grounded]` silence; `[generic]` that B2C roles touch this less |
| G5 | Merchant customer base (R12, important) | transferability | Strong B2C subscription growth | A bridge from consumer to business buyers; its limit should be named | Small-business or creator segments in your products, any B2B2C motion | A segment analysis, a case study | `[inferred]` from the JD header |
| G6 | Solo execution (R13, important) | transferability | Hands-on tools, but team-led delivery | Team of one means doing the work, not directing it | Periods before you hired, channels you ran yourself | Work you built yourself, such as queries or Braze flows | `[grounded]` your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor (see R1) | red_flag | medium | "$70–85k base plus meaningful equity upside" | The posted top is about $65k under your floor, and equity doesn't pay a base salary | `[grounded]` JD against your stated floor | Is the base range firm, or is there budget for a senior hire at $150k or more? | confirmed |
| RR2 | On-site only, against your remote-only constraint (see R2) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions" | The JD rules out flexibility in its own words | `[grounded]` JD | Is fully remote possible for this role? | confirmed |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required" / "$70–85k base" | Pay may be set for a junior-to-mid role while asking for executive experience. The market band wasn't verified because the search was refused, so this stays a risk signal | `[inferred]` from the JD's own terms; `[generic]` that senior growth leadership usually pays more | How was the base range set, and what level is it benchmarked against? | unresolved |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… team of one" | Several full-time roles folded into one hire | `[generic]` pattern for bundled growth roles | Which two or three of these matter most in the first six months, and which can wait? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The phrasing makes after-hours work part of the culture, not an exception | `[inferred]` from "just who we are" | How often in the last quarter did "when it matters" come up? | unresolved |
| RR6 | Demanding mandate with no success metrics | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for "all revenue growth" with no agreed definition of success | `[inferred]` from the JD's scope against its silence on targets | What would make this hire a success at 6 and 12 months? | unresolved |
| RR7 | Responsibility without stated resources | unknown | — | "we believe in players who don't need a bench" | The JD gives no budget, tooling or hiring plan | `[inferred]` from the JD's silence on budget and headcount | What's the growth budget, and when does the first hire come? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Profitable since day one | positive_signal | — | "profitable since day one" | If true, this means runway and less pressure to raise money | `[grounded]` JD claim, not verified | What revenue and margin does "profitable" refer to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | See R1, R2 | `[grounded]` the map's failed gates | pending your approval |
| A2 | Optional: if the company itself interests you, send one short note asking whether a remote, senior-paid version of the role exists. Don't spend more than that | Only the employer changing terms resolves R1 and R2 | `[grounded]` R1, R2; RR1, RR2 | pending your approval |
| A3 | If you go ahead anyway, ask the RR1–RR8 verification questions word for word before investing time | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin"; the call was refused (search permission not granted). Would have confirmed the company exists as described and whether the posting is live, which would resolve RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026"; the call was refused. Would have given the market band for role reality and confirmed or eased RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

If you want a saved record, I can write this up as `tuesday-dossier.md`.

**Upgrade menu**
- Allow web search: targets 1 and 2 run, which confirms or resolves RR8 and puts a sourced market band against RR3.
- A link to the live posting or Novaline's careers page: RR8 resolves.
- Your CV: R4–R11 can rise above `medium` where it adds detail, and G1–G4 may close from what it shows.
- The hiring manager's name: sharpens the scope read and which of your stories to lead with.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.