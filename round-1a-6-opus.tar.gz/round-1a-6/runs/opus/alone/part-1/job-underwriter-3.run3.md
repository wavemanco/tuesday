I'm checking the employer and market pay before writing the assessment.
# Novaline, Head of Growth: should you apply?

## Decision snapshot

**No, it isn't worth pursuing, and your sense that something is off is right. R1 and R2 are both hard gates and both fail · `no_go`**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Compensation: $70–85k base)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)
- `important`: unclear: R10 (Selling to businesses), R11 (Team of one to start)

R1, R2: terms that no wording can fix. R3, R4, R5 (`medium`): your core growth record. R6, R7, R8, R9, R10, R11: scope your background doesn't show yet. None of that matters unless R1 and R2 move.

**Opportunity ledger.** Apart from your constraints, the role itself raises flags. RR1 and RR2 are your two constraints colliding with the posting. RR3 is senior requirements set against a low base. RR4 and RR5 are seven functions with no team and no stated budget. RR6 is open-ended hours. RR7 is a mandate with no fixed definition of success. RR8 puts equity in place of cash. RR9 is that I couldn't verify the employer. RR10 runs the other way: reporting to the CEO with a dotted line to the board.

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Compensation: $70–85k base)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** Novaline would have to offer both a fully remote role from Portland and a base of at least $150k. One without the other still fails, because you set both as non-negotiable.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline. The posting calls it an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting text; not checked independently (RR9) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` posting |
| Working pattern | "On-site in our Austin office 5 days a week — no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | "$70–85k base plus meaningful equity upside" | `[grounded]` posting |
| First-90-days / first-year outcomes | Not stated. "Success metrics will evolve as we learn" | `[grounded]` posting is silent |
| Scope read | Seven functions owned by one person with no team, at head-of-function seniority. That is broader than one role | `[inferred]` from counting the functions listed against "team of one" |
| Market calibration | Not established: the role-family sweep couldn't run, so I give no market band here | — |
| Unknowns | Marketing budget and who controls it; whether there's a plan to hire; equity terms (percentage, strike price, vesting); who the customers are | — |
| Contradictions | None inside the posting. I couldn't check it against a careers page | `[grounded]` posting read in full |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit: remote-only, living in Portland, not relocating. The posting rules remote work out in so many words | `[grounded]` posting and your stated constraint | Only a change in Novaline's terms resolves it |
| R2 | Compensation: $70–85k base, against your $150k floor | hard_gate | hard_gate_fail | high | hard_gate | The top of the posted range is $65k below your floor. Equity doesn't count toward a base floor | `[grounded]` posting and your stated constraint | Only a change in Novaline's terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years in growth, as growth lead and then Head of Growth at two companies. You didn't say how many of the 9 were in lead roles, so `medium` until that's confirmed | `[grounded]` your intake message | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid and scaled one company from $8M to $40M ARR over three years with a budget you controlled. Self-reported, nothing inspectable yet | `[grounded]` your intake message | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and are deep in Braze | `[grounded]` your intake message | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` silence in your intake | Moot under `no_go` |
| R7 | Brand and PR | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` silence in your intake | Moot under `no_go` |
| R8 | Partnerships | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` silence in your intake | Moot under `no_go` |
| R9 | Sales ops | must_have | unclear | none | discovery | Your background doesn't mention it. Both companies were B2C subscription businesses | `[grounded]` your intake message | Moot under `no_go` |
| R10 | Selling to businesses (merchants) | important | unclear | none | discovery | "E-commerce enablement" plus a sales-ops remit suggests business customers. Your record is B2C | `[inferred]` from "e-commerce enablement" and "sales ops" in the posting | Moot under `no_go` |
| R11 | "Team of one to start": hands-on work across every channel | important | unclear | low | discovery | You led teams of 3–7. Your SQL, GA4 and Braze depth points to hands-on work but doesn't show it across all seven functions | `[inferred]` from the tools you named | Moot under `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Channels beyond paid and lifecycle (R6, R7, R8, R9; must_have) | discovery | Ownership of paid, lifecycle and experimentation only | Would decide how complete your fit is, but only matters if R1 and R2 change | An SEO or content program you ran or oversaw; agency or PR relationships you managed; a partnership or affiliate channel you launched | A channel-mix deck, a content calendar, a partner deal summary | `[grounded]` silence in your intake |
| G2 | Selling to businesses (R10, important) | discovery | B2C subscription only | Same: only matters if R1 and R2 change | Any B2B pilot, a merchant-facing product, or sales-assist funnels | A pipeline dashboard or a funnel write-up | `[inferred]` from "e-commerce enablement" in the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below the candidate's floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted range tops out $65k under your floor | `[grounded]` posting and your stated constraint | Is the base range firm, or is there room above $85k for this hire? | confirmed |
| RR2 | On-site only, against remote-only (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out the only arrangement you'd accept | `[grounded]` posting and your stated constraint | Is there any scenario where this role is remote? | confirmed |
| RR3 | Seniority and pay mismatch | risk_signal | medium | "8+ years growth leadership required" / "$70–85k base" | The base may sit well below what this seniority usually earns. Unconfirmed because the market sweep couldn't run | `[inferred]` from the posting setting its own seniority bar beside its pay | How did you arrive at the base range for an 8+-year head of growth? | unresolved |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several functions folded into one seat, accountable for all of them | `[inferred]` from the functions listed against "team of one" | Which of these seven do you expect to be delivered in year one, and which can wait? | unresolved |
| RR5 | Responsibility without stated resources | risk_signal | medium | "players who don't need a bench" | No team, budget or hiring plan is mentioned for a revenue mandate | `[inferred]` from the posting's silence on budget and headcount | What's the annual growth budget, who controls it, and when is the first hire? | unresolved |
| RR6 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work is framed as part of the culture, not as an exception | `[inferred]` from the quoted wording | In the last quarter, how many weekends did the team work? | unresolved |
| RR7 | Demanding mandate, success undefined | risk_signal | medium | "success metrics will evolve as we learn" | You'd own all revenue growth with no fixed definition of success | `[inferred]` from the quoted wording | What would make this hire a success at six and twelve months? | unresolved |
| RR8 | Equity used in place of cash | unknown | — | "meaningful equity upside" | The equity may be offered to make up for the low base. Its terms aren't stated | `[inferred]` from the base range sitting next to the equity language | What percentage, strike price, vesting and last valuation come with the grant? | unresolved |
| RR9 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR10 | Senior access | positive_signal | — | "Report to the CEO with a dotted line to the board" | You'd have direct access to the people who decide | `[grounded]` posting | How often would this role present to the board? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | see R1, R2, RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | Optional: one short note to the recruiter asking whether this role could be remote at a $150k+ base. Stop there if the answer is no | It's the only path that changes R1 and R2, and it costs one message | `[grounded]` RR1, RR2 | pending your approval |
| A3 | If they say yes to both, ask the RR3 to RR9 questions before any interview | The register doubles as your screening checklist | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin". The search was refused because web search isn't permitted in this session. It would have checked the organization row and contradictions, and cleared or confirmed RR9 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026". Also refused for lack of permission. It would have set the market calibration row and confirmed or cleared RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can write all this up as a `tuesday-dossier.md` you can keep or carry into later sessions, if you'd like.

## Upgrade menu

- Allow web search → target 1 checks Novaline's existence and the live posting (RR9), and target 2 sets a market pay band (RR3). Neither changes the `no_go`.
- The hiring manager's name → the scope read in role reality.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs once search is allowed.
- A recruiter reply offering remote work and a $150k+ base → R1 and R2 reopen, and G1, G2 and the RR3 to RR9 questions become the next step.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.