I've read the evaluation framework. Next I'll run a few quick searches to check the employer and the market, then write up the assessment.
# Senior Product Analyst at Harborlight Health: fit assessment for Arjun

## Decision snapshot

**Yes, you're a fit, and it's worth applying once you've confirmed the employer and the posting are real. R1, R2, R3, R4, R5 and R7a are all `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct R1, R2, R3, R4, R5, R7a · adjacent R6 (Define and maintain the metrics layer)
- `important`: adjacent R7b (Partner with clinicians) · unclear R8 (Mentor two junior analysts)
- `preferred`: adjacent R9 (Healthcare data experience, HIPAA)

R6 is probably one question from `direct`. R7b and R9 are real bridges with their limits named. R8 has no evidence either way yet.

**Opportunity ledger.** Nothing here is alarming, but a lot is unverified. I couldn't check the employer (RR1), the pay isn't stated (RR2), and ownership of the data stack and experiment volume are open (RR3, RR4). The JD itself is specific and internally consistent (RR5).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the employer and the live posting check out (RR1); (2) the pay meets your floor (RR2); (3) R9 is always described as adjacent privacy work, never as HIPAA experience

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up with about 400 people, Series C | `[grounded]` JD header, not independently checked (RR1) |
| Mandate | Own product analytics for the care-navigation app: the metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians | `[grounded]` JD |
| Team | Mentor two junior analysts | `[grounded]` JD |
| First-90-day / first-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | A full product-analytics remit for one app, with a small team under you. It reads like a working senior IC/lead role, not an empty title | `[inferred]` from the responsibility list plus two named reports |
| Market calibration | Not available. The role-family search couldn't run (see Evidence status) | — |
| Compensation | Not stated in the posting | `[grounded]` JD; see RR2 |
| Unknowns | Pay; location and remote policy; reporting line; who owns data engineering; experiment traffic; clinical review of tests | — |
| Contradictions | None inside the JD. Not compared against the careers page because the check couldn't run | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years of product analytics at a subscription company. Specific and self-reported, with no artifact yet (intake ceiling) | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake. "Expert" will be tested in a technical screen, not taken from the CV | `[grounded]` your background; `[generic]` that senior analyst loops usually include a live SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Ownership and an outcome are both stated | `[grounded]` your background | none; it's your lead story (P1) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch, with 40+ governed dashboards. Same tool the JD names | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | Optional: a redacted memo (P6) |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | "Governed dashboards" points to centrally defined metrics, but your background doesn't say you owned metric definitions or the Looker model. Held at adjacent until you confirm | `[inferred]` from "governed dashboards" and "built from scratch" | G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | must_have | direct | medium | none | A pricing test you ran is tied to a retention outcome, and you present to the VP Product monthly | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | What carries over: translating analysis for non-technical execs. The limit: no clinical stakeholders so far. `[generic]` Clinicians tend to judge evidence differently from execs (more caution about harm, different norms) | `[grounded]` your background; `[generic]` the clinical-norms clause | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or managing anyone | `[grounded]` silence in your background | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | What carries over: GDPR/CCPA consumer PII, and you built the consent-state model for the warehouse. The limit: you haven't worked in healthcare, which you said yourself. `[generic]` HIPAA brings concepts GDPR/CCPA don't cover one-to-one: PHI, business associate agreements, de-identification standards | `[grounded]` your background; `[generic]` the HIPAA-concepts clause | G4; framing in P3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Looker built from scratch with governed dashboards, but no stated ownership of metric definitions | It's the JD's first responsibility. Confirming it moves the last adjacent must-have to `direct` | Writing the LookML model or explores; defining "active subscriber" or "churn" so every dashboard used one version; a metrics dictionary; resolving two teams' conflicting numbers | A redacted LookML snippet, a metrics glossary page, or a definitions doc | `[grounded]` your background's silence on definitions |
| G2 | Mentoring (R8, important) | discovery | Nothing either way | Two named reports make it a real part of the job | Onboarding a new analyst; reviewing others' experiment designs or SQL; running a test-design review; a teammate you brought up to speed | A review checklist, a training doc, or an internal guide you wrote | `[grounded]` silence in your background |
| G3 | Clinicians (R7b, important) | transferability | Exec and VP Product audiences, no clinical ones | It's the clearest domain-new part of the role | Explaining uncertainty or a null result to a decision-maker; a test stopped or shaped by a safety, legal or ops partner | The metrics memo (redacted) | `[grounded]` your background; `[generic]` that domain-new stakeholders get probed |
| G4 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | It's a stated plus. An honest bridge beats an overclaim | Access controls on PII tables, deletion or consent propagation, working with legal on data use | A description of the consent-state model with no data in it | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (the check couldn't run) | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have much of a footprint, the posting may be old or copied from an aggregator, or it may not be a real hiring employer | `[generic]` a pattern for companies like this, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (the posting has no pay language) | The figure may be below what you'd accept, or the company may just not publish ranges | `[inferred]` from the missing figure | What's the budgeted range for this role? | unresolved |
| RR3 | Who owns the data stack under the metrics layer | unknown | — | "define and maintain the metrics layer" | The role may carry data-engineering work that isn't in the JD | `[inferred]` from the JD saying nothing about a data or platform team | Who owns the warehouse and pipelines, and where does analytics' responsibility for the metrics layer start? | unresolved |
| RR4 | Experiment volume and review in a health product | unknown | — | "design and analyze A/B tests" … "partner with … clinicians" | Traffic may be lower than at a 2M-subscriber consumer business, and tests may need clinical sign-off | `[generic]` that care-navigation products often have smaller user bases and add clinical review | What's typical weekly traffic for a test, and what review does a test go through before launch? | unresolved |
| RR5 | Specific, coherent JD: named tools, named team size, clear remit | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The scope is concrete and the resourcing is stated | `[grounded]` JD | What would a successful first 90 days look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P0 | Find the posting on Harborlight Health's own careers page before tailoring anything | RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the experimentation program, in your own words: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3 | `[grounded]` your background | pending your approval |
| P2 | Second story: "Built the company's Looker instance from scratch — 40+ governed dashboards." Add metric-definition ownership only if G1 confirms it | R4, R6 | `[grounded]` your background | pending your approval |
| P3 | Name the healthcare gap plainly in the cover note: "I haven't worked in healthcare; I've handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." | R9 | `[grounded]` your background | pending your approval |
| P4 | Ask the questions from RR2, RR3, RR4 and RR5 word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |
| P5 | Prepare a redacted metrics memo or experiment write-up as a work sample, if your employer allows it | R5, R3 | `[grounded]` R5, R3 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app". The call was refused because web search permission isn't granted. It would have confirmed or cleared RR1 and filled the contradictions row |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026". The call was refused for the same reason. It would have given the market calibration row and a pay band to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

---

I can save all of this as `tuesday-dossier.md` so you can carry it into later sessions, if that's useful.

**Upgrade menu**
- **Web search permission:** turning it on runs targets 1 and 2, which would clear or confirm RR1 and add a market pay band.
- **A link to the live posting on Harborlight's own site:** resolves RR1 without any search.
- **Your pay floor, location and remote needs, and work authorization:** turns the hard-gates line from "unknown" into real checks.
- **Answers to G1 and G2:** R6 may move to `direct`, and R8 gets graded.
- **A redacted LookML snippet, metrics glossary or memo:** raises R6 or R5 to `high`.
- **The hiring manager's name:** tells you which story to lead with for that reader.
- **A deeper research pass on Harborlight:** funding, leadership churn and employee reports; up to 5 more searches and 2 more fetches. It also needs search permission. Say the word and it runs.

**Questions**

1. **Constraints:** what's your pay floor, and do you need a specific location or remote arrangement (and any work-authorization limits)?
2. **G1:** did you personally define the metrics behind those governed dashboards, for example by writing the Looker model or a metrics dictionary, or settling which "churn" definition won?
3. **G2:** have you mentored, onboarded or reviewed the work of other analysts, even informally?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.