Reading done; now running the L1 checks on Harborlight Health and the role family.
# Harborlight Health — Senior Product Analyst

## Decision snapshot

**Yes. You fit this role on substance and it's worth applying to, but two conditions come first: confirm the employer is who the posting says, and check the role's terms against your own limits. Every must-have (R1, R2, R3, R4, R5) is a `direct` match. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · unclear: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience (HIPAA))

R8: your background doesn't mention mentoring, and that's the senior-level part of this role. R9 (`medium`): you have real privacy work to point to, but it isn't HIPAA experience. R6: "governed dashboards" suggests you've built a metrics layer, but you haven't said so.

**Opportunity ledger.** The role looks normally scoped and has a team behind it (RR4). I couldn't confirm the employer itself, because the search was blocked (RR1). The posting doesn't give pay (RR2) or location (RR3). And it's an open question how much "self-serve" is possible on health data (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight Health and this live posting check out on its own careers page (RR1). (2) Pay and location clear your floor and needs (RR2, RR3). (3) R9 is presented as consumer-privacy work, never as HIPAA or healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: digital-health scale-up, about 400 people, Series C, makes a care-navigation app | `[grounded]` JD header; not checked independently (RR1) |
| Mandate | Own product analytics: the metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Must-haves | 5+ years product analytics; expert SQL; experiment design at scale; Looker or similar; strong writing for non-technical readers | `[grounded]` JD |
| Preferred | Healthcare data experience (HIPAA) | `[grounded]` JD, "a plus" |
| Hard gates | None stated: the JD names no location, work authorization, schedule or pay | `[grounded]` JD silence |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | One analytics area plus a small team to lead. That's ordinary for this title, not several jobs folded into one | `[inferred]` from the responsibilities list against the "two junior analysts" line |
| Market calibration | Not established. The role-family search was blocked, and I won't give a pay band from memory | — |
| Unknowns | Pay; location and remote policy; PHI access for analysts; what success in year one looks like | — |
| Contradictions | None inside the JD. Couldn't check it against the careers page (RR1) | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years. Specific, but a first pass can't go above `medium` | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse". Daily use is stated; "expert" will be tested, not taken on trust | `[grounded]` your background; `[generic]` that SQL depth gets tested live in this role family | Prepare for a live SQL exercise |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program, 30+ tests a year, about 2M subscribers, the pricing test behind an 11% retention lift | `[grounded]` your background | A sanitized test write-up would raise this to high |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards. Same tool the JD names | `[grounded]` your background | Sanitized screenshots or a LookML excerpt would raise this to high |
| R5 | Strong writing for non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo the exec team reads, plus a monthly presentation to the VP Product | `[grounded]` your background | A redacted memo would raise this to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed" dashboards hint at shared metric definitions, but you never say you own a metrics layer. Low, not none, because there's something concrete to ask about | `[inferred]` from "governed" | see G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | The pricing test produced a shipped decision, and you present to the VP Product monthly | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | You've never worked in healthcare, and your background names no partner with domain expertise | `[grounded]` your background | see G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring or managing anyone | `[grounded]` your background is silent | see G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Real overlap: GDPR/CCPA consumer PII, and you built the consent-state model. The limit: none of it involved health information under HIPAA | `[grounded]` your background; `[generic]` that HIPAA's rules for health information are a different regime from consumer-privacy law | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | 40+ governed Looker dashboards; no stated ownership of metric definitions | It's the first line of the mandate, so proof that you've owned it changes how you position yourself | You wrote the LookML explores and measures that defined retention or churn; you resolved two teams' conflicting definitions of the same metric; you ran a metric-certification or change process | A LookML excerpt, a metrics dictionary, a definitions doc | `[inferred]` from "governed"; `[grounded]` the mandate's wording |
| G2 | Mentoring (R8, important) | discovery | Nothing yet | It's the senior-level part of the role, and right now there's no evidence for it at all | Onboarding a new analyst onto the warehouse; reviewing other people's SQL or experiment designs; teaching PMs to read test results; leading an analytics guild | Your own description; a review comment you wrote; a training doc | `[grounded]` your background is silent; `[generic]` that senior titles get probed on team leadership |
| G3 | Clinicians (R7b, important) | discovery | Never worked in healthcare | It sets which story you bring to the clinician-partnership question | Working with nutritionists, food-safety or operations specialists on analysis they acted on | Your own description | `[inferred]` that partnering with domain experts is the nearest equivalent |
| G4 | HIPAA (R9, preferred) | transferability | Consumer PII under GDPR/CCPA; a consent-state model | Preferred only, so it can't sink you, but it's an honest bridge to show | What carries over: modelling consent and access state, PII handling. The limit: no health information, no HIPAA. What would strengthen it: a short note on how your consent model would map to PHI access tiers | A sanitized consent-model diagram | `[grounded]` your background; `[generic]` that HIPAA is a separate regime |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to show up, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. Here, the search was blocked, so nothing was checked | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (the posting gives no figure) | The figure may sit below what the title usually pays, or the company may just not publish pay | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | (the posting gives no location) | Could be remote, hybrid or on-site; that matters against any limits you have | `[inferred]` from the posting's silence | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Defined scope with an existing team | positive_signal | — | "mentor two junior analysts" | You'd be joining an analytics team that already has people, not building one alone | `[grounded]` JD | Who do the analysts report to, and how is analytics staffed today? | noted |
| RR5 | Self-serve dashboards on health data | unknown | — | "build self-serve dashboards in Looker" | Access controls on health information may limit how self-serve the dashboards can be | `[inferred]` from the self-serve mandate in a care-navigation product | What health data can analysts query, and is there a de-identified layer for self-serve? | unresolved |

## Application plan

Everything below is proposed language for you to approve. Each line traces back to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find this role on Harborlight Health's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | see R3 | `[grounded]` your words | pending your approval |
| P2 | Second line: "Built the company's Looker instance from scratch: 40+ governed dashboards." | see R4 | `[grounded]` your words | pending your approval |
| P3 | Third line: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | see R5 | `[grounded]` your words | pending your approval |
| P4 | Privacy line, exactly this scope: "Handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." Never "HIPAA experience" | see R9 | `[grounded]` your words | pending your approval |
| Q1 | Ask the RR1, RR2, RR3 and RR5 questions word for word at the recruiter screen | The register doubles as your interview questions | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app". The host refused permission. It would have confirmed the company and the live posting (RR1, role reality's Organization and Contradictions rows) |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary scope 2026". The host refused permission. It would have filled market calibration and given a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | You didn't give a name, so there was nothing to search |

I can save all this as `tuesday-dossier.md` so you can carry it into later sessions. Just say if you want it.

**Upgrade menu**
- **Allow web search:** I'd rerun targets 1 and 2. That could clear RR1 and lift the cap on the decision, and it would give a pay band for RR2.
- **A deeper pass:** funding, leadership turnover and employee reports, up to 5 more searches and 2 more fetches. This needs search allowed.
- **Your limits (pay floor, location, work authorization):** gives the hard-gates line something to check.
- **Sanitized artifacts** (a LookML excerpt, a test write-up, a redacted memo): would raise R3, R4, R5 and R6 toward `high`.
- **The hiring manager's name:** tells you which of your stories to lead with for that reader.

**Questions**

1. **G2:** Have you mentored or onboarded anyone? For example, reviewing another analyst's SQL or experiment designs, or teaching PMs to read results. What was yours, and for how long?
2. **G1:** Did you own the metric definitions behind those governed dashboards, such as LookML measures or a metrics dictionary? Or was it more that you built the dashboards on definitions others set?
3. **Constraints:** What's your pay floor, and do you need remote, a particular location, or visa sponsorship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.