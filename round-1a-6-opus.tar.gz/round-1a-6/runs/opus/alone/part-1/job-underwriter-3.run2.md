I'm reading the skill's rules, then I'll do a quick check on Novaline and market pay before writing up the assessment.
Your instinct is right. This doesn't fit you, and the posting has problems that go beyond your fit.

## Decision snapshot

**No, not worth pursuing: R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland)
- `must_have`: direct: R3, R4, R5 · adjacent: R6 (Owning all growth hands-on as a team of one) · unclear: R7 (SEO/content)
- `important`: adjacent: R11 (Growth for an e-commerce enablement business) · unclear: R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops), R12 (Reporting to the board)

R1, R2: failed on the posting's own terms, and no wording changes that; R3, R4, R5: the core of your record, matching the posting's own language.

**Opportunity ledger.** Your two constraints conflict head-on with the posting (RR1, RR3). Leaving those aside, the role shows strain on its own: seven functions with no team and no stated budget (RR4, RR5), always-on hours stated as culture (RR6), and no success metrics on a demanding mandate (RR7). The pay looks low for the mandate, but that couldn't be checked against the market (RR2). The equity terms (RR8) and the employer itself (RR10) are unverified. One entry points the other way: profitability is claimed (RR9).

- **Hard gates:** failed: R1 (Base pay of at least $150k), R2 (Remote-only, from Portland).
- **Severe red flags:** RR1 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** R1 and R2 would both have to change: a base of $150k or more, and the role opened to fully remote work from Portland, which the posting's "no exceptions" rules out. Even then, RR4, RR5, RR6 and RR7 would need clean answers before this became a `conditional_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting text; not confirmed (RR10) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Resources | "A team of one to start"; no budget mentioned | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Terms | $70–85k base plus "meaningful equity upside"; on-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| First-90-days and first-year outcomes | None stated: "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | One person covering seven functions, priced well below your floor (R1), with seniority demands (8+ years) that don't match the resources offered | `[inferred]` from the function list set against "team of one" and the stated base |
| Market calibration | Not established. The role-family sweep couldn't run, so no market band is given, and none is quoted from memory (RR2) | none: research unavailable |
| Unknowns | Growth budget; equity terms; how success is judged; what "when it matters" means in practice | — |
| Contradictions | A profitable company asking for 8+ years of leadership offers $70–85k for a role that owns all revenue | `[inferred]` from the posting's own claims set side by side |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your hard constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor, which is specific. The fit fails because the posting states "$70–85k base" | `[grounded]` posting and your stated constraint | Only you or the employer changing terms resolves it |
| R2 | Remote-only, from Portland (your hard constraint) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The fit fails because the posting says "On-site in our Austin office 5 days a week — no exceptions" | `[grounded]` posting and your stated constraint | Only you or the employer changing terms resolves it |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | 9 years, titled Growth lead and then Head of Growth, at two companies. Self-reported, so capped at medium | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid; $8M→$40M ARR over three years with a budget you controlled | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle, and you're deep in Braze | `[grounded]` your stated background | none |
| R6 | Owning all growth hands-on as a team of one | must_have | adjacent | medium | transferability | Your SQL, GA4 and Braze depth points to hands-on skill. Limit: your record is leading teams of 3–7, not running seven functions alone | `[grounded]` your stated background; `[inferred]` that this is the limit | see G5 |
| R7 | SEO/content | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` your background is silent | see G1 |
| R8 | Brand and PR | important | unclear | low | discovery | Not mentioned | `[grounded]` your background is silent | see G3 |
| R9 | Partnerships | important | unclear | low | discovery | Not mentioned | `[grounded]` your background is silent | see G2 |
| R10 | Sales ops | important | unclear | low | discovery | Not mentioned. B2C subscription businesses often run without a sales team | `[grounded]` your background is silent; `[generic]` the B2C pattern | see G2 |
| R11 | Growth for an e-commerce enablement business | important | adjacent | medium | transferability | "E-commerce enablement" likely means selling to merchants. Your record is B2C subscription. Metrics and lifecycle skills carry over; selling to businesses wasn't part of it | `[inferred]` from the posting's descriptor; `[grounded]` your background | see G4 |
| R12 | Reporting to the board (dotted line) | important | unclear | low | discovery | Your background doesn't say whether you reported to a board | `[grounded]` your background is silent | none while R1 and R2 fail |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | Nothing on organic or content | It can't move the decision while R1 and R2 fail; it matters for similar roles you pursue | Owning an organic channel's targets; a content program you funded or ran inside your growth budget | An organic traffic dashboard; a content calendar | `[grounded]` background silent |
| G2 | Partnerships and sales ops (R9, R10, important) | discovery | Nothing on either | Same as G1 | Affiliate or co-marketing deals; CRM pipeline hygiene; handing off to a sales team | A partner deal summary; a pipeline report | `[grounded]` background silent |
| G3 | Brand and PR (R8, important) | discovery | Nothing on either | Same as G1 | Running a launch with an agency; owning brand guidelines or positioning tests | A launch brief; press coverage | `[grounded]` background silent |
| G4 | E-commerce enablement context (R11, important) | transferability | Bridge: lifecycle, experimentation and ARR scaling. Limit: no selling to businesses. Strengthener: any merchant-facing or B2B2C work | It matters for e-commerce enablement roles generally | Partner-channel or merchant-facing growth work | A case summary | `[inferred]` bridge drawn from your stated background |
| G5 | Team of one (R6, must_have) | transferability | Bridge: hands-on tool depth. Limit: you've led teams rather than covered every function yourself. Strengthener: periods when you ran channels yourself | Same as G1 | Early months before you hired your team; covering for open roles | A sample of your own SQL or Braze work | `[inferred]` bridge drawn from your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay conflicts with your floor (see R1) | red_flag | high | "Compensation: $70–85k base plus meaningful equity upside" | The top of the stated range is about $65k below your minimum base | `[grounded]` posting and your constraint | Is there any flexibility in base above $85k for this role? | confirmed |
| RR2 | Pay looks low for the seniority asked | risk_signal | medium | "8+ years growth leadership required" | A base this size may be priced for a more junior role, or may rely on equity to make up the gap. It couldn't be checked against the market | `[inferred]` from the seniority asked against the stated base; market comparison not established | How did you set the base band, and what roles did you benchmark it against? | unresolved |
| RR3 | On-site conflicts with your remote-only constraint (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work explicitly | `[grounded]` posting and your constraint | Is the five-day on-site requirement truly fixed for this role? | confirmed |
| RR4 | Several specializations bundled into one role | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | The role may combine several jobs at one salary | `[generic]` pattern for bundled growth roles | Which of these functions matter most in year one, and which can wait? | unresolved |
| RR5 | Responsibility without resources | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one to start" | The holder may be accountable for all revenue with no team, and no budget is stated | `[inferred]` from the mandate against the silence on budget and headcount | What growth budget and hiring plan are committed for the first year? | unresolved |
| RR6 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work is framed as identity rather than exception | `[inferred]` from the posting's wording | In the last quarter, how often did the team work evenings or weekends, and what triggered it? | unresolved |
| RR7 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be undefined, which leaves the holder exposed when targets shift | `[inferred]` from the posting's wording | What would a successful first six months look like, in numbers? | unresolved |
| RR8 | Equity terms not stated | unknown | — | "meaningful equity upside" | The equity's value can't be assessed without its size, vesting and strike price | `[generic]` equity can't be valued without its terms | What percentage of fully diluted shares, on what vesting schedule, and at what strike price? | unresolved |
| RR9 | Profitability claimed | positive_signal | — | "profitable since day one" | If true, this points to financial stability | `[grounded]` posting; unverified | What are current revenue and runway? | noted |
| RR10 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. This stays open only because research couldn't run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply; spend the time on other openings | see R1, R2 | `[grounded]` map | pending your approval |
| A2 | If Novaline approaches you, reply once asking RR1's and RR3's questions before any call | Rules out a wasted interview loop | `[grounded]` RR1, RR3 | pending your approval |
| A3 | Screen future postings early for a stated base and remote policy, and for any team or budget behind the mandate | The patterns behind RR1, RR3, RR4 and RR5 | `[grounded]` register | pending your approval |

Nothing here is final. The actions above, and any advice in this response, are proposals pending your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search was sent ("Novaline e-commerce enablement startup Austin careers Head of Growth") and the permission was refused. It would have confirmed the company and whether the posting is live (RR10) |
| 2. Role-family sweep | unavailable | A search was sent ("Head of Growth Series A startup base salary 2026") and the permission was refused. It would have given the market calibration and confirmed or cleared RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

---

I can save this as a `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- Allow web search → targets 1 and 2 run, RR10 can close, and RR2 gets a market band to compare against.
- A link to the live posting or Novaline's careers page → checks RR10 directly.
- A deeper research pass on Novaline (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds RR2, RR8 and RR10. Say the word and it runs. Neither of these can change R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.