Read the skill's method files; now fetching the posting.
I read the posting. The rest of this is a structured assessment of how your background maps onto it.

## Decision snapshot

**Yes, it's worth going for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week)
- `must_have`: direct: R2, R3, R4a, R7 · adjacent: R5 (Experience owning a forecast) · unclear: R4b (Spreadsheet modelling), R6 (Working with finance on billing or revenue data)
- `important`: direct: R8 · absent: R9 (Own billing data)

R5: your monthly pipeline review is a real bridge to forecasting, but it has a limit, and that limit needs naming. R6 and R9: the billing-data side, where you already said the gap is.

**Opportunity ledger.** The role looks sound and open about its terms. Pay is stated and sits inside the market band (RR1), and the employer is established and funded (RR5). Still open: who owns the forecast number (RR3), whether a "Lead" manages anyone (RR4), and the fact that the role isn't on a page of Quillfield's own site that I could find (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) two days a week in Bristol works for you (R1). (2) Forecasting is described as adjacent experience, never as owning a forecast (R5). (3) Billing data is named plainly as the gap it is (R6, R9), not smoothed over.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about (search snippet) |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Terms | Bristol, hybrid, two days a week in the office. £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield. Previously sales operations manager at Corvane Payments for four years | `[grounded]` public profile (search snippet); name from your recruiter |
| Scope read | The role sits between sales and finance: CRM is the sales-side system, while billing data and the forecast are finance-facing. The role reports into a Head of RevOps, not the CFO | `[inferred]` from the mandate's wording and the hiring manager's title |
| Market calibration | Revenue operations lead, UK B2B software: median base £64,200, interquartile range £57,800–£70,400. The posting's £61,500–£67,000 sits around that median, inside the range | `[generic]` Ledgerline 2026 UK RevOps Pay Guide (n=438); `[grounded]` posting figure |
| Unknowns | Who owns the forecast number; whether the role has reports; share option terms; which billing system they use | — |
| Contradictions | None between the posting and Quillfield's about page | `[grounded]` posting and about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states this term. You haven't said where you're based or whether two Bristol days work | `[grounded]` posting; background silent | Closing question on R1 |
| R2 | 4+ years in RevOps, sales ops or a similar analytics role at a B2B software company | must_have | direct | medium | none | Five years in sales ops, the last two running UK revenue ops. You described the company as "B2B payments", and the posting asks for "B2B software", but the posting's "or similar" wording is loose. Medium is the most a stated background can earn before anything is inspected | `[grounded]` your background; `[inferred]` that payments reads as close to software for this screen | none |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | You're Salesforce admin certified. The certificate can be inspected but I haven't seen it | `[grounded]` your background | Upgrade menu: the certification record |
| R4a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. "Strong" isn't established beyond regular use | `[grounded]` your background | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | Using Excel daily doesn't establish modelling, which means building driver-based or scenario models. Daily use and modelling are different kinds of work | `[grounded]` your background | Queue G3 |
| R5 | Experience owning a forecast / running the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | What carries over: you run the monthly pipeline review with your sales director. The limit, in your words: "never owned the company forecast — finance did that" | `[grounded]` your background | Queue G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data, but "or revenue data" is still open. Renewal dashboards and finance owning the forecast suggest some contact with finance, but nothing confirmed | `[grounded]` your background; `[inferred]` that renewal reporting may have touched revenue figures | Queue G2 |
| R7 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Finance as an audience for that reporting isn't established | `[grounded]` your background | none |
| R8 | Own CRM data | important | direct | medium | none | Salesforce admin certified, and you ran revenue ops for the UK team | `[grounded]` your background | none |
| R9 | Own billing data | important | absent | none | capability | By your own account, you've never worked on billing data. G2 could reopen this if it turns up adjacent work | `[grounded]` your statement | Closure path: a short work sample, application plan W1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R5, must_have) | transferability | You run a monthly pipeline review with the sales director. Finance owned the company forecast | Forecasting is a third of the stated mandate and a must-have | Producing a commit or best-case number from the pipeline review; giving finance pipeline inputs for their forecast; tracking forecast against actuals; calling renewal or churn numbers | A pipeline-review pack, or a sanitized forecast-vs-actual sheet | `[grounded]` your background; `[inferred]` that the mandate's weight makes this the main bridge |
| G2 | Finance and revenue data (R6, must_have) | discovery | No billing data. Revenue-data work with finance is unstated | A must-have that could be `adjacent` rather than `unclear` | Reconciling closed-won with what finance booked; renewal ARR or churn figures finance used; fixing CRM fields that fed finance reports; payment or transaction data at a payments company | A dashboard screenshot or a reconciliation sheet, sanitized | `[grounded]` your background |
| G3 | Spreadsheet modelling (R4b, must_have) | discovery | You use Excel daily; no models are described | A must-have that's probably answerable from your own history | Capacity or quota models; territory planning; a renewal or churn projection; scenario tabs for the sales director | One sanitized model | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary stated and in line with the market | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The pay is published and sits inside the role-family range | `[grounded]` posting; `[generic]` Ledgerline band | What are the terms of the share options: size, vesting and strike? | noted |
| RR2 | Role not found on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield \| Tallyboard Jobs" | Their vacancies may live elsewhere, or only on job boards. Your recruiter and the hiring manager's profile are consistent with the posting | `[inferred]` from a failed fetch of quillfield.co.uk/careers | Is this role listed on Quillfield's own site, and is it the same posting? | unresolved |
| RR3 | Forecast and billing ownership shared with finance | risk_signal | low | "run the quarterly revenue forecast with the CFO" | The role could be held to account for a number the CFO controls, and for billing data it doesn't administer | `[inferred]` from the mandate against a reporting line into RevOps | Who signs off the forecast number, and who has final say on billing data definitions? | unresolved |
| RR4 | "Lead" title, no reports mentioned | unknown | — | "Revenue Operations Lead" | The role may be individual-contributor only | `[inferred]` from the posting's silence on team | Does this role manage anyone now, or is a hire planned? | unresolved |
| RR5 | Employer established and funded | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M) closed in April 2025" | A real company with recent funding, consistent with the posting | `[grounded]` about page | What changed in RevOps after the Series A? | noted |

## Application plan

Every row is proposed and pending your approval. That includes the framing wording, not just the actions.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the two Bristol days before applying | R1 | `[grounded]` posting | pending your approval |
| P1 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review | They map to R7 and R5. Your payments-company background matches the hiring manager's own previous role | `[grounded]` your background; hiring manager's public profile | pending your approval |
| P2 | Describe forecasting as "I run the monthly pipeline review with our sales director; finance owned the company forecast" | R5: these are your words, and the limit stays visible | `[grounded]` your background | pending your approval |
| P3 | State the billing gap plainly: "I haven't worked on billing data" | R6, R9 | `[grounded]` your statement | pending your approval |
| W1 | A one-page note on how you'd reconcile CRM bookings against billing records, offered as a work sample | Closure path for R9, and partly for R6 | `[inferred]` from the mandate's billing ownership | pending your approval |
| Q1 | Ask the RR1–RR5 questions in interviews | They double as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers: no page there. Moved the organization row, RR5 and RR2 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned the "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row, the scope read and P1 |

I can save this as a `tuesday-dossier.md` file you can carry into later sessions, if you'd like it.

**Upgrade menu**
- Your answers to G1–G3 would strengthen or settle R5, R6 and R4b, and could change R9.
- Your location, or whether Bristol two days a week works, would settle R1 and might move the status to `go` or `no_go`.
- Your Salesforce certification record would raise R3 to `high`.
- A pay floor or other non-negotiables would let me check them as gates instead of leaving them as unknowns.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) runs if you say the word.

**Questions**

R1: Can you be in Bristol two days a week, and do you have any other must-haves on pay or location?

G2: Have you ever reconciled closed-won deals or renewal numbers against what finance recorded, or built anything finance used?

G1: Did your monthly pipeline review produce a forecast or commit number, and did that number go to finance?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.