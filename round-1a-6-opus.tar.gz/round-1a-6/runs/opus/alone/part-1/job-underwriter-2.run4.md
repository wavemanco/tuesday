I've finished the assessment. My two web searches, one on Quartzline and one on PM pay, were blocked by permissions. So everything below comes from your JD and resume only, and I couldn't confirm anything about the company or the market.

## Decision snapshot

**No, you're not wasting your time. This is a good first PM target for your background. The thing most likely to stop you is the "3+ years PM experience" screen (R1b), not your skills. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1a (3+ years PM experience, equivalent work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1b (3+ years PM experience, titled)
- `important` — direct: R9 · adjacent: R6 (Run discovery with integration partners), R8 (Write specs), R11 (Coordinate launches with sales and support) · unclear: R7 (Own the roadmap), R10 (Define and track adoption metrics)

R1b: a risk at the screening stage, not a missing skill. R2: the bridge you'll have to argue, with its limit stated. R5, R7 and R10: open questions that one answer each could settle.

**Opportunity ledger.** The mandate is concrete and staffed (RR4). I couldn't confirm the employer because the research was blocked (RR1). The posting doesn't state pay or location (RR3, RR5), and the titled-years must-have is the main screening risk (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Quartzline and the posting check out as described (RR1).
  2. You get your application to a person rather than only a keyword screen, because R1b can't be fixed by wording (RR2).
  3. R2 is presented as adjacent work on API integrations, never as having shipped an API product.
  4. Pay and location fit constraints you haven't told me yet (RR3, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, about 150 people, Series B | `[grounded]` JD header; not confirmed by research (RR1) |
| Mandate | Own the roadmap for a partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | One platform product, two squads, partners outside the company. A normal single-product PM scope, not a group or head-of role | `[inferred]` from the JD's squad count and single product area |
| Customer of the product | Integration partners, meaning engineers at other companies who integrate with Quartzline's API | `[grounded]` JD "partner-facing API platform"; `[inferred]` that partners' engineers are the hands-on users |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not available. The pay and title search was blocked, so I give no pay range rather than guess one | — |
| Unknowns | Pay; location and remote policy; reporting line; current adoption baseline; whether the "3+ years" is applied literally | — |
| Contradictions | None inside the JD; no careers page to check it against | `[grounded]` JD only |

## Evidence map

Confidence tops out at `medium` throughout. Everything here is your own written account, and none of it has been probed or backed by a document yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: PM-equivalent work | must_have | adjacent | medium | transferability | You've spent 7 years scoping, writing requirements, coordinating engineers and PMs, and collecting roadmap input. Much of that is the same work PMs do. Limit: no stated ownership of what gets built or why. | `[grounded]` resume | Make the bridge case in your positioning (P1) |
| R1b | 3+ years PM experience: titled PM years | must_have | absent | none | capability | You told me directly that you've never held a PM title. Nothing you write can change this. | `[grounded]` user statement | Treat as a material risk; P2 is the way around it |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs from start to finish, so you know the API from the integrator's side as an expert. Limit: you delivered integrations on top of the product; nothing shows you shipped the API or platform itself. | `[grounded]` resume; `[generic]` that API PM interviews probe this exact line | G1, G2 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | You stated Postman, SQL and reading OpenAPI specs, and integration architecture work backs it up. Confirmed in writing, nothing inspected yet, so expect a probe. | `[grounded]` resume | none |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, the client's engineers and your PMs on custom builds. That covers engineering and customers on both sides. | `[grounded]` resume | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | The resume doesn't mention working with sales. Solutions engineers often work beside sales, but you haven't said so. | `[grounded]` resume is silent; `[generic]` that solutions engineers commonly sit next to sales | G4 in the queue (not asked this turn) |
| R5 | Agile delivery | must_have | unclear | low | discovery | The resume says nothing about how delivery was run. | `[grounded]` resume is silent | G3 in the queue (not asked this turn) |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions are listening to customers. Limit: workshops scoped one client's integration and the sessions fed input to product. Neither is stated as deciding what to build. | `[grounded]` resume | P1 positioning; E1 |
| R7 | Own the roadmap | important | unclear | low | discovery | You fed the roadmap with input. Nothing shows you prioritized or decided. | `[grounded]` resume | G2 |
| R8 | Write specs | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture, plus a playbook the whole team uses. Limit: those were per-client integration documents, not product specs for a shared platform. | `[grounded]` resume | W1 work sample |
| R9 | Drive delivery with engineering squads | important | direct | medium | none | 30+ go-lives coordinating engineers through UAT and launch. This is delivery-driving under another name. | `[grounded]` resume | none |
| R10 | Define and track adoption metrics | important | unclear | low | discovery | The resume has no metrics. An internal tool that support agents adopted, remembered from an earlier conversation and not confirmed by you, could be relevant. | `[grounded]` resume is silent; the triage tool is an unconfirmed lead from earlier context | G1 |
| R11 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-lives are launches with one client; a playbook the whole team uses is enablement. Limit: there's no product launch across a market, and sales isn't mentioned. | `[grounded]` resume | none beyond G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption metrics (R2, R10) | discovery | An unconfirmed lead from earlier context that you built an internal request-triage tool support agents adopted. Nothing in the resume. | If it's real, it's the closest thing you have to "I built something, people used it, I measured it." That helps both a must-have row and an important one. | You defined what the tool did; you got agents to switch to it; you tracked usage or time saved; you iterated on feedback | Screenshots, a usage count, an internal announcement, a short README | `[grounded]` resume is silent; `[generic]` that PM interviews value build-adopt-measure stories |
| G2 | Productization and roadmap influence (R2, R7) | discovery | You coordinated custom builds with PMs. It isn't stated whether any became standard product. | A custom build you specified that became a standard endpoint or feature would bring R2 close to direct | A client request you turned into a general feature; an endpoint or field added because of your requirements doc; a roadmap item that came from your sessions and shipped | Release notes, the original requirements doc (sanitized), a changelog entry | `[grounded]` resume says "custom builds"; `[inferred]` that some may have been productized |
| G3 | Agile delivery (R5) | discovery | Nothing stated | A must-have; probably an easy fill | Working in sprints with engineering; backlog grooming for integration work; Jira epics you owned | A Jira board screenshot, sanitized | `[grounded]` resume is silent |
| G4 | Sales stakeholders (R4b) | discovery | Nothing stated | Part of a must-have row | Pre-sales scoping calls; handing over to account managers; deal-support architecture reviews | none needed; one sentence will do | `[grounded]` resume is silent |
| G5 | Titled PM years (R1b) | capability | Confirmed absent | Can't be closed before you apply; only someone choosing to waive it can get you past it | Longer term: an internal move to PM at your current company, or technical-PM or solutions-to-product roles that explicitly welcome career switchers | — | `[grounded]` user statement; `[generic]` that internal transfers are a common route into PM |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have much of a footprint, the posting may be stale or copied from elsewhere, or it may not be a real hiring employer. Here, research didn't run at all. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Titled-years must-have against a career switcher | risk_signal | medium | "3+ years product management experience (must-have)" | Recruiters or software may screen this literally and reject before anyone reads the integration work | `[generic]` that "must-have" year counts are often screened literally at first pass | Would you consider someone whose product experience comes from leading API integrations as a solutions engineer, rather than from a PM title? | unresolved |
| RR3 | Compensation withheld | unknown | — | No pay stated in the JD | The posting doesn't state pay; I couldn't look up a market range | `[grounded]` JD silence | What is the salary range budgeted for this role? | unresolved |
| RR4 | Concrete mandate with resources | positive_signal | — | "drive delivery with two engineering squads" | Clear scope, named teams and a defined user group (integration partners) | `[grounded]` JD | What does adoption look like today, and what would success be in year one? | noted |
| RR5 | Location and remote policy unstated | unknown | — | No location in the JD | Could conflict with constraints you haven't told me yet | `[grounded]` JD silence | Where is this role based, and what's the in-office expectation? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with: "7 years leading client integrations of a vendor's REST APIs, 30+ end to end from scoping workshops to go-live." You stood on the API provider's side, the same side Quartzline stands on with its partners. | R2, R6, R9; it traces to your own line "Led 30+ client integrations of our REST APIs end to end" | `[grounded]` resume | pending your approval |
| P2 | Get to the hiring manager or a referral instead of only applying through the portal | RR2, R1b; wording can't get you past a literal year screen | `[generic]` that referrals bypass first-pass screens | pending your approval |
| E1 | Group the integration playbook and the quarterly roadmap-input sessions together near the top of your resume as product-facing work, using your own wording. No new claims. | R6, R8 | `[grounded]` resume | resume_edits_pending_approval |
| W1 | A one-page product spec or teardown of Quartzline's public API docs, if they publish any: one partner pain point, a proposed change, a metric to judge it by | R8, R10, R1b; it shows PM output directly | `[inferred]` assumes public docs exist, which I haven't confirmed | pending your approval |
| Q1 | Ask the verification questions for RR1, RR2, RR3, RR4 and RR5 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Never call yourself a PM or say you "owned the roadmap." Say "fed the roadmap" and "coordinated builds." | R1b, R7; an inflated claim fails the first follow-up question | `[grounded]` user statement | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the internal request-triage tool support agents adopted (from earlier context, unconfirmed, asked in G1). Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics API platform Series B"; the search was refused for lack of permission. It would have settled RR1 and the organization and contradictions rows. |
| 2. Role-family sweep | unavailable | Searched "Product Manager Platform APIs salary B2B SaaS Series B 3 years experience"; refused for lack of permission. It would have filled in market calibration and checked pay for RR3. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can also save all of this as `tuesday-dossier.md` so you can pick it up later.

## Upgrade menu

- Allow web search → RR1 settles, and market calibration gets a researched pay range for this role.
- A link to the live posting on Quartzline's own careers page → RR1 closes without search, and the JD gets checked against it.
- Your pay floor, location and work-authorization constraints → the hard-gates line becomes actual checks against RR3 and RR5.
- The hiring manager's name → the scope read, plus which of your stories P1 should lead with for that person.
- A sanitized requirements document or your integration playbook → R8 and R3 move toward `high`.
- A deeper research pass on Quartzline (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs, once search is allowed.

## Questions

**G1:** I have a note from an earlier conversation that you built an internal request-triage tool that support agents adopted. Is that right? If so, what part was yours, how many people used it, and did you track whether it worked?

**G2:** Did any custom build you specified with engineering and product become a standard feature or API endpoint other clients used? What was your part in it?

**Constraints:** What are your non-negotiables on pay, location or remote work, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.