I'm checking Novaline and market pay for this role so I can weigh the posting against your constraints.
# Novaline, Head of Growth: decision

## Decision snapshot

**No, this one isn't worth pursuing. R1 and R2 are both hard gates, and both fail. Status: `no_go`.** Your sense that something is off has a basis too: the register below lists six risk signals, separate from the two dealbreakers.

**Fit ledger.**

- `hard_gate`: unclear: R3 (Evenings and weekends when it matters) · hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site in Austin 5 days a week)
- `must_have`: direct: R5, R6, R7 · unclear: R4 (8+ years growth leadership), R8 (SEO/content), R9 (Brand and PR), R10 (Partnerships), R11 (Sales ops)
- `important`: adjacent: R12 (Team of one to start), R13 (E-commerce enablement, a B2B motion)

R1, R2: each fails on the posting's own terms; R5, R6, R7: your strongest evidence and on-target; R4: likely met, but your leadership years aren't separated out yet; R8, R9, R10, R11: not covered by what you shared.

**Opportunity ledger.** Your two non-negotiables are each contradicted by an explicit term (RR1, RR2). Apart from you, the role combines seven functions with no team (RR4), no stated budget (RR5), always-on hours (RR6) and no definition of success (RR7). The pay also looks low for the years and the board-facing mandate it asks for (RR3). I couldn't confirm the employer (RR8), and the equity is unspecified (RR10). In its favour, it reports to the CEO with board visibility, and it says it has been profitable since day one (RR9).

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site in Austin 5 days a week); unconfirmed: R3 (Evenings and weekends when it matters).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** both of these would have to change: (1) Novaline offers a base of at least $150k (R1, RR1); and (2) it offers fully remote work from Portland (R2, RR2). Either it changes those terms, or you change one of your non-negotiables. Better wording on your side can't fix either one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; not confirmed independently (RR8) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | Reports to the CEO, dotted line to the board | `[grounded]` posting |
| Resources | "A team of one to start"; no budget mentioned | `[grounded]` posting; silence on budget `[grounded]` |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" (size, vesting and strike not stated) | `[grounded]` posting |
| First-90-days / first-year outcomes | None stated: "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | This is several leadership roles in one (performance marketing, content/SEO, CRM, brand/comms, partnerships, revops), executed solo, with board accountability | `[inferred]` from the seven named functions against "team of one" |
| Market calibration | Not established. The role-family search was blocked, so I give no market band. See the upgrade menu | — |
| Unknowns | Marketing budget; equity terms; how success is measured; customer type (merchants or consumers); whether a team is planned and when | — |
| Contradictions | Profitable since day one and board-facing, yet the base is $70–85k for 8+ years of leadership. That's a tension, not a contradiction (RR3) | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k (against your ≥$150k floor) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor. The posting's ceiling of $85k is $65k below it. Equity doesn't count toward a base-pay floor | `[grounded]` posting and your stated constraint | Surface it; only a change of terms by Novaline or by you resolves it |
| R2 | On-site in Austin 5 days a week, no exceptions (against remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint. "No exceptions" rules out a hybrid or remote arrangement in the posting's own words | `[grounded]` posting and your stated constraint | Surface it; only a change of terms resolves it |
| R3 | Evenings and weekends when it matters | hard_gate | unclear | none | hard_gate | A schedule term from the posting. You stated no constraint on hours, so it's unsettled | `[grounded]` posting; your silence on hours | None. R1 and R2 already decide the case |
| R4 | 8+ years growth leadership | must_have | unclear | medium | discovery | You have 9 years in growth, the later part as Growth Lead and then Head of Growth. What you shared doesn't say how many of the 9 were in leadership roles | `[grounded]` your background as stated | G1 |
| R5 | Own revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years, with a budget you controlled. That's specific, but nothing inspectable has been seen yet | `[grounded]` your background as stated | None |
| R6 | Paid acquisition | must_have | direct | medium | none | Stated as owned at both companies | `[grounded]` your background as stated | None |
| R7 | Lifecycle/CRM | must_have | direct | medium | none | Stated as owned; deep in Braze | `[grounded]` your background as stated | None |
| R8 | SEO/content | must_have | unclear | low | discovery | Not mentioned in what you shared. That means not established, not absent | `[grounded]` silence in your background | G2 |
| R9 | Brand and PR | must_have | unclear | low | discovery | Not mentioned in what you shared | `[grounded]` silence in your background | G2 |
| R10 | Partnerships | must_have | unclear | low | discovery | Not mentioned in what you shared | `[grounded]` silence in your background | G2 |
| R11 | Sales ops | must_have | unclear | low | discovery | Not mentioned. Your companies were B2C subscription businesses, and a sales function may not have existed there | `[grounded]` silence in your background; `[inferred]` from the B2C subscription model | G2 |
| R12 | Team of one to start | important | adjacent | medium | transferability | You've built and managed teams of 3–7. Doing seven functions alone is a different job. What you shared doesn't show you running all seven solo. Hands-on SQL, GA4 and Braze suggest you can execute in analytics and lifecycle yourself | `[grounded]` your background; `[inferred]` hands-on depth from the tools | None. The decision doesn't depend on it |
| R13 | E-commerce enablement, a B2B motion | important | adjacent | medium | transferability | Inferred requirement: "e-commerce enablement" plus sales ops and partnerships point to selling to businesses. Your experience is B2C subscription. Paid, lifecycle and experimentation carry over; a B2B sales motion isn't shown | `[inferred]` from the posting's company description and function list | None. The decision doesn't depend on it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 8+ years growth leadership (R4, must_have) | discovery | 9 years in growth, with leadership titles later on. The years in leadership roles aren't separated out | It doesn't change this decision. For other Head of Growth roles, a literal years-of-leadership screen is where this row would matter | Years as Growth Lead; earlier years leading a channel or a pod before the title | Dated titles on your CV or LinkedIn | `[grounded]` your background as stated; `[generic]` that titled-years lines are often screened literally |
| G2 | SEO/content, brand/PR, partnerships, sales ops (R8, R9, R10, R11, must_have) | discovery | None of the four is mentioned | It doesn't change this decision. It matters for roles with a similarly broad mandate | Owning or overseeing content/SEO programs; agency or PR management; affiliate, channel or co-marketing deals; CRM-to-revenue pipeline work | Program briefs, partnership one-pagers, dashboards | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor (see R1) | red_flag | high | "Compensation: $70–85k base plus meaningful equity upside" | The posted ceiling is $65k under your floor, and equity can't count toward a base-pay floor | `[grounded]` posting and your constraint | Is the base band fixed, or is there a path to $150k for the right person? | confirmed |
| RR2 | On-site mandate against remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out the only arrangement you'll accept | `[grounded]` posting and your constraint | Is fully remote from Portland possible for this role? | confirmed |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" … "$70–85k base" | The years, the board line and the end-to-end mandate may cost more at market than this base pays. Unconfirmed because the role-family search was blocked. Held at `medium` until a band is checked | `[inferred]` from the posting's own years and mandate against its base figure | How did you arrive at this base band, and how does it compare with the rest of the leadership team? | unresolved |
| RR4 | Several specialist roles bundled into one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | One person is accountable for seven functions that companies often staff separately | `[inferred]` from the function list; `[generic]` that these are often separate roles | Which two or three of these matter most in the first six months? | unresolved |
| RR5 | Responsibility without resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | Full revenue accountability with no team and no stated budget | `[inferred]` from "team of one" against the silence on budget | What's the marketing budget for the first year, and when is the first hire planned? | unresolved |
| RR6 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work is described as the culture, not as an exception | `[grounded]` posting's own wording | In the last quarter, how often did the leadership team work evenings or weekends? | unresolved |
| RR7 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability to the CEO and board without an agreed definition of success | `[inferred]` from the mandate against the posting's statement on metrics | What would the board call a successful first year in this role? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. The search was blocked, so none of these is more likely than the others | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | CEO reporting line, board visibility, stated profitability | positive_signal | — | "Report to the CEO with a dotted line to the board" … "profitable since day one" | Real seniority and access, and stated financial health | `[grounded]` posting | What has driven revenue to date, and what does the board want from growth next? | noted |
| RR10 | Equity unspecified | unknown | — | "meaningful equity upside" | Grant size, vesting, strike price and the current valuation aren't stated | `[grounded]` posting's silence on terms | What's the grant as a percentage of fully diluted shares, and what are the vesting and strike terms? | unresolved |

## Application plan

These are all proposals and wait on your approval, the advice in this section included.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1, R2; RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | Optional: send one short note asking only RR1's and RR2's questions. Go no further unless both come back yes | It's the only factual way R1 and R2 could change; "no exceptions" makes a yes unlikely | `[grounded]` RR1, RR2; `[inferred]` that a yes is unlikely, from "no exceptions" | pending your approval |
| A3 | When screening other Head of Growth roles, check for RR4, RR5 and RR7 before fit | These are the signals here that don't depend on your two constraints | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce startup Austin"; the call was refused because web search permission wasn't granted. It would have confirmed or cleared RR8, and checked the organization and contradictions rows in role reality |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026"; the call was refused because permission wasn't granted. It would have given the market calibration row a band and confirmed or reduced RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this assessment as `tuesday-dossier.md` for you to keep and reuse if you'd like.

**Upgrade menu**
- **Allow web search:** targets 1 and 2 run. RR8 clears or stands, the market band fills role reality, and RR3 is confirmed or reduced. R1 and R2 fail either way.
- **A deeper research pass on Novaline** (funding, leadership churn, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): just say so, once search is allowed.
- **Novaline's answer to RR1's and RR2's questions:** the only input that could reopen R1 and R2.
- **The hiring manager's name:** target 3, which sharpens the scope read if the role ever reopens.
- **Dated titles from your CV:** closes G1, so R4 resolves for this and similar roles.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.