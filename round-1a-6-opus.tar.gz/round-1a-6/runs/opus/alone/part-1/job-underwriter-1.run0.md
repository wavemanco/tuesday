I've read the skill's rules and am now checking the employer and market at the default research tier.
# Should Arjun apply? Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, you're a fit and it's worth applying, once the posting checks out. You meet R1, R2, R3, R4 and R5 directly. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important`: adjacent: R7b (Partner with clinicians) · unclear: R7a (Partner with PMs to turn analysis into roadmap decisions), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience (HIPAA))

R6, R7a, R8: the evidence may exist but you haven't said it yet; R7b, R9: credible bridges, with their limits named.

**Opportunity ledger.** I couldn't confirm the employer or the posting because my searches were refused (RR1). Pay (RR2), location (RR3), what "experiment design at scale" means here (RR4) and whether the junior analysts report to you (RR5) are all unstated. One entry is positive: the scope is concrete and specific (RR6).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) pay and location turn out to be acceptable to you (RR2, RR3); (3) your healthcare and clinician bridges are presented as adjacent work, never as healthcare experience (R7b, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a Series C digital-health scale-up of about 400 people with a care-navigation app | `[grounded]` JD header; not verified independently (RR1) |
| Mandate | Own product analytics: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Must-haves | 5+ years product analytics; expert SQL; experiment design at scale; Looker or similar BI; strong writing for non-technical stakeholders | `[grounded]` JD |
| Preferred | Healthcare data experience (HIPAA) | `[grounded]` JD: "a plus" |
| Hard gates | None stated: no location, authorization, schedule or pay terms in the posting | `[grounded]` JD silence |
| Scope read | A senior individual-contributor role with a small mentoring load. It is not a manager title, but "own" and "define and maintain the metrics layer" put the analytics foundations on this person | `[inferred]` from the JD's verbs and the stated two-junior team |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not established: the role-family search was refused, so there's no pay or scope band to compare against | n/a |
| Unknowns | Pay; location and working pattern; test volume and outcome metrics; reporting line for the juniors; what "metrics layer" means in practice (Looker's LookML, a dbt semantic layer, or something else) | n/a |
| Contradictions | None found between your account and the JD. The posting itself couldn't be checked against the company's site | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. It's specific but self-reported, and nothing has been inspected yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse, plus building a warehouse consent-state model. "Expert" will be tested live, not taken on your word | `[grounded]` your background; `[generic]` senior analyst loops usually include a live SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." It's specific and maps directly. Expect a probe on which part of the 11% result was the test design versus the product change | `[grounded]` your background; `[generic]` that headline lifts get probed for attribution | none; prepare the test's design, guardrails and readout |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch, with 40+ governed dashboards. That's an exact tool match | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. A redacted memo would raise this to `high` | `[grounded]` your background | Offer a redacted memo excerpt as a work sample |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | A governed Looker instance suggests you defined metrics, but you haven't said whether you owned the metric definitions (LookML models, a dbt layer, or metric governance). A dashboard build doesn't establish this on its own, so I've taken the lower reading | `[inferred]` from "built the Looker instance… governed dashboards" | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | unclear | medium | discovery | You present to the VP Product monthly, which is a specific claim. You haven't said which roadmap decisions your analysis changed, apart from the pricing test | `[grounded]` your background | See G3 |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | It carries over: translating analysis for non-technical execs (R5). The limit is that you've had no clinical stakeholders; clinicians reason in terms of patient safety and outcomes, which commercial execs don't | `[grounded]` your background; `[generic]` how clinical partners frame metrics | See G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or managing anyone | `[grounded]` silence in your background | See G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | It carries over: GDPR/CCPA consumer PII and a consent-state model you built for the warehouse. The limit is that HIPAA's protected health information rules (minimum necessary, de-identification, vendor agreements) differ from consumer-privacy law, and you haven't worked under them | `[grounded]` your background; `[generic]` HIPAA vs GDPR/CCPA differences | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | You built a governed Looker instance, but haven't said whether you owned the metric definitions | It's the only `must_have` row below `direct` | Writing LookML views and explores that defined "active subscriber" or "churn"; running a metric-definition review with finance or product; retiring duplicate metrics; a dbt semantic layer | A metric dictionary, a LookML repo excerpt, a governance doc | `[grounded]` gap in your background; `[inferred]` that this is the row most likely to be tested |
| G2 | Mentoring juniors (R8, important) | discovery | Nothing about mentoring or managing anyone | It's a stated responsibility, and the senior title rests partly on it | Onboarding new analysts onto the Looker instance; reviewing other people's SQL or test designs; an intern or junior you guided | A training doc, an onboarding guide, a peer reference | `[grounded]` silence in your background |
| G3 | Roadmap influence (R7a, important) | discovery | Monthly VP Product presentations; the pricing test is the only named decision | Concrete decisions changed are what "partner with PMs" gets judged on | A feature cut or kept on your analysis; a roadmap re-prioritized after a test readout | A decision memo, a test readout | `[grounded]` your background |
| G4 | Clinician partnership (R7b, important) | transferability | Strong exec communication, no clinical audience | An honest bridge beats a claim the interview will break | The exec memo as proof that you translate well; any work with ops, support or safety teams on customer-harm metrics | A memo excerpt | `[generic]` how clinical partners frame metrics |
| G5 | HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling plus a consent-state model | It's preferred, so it adds rather than gates; the risk is overclaiming it | The consent-state model's design; access controls or PII masking you set up in Snowflake | A design doc for the consent model | `[generic]` HIPAA vs GDPR/CCPA differences |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | My research calls were refused, so this is unchecked rather than doubtful. The posting may be live and accurate, it may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation withheld | unknown | — | (no pay stated in the posting) | The company may just not publish pay, or the figure may sit below what a 6-year senior expects. No band is established because the market search was refused | `[inferred]` from the posting's silence | What base salary range and equity are budgeted for this role? | unresolved |
| RR3 | Location and working pattern unstated | unknown | — | (no location or remote policy stated) | It could be remote, hybrid or office-based. Unknown against your constraints, which you haven't given | `[inferred]` from the posting's silence | Is this role remote, hybrid or office-based, and where? | unresolved |
| RR4 | "At scale" undefined for a care-navigation app | unknown | — | "experiment design at scale" | Traffic and outcome metrics may differ from a 2M-subscriber consumer base, with longer time-to-read and more clinical guardrails | `[inferred]` from the product type; `[generic]` that health outcomes take longer to read | Roughly how many tests run per quarter, and what are the primary outcome metrics and their time-to-read? | unresolved |
| RR5 | Reporting line for the juniors unstated | unknown | — | "mentor two junior analysts" | It could be informal mentoring or real line management; that changes the job and what R8 needs to show | `[inferred]` from the JD's wording | Will the two junior analysts report to this role? | unresolved |
| RR6 | Concrete scope: tools, team size and partners named | positive_signal | — | "build self-serve dashboards in Looker… mentor two junior analysts" | The role looks genuinely defined rather than a catch-all | `[grounded]` JD | What would a strong first 90 days look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program in your own words: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | Closest match to R3 | `[grounded]` your background | pending your approval |
| P2 | Second, the Looker build: "Built the company's Looker instance from scratch — 40+ governed dashboards". Don't add "metrics layer" until G1 is answered | R4 directly; R6 is still unclear | `[grounded]` your background | pending your approval |
| P3 | Present privacy work as "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse", never as healthcare or HIPAA experience | R9's limit | `[grounded]` your background | pending your approval |
| P4 | Offer a redacted metrics-memo excerpt as a writing sample | R5 to `high` | `[grounded]` R5 | pending your approval |
| P5 | Verify the posting on Harborlight's own careers page before writing a tailored application | RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Ask the RR2–RR5 questions verbatim at the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app careers" was refused (permission not granted). It would have confirmed the company and the live posting and cleared RR1 |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary 2026" was refused (permission not granted). It would have given the market calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can write all of this up as a `tuesday-dossier.md` file you can keep or come back to. Just say if you want it.

**Upgrade menu**
- Granting web search: target 1 clears or confirms RR1, and target 2 adds a pay band and the market calibration line.
- Your non-negotiables (pay floor, location, visa status): turns the hard-gates line from unknown into real checks against RR2 and RR3.
- A metric dictionary or LookML excerpt: R6 moves out of `unclear`.
- A redacted metrics memo: R5 to `high`, plus a ready writing sample.
- The hiring manager's name: a scope read, and which of your stories to lead with for that reader.
- A deeper research pass on Harborlight (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: When you built the Looker instance, did you also own the metric definitions themselves, for example LookML models, a metric dictionary, or settling what "churn" meant with finance?

G2: Have you mentored, onboarded or reviewed the work of other analysts, even informally?

RR2/RR3: What are your non-negotiables on pay, location or remote work, and work authorization?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.