Reading the skill's worked report template before writing the assessment.
Now running the L1 research pass (company check, then a market sweep for the role).
**Yes, apply. Your experience covers this role's core requirements directly. The conditions are below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important`: direct: R7a · adjacent: R7b (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience (HIPAA))

R6: probably recoverable from the Looker build, but you haven't said it yet; R8: your background doesn't mention mentoring; R7b and R9: these are the healthcare bridges, and their limits are named in the map.

**Opportunity ledger.** The role is well defined but the employer is unverified. I couldn't confirm the company or the posting (RR1). Pay isn't stated (RR2). Who owns the juniors, and what can be A/B tested in a health product, are open (RR4, RR5). No success measures are stated (RR6). One entry is positive: the role comes with a named team (RR3).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting check out (RR1); (2) the mentoring question is answered honestly, either with real examples or as a stated growth area (R8); (3) the healthcare bridge is framed as consumer-privacy work, never as HIPAA or healthcare experience (R7b, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header; not independently checked, because research was refused (see Evidence status) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A senior IC with lead-like breadth: one person across metrics definition, experimentation, BI and people development | `[inferred]` from the five responsibilities listed with no other analytics lead mentioned |
| Market calibration | Not established. The role-family sweep couldn't run, so I can give no band for title, scope or pay | none: research unavailable |
| Compensation | Not stated in the posting | `[grounded]` JD silent |
| Unknowns | Pay; location and remote policy; whether the juniors report to this role; limits on experimenting with clinical content; who owns the metrics layer today | — |
| Contradictions | None inside the JD; not checked against a careers page | `[grounded]` JD read in full |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years at a meal-kit subscription company (~2M subscribers). Specific, but self-reported with nothing to inspect yet | `[grounded]` your background message | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse". Specific and daily. "Expert" will be tested live, not taken from a CV | `[grounded]` your message; `[generic]` that analytics loops usually include a live SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | "Designed and ran the experimentation program: 30+ A/B tests a year", including the pricing test behind an 11% retention lift. Your strongest row | `[grounded]` your message | Optional: a sanitized test-readout write-up would raise this to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | "Built the company's Looker instance from scratch — 40+ governed dashboards." This is the named tool, not just a similar one | `[grounded]` your message | Optional: a redacted dashboard screenshot would raise this to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your message | Optional: a redacted memo excerpt as a work sample |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" and building Looker from scratch point toward owning metric definitions, but you never said you defined or maintained the metric logic yourself. I won't assume it | `[grounded]` your message is silent on metric ownership | See G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product, and the pricing test led to a retention change | `[grounded]` your message | none |
| R7b | Partner with clinicians | important | adjacent | low | transferability | You have exec and product stakeholders, but no clinical ones. Clinicians weigh patient safety and care quality, not just conversion | `[grounded]` no clinical stakeholders in your message; `[generic]` that clinical partners weigh different outcomes | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring or managing anyone | `[grounded]` your message is silent | See G2 |
| R9 | Healthcare data experience (HIPAA), preferred | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII, and you built the warehouse's consent-state model. You have never worked under HIPAA or with PHI | `[grounded]` your message, including "Never worked in healthcare" | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | You built Looker and the governed dashboards; your message doesn't say whether you owned metric definitions | R6 is the one `must_have` row that isn't `direct`; a yes moves it to `direct` | Writing LookML views and explores; owning the canonical definition of "active subscriber" or churn; settling conflicting metric definitions between teams; a dbt or semantic-layer project | A LookML or dbt excerpt, a metrics glossary, a definitions doc | `[grounded]` your message is silent on definitions |
| G2 | Mentoring (R8, important) | discovery | Nothing in your background | The JD names two juniors, so you will be asked about this | Onboarding a new analyst; reviewing others' SQL or test designs; running an experimentation training; informal mentoring of an intern | A training deck, a review checklist, a mentee's note | `[grounded]` your message is silent |
| G3 | Clinician partnership (R7b, important) | transferability | Carries over: turning analysis into decisions for non-technical leaders. Limit: you haven't worked with clinicians or with care-quality outcomes. Strengthener: show how you balanced a business metric against a guardrail metric | It's a stated responsibility in a domain you're new to | Tests where you set guardrail metrics such as complaints or cancellations; working with ops or food-safety experts | A test plan that shows guardrails | `[grounded]` your message; `[generic]` that guardrail framing is the closest consumer equivalent |
| G4 | HIPAA (R9, preferred) | transferability | Carries over: handling PII, consent modeling, privacy-aware warehouse design. Limit: HIPAA's PHI rules, de-identification standards and the "minimum necessary" principle are new to you | It's only a plus, but it's the most visible domain gap | — (already stated by you) | Your consent-state model design doc, sanitized | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here the cause is simply that research couldn't run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (no pay figure in the JD) | The range may come later in the process, or may sit outside what you expect; no market band could be researched to compare it against | `[inferred]` from the posting's silence | What salary range and equity are budgeted for this role? | unresolved |
| RR3 | Named team to develop | positive_signal | — | "mentor two junior analysts" | The function has real people and resources, not one analyst alone | `[grounded]` JD | How long have the two juniors been on the team, and what are they working on now? | noted |
| RR4 | Mentoring without stated reporting lines | unknown | — | "mentor two junior analysts" | You may be responsible for their growth without managing them | `[inferred]` from "mentor" rather than "manage" | Do the two juniors report to this role, or to someone else? | unresolved |
| RR5 | What can be tested in a health product | unknown | — | "design and analyze A/B tests" | Clinical content, consent and safety rules may limit experiments, so your 30+ tests a year pace may not carry over | `[generic]` that regulated health products restrict experiments on clinical flows | Which product areas are open to A/B testing, and who signs off on tests that touch clinical content? | unresolved |
| RR6 | No success measures stated | unknown | — | (no outcomes in the JD) | What success looks like may be undefined, or just not written down | `[inferred]` from the JD's silence | What would make this hire a success at six months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with: "Designed and ran the experimentation program — 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | see R3 | `[grounded]` your own words | pending your approval |
| P2 | Second, the Looker build: "Built the company's Looker instance from scratch — 40+ governed dashboards." Add metrics-layer ownership only if G1 confirms it | see R4, R6 | `[grounded]` your own words | pending your approval |
| P3 | Frame privacy as "GDPR/CCPA consumer PII; built the consent-state model for our warehouse." Never "HIPAA experience" or "healthcare data" | see R9 | `[grounded]` your own words | pending your approval |
| P4 | Use the monthly exec memo and the VP Product readouts as your writing evidence; bring a redacted memo excerpt if you're allowed to | see R5 | `[grounded]` your message | pending your approval |
| P5 | Check the employer and the live posting before you spend effort on a tailored application | see RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Ask the verification questions for RR2, RR4, RR5 and RR6 in your first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |

Nothing in this plan is final until you approve it. That covers the lines in P1–P4 and the positioning advice around them.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app"; the call was refused because search permission isn't granted. It would have confirmed or cleared RR1 and filled the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary 2026"; the call was refused because search permission isn't granted. It would have set the market calibration and a pay band to compare against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you want to keep this, I can save it as a `tuesday-dossier.md` file you can bring back to later sessions.

**Upgrade menu**
- Grant search permission → targets 1 and 2 run: RR1 can clear (which may lift the status toward `go`), and role reality gets a market band and a pay comparison.
- Your CV, or a redacted dashboard screenshot, memo excerpt or test readout → R3, R4 and R5 can rise to `high`.
- An answer to G1 → R6 can move to `direct`, which would put every `must_have` row (R1–R6) at `direct`.
- Your non-negotiables (pay floor, location or remote, start date) → real hard-gate checks in place of "unknown".
- The hiring manager's name → which of your stories to lead with for that reader.
- A deeper research pass on Harborlight (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs once search is allowed.

**Questions**

G1: Did you personally define and maintain metric logic, for example LookML models, canonical definitions of churn or active subscribers, or a dbt or semantic layer? Or did someone else own the definitions while you built the dashboards?

G2: Have you mentored, onboarded or reviewed the work of other analysts, even informally? What did that involve?

Constraints: Do you have a pay floor, a location or remote requirement, or other must-haves this role has to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.