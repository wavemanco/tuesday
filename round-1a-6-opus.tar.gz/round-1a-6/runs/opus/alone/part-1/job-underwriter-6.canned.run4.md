I've read the skill's rules; next I'll open the posting and do the research.
## Decision snapshot

**Yes, go for it. The core of the job matches what you do now, and two gaps need honest framing before you apply. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days a week)
- `must_have` — direct: R2a, R3, R4a · adjacent: R5 (Experience owning a forecast) · unclear: R2b (At a B2B software company), R4b (Spreadsheet modelling), R6 (Working with finance on billing or revenue data)
- `important` — direct: R7 · absent: R8 (Own billing data)

R5 — your pipeline review is a real bridge, but you haven't owned a forecast and that limit has to be stated; R6 — the row your answers are most likely to move; R8 — a real gap you can learn, so say it openly rather than stretch to cover it.

**Opportunity ledger.** The role looks sound. The employer exists as described (RR5) and the pay is published and sits at market rate (RR4). Two things are unknown: who actually owns the forecast (RR3), and whether one person is expected to cover all of CRM, billing data, reporting and the forecast (RR2). Separately, I couldn't confirm the posting on Quillfield's own website (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) two days a week in Bristol works for you (R1); (2) you present the forecast gap as adjacent experience and never claim you owned one (R5); (3) the forecast and billing scope turn out to be supported, not solo, when you ask in interview (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about (search result) |
| Mandate | "Own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Reporting line | The recruiter named Tamsin Achebe as hiring manager. Her public title is Head of Revenue Operations, Quillfield, and before that she was a sales operations manager at Corvane Payments for four years | `[grounded]` your message; public profile (search result) |
| Scope read | A "Lead" role under a Head of RevOps, so probably a senior individual contributor or first hire, not head of the function. The forecast is shared with the CFO, not owned alone | `[inferred]` from the title, the hiring manager's title and "with the CFO" |
| First-year outcomes | Not stated. Probably a working quarterly forecast cycle and billing data fit for reporting | `[inferred]` from the mandate; the posting names no outcomes |
| Market calibration | UK B2B software RevOps lead: median base £64,200, middle half £57,800–£70,400 (n=438). The posting's £61.5k–£67k sits inside that range and spans the median. It's a national figure, not Bristol-specific | `[generic]` Ledgerline 2026 UK pay guide; `[grounded]` posting figure |
| Unknowns | Size of the RevOps team; who signs off the forecast; what billing system they use and how clean its data is; how the share options are valued | — |
| Contradictions | None between the posting and Quillfield's about page. The posting wasn't found on Quillfield's own site (RR1) | `[grounded]` about page; careers URL returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the term. You didn't say where you're based or whether it works. "UK team" doesn't settle it | `[grounded]` posting; your message is silent | Closing question R1 |
| R2a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. Specific, but nothing inspectable yet | `[grounded]` your message | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a "B2B payments company". Whether it sells software as its product isn't stated | `[grounded]` your wording; `[generic]` many payments firms are software businesses and some aren't | Say in the CV what the product is, if it is software |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. A certification record would raise this to high | `[grounded]` your message | Optional: link the certification record |
| R4a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. "Strong" isn't shown yet. Expect a technical probe | `[grounded]` your message; `[generic]` RevOps loops often include a SQL exercise | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily, but daily use isn't modelling. Whether you've built driver-based or scenario models isn't stated | `[grounded]` your message | See G3 |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is the input side of a forecast. Limit, in your words: "never owned the company forecast — finance did that" | `[grounded]` your message | See G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Billing data is ruled out by your own statement. Revenue data is open: renewal dashboards may use contract values, and whether finance used them isn't stated | `[grounded]` your message | See G2 |
| R7 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is open (G2) | `[grounded]` your message | Optional: a sanitized dashboard screenshot |
| R8 | Own billing data | important | absent | none | capability | You've said you've never worked on billing data. No adjacent claim was made. At an invoicing company this data is core to the product | `[grounded]` your message; `[inferred]` that billing data matters more at an invoicing company | Present it as the area you'd be learning (P3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R5, must_have) | transferability | Pipeline review with the sales director; finance owned the company forecast | The role runs the quarterly forecast with the CFO. How strong this bridge is shapes your positioning | A commit or best-case call you built for the sales director; a renewal or churn forecast; pipeline-coverage figures finance pulled into its number; a forecast-accuracy check you ran | A sanitized pipeline-review deck or commit sheet | `[grounded]` your message; `[inferred]` that this is the most-probed gap |
| G2 | Finance and revenue data (R6, must_have) | discovery | Renewal dashboards exist; finance's use of them is unknown | Resolving it could move R6 to `direct` or `adjacent` | Dashboards showing ARR, contract value or renewal revenue; reconciling CRM figures with finance's; finance using your numbers in board or monthly packs | A dashboard screenshot with figures blurred | `[grounded]` your message |
| G3 | Spreadsheet modelling (R4b, must_have) | discovery | Excel daily, with no model described | Likely to come up as a case exercise | A capacity or quota model; a renewal-rate scenario model; a territory or commission model | A sanitized model file | `[generic]` RevOps case exercises often test this |
| G4 | B2B software company (R2b, must_have) | discovery | "B2B payments company" | A literal screen might read payments as a different sector | The company sells a software platform or API to businesses | The company's own product description | `[generic]` screening may be literal |
| G5 | Own billing data (R8, important) | capability | Ruled out by you | Billing data is central at an invoicing company | — | Closure path: learn a billing data model (invoices, credit notes, how billing ties to recognised revenue) before interview, and say plainly it's new to you | `[inferred]` from Quillfield's product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own site | unknown | — | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | Quillfield may list jobs only through Tallyboard, or that listing may be out of date | `[inferred]` from the careers URL returning no page, set against the about page confirming the company | Is this role open now, and is the Tallyboard listing the current description? | unresolved |
| RR2 | Broad mandate for one role | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting … and run the quarterly revenue forecast" | Four workstreams may sit with one person | `[inferred]` from the posting's scope set against its silence on team; `[generic]` RevOps teams at ~100-person companies are often small | Who else works in revenue operations, and which of CRM, billing data, reporting and the forecast would I own alone? | unresolved |
| RR3 | Who owns the forecast | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast may sit with this role, the Head of RevOps or finance, which changes how much R5 counts against you | `[inferred]` from "with the CFO" and the hiring manager's title | Who signs off the quarterly forecast today, and what would this role produce for it in the first quarter? | unresolved |
| RR4 | Pay published and at market | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Pay is transparent and within the role-family middle range | `[grounded]` posting; `[generic]` Ledgerline band | How are the share options sized, priced and vested? | noted |
| RR5 | Employer established as described | positive_signal | — | "Quillfield makes invoicing and payments software for UK builders' merchants" | Company, product and location match the posting | `[grounded]` about page | How big is the revenue team today, sales and finance included? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review | see R7, R5 | `[grounded]` your message | pending your approval |
| P2 | Forecast line for the CV or interview: "I run the monthly pipeline review with our sales director; the company forecast sat with finance." Use the JD's "owned the forecast" wording for none of your own history | see R5 | `[grounded]` audited clause by clause against your own two sentences | pending your approval |
| P3 | Billing data: say it's the area you'd be learning, and don't use the payments-company context to imply you've worked on it | see R8 | `[grounded]` your statement | pending your approval |
| P4 | If your company sells software, say so in the CV's company line | see R2b | `[grounded]` your wording | pending your approval |
| P5 | Ask the recruiter whether the role is current before you tailor a CV | see RR1 | `[grounded]` RR1 | pending your approval |
| P6 | Ask the RR2 and RR3 verification questions in the first call | The answers decide how much R5 and R8 count | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization and contradictions rows, RR5 and RR1 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned her public profile (linkedin.example/in/tamsin-achebe). Moved role reality's reporting line and scope read |

If you'd like, I can save this as `tuesday-dossier.md` so you can carry it into later sessions.

## Upgrade menu

- Your location or commute, and your salary floor → settles R1 and lets me check the £61.5k–£67k against what you need.
- Answers to G1 and G2 → R5's bridge gets stronger or weaker, and R6 resolves.
- A sanitized dashboard screenshot or your Salesforce certification record → R7 and R3 can move toward `high`.
- A spreadsheet model you built → R4b resolves.
- Quillfield's own listing, or the recruiter confirming the role is current → RR1 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, employee reviews, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

R1 — Does two days a week in the Bristol office work for you?

G1 — In the monthly pipeline review, did you produce any number that fed finance's forecast, such as a commit, a renewal forecast or a coverage call? What happened to it?

G2 — Did your renewal dashboards show contract values, ARR or other revenue figures, and did finance use them or reconcile against them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.