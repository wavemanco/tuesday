I've read the skill's rules; next I'll check that Pellucid Learning and the posting match what you pasted.
## Decision snapshot

**Yes, it looks worth applying to, if the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (a dbt-modelled warehouse in BigQuery) · unclear: R9 (ingestion from our app and CRM), R10 (the data contracts our analysts depend on)

R6: a bridge from Snowflake, with its limit stated. BigQuery appears in the role's duties, not in its requirements list. R9, R10: your background doesn't mention them, which is not the same as not having done them.

**Opportunity ledger.** The pay is stated, and the range is at or above the band in your recruiter's report (RR2). The posting names a funded, mid-size employer (RR6), but I couldn't verify it because my web searches were refused (RR1). Still unknown: who you'd report to (RR3), what "run the pipelines" means for on-call (RR4), and what the equity is (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Pellucid's own careers page (RR1); (2) you're based in the US or can work from Denver (R1); (3) you present BigQuery as something you'd be moving to from Snowflake, never as experience you have (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not checked against the live site (RR1) |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | One platform's reporting stack, end to end, with no reports or team lead duties mentioned. That is an individual-contributor ownership role | `[inferred]` from the JD's duties and its silence on managing people |
| Market calibration | The report's typical "Senior" at a Series B–D company has 5–8 years and owns one domain's pipelines with no direct reports. This role matches that, and your 6 years sit inside it. Against the report's median of $151,000 (IQR $139,000–$163,500), the posting's floor is $9,000 above the 25th percentile and its top is $2,500 above the 75th | `[generic]` Datawright 2026 report as pasted, not checked; `[grounded]` JD for the range |
| Unknowns | Hiring manager and reporting line; team size; on-call; equity type and size; which CRM; interview loop | — |
| Contradictions | None between the JD and the about-page text as pasted | `[grounded]` pasted texts only; not compared with the live pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US | `[grounded]` JD term; your background is silent on it | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering" is specific but self-reported, and there's no artifact to inspect at intake | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily." Specific; expect a live SQL or Python exercise to test it | `[grounded]` your background; `[generic]` that this role family tests it live | none |
| R4 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models." Specific and owned | `[grounded]` your background | none |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the requirement is worded | `[grounded]` your background against the JD wording | none |
| R6 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt modelling on Snowflake carries over. What it doesn't cover: BigQuery's cost model (bytes scanned, slots), partitioning and clustering, and nested or repeated fields | `[grounded]` "Never used BigQuery"; `[generic]` what differs between the two warehouses | See G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration." An exact match | `[grounded]` your background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite." Specific and owned | `[grounded]` your background | none |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background doesn't mention which sources you ingested or how | `[grounded]` background silent | See G2 |
| R10 | The data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations suite is close to this, but contracts with downstream analysts aren't mentioned | `[inferred]` closeness drawn from R8 | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Solid dbt and Snowflake work, and you've said you haven't used BigQuery | It's the platform you'd work on from day one. Because the requirements list only says "a cloud warehouse", this is something to present well, not a missing requirement | Any GCP use at all; moving dbt models between adapters; cost or performance tuning on Snowflake (clustering, warehouse sizing) | A small public repo with a few of your models running on BigQuery | `[grounded]` JD wording and your statement; `[generic]` that a short work sample narrows this objection |
| G2 | App and CRM ingestion (R9, important) | discovery | Nothing about your ingestion sources | It's one of the role's three named duties | Pulling from a CRM like Salesforce or HubSpot; product event streams; Fivetran or Airbyte connectors; custom Python extractors; CDC from an application database | A pipeline README or DAG diagram, sanitized | `[grounded]` JD duty; background silent |
| G3 | Data contracts (R10, important) | discovery | A test suite you set up, but nothing about agreements with analysts | The JD names contracts as something analysts depend on, so it's likely to be probed | Schema or freshness agreements with analytics; dbt model contracts or versions; alerting the owners when a GE check breaks; documented SLAs | A contract YAML, an SLA doc, an incident write-up | `[grounded]` JD; `[inferred]` link to R8 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here the cause is that my searches were refused, so nothing was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary range stated, at or above the report's band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and competitive for the level | `[grounded]` JD; `[generic]` band from the pasted report | Where in the range do offers for this level usually land? | noted |
| RR3 | No hiring manager or reporting line named | unknown | — | "The posting names no hiring manager." | The reporting line may be undecided, or simply not published | `[inferred]` from the posting's silence | Who does this role report to, and how big is the data team? | unresolved |
| RR4 | "Build and run" may include on-call | unknown | — | "Build and run the pipelines" | Running production pipelines can come with an on-call rotation | `[generic]` role-family pattern | Is there an on-call rotation for pipelines, and how often does it come around? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | The type, size and vesting are unknown, so its value can't be judged | `[inferred]` from the bare phrase | What form does the equity take, how large is a typical grant at this level, and what's the vesting schedule? | unresolved |
| RR6 | Recent Series C and a mid-size headcount | positive_signal | — | "264 employees. Series C ($52M, February 2026)." | Recent funding suggests the role is resourced, if the figures are confirmed | `[grounded]` pasted about page, unverified | What's the data team's hiring plan over the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the careers URL yourself and confirm the posting is live before you put time in | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with what you've already said, in your own words: "built our dbt project on Snowflake — about 180 models", Airflow orchestration, and "set up our Great Expectations test suite" | R4, R7, R8 | `[grounded]` your background | pending your approval |
| E2 | State BigQuery plainly as Snowflake experience, with BigQuery not yet used. Don't list BigQuery as a skill | R6 | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Optional: a small public repo running a few dbt models on BigQuery | G1 | `[generic]` a short sample narrows the warehouse objection | pending your approval |
| Q1 | Ask the register's verification questions word for word in early calls | RR1, RR3, RR4, RR5 | `[grounded]` register | pending your approval |

Every proposed wording above (E1, E2) uses only your own phrases, and each one is pending your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring Denver senior data engineer". Web search permission was refused. It would have confirmed the company and the live posting, and cleared RR1 |
| 2. Role-family sweep | unavailable | Searched "Datawright 2026 Data Engineering Pay Report" to check the pasted report was real and current. Refused. It would have confirmed the market calibration band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search for |

I can save all of this as a `tuesday-dossier.md` to carry into later steps, if that's useful.

**Upgrade menu**
- Allow web search and I'll rerun targets 1–2 → RR1 clears or stands, and the report's band is checked. On your word I'd also do a deeper pass on Pellucid (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches).
- Your location and any pay floor or other non-negotiables → R1 closes, and the salary range gets checked against your floor.
- Answers to G2 and G3 → R9 and R10 move off `unclear`.
- The hiring manager's name → a sharper scope read, and a choice of which story to lead with for that person.
- Your current CV → I can check whether it presents R4–R8 as clearly as your summary here does.

**Questions**

R1: Are you based in the US, or able to work from Denver? And is there a pay floor or other non-negotiable I should check this role against?

G2: What sources have you built ingestion for, such as a CRM, product events or app databases, and with what tools?

G3: Have you set up agreements with analysts on schemas, freshness or breaking changes, for example dbt contracts or owner alerts when a Great Expectations check fails?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.