I've read the skill's rules. Next I'm opening your posting link, then I'll check the company and the role.
**Yes, it's worth applying for, as long as the conditions below hold. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two days a week in the office)
- `must_have`: direct: R2a, R3, R4a · adjacent: R5 (experience owning a forecast) · unclear: R2b (at a B2B software company), R4b (spreadsheet modelling), R6 (working with finance on billing or revenue data)
- `important`: direct: R7, R9 · absent: R8 (own billing data)

R5: a credible bridge from your pipeline review, with its limit named; R6, R8: the finance and billing side, which is the real gap; R1: the one term not yet settled.

**Opportunity ledger.** The role looks sound. The pay is stated and sits near the market middle (RR1), and the hiring manager is the Head of Revenue Operations (RR5). The mandate is broad for a company of 96 people (RR3), and the posting's split of the forecast with the CFO is undefined (RR4). I couldn't find the role on Quillfield's own site (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Two days a week in Bristol works for you (R1). If it doesn't, this becomes `no_go`.
  2. £61,500–£67,000 meets your floor.
  3. The forecast experience is framed honestly as adjacent, never as ownership (R5, RR4).
  4. You can show something real on the finance and revenue-data side (R6), or you go in naming billing as the thing you'd learn (R8).
  5. The recruiter confirms the role is open (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about (search result) |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that the sales and finance teams run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Reporting line | Tamsin Achebe, Head of Revenue Operations at Quillfield. Previously sales operations manager at Corvane Payments for four years | `[grounded]` public profile (search result) |
| Scope read | A lead role under an existing revenue-operations head. It differs from your current job mainly on the finance side: billing data and the forecast | `[inferred]` from the mandate against the hiring manager's title |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posting's range sits inside it, around the median. Pay only; I didn't search scope norms | `[generic]` Ledgerline 2026 pay guide (search snippet, page not fetched); `[grounded]` posting figures |
| Unknowns | Team size; the billing system; who signs off the forecast; whether billing admin sits with finance or with this role; your location and pay floor | — |
| Contradictions | None between the posting and Quillfield's about page. The role isn't visible on Quillfield's own site (RR2) | `[grounded]` careers page fetch returned no page; role search returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You didn't say where you're based or whether two office days work for you | `[grounded]` posting; your background is silent on it | Closing question 1 |
| R2a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | 5 years in sales ops, the last 2 running revops for the UK team. Specific, but self-reported with nothing to inspect yet | `[grounded]` your background | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a "B2B payments company". Whether it counts as software isn't established | `[grounded]` your wording; `[generic]` that literal screens read the employer's category | Upgrade menu: say what the company sells |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. A certification can be checked, but I haven't checked it | `[grounded]` your background | Upgrade menu: certification verification link |
| R4a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. How you use it isn't detailed, so it stays medium | `[grounded]` your background | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily, but daily use isn't the same as modelling (capacity, quota, commission or scenario models). Not established | `[grounded]` your wording; `[inferred]` that use and modelling differ | Upgrade menu: name a model you built |
| R5 | Experience owning a forecast (the role runs the quarterly revenue forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director. You've said plainly that you never owned the company forecast, which finance did | `[grounded]` your background | G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've ruled out billing data. The requirement says "or", and renewal dashboards often draw on contract or revenue values, so revenue work with finance may exist but isn't stated | `[grounded]` your wording; `[generic]` that renewal reporting usually involves contract values | G2 |
| R7 | Own the CRM data | important | direct | medium | none | Salesforce admin who rebuilt the pipeline and renewal dashboards | `[grounded]` your background | none |
| R8 | Own the billing data | important | absent | none | capability | You've said directly that you've never worked on billing data | `[grounded]` your background | G3 closure path |
| R9 | Build pipeline and renewal reporting for the sales and finance teams | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them isn't stated | `[grounded]` your background | Upgrade menu: sanitized dashboard screenshots |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5, must_have) | transferability | **Carries over:** running the monthly pipeline review with the sales director. **Limit:** you haven't owned the company number, and the role runs it with the CFO. **Would strengthen:** a sales-side commit or forecast you produced and tracked | The role's most distinctive duty; this bridge decides how far you can push the positioning | Producing a commit or best-case number at pipeline review; tracking forecast accuracy against actuals; feeding the pipeline view into finance's forecast | A sanitized pipeline-review deck or forecast-vs-actual sheet | `[grounded]` your background; `[inferred]` that this is the decisive row |
| G2 | Finance on revenue data (R6, must_have) | discovery | No billing data. Revenue data with finance isn't covered either way | Resolving it could move R6 to `direct` | Reconciling renewals or bookings with finance; commission or ARR figures agreed with finance; month-end hand-offs | A reconciliation template or a dashboard spec that names finance as a user | `[grounded]` your silence on it |
| G3 | Billing data (R8, important) | capability | Absent by your own statement | Carried as the main learning curve | Closure path: learn Quillfield's billing system before or during onboarding, and present it as your first-90-days learning item. This is not a claim | — | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, at market | positive_signal | — | "£61,500–£67,000 plus share options" | The range sits near the role-family median | `[grounded]` posting; `[generic]` band | How are the share options valued and vested? | noted |
| RR2 | Role not found on Quillfield's own site | unknown | — | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | Quillfield may recruit only through the jobs board or the recruiter, the listing may be stale, or the careers page may live at another address | `[generic]` pattern, not a claim about this employer | Is this role open now, and is it listed on Quillfield's own site? | unresolved |
| RR3 | Broad mandate for the company's size | risk_signal | low | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may combine sales-ops and finance-ops work with little team support | `[inferred]` from the mandate against 96 employees | Who else works in revenue operations, and does billing admin sit with finance or with this role? | unresolved |
| RR4 | Forecast ownership split undefined | unknown | — | "run the quarterly revenue forecast with the CFO" | It's unclear whether this role owns the number or prepares it for the CFO | `[inferred]` from the word "with" | Who signs off the forecast that goes to the board, this role or the CFO? | unresolved |
| RR5 | A revenue-operations head is in post | positive_signal | — | "Head of Revenue Operations, Quillfield" | The function has a lead to report into | `[grounded]` public profile | What should this role have taken off your plate by month six? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own words: "rebuilt our pipeline and renewal dashboards", Salesforce admin certified, running revops for the UK team | See R3, R7, R9 | `[grounded]` your background | pending your approval |
| P2 | Frame the forecast exactly: "I run the monthly pipeline review with our sales director; the company forecast was owned by finance." Don't write "forecasting experience" | See R5 | `[grounded]` your wording | pending your approval |
| P3 | Name billing data as the thing you'd learn first, never as experience | See R8 | `[grounded]` your statement | pending your approval |
| P4 | Ask the recruiter RR2's question, and RR3 and RR4, before investing in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |
| P5 | Mention your payments-sector context; the hiring manager's past role was also sales ops at a payments company | See RR5 | `[grounded]` public profile | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software Bristol careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page; searched 'Quillfield "Revenue Operations Lead" job', no results. Moved the organization and contradictions rows and RR2 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the reporting line, RR5 and P5 |

I can save all of this as `tuesday-dossier.md` to carry into later steps, if you'd like.

**Upgrade menu**
- Your location and pay floor: settles R1 and checks RR1 against your number.
- Your CV: turns R2b and R4b from my reading of a summary into readable text.
- What your current employer sells (a software platform or not): settles R2b.
- A model you built in Excel (capacity, quota, commission): could move R4b to `direct`.
- Your Salesforce certification verification link: R3 to `high`.
- Sanitized dashboard screenshots: R9 to `high`.
- A deeper research pass on Quillfield (funding and leadership since the Series A, hiring patterns, employee reports, recent news), up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

R1: Can you do two days a week in Bristol, and does £61,500–£67,000 meet your floor?

G1: Does your monthly pipeline review produce a number you put your name to, like a commit or a forecast? Do you track it against what actually closed?

G2: Have you worked with finance on revenue figures of any kind, such as renewal values, bookings reconciliations or commission data, even if not billing?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.