Reading the skill's rules is done. Next I'm checking that Pellucid's posting is live, then I'll write up the assessment.
**Yes, it looks worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R6, R7
- `important`: adjacent: R5 (BigQuery as the warehouse) · unclear: R8 (ingestion from our app and CRM), R9 (data contracts our analysts depend on)

R5: Snowflake to BigQuery is a credible bridge, with its limit stated; R8, R9: your background doesn't cover these yet, so they're open questions, not gaps.

**Opportunity ledger.** The pay sits at or above the market band your recruiter sent (RR2), and the company raised a Series C this year (RR5). The posting names no reporting line and no first-year outcomes (RR3, RR4). I also couldn't confirm the posting myself (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live (RR1); (2) you can work US-remote or from Denver (R1); (3) BigQuery is presented as new to you, with Snowflake as the bridge, never as experience you have (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring for schools in 31 US states; founded 2016 in Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page as you pasted it; not checked live (RR1) |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting) owned end to end, with no direct reports mentioned | `[inferred]` from the JD's single "reporting" mandate and its silence on managing people |
| Market calibration | Senior at Series B–D usually means 5–8 years and ownership of one domain's pipelines with no reports. This JD matches that. The posting's $148,000–$166,000 runs from above the band's 25th percentile ($139,000) to above its 75th ($163,500), and its midpoint ($157,000) is above the median ($151,000) | `[generic]` Datawright 2026 report as pasted (US, n=2,310); `[grounded]` JD, for the posting's range |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Reporting line and team size; success measures; equity terms; whether BigQuery experience is screened as must-have | — |
| Contradictions | None between the pasted JD and About page; I couldn't check either against the live site | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work from the US | `[grounded]` JD term; background silent | G1's question |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated, above the 5+ bar. You told me this but nothing has been inspected, so it stays `medium` | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake meets "a cloud warehouse" | `[grounded]` your background | an inspectable artifact would raise it (upgrade menu) |
| R5 | BigQuery, the warehouse this team runs | important | adjacent | medium | transferability | The JD names BigQuery in the role description, not the requirements. dbt-on-Snowflake modelling carries over directly. The limit: you haven't used BigQuery's cost model, partitioning and clustering, IAM, or its SQL dialect | `[grounded]` JD wording and your "never used BigQuery"; `[generic]` that warehouse switches are usually treated as learnable at this level | G2; plan W1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | none |
| R8 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your background covers modelling and orchestration, not where your data came from | `[grounded]` background silent; `[inferred]` that a payroll company had source systems to ingest | G3's question |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned. The Great Expectations suite may be part of an answer but isn't a contract on its own | `[grounded]` background silent | G4's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | US-remote or Denver (R1, hard_gate) | hard_gate | Nothing about your location or right to work | The one condition that could turn this into a no | — | — | `[grounded]` JD term |
| G2 | BigQuery (R5, important) | transferability | Strong dbt and Snowflake; no BigQuery | Likely the first probe in a technical screen | dbt adapters you've switched; Snowflake cost and clustering tuning you did; any warehouse migration | A small public dbt project running on BigQuery | `[grounded]` your background; `[generic]` that screens probe the named stack |
| G3 | Ingestion from the app and CRM (R8, important) | discovery | Ingestion not described | Half of this role's stated pipeline work | Loading Salesforce or HubSpot data; app event or database CDC pipelines; Fivetran, Airbyte or custom Python extractors you owned | A design doc, a DAG listing, a redacted architecture diagram | `[grounded]` JD lists both sources |
| G4 | Data contracts (R9, important) | discovery | Not mentioned | The JD calls these out as something analysts depend on | Schema agreements with upstream engineers; dbt model contracts or exposures; Great Expectations checks wired to block a bad load; SLAs agreed with analysts | dbt `contract:` configs, a contract spec, an incident write-up | `[grounded]` JD wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not established from attributable sources: both my checks were blocked by permissions | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Three possibilities, none ranked: the posting is stale, the copy differs from the live page, or it isn't a live opening | `[generic]` pattern, not a claim about this company | Is the Senior Data Engineer role on your careers page still open, and who would I be interviewing with? | unresolved |
| RR2 | Pay at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Posted pay matches or beats the band for this title and stage | `[grounded]` JD; `[generic]` Datawright band | Where in the range do you expect to place someone with 6 years and no BigQuery? | noted |
| RR3 | No hiring manager or reporting line named | unknown | — | the posting names no hiring manager | Ownership of the reporting stack may sit with one engineer or a team; it isn't clear which | `[inferred]` from the JD's silence | Who does this role report to, and how many data engineers are on the team? | unresolved |
| RR4 | No success measures stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | What a good first year looks like is undefined | `[inferred]` from the JD's silence on outcomes | What would a successful first year in this role look like? | unresolved |
| RR5 | Recent Series C | positive_signal | — | "Series C ($52M, February 2026)" | Funding is recent, which tends to support near-term hiring | `[grounded]` About page as pasted; `[generic]` funding-to-hiring pattern | What are the equity terms: type, vesting, and the last preferred price? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with: "Built our dbt project on Snowflake (about 180 models); set up our Great Expectations test suite; Airflow orchestration" | see R4, R6, R7 | `[grounded]` your own sentences, wording unchanged | resume_edits_pending_approval |
| E2 | State BigQuery plainly: warehouse experience is Snowflake, and BigQuery is new to you. Don't list it as a skill | see R5 | `[grounded]` "Never used BigQuery" | pending your approval |
| W1 | Optional: port a handful of dbt models to a BigQuery sandbox and publish them as a public repo before the technical screen | see R5, G2 | `[generic]` a small artifact narrows a named-stack gap | pending your approval |
| A1 | Open the posting yourself and confirm it's live before investing time | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions for RR1, RR3, RR4 and RR5 in the recruiter screen | The register doubles as screen prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried to fetch pellucidlearning.com/careers/senior-data-engineer and to search "Pellucid Learning Senior Data Engineer". Permission settings refused both. They would have confirmed the posting is live and matches your copy, which is why RR1 stays open |
| 2. Role-family sweep | skipped | The Datawright report you pasted is already in hand and fixes the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was nothing to search for |

I can put all of this into a `tuesday-dossier.md` to carry forward, if that's useful.

**Upgrade menu**
- Confirm the posting is live (open it, or allow web access) → RR1 closes and the `conditional_go` cap lifts.
- Your location, right-to-work status and pay floor → R1 settles, and your floor gets checked against the posting's $148,000–$166,000.
- Examples for G3 or G4 → R8 and R9 move to `direct` or `adjacent`.
- For data engineering the proof artifact is code: a sanitized dbt docs site, a Great Expectations config, or a public repo → R4 and R7 can rise to `high`.
- The hiring manager's name → a sharper scope read, and which story to lead with.
- A deeper research pass on Pellucid (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). It needs web access allowed. Say the word and it runs.

**G1**: Are you based in the US, or willing to work from Denver? Do you have a pay floor or any other non-negotiables?

**G3**: Did you own any ingestion work, such as pulling CRM data (Salesforce, HubSpot) or app and database data into Snowflake? Which tools, and which parts were yours?

**G4**: Have you set up anything that worked as a data contract, like schema agreements with upstream teams, dbt model contracts, or quality checks that blocked bad loads before analysts saw them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.