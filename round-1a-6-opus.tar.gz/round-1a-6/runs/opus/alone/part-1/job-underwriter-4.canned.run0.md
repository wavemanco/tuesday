Quick update: I've run three of my five allowed searches. The company name returned nothing, so I'm trying one more search for its careers page before writing this up.
# Should Renata apply? Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Your experience covers what the role asks for, but Brindlemoor's own careers page contradicts the "fully remote" line in the JD. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (monitor rating models)
- `important`: unclear: R8 (recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (pet-insurance pricing domain)

R5b: probably part of your maintenance work, but you didn't say so; R8: the product side of your recommendations isn't covered yet; R10: a credible bridge from motor pricing, with its limit named.

**Opportunity ledger.** The posting is live on the company's own site and its reporting line matches the JD (RR4). But the working pattern is contradicted (RR1), the salary is withheld (RR2), and the company's size and stage could not be established (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed in writing and works for you (R1, RR1); (2) the budgeted salary meets your floor (RR2); (3) pet insurance is framed as a bridge from motor pricing, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD and careers page agree |
| Line management | None stated, in the JD or on the careers page | `[grounded]` JD and careers page silence |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` JD; `[grounded]` brindlemoor.co.uk/careers/senior-pricing-analyst |
| Scope read | A senior individual-contributor pricing role with a single product to cover; the title doesn't imply team leadership here | `[inferred]` from the mandate and the absence of any management language |
| Hiring manager | Director of Pricing; previously head of pricing analytics at Calloway Re for six years; spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. Whether Brindlemoor's book is small is not established | `[grounded]` public professional profile |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (Pricewell 2026, n=612). This is the market band, not Brindlemoor's offer, and the posting withholds pay (RR2) | `[generic]` 2026 pay survey; `[grounded]` the JD's silence on pay |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Salary; company size and stage; how big the pet book is; who decides on product changes | none |
| Contradictions | Remote versus Leeds four days a week, between the JD and the company's own careers page | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | Your own constraint on location isn't stated, so nothing grades it yet. The employer's terms are also contested: the JD says remote, the careers page says Leeds four days a week | `[grounded]` JD versus careers page | Closing question 1; confirm the pattern with the recruiter in writing |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Self-reported, which is the ceiling at intake | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Stated, not yet inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built a rating model | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" doesn't say whether you monitored performance (drift, actual-versus-expected, triggers for a refit). Low rather than none because there's a concrete thread to pull | `[grounded]` your background is silent on monitoring | G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. You said "ran", so how much of the design and readout was yours isn't stated; expect a probe | `[grounded]` your background | Rehearse exactly which parts were yours |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Turning results into recommendations for product | important | unclear | low | discovery | Your background covers underwriting as the audience; product isn't mentioned | `[grounded]` your background is silent on product | G2 |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance pricing domain (implied by the product) | preferred | adjacent | medium | transferability | What carries over: GLM rating, price testing and underwriting-facing reviews in a personal-lines book. The limit: you've never worked on pet insurance. `[generic]` Pet rating usually turns on factors motor doesn't use, such as species, breed and the animal's age, plus vet-cost inflation | `[inferred]` requirement, from "our pet-insurance product"; `[grounded]` your own statement | See the application plan, P2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | Built and maintained a GLM; nothing yet on how you tracked its performance after deployment | This is the only `must_have` row not at `direct`, and the hiring manager's public talk is about monitoring rating models | Actual-versus-expected tracking on the young-driver book; drift or stability checks on rating factors; deciding when the model needed a refit; reporting monitoring results at the quarterly review | A sanitized monitoring dashboard description, a refit decision note, or the structure of a quarterly review pack | `[grounded]` your background is silent; `[grounded]` the talk title in Odile Varga's public profile |
| G2 | Recommendations for product (R8, important) | discovery | Your recommendations go to underwriting; there's no sign of a product audience | The JD names product as a second audience for the recommendations | Price-test results that changed cover options, excesses or the quote journey; working with a product owner on a launch or a rate change | An example of a recommendation and what it changed | `[grounded]` the JD names product; your background is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicted between the JD and the careers page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One of the two is out of date, or the pattern changed after the JD was written | `[inferred]` from the two sources disagreeing | Is this role fully remote, or based in Leeds four days a week, and is that written into the contract? | unresolved |
| RR2 | Salary withheld | unknown | — | No pay figure in the JD or on the careers page | The figure may sit anywhere relative to the £52.1k–£64.9k market range in role reality | `[inferred]` from the withheld figure, set against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Company size and stage not established | unknown | — | "Brindlemoor (insurtech)" | A search on the company name returned nothing beyond the careers page, so its size, funding and book size are unknown. The posting itself is live on the company's own domain | `[grounded]` search results; careers page fetched | How large is the pet book today, and how is the pricing team staffed? | unresolved |
| RR4 | Posting live on the company's own site, with the reporting line matching the JD | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The role exists as described, apart from RR1 | `[grounded]` careers page fetched | Who else sits in the pricing team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter in writing before investing in the application | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with your GLM story: "Built and maintained the GLM rating model for our young-driver book." Add monitoring only once G1 confirms it | The mandate centres on rating models (R4, R5a), and the hiring manager's public talk is about monitoring them (R5b) | `[grounded]` your own sentence; Odile Varga's public profile | pending your approval |
| P2 | Name the pet gap yourself: "My pricing experience is in UK motor; I haven't priced pet insurance. What carries over is GLM rating, price testing and taking results to underwriting." | See R10. Say it as a bridge, never as pet experience | `[grounded]` your own statements | pending your approval |
| P3 | Use your own verbs: "Ran 14 price tests last year with the underwriting team" and "Present the quarterly pricing review to the head of underwriting". Don't write "designed" or "led" unless you confirm those parts were yours | See R6, R7 | `[grounded]` your own sentences | pending your approval |
| Q1 | Ask the RR1–RR4 verification questions as written, on the recruiter call or in interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

The CV wording in P1–P3 is `resume_edits_pending_approval`. The positioning advice in the same rows is proposed too, and none of it is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers senior pricing analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: the contradictions row, RR1, RR3 and RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: the market calibration line and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved: the hiring manager row and P1 |

I can also put the whole assessment into a `tuesday-dossier.md` file you can keep and update; just say if you want it.

## Upgrade menu

- **Your working-pattern and pay non-negotiables:** R1 resolves to met or failed, and RR2 gets a floor to test against.
- **An answer to G1:** R5b can move to `direct`, and P1 gains its strongest line for this hiring manager.
- **An answer to G2:** R8 resolves.
- **The recruiter's written answer on remote versus Leeds:** RR1 closes. If you need remote and the answer is Leeds, this likely becomes `no_go`.
- **An inspectable artifact** (a sanitized price-test readout or a quarterly review structure): R6 and R7 can rise to `high`.
- **A deeper research pass on Brindlemoor** (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches): RR3 could close. Say the word and it runs.

## Questions

1. **R1:** What's your working-pattern non-negotiable? Could you do Leeds four days a week, or do you need fully remote? And what's your base salary floor?
2. **G1:** On the young-driver GLM, how did you check that the model was still performing after it went live, and what did you do when it drifted?
3. **G2:** Has any of your pricing work changed something on the product side, such as cover options, excesses or the quote journey? What was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.