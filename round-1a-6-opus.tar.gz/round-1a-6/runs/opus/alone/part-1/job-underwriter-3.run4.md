Still working: I've read the skill's rules and am now running a few quick searches on Novaline and on typical Head of Growth pay.
I wouldn't pursue this one. Your hunch is right: the posting's own terms rule you out, and parts of it look wrong for anyone.

## Decision snapshot

**No, not worth pursuing. R1 and R2, both hard gates, fail on the posting's own terms, and what feels off shows up in RR3, RR4, RR5 and RR6. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay of at least $150k), R2 (On-site in Austin 5 days a week, no exceptions)
- `must_have`: direct: R4, R5 · unclear: R3 (8+ years growth leadership), R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)
- `important`: adjacent: R10 (E-commerce enablement context), R11 (Team of one to start)

R1, R2: these fail on terms the JD states outright. R6, R7, R8, R9: scope your background hasn't shown yet, and it only matters if R1 and R2 change.

**Opportunity ledger.** Going by the posting's own words, the role is under-resourced and under-defined. Seven functions sit with one person (RR3), with no budget or authority stated (RR4). Evenings and weekends are part of the deal (RR5). Success metrics are left open (RR6), and the equity is undefined (RR7). I couldn't confirm the employer, because my searches weren't permitted (RR8). One entry points the other way: the claim that it has been profitable since day one (RR9), which is unverified.

- **Hard gates:** failed: R1 (Base pay of at least $150k), R2 (On-site in Austin 5 days a week, no exceptions).
- **Severe red flags:** none found.
- **What would have to be different:** Novaline would need to offer a base of at least $150k (R1, RR1) *and* make the role fully remote (R2, RR2). If you dropped either of your non-negotiables, the other gate would still fail.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline: e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD, not checked against the company's own site (RR8) |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget mentioned | `[grounded]` JD |
| First-year outcomes | None stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside" | `[grounded]` JD |
| Scope read | The JD bundles several specialist functions (brand/PR, SEO/content and sales ops are commonly separate hires) into one seat with a board-facing mandate | `[grounded]` JD's function list; `[generic]` that these are commonly separate roles |
| Market calibration | Not established, because the role-family pay sweep didn't run. This is why RR1 is stated against your floor and the JD's mandate, not against a market band | — |
| Unknowns | Growth budget; decision rights; equity terms; how success is judged; whether the posting is live | — |
| Contradictions | No contradiction between sources, since only the JD was provided. There is a tension: a profitable Series A company offering $70–85k for an 8+ year, board-facing head role | `[inferred]` from the JD's stage and profitability claims set against its stated pay |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your hard constraint), against the JD's "$70–85k base" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your constraint, which is specific and your own. It fails because the top of the JD's range is $65k under your floor, and equity doesn't count toward base | `[grounded]` JD figure and your stated floor | Only the employer changing its terms resolves this (plan A2) |
| R2 | On-site in Austin 5 days a week, no exceptions, against your remote-only constraint (Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your constraint. It fails on the JD's own words, "no exceptions", which rules out the usual route of negotiating | `[grounded]` JD quote and your stated constraint | None. Wording can't solve this |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | 9 years in growth, holding growth lead and then Head of Growth titles. How many of those years were leadership isn't stated, and the JD asks for leadership years specifically. This is a screening risk, not a gate | `[grounded]` your summary | G1 |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid at two companies and scaled one from $8M to $40M ARR with a budget you controlled. It's specific but not yet backed by an artifact | `[grounded]` your summary | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle at two companies and work deep in Braze. Specific, no artifact yet | `[grounded]` your summary | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Your summary names paid, lifecycle and experimentation, not SEO/content | `[grounded]` silence in your summary | G2 |
| R7 | Brand and PR | must_have | unclear | none | discovery | Not mentioned in your summary | `[grounded]` silence in your summary | G2 |
| R8 | Partnerships | must_have | unclear | none | discovery | Not mentioned in your summary | `[grounded]` silence in your summary | G2 |
| R9 | Sales ops | must_have | unclear | none | discovery | Not mentioned in your summary. B2C subscription growth often runs without a sales team | `[grounded]` silence in your summary; `[generic]` B2C sales pattern | G2 |
| R10 | E-commerce enablement context (merchant-facing, likely B2B) | important | adjacent | medium | transferability | Your growth record is in B2C subscription. Paid, lifecycle and experimentation carry over; selling to merchants rather than consumers is the limit | `[inferred]` B2B reading from "e-commerce enablement"; `[grounded]` your B2C history | G3 |
| R11 | "Team of one to start" (hands-on, solo execution) | important | adjacent | medium | transferability | You built and managed teams of 3–7, and your SQL/GA4 depth suggests you can work hands-on. Running all seven functions alone is untested | `[grounded]` your summary; `[inferred]` hands-on capacity from your tool depth | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3, must_have) | discovery | 9 years in growth, with lead/head titles; how many years were leadership isn't stated | Doesn't matter while R1 and R2 fail. In other searches, roles that ask for "8+ years leadership" may screen on titled years | Years leading the growth function, even if the title came later; managing contractors or agencies | Dated titles on your CV, an org chart | `[grounded]` your summary; `[generic]` titled-years screening |
| G2 | SEO/content, brand/PR, partnerships, sales ops (R6–R9, must_have) | discovery | No evidence either way | Doesn't matter here. It would matter for other "full-stack" head roles | Content or SEO tests inside your experimentation program; launch PR; affiliate, channel or co-marketing deals; owning CRM pipeline hygiene | Experiment logs, launch briefs, partner deal summaries | `[grounded]` silence in your summary |
| G3 | B2B merchant context and solo execution (R10, R11, important) | transferability | Credible adjacent experience, limits as named in R10 and R11 | Doesn't matter here | Experiments you ran and analyzed yourself; any B2B or merchant-side channel | A sanitized experiment readout | `[inferred]` from your summary |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay far below your floor and below what the mandate implies (see R1) | red_flag | medium | "$70–85k base plus meaningful equity upside" | The stated base may be low for an 8+ year, board-facing head role, with equity standing in for cash. Not confirmed against a market band, because the sweep didn't run. Its severity is medium because R1 already decides the outcome | `[inferred]` from the JD's years and mandate against its figure | Is the base range fixed, and how was it set for an 8+ year leadership role? | confirmed |
| RR2 | Fully on-site with no flexibility, against your remote-only constraint (see R2) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions" | Conflicts with your non-negotiable. The JD rules out negotiating it | `[grounded]` JD quote | Is there any remote arrangement for this role? | confirmed |
| RR3 | Several specializations bundled into one seat | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one" | One person accountable for work that is usually split across several roles | `[grounded]` JD list; `[generic]` that these are usually split | Which of these functions matter most in year one, and which can wait? | unresolved |
| RR4 | Responsibility without stated resources or authority | risk_signal | medium | "Own all revenue growth end to end … a team of one to start" | Accountable for all revenue with no budget, headcount plan or decision rights in sight | `[inferred]` from the JD's scope set against its silence on budget | What growth budget and hiring plan come with the role, and who signs off on spend? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work presented as culture rather than as an exception | `[grounded]` JD quote | How often did "when it matters" happen last quarter? | unresolved |
| RR6 | No definition of success on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held to a target that keeps moving, with the board watching | `[inferred]` from the JD's open metrics alongside its board dotted line | What would the CEO and board need to see at 6 and 12 months? | unresolved |
| RR7 | Equity terms undefined | unknown | — | "meaningful equity upside" | The equity's value can't be assessed without its size, vesting and valuation basis | `[grounded]` JD gives no terms | What percentage, strike price, vesting schedule and last valuation apply? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | My searches weren't permitted. The company may be too new or small to have a footprint, the posting may be old or copied from elsewhere, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Profitable since founding | positive_signal | — | "profitable since day one" | If true, the company has some runway beyond its funding round, which makes the low base harder to explain (RR1) | `[grounded]` JD claim, unverified | What is the revenue scale today, and what did the Series A fund? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply | R1, R2 | `[grounded]` evidence map | pending your approval |
| A2 | Optional: one short note asking whether base and location are fixed, accepting that a "no" closes it | Only the employer changing its terms can move R1 or R2 | `[grounded]` JD terms | pending your approval |
| A3 | In your search, filter Head of Growth roles to those that state remote and a base of at least $150k, and treat bundled "team of one" mandates (RR3, RR4) as a screening flag | Saves effort on roles with the same pattern | `[grounded]` your constraints; `[inferred]` the pattern from this JD | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth"; refused (search permission not granted). It would have confirmed the company and whether the posting is live, and could have cleared RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup base salary 2026"; refused (search permission not granted). It would have given the market calibration row and checked RR1 against a market band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to run |

I can write all this up as a `tuesday-dossier.md` file you can keep and reuse if you'd like.

**Upgrade menu**
- **Allow web search:** targets 1 and 2 run, which could clear or confirm RR8 and add a market pay band to RR1. The decision wouldn't change, because R1 and R2 fail on the JD's own terms.
- **A link to the live posting or Novaline's careers page:** confirms the posting is live and could clear RR8.
- **A deeper research pass** on funding, leadership turnover and employee reports (up to 5 more searches and 2 more fetches). Say the word and it runs once search is allowed.
- **Your CV with dated titles:** settles R3 and G1 for future postings with the same screen.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.