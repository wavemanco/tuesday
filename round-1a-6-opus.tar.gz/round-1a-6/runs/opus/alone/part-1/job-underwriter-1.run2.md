I've read the evaluation framework and I'm checking Harborlight Health's public footprint before writing up the assessment.
**Yes, apply. You meet every must-have in the posting (R1, R2, R3, R4, R5), but check first that the employer and the posting are real. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R7a · unclear: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R1, R2, R3, R4, R5 — all `medium`, waiting only on inspectable artifacts; R8 — the senior-level gap most worth closing before you apply; R9 — a real bridge, its limit named.

**Opportunity ledger.** I couldn't confirm the employer because my web searches were refused (RR1). Pay, location and reporting line are all unstated (RR2, RR3, RR5). One entry runs the other way: the tools and the team are named concretely (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting check out — RR1; (2) you have a mentoring story you can tell honestly — R8; (3) your GDPR/CCPA work is framed as adjacent to HIPAA, never as healthcare experience — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header; not checked externally (RR1) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentor two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A senior individual-contributor post with mentoring, not a management post. It owns the whole analytics surface of one product | `[inferred]` from "own product analytics" and "mentor", against no mention of direct reports |
| Market calibration | Not established. The role-family sweep could not run, so I haven't given a pay band rather than quote one from memory | — |
| Unknowns | Compensation; location or remote; reporting line; whether the juniors report to this role; warehouse stack; how much patient data the role touches | `[grounded]` JD silent on each |
| Contradictions | None within the JD; careers page not checked | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years stated. Self-report with no artifact yet, so the intake ceiling of `medium` applies | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" gets tested live rather than shown on paper | `[grounded]` your background; `[generic]` that SQL skill in this role family is usually checked in a technical screen | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program: 30+ tests a year on a ~2M-subscriber base, including the pricing test behind an 11% retention lift. Expect a probe on how that lift was measured | `[grounded]` your background | Have the pricing test's readout ready: metric definition, window, sample, guardrails |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | A sanitized memo excerpt would raise this to high (W1) |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" suggests governed metric definitions, but your background doesn't say you owned the LookML model or the metric definitions themselves | `[grounded]` background silent on metric-definition ownership; `[inferred]` that governed dashboards imply governed definitions | G2 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | You present to the VP Product monthly, and the pricing test fed a retention outcome | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | No clinician or comparable domain-expert partnership is in your background yet. Not judged absent on a first pass | `[grounded]` background silent | G3, in the upgrade menu |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring, managing or reviewing others' work | `[grounded]` background silent; `[generic]` that senior analyst loops in this role family usually ask about developing others | G1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Carries over: you've handled regulated consumer PII under GDPR/CCPA and built the warehouse's consent-state model. The limit: none of HIPAA's specifics — patient health data, business associate agreements, de-identification standards, minimum-necessary access | `[grounded]` your background; `[inferred]` the adjacency, from privacy-regulated data work to health-data rules | E2 framing |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring junior analysts (R8, important) | discovery | Nothing on developing others | The JD names this; a concrete example removes the one senior-level question your background leaves open | Onboarding a new analyst onto the Looker model; reviewing others' SQL or experiment designs; running a stats or experimentation clinic for PMs or analysts; being the informal lead for an intern | A review checklist, onboarding doc, training deck | `[grounded]` background silent; `[generic]` that loops probe this at senior level |
| G2 | Metrics-layer ownership (R6, important) | discovery | Looker built from scratch, 40+ governed dashboards; metric-definition ownership not stated | Owning the metrics layer is the first responsibility the JD lists | Writing the LookML explores and measures; settling "what counts as an active subscriber"; a dbt or semantic-layer model; a metric dictionary | LookML excerpt, metric dictionary page, data-model diagram | `[grounded]` background silent on definitions |
| G3 | Clinician-style partnership (R7b, important) | discovery | No domain-expert partnership stated | Clinicians are named stakeholders; a comparable story makes for a stronger bridge | Working with culinary, food-safety, supply-chain or support teams whose expertise shaped the analysis; translating findings for non-analytical experts | A memo or readout written for such a team | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here the search simply couldn't run | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | JD gives no salary | The figure may sit anywhere relative to market, or the company may not publish ranges | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Mentoring versus management unclear | unknown | — | "mentor two junior analysts" | The role may carry people development without formal authority, or the juniors may be direct reports | `[inferred]` from the JD's wording | Will the two junior analysts report to this role, and who owns their reviews? | unresolved |
| RR4 | Concrete tools and team named | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The scope comes with named resources, not a blank mandate | `[grounded]` JD | What does the current Looker model cover today? | noted |
| RR5 | Location, reporting line and patient-data access unstated | unknown | — | JD silent | Location may conflict with your constraints; how much patient data the role touches shapes how much HIPAA matters | `[inferred]` from the posting's silence | Where is this role based, who does it report to, and what patient data does it touch? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's own careers page before tailoring anything | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with "Designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift". Keep "behind" rather than "drove" unless the lift was yours alone | see R3 | `[grounded]` your wording, kept as given | pending your approval |
| E2 | Frame privacy work as "governed GDPR/CCPA consumer PII; built the warehouse consent-state model". Never as healthcare or HIPAA experience | see R9 | `[grounded]` your background | pending your approval |
| W1 | A sanitized excerpt of a monthly metrics memo as a writing sample | see R5 | `[grounded]` R5 | pending your approval |
| Q1 | Ask the verification questions from RR1, RR2, RR3, RR4 and RR5 in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

None of the wording above is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app Series C" was refused (web-search permission not granted). Would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range 2026" was refused. Would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like, I can save all of this as a `tuesday-dossier.md` to carry into later steps.

**Upgrade menu**
- A link to the live posting, or permission for web search → RR1 resolves and the cap on the decision lifts; a pay band fills the market calibration row.
- Your pay floor, location needs and work authorization → real hard-gate checks in place of "unknown".
- A sanitized memo, experiment readout or LookML excerpt → R5, R3 or R6 rises toward `high`.
- An answer to G3 → R7b's clinician bridge strengthens or resolves.
- The hiring manager's name → which verified story to lead with for that reader.
- A deeper research pass on Harborlight (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) → just say so and it runs.

**G1** — Have you ever helped another analyst get better: onboarding them, reviewing their SQL or test designs, or teaching PMs experimentation? What did you do, and what changed?

**G2** — In the Looker build, did you write the LookML model and settle the metric definitions yourself, or did someone else own the definitions while you built on top?

**Constraints** — Do you have any non-negotiables, such as a pay floor, remote or location needs, or visa sponsorship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.