Reading done — I've loaded the underwriting rules. Next I'll run one quick check that the Pellucid posting is live, then write up the assessment.
# Pellucid Learning — Senior Data Engineer

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Based in the US, remote, or in Denver)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery as the team's warehouse) · unclear: R9 (Ingestion from the app and CRM), R10 (Data contracts analysts depend on)

R8: a close bridge from Snowflake, with its limit named; R9, R10: not covered yet by anything you've told me.

**Opportunity ledger.** The pay is stated and sits above the market median (RR2), and the scope matches what the title usually means (RR5). Equity terms (RR3) and team and reporting line (RR4) are unknown. RR1 stays open only because my check of the posting was refused, not because anything looked wrong.

- **Hard gates:** none failed; unconfirmed: R1 (Based in the US, remote, or in Denver); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1, US-based and authorized to work; (2) the posting is still live on Pellucid's careers page (RR1); (3) you present BigQuery honestly as adjacent experience and never as experience you have (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016 in Denver, 264 employees, Series C of $52M in February 2026 | `[grounded]` the About text you pasted |
| Mandate | "Build and run the pipelines behind our tutoring platform's reporting": ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years DE; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting pipelines) and no people management mentioned. That is a normally scoped senior IC role, not several roles bundled into one | `[inferred]` from the JD's single mandate and its silence on reports |
| Market calibration | The report's Senior DE at Series B–D is 5–8 years and owns one domain's pipelines with no reports. The posting matches on both. Pay: the posting's $148k–$166k against the report's median of $151k and IQR of $139k–$163.5k. The posting's floor is $9k above the lower quartile, its midpoint ($157k) is $6k above the median, and its top is $2.5k above the upper quartile | `[generic]` Datawright 2026 report (n=2,310), as pasted; `[grounded]` JD for the posting's figures |
| First-90-days outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Team size and who the role reports to; equity form and size; first-year goals | — |
| Contradictions | None between the JD and the About text you pasted. Not checked against the live site (see Evidence status) | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the US, remote, or in Denver | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you're authorized to work in the US | `[grounded]` JD "Remote (US) or our Denver office"; your background is silent | Closing question R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. That is specific but self-reported, the ceiling at intake | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", self-reported | `[grounded]` your background | none |
| R4 | dbt | must_have | direct | medium | none | Built your company's dbt project, about 180 models | `[grounded]` your background | Upgrade menu: an inspectable sample raises it to high |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake satisfies "a cloud warehouse" as the JD words it | `[grounded]` your background and JD wording | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, the JD's named tool | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | none |
| R8 | BigQuery as the team's warehouse | important | adjacent | medium | transferability | The JD names BigQuery in the mandate, not the requirements. Your dbt work on Snowflake carries over to dbt modelling. The limit is that you've never used BigQuery itself | `[grounded]` JD lists "a cloud warehouse" as the requirement and names BigQuery in the mandate; your own words: "Never used BigQuery" | Gap queue G1 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | You describe the modelling, orchestration and testing layers, but not where the data came from or who built the ingestion | `[grounded]` your background is silent on sources | Closing question G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your GE suite is near this, but contracts with downstream users aren't mentioned | `[grounded]` your background is silent | Closing question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Carries over: dbt modelling, testing and Airflow orchestration. Limit: no hands-on BigQuery | Interviewers will probably ask about warehouse-specific topics like partitioning, cost control and SQL dialect | A small dbt project you run on BigQuery yourself | A public repo with that project | `[grounded]` your own words; `[generic]` that interviewers probe warehouse-specific topics |
| G2 | Ingestion from app and CRM (R9, important) | discovery | No ingestion sources named | It's one of the three named parts of the mandate | Loading product or application data into Snowflake; pulling a CRM (Salesforce, HubSpot) via API or a tool like Fivetran or Airbyte; building or maintaining CDC or batch loaders in Python | An Airflow DAG description or an architecture sketch | `[grounded]` JD mandate; your background is silent |
| G3 | Data contracts (R10, important) | discovery | GE suite, but no agreements with downstream consumers described | It's the part of the mandate analysts depend on directly | Agreeing schemas or SLAs with analysts or finance; dbt model contracts or exposures; alerting consumers when a source changes | A contract or schema doc, sanitized | `[grounded]` JD mandate; your background is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not independently confirmed (my check was refused) | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Pasted text may be stale. In general a posting may be out of date or aggregated, the entity may differ from its description, or it may not represent a real hiring employer. These are possibilities, none ranked as likely | `[generic]` pattern, not a claim about this company | Is the Senior Data Engineer role still open, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated and above the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent, and the band runs from above the report's lower quartile to above its upper quartile | `[grounded]` JD figure; `[generic]` report band | How do you decide where an offer lands within the band? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Its form, size and vesting can't be valued from the posting | `[inferred]` from the JD's silence on terms | What form does the equity take (options or RSUs), roughly how large, and on what vesting schedule? | unresolved |
| RR4 | Team and reporting line unstated | unknown | — | "Build and run the pipelines" | The role could be one engineer within a team or the only data engineer. The JD doesn't say which | `[inferred]` from the JD's silence on team | How many data engineers are there today, and who does this role report to? | unresolved |
| RR5 | Scope matches the market norm for the title | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | The single-domain IC scope matches the report's typical Senior scope | `[grounded]` JD; `[generic]` report | What would success look like at six months? | noted |
| RR6 | Recently funded | positive_signal | — | "Series C ($52M, February 2026)" | A recent raise makes near-term hiring credible | `[inferred]` from the pasted About text | How is the data team expected to grow after the Series C? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the stack overlap in your own words: "built our dbt project on Snowflake, about 180 models", Airflow orchestration, "set up our Great Expectations test suite" | Covers R4, R5, R6, R7 | `[grounded]` your background | pending your approval |
| A2 | Say plainly that you haven't worked in BigQuery and frame it as dbt-on-Snowflake experience moving to a new warehouse. Never list BigQuery as a skill | R8 is adjacent and listing it would be an unverified claim | `[grounded]` your own words | pending your approval |
| W1 | Optional: build a small dbt project on BigQuery and link it | Narrows the R8 limit with something an interviewer can inspect | `[generic]` what interviewers can check for this role family | pending your approval |
| Q1 | Ask the questions in RR1, RR2, RR3, RR4 and RR5 in screening calls | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search ("Pellucid Learning senior data engineer careers") was sent to check that the pasted posting and About text are current. Permission was refused. It would have resolved RR1 and confirmed the contradictions row in Role reality |
| 2. Role-family sweep | skipped | The Datawright report you pasted already settles the market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was nothing to search for |

I can save all of this as `tuesday-dossier.md` so you can carry it into later sessions.

## Upgrade menu

- **Allow web search:** RR1 closes, and the "posting is live" condition goes away.
- **Your pay floor and any must-haves (remote only, equity minimum):** I check them against the role as hard gates instead of marking them unknown.
- **A sanitized dbt or GE sample, or the W1 repo:** R4, R7 or R8 can move above `medium`.
- **The recruiter's name for the hiring manager:** a read on scope and which story to lead with.
- **A deeper research pass on Pellucid** (leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

**R1:** Are you based in the US and authorized to work here without sponsorship?

**G2:** At the payroll company, did you build or own any ingestion, such as loading application data or pulling from a CRM or other SaaS API? Which parts were yours?

**G3:** Have you set up agreed schemas, freshness SLAs or dbt contracts with analysts or other downstream teams, beyond the GE checks?

For any of these, answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.