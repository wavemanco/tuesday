Posting read. Now checking Quillfield's own site, market pay for the role, and the hiring manager's public profile.
I'd go for it, but as a stretch: you're short on two of the things they ask for. Quillfield checks out as a real company, and the pay is stated and in line with the market.

## Decision snapshot

**Yes, worth going for — but as a stretch on R5 and R6, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two days a week in the office)
- `must_have` — direct: R2a, R3, R4a · adjacent: R5 (Experience owning a forecast) · unclear: R2b (at a B2B software company), R4b (Spreadsheet modelling), R6 (Working with finance on billing or revenue data)
- `important` — direct: R7

R5 — a credible bridge from your monthly pipeline review, with its limit stated; R6 — still open: you've said the billing half isn't you, and the revenue-data half hasn't been asked yet.

**Opportunity ledger.** The posting is open about its terms: pay is stated and sits inside the market band (RR1). Still open: the role isn't on Quillfield's own site yet (RR2), it's unclear how forecast ownership is split with the CFO (RR3), and the share option terms aren't given (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) two office days in Bristol work for you — R1; (2) the forecast experience is described honestly as next to it, not as owning it — R5; (3) R6 stays a named gap, not something the wording covers up, and moves up only if G1 turns up finance-facing revenue work; (4) the posting is confirmed live — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) in April 2025 | `[grounded]` Quillfield "About" page, search result |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; before that, four years as sales operations manager at Corvane Payments | `[grounded]` public LinkedIn profile, search result |
| Scope read | One lead covering CRM, billing data, reporting and the forecast. That breadth is ordinary for one RevOps role at a company of about 100, and it sits under a Head of RevOps, so it isn't the whole function | `[inferred]` from the posting's mandate set against headcount and the hiring manager's title |
| Market calibration | Ledgerline's 2026 guide puts UK B2B software RevOps leads at a median base of £64,200, with an interquartile range of £57,800–£70,400. The posting's range falls inside that, either side of the median. The band is the market, not Quillfield's offer | `[generic]` role-family sweep, 2026 pay guide; `[grounded]` posting, for the stated range |
| Unknowns | Who owns the forecast number between this role and the CFO; option terms; whether the role is live on Quillfield's own channels; your stage (I've assumed you're still evaluating) | — |
| Contradictions | None found. The posting's Bristol location matches the company's | `[grounded]` posting and About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The posting states the term; you haven't said where you live or what attendance works for you | `[grounded]` posting; your background is silent on it | Closing question R1 |
| R2a | 4+ years in revenue operations or sales operations | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. Specific, but self-reported and not yet probed | `[grounded]` your background | none |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | You said "B2B payments company". Whether it sells software isn't stated. The posting names the sector, so a literal screen may read it that way | `[grounded]` your wording; `[generic]` that length-and-sector lines are often screened literally | Gap queue G3 |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. A certificate can be checked, but none has been seen yet | `[grounded]` your background | Upgrade menu: certification record |
| R4a | Strong SQL | must_have | direct | medium | none | "SQL weekly", stated plainly | `[grounded]` your background | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows how often you use it, not that you build models | `[grounded]` your wording | Gap queue G4 |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is the input side of a forecast. Its limit is that you've never owned the company forecast; finance did | `[grounded]` your background, including the limit you stated | Gap queue G2 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've ruled out billing data yourself. Whether your renewal dashboards or the pipeline review fed finance's revenue work isn't stated | `[grounded]` your background | Gap queue G1 |
| R7 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them is the R6 question | `[grounded]` your background; `[grounded]` posting responsibility | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working with finance on revenue data (R6, must_have) | discovery | Billing ruled out; revenue-data contact with finance not established | It's the must-have furthest from established. Recovering it narrows the stretch to R5 alone | Renewal numbers finance pulled into their forecast or board pack; reconciling CRM bookings against finance's figures; agreeing definitions (ARR, churn, renewal rate) with finance; handing pipeline data into finance's monthly process | A sanitized dashboard screenshot, a data-definitions doc, a reconciliation sheet | `[grounded]` your background; `[inferred]` that recovery narrows the stretch |
| G2 | Owning a forecast (R5, must_have) | transferability | Monthly pipeline review run with the sales director; the forecast sat with finance | The posting has you running the quarterly forecast with the CFO | Carries over: pipeline review discipline, stage hygiene, rep-level calls. Limit: no ownership of the company number and no CFO-facing forecast. Strengthener: a sanitized pipeline-review pack, or a written example of turning pipeline into a quarterly projection | A sanitized pipeline-review pack | `[grounded]` your background, including its limit |
| G3 | B2B software company (R2b, must_have) | discovery | "B2B payments company", product type unstated | Decides whether the sector line reads as met | A SaaS or platform product your employer sells; subscription or renewal revenue (your renewal dashboards suggest it) | Company description or product page | `[grounded]` your wording; `[inferred]` from the renewal dashboards |
| G4 | Spreadsheet modelling (R4b, must_have) | discovery | Daily Excel use; no model mentioned | Forecasting work leans on modelling | A capacity, quota or territory model; a renewal or churn projection; scenario tabs for the pipeline review | A sanitized model | `[grounded]` your wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The terms are open, and the pay fits the seniority | `[grounded]` posting; `[generic]` band from the Ledgerline 2026 guide | Where in the range do you expect to land for someone with this background? | noted |
| RR2 | Role not found on Quillfield's own site | unknown | — | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | Quillfield may hire through job boards and recruiters, or the listing may have gone up before its own site was updated | `[grounded]` quillfield.co.uk/careers returned no page; `[generic]` that small companies often list only on job boards | Is this role open now, and is the Tallyboard listing current? | unresolved |
| RR3 | Forecast ownership shared with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast while the CFO owns the number, or own it outright | `[inferred]` from the posting's "with" | Who signs off the quarterly number, and what does this role own in it? | unresolved |
| RR4 | Option terms unstated | unknown | — | "plus share options" | The options may be material or token | `[generic]` early-stage option grants vary widely | What's the option grant and vesting schedule for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the office days work before applying | see R1 | `[grounded]` posting | pending your approval |
| A2 | Put the forecast honestly, in your own words: "I run the monthly pipeline review with our sales director; the company forecast sat with finance." Then say what you'd need to learn | see R5, G2 | `[grounded]` your background | pending your approval |
| A3 | Lead with the pipeline and renewal dashboard rebuild. Tamsin Achebe's own path was sales ops at a payments company, so your setting will be easy for her to follow; don't use that as a reason to overclaim | see R7; hiring manager row | `[grounded]` public profile; `[inferred]` that the setting will read clearly | pending your approval |
| W1 | A sanitized pipeline-review pack or renewal-dashboard screenshot | see R5, R7 | `[grounded]` your background | pending your approval |
| A4 | Ask the recruiter whether the role is live and how forecast ownership splits with the CFO | see RR2, RR3 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions from RR1–RR4 in the loop, word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved the organization and contradictions rows, and RR2 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row and A3 |

I can also write all of this up as a `tuesday-dossier.md` you can keep and build on. Just ask.

**Upgrade menu**
- Your location and office-day limits → R1 resolves to met or failed.
- A salary floor → checked against £61,500–£67,000 and the band.
- An answer to G1 → R6 moves, and the stretch may narrow to R5 alone.
- Your Salesforce certification record → R3 to `high`.
- A sanitized pipeline-review pack or model → R5 and R4b strengthen.
- A deeper research pass on Quillfield (leadership changes since the Series A, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds the risk register. Say the word and it runs.

**Questions**

R1 — Can you be in Quillfield's Bristol office two days a week?

G1 — Has finance ever used numbers you produced, like renewal figures, pipeline data or definitions you agreed with them? What part was yours?

G3 — Does your current company sell software, and is its revenue subscription or renewal-based?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.